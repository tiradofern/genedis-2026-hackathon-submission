# Independent final scientific and preparation review

**Verdict: acceptable for investigator review as an NSCLC computational reconstruction and longitudinal-cohort feasibility submission.** No material scientific or source-only packaging defect remains in the reviewed scope. This verdict is not permission to upload, email, change access, select a project license, or assert a resistance discovery.

## Accepted evidence

- The fresh source recovery verifies all 47 frozen inputs. Two new local builds reproduce the 507 LUAD/481 LUSC source-patient backbone and all 25 provisional programs. The independent export check verifies all 1,904 complete gene-loading rows against the recovered bootstrap.
- Fresh core checks pass: 28 Python tests, five frontend tests, syntax/compile and real-data desktop/mobile browser checks. Reviewed figures accurately present inventory and fixed gene-set overlap, without patient resistance effects.
- The accepted extracted-archive reconstruction is `submission/archive_replay_pinned_2026-10-31.json`. It explicitly invokes the existing `.venv`, verifies NumPy 2.3.3 and SciPy 1.16.2, rechecks all 47 copied cached inputs, passes six checks, reproduces the semantic bootstrap after excluding only creation time, and matches all eight other deterministic prepared-artifact hashes. Independent comparison confirms exact bootstrap equality in the extracted directory.
- This is a clean-directory archive transport/reconstruction using verified cached public inputs and an existing pinned environment. It is not a fresh dependency installation, second full network retrieval, independent biological cohort or replay of the heavy historical phylogeny/normal-reference pipelines.
- Both longitudinal candidate gates remain closed. No primary paired program scores, effects or inferential P values were generated. The result is untested/inconclusive feasibility, not evidence against recurring adaptations.

## Retained failure and limitations

The first extracted-archive attempt is preserved in `submission/archive_replay_2026-10-31.json` with `review_required`. Resolving the virtual-environment executable symlink selected the base interpreter. Independent comparison found only two bootstrap differences: recorded NumPy 2.3.5 instead of 2.3.3 and SciPy 1.17.0 instead of 1.16.2; all eight other prepared files matched. This was an environment-provenance failure, not an observed biological or numerical discrepancy. The helper now preserves the invocation path with `.absolute()` and checks exact dependency versions before preparation. The pinned second attempt is the accepted result.

Historical aggregate program summaries agree, but exact historical full gene-membership identity remains unavailable. Same-source computational repeatability does not establish program stability, holdout preservation, a biological tier, resistance specificity or causality. Existing negative evolutionary findings and failed normal-reference rejection remain visible.

## Archive and claim review

The explicit allowlist, builder and verifier were reviewed. Initial missing independent-review and fresh-log entries were corrected. Independent positive/negative path checks and actual preflight archive inspection verify required reviews, complete definitions, source terms and logs, while excluding raw expression, prepared patient matrices/SQLite, downloaded publications/supplements, installed environments, credentials, Git internals and personal handoff transcripts. The corrected replay helper is included in the second preflight archive. Full checksum inventories and regular-entry/path checks pass.

Small frozen MSigDB definitions have their separate CC BY 4.0 attribution/version/terms. Historical TRACERx academic/noncommercial restrictions and upstream Auspice AGPL terms remain separate from the pending project software license. Nothing in this review grants unrestricted source-data redistribution or public-hosting rights.

The final reviewer entrypoint and scientific summary make the correct claim: a reconstructable multi-omics exploration tool, accurately bounded provisional-program inventory and audited decision to withhold unsupported longitudinal inference. They distinguish recurrence, resistance enrichment, selection and functional contribution; no validated Molecular Survival Island is claimed.

## Final transport checkpoint

The final clean-commit ZIP still receives an external content/hash check after the commit and build. That check must confirm the accepted pinned report and all logs are included, both cohort gates remain closed, and core model/source manifests are unchanged from the reviewed reconstruction. A final archive cannot contain its own final-byte checksum; use the generated package inventory plus an external archive SHA256.

No additional biological analysis is required to complete this bounded submission. Investigator review of the exact final package, intended distribution terms and explicit organizer-delivery approval remains the final step requested by the investigator.
