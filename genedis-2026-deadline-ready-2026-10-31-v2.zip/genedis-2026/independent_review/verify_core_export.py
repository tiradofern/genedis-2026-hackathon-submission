"""Independently verify recovered program definitions and two fresh builds.

This reads existing artifacts only. It performs no discovery, refitting or
biological validation. Run after the two documented explorer builds exist.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np


def verify(root: Path) -> dict:
    first_path = root / "data/processed/explorer_release_2026-10-31"
    second_path = root / "data/processed/explorer_release_rerun_2026-10-31"
    first = json.loads((first_path / "bootstrap.json").read_text())
    second = json.loads((second_path / "bootstrap.json").read_text())
    first.pop("created_utc", None)
    second.pop("created_utc", None)
    expected = {}
    for code, cohort in first["cohorts"].items():
        for program in cohort["programs"]:
            assert program["gene_count"] == len(program["genes"])
            assert abs(sum(g["weight"] ** 2 for g in program["genes"]) - 1) < 1e-10
            for gene in program["genes"]:
                key = code, program["id"], gene["id"]
                assert key not in expected
                expected[key] = gene["symbol"], gene["weight"]

    definitions = root / "release_recovery/program_definitions_2026-10-31.tsv"
    with definitions.open(newline="") as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    actual = {}
    for row in rows:
        key = row["cohort"], row["program_id"], row["entrez_id"]
        assert key not in actual
        assert row["computational_status"] == "provisional_module"
        assert row["biological_tier"] == "unassigned"
        loading = float(row["pc1_loading"])
        assert math.isfinite(loading)
        actual[key] = row["source_symbol"], loading
    assert actual == expected
    assert first == second

    arrays = {}
    for code in ("LUAD", "LUSC"):
        with np.load(first_path / f"{code}_matrices.npz", allow_pickle=False) as left:
            with np.load(second_path / f"{code}_matrices.npz", allow_pickle=False) as right:
                assert set(left.files) == set(right.files)
                arrays[code] = {
                    key: bool(np.array_equal(left[key], right[key], equal_nan=True))
                    for key in left.files
                }
                assert all(arrays[code].values())

    digest = hashlib.sha256(definitions.read_bytes()).hexdigest()
    recovery = json.loads((root / "release_recovery/core_recovery_final_2026-10-31.json").read_text())
    assert digest == recovery["program_definitions"]["sha256"]
    return {
        "status": "passed",
        "method": "Independent exact key/value comparison of complete exported gene definitions to recovered bootstrap; independent exact semantic bootstrap and matrix-array comparison between two fresh builds. No refitting and no biological validation.",
        "export_rows": len(rows),
        "programs": len({(row["cohort"], row["program_id"]) for row in rows}),
        "rows_by_cohort": dict(Counter(row["cohort"] for row in rows)),
        "export_sha256": digest,
        "export_matches_bootstrap": True,
        "semantic_bootstrap_exactly_equal_excluding_created_utc": True,
        "matrix_arrays_exactly_equal": arrays,
        "historical_full_membership_identity": "not established; original full membership artifact unavailable",
        "review_note": "Final recovery report points at a temporary verification export path; bundled release_recovery/program_definitions_2026-10-31.tsv has the recorded hash.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    print(json.dumps(verify(args.root), indent=2))


if __name__ == "__main__":
    main()
