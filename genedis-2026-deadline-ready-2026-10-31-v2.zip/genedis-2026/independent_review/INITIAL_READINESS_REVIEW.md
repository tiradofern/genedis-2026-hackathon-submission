# Independent scientific and release readiness review

Review date: October 31, 2026. Initial source: cumulative commit `a4edb2ba85daef38f38b4d9a3c4cbaa1516df0b9`. This review is additive. It does not replace historical analyses or independently certify unexecuted reconstruction.

## Current disposition

**Release candidate preparation may proceed. Scientific conclusions and external submission remain conditional.** The strongest minimum submission is a reproducible NSCLC exploration tool with an accurate inventory, provisional RNA programs, explicit negative findings, and a bounded paired-expression feasibility/pilot extension. No validated Molecular Survival Island or causal resistance mechanism is established by the existing repository.

## Verified existing evidence

- The recorded primary-tumor multi-omics intersection contains 507 LUAD and 481 LUSC participants. They are separate histologies, not longitudinal resistance cohorts. The frozen training/evaluation partitions are 354/153 and 336/145 respectively.
- The dated preparation report records 14 LUAD and 11 LUSC training-derived RNA programs. Every recorded program is provisional, has no assigned biological evidence tier, and lists resampling and holdout preservation as not run. Recorded training coordination is not independent validation.
- The route analyses preserve important negative findings. The original LUAD source-tree analysis has no BH-significant result across 132 tested directions; expanded analyses have no significant direction across 306 LUAD and 56 LUSC tests; the CNA analysis has no significant direction across 1,450 LUAD and 1,100 LUSC tests. Source trees, inferred CNA region trees, and population dependency models measure different objects.
- The normal-reference extension has not projected tumors. The HLCA rejection gate failed; unsupported Mesothelium profiles were accepted as fibroblasts. GTEx also has weak off-reference rejection. Classification accuracy among represented normal classes does not establish valid malignant-cell mapping, tumor origin, ancestry, or a usable resistance reference.
- The root project license remains pending selection. Auspice 3.1.0 is separately AGPL-3.0-only. TRACERx source guidance explicitly preserves academic/noncommercial restrictions and does not infer redistribution or hosting permission from public accessibility.

These statements are based on the checked-in scientific record, not a fresh replay. The new release must separately report which datasets/artifacts were recovered, which analyses were executed again, and which results remain historical only.

## Scientific claim boundaries

1. **Recurrence:** repeated features or same-direction program changes among independent resistant patients can be described when patient independence, exposure, specimen timing, pairing, multiplicity, and replication requirements are satisfied. A missing responder group does not automatically invalidate this level.
2. **Resistance enrichment:** requires appropriate non-resistant comparators and explicit confounding assessment. Resistant-only or pre/post-resistant pairs alone cannot establish enrichment specific to resistance.
3. **Treatment-associated selection:** requires evidence resolving change in clone abundance/fitness or another justified evolutionary design. Paired bulk expression alone cannot distinguish selection of pre-existing clones, cell-state plasticity, composition, sampling-site change, or technical effects.
4. **Functional contribution:** requires perturbation or comparable mechanistic evidence. Recurrence, prognosis, pathway annotation, and a displayed network do not establish a resistance mechanism.

For the conditional pilot, predefined Hallmark rank-score changes measure transcriptional program shifts. They are not genomic conservation, pathway flux, independently discovered modules, or evidence of gene coordination. Any tumor-intrinsic interpretation requires evidence beyond bulk profiles, especially for interferon and EMT signals.

## Preconditions for an inferential paired pilot

- Freeze exact gene lists, score definition, tested directions, eligibility, patient-level pair selection, primary contrast, missingness/coverage gates, multiplicity family, and sensitivity rules before observing program effects.
- Verify acquired resistance at the patient level. Do not silently combine primary resistance, stable disease without an accepted acquired-resistance definition, scheduled on-treatment sampling, progression after intervening therapy, cell lines, and post-treatment samples without an eligible pretreatment partner.
- Preserve one independent patient as the experimental unit. Multiple progression specimens must not inflate sample size. Selection among eligible samples must use a prespecified clinical rule, never favorable expression effects.
- Require usable sample provenance for specimen site and processing. Complete confounding of treatment state with site or processing blocks an inferential change claim. Unknown provenance stays unknown; filenames are not inferred batch labels.
- Use within-cohort paired contrasts and compare effects across cohorts. Do not pool expression matrices or correct a perfectly confounded design using unidentifiable batch adjustment.
- Report each cohort's effect, uncertainty, raw paired changes and exact denominator. A shared effect requires independently adequate evidence in each cohort, not a pooled result driven by one cohort.
- If only one cohort passes, label it a single-cohort pilot; it cannot demonstrate cross-cancer recurrence. If neither passes, a feasibility/negative readiness report is a valid result.
- Exact sign-flip testing requires symmetry/exchangeability of paired errors under the null; this is not randomized treatment assignment. Report assumptions, attainable p-values and the full testing family. A four-patient same-site subgroup cannot attain a one-sided p-value below 1/16 before correction.

## Release checks to complete

- Recover or reproduce full program memberships/loadings and source provenance before presenting a runnable program explorer. A dated hash alone does not provide a missing artifact.
- Separate deterministic scientific outputs from timestamps, path differences and line-ending differences. Do not reinterpret benign serialization changes as biological differences, or dismiss numerical changes without comparing them.
- Independently inspect actual figures and machine-readable results, including sample counts, exclusions, corrected p-values, uncertainty, negative outcomes, and unsupported claims.
- Build the final archive from an explicit allowlist. The historical `scripts/package_audit.py` recursively includes most local files and does not exclude `.env` or all ignored prepared data; it is unsuitable unchanged for the expanded checkout.
- Exclude credentials, raw datasets, local patient-level outputs and installed third-party runtimes from a default review archive. Supply source-specific retrieval instructions and terms instead; decide any redistribution separately.
- State that the project license is unresolved. Do not describe the project as MIT or open source. Any upstream code license is separate from the project and source-data terms.
- Provide a reviewer entry point, pinned environment, exact commands, fresh test logs, artifact checksums and a clear list of features that require additional retrieval/runtime setup.
- Check the organizer's actual submission requirements and timezone against a primary source; the PI-provided operational deadline is 6:00 p.m. Eastern on October 31, 2026. An inaccessible private repository is not an organizer-accessible submission link.
- Keep final upload, access changes, external messages and merges outside the current release-preparation actions.

## Open review items

The final independent verdict is pending the frozen protocol, cohort eligibility manifest, reconstructed core artifacts, fresh verification results, pilot/feasibility outputs, source/terms manifest and final archive contents. This initial review does not certify those items.
