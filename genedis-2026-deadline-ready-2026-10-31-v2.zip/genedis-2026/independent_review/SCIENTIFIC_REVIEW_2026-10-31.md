# Independent review of the bounded scientific submission

## Verdict

**Scientifically acceptable as an NSCLC computational reproducibility and longitudinal-data feasibility submission.** The present evidence does not support a new cross-cancer program-change result or a validated Molecular Survival Island. Both candidate longitudinal cohorts fail the frozen inferential readiness gate, so primary program scoring, paired effects and inferential P values must remain unperformed.

This verdict is conditional on final packaging accurately preserving these limits. Organizer submission, repository access changes, project-license selection and any new inferential analysis remain separate investigator decisions.

## Materials reviewed

- Cumulative source at `a4edb2ba85daef38f38b4d9a3c4cbaa1516df0b9`, local `AGENTS.md`, scientific source/method guides and dated preparation report.
- `pilot/PROTOCOL_2026-10-31.md`, six-program release manifest, membership/terms documents and both cohort gates.
- Fresh source recovery, same-environment rebuild reports, exported full program definitions, test logs and real-data browser screenshots.
- Independent exact export/bootstrap and first/second-build array comparisons, saved in `core_export_review.json`.

## Verified support for the minimum submission

The recovery report records 47/47 historical source files with 647,110,442 bytes and matching historical identities. Fresh tests record 28 passing Python tests, five passing frontend tests, passing compile/syntax checks and a successful real-data browser smoke check. Reviewed screenshots visibly retain provisional program status, missing preservation and unassigned biological tiers.

The independent export check confirms **1,904 gene-loading rows across 25 programs**: 905 LUAD and 999 LUSC rows. Every program/gene identifier, source symbol and loading equals the recovered bootstrap; there are no duplicate program/gene keys or nonfinite weights, and PC1 loading vectors have unit norm. The two new builds have exactly equal semantic bootstraps after removing only creation time, and all saved matrix arrays are exactly equal. This is same-code, same-source, same-environment computational repeatability, not biological replication.

The fresh recovered summaries agree with the historical program metrics. The original complete membership artifact was not available, however, so exact historical membership identity is **not established**. Changes in whole-file fingerprint or binary serialization must not be equated with biological differences, and summary agreement must not be equated with unavailable historical full-artifact identity.

The independent artifact check can be repeated without modifying outputs with `.venv/bin/python independent_review/verify_core_export.py` after the documented two builds. It requires the pinned NumPy environment and local prepared artifacts; those patient-level artifacts are not bundled in the review archive.

## Longitudinal gate review

| Cohort | Verified public inventory | Current readiness verdict |
| --- | --- | --- |
| GSE65185 melanoma | 70 expression columns: 62 patient tumors and eight experimental cell-line samples; 19 title-defined patient IDs; at most 18 patients with a nominal pretreatment sample | Descriptive feasibility only. Sample identity/regimen contradictions, specimen-site and clinical-timing gaps, processing provenance and unresolved original supplementary metadata block inference. The already resistant Pt21 surrogate is not an untreated baseline. Multiple progression biopsies are not independent patients. |
| GSE248249 NSCLC | 42 profiles, 29 author-defined patients, 13 nominal pretreatment/progression pairs, four matching broad-site pairs | Stop inferential testing. Patient-level strict acquired-resistance response crosswalk, processing-batch assignment, final normalization and feature mapping are unresolved; nine pairs change broad anatomic site. Four broad-site matches are not verified same lesions and cannot attain one-sided exact p below 1/16. |

Zero fully verified eligible pairs means **zero adjudicated ready pairs at this audit**, not that no eligible pairs exist. A failed supplement retrieval does not prove that the needed metadata are absent from all public sources. Both cohorts could be reassessed after appropriate documentation and a new prospective protocol decision.

These findings are an untested/inconclusive molecular result. They must not be reported as absent program change, absent convergence, or refutation of the central hypothesis. Missing non-resistant comparators would limit resistance-specific enrichment, but do not themselves invalidate a properly controlled recurrence study.

## Statistical and measurement review

No critical statistical defect was identified in the frozen protocol. It fixes the full six-program/two-direction family, uses p=1 for unassessable hypotheses, defines the single-cohort fallback, and preserves paired patient independence. Conditional on valid per-cohort directional tests, `max(p_melanoma,p_NSCLC)` is a valid same-direction conjunction test and Benjamini–Yekutieli correction over all 12 hypotheses accommodates arbitrary dependence, including overlapping interferon sets.

Exact paired sign flips require symmetric/exchangeable paired differences under the null; pairing alone is insufficient and treatment was not randomized. Bootstrap intervals are approximate, pointwise descriptive intervals with limited small-sample reliability. The small-n attainable-P constraint is mathematical feasibility, not an observed biological result. No post-effect test substitution or family reduction is justified.

The program verification command passed: six intact human MSigDB 2024.1.Hs Hallmarks, 985 unique symbols, source/panel hashes preserved. Source terms and citation are documented. Definitions were frozen before patient program scoring. These are literature-informed published signatures, not de novo discovered resistance modules. Relative rank-score changes would not establish flux, absolute expression change, genomic conservation, internal coordination or a cancer-cell-intrinsic mechanism. IFN alpha/gamma substantially overlap; melanoma EMT annotation does not demonstrate literal epithelial transition.

Any future inference must distinguish recurrence, enrichment relative to appropriate non-resistant comparators, treatment-associated selection, and functional contribution. Legacy biological tiers are a separate axis; neither fixed score recurrence nor software reproducibility automatically assigns a tier.

## Findings that must remain visible

- All 25 legacy RNA programs remain provisional, without completed stability/preservation or biological tier assignment.
- TCGA population models and TRACERx mutation/CNA route analyses do not establish a reliable shared evolutionary route; their null, unresolved-order and held-out limitations remain part of the scientific record.
- Normal-reference classification does not validate tumor projection. The failed HLCA rejection gate, unsupported-class false assignments and weak GTEx off-reference rejection must not be hidden behind represented-class accuracy.
- No current analysis establishes a conserved genomic region, treatment selection, resistance-specific enrichment, functional resistance mechanism or clinical utility.

## Release disposition

The proposed release can accurately demonstrate a recovered multi-omics explorer, complete provisional-program definitions, reproducibility evidence, negative findings and an auditable feasibility decision. It should not include a decorative network labelled as a newly discovered MSI.

Final archive/allowlist review is recorded separately when the package is available. Project software licensing is still pending; upstream software and dataset terms are separate. Raw datasets, installed runtimes, credentials and unrestricted patient-level output redistribution must not be inferred from permission to prepare a review package. No external upload is authorized by this review.
