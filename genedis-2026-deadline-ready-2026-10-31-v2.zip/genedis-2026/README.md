# GeNeDis 2026 — Molecular Survival Islands research workflow

**Start with the [submission reviewer README](submission/REVIEWER_README.md) and [scientific summary](submission/SCIENTIFIC_SUMMARY.md).** These describe the current deadline-ready materials, installation, sources, executed results, QC and limitations. The package and Gmail message are prepared for investigator review; **nothing is submitted or sent by preparing them**.

The project has two distinct contributions:

- **NSCLC multi-omics backbone:** a reproducible local explorer linking RNA, copy-number, reported variants and clinical/specimen metadata for **507 LUAD and 481 LUSC tumors**, with **25 provisional RNA programs**. These are not validated resistance mechanisms.
- **Exploratory acquired-resistance measurements:** all **50 published Hallmark programs** retained across two MCC patients and one melanoma patient; 46 activity summaries and 31 conditional coordination endpoints are assessable. The melanoma endpoint has six lineage-positive putative malignant cells, and the stricter five-cell mask cannot assess coordination. The conditional OXPHOS observation does not qualify as an MSI. **Robust discovery is inconclusive; independent NSCLC validation was not reached.**

The [complete cellular results](pilot/cellular_2026-10-31/RESULTS_2026-10-31.md), [figures](pilot/cellular_2026-10-31/figures/README.md), [exact reconstruction instructions](pilot/cellular_2026-10-31/EXECUTION_REPRODUCIBILITY.md) and [independent evidence review](pilot/cellular_2026-10-31/FINAL_EVIDENCE_REVIEW.md) preserve negative and unavailable results. Exact numerical replay and fresh preparation matched; computational reproducibility does not establish resistance specificity, convergent selection, genomic conservation or causality.

Use [core reconstruction instructions](release_recovery/README.md) to install and launch the NSCLC explorer. Large public source files and cell-level intermediates are retrieved locally through documented accession/URL/hash manifests; they are not bundled. The previous scientific release and original review archive remain preserved. Final delivery requires an explicit instruction; the current request authorizes an **unsent Gmail draft only**.

## Preserved research and collaboration context

The material below records earlier research context and workflows. Current executed findings and submission claims are governed by the entry points above; historical pending-work statements do not supersede the current reports.

Private collaboration workspace for Fernanda Tirado and Justin, using Codex with one shared project repository.

**Start with [Current status](docs/CURRENT_STATUS.md), [Decisions](docs/DECISIONS.md), and [Shared tasks](docs/TASKS.md).** [Working together through Codex](docs/TEAM_WORKFLOW.md) explains setup and review. Durable Codex guidance is in [AGENTS.md](AGENTS.md).

## Scientific scope

The current aim is to investigate candidate coordinated molecular survival programs in NSCLC, including functionally related states that may arise through different genomic routes, and their pathology, IHC, and clinical correlates. The first local app uses 507 TCGA LUAD and 481 TCGA LUSC primary tumors with verified RNA, CNA and mutation-assay coverage. See [verified data readiness](docs/PUBLIC_DATA_READINESS.md), [initial candidate-island criteria](docs/CANDIDATE_ISLAND_CRITERIA.md), and the [app guide](docs/EXPLORER_GUIDE.md). The preferred presentation narrative is Gross -> Scope -> Genomics -> Population-Level Discovery. The app displays 25 provisional RNA programs; no reproducible island or biological evidence tier has been established.

## Run the first local app

On the prepared Windows checkout, run `& '.\Start Explorer.ps1'` from this directory and open **http://127.0.0.1:8766**. For a fresh checkout, follow the [environment and source preparation steps](docs/EXPLORER_GUIDE.md). The app supports molecular/pathology inspection, DNA and RNA filters, program scores, frozen group comparisons, and CSV/JSON exploration exports. RPPA availability and GDC slide links are recorded separately; IHC and grade remain unavailable. Raw inputs and generated matrices are not committed.

The October 14 selected study of acquired PD-(L)1 resistance in GSE248249 remains preserved as prior work, with 13 complete patient pairs among 42 profiles/29 patients. Its role in the broader demonstration is unresolved. GSE207422 bulk remains a separate baseline pathologic-response comparison. Complete annotation and batch/site QC remain prerequisites for inferential use. The dated audit documents and `configs/design_status.json` describe the earlier audit state; current direction is recorded in the status and decision documents.

Read the [project overview](docs/PROJECT_OVERVIEW.md), [scientific decision report](docs/scientific_decision_report.md), and [dataset feasibility assessment](docs/dataset_feasibility.md). The original concept is retained in `docs/original_handoff.txt`; use the audited and subsequently accepted decisions where the design changed.

## Justin's initial review

Use [the review prompt](reviews/REVIEW_PROMPT.txt) and [evidence guide](reviews/REVIEW_GUIDE.md). Save the completed report as `reviews/justin-initial-review.md`, using [the template](reviews/REVIEW_TEMPLATE.md), on a review branch. Return a pull request link so feedback and follow-up stay with the project.

## Reproduce the dataset audit

Python 3.11+; the audit uses only the standard library. Small curated metadata, sample manifests, source references, and the dated audit outputs are versioned. Complete expression matrices remain downloadable inputs.

```powershell
python scripts/download_data.py --small-matrices --comparison-matrix --additional-metadata --list
python scripts/download_data.py --small-matrices --comparison-matrix --additional-metadata
python scripts/audit_metadata.py
python -m unittest discover -s tests -v
```

Run the writing audit in a working copy when reviewing the historical baseline. Metadata-only reruns change the current report and do not reconstruct full expression checks; preserve `results/reports/audit_summary_2026-10-14.json`.

The earlier GEO processed expression inputs total about 25 MB compressed. The separate October 17 TCGA verification retrieved approximately 647 MB of processed sources and metadata, retained outside Git. Rebuild that audit with `python scripts/audit_public_tcga.py --download --include-mutations`; its source inventory, sample crosswalk, slide manifest, and readiness report are versioned. Large raw files, credentials, and personal conversation histories are excluded. Optional paper-metadata endpoints failed during the initial audit and are not prerequisites. See [reproducibility](docs/reproducibility.md), [limitations](docs/limitations.md), and the [audit-era README](docs/audit_README_2026-10-14.md).

## Collaboration and release

Use a branch and pull request for substantive reviews and changes. The task list and decision log record agreed ownership and scientific adjudication. Repository invitations and each user's Codex/GitHub access are separate from the project documents. The project release license remains pending; source data keep their applicable terms.

The event page checked October 14 listed October 31, 2026 for submission. The cutoff time/timezone and registration-specific template remain to be confirmed. This repository is a working research project, not a completed hackathon submission.
