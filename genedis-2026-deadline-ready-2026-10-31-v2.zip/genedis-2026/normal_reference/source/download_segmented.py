"""Bounded range transfer for the same pinned inputs; final whole-file checks remain mandatory."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
import urllib.request

from .download import HERE, CHUNK, atomic_json, verify

SEGMENT = 32 * 1024 * 1024


def sha256(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(CHUNK):
            result.update(chunk)
    return result.hexdigest()


def range_binding(spec: dict, start: int, end: int) -> dict:
    return {
        "contract_sha256": spec["contract_sha256"], "pinned_url": spec["pinned_url"],
        "source_size_bytes": spec["size_bytes"], "source_etag": spec.get("source_etag"),
        "source_generation": spec.get("generation"), "dataset_version_id": spec.get("dataset_version_id"),
        "start": start, "end": end, "expected_content_range": f"bytes {start}-{end}/{spec['size_bytes']}",
    }


def range_segment(spec: dict, start: int, end: int, destination: Path) -> Path:
    path = destination / f"{spec['key']}.{start:012d}-{end:012d}.segment"
    receipt_path = path.with_name(path.name + ".receipt.json")
    binding = range_binding(spec, start, end)
    expected = end - start + 1
    if path.exists() and receipt_path.exists() and path.stat().st_size == expected:
        receipt = json.loads(receipt_path.read_text())
        if all(receipt.get(key) == value for key, value in binding.items()) and receipt.get("sha256") == sha256(path):
            return path
        raise ValueError("Existing range receipt/content/source binding changed")
    # Size or a filename is not provenance. Unreceipted old ranges are fetched again.
    temp = path.with_name(path.name + ".tmp")
    request = urllib.request.Request(spec["pinned_url"], headers={"Range": f"bytes={start}-{end}"})
    with urllib.request.urlopen(request, timeout=120) as response:
        if response.status != 206 or response.headers.get("Content-Range") != f"bytes {start}-{end}/{spec['size_bytes']}":
            raise ValueError("Pinned endpoint did not honor an exact range")
        if spec.get("source_etag") and response.headers.get("ETag") != spec["source_etag"]:
            raise ValueError("Pinned object ETag changed during range transfer")
        if int(response.headers["Content-Length"]) != expected:
            raise ValueError("Range content length changed")
        with temp.open("wb") as stream:
            while chunk := response.read(CHUNK):
                stream.write(chunk)
                if stream.tell() > expected:
                    raise ValueError("Range exceeded the contracted size")
    if temp.stat().st_size != expected:
        raise ValueError("Truncated range; retained partial is never considered complete")
    os.replace(temp, path)
    atomic_json(receipt_path, {**binding, "sha256": sha256(path), "fetched_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "guarded_exact_response": True})
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--contract", type=Path, default=HERE / "input_contract.json")
    parser.add_argument("--workers", type=int, choices=[2, 4, 8], default=8)
    parser.add_argument("--keys", nargs="+", default=["gtex_tpm", "hlca_core"])
    args = parser.parse_args()
    contract_bytes = args.contract.read_bytes()
    contract_hash = hashlib.sha256(contract_bytes).hexdigest()
    contract = json.loads(contract_bytes)
    specs = [{**x, "contract_sha256": contract_hash} for x in contract["files"] if x["key"] in args.keys]
    if len(specs) != len(args.keys) or sum(x["size_bytes"] for x in contract["files"]) >= contract["download_budget_bytes"]:
        raise ValueError("Unknown keys or out-of-budget contract")
    destination = HERE / "data/downloads"
    segments = HERE / "data/segments"
    segments.mkdir(parents=True, exist_ok=True)
    receipts_path = HERE / "data/download_receipts.json"
    receipts = json.loads(receipts_path.read_text()) if receipts_path.exists() else {}
    if any(v.get("contract_sha256") != contract_hash for v in receipts.values()):
        raise ValueError("Existing receipt contract changed")
    if shutil.disk_usage(destination).free < 2 * sum(x["size_bytes"] for x in specs) + 1_000_000_000:
        raise ValueError("Insufficient disk for bounded ranges and assembly")
    pending_specs, requests = [], []
    prefix_lengths = {}
    for spec in specs:
        target = destination / spec["filename"]
        if target.exists():
            hashes = verify(target, spec)
            receipts[spec["key"]] = {"key": spec["key"], "filename": spec["filename"], "contract_sha256": contract_hash, "verified_utc": dt.datetime.now(dt.timezone.utc).isoformat(), **hashes}
            atomic_json(receipts_path, receipts)
            continue
        prefix = target.with_name(target.name + ".part")
        start = prefix.stat().st_size if prefix.exists() else 0
        if start > spec["size_bytes"]:
            raise ValueError("Prefix exceeds the contracted source size")
        prefix_lengths[spec["key"]] = start
        pending_specs.append(spec)
        for offset in range(start, spec["size_bytes"], SEGMENT):
            requests.append((spec, offset, min(offset + SEGMENT, spec["size_bytes"]) - 1))
    completed = 0
    last = time.monotonic()
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(range_segment, spec, start, end, segments) for spec, start, end in requests]
        for future in as_completed(futures):
            future.result()
            completed += 1
            if time.monotonic() - last > 20:
                print(json.dumps({"completed_ranges": completed, "total_ranges": len(requests), "range_workers": args.workers}), flush=True)
                last = time.monotonic()
    for spec in pending_specs:
        target = destination / spec["filename"]
        prefix = target.with_name(target.name + ".part")
        assembly = target.with_name(target.name + ".assembling")
        start = prefix_lengths[spec["key"]]
        if (prefix.stat().st_size if prefix.exists() else 0) != start:
            raise ValueError("Prefix was modified by another downloader")
        with assembly.open("wb") as output:
            if start:
                with prefix.open("rb") as source:
                    shutil.copyfileobj(source, output, CHUNK)
            for _, begin, end in (item for item in requests if item[0]["key"] == spec["key"]):
                path = segments / f"{spec['key']}.{begin:012d}-{end:012d}.segment"
                with path.open("rb") as source:
                    shutil.copyfileobj(source, output, CHUNK)
        hashes = verify(assembly, spec)
        os.replace(assembly, target)
        receipts[spec["key"]] = {"key": spec["key"], "filename": spec["filename"], "contract_sha256": contract_hash, "verified_utc": dt.datetime.now(dt.timezone.utc).isoformat(), **hashes, "acquisition": "Bounded exact ranges; full-file upstream checksum comparison where available. HLCA multipart ETag is not an MD5; local SHA256 calculated."}
        atomic_json(receipts_path, receipts)
        # These are exact source-owned ignored files, removed only after full verification.
        for _, begin, end in (item for item in requests if item[0]["key"] == spec["key"]):
            (segments / f"{spec['key']}.{begin:012d}-{end:012d}.segment").unlink()
        if prefix.exists():
            prefix.unlink()
        print(json.dumps({"key": spec["key"], "status": "verified", **hashes}), flush=True)
    print(json.dumps({"completed_files": len(receipts), "contract_sha256": contract_hash}), flush=True)


if __name__ == "__main__":
    main()
