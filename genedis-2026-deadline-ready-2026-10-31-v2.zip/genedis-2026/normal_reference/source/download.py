"""Download only pinned public processed inputs, with resume and exact integrity checks."""
from __future__ import annotations

import argparse
import base64
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import threading
import time
import urllib.request

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / ".runtime" / "packages"))
CHUNK = 4 * 1024 * 1024
LOCK = threading.Lock()


def atomic_json(path: Path, value: object) -> None:
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    temp.replace(path)


def hash_file(path: Path) -> dict:
    import google_crc32c
    sha = hashlib.sha256()
    md5 = hashlib.md5(usedforsecurity=False)
    crc = google_crc32c.Checksum()
    size = 0
    with path.open("rb") as stream:
        while chunk := stream.read(CHUNK):
            sha.update(chunk)
            md5.update(chunk)
            crc.update(chunk)
            size += len(chunk)
    return {"size_bytes": size, "sha256": sha.hexdigest(), "md5_base64": base64.b64encode(md5.digest()).decode(), "crc32c_base64": base64.b64encode(crc.digest()).decode()}


def verify(path: Path, spec: dict) -> dict:
    hashes = hash_file(path)
    if hashes["size_bytes"] != spec["size_bytes"]:
        raise ValueError(f"Wrong size for {spec['key']}")
    for field in ["md5_base64", "crc32c_base64"]:
        if spec.get(field) and hashes[field] != spec[field]:
            raise ValueError(f"Upstream {field} mismatch for {spec['key']}")
    return hashes


def acquire(spec: dict, destination: Path, contract_hash: str) -> dict:
    target = destination / spec["filename"]
    part = target.with_name(target.name + ".part")
    if target.exists():
        hashes = verify(target, spec)
        return {"key": spec["key"], "filename": spec["filename"], "contract_sha256": contract_hash, "verified_utc": dt.datetime.now(dt.timezone.utc).isoformat(), **hashes, "upstream_integrity": "CRC32C/MD5 compared where provided; HLCA version URL/size only, local SHA256 computed"}
    start = part.stat().st_size if part.exists() else 0
    if start > spec["size_bytes"]:
        raise ValueError("Existing partial input exceeds the pinned object size")
    if start != spec["size_bytes"]:
        request = urllib.request.Request(spec["pinned_url"])
        if start:
            request.add_header("Range", f"bytes={start}-")
        response = urllib.request.urlopen(request, timeout=120)
        with response:
            if start and (response.status != 206 or not response.headers.get("Content-Range", "").startswith(f"bytes {start}-")):
                raise ValueError("Server did not honor the exact resume range")
            etag = response.headers.get("ETag")
            if spec.get("source_etag") and etag != spec["source_etag"]:
                raise ValueError("Pinned HLCA object ETag changed")
            remaining = int(response.headers.get("Content-Length", spec["size_bytes"] - start))
            if remaining != spec["size_bytes"] - start:
                raise ValueError("Pinned response has an unexpected content length")
            done = start
            last_report = time.monotonic()
            with part.open("ab" if start else "wb") as stream:
                while chunk := response.read(CHUNK):
                    stream.write(chunk)
                    done += len(chunk)
                    if done > spec["size_bytes"]:
                        raise ValueError("Transfer exceeds the pinned object size")
                    if time.monotonic() - last_report >= 20:
                        print(json.dumps({"key": spec["key"], "downloaded_bytes": done, "expected_bytes": spec["size_bytes"]}), flush=True)
                        last_report = time.monotonic()
    hashes = verify(part, spec)
    os.replace(part, target)
    print(json.dumps({"key": spec["key"], "status": "verified", **hashes}), flush=True)
    return {"key": spec["key"], "filename": spec["filename"], "contract_sha256": contract_hash, "verified_utc": dt.datetime.now(dt.timezone.utc).isoformat(), **hashes, "upstream_integrity": "CRC32C/MD5 compared where provided; HLCA version URL/size only, local SHA256 computed"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--contract", type=Path, default=HERE / "input_contract.json")
    parser.add_argument("--keys", nargs="*", help="Acquire a bounded subset of pinned file keys")
    parser.add_argument("--workers", type=int, choices=[1, 2], default=2)
    args = parser.parse_args()
    contract_bytes = args.contract.read_bytes()
    contract = json.loads(contract_bytes)
    contract_hash = hashlib.sha256(contract_bytes).hexdigest()
    specs = contract["files"]
    if args.keys:
        if not set(args.keys) <= {x["key"] for x in specs}:
            raise ValueError("Unknown file key")
        specs = [x for x in specs if x["key"] in args.keys]
    if sum(x["size_bytes"] for x in contract["files"]) >= contract["download_budget_bytes"]:
        raise ValueError("Pinned acquisition exceeds its budget")
    destination = HERE / "data" / "downloads"
    destination.mkdir(parents=True, exist_ok=True)
    needed = sum(max(0, x["size_bytes"] - (destination / x["filename"]).stat().st_size) if (destination / x["filename"]).exists() else x["size_bytes"] for x in specs)
    if shutil.disk_usage(destination).free < needed + 2_000_000_000:
        raise ValueError("Insufficient free disk for the bounded transfer")
    receipt_path = HERE / "data" / "download_receipts.json"
    receipts = json.loads(receipt_path.read_text()) if receipt_path.exists() else {}
    if any(v.get("contract_sha256") != contract_hash for v in receipts.values()):
        raise ValueError("Existing receipts belong to a different input contract")
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(acquire, x, destination, contract_hash): x for x in specs}
        for future in as_completed(futures):
            receipt = future.result()
            with LOCK:
                receipts[receipt["key"]] = receipt
                atomic_json(receipt_path, receipts)
    print(json.dumps({"completed_files": len(receipts), "contract_sha256": contract_hash}), flush=True)


if __name__ == "__main__":
    main()
