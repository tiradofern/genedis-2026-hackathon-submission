"""Restore exact frozen HLCA bytes from public ranges, without inventing old receipts.

All work starts in a new ignored directory. Original historical ledger bytes are
restored only after every payload and the derived container match their frozen
SHA256. Newly acquired/cached-range verification records remain separate.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime as dt
import io
import json
import os
from pathlib import Path
import shutil
import time
import urllib.request

from .audit import HERE, digest
from .download import CHUNK, atomic_json, hash_file


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def relative_path(root: Path, relative: str) -> Path:
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Ledger path escapes its root")
    return path


def verify_payload(path: Path, entry: dict):
    if path.stat().st_size != entry["end"] - entry["start"] + 1 or digest(path) != entry["sha256"]:
        raise ValueError("Range payload does not equal the frozen historical content SHA/length")


def acquire_range(spec: dict, entry: dict, destination: Path, cached_root: Path | None):
    target = relative_path(destination, entry["path"])
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise ValueError("A new staging range already exists")
    record = {"source_dataset_version_id": spec["dataset_version_id"], "source_object_version": spec["source_object_version"], "source_etag": spec["source_etag"], "source_size_bytes": spec["size_bytes"], "pinned_url": spec["pinned_url"], "start": entry["start"], "end": entry["end"], "sha256": entry["sha256"], "path": entry["path"], "verified_utc": utc()}
    cached = relative_path(cached_root, entry["path"]) if cached_root is not None else None
    if cached is not None and cached.exists():
        verify_payload(cached, entry)
        # A hard link avoids a second 3GB payload copy. Neither side is modified.
        os.link(cached, target)
        record.update(acquisition="existing_cache_rehashed_against_historical_content", newly_downloaded_bytes=0, original_receipt_timestamp_recreated=False)
    else:
        expected = entry["end"] - entry["start"] + 1
        expected_range = f"bytes {entry['start']}-{entry['end']}/{spec['size_bytes']}"
        request = urllib.request.Request(spec["pinned_url"], headers={"Range": f"bytes={entry['start']}-{entry['end']}"})
        temporary = target.with_name(target.name + ".acquiring")
        with urllib.request.urlopen(request, timeout=120) as response:
            if response.status != 206 or response.headers.get("Content-Range") != expected_range:
                raise ValueError("Public replay did not receive the exact pinned Content-Range")
            if response.headers.get("ETag") != spec["source_etag"] or int(response.headers.get("Content-Length", -1)) != expected:
                raise ValueError("Public replay ETag or response length changed")
            with temporary.open("xb") as stream:
                while chunk := response.read(CHUNK):
                    stream.write(chunk)
                    if stream.tell() > expected:
                        raise ValueError("Public replay exceeded its exact range")
        verify_payload(temporary, entry)
        os.link(temporary, target)
        temporary.unlink()
        record.update(acquisition="new_guarded_public_range", newly_downloaded_bytes=expected, original_receipt_timestamp_recreated=False, response_content_range=expected_range)
    verify_payload(target, entry)
    atomic_json(target.with_name(target.name + ".replay-receipt.json"), record)
    return record


class LedgerFile(io.RawIOBase):
    """Read source offsets only where the historical ledger supplies exact bytes."""
    def __init__(self, root: Path, ledger: dict):
        self.root, self.ledger = root, ledger
        self.position = 0
        self.streams = {}

    def readable(self):
        return True

    def seekable(self):
        return True

    def tell(self):
        return self.position

    def seek(self, offset, whence=0):
        if whence not in [0, 1, 2]:
            raise ValueError("Invalid source seek mode")
        target = offset if whence == 0 else self.position + offset if whence == 1 else self.ledger["source_size_bytes"] + offset
        if target < 0:
            raise ValueError("Negative source seek")
        self.position = target
        return target

    def read(self, size=-1):
        if size < 0:
            raise ValueError("Unbounded source read is forbidden")
        remaining = min(size, max(0, self.ledger["source_size_bytes"] - self.position))
        pieces = []
        while remaining:
            entry = next((entry for entry in self.ledger["ranges"] if entry["start"] <= self.position <= entry["end"]), None)
            if entry is None:
                raise ValueError(f"Historical range coverage lacks source offset {self.position}; missing bytes cannot be guessed")
            name = entry["path"]
            if name not in self.streams:
                self.streams[name] = relative_path(self.root, name).open("rb")
            stream = self.streams[name]
            stream.seek(self.position - entry["start"])
            wanted = min(remaining, entry["end"] - self.position + 1)
            part = stream.read(wanted)
            if len(part) != wanted:
                raise ValueError("A previously verified range was truncated")
            pieces.append(part)
            remaining -= wanted
            self.position += wanted
        return b"".join(pieces)

    def readinto(self, array):
        data = self.read(len(array))
        array[:len(data)] = data
        return len(data)

    def close_sources(self):
        for stream in self.streams.values():
            stream.close()


def validate_ledger(ledger, spec, audit):
    model_input = audit["model_input"]
    expected = {"initial_contract_sha256": audit["contract_sha256"], "acquisition_amendment_sha256": model_input["amendment_sha256"], "source_url": spec["url"], "source_dataset_version_id": spec["dataset_version_id"], "source_size_bytes": spec["size_bytes"], "source_etag": spec["source_etag"], "source_object_version": spec["source_object_version"], "full_source_file_retrieved": False, "full_source_sha256": None}
    if any(ledger.get(key) != value for key, value in expected.items()):
        raise ValueError("Historical range ledger does not bind the exact frozen source")
    paths = set()
    for entry in ledger["ranges"]:
        if not 0 <= entry["start"] <= entry["end"] < spec["size_bytes"] or entry["path"] in paths or not entry["path"].startswith("data/"):
            raise ValueError("Historical range bounds/path are invalid")
        relative_path(HERE, entry["path"])
        paths.add(entry["path"])
    if ledger["derived_file"]["sha256"] != model_input["sha256"] or ledger["derived_file"]["size_bytes"] != model_input["size_bytes"]:
        raise ValueError("Historical derived-file identity differs from the immutable audit")


def publish_missing(files: list[tuple[Path, Path]]):
    """Preflight every destination, then atomically create only absent exact files."""
    missing, matching = [], []
    for source, target in files:
        if target.exists():
            if target.stat().st_size != source.stat().st_size or digest(target) != digest(source):
                raise ValueError(f"Different existing target is preserved: {target.name}")
            matching.append(target)
        else:
            missing.append((source, target))
    for source, target in missing:
        target.parent.mkdir(parents=True, exist_ok=True)
        os.link(source, target)  # Atomic no-replace; concurrent creations cannot be overwritten.
    return {"already_matching_files": len(matching), "published_only_missing_files": len(missing)}


def main():
    import h5py
    import numpy as np
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workdir", type=Path, help="New ignored staging directory below source/data")
    parser.add_argument("--reuse-cached", action="store_true", help="Rehash existing local payloads instead of downloading matching content again")
    parser.add_argument("--publish-missing", action="store_true", help="After exact proof, create only missing canonical source inputs")
    parser.add_argument("--workers", type=int, choices=[1, 2, 4, 8], default=4)
    args = parser.parse_args()
    if (h5py.__version__, h5py.version.hdf5_version, np.__version__) != ("3.15.1", "1.14.6", "2.3.3"):
        raise ValueError("Exact container replay requires pinned h5py 3.15.1/HDF5 1.14.6/NumPy 2.3.3; never rebless changed bytes")
    contract_path, audit_path = HERE / "input_contract.json", HERE / "hlca_audit.json"
    contract, audit = json.loads(contract_path.read_text()), json.loads(audit_path.read_text())
    audit_sha = digest(audit_path)
    model_input = audit["model_input"]
    if audit["resource"] != "hlca" or digest(contract_path) != audit["contract_sha256"] or digest(HERE / "eligibility_contract.json") != audit["eligibility_contract_sha256"] or digest(HERE / "acquisition_amendment.json") != model_input["amendment_sha256"]:
        raise ValueError("Frozen audit/contract/eligibility/amendment changed")
    for name, expected in audit["producer_sha256"].items():
        if digest(relative_path(HERE, name)) != expected:
            raise ValueError("Frozen producer changed")
    historical_path = HERE / "hlca_source_ranges_manifest.json"
    if digest(historical_path) != model_input["source_ranges_manifest_sha256"]:
        raise ValueError("Versioned historical ledger differs from the immutable fitted-input binding")
    historical_bytes = historical_path.read_bytes()
    ledger = json.loads(historical_bytes)
    spec = next(spec for spec in contract["files"] if spec["key"] == "hlca_core")
    validate_ledger(ledger, spec, audit)
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    workdir = (args.workdir or HERE / "data/replay" / f"hlca-input-{stamp}").resolve()
    if not workdir.is_relative_to((HERE / "data").resolve()) or workdir.exists():
        raise ValueError("Choose a new ignored staging directory below source/data")
    if shutil.disk_usage(HERE).free < 7_000_000_000:
        raise ValueError("At least 7GB temporary free space is required")
    workdir.mkdir(parents=True)
    records, last = [], time.monotonic()
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(acquire_range, spec, entry, workdir, HERE if args.reuse_cached else None) for entry in ledger["ranges"]]
        for future in as_completed(futures):
            records.append(future.result())
            if time.monotonic() - last > 20:
                print(json.dumps({"replay_ranges_verified": len(records), "total": len(futures)}), flush=True)
                last = time.monotonic()
    print(json.dumps({"replay_ranges_verified": len(records), "new_download_bytes": sum(record["newly_downloaded_bytes"] for record in records)}), flush=True)
    remote = LedgerFile(workdir, ledger)
    destination = relative_path(workdir, model_input["path"])
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        with h5py.File(remote, "r") as original, h5py.File(destination, "w") as derived:
            for group in ["obs", "raw"]:
                original.copy(group, derived, name=group)
                print(json.dumps({"replayed_hdf5_group": group}), flush=True)
            derived.attrs["normal_reference_subset"] = "Source obs and raw groups only; normalized X and embeddings omitted"
            derived.attrs["source_dataset_version"] = spec["dataset_version_id"]
            derived.attrs["initial_contract_sha256"] = audit["contract_sha256"]
            derived.attrs["acquisition_amendment_sha256"] = model_input["amendment_sha256"]
    finally:
        remote.close_sources()
    hashes = hash_file(destination)
    if hashes != audit["input_hashes"][model_input["matrix_key"]] or hashes["sha256"] != model_input["sha256"]:
        raise ValueError("Full derived-container replay is not byte-identical; preserved in staging, never published or reblessed")
    for entry in ledger["ranges"]:
        verify_payload(relative_path(workdir, entry["path"]), entry)
    staged_ledger = relative_path(workdir, model_input["source_ranges_manifest_path"])
    staged_ledger.parent.mkdir(parents=True, exist_ok=True)
    staged_ledger.write_bytes(historical_bytes)
    receipt = {"key": model_input["matrix_key"], "filename": destination.name, "contract_sha256": audit["contract_sha256"], "amendment_sha256": model_input["amendment_sha256"], "source_ranges_manifest_sha256": model_input["source_ranges_manifest_sha256"], "source_matrix_key": "hlca_core", "full_source_file_retrieved": False, **hashes, "verified_utc": utc(), "acquisition": "Exact frozen container replay; historical ledger restored only after payload SHA verification; new range receipts kept separately"}
    atomic_json(workdir / "new_range_replay_receipts.json", {"schema": "hlca_exact_input_replay_v0.1", "historical_ledger_sha256": model_input["source_ranges_manifest_sha256"], "historical_receipt_timestamps_recreated": False, "new_records": sorted(records, key=lambda row: row["start"])})
    atomic_json(workdir / "new_model_input_receipt.json", receipt)
    publication = {"published_only_missing_files": 0}
    if args.publish_missing:
        # Reject receipt conflicts before publishing any of the payload files.
        receipts_path = HERE / "data/download_receipts.json"
        before = receipts_path.read_bytes() if receipts_path.exists() else None
        receipts = json.loads(before) if before else {}
        existing = receipts.get(model_input["matrix_key"])
        if existing is not None and any(existing.get(key) != receipt[key] for key in ["filename", "contract_sha256", "amendment_sha256", "source_ranges_manifest_sha256", "sha256", "size_bytes"]):
            raise ValueError("Existing input receipt differs and is preserved")
        files = [(relative_path(workdir, entry["path"]), relative_path(HERE, entry["path"])) for entry in ledger["ranges"]]
        files += [(destination, relative_path(HERE, model_input["path"])), (staged_ledger, relative_path(HERE, model_input["source_ranges_manifest_path"]))]
        publication = publish_missing(files)
        if existing is None:
            if (receipts_path.read_bytes() if receipts_path.exists() else None) != before:
                raise ValueError("Acquisition receipts changed concurrently; exact staged data preserved, receipt not written")
            receipts[model_input["matrix_key"]] = receipt
            atomic_json(receipts_path, receipts)
    if digest(audit_path) != audit_sha or digest(historical_path) != model_input["source_ranges_manifest_sha256"]:
        raise ValueError("Frozen provenance changed during replay")
    proof = {"schema": "hlca_exact_input_replay_v0.1", "immutable_audit_sha256": audit_sha, "historical_ledger_sha256": model_input["source_ranges_manifest_sha256"], "verified_range_count": len(records), "verified_range_bytes": sum(row["end"] - row["start"] + 1 for row in records), "newly_downloaded_bytes": sum(row["newly_downloaded_bytes"] for row in records), "cached_ranges_rehashed": sum(row["acquisition"].startswith("existing_cache") for row in records), "derived_input": hashes, "exact_frozen_container_bytes": True, "full_source_file_retrieved": False, "historical_receipt_timestamps_recreated": False, "new_receipts_file": "new_range_replay_receipts.json", "runtime": {"h5py": h5py.__version__, "hdf5": h5py.version.hdf5_version, "numpy": np.__version__}, "frozen_producers_contracts_audits_models_modified": False, **publication, "completed_utc": utc()}
    atomic_json(workdir / "input_replay_review.json", proof)
    print(json.dumps(proof), flush=True)


if __name__ == "__main__":
    main()
