"""Safeguards for real source contracts; fixtures do not validate biology."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from .audit import finalize_genes, gene_identity, h5_strings
from .download_segmented import range_segment
from .extract_hlca_raw import CachedPinnedFile, csr_integrity


class Response:
    status = 206

    def __init__(self, data):
        self.data = data
        self.headers = {"Content-Range": f"bytes 0-{len(data)-1}/{len(data)}", "Content-Length": str(len(data)), "ETag": '"version-1"'}

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def read(self, n=-1):
        result, self.data = self.data[:n], self.data[n:]
        return result


def spec():
    return {"key": "hlca_core", "contract_sha256": "contract-1", "pinned_url": "https://example.invalid/version-1.h5ad", "size_bytes": 4, "source_etag": '"version-1"', "dataset_version_id": "version-1"}


class SourceSafeguards(unittest.TestCase):
    def test_same_length_unreceipted_range_is_refetched(self):
        with tempfile.TemporaryDirectory() as temp:
            directory = Path(temp)
            stale = directory / "hlca_core.000000000000-000000000003.segment"
            stale.write_bytes(b"old!")
            with patch("urllib.request.urlopen", return_value=Response(b"new!")) as remote:
                result = range_segment(spec(), 0, 3, directory)
            self.assertEqual(result.read_bytes(), b"new!")
            remote.assert_called_once()
            receipt = json.loads(result.with_name(result.name + ".receipt.json").read_text())
            self.assertEqual(receipt["sha256"], hashlib.sha256(b"new!").hexdigest())
            self.assertEqual(receipt["dataset_version_id"], "version-1")

    def test_modified_cached_range_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            directory = Path(temp)
            with patch("urllib.request.urlopen", return_value=Response(b"good")):
                result = range_segment(spec(), 0, 3, directory)
            result.write_bytes(b"evil")
            with patch("urllib.request.urlopen") as remote:
                with self.assertRaisesRegex(ValueError, "receipt/content/source"):
                    range_segment(spec(), 0, 3, directory)
            remote.assert_not_called()

    def test_wrong_source_version_rejected_even_with_same_bytes(self):
        with tempfile.TemporaryDirectory() as temp:
            directory = Path(temp)
            with patch("urllib.request.urlopen", return_value=Response(b"good")):
                range_segment(spec(), 0, 3, directory)
            changed = {**spec(), "dataset_version_id": "version-2"}
            with self.assertRaisesRegex(ValueError, "receipt/content/source"):
                range_segment(changed, 0, 3, directory)

    def test_bad_content_range_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            response = Response(b"good")
            response.headers["Content-Range"] = "bytes 4-7/8"
            with patch("urllib.request.urlopen", return_value=response):
                with self.assertRaisesRegex(ValueError, "exact range"):
                    range_segment(spec(), 0, 3, Path(temp))

    def test_wrong_remote_etag_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            response = Response(b"good")
            response.headers["ETag"] = '"different-version"'
            with patch("urllib.request.urlopen", return_value=response):
                with self.assertRaisesRegex(ValueError, "ETag changed"):
                    range_segment(spec(), 0, 3, Path(temp))

    def test_numeric_ensembl_version_removal_preserves_par_y(self):
        self.assertEqual(gene_identity("ENSG00000123456.9_PAR_Y")[:2], ("ENSG00000123456_PAR_Y", "9"))
        self.assertEqual(gene_identity("ACTB")[2], "invalid_ensembl_gene_id")

    def test_ambiguous_stable_ids_exclude_all_rows(self):
        with tempfile.TemporaryDirectory() as temp:
            rows = [{"row_index": i, "original_gene_id": f"ENSG00000123456.{i+1}", "stable_gene_id": "ENSG00000123456", "gene_version": str(i+1), "symbol": "DUP", "identity_status": "eligible_identity"} for i in range(2)]
            report = finalize_genes(rows, Path(temp) / "genes.tsv")
            self.assertEqual(report["identity_status_counts"], {"duplicate_stable_id_all_rows_excluded": 2})

    def test_numeric_age_metadata_preserved(self):
        import h5py
        with tempfile.TemporaryDirectory() as temp:
            with h5py.File(Path(temp) / "metadata.h5", "w") as handle:
                obs = handle.create_group("obs")
                obs.create_dataset("_index", data=np.array([b"a", b"b"]))
                obs.create_dataset("age", data=np.array([34.5, np.nan]))
                result = h5_strings(obs, "age")
                self.assertEqual(list(result), ["34.5", "nan"])

    def test_csr_invalid_pointer_or_gene_index_rejected(self):
        import h5py
        with tempfile.TemporaryDirectory() as temp:
            with h5py.File(Path(temp) / "counts.h5", "w") as handle:
                raw = handle.create_group("raw/X")
                raw.attrs["shape"] = [584944, 27402]
                raw.attrs["encoding-type"] = "csr_matrix"
                raw.create_dataset("data", data=np.array([1.0], dtype=np.float32))
                raw.create_dataset("indices", data=np.array([27402], dtype=np.int64))
                pointers = np.ones(584945, dtype=np.int64)
                pointers[0] = 0
                raw.create_dataset("indptr", data=pointers)
                with self.assertRaisesRegex(ValueError, "gene index"):
                    csr_integrity(handle)

    def test_csr_negative_nonfinite_or_fractional_counts_rejected(self):
        import h5py
        with tempfile.TemporaryDirectory() as temp:
            with h5py.File(Path(temp) / "counts.h5", "w") as handle:
                raw = handle.create_group("raw/X")
                raw.attrs["shape"] = [584944, 27402]
                raw.attrs["encoding-type"] = "csr_matrix"
                counts = raw.create_dataset("data", data=np.array([1.0], dtype=np.float32))
                raw.create_dataset("indices", data=np.array([0], dtype=np.int64))
                pointers = np.ones(584945, dtype=np.int64)
                pointers[0] = 0
                raw.create_dataset("indptr", data=pointers)
                for value in [-1.0, np.nan, 0.5]:
                    counts[0] = value
                    with self.subTest(value=value), self.assertRaisesRegex(ValueError, "nonnegative integers"):
                        csr_integrity(handle)

    def test_csr_nonmonotone_pointers_rejected(self):
        import h5py
        with tempfile.TemporaryDirectory() as temp:
            with h5py.File(Path(temp) / "counts.h5", "w") as handle:
                raw = handle.create_group("raw/X")
                raw.attrs["shape"] = [584944, 27402]
                raw.attrs["encoding-type"] = "csr_matrix"
                raw.create_dataset("data", data=np.array([1.0], dtype=np.float32))
                raw.create_dataset("indices", data=np.array([0], dtype=np.int64))
                pointers = np.ones(584945, dtype=np.int64)
                pointers[0] = 0
                pointers[3] = 0
                raw.create_dataset("indptr", data=pointers)
                with self.assertRaisesRegex(ValueError, "indptr"):
                    csr_integrity(handle)


if __name__ == "__main__":
    unittest.main()
