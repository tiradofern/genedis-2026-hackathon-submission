"""Read only pinned H5AD metadata by exact ranges; does not declare matrix readiness."""
from __future__ import annotations

from collections import Counter, OrderedDict, defaultdict
import hashlib
import io
import json
from pathlib import Path
import urllib.request

from .audit import HERE, HLCA_FIELDS, h5_strings, digest, write_tsv
from .download import atomic_json


class PinnedHTTPFile(io.RawIOBase):
    """Small bounded cache; every fetched range is tied to one immutable version."""
    def __init__(self, spec: dict):
        self.spec = spec
        self.position = 0
        self.block_size = 256 * 1024
        self.cache = OrderedDict()
        self.range_receipts = {}

    def readable(self):
        return True

    def seekable(self):
        return True

    def tell(self):
        return self.position

    def seek(self, offset, whence=0):
        target = offset if whence == 0 else self.position + offset if whence == 1 else self.spec["size_bytes"] + offset
        if target < 0:
            raise ValueError("Negative source seek")
        self.position = target
        return target

    def _block(self, start):
        if start in self.cache:
            self.cache.move_to_end(start)
            return self.cache[start]
        end = min(start + self.block_size, self.spec["size_bytes"]) - 1
        request = urllib.request.Request(self.spec["pinned_url"], headers={"Range": f"bytes={start}-{end}"})
        with urllib.request.urlopen(request, timeout=60) as response:
            if response.status != 206 or response.headers.get("Content-Range") != f"bytes {start}-{end}/{self.spec['size_bytes']}":
                raise ValueError("H5AD metadata server ignored an exact range")
            if response.headers.get("ETag") != self.spec["source_etag"]:
                raise ValueError("Pinned H5AD changed during metadata preflight")
            data = response.read()
        if len(data) != end - start + 1:
            raise ValueError("Truncated metadata range")
        self.range_receipts[str(start)] = {"end": end, "sha256": hashlib.sha256(data).hexdigest()}
        self.cache[start] = data
        if len(self.cache) > 32:
            self.cache.popitem(last=False)
        return data

    def read(self, size=-1):
        if size < 0:
            raise ValueError("Unbounded H5AD remote read is forbidden")
        size = min(size, self.spec["size_bytes"] - self.position)
        pieces = []
        while size:
            start = self.position // self.block_size * self.block_size
            block = self._block(start)
            offset = self.position - start
            part = block[offset:offset + size]
            pieces.append(part)
            self.position += len(part)
            size -= len(part)
        return b"".join(pieces)

    def readinto(self, array):
        data = self.read(len(array))
        array[:len(data)] = data
        return len(data)


def main():
    import h5py
    contract_path = HERE / "input_contract.json"
    contract = json.loads(contract_path.read_text())
    spec = next(x for x in contract["files"] if x["key"] == "hlca_core")
    remote = PinnedHTTPFile(spec)
    with h5py.File(remote, "r") as handle:
        obs = handle["obs"]
        n = len(obs[obs.attrs.get("_index", "_index")])
        columns = list(obs)
        fields = [f for f in HLCA_FIELDS if f in columns]
        arrays = {f: h5_strings(obs, f) for f in fields}
        donor_studies = defaultdict(set)
        for donor, study in zip(arrays["donor_id"], arrays["study"], strict=True):
            donor_studies[donor].add(study)
        donor_conditions = defaultdict(set)
        for donor, condition in zip(arrays["donor_id"], arrays["subject_type"], strict=True):
            donor_conditions[donor].add(condition)
        var = handle["raw/var"]
        var_columns = list(var)
        var_index = var.attrs.get("_index", "_index")
        var_ids = h5_strings(var, var_index)
        summary = {
            "scope": "Pinned metadata preflight only; full raw counts and full-file integrity remain pending",
            "contract_sha256": digest(contract_path), "status": "metadata_only_not_source_ready",
            "cells": n, "genes_in_raw_var": len(var_ids), "gene_id_examples": list(var_ids[:3]),
            "raw_shape": list(map(int, handle["raw/X"].attrs["shape"])),
            "raw_encoding": str(handle["raw/X"].attrs.get("encoding-type")), "raw_data_dtype": str(handle["raw/X/data"].dtype),
            "obs_columns": columns, "raw_var_columns": var_columns,
            "donor_ids": len(donor_studies), "donor_ids_spanning_studies": sum(len(s) > 1 for s in donor_studies.values()),
            "studies": len(set(arrays["study"])), "datasets": len(set(arrays["dataset"])), "samples": len(set(arrays["sample"])),
            "subject_type_donors": dict(Counter("|".join(sorted(v)) for v in donor_conditions.values())),
            "categorical_cells": {f: dict(Counter(arrays[f])) for f in fields if f not in ["donor_id", "sample", "age_or_mean_of_age_range"]},
        }
        out = HERE / "data/audit"
        out.mkdir(parents=True, exist_ok=True)
        write_tsv(out / "hlca_metadata_preflight_cells.tsv", ["cell_index"] + fields, ({"cell_index": i, **{f: arrays[f][i] for f in fields}} for i in range(n)))
    summary["remote_unique_ranges"] = len(remote.range_receipts)
    summary["remote_bytes_read"] = sum(v["end"] - int(start) + 1 for start, v in remote.range_receipts.items())
    atomic_json(HERE / "data/audit/hlca_metadata_ranges.json", {"contract_sha256": digest(contract_path), "ranges": remote.range_receipts})
    atomic_json(HERE / "hlca_metadata_preflight.json", summary)
    print(json.dumps({k: summary[k] for k in ["status", "cells", "donor_ids", "studies", "datasets", "samples", "subject_type_donors", "remote_bytes_read"]}), flush=True)


if __name__ == "__main__":
    main()
