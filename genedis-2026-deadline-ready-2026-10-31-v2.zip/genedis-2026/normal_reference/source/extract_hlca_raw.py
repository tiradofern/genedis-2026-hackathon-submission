"""Copy only obs and raw from the same pinned HLCA, with guarded ranged provenance."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import time

import numpy as np

from .audit import HERE, digest
from .download import atomic_json, hash_file
from .download_segmented import SEGMENT, range_segment, range_binding
from .metadata_preflight import PinnedHTTPFile

FIRST_RAW_CHUNK = 2_743_316_401


class CachedPinnedFile(PinnedHTTPFile):
    def __init__(self, spec, prefix, ranges, directory):
        super().__init__(spec)
        self.prefix_path = prefix
        self.prefix_size = prefix.stat().st_size if prefix.exists() else 0
        self.prefix = prefix.open("rb") if self.prefix_size else None
        self.ranges = ranges
        self.directory = directory
        self.extra_directory = HERE / "data/hlca_metadata_ranges"
        self.extra_directory.mkdir(parents=True, exist_ok=True)
        self.extras = {}
        self.open_segments = {}

    def _block(self, start):
        end = min(start + self.block_size, self.spec["size_bytes"])
        if self.prefix is not None and end <= self.prefix_size:
            if self.prefix_path.stat().st_size != self.prefix_size:
                raise ValueError("The preserved source prefix was modified by another downloader")
            self.prefix.seek(start)
            data = self.prefix.read(end - start)
            if len(data) != end - start:
                raise ValueError("Preserved source prefix became truncated")
            # The initial full-transfer prefix had no per-range receipt. Compare every
            # consumed block with a freshly guarded source read; unconsumed bytes are
            # preserved but never asserted as verified input provenance.
            guarded = super()._block(start)
            if data != guarded:
                raise ValueError("Preserved prefix does not equal this pinned source version")
            return self._persist_extra(start, end, guarded)
        for begin, finish in self.ranges:
            if begin <= start and end - 1 <= finish:
                key = (begin, finish)
                if key not in self.open_segments:
                    path = self.directory / f"{self.spec['key']}.{begin:012d}-{finish:012d}.segment"
                    self.open_segments[key] = path.open("rb")
                stream = self.open_segments[key]
                stream.seek(start - begin)
                data = stream.read(end - start)
                if len(data) != end - start:
                    raise ValueError("Prefetched source range became truncated")
                return data
        # Non-prefetched bytes are never guessed or filled. Fetch from the same object.
        data = super()._block(start)
        return self._persist_extra(start, end, data)

    def _persist_extra(self, start, end, data):
        path = self.extra_directory / f"{start:012d}-{end - 1:012d}.bin"
        expected_sha = hashlib.sha256(data).hexdigest()
        temp = path.with_name(path.name + ".tmp")
        temp.write_bytes(data)
        temp.replace(path)
        if digest(path) != expected_sha:
            raise ValueError("Retained on-demand bytes do not equal the guarded response")
        binding = range_binding(self.spec, start, end - 1)
        atomic_json(path.with_name(path.name + ".receipt.json"), {**binding, "sha256": expected_sha, "guarded_exact_response": True})
        self.extras[str(start)] = {"end": end - 1, "sha256": expected_sha, "filename": path.name}
        return data

    def close_sources(self):
        if self.prefix is not None:
            self.prefix.close()
        for stream in self.open_segments.values():
            stream.close()


def csr_integrity(handle):
    raw = handle["raw/X"]
    shape = tuple(map(int, raw.attrs["shape"]))
    if shape != (584944, 27402) or raw.attrs.get("encoding-type") != "csr_matrix":
        raise ValueError("Raw-only extraction changed shape or CSR encoding")
    if len(raw["data"]) != len(raw["indices"]):
        raise ValueError("Mismatched raw sparse arrays")
    pointer = raw["indptr"][:]
    if len(pointer) != shape[0] + 1 or pointer[0] != 0 or pointer[-1] != len(raw["data"]) or np.any(np.diff(pointer) < 0):
        raise ValueError("Invalid raw CSR indptr")
    count_sum = 0.0
    maximum = 0.0
    for start in range(0, len(raw["data"]), 4_000_000):
        array = raw["data"][start:start + 4_000_000]
        indices = raw["indices"][start:start + 4_000_000]
        if np.any(~np.isfinite(array)) or np.any(array < 0) or np.any(array != np.floor(array)):
            raise ValueError("Source raw counts are not finite nonnegative integers")
        if np.any(indices < 0) or np.any(indices >= shape[1]):
            raise ValueError("Raw CSR gene index is out of range")
        count_sum += float(array.sum(dtype=np.float64))
        maximum = max(maximum, float(array.max(initial=0)))
    return {"shape": list(shape), "stored_values_scanned": len(raw["data"]), "finite_nonnegative_integer": True, "indices_indptr_valid": True, "raw_count_sum": count_sum, "maximum_stored_count": maximum}


def main():
    import h5py
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers", type=int, choices=[2, 4, 8], default=8)
    args = parser.parse_args()
    contract_path = HERE / "input_contract.json"
    amendment_path = HERE / "acquisition_amendment.json"
    contract = json.loads(contract_path.read_text())
    amendment = json.loads(amendment_path.read_text())
    if digest(contract_path) != amendment["initial_contract_sha256"]:
        raise ValueError("Original source contract changed")
    spec = {**next(x for x in contract["files"] if x["key"] == "hlca_core"), "contract_sha256": digest(contract_path)}
    if spec["dataset_version_id"] != amendment["source_dataset_version_id"] or spec["source_etag"] != amendment["source_etag"]:
        raise ValueError("Acquisition amendment changed the pinned source")
    downloads = HERE / "data/downloads"
    prefix = downloads / (spec["filename"] + ".part")
    prefix_size = prefix.stat().st_size if prefix.exists() else 0
    if prefix_size > spec["size_bytes"]:
        raise ValueError("Invalid preserved source prefix")
    destination = downloads / amendment["local_filename"]
    if destination.exists():
        raise SystemExit("Raw-only extraction already exists; use its immutable audit or a new explicit version")
    segments = HERE / "data/segments"
    segments.mkdir(parents=True, exist_ok=True)
    start = FIRST_RAW_CHUNK // SEGMENT * SEGMENT
    ranges = [(offset, min(offset + SEGMENT, spec["size_bytes"]) - 1) for offset in range(start, spec["size_bytes"], SEGMENT)]
    last = time.monotonic()
    completed = 0
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(range_segment, spec, begin, end, segments) for begin, end in ranges]
        for future in as_completed(futures):
            future.result()
            completed += 1
            if time.monotonic() - last > 20:
                print(json.dumps({"raw_only_prefetch_ranges_complete": completed, "ranges_total": len(ranges), "planned_tail_bytes": spec["size_bytes"] - start}), flush=True)
                last = time.monotonic()
    if (prefix.stat().st_size if prefix.exists() else 0) != prefix_size:
        raise ValueError("Preserved prefix changed during extraction")
    source_ranges = []
    for begin, end in ranges:
        path = segments / f"{spec['key']}.{begin:012d}-{end:012d}.segment"
        receipt_path = path.with_name(path.name + ".receipt.json")
        receipt = json.loads(receipt_path.read_text())
        if not all(receipt.get(key) == value for key, value in range_binding(spec, begin, end).items()) or receipt["sha256"] != digest(path):
            raise ValueError("Prefetched source range changed after guarded transfer")
        source_ranges.append({"start": begin, "end": end, "kind": "version_guarded_exact_range", "sha256": receipt["sha256"], "path": "data/segments/" + path.name, "receipt_sha256": digest(receipt_path)})
    remote = CachedPinnedFile(spec, prefix, ranges, segments)
    temporary = destination.with_name(destination.name + ".assembling")
    try:
        with h5py.File(remote, "r") as original, h5py.File(temporary, "w") as derived:
            for group in ["obs", "raw"]:
                original.copy(group, derived, name=group)
                print(json.dumps({"copied_hdf5_group": group}), flush=True)
            # This file is intentionally a raw-only HDF5 subset, not original normalized AnnData.
            derived.attrs["normal_reference_subset"] = "Source obs and raw groups only; normalized X and embeddings omitted"
            derived.attrs["source_dataset_version"] = spec["dataset_version_id"]
            derived.attrs["initial_contract_sha256"] = digest(contract_path)
            derived.attrs["acquisition_amendment_sha256"] = digest(amendment_path)
        for begin, receipt in remote.extras.items():
            source_ranges.append({"start": int(begin), "end": receipt["end"], "kind": "version_guarded_hdf5_on_demand_range", "sha256": receipt["sha256"], "path": "data/hlca_metadata_ranges/" + receipt["filename"]})
    finally:
        remote.close_sources()
    with h5py.File(temporary, "r") as handle:
        if set(handle) != {"obs", "raw"} or "X" in handle:
            raise ValueError("Unexpected normalized/extra groups in raw-only extraction")
        integrity = csr_integrity(handle)
        if len(handle["obs"][handle["obs"].attrs.get("_index", "_index")]) != 584944 or len(handle["raw/var"][handle["raw/var"].attrs.get("_index", "_index")]) != 27402:
            raise ValueError("Raw-only copy changed source cell or gene identities")
    hashes = hash_file(temporary)
    range_manifest = {
        "schema": "hlca_guarded_source_ranges_v0.1", "initial_contract_sha256": digest(contract_path),
        "acquisition_amendment_sha256": digest(amendment_path), "source_url": spec["url"],
        "source_dataset_version_id": spec["dataset_version_id"], "source_size_bytes": spec["size_bytes"],
        "source_etag": spec["source_etag"], "source_object_version": spec["source_object_version"],
        "unreceipted_legacy_prefix_retained_bytes": prefix_size,
        "legacy_prefix_verification": "Only blocks actually consumed were compared against freshly guarded source reads and included below. No whole-prefix integrity assertion.",
        "full_source_file_retrieved": False, "full_source_sha256": None,
        "range_bytes_retained_with_possible_overlaps": sum(r["end"] - r["start"] + 1 for r in source_ranges),
        "ranges": sorted(source_ranges, key=lambda r: (r["start"], r["end"])),
        "derived_file": {"path": "data/downloads/" + destination.name, **hashes},
        "raw_counts_integrity": integrity,
    }
    manifest_path = HERE / "data/audit/hlca_source_ranges.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    for entry in source_ranges:
        path = HERE / entry["path"]
        if path.stat().st_size != entry["end"] - entry["start"] + 1 or digest(path) != entry["sha256"]:
            raise ValueError("A retained source-range ledger path no longer matches its bytes")
    atomic_json(manifest_path, range_manifest)
    os.replace(temporary, destination)
    receipt_path = HERE / "data/download_receipts.json"
    receipts = json.loads(receipt_path.read_text())
    receipts["hlca_core_raw"] = {"key": "hlca_core_raw", "filename": destination.name, "contract_sha256": digest(contract_path), "amendment_sha256": digest(amendment_path), "source_ranges_manifest_sha256": digest(manifest_path), "source_matrix_key": "hlca_core", "full_source_file_retrieved": False, **hashes}
    atomic_json(receipt_path, receipts)
    # Aggregate proof contains no cell/donor IDs or source range filenames.
    proof = {"initial_contract_sha256": digest(contract_path), "amendment_sha256": digest(amendment_path), "source_ranges_manifest_sha256": digest(manifest_path), "derived_sha256": hashes["sha256"], "derived_bytes": hashes["size_bytes"], "source_range_count": len(source_ranges), "range_bytes_retained_with_possible_overlaps": range_manifest["range_bytes_retained_with_possible_overlaps"], "full_source_file_retrieved": False, "raw_counts_integrity": integrity}
    atomic_json(HERE / "raw_extraction_review.json", proof)
    print(json.dumps({"status": "raw_only_extracted_and_audited", **proof}), flush=True)


if __name__ == "__main__":
    main()
