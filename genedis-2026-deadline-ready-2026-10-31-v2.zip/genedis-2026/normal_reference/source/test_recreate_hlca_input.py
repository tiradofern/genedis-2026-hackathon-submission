"""Fictional exact-range/container-restoration guard tests; no real RNA downloads."""
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from . import recreate_hlca_input as replay


class Response(io.BytesIO):
    status = 206

    def __init__(self, data=b"ABCD", **headers):
        super().__init__(data)
        self.headers = {"ETag": '"fictional-etag"', "Content-Range": "bytes 0-3/8", "Content-Length": "4", **headers}


class ReplayGuards(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.spec = {"dataset_version_id": "fictional-version", "source_object_version": "fictional-object", "source_etag": '"fictional-etag"', "size_bytes": 8, "pinned_url": "https://example.invalid/immutable-fictional.h5ad"}
        self.entry = {"path": "data/segment.bin", "start": 0, "end": 3, "sha256": hashlib.sha256(b"ABCD").hexdigest()}

    def tearDown(self):
        self.temporary.cleanup()

    def test_corrupt_same_length_cache_is_not_blessed(self):
        cache = self.root / "cache/data"
        cache.mkdir(parents=True)
        (cache / "segment.bin").write_bytes(b"WXYZ")
        with patch.object(replay.urllib.request, "urlopen") as remote, self.assertRaisesRegex(ValueError, "frozen historical content"):
            replay.acquire_range(self.spec, self.entry, self.root / "new", self.root / "cache")
        remote.assert_not_called()
        self.assertFalse((self.root / "new/data/segment.bin").exists())

    def test_wrong_remote_etag_or_content_range_rejected(self):
        for headers in [{"ETag": '"other-version"'}, {"Content-Range": "bytes 1-4/8"}, {"Content-Length": "5"}]:
            with self.subTest(headers=headers), patch.object(replay.urllib.request, "urlopen", return_value=Response(**headers)), self.assertRaises(ValueError):
                replay.acquire_range(self.spec, self.entry, self.root / "new", None)
        self.assertFalse((self.root / "new/data/segment.bin").exists())

    def test_correct_remote_headers_with_wrong_payload_rejected(self):
        with patch.object(replay.urllib.request, "urlopen", return_value=Response(b"WXYZ")), self.assertRaisesRegex(ValueError, "frozen historical content"):
            replay.acquire_range(self.spec, self.entry, self.root / "new", None)
        self.assertFalse((self.root / "new/data/segment.bin").exists())

    def test_ledger_coverage_gap_fails_without_zero_fill(self):
        path = self.root / "data/segment.bin"
        path.parent.mkdir()
        path.write_bytes(b"ABCD")
        stream = replay.LedgerFile(self.root, {"source_size_bytes": 8, "ranges": [self.entry]})
        try:
            self.assertEqual(stream.read(4), b"ABCD")
            with self.assertRaisesRegex(ValueError, "missing bytes cannot be guessed"):
                stream.read(1)
        finally:
            stream.close_sources()

    def test_wrong_ledger_version_rejected(self):
        spec = {**self.spec, "url": self.spec["pinned_url"]}
        audit = {"contract_sha256": "fictional-contract", "model_input": {"amendment_sha256": "fictional-amendment", "sha256": "fictional-derived", "size_bytes": 10}}
        with self.assertRaisesRegex(ValueError, "exact frozen source"):
            replay.validate_ledger({"source_dataset_version_id": "wrong-version"}, spec, audit)

    def test_different_existing_target_prevents_all_publication(self):
        a, b, existing = [self.root / name for name in ["a", "b", "existing"]]
        a.write_bytes(b"verified-a")
        b.write_bytes(b"verified-b")
        existing.write_bytes(b"other")
        with self.assertRaisesRegex(ValueError, "preserved"):
            replay.publish_missing([(a, self.root / "missing"), (b, existing)])
        self.assertFalse((self.root / "missing").exists())
        self.assertEqual(existing.read_bytes(), b"other")

    def test_cached_proof_is_distinct_from_historical_receipt(self):
        cached = self.root / "cache/data/segment.bin"
        cached.parent.mkdir(parents=True)
        cached.write_bytes(b"ABCD")
        with patch.object(replay.urllib.request, "urlopen") as remote:
            record = replay.acquire_range(self.spec, self.entry, self.root / "new", self.root / "cache")
        remote.assert_not_called()
        self.assertEqual(record["newly_downloaded_bytes"], 0)
        self.assertFalse(record["original_receipt_timestamp_recreated"])
        self.assertTrue((self.root / "new/data/segment.bin.replay-receipt.json").exists())
        self.assertFalse((self.root / "new/data/segment.bin.receipt.json").exists())


if __name__ == "__main__":
    unittest.main()
