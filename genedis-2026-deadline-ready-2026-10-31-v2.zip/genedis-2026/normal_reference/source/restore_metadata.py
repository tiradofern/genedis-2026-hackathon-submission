"""Recreate missing ignored metadata against an existing immutable source audit.

This is intentionally additive: it does not change frozen source producers,
contracts, completed audit bytes, acquired matrices, or fitted model artifacts.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import shutil

from .audit import HERE, audit_gtex, audit_hlca, digest
from .download import atomic_json, hash_file


def safe_source_path(relative: str) -> Path:
    path = (HERE / relative).resolve()
    if not path.is_relative_to(HERE.resolve()):
        raise ValueError("An immutable audit path escapes the source directory")
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--resource", required=True, choices=["gtex", "hlca"])
    parser.add_argument("--workdir", type=Path, help="New ignored staging directory below source/data; must not already exist")
    parser.add_argument("--publish-missing", action="store_true", help="Publish only missing canonical TSVs after all exact checks pass")
    args = parser.parse_args()
    audit_path = HERE / f"{args.resource}_audit.json"
    audit = json.loads(audit_path.read_text())
    contract_path = HERE / "input_contract.json"
    contract = json.loads(contract_path.read_text())
    audit_hash = digest(audit_path)
    if audit["resource"] != args.resource or audit["contract_sha256"] != digest(contract_path) or audit["eligibility_contract_sha256"] != digest(HERE / "eligibility_contract.json"):
        raise ValueError("The existing immutable audit does not match this input/eligibility contract")
    for producer, expected in audit["producer_sha256"].items():
        if digest(safe_source_path(producer)) != expected:
            raise ValueError(f"Frozen source producer changed: {producer}")
    specs = {spec["key"]: spec for spec in contract["files"]}
    receipts = json.loads((HERE / "data/download_receipts.json").read_text())
    model_input = audit["model_input"]
    matrix_key = model_input["matrix_key"]
    matrix_path = safe_source_path(model_input["path"])
    if matrix_path.parent != (HERE / "data/downloads").resolve():
        raise ValueError("This wrapper requires the declared canonical download directory")
    keys = [key for key in audit["input_hashes"] if key.startswith("gtex_")] if args.resource == "gtex" else [matrix_key]
    for key in keys:
        receipt = receipts[key]
        path = (HERE / "data/downloads" / receipt["filename"]).resolve()
        if not path.is_relative_to((HERE / "data/downloads").resolve()) or receipt["contract_sha256"] != audit["contract_sha256"]:
            raise ValueError("Missing or foreign acquired-source receipt")
        actual = hash_file(path)
        bound = audit["input_hashes"][key]
        if any(actual[field] != bound[field] for field in ["size_bytes", "sha256", "md5_base64", "crc32c_base64"]):
            raise ValueError(f"Acquired source bytes differ from the immutable fitted-input audit: {key}")
        if receipt["sha256"] != bound["sha256"] or receipt["size_bytes"] != bound["size_bytes"]:
            raise ValueError("Current acquisition receipt disagrees with immutable input bytes")
    if matrix_path.stat().st_size != model_input["size_bytes"] or digest(matrix_path) != model_input["sha256"]:
        raise ValueError("The actual model matrix differs from the original audit; semantic similarity cannot rebless it")
    if matrix_key == "hlca_core_raw":
        if digest(HERE / "acquisition_amendment.json") != model_input["amendment_sha256"]:
            raise ValueError("Raw-only acquisition amendment changed")
        ranges_path = safe_source_path(model_input["source_ranges_manifest_path"])
        if digest(ranges_path) != model_input["source_ranges_manifest_sha256"]:
            raise ValueError("Restore the exact archived/canonical source-range ledger; never substitute a newly timestamped ledger")
        ranges = json.loads(ranges_path.read_text())
        if ranges["initial_contract_sha256"] != audit["contract_sha256"] or ranges["acquisition_amendment_sha256"] != model_input["amendment_sha256"] or ranges["full_source_file_retrieved"] is not False:
            raise ValueError("Raw-only source-range contract is inconsistent")
        for entry in ranges["ranges"]:
            path = safe_source_path(entry["path"])
            if path.stat().st_size != entry["end"] - entry["start"] + 1 or digest(path) != entry["sha256"]:
                raise ValueError("A retained source range differs from the immutable range ledger")
        specs["hlca_core"] = {**specs["hlca_core"], "filename": matrix_path.name}
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    workdir = (args.workdir or HERE / "data/replay" / f"{args.resource}-{stamp}").resolve()
    if not workdir.is_relative_to((HERE / "data").resolve()) or workdir.exists():
        raise ValueError("Choose a new ignored staging directory below source/data")
    workdir.mkdir(parents=True)
    callback = audit_gtex if args.resource == "gtex" else audit_hlca
    actual_result = callback(specs, HERE / "data/downloads", workdir)
    expected_result = {key: value for key, value in audit["result"].items() if key != "completed_utc"}
    if actual_result != expected_result:
        actual_keys = {key for key in set(actual_result) | set(expected_result) if actual_result.get(key) != expected_result.get(key)}
        raise ValueError(f"Regenerated source metadata/results differ in {sorted(actual_keys)}; nothing published")
    expected_files = ["gtex_samples.tsv", "gtex_gene_manifest.tsv"] if args.resource == "gtex" else ["hlca_cells.tsv", "hlca_gene_manifest.tsv", "hlca_donor_class_coverage.tsv"]
    expected_manifest_hashes = {"gtex_samples.tsv": audit["result"].get("sample_manifest_sha256"), "gtex_gene_manifest.tsv": audit["result"]["genes"]["manifest_sha256"]} if args.resource == "gtex" else {"hlca_cells.tsv": audit["result"]["cell_manifest_sha256"], "hlca_gene_manifest.tsv": audit["result"]["genes"]["manifest_sha256"], "hlca_donor_class_coverage.tsv": audit["result"]["donor_class_manifest_sha256"]}
    for name, expected in expected_manifest_hashes.items():
        if not expected or digest(workdir / name) != expected:
            raise ValueError(f"Reconstructed manifest {name} differs from its immutable audited bytes; nothing published")
    published, already_matching = [], []
    canonical = HERE / "data/audit"
    canonical.mkdir(parents=True, exist_ok=True)
    missing = []
    for name in expected_files:
        staged = workdir / name
        target = canonical / name
        if target.exists():
            if digest(target) != digest(staged):
                raise ValueError(f"Existing canonical {name} differs; it is preserved and not overwritten")
            already_matching.append(name)
        else:
            missing.append(name)
    # Validate every existing canonical target before publishing any missing file.
    for name in missing if args.publish_missing else []:
        staged = workdir / name
        target = canonical / name
        temporary = target.with_name(target.name + ".restore.tmp")
        if temporary.exists():
            raise ValueError("A previous restoration temporary exists; preserve and inspect it")
        shutil.copyfile(staged, temporary)
        if digest(temporary) != digest(staged):
            raise ValueError("A metadata copy did not preserve exact bytes")
        # Atomic no-replace publication on the local filesystem. A race cannot
        # overwrite a canonical target on either Windows or POSIX.
        os.link(temporary, target)
        temporary.unlink()
        published.append(name)
    if digest(audit_path) != audit_hash:
        raise ValueError("Immutable audit changed during metadata restoration")
    proof = {"resource": args.resource, "immutable_audit_sha256": audit_hash, "exact_result_invariants": True, "staged_manifest_sha256": {name: digest(workdir / name) for name in expected_files}, "already_matching_canonical_files": already_matching, "published_only_missing_files": published, "contracts_audits_models_modified": False, "completed_utc": dt.datetime.now(dt.timezone.utc).isoformat()}
    atomic_json(workdir / "restoration_review.json", proof)
    print(json.dumps(proof), flush=True)


if __name__ == "__main__":
    main()
