"""Deliberately pin public processed release metadata; never repin during modeling."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import urllib.parse
import urllib.request

HERE = Path(__file__).resolve().parent
COLLECTION = "6f6d381a-7701-4781-935c-db10d30de293"
CORE_DATASET = "066943a2-fdac-4b29-b348-40cede398e4e"
CORE_VERSION = "688185ad-11c2-4172-a53a-f4f1f4076860"
TPM = "GTEx_Analysis_2026-05-19_v11_RNASeQCv2.4.3_gene_tpm.gct.gz"
GTEX_OBJECTS = {
    "gtex_tpm": f"bulk-gex/v11/rna-seq/{TPM}",
    "gtex_sample_attributes": "annotations/v11/metadata-files/GTEx_Analysis_v11_Annotations_SampleAttributesDS.txt",
    "gtex_subject_phenotypes": "annotations/v11/metadata-files/GTEx_Analysis_v11_Annotations_SubjectPhenotypesDS.txt",
    "gtex_sample_dictionary": "annotations/v11/metadata-files/GTEx_Analysis_v11_Annotations_SampleAttributesDD.xlsx",
    "gtex_subject_dictionary": "annotations/v11/metadata-files/GTEx_Analysis_v11_Annotations_SubjectPhenotypesDD.xlsx",
    "gtex_rna_description": "bulk-gex/v11/rna-seq/description.tsv",
    "gtex_lcm_description": "bulk-gex/v11/rna-seq/README_LCM_pilot.txt",
}


def get_json(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=60) as response:
        return json.load(response)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=HERE / "input_contract.json")
    args = parser.parse_args()
    if args.out.exists():
        raise SystemExit("Refusing to overwrite an input contract; deliberately select a new versioned path.")
    files = []
    for key, name in GTEX_OBJECTS.items():
        encoded = urllib.parse.quote(name, safe="")
        metadata_url = f"https://storage.googleapis.com/storage/v1/b/adult-gtex/o/{encoded}"
        obj = get_json(metadata_url)
        files.append({
            "key": key, "filename": Path(name).name, "resource": "GTEx",
            "url": f"https://storage.googleapis.com/adult-gtex/{name}",
            "pinned_url": obj["mediaLink"], "metadata_url": metadata_url,
            "size_bytes": int(obj["size"]), "generation": obj["generation"],
            "crc32c_base64": obj.get("crc32c"), "md5_base64": obj.get("md5Hash"),
            "object_updated_utc": obj["updated"],
        })
    url = f"https://api.cellxgene.cziscience.com/curation/v1/dataset_versions/{CORE_VERSION}"
    core = get_json(url)
    # A version endpoint can wrap its dataset in a version metadata object.
    dataset = core.get("dataset", core)
    if dataset.get("dataset_id") != CORE_DATASET or dataset.get("dataset_version_id") != CORE_VERSION:
        raise ValueError("Unexpected HLCA dataset/version metadata")
    if dataset["cell_count"] != 584944 or dataset["feature_count"] != 27402:
        raise ValueError("HLCA pinned dimensions changed")
    assets = [a for a in dataset["assets"] if a["filetype"] == "H5AD"]
    if len(assets) != 1:
        raise ValueError("Expected exactly one pinned H5AD asset")
    asset = assets[0]
    with urllib.request.urlopen(urllib.request.Request(asset["url"], method="HEAD"), timeout=60) as response:
        headers = dict(response.headers)
    if int(headers["Content-Length"]) != asset["filesize"]:
        raise ValueError("HLCA HEAD size disagrees with its versioned API")
    files.append({
        "key": "hlca_core", "filename": f"{CORE_VERSION}.h5ad", "resource": "HLCA",
        "url": asset["url"], "pinned_url": asset["url"], "metadata_url": url,
        "size_bytes": asset["filesize"], "dataset_id": CORE_DATASET,
        "dataset_version_id": CORE_VERSION, "collection_id": COLLECTION,
        "schema_version": dataset["schema_version"], "source_etag": headers.get("ETag"),
        "source_object_version": headers.get("x-amz-version-id"),
        "etag_is_content_md5": False, "upstream_content_checksum": None,
        "version_published_at": dataset.get("published_at"),
        "api_cells": dataset["cell_count"], "api_features": dataset["feature_count"],
        "api_donor_strings": len(dataset["donor_id"]),
    })
    total = sum(f["size_bytes"] for f in files)
    if total >= 15_000_000_000:
        raise ValueError("Acquisition exceeds the authorized processed-data budget")
    contract = {
        "contract_version": "normal_reference_inputs_v0.1",
        "pinned_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "scope": "Input provenance only; not a frozen statistical model or validation gate",
        "download_budget_bytes": 15_000_000_000, "working_budget_bytes": 30_000_000_000,
        "total_expected_download_bytes": total,
        "gtex": {
            "release": "Adult GTEx V11 updated 2026-05-19 (announced 2026-05-28)",
            "processing": "GRCh38, GENCODE 47, STAR 2.7.11b; RNA-SeQC 2.4.3 gene TPM",
            "orientation": "gene rows, sample columns; GCT 1.2 Name=versioned Ensembl gene ID, Description=source symbol",
            "units": "TPM, continuous abundance; not integer counts", "lcm_included": False,
            "terms_url": "https://gtexportal.org/home/license",
            "terms_summary": "Custom GTEx Portal terms: acknowledge source and access date; no endorsement; mark outdated redistributed data; no warranty",
            "raw_sequence_access": "Controlled dbGaP/AnVIL; neither needed nor acquired",
        },
        "hlca": {
            "atlas": "HLCA v1.0 healthy core only, current CELLxGENE curated file",
            "orientation": "H5AD cells by genes; audit actual raw/var identities before use",
            "raw_counts": "raw.X", "normalized_X": "SCRAN-normalized log counts; counts themselves not batch corrected",
            "eligibility": "Published healthy core; audit source donor disease/collection annotations; does not certify entirely healthy or mutation-free donors",
            "terms_url": "https://data.humancellatlas.org/hca-bio-networks/lung/atlases/lung-v1-0",
            "data_license": "CC BY 4.0 and HCA data release policy; repository code MIT is a separate license",
            "full_atlas_excluded": True,
        },
        "independence": "All records for the same verified donor stay together; no cell/sample as an independent donor. Cross-resource donor overlap is not verifiable from anonymous IDs alone.",
        "tumor_projection": "Pending comparable processing and exact existing-patient linkage; no concatenation with historical batch-normalized RSEM",
        "files": files,
    }
    args.out.write_text(json.dumps(contract, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"contract": str(args.out), "sha256": hashlib.sha256(args.out.read_bytes()).hexdigest(), "files": len(files), "expected_bytes": total}))


if __name__ == "__main__":
    main()
