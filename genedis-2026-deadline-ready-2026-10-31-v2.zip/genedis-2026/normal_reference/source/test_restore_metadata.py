"""Focused publication guards with fictional inputs, not an RNA/model rescan."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from . import restore_metadata as restore
from .download import hash_file


def sha(data):
    return hashlib.sha256(data).hexdigest()


class RestorationGuards(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        (self.root / "data/downloads").mkdir(parents=True)
        (self.root / "data/audit").mkdir()
        self.matrix = self.root / "data/downloads/fictional.gz"
        self.matrix.write_bytes(b"fictional-source")
        (self.root / "input_contract.json").write_text(json.dumps({"files": [{"key": "gtex_tpm", "filename": self.matrix.name}]}))
        (self.root / "eligibility_contract.json").write_text('{"fictional":true}')
        (self.root / "producer.py").write_text("# fictional frozen producer\n")
        self.sample = b"sample_id\tdonor_id\nfictional-sample\tfictional-donor\n"
        self.genes = b"stable_gene_id\tsymbol\nENSG00000123456\tFICTIONAL\n"
        self.result = {"sample_manifest_sha256": sha(self.sample), "genes": {"manifest_sha256": sha(self.genes)}}
        contract_sha = restore.digest(self.root / "input_contract.json")
        hashes = hash_file(self.matrix)
        receipt = {"filename": self.matrix.name, "contract_sha256": contract_sha, **hashes}
        (self.root / "data/download_receipts.json").write_text(json.dumps({"gtex_tpm": receipt}))
        self.audit = {"resource": "gtex", "contract_sha256": contract_sha, "eligibility_contract_sha256": restore.digest(self.root / "eligibility_contract.json"), "producer_sha256": {"producer.py": restore.digest(self.root / "producer.py")}, "input_hashes": {"gtex_tpm": hashes}, "model_input": {"matrix_key": "gtex_tpm", "path": "data/downloads/fictional.gz", "sha256": hashes["sha256"], "size_bytes": hashes["size_bytes"]}, "result": {**self.result, "completed_utc": "fictional-original-time"}}
        (self.root / "gtex_audit.json").write_text(json.dumps(self.audit))
        self.original_audit = (self.root / "gtex_audit.json").read_bytes()

    def tearDown(self):
        self.temporary.cleanup()

    def callback(self, specs, downloads, workdir):
        (workdir / "gtex_samples.tsv").write_bytes(self.sample)
        (workdir / "gtex_gene_manifest.tsv").write_bytes(self.genes)
        return self.result

    def run_wrapper(self, callback=None):
        argv = ["restore_metadata", "--resource", "gtex", "--workdir", str(self.root / "data/replay-test"), "--publish-missing"]
        with patch.object(restore, "HERE", self.root), patch.object(restore, "audit_gtex", callback or self.callback), patch("sys.argv", argv), contextlib.redirect_stdout(io.StringIO()):
            restore.main()

    def test_bad_reconstructed_manifest_never_published(self):
        def wrong(specs, downloads, workdir):
            self.callback(specs, downloads, workdir)
            (workdir / "gtex_samples.tsv").write_bytes(b"wrong-but-callback-reports-old-sha")
            return self.result
        with self.assertRaisesRegex(ValueError, "Reconstructed manifest"):
            self.run_wrapper(wrong)
        self.assertEqual(list((self.root / "data/audit").iterdir()), [])
        self.assertEqual((self.root / "gtex_audit.json").read_bytes(), self.original_audit)

    def test_existing_different_target_blocks_all_publication(self):
        target = self.root / "data/audit/gtex_gene_manifest.tsv"
        target.write_bytes(b"user-owned-different-file")
        with self.assertRaisesRegex(ValueError, "preserved and not overwritten"):
            self.run_wrapper()
        self.assertFalse((self.root / "data/audit/gtex_samples.tsv").exists())
        self.assertEqual(target.read_bytes(), b"user-owned-different-file")

    def test_matching_restoration_creates_only_missing_exact_file(self):
        existing = self.root / "data/audit/gtex_samples.tsv"
        existing.write_bytes(self.sample)
        before = existing.stat().st_mtime_ns
        self.run_wrapper()
        self.assertEqual(existing.read_bytes(), self.sample)
        self.assertEqual(existing.stat().st_mtime_ns, before)
        self.assertEqual((self.root / "data/audit/gtex_gene_manifest.tsv").read_bytes(), self.genes)
        self.assertEqual((self.root / "gtex_audit.json").read_bytes(), self.original_audit)


if __name__ == "__main__":
    unittest.main()
