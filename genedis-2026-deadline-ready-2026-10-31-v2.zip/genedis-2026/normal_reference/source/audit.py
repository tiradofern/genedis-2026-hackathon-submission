"""Audit actual pinned matrices and donor metadata without fitting any reference."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import datetime as dt
import gzip
import hashlib
import json
from pathlib import Path
import re
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / ".runtime" / "packages"))
import numpy as np

from .download import atomic_json, hash_file

GENE = re.compile(r"^(ENSG[0-9]+)(?:\.([0-9]+))?(_PAR_Y)?$")
GTEX_SAMPLE_FIELDS = ["sample_id", "donor_id", "tissue", "tissue_group", "sex", "age_bracket", "hardy", "rin", "ischemic_time", "source_sample_type", "autolysis", "center", "rna_extraction_batch", "gene_expression_batch", "pathology_notes", "vendor_qc_fail"]
HLCA_FIELDS = ["donor_id", "sample", "study", "dataset", "ann_finest_level", "ann_level_1", "ann_level_2", "ann_level_3", "ann_level_4", "ann_level_5", "subject_type", "lung_condition", "disease", "tissue", "tissue_sampling_method", "smoking_status", "age_or_mean_of_age_range", "sex", "reference_genome", "assay", "is_primary_data"]


def digest(path: Path) -> str:
    sha = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(4 * 1024 * 1024):
            sha.update(chunk)
    return sha.hexdigest()


def gene_identity(identifier: str) -> tuple[str, str, str]:
    match = GENE.fullmatch(identifier)
    if not match:
        return "", "", "invalid_ensembl_gene_id"
    return match.group(1) + (match.group(3) or ""), match.group(2) or "", "eligible_identity"


def write_tsv(path: Path, fields: list[str], rows) -> None:
    temp = path.with_name(path.name + ".tmp")
    with temp.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fields, delimiter="\t", extrasaction="ignore", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    temp.replace(path)


def finalize_genes(rows: list[dict], path: Path) -> dict:
    stable_counts = Counter(x["stable_gene_id"] for x in rows if x["stable_gene_id"])
    symbols = Counter(x["symbol"] for x in rows if x["symbol"])
    for row in rows:
        if row["stable_gene_id"] and stable_counts[row["stable_gene_id"]] > 1:
            row["identity_status"] = "duplicate_stable_id_all_rows_excluded"
        row["symbol_multiplicity"] = symbols[row["symbol"]] if row["symbol"] else 0
    write_tsv(path, ["row_index", "original_gene_id", "stable_gene_id", "gene_version", "symbol", "identity_status", "symbol_multiplicity"], rows)
    return {
        "rows": len(rows), "unique_original_ids": len({x["original_gene_id"] for x in rows}),
        "identity_status_counts": dict(Counter(x["identity_status"] for x in rows)),
        "duplicate_stable_id_keys": sum(v > 1 for v in stable_counts.values()),
        "duplicate_symbol_keys": sum(v > 1 for v in symbols.values()),
        "missing_symbols": sum(not x["symbol"] for x in rows),
        "manifest_sha256": digest(path),
        "rule": "Keep exact IDs/symbols and Ensembl versions. Remove numeric version only for explicit stable-ID joins, preserving PAR_Y. Exclude every row of ambiguous stable IDs. Symbol multiplicity is reported, never resolved by taking a first row.",
    }


def audit_gtex(specs: dict, downloads: Path, out: Path) -> dict:
    metadata = {}
    with (downloads / specs["gtex_sample_attributes"]["filename"]).open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        metadata_fields = reader.fieldnames
        for row in reader:
            if row["SAMPID"] in metadata:
                raise ValueError("Duplicate GTEx SAMPID metadata")
            metadata[row["SAMPID"]] = row
    subjects = {}
    with (downloads / specs["gtex_subject_phenotypes"]["filename"]).open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream, delimiter="\t"):
            if row["SUBJID"] in subjects:
                raise ValueError("Duplicate GTEx SUBJID metadata")
            subjects[row["SUBJID"]] = row
    genes, profiles = [], []
    n_negative = n_nonfinite = 0
    last = time.monotonic()
    with gzip.open(downloads / specs["gtex_tpm"]["filename"], "rt", encoding="utf-8", newline="") as stream:
        if stream.readline().strip() != "#1.2":
            raise ValueError("Expected GCT1.2")
        n_genes, n_samples = map(int, stream.readline().strip().split("\t"))
        header = stream.readline().rstrip("\r\n").split("\t")
        if header[:2] != ["Name", "Description"] or len(header) != n_samples + 2 or len(set(header[2:])) != n_samples:
            raise ValueError("Wrong/duplicate GTEx matrix columns")
        missing_samples, missing_subjects = [], []
        for sample_id in header[2:]:
            donor = "-".join(sample_id.split("-")[:2])
            if sample_id not in metadata:
                missing_samples.append(sample_id)
            if donor not in subjects:
                missing_subjects.append(donor)
            meta, subject = metadata.get(sample_id, {}), subjects.get(donor, {})
            tissue = meta.get("SMTSD", "")
            profiles.append({
                "sample_id": sample_id, "donor_id": donor, "tissue": tissue,
                "tissue_group": meta.get("SMTS", ""), "sex": subject.get("SEX", ""),
                "age_bracket": subject.get("AGE", ""), "hardy": subject.get("DTHHRDY", ""),
                "rin": meta.get("SMRIN", ""), "ischemic_time": meta.get("SMTSISCH", ""),
                "source_sample_type": "cultured_or_transformed_cells" if tissue.startswith("Cells -") else "bulk_tissue",
                "autolysis": meta.get("SMATSSCR", ""), "center": meta.get("SMCENTER", ""),
                "rna_extraction_batch": meta.get("SMNABTCH", ""), "gene_expression_batch": meta.get("SMGEBTCH", ""),
                "pathology_notes": meta.get("SMPTHNTS", ""), "vendor_qc_fail": meta.get("SMVQCFL", ""),
            })
        if missing_samples or missing_subjects:
            raise ValueError("Actual GTEx expression columns have unmatched metadata/donors")
        excluded_tissues = {"Cells - Cultured fibroblasts", "Cells - EBV-transformed lymphocytes"}
        primary = [row for row in profiles if row["tissue"] not in excluded_tissues]
        if len(primary) != 18637 or len({row["donor_id"] for row in primary}) != 946 or len({row["tissue"] for row in primary}) != 52:
            raise ValueError("GTEx actual native-tissue eligibility changed from the prefit contract")
        for index, line in enumerate(stream):
            identifier, symbol, values = line.rstrip("\r\n").split("\t", 2)
            array = np.fromstring(values, sep="\t", dtype=np.float64)
            if array.size != n_samples:
                raise ValueError(f"GTEx row {index} has malformed expression values")
            n_negative += int(np.sum(array < 0))
            n_nonfinite += int(np.sum(~np.isfinite(array)))
            stable, version, status = gene_identity(identifier)
            genes.append({"row_index": index, "original_gene_id": identifier, "stable_gene_id": stable, "gene_version": version, "symbol": symbol, "identity_status": status})
            if time.monotonic() - last >= 20:
                print(json.dumps({"audit": "gtex", "rows_checked": index + 1, "expected": n_genes}), flush=True)
                last = time.monotonic()
    if len(genes) != n_genes or n_negative or n_nonfinite:
        raise ValueError("GTEx dimensions or nonnegative-finite TPM integrity failed")
    write_tsv(out / "gtex_samples.tsv", GTEX_SAMPLE_FIELDS, profiles)
    gene_report = finalize_genes(genes, out / "gtex_gene_manifest.tsv")
    tissues = []
    for tissue in sorted({x["tissue"] for x in profiles}):
        rows = [x for x in profiles if x["tissue"] == tissue]
        tissues.append({"tissue": tissue, "samples": len(rows), "donors": len({x["donor_id"] for x in rows}), "source_sample_type": rows[0]["source_sample_type"], "repeated_donor_tissue_samples": len(rows) - len({x["donor_id"] for x in rows})})
    included_donors = {x["donor_id"] for x in profiles}
    donor_tissue_counts = Counter((x["donor_id"], x["tissue"]) for x in profiles)
    return {
        "resource": "GTEx", "ready_for_normal_only_preparation": True,
        "orientation": "gene rows by sample columns", "units": "RNA-SeQC2.4.3 gene TPM",
        "samples": len(profiles), "independent_donor_ids": len(included_donors), "tissues": len(tissues),
        "primary_native_tissue_samples": len(primary), "primary_native_donors": len({row["donor_id"] for row in primary}), "primary_native_tissues": len({row["tissue"] for row in primary}),
        "excluded_cultured_source_classes": dict(Counter(row["tissue"] for row in profiles if row["tissue"] in excluded_tissues)),
        "metadata_sample_rows": len(metadata), "metadata_subject_rows": len(subjects),
        "metadata_subjects_without_current_matrix": len(set(subjects) - included_donors),
        "matrix_columns_missing_metadata": 0, "matrix_donors_missing_metadata": 0,
        "same_donor_tissue_multiple_samples_groups": sum(v > 1 for v in donor_tissue_counts.values()),
        "extra_same_donor_tissue_samples": sum(v - 1 for v in donor_tissue_counts.values()),
        "source_sample_type_counts": dict(Counter(x["source_sample_type"] for x in profiles)),
        "sample_metadata_missing": {field: sum(not x[field] for x in profiles) for field in GTEX_SAMPLE_FIELDS},
        "donor_metadata_missing": {field: sum(not subjects[d].get(field, "") for d in included_donors) for field in ["SEX", "AGE", "DTHHRDY"]},
        "donor_sex_counts_source_codes": dict(Counter(subjects[d]["SEX"] for d in included_donors)),
        "donor_age_brackets": dict(Counter(subjects[d]["AGE"] for d in included_donors)),
        "tissue_coverage": tissues, "genes": gene_report,
        "expression_integrity": {"all_rows_scanned": True, "values_checked": n_genes * n_samples, "negative": n_negative, "nonfinite": n_nonfinite},
        "sample_manifest_sha256": digest(out / "gtex_samples.tsv"),
        "full_metadata_fields": metadata_fields,
        "eligibility_not_implicitly_applied": "All actual current matrix columns retained in source manifest. Cultured/transformed lines tagged. Any organ-only restriction and within-donor replicate handling must be explicit model rules.",
        "health_limit": "Non-diseased sampled tissues do not certify entirely healthy donors; exact age/ethnicity require controlled access; smoking not present in the open phenotype table.",
    }


def h5_strings(group, name: str) -> np.ndarray:
    if name not in group:
        return np.full(len(group[group.attrs.get("_index", "_index")]), "", dtype=object)
    item = group[name]
    if hasattr(item, "keys"):
        categories = item["categories"][:]
        categories = np.array([x.decode() if isinstance(x, bytes) else str(x) for x in categories], dtype=object)
        codes = item["codes"][:]
        return np.array([categories[i] if i >= 0 else "" for i in codes], dtype=object)
    array = item[:]
    return np.array([x.decode() if isinstance(x, bytes) else str(x) for x in array], dtype=object)


def audit_hlca(specs: dict, downloads: Path, out: Path) -> dict:
    import h5py
    with h5py.File(downloads / specs["hlca_core"]["filename"], "r") as handle:
        obs = handle["obs"]
        obs_columns = list(obs.keys())
        n_cells = len(obs[obs.attrs.get("_index", "_index")])
        values = {field: h5_strings(obs, field) for field in HLCA_FIELDS}
        if "raw" not in handle or "X" not in handle["raw"]:
            raise ValueError("Pinned HLCA has no raw.X")
        raw, var = handle["raw/X"], handle["raw/var"]
        shape = tuple(map(int, raw.attrs["shape"]))
        if shape[0] != n_cells or shape != (584944, 27402):
            raise ValueError("Actual HLCA raw shape disagrees with the pinned contract")
        if raw.attrs.get("encoding-type") != "csr_matrix":
            raise ValueError("This bounded audit expects source CSR raw counts")
        pointer = raw["indptr"][:]
        if len(raw["data"]) != len(raw["indices"]) or len(pointer) != shape[0] + 1 or pointer[0] != 0 or pointer[-1] != len(raw["data"]) or np.any(np.diff(pointer) < 0):
            raise ValueError("HLCA CSR structure is invalid")
        ids = h5_strings(var, var.attrs.get("_index", "_index"))
        if len(ids) != shape[1]:
            raise ValueError("HLCA raw.var length differs from raw gene dimension")
        symbol_field = "feature_name" if "feature_name" in var else "gene_symbols" if "gene_symbols" in var else None
        symbols = h5_strings(var, symbol_field) if symbol_field else np.full(shape[1], "", dtype=object)
        genes = []
        for index, (identifier, symbol) in enumerate(zip(ids, symbols, strict=True)):
            stable, version, status = gene_identity(identifier)
            genes.append({"row_index": index, "original_gene_id": identifier, "stable_gene_id": stable, "gene_version": version, "symbol": symbol, "identity_status": status})
        gene_report = finalize_genes(genes, out / "hlca_gene_manifest.tsv")
        raw_integrity = {"nonzero_values": len(raw["data"]), "negative": 0, "nonfinite": 0, "noninteger": 0, "dtype": str(raw["data"].dtype)}
        for start in range(0, len(raw["data"]), 4_000_000):
            array = raw["data"][start:start + 4_000_000]
            indices = raw["indices"][start:start + 4_000_000]
            raw_integrity["negative"] += int(np.sum(array < 0))
            raw_integrity["nonfinite"] += int(np.sum(~np.isfinite(array)))
            raw_integrity["noninteger"] += int(np.sum(array != np.floor(array)))
            if np.any(indices < 0) or np.any(indices >= shape[1]):
                raise ValueError("HLCA CSR gene index is invalid")
        raw_integrity["all_stored_count_values_scanned"] = True
        raw_integrity["csr_dimensions_indices_indptr_valid"] = True
        if any(raw_integrity[key] for key in ["negative", "nonfinite", "noninteger"]):
            raise ValueError("HLCA raw.X did not pass untransformed-count integrity")
        donor_ids = set(values["donor_id"])
        if "" in donor_ids or any(not x for x in values["sample"]) or any(not x for x in values["study"]):
            raise ValueError("HLCA donor/sample/study identity is missing")
        # Do not prepend a study to a harmonized donor ID: that could split one donor across roles.
        donor_studies = defaultdict(set)
        for donor, study in zip(values["donor_id"], values["study"], strict=True):
            donor_studies[donor].add(study)
        blocked_donors = {donor for donor, condition in zip(values["donor_id"], values["lung_condition"], strict=True) if condition != "Healthy"}
        primary_eligible = np.array([donor not in blocked_donors for donor in values["donor_id"]])
        if len(donor_ids - blocked_donors) != 104 or int(primary_eligible.sum()) != 523962:
            raise ValueError("Actual HLCA eligibility differs from the prefit healthy-only contract")
        counts = {field: dict(Counter(values[field])) for field in HLCA_FIELDS if field not in ["donor_id", "sample", "age_or_mean_of_age_range"]}
        columns = ["cell_index"] + HLCA_FIELDS + ["primary_eligible", "primary_exclusion_reason"]
        write_tsv(out / "hlca_cells.tsv", columns, ({"cell_index": index, **{field: values[field][index] for field in HLCA_FIELDS}, "primary_eligible": bool(primary_eligible[index]), "primary_exclusion_reason": "" if primary_eligible[index] else "whole_donor_nonhealthy_or_tumor_adjacent_source_label"} for index in range(n_cells)))
        profile_counts = Counter(zip(values["donor_id"], values["ann_level_2"], strict=True))
        profile_rows = [{"donor_id": donor, "class_label": label, "cells": count, "studies": "|".join(sorted(donor_studies[donor]))} for (donor, label), count in sorted(profile_counts.items())]
        write_tsv(out / "hlca_donor_class_coverage.tsv", ["donor_id", "class_label", "cells", "studies"], profile_rows)
        study_coverage = []
        for study in sorted(set(values["study"])):
            indices = values["study"] == study
            study_coverage.append({"study": study, "cells": int(indices.sum()), "donor_ids": len(set(values["donor_id"][indices])), "level2_classes": len(set(values["ann_level_2"][indices]))})
        var_columns = list(var)
        source_X = {"present_in_local_subset": False, "scope": "Normalized X deliberately omitted by explicit raw-only acquisition amendment"}
        if "X" in handle:
            source_X = {"present_in_local_subset": True, "encoding": str(handle["X"].attrs.get("encoding-type")), "shape": list(map(int, handle["X"].attrs.get("shape", [])))}
        age_item = obs.get("age_or_mean_of_age_range")
        age_storage = {"encoding": str(age_item.attrs.get("encoding-type")), "dtype": str(age_item.dtype) if hasattr(age_item, "dtype") else "categorical_group"} if age_item is not None else {"missing": True}
    return {
        "resource": "HLCA healthy core", "ready_for_normal_only_preparation": True,
        "orientation": "cells by genes", "raw_count_shape": list(shape),
        "independent_donor_ids": len(donor_ids), "samples": len(set(values["sample"])),
        "primary_healthy_donors": len(donor_ids - blocked_donors), "primary_healthy_cells": int(primary_eligible.sum()),
        "excluded_whole_donors": len(blocked_donors), "excluded_cells": int((~primary_eligible).sum()),
        "studies": len(set(values["study"])), "datasets": len(set(values["dataset"])),
        "harmonized_donor_ids_in_multiple_studies": sum(len(s) > 1 for s in donor_studies.values()),
        "donor_identity_rule": "Keep source harmonized donor_id as the grouping key; retain study/dataset/sample. Cross-study duplicate donor resolution beyond the harmonized source IDs is not independently proven.",
        "source_obs_columns": obs_columns,
        "audited_obs_fields_present": [field for field in HLCA_FIELDS if field in obs_columns],
        "metadata_missing_cells": {field: sum(x in ["", "nan", "None", "unknown"] for x in values[field]) for field in HLCA_FIELDS},
        "categorical_cell_counts": counts,
        "study_coverage": study_coverage,
        "donor_level2_profile_candidates": len(profile_rows),
        "donor_level2_profiles_at_least20_cells": sum(x["cells"] >= 20 for x in profile_rows),
        "genes": gene_report, "raw_counts_integrity": raw_integrity,
        "X_storage": source_X, "raw_var_columns": var_columns,
        "age_storage": age_storage,
        "cell_manifest_sha256": digest(out / "hlca_cells.tsv"),
        "donor_class_manifest_sha256": digest(out / "hlca_donor_class_coverage.tsv"),
        "normal_eligibility": "Source original core retained. Primary exactly source Healthy only, with whole-donor blocking of all 3 tumor-adjacent donors/60982 cells; 104 donors/523962 cells remain. No full-core healthy sensitivity. Non-diseased tissue is not a guarantee of a globally healthy, cancer-free or mutation-free donor.",
        "normalization": "Pseudobulk must sum raw.X within exact donor and cell type before chosen normalization; X SCRAN log values must not be summed as counts. Integrated scANVI embedding is not harmonized gene counts.",
        "primary_data_note": "All core cells are a secondary integrated view. Do not require is_primary_data=True within this pinned core or it would remove the intended atlas; do not add overlapping original/full-atlas cells as independent observations.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--contract", type=Path, default=HERE / "input_contract.json")
    parser.add_argument("--resource", choices=["gtex", "hlca", "all"], default="all")
    parser.add_argument("--verify-files", action="store_true", help="Recompute full download hashes before audit, in addition to receipts")
    args = parser.parse_args()
    contract_bytes = args.contract.read_bytes()
    contract = json.loads(contract_bytes)
    contract_hash = hashlib.sha256(contract_bytes).hexdigest()
    specs = {x["key"]: x for x in contract["files"]}
    receipts = json.loads((HERE / "data/download_receipts.json").read_text())
    amendment_path = HERE / "acquisition_amendment.json"
    ranges_path = HERE / "data/audit/hlca_source_ranges.json"
    if "hlca_core_raw" in receipts:
        amendment = json.loads(amendment_path.read_text())
        receipt = receipts["hlca_core_raw"]
        if amendment["initial_contract_sha256"] != contract_hash or receipt["amendment_sha256"] != digest(amendment_path) or receipt["source_ranges_manifest_sha256"] != digest(ranges_path) or receipt.get("full_source_file_retrieved") is not False:
            raise ValueError("Raw-only source provenance is missing or changed")
        ranges = json.loads(ranges_path.read_text())
        if ranges["initial_contract_sha256"] != contract_hash or ranges["acquisition_amendment_sha256"] != digest(amendment_path):
            raise ValueError("Raw-only range manifest belongs to a different source")
        for entry in ranges["ranges"]:
            path = HERE / entry["path"]
            if path.stat().st_size != entry["end"] - entry["start"] + 1 or digest(path) != entry["sha256"]:
                raise ValueError("Retained raw-only source range bytes changed")
        specs["hlca_core"] = {**specs["hlca_core"], "filename": receipt["filename"], "size_bytes": receipt["size_bytes"], "receipt_key": "hlca_core_raw"}
    needed = [k for k, spec in specs.items() if args.resource == "all" or spec["resource"].lower() == args.resource]
    for key in needed:
        receipt_key = specs[key].get("receipt_key", key)
        path = HERE / "data/downloads" / specs[key]["filename"]
        if receipt_key not in receipts or receipts[receipt_key]["contract_sha256"] != contract_hash or path.stat().st_size != specs[key]["size_bytes"]:
            raise ValueError(f"Missing or stale exact input receipt: {key}")
        if args.verify_files and hash_file(path)["sha256"] != receipts[receipt_key]["sha256"]:
            raise ValueError(f"Input bytes changed since download: {key}")
    out = HERE / "data/audit"
    out.mkdir(parents=True, exist_ok=True)
    report_path = HERE / "audit_summary.json"
    report = json.loads(report_path.read_text()) if report_path.exists() else {"schema": "normal_reference_source_audit_v0.1", "contract_sha256": contract_hash, "resources": {}}
    if report["contract_sha256"] != contract_hash:
        raise ValueError("Cannot replace an audit with a different contract")
    for resource, callback in [("gtex", audit_gtex), ("hlca", audit_hlca)]:
        if args.resource not in ["all", resource]:
            continue
        if (HERE / f"{resource}_audit.json").exists():
            raise ValueError(f"Immutable completed {resource} audit already exists; use a deliberately versioned new audit")
        result = callback(specs, HERE / "data/downloads", out)
        result["completed_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
        report["resources"][resource] = result
        report.setdefault("references", {})[resource] = {"status": "ready", "input_contract_sha256": contract_hash, "ready_scope": "source integrity and metadata only; no biological validation"}
        report["input_hashes"] = {key: {field: receipts[key][field] for field in ["size_bytes", "sha256", "md5_base64", "crc32c_base64"]} for key in sorted(receipts)}
        report["all_sources_ready"] = set(report["resources"]) == {"gtex", "hlca"}
        report["source_only"] = "No model fit, donor role assignment, validation result or tumor projection is produced by this audit."
        report["producer_sha256"] = {name: digest(HERE / name) for name in ["audit.py", "download.py", "download_segmented.py", "extract_hlca_raw.py", "metadata_preflight.py", "pin_sources.py", "requirements-source.txt"]}
        report["eligibility_contract_sha256"] = digest(HERE / "eligibility_contract.json")
        matrix_key = "gtex_tpm" if resource == "gtex" else specs["hlca_core"].get("receipt_key", "hlca_core")
        model_input = {"matrix_key": matrix_key, "path": "data/downloads/" + receipts[matrix_key]["filename"], "size_bytes": receipts[matrix_key]["size_bytes"], "sha256": receipts[matrix_key]["sha256"]}
        if matrix_key == "hlca_core_raw":
            model_input.update({"amendment_sha256": digest(amendment_path), "source_ranges_manifest_path": "data/audit/hlca_source_ranges.json", "source_ranges_manifest_sha256": digest(ranges_path), "full_source_file_retrieved": False, "groups": ["obs", "raw"], "normalized_X_omitted": True})
        atomic_json(HERE / f"{resource}_audit.json", {"contract_sha256": contract_hash, "eligibility_contract_sha256": report["eligibility_contract_sha256"], "resource": resource, "result": result, "input_hashes": report["input_hashes"], "producer_sha256": report["producer_sha256"], "model_input": model_input})
        atomic_json(report_path, report)
        print(json.dumps({"resource": resource, "status": "audited", "independent_donors": result["independent_donor_ids"]}), flush=True)


if __name__ == "__main__":
    main()
