"""Join exact current matrix columns to complete public metadata before any fit."""
from collections import Counter
import csv
import gzip
import hashlib
import json

from .audit import HERE, GTEX_SAMPLE_FIELDS, digest, write_tsv
from .download import atomic_json


def main():
    contract = json.loads((HERE / "input_contract.json").read_text())
    specs = {x["key"]: x for x in contract["files"]}
    downloads = HERE / "data/downloads"
    metadata = {}
    with (downloads / specs["gtex_sample_attributes"]["filename"]).open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream, delimiter="\t"):
            if row["SAMPID"] in metadata:
                raise ValueError("Duplicate source sample metadata")
            metadata[row["SAMPID"]] = row
    with (downloads / specs["gtex_subject_phenotypes"]["filename"]).open(encoding="utf-8-sig", newline="") as stream:
        subjects = {row["SUBJID"]: row for row in csv.DictReader(stream, delimiter="\t")}
    path = downloads / specs["gtex_tpm"]["filename"]
    if not path.exists():
        path = path.with_name(path.name + ".part")
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        header_lines = [stream.readline() for _ in range(3)]
    n_genes, n_samples = map(int, header_lines[1].strip().split("\t"))
    ids = header_lines[2].rstrip("\r\n").split("\t")[2:]
    if header_lines[0].strip() != "#1.2" or len(ids) != n_samples or len(set(ids)) != n_samples:
        raise ValueError("Malformed source matrix header")
    records = []
    excluded_classes = {"Cells - Cultured fibroblasts", "Cells - EBV-transformed lymphocytes"}
    for sample in ids:
        donor = "-".join(sample.split("-")[:2])
        meta, subject = metadata[sample], subjects[donor]
        tissue = meta["SMTSD"]
        records.append({"sample_id": sample, "donor_id": donor, "tissue": tissue, "tissue_group": meta["SMTS"], "sex": subject["SEX"], "age_bracket": subject["AGE"], "hardy": subject["DTHHRDY"], "rin": meta["SMRIN"], "ischemic_time": meta["SMTSISCH"], "source_sample_type": "cultured_or_transformed_cells" if tissue in excluded_classes else "bulk_tissue", "primary_eligible": tissue not in excluded_classes, "autolysis": meta["SMATSSCR"], "center": meta["SMCENTER"], "rna_extraction_batch": meta["SMNABTCH"], "gene_expression_batch": meta["SMGEBTCH"], "pathology_notes": meta.get("SMPTHNTS", ""), "vendor_qc_fail": meta.get("SMVQCFL", "")})
    primary = [x for x in records if x["primary_eligible"]]
    summary = {
        "status": "metadata_only_not_source_ready", "scope": "Complete metadata and current matrix header audited; full matrix values and full-file checksum remain pending",
        "contract_sha256": digest(HERE / "input_contract.json"), "eligibility_contract_sha256": digest(HERE / "eligibility_contract.json"),
        "matrix_header_sha256": hashlib.sha256("".join(header_lines).encode()).hexdigest(),
        "source_genes_in_header": n_genes, "source_samples": n_samples, "source_donors": len({x["donor_id"] for x in records}), "source_classes": len({x["tissue"] for x in records}),
        "primary_samples": len(primary), "primary_donors": len({x["donor_id"] for x in primary}), "primary_tissues": len({x["tissue"] for x in primary}),
        "excluded_source_classes": dict(Counter(x["tissue"] for x in records if not x["primary_eligible"])),
        "metadata_samples": len(metadata), "metadata_subjects": len(subjects),
        "missing_metadata": {field: sum(not x[field] for x in records) for field in ["rin", "ischemic_time", "autolysis", "center", "rna_extraction_batch", "gene_expression_batch"]},
        "rin_range": [min(float(x["rin"]) for x in records), max(float(x["rin"]) for x in records)],
        "source_classes": [{"tissue": tissue, "samples": sum(x["tissue"] == tissue for x in records), "donors": len({x["donor_id"] for x in records if x["tissue"] == tissue}), "primary_eligible": tissue not in excluded_classes} for tissue in sorted({x["tissue"] for x in records})],
        "qc_limit": "Current analysis matrix is the published eligibility set; the open sample metadata have quantitative QC/pathology notes but no standalone PASS flag. No additional arbitrary RIN cutoff is imposed. Non-diseased tissue does not prove a pathology-free or globally healthy donor.",
    }
    out = HERE / "data/audit"
    out.mkdir(parents=True, exist_ok=True)
    write_tsv(out / "gtex_samples_preflight.tsv", GTEX_SAMPLE_FIELDS + ["primary_eligible"], records)
    atomic_json(HERE / "gtex_metadata_preflight.json", summary)
    print(json.dumps({key: summary[key] for key in ["status", "source_samples", "source_donors", "primary_samples", "primary_donors", "primary_tissues", "excluded_source_classes", "rin_range"]}))


if __name__ == "__main__":
    main()
