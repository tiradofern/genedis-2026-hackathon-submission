"""Public processed input contracts for a separate normal-only reference."""
