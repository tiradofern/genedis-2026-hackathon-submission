"""Prepare separate normal-only matrices after the source audit is ready.

GTEx is streamed twice. Healthy HLCA counts are summed in sparse cell blocks,
never converted to a dense cell-by-gene matrix. Only bounded donor/class
matrices and selected log-expression features are saved under ignored data/.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import gzip
import json
from pathlib import Path
import sys

import numpy as np

from .core import (NORMAL_STATUS, ROLES, class_weights, donor_split, file_hash,
                   identity_mask, validate_records, weighted_statistics, write_json)

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CONFIG = ROOT / "configs" / "normal_reference_v0_1.json"


def read_tsv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def paths_for_source(reference: str, contract: Path) -> tuple[dict, dict, Path]:
    value = json.loads(contract.read_text(encoding="utf-8"))
    receipts_path = contract.parent / "data" / "download_receipts.json"
    audit_path = contract.parent / f"{reference}_audit.json"
    if not audit_path.exists():
        raise ValueError("Source audit is not ready: missing audited summary")
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    if audit.get("contract_sha256") != file_hash(contract):
        raise ValueError("Stale source audit contract")
    if audit.get("resource") != reference or audit.get("result", {}).get("ready_for_normal_only_preparation") is not True:
        raise ValueError(f"Source reference not audited ready or wrong resource: {reference}")
    eligibility = contract.parent / "eligibility_contract.json"
    if file_hash(eligibility) != audit.get("eligibility_contract_sha256"):
        raise ValueError("Source audit uses a stale eligibility contract")
    for name, digest in audit.get("producer_sha256", {}).items():
        producer = (contract.parent / name).resolve()
        if not producer.is_relative_to(ROOT.resolve()) or file_hash(producer) != digest:
            raise ValueError(f"Source audit producer changed: {name}")
    if not audit.get("producer_sha256"):
        raise ValueError("Source audit has no producer bindings")
    receipts = json.loads(receipts_path.read_text())
    model_input = audit.get("model_input")
    if not model_input:
        raise ValueError("Source audit lacks an explicit model input")
    key = model_input["matrix_key"]
    if key not in ("gtex_tpm", "hlca_core", "hlca_core_raw") or (reference == "gtex") != (key == "gtex_tpm"):
        raise ValueError("Wrong source model input key")
    receipt = receipts[key]
    audited_input = audit["input_hashes"][key]
    data_path = (contract.parent / model_input["path"]).resolve()
    if not data_path.is_relative_to((contract.parent / "data").resolve()):
        raise ValueError("Source matrix path escapes audited data directory")
    if receipt["contract_sha256"] != file_hash(contract) or data_path.stat().st_size != model_input["size_bytes"]:
        raise ValueError("Source bytes/receipt do not match pinned source")
    if any(row["sha256"] != receipt["sha256"] or row["size_bytes"] != receipt["size_bytes"] for row in (audited_input, model_input)):
        raise ValueError("Source audit, model input and download receipt disagree")
    if file_hash(data_path) != receipt["sha256"]:
        raise ValueError("Source content changed since audit")
    if reference == "gtex":
        sample_manifest = contract.parent / "data" / "audit" / "gtex_samples.tsv"
        if file_hash(sample_manifest) != audit["result"]["sample_manifest_sha256"]:
            raise ValueError("GTEx donor/class metadata changed since source audit")
    if key == "hlca_core_raw":
        amendment = contract.parent / "acquisition_amendment.json"
        if file_hash(amendment) != model_input["amendment_sha256"] or model_input.get("full_source_file_retrieved") is not False or model_input.get("normalized_X_omitted") is not True or model_input.get("groups") != ["obs", "raw"]:
            raise ValueError("HLCA raw-only acquisition amendment does not match audited scope")
        ranges = (contract.parent / model_input["source_ranges_manifest_path"]).resolve()
        if not ranges.is_relative_to(contract.parent.resolve()) or file_hash(ranges) != model_input["source_ranges_manifest_sha256"]:
            raise ValueError("HLCA raw-only range ledger changed or escaped its source directory")
    return value, audit, data_path


def group_records(samples: list[dict], reference: str, config: dict) -> tuple[list[dict], np.ndarray, dict]:
    donors = [row["donor_id"] for row in samples]
    roles = donor_split(donors, reference, config["seed"], config["donor_roles"])
    groups = defaultdict(list)
    for i, sample in enumerate(samples):
        if sample.get("normal_status", NORMAL_STATUS) != NORMAL_STATUS:
            raise ValueError("Non-eligible normal source row reached model preparation")
        groups[(sample["donor_id"], sample["class_label"])].append(i)
    group_keys = sorted(groups)
    records = []
    sample_group = np.empty(len(samples), dtype=np.int32)
    for group_index, (donor, label) in enumerate(group_keys):
        indices = groups[(donor, label)]
        studies = sorted(set(samples[i].get("study_id", reference) for i in indices))
        covariates = {}
        for key in ("sex", "age_bracket", "age", "smoking", "hardy", "rin", "ischemic_time", "tissue_sampling_method", "subject_type", "lung_condition", "autolysis", "center", "rna_extraction_batch", "gene_expression_batch", "vendor_qc_fail"):
            observed = sorted(set(str(samples[i].get(key, "")).strip() for i in indices) - {"", "nan", "None"})
            covariates[key] = observed[0] if len(observed) == 1 else ("multiple" if observed else None)
        records.append({"profile_id": f"{reference}:{donor}:{label}", "donor_id": donor, "class_label": label,
                        "source_id": reference, "study_id": "|".join(studies), "study_ids": studies,
                        "role": roles[donor], "normal_status": NORMAL_STATUS, "source_records": len(indices),
                        "covariates": covariates})
        sample_group[indices] = group_index
    validate_records(records)
    training_counts = Counter(r["class_label"] for r in records if r["role"] == "train")
    represented = sorted(label for label, n in training_counts.items() if n >= config["profiles"]["minimum_training_donors_per_class"])
    return records, sample_group, {"supported_classes": represented, "training_donors_per_class": dict(sorted(training_counts.items())),
                                   "unsupported_classes": sorted(set(r["class_label"] for r in records) - set(represented)),
                                   "primary_class_count": len(set(r["class_label"] for r in records)), "supported_class_count": len(represented),
                                   "unsupported_class_count": len(set(r["class_label"] for r in records) - set(represented)),
                                   "source_records": len(samples), "donors": len(roles), "eligible_profiles": len(records),
                                   "roles": {role: {"donors": len(set(r["donor_id"] for r in records if r["role"] == role)),
                                                     "profiles": sum(r["role"] == role for r in records)} for role in ROLES}}


def choose_features(stats: list[dict], config: dict) -> list[int]:
    rules = config["features"]
    eligible = [i for i, row in enumerate(stats) if row["identity_eligible"] and row["training_missing_fraction"] <= rules["max_missing_training_fraction"] + 1e-12
                and row["training_positive_fraction"] >= rules["min_positive_training_fraction"] and row["training_variance"] >= rules["min_weighted_variance"]]
    selected = sorted(eligible, key=lambda i: (-stats[i]["training_variance"], stats[i]["stable_id"]))[:rules["maximum"]]
    if len(selected) < 3:
        raise ValueError("Too few training-only eligible genes")
    return selected


def feature_exclusions(stats: list[dict], selected_count: int, config: dict) -> dict:
    """Disjoint ordered losses; full gene-by-gene decisions remain local."""
    rules = config["features"]
    remaining = [row for row in stats if row["identity_eligible"]]
    losses = {"identity_excluded": len(stats) - len(remaining)}
    for reason, predicate in (
        ("training_missingness", lambda row: row["training_missing_fraction"] <= rules["max_missing_training_fraction"] + 1e-12),
        ("training_positive_fraction", lambda row: row["training_positive_fraction"] >= rules["min_positive_training_fraction"]),
        ("training_variability", lambda row: row["training_variance"] >= rules["min_weighted_variance"]),
    ):
        passed = [row for row in remaining if predicate(row)]
        losses[reason] = len(remaining) - len(passed)
        remaining = passed
    losses["eligible_below_top_variance_rank"] = len(remaining) - selected_count
    return {"input": len(stats), "eligible": len(remaining), "selected": selected_count, "ordered_exclusions": losses,
            "partition_check": sum(losses.values()) + selected_count == len(stats)}


def write_prepared(reference: str, matrix: np.ndarray, records: list[dict], selected: list[dict],
                   stats: list[dict], counts: dict, identity: dict, contract: Path, audit: dict, config: dict,
                   units: str, extra: dict | None = None, full_matrix: np.ndarray | None = None) -> None:
    destination = HERE / "data" / reference
    destination.mkdir(parents=True, exist_ok=True)
    np.save(destination / "expression.npy", np.asarray(matrix, dtype=np.float32), allow_pickle=False)
    write_json(destination / "records.json", records)
    write_json(destination / "selected_genes.json", selected)
    # Full exclusions and original identities remain local; aggregates are versioned.
    write_json(destination / "gene_eligibility.json", stats)
    files = {name: file_hash(destination / name) for name in ("expression.npy", "records.json", "selected_genes.json", "gene_eligibility.json")}
    if full_matrix is not None:
        np.save(destination / "all_gene_expression.npy", np.asarray(full_matrix, dtype=np.float32), allow_pickle=False)
        files["all_gene_expression.npy"] = file_hash(destination / "all_gene_expression.npy")
    audit_path = contract.parent / f"{reference}_audit.json"
    source_bindings = {str(path.relative_to(ROOT)): file_hash(path) for path in (contract, audit_path, contract.parent / "eligibility_contract.json")}
    source_bindings.update({str((contract.parent / name).relative_to(ROOT)): digest for name, digest in audit["producer_sha256"].items()})
    if reference == "gtex":
        source_bindings[str((contract.parent / "data" / "audit" / "gtex_samples.tsv").relative_to(ROOT))] = audit["result"]["sample_manifest_sha256"]
    if audit["model_input"]["matrix_key"] == "hlca_core_raw":
        source_bindings[str((contract.parent / "acquisition_amendment.json").relative_to(ROOT))] = audit["model_input"]["amendment_sha256"]
        ranges_path = (contract.parent / audit["model_input"]["source_ranges_manifest_path"]).resolve()
        source_bindings[str(ranges_path.relative_to(ROOT))] = audit["model_input"]["source_ranges_manifest_sha256"]
    manifest = {"schema": "normal-reference-prepared-v1", "reference_id": reference, "normal_only": True,
                "source_contract_sha256": file_hash(contract), "source_audit_sha256": file_hash(audit_path), "source_audit": str(audit_path.relative_to(ROOT)),
                "source_bindings": source_bindings, "audited_matrix_input": audit["model_input"],
                "source_contract": str(contract.relative_to(ROOT)), "config_sha256": file_hash(CONFIG), "counts": counts,
                "features": {**identity, **feature_exclusions(stats, len(selected), config), "selection_rule": config["features"]["rank"]},
                "expression_units": units, "files": files, "extra": extra or {},
                "preparation_producers": {str(Path(__file__).relative_to(ROOT)): file_hash(Path(__file__)),
                                          "normal_reference/model/core.py": file_hash(HERE / "core.py")}}
    write_json(destination / "prepared_manifest.json", manifest)
    print(json.dumps({"reference": reference, "prepared": True, "counts": counts, "features": manifest["features"]}), flush=True)


def prepare_gtex(contract: Path, config: dict, data_path: Path, audit: dict) -> None:
    samples = read_tsv(contract.parent / "data" / "audit" / "gtex_samples.tsv")
    # Explicit source-specific metadata mapping; unknown tissue rows fail closed.
    for row in samples:
        row["class_label"] = row["tissue"]
        row["study_id"] = "GTEx_V11"
    # GTEx transformed cell lines are reference populations distinct from tissues;
    # excluded from the body-wide tissue map rather than called normal organs.
    excluded_labels = set(config["source_eligibility"]["gtex_excluded_labels"])
    excluded_cell_lines = [row for row in samples if row["class_label"] in excluded_labels]
    included_positions = [i for i, row in enumerate(samples) if row["class_label"] not in excluded_labels]
    included = [samples[i] for i in included_positions]
    records, group_indices, counts = group_records(included, "gtex", config)
    counts["excluded_cell_line_samples"] = len(excluded_cell_lines)
    train_indices = np.array([i for i, row in enumerate(records) if row["role"] == "train" and row["class_label"] in counts["supported_classes"]])
    weights = class_weights([records[i] for i in train_indices])
    sizes = np.bincount(group_indices)
    source_ids, symbols = [], []
    def rows():
        with gzip.open(data_path, "rt", encoding="utf-8") as handle:
            if handle.readline().strip() != "#1.2":
                raise ValueError("Unexpected GTEx GCT version")
            dimensions = tuple(map(int, handle.readline().split()))
            header = handle.readline().rstrip("\n").split("\t")
            if header[:2] != ["Name", "Description"] or header[2:] != [r["sample_id"] for r in samples]:
                raise ValueError("GTEx sample order differs from source-audited metadata")
            if dimensions[1] != len(samples):
                raise ValueError("GTEx declared dimensions mismatch")
            row_count = 0
            for line in handle:
                gene, symbol, expression = line.rstrip("\n").split("\t", 2)
                values = np.fromstring(expression, sep="\t", dtype=np.float64)
                if len(values) != len(samples) or np.any(values < 0) or not np.isfinite(values).all():
                    raise ValueError("Invalid GTEx abundance row")
                profile = np.bincount(group_indices, weights=values[included_positions], minlength=len(records)) / sizes
                yield gene, symbol, np.log2(profile + 1)
                row_count += 1
            if row_count != dimensions[0]:
                raise ValueError("GTEx observed gene rows mismatch")
    stats = []
    for row_number, (gene, symbol, values) in enumerate(rows()):
        mean, variance, missing, positive = weighted_statistics(values[train_indices, None], weights)
        source_ids.append(gene)
        symbols.append(symbol)
        stats.append({"source_row": row_number, "source_id": gene, "symbol": symbol, "training_mean": float(mean[0]),
                      "training_variance": float(variance[0]), "training_missing_fraction": float(missing[0]), "training_positive_fraction": float(positive[0])})
        if row_number % 10000 == 0:
            print(json.dumps({"reference": "gtex", "stage": "training-only-feature-pass", "rows": row_number}), flush=True)
    stable_ids, keep, identity = identity_mask(source_ids)
    for i, row in enumerate(stats):
        row.update(stable_id=stable_ids[i], identity_eligible=bool(keep[i]))
    selected_indices = choose_features(stats, config)
    position = {source_row: column for column, source_row in enumerate(selected_indices)}
    matrix = np.empty((len(records), len(selected_indices)), dtype=np.float32)
    for row_number, (_gene, _symbol, values) in enumerate(rows()):
        if row_number in position:
            matrix[:, position[row_number]] = values
    selected = [stats[i] for i in selected_indices]
    write_prepared("gtex", matrix, records, selected, stats, counts, identity, contract, audit, config, "log2(TPM+1)",
                   {"tissue_profile_caveat": "Non-diseased sampled tissues include cell composition and collection/terminal-state effects; donors are not certified entirely healthy", "cell_line_exclusion": "Exact source Cells - Cultured fibroblasts and Cells - EBV-transformed lymphocytes excluded", "study_transfer": "GTEx single study; external leave-study transfer unavailable"})


def read_h5_strings(group, key):
    node = group[key]
    if hasattr(node, "keys") and "codes" in node and "categories" in node:
        category_node = node["categories"]
        categories = np.asarray(category_node.asstr()[:] if category_node.dtype.kind in ("O", "S", "U") else category_node[:].astype(str))
        codes = np.asarray(node["codes"][:])
        return np.array([categories[i] if i >= 0 else "" for i in codes], dtype=object)
    return np.asarray(node.asstr()[:] if node.dtype.kind in ("O", "S", "U") else node[:].astype(str), dtype=object)


def prepare_hlca(contract: Path, config: dict, data_path: Path, audit: dict) -> None:
    sys.path.insert(0, str(contract.parent / ".runtime" / "packages"))
    import h5py
    from scipy.sparse import csr_matrix
    with h5py.File(data_path, "r") as h5:
        obs = h5["obs"]
        class_key = config["profiles"]["hcl_reference_annotation"]
        classes = read_h5_strings(obs, class_key)
        donors = read_h5_strings(obs, "donor_id")
        studies = read_h5_strings(obs, "study")
        lung_condition = read_h5_strings(obs, "lung_condition")
        subject_type = read_h5_strings(obs, "subject_type")
        covariate_fields = {"sex": "sex", "age": "age_or_mean_of_age_range", "smoking": "smoking_status", "tissue_sampling_method": "tissue_sampling_method"}
        optional = {canonical: read_h5_strings(obs, source) for canonical, source in covariate_fields.items() if source in obs}
        optional.update(subject_type=subject_type, lung_condition=lung_condition)
        cells = len(donors)
        # The audited healthy-core raw layer is required. X is not substituted.
        if "raw" not in h5 or "X" not in h5["raw"]:
            raise ValueError("HLCA raw counts missing; SCRAN-normalized X cannot replace them")
        raw = h5["raw"]
        x = raw["X"]
        encoding = x.attrs.get("encoding-type", "")
        if isinstance(encoding, bytes):
            encoding = encoding.decode()
        if encoding != "csr_matrix":
            raise ValueError("Expected audited HLCA raw.X CSR representation")
        var = raw["var"]
        index_key = var.attrs.get("_index", "_index")
        if isinstance(index_key, bytes):
            index_key = index_key.decode()
        gene_ids = read_h5_strings(var, index_key).tolist()
        symbol_key = next((key for key in ("feature_name", "gene_symbols", "gene_symbol") if key in var), None)
        symbols = read_h5_strings(var, symbol_key).tolist() if symbol_key else [""] * len(gene_ids)
        stable_ids, keep, identity = identity_mask(gene_ids)
        adjacent_donors = set(donor for donor, condition in zip(donors, lung_condition) if condition == "Healthy (tumor adjacent)")
        nonhealthy_donors = set(donor for donor, condition in zip(donors, lung_condition) if condition != "Healthy")
        healthy = np.array([condition == "Healthy" and donor not in nonhealthy_donors for donor, condition in zip(donors, lung_condition)])
        if len(set(donors[healthy])) != 104 or int(healthy.sum()) != 523962:
            raise ValueError("HLCA primary source eligibility differs from pre-fit audited population")
        valid_annotation = np.array([bool(donor) and bool(label) and label.lower() not in ("nan", "none", "unassigned", "unknown") for donor, label in zip(donors, classes)])
        valid = healthy & valid_annotation
        units = Counter((donor, label) for donor, label, eligible in zip(donors, classes, valid) if eligible)
        minimum = config["profiles"]["hcl_minimum_cells_per_donor_class"]
        valid &= np.array([units[(donor, label)] >= minimum for donor, label in zip(donors, classes)])
        samples = [{"donor_id": donors[i], "class_label": classes[i], "study_id": studies[i], **{key: values[i] for key, values in optional.items()}} for i in np.where(valid)[0]]
        records, group_indices, counts = group_records(samples, "hlca", config)
        source_healthy_classes = sorted(set(classes[healthy & valid_annotation]))
        counts["unsupported_classes"] = sorted(set(source_healthy_classes) - set(counts["supported_classes"]))
        counts.update(primary_class_count=len(source_healthy_classes), unsupported_class_count=len(counts["unsupported_classes"]))
        for label in source_healthy_classes:
            counts["training_donors_per_class"].setdefault(label, 0)
        counts["primary_class_coverage"] = [{"class_label": label, "source_healthy_cells": int(np.sum(healthy & (classes == label))),
                                             "source_healthy_donors": len(set(donors[healthy & (classes == label)])),
                                             "eligible_donor_class_profiles": sum(row["class_label"] == label for row in records),
                                             "training_donors": counts["training_donors_per_class"][label]} for label in source_healthy_classes]
        cell_to_group = np.full(cells, -1, dtype=np.int32)
        cell_to_group[valid] = group_indices
        summed = np.zeros((len(records), len(gene_ids)), dtype=np.float64)
        indptr = x["indptr"]
        checked_nonzero = 0
        for start in range(0, cells, 4096):
            stop = min(cells, start + 4096)
            pointers = np.asarray(indptr[start:stop + 1])
            begin, end = int(pointers[0]), int(pointers[-1])
            values = np.asarray(x["data"][begin:end])
            indices = np.asarray(x["indices"][begin:end])
            if not np.isfinite(values).all() or np.any(values < 0) or not np.allclose(values, np.rint(values), atol=1e-6, rtol=0):
                raise ValueError("HLCA raw.X is not nonnegative integer counts")
            checked_nonzero += len(values)
            block = csr_matrix((values, indices, pointers - begin), shape=(stop - start, len(gene_ids)))
            groups = cell_to_group[start:stop]
            retained = np.where(groups >= 0)[0]
            aggregation = csr_matrix((np.ones(len(retained)), (groups[retained], retained)), shape=(len(records), stop - start))
            summed += (aggregation @ block).toarray()
            if start % 40960 == 0:
                print(json.dumps({"reference": "hlca", "stage": "raw-count-pseudobulk", "cells": stop}), flush=True)
        library = summed.sum(axis=1)
        if np.any(library <= 0):
            raise ValueError("Zero HLCA pseudobulk library")
        expression = np.log2(summed / library[:, None] * 1_000_000 + 1)
        train_indices = np.array([i for i, row in enumerate(records) if row["role"] == "train" and row["class_label"] in counts["supported_classes"]])
        mean, variance, missing, positive = weighted_statistics(expression[train_indices], class_weights([records[i] for i in train_indices]))
        stats = [{"source_row": i, "source_id": gene_ids[i], "stable_id": stable_ids[i], "symbol": symbols[i], "identity_eligible": bool(keep[i]),
                  "training_mean": float(mean[i]), "training_variance": float(variance[i]), "training_missing_fraction": float(missing[i]), "training_positive_fraction": float(positive[i])} for i in range(len(gene_ids))]
        selected_indices = choose_features(stats, config)
        counts.update(source_cells=cells, source_core_donors=len(set(donors)), healthy_source_donors=len(set(donors[healthy])),
                      healthy_donors_without_eligible_profile=len(set(donors[healthy]) - set(row["donor_id"] for row in records)),
                      healthy_source_cells=int(healthy.sum()), adjacent_source_cells=int(np.sum(lung_condition == "Healthy (tumor adjacent)")),
                      whole_adjacent_donors_excluded=len(adjacent_donors), nonhealthy_or_adjacent_donor_cells_excluded=int((~healthy).sum()),
                      whole_nonhealthy_donors_excluded=len(nonhealthy_donors),
                      missing_annotation_healthy_cells=int((healthy & ~valid_annotation).sum()),
                      undersized_donor_class_healthy_cells=int((healthy & valid_annotation & ~valid).sum()),
                      healthy_subject_type_counts=dict(Counter(str(value) for value in subject_type[healthy])),
                      healthy_subject_type_donors={str(value): len(set(donors[healthy & (subject_type == value)])) for value in sorted(set(subject_type[healthy]))},
                      excluded_cells=int((~valid).sum()), minimum_cells_per_profile=minimum,
                      raw_nonzero_values_verified=checked_nonzero, source_records=int(valid.sum()))
        write_prepared("hlca", expression[:, selected_indices], records, [stats[i] for i in selected_indices], stats, counts, identity, contract, audit, config,
                       "log2(donor-cell-class raw-count CPM+1)", {"annotation": class_key, "minimum_cells_per_profile": minimum,
                       "count_aggregation": "sum source raw.X counts by verified donor and broad annotated cell class; CPM over full raw gene library, then log2(x+1)",
                       "covariate_source_fields": covariate_fields,
                       "healthy_eligibility": "Exact lung_condition Healthy; every donor with any non-Healthy or missing condition excluded entirely before donor split/feature selection; adjacent records not projected",
                       "source_normalization": "The source integrated embedding does not batch-correct these counts", "cross_modality": "Distinct from bulk TPM; direct GTEx/HLCA/tumor numerical concatenation forbidden"}, full_matrix=expression)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", required=True, choices=["gtex", "hlca"])
    parser.add_argument("--contract", type=Path, default=ROOT / "normal_reference" / "source" / "input_contract.json")
    args = parser.parse_args()
    config = json.loads(CONFIG.read_text())
    _contract, audit, data_path = paths_for_source(args.reference, args.contract)
    from .freeze import ensure_freeze
    ensure_freeze(args.contract)
    if (HERE / "data" / args.reference / "prepared_manifest.json").exists():
        raise ValueError("Prepared reference exists; use a deliberately new version rather than overwrite")
    (prepare_gtex if args.reference == "gtex" else prepare_hlca)(args.contract, config, data_path, audit)


if __name__ == "__main__":
    main()
