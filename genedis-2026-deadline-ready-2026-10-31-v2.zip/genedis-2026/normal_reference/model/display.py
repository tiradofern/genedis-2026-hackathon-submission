"""Fail-closed aggregate display loader; never exposes individual donor files."""
import json
from pathlib import Path

from .core import file_hash


def load_verified_report(project_root: Path) -> dict:
    root = Path(project_root).resolve()
    manifest_path = root / "normal_reference" / "model" / "output" / "display_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schema") != "normal-reference-display-bindings-v1":
        raise ValueError("Unsupported normal-reference display bindings")
    expected_report = "normal_reference/model/aggregate_report.json"
    if expected_report not in manifest.get("files", {}):
        raise ValueError("Normal-reference aggregate missing from display bindings")
    for relative, digest in manifest["files"].items():
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or file_hash(path) != digest:
            raise ValueError(f"Normal-reference display artifact stale or changed: {relative}")
    report = json.loads((root / expected_report).read_text(encoding="utf-8"))
    if report.get("schema") != "normal-reference-validation-v1" or {r.get("reference_id") for r in report.get("references", [])} != {"gtex", "hlca"}:
        raise ValueError("Unsupported or wrong-source normal-reference report")
    return report
