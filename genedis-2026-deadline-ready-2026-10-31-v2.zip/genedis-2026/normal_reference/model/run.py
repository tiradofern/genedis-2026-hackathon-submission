"""Fit, lock, calibrate, then evaluate a normal-only reference exactly once.

The development record is written before calibration or test model assessment.
Source integrity/eligibility scans can read all bytes without fitting to them.
The empirical gate measures internal consistency, not biological or
clinical adequacy. Tumor projection remains independently blocked.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import datetime as dt
import json
from pathlib import Path

import numpy as np
from scipy.spatial.distance import cdist

from .core import (ROLES, donor_intervals, donor_maximum, file_hash, finite_quantile,
                   fit_transform, metrics, profile_stability, project,
                   validate_records, write_json)
from .prepare import CONFIG, HERE, ROOT, paths_for_source
from .transfer import leave_study_out
from .stability import full_training_stability


def projection(x, model, manifest, config, threshold=None):
    return project(x, model, units=manifest["expression_units"], expected_units=manifest["expression_units"],
                   missing_limit=config["rejection"]["maximum_missing_selected_gene_fraction"], threshold=threshold)


def verified_prepared(reference):
    directory = HERE / "data" / reference
    manifest_path = directory / "prepared_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    if manifest.get("schema") != "normal-reference-prepared-v1" or manifest.get("reference_id") != reference or manifest.get("normal_only") is not True:
        raise ValueError("Wrong source/reference or non-normal prepared matrix")
    if manifest["config_sha256"] != file_hash(CONFIG):
        raise ValueError("Prepared matrix uses a stale configuration")
    contract = ROOT / manifest["source_contract"]
    if file_hash(contract) != manifest["source_contract_sha256"] or file_hash(ROOT / manifest["source_audit"]) != manifest["source_audit_sha256"]:
        raise ValueError("Stale source contract/audit")
    for relative, digest in manifest["source_bindings"].items():
        if file_hash(ROOT / relative) != digest:
            raise ValueError(f"Source metadata/producer changed since preparation: {relative}")
    paths_for_source(reference, contract)
    for name, digest in manifest["files"].items():
        if file_hash(directory / name) != digest:
            raise ValueError(f"Prepared artifact changed: {name}")
    for name, digest in manifest["preparation_producers"].items():
        if file_hash(ROOT / name) != digest:
            raise ValueError(f"Preparation producer changed after preparing: {name}")
    records = json.loads((directory / "records.json").read_text())
    genes = json.loads((directory / "selected_genes.json").read_text())
    validate_records(records)
    matrix = np.load(directory / "expression.npy", mmap_mode="r", allow_pickle=False)
    if matrix.shape != (len(records), len(genes)):
        raise ValueError("Prepared matrix dimensions differ from manifest")
    return directory, manifest, records, genes, matrix


def indices_for(records, role, labels=None):
    return np.array([i for i, record in enumerate(records) if record["role"] == role and (labels is None or record["class_label"] in labels)], dtype=int)


def gene_permutations(x, seed):
    rng = np.random.default_rng(seed)
    return np.array([row[rng.permutation(len(row))] for row in x])


def rejection_interval(records, rejected, seed, resamples):
    by_donor = defaultdict(list)
    for record, value in zip(records, rejected):
        by_donor[record["donor_id"]].append(float(value))
    donor_values = np.array([np.mean(by_donor[key]) for key in sorted(by_donor)])
    rng = np.random.default_rng(seed)
    draws = np.mean(rng.choice(donor_values, (resamples, len(donor_values)), replace=True), axis=1)
    return {"donors": len(donor_values), "profiles": len(records), "donor_mean_rejection": float(donor_values.mean()),
            "interval": np.quantile(draws, [.025, .975]).tolist(), "method": "whole-donor bootstrap of within-donor rejection fraction"}


def develop(x, records, train_projection, train_records, model, manifest, config, calibration_donor_count):
    if not any(row["class_label"] in model["labels"] for row in records):
        raise ValueError("No represented class in independent normal development donors")
    mapped = projection(x, model, manifest, config)
    negatives = projection(gene_permutations(x, config["seed"] + 101), model, manifest, config)
    training_scores = donor_maximum(train_projection["score"], train_records)
    candidates = []
    for quantile in config["rejection"]["development_quantile_candidates"]:
        # Calibration donor count is metadata, never opened expression values.
        if np.ceil((calibration_donor_count + 1) * quantile) > calibration_donor_count:
            continue
        threshold = finite_quantile(training_scores, quantile)
        assigned = mapped["assigned"].copy()
        assigned[mapped["score"] > threshold] = "unassigned"
        normal = metrics(records, assigned, model["labels"])
        rejected = negatives["score"] > threshold
        rejection = rejection_interval(records, rejected, config["seed"] + 102, config["validation"]["interval_resamples"])
        objective = (normal["macro_recall"] + rejection["donor_mean_rejection"]) / 2
        candidates.append({"quantile": quantile, "development_threshold_from_training": threshold,
                           "normal_metrics": normal, "negative_rejection": rejection, "objective": objective})
    if not candidates:
        raise ValueError("Insufficient independent calibration donors for every prespecified quantile")
    best = max(candidates, key=lambda row: (row["objective"], row["normal_metrics"]["coverage"], -row["quantile"]))
    assigned = mapped["assigned"].copy()
    assigned[mapped["score"] > best["development_threshold_from_training"]] = "unassigned"
    intervals = donor_intervals(records, assigned, model["labels"], config["validation"]["interval_resamples"], config["seed"] + 103)
    return {"stage": "development_locked_before_calibration_and_test_assessment", "locked_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            "selection_scope": "normal development only; training-defined feature universe and PCA unchanged",
            "quantile_candidates": candidates, "selected_quantile": best["quantile"],
            "development_metrics": best["normal_metrics"], "development_intervals": intervals,
            "normal_macro_recall_lower_gate": intervals["intervals"]["macro_recall"][0],
            "gene_permuted_rejection_lower_gate": best["negative_rejection"]["interval"][0],
            "gate_interpretation": "Data-derived internal normal-reference consistency targets, not investigator-approved biological or clinical accuracy standards"}


def leave_class_out(mapped, model, records, threshold, seed, resamples):
    labels = model["labels"]
    scores = []
    known_records = []
    nearest_alternative = []
    for i, record in enumerate(records):
        if record["class_label"] not in labels:
            continue
        row = mapped["distances"][i].copy()
        row[labels.index(record["class_label"])] = np.inf
        alternate = int(np.argmin(row))
        scores.append(row[alternate] / model["radii"][alternate])
        nearest_alternative.append(labels[alternate])
        known_records.append(record)
    rejection = rejection_interval(known_records, np.array(scores) > threshold, seed, resamples)
    rejection.update(method="Withhold true class centroid from each held-out normal query, retain frozen transform and other classes; descriptive near-reference negative control",
                     limitation="Not a full leave-population-out refit: PCA/features still trained with that class; related tissues can remain similar and need not be rejected")
    return rejection


def technical_audit(records, predictions, labels, mapped, model):
    """Donor/class descriptive strata; no causal adjustment or false batch claim."""
    output = {}
    for covariate in ("sex", "age_bracket", "age", "smoking", "hardy", "rin", "ischemic_time", "tissue_sampling_method", "subject_type", "lung_condition", "autolysis", "center", "rna_extraction_batch", "gene_expression_batch", "vendor_qc_fail", "study_id"):
        groups = defaultdict(list)
        for i, record in enumerate(records):
            value = record.get("study_id") if covariate == "study_id" else record.get("covariates", {}).get(covariate)
            if covariate in ("rin", "ischemic_time", "age") and value not in (None, "multiple"):
                try:
                    number = float(value)
                    # Fixed descriptive bins; no model tuning or inferred values.
                    value = str(int(number // (2 if covariate == "rin" else 20)) * (2 if covariate == "rin" else 20)) + "+"
                except (TypeError, ValueError):
                    pass
            groups[str(value) if value else "unavailable"].append(i)
        strata = []
        for value, positions in sorted(groups.items()):
            subset = [records[i] for i in positions]
            result = metrics(subset, [predictions[i] for i in positions], labels)
            within_class = []
            for class_index, label in enumerate(labels):
                class_positions = [i for i in positions if records[i]["class_label"] == label]
                donors = len(set(records[i]["donor_id"] for i in class_positions))
                if donors < 3:
                    continue
                offset = np.linalg.norm(mapped["coordinates"][class_positions].mean(axis=0) - model["centroids"][class_index])
                within_class.append({"class_label": label, "donors": donors, "centroid_offset": float(offset)})
            strata.append({"value": value, "donors": len(set(r["donor_id"] for r in subset)), "profiles": len(subset),
                           "macro_recall": result["macro_recall"], "coverage": result["coverage"],
                           "mean_assigned_distance_rejection_score": float(np.mean(mapped["score"][positions])),
                           "within_class_geometry": {"eligible_classes_at_least_three_donors": len(within_class),
                                                     "median_subgroup_centroid_offset": float(np.median([row["centroid_offset"] for row in within_class])) if within_class else None,
                                                     "largest_offset_classes": sorted(within_class, key=lambda row: -row["centroid_offset"])[:3]}})
        output[covariate] = {"status": "descriptive_only", "strata": strata, "geometry_units": "Unitless Euclidean retained-PCA distance from each source-class normal-training centroid",
                             "limitation": "Direct observed source/batch/quality stratum geometry and performance; tissue/class composition and covariates remain entangled; no causal adjusted effect or batch removal is claimed"}
    return output


def source_transfer_status(records):
    study_donors = defaultdict(set)
    class_study_donors = defaultdict(lambda: defaultdict(set))
    for row in records:
        for study in row.get("study_ids", [row["study_id"]]):
            study_donors[study].add(row["donor_id"])
            class_study_donors[row["class_label"]][study].add(row["donor_id"])
    if len(study_donors) == 1:
        return {"status": "untestable_single_source_study", "studies": len(study_donors), "reason": "Internal donor holdout cannot establish transfer to independent processing/studies"}
    return {"status": "pending_full_leave_study_out_refits", "studies": len(study_donors),
            "study_donor_counts": {study: len(donors) for study, donors in sorted(study_donors.items())},
            "shared_classes_by_study": {study: sum(len(mapping.get(study, set())) >= 2 and len(set().union(*(donors for other, donors in mapping.items() if other != study))) >= 2
                                                   for mapping in class_study_donors.values()) for study in study_donors},
            "reason": "Ordinary donor holdout mixes source studies; full independent-study refits required before transfer claims"}


def run_reference(reference):
    directory, manifest, records, genes, matrix = verified_prepared(reference)
    from .freeze import ensure_freeze
    ensure_freeze(ROOT / manifest["source_contract"])
    config = json.loads(CONFIG.read_text())
    output = directory / "fit"
    if (output / "validation.json").exists() or (output / "development_lock.json").exists():
        raise ValueError("A development/test result already exists; use a deliberately versioned reference rather than reopen/refit")
    output.mkdir(parents=True, exist_ok=True)
    supported = manifest["counts"]["supported_classes"]
    train_positions = indices_for(records, "train", supported)
    train_records = [records[i] for i in train_positions]
    x_train = np.array(matrix[train_positions], dtype=np.float64)
    print(json.dumps({"reference": reference, "stage": "normal-training-fit", "profiles": len(train_records), "genes": len(genes)}), flush=True)
    model = fit_transform(x_train, train_records, config)
    labels = model["labels"]
    np.savez(output / "model.npz", **{key: value for key, value in model.items() if key != "labels"})
    write_json(output / "model_metadata.json", {"labels": labels, "expression_units": manifest["expression_units"], "prepared_manifest_sha256": file_hash(directory / "prepared_manifest.json"),
                                               "config_sha256": file_hash(CONFIG), "model_sha256": file_hash(output / "model.npz"),
                                               "producer_sha256": {str(p.relative_to(ROOT)): file_hash(p) for p in (HERE / "core.py", HERE / "run.py", HERE / "prepare.py", HERE / "display.py", HERE / "transfer.py", HERE / "stability.py", HERE / "freeze.py")}})
    training_mapped = projection(x_train, model, manifest, config)
    development_positions = indices_for(records, "development")
    development_records = [records[i] for i in development_positions]
    x_development = np.array(matrix[development_positions], dtype=np.float64)
    calibration_donors = len(set(r["donor_id"] for r in records if r["role"] == "calibration" and r["class_label"] in labels))
    lock = develop(x_development, development_records, training_mapped, train_records, model, manifest, config, calibration_donors)
    lock.update(model_sha256=file_hash(output / "model.npz"), prepared_manifest_sha256=file_hash(directory / "prepared_manifest.json"), config_sha256=file_hash(CONFIG))
    write_json(output / "development_lock.json", lock)
    print(json.dumps({"reference": reference, "stage": "development-locked", "quantile": lock["selected_quantile"], "normal_recall_gate": lock["normal_macro_recall_lower_gate"], "negative_rejection_gate": lock["gene_permuted_rejection_lower_gate"]}), flush=True)
    # Calibration values first enter model assessment after the numerical lock.
    calibration_positions = indices_for(records, "calibration", labels)
    calibration_records = [records[i] for i in calibration_positions]
    calibration_mapped = projection(np.array(matrix[calibration_positions], dtype=np.float64), model, manifest, config)
    scores = donor_maximum(calibration_mapped["score"], calibration_records)
    threshold = finite_quantile(scores, lock["selected_quantile"])
    calibration = {"donors": len(scores), "profiles": len(calibration_records), "threshold": threshold,
                   "rejection_quantile": lock["selected_quantile"], "method": config["rejection"]["calibration"],
                   "development_lock_sha256": file_hash(output / "development_lock.json"),
                   "coverage_scope": "Donor maximum over available normal profiles, under donor exchangeability; tissue/study availability shifts can violate transport"}
    write_json(output / "calibration.json", calibration)
    # Test values first enter model assessment after development/calibration.
    test_positions = indices_for(records, "test")
    test_records = [records[i] for i in test_positions]
    x_test = np.array(matrix[test_positions], dtype=np.float64)
    mapped = projection(x_test, model, manifest, config, threshold)
    measured = metrics(test_records, mapped["assigned"], labels)
    intervals = donor_intervals(test_records, mapped["assigned"], labels, config["validation"]["interval_resamples"], config["seed"] + 201)
    permuted = projection(gene_permutations(x_test, config["seed"] + 202), model, manifest, config, threshold)
    negative = rejection_interval(test_records, permuted["assigned"] == "unassigned", config["seed"] + 203, config["validation"]["interval_resamples"])
    rng = np.random.default_rng(config["seed"] + 204)
    null = []
    for _ in range(100):
        remapping = dict(zip(labels, rng.permutation(labels)))
        predictions = [remapping.get(value, "unassigned") for value in mapped["assigned"]]
        null.append(metrics(test_records, predictions, labels)["macro_recall"])
    null_upper = float(np.quantile(null, .95))
    gates = {"normal_development_consistency": measured["macro_recall"] >= lock["normal_macro_recall_lower_gate"],
             "negative_control_development_consistency": negative["donor_mean_rejection"] >= lock["gene_permuted_rejection_lower_gate"],
             "normal_recall_interval_above_label_null": intervals["intervals"]["macro_recall"][0] > null_upper}
    per_class = [{"class_label": label, "train_donors": sum(r["class_label"] == label for r in train_records),
                  "status": "fitted_supported_class" if any(r["class_label"] == label for r in test_records) else "fitted_unvalidated_no_test_donors",
                  "test_donors": len(set(r["donor_id"] for r in test_records if r["class_label"] == label)),
                  "test_profiles": sum(r["class_label"] == label for r in test_records), "recall": measured["per_class_recall"][i],
                  "recall_interval": intervals["intervals"]["per_class_recall"][i],
                  "claim": ("untested; no held-out eligible donors" if not any(r["class_label"] == label for r in test_records) else
                            "descriptive only; fewer than five independent test donors" if sum(r["class_label"] == label for r in test_records) < 5 else "internal held-out donors only")} for i, label in enumerate(labels)]
    for label in manifest["counts"]["unsupported_classes"]:
        positions = [i for i, row in enumerate(test_records) if row["class_label"] == label]
        subset = [test_records[i] for i in positions]
        rejected = np.array([mapped["assigned"][i] == "unassigned" for i in positions])
        assignment_counts = Counter(str(mapped["assigned"][i]) for i in positions if mapped["assigned"][i] != "unassigned")
        rejection = rejection_interval(subset, rejected, config["seed"] + 211, config["validation"]["interval_resamples"]) if subset else None
        donors = len(set(row["donor_id"] for row in subset))
        per_class.append({"class_label": label, "status": "untrained_insufficient_training_donors", "reason": "Fewer than five independent training donors under frozen eligibility rule",
                          "train_donors": manifest["counts"]["training_donors_per_class"].get(label, 0), "test_donors": donors, "test_profiles": len(subset),
                          "recall": None, "recall_interval": None, "rejected_profiles": int(rejected.sum()), "false_assignment_profiles": len(subset) - int(rejected.sum()),
                          "accepted_as_classes": dict(sorted(assignment_counts.items())), "rejection": rejection,
                          "claim": "unvalidated population; descriptive rejection only" + ("; fewer than five test donors" if donors < 5 else "")})
    source_class_coverage = {row["class_label"]: row for row in manifest["counts"].get("primary_class_coverage", [])}
    for row in per_class:
        source_coverage = source_class_coverage.get(row["class_label"], {})
        row["source_primary_donors"] = source_coverage.get("source_healthy_donors", len(set(record["donor_id"] for record in records if record["class_label"] == row["class_label"])))
        row["source_primary_cells"] = source_coverage.get("source_healthy_cells")
        row["eligible_profiles_all_roles"] = sum(record["class_label"] == row["class_label"] for record in records)
        row["test_denominator_scope"] = "Eligible donor/class profiles after all source and minimum-cell rules; source donors/cells alone do not establish eligible pseudobulk coverage"
    sensitivity = []
    for fraction in config["validation"]["missing_gene_sensitivity_fractions"]:
        rng = np.random.default_rng(config["seed"] + int(fraction * 10000))
        missing = x_test.copy()
        columns = rng.choice(len(genes), max(1, int(np.ceil(len(genes) * fraction))), replace=False)
        missing[:, columns] = np.nan
        projected = projection(missing, model, manifest, config, threshold)
        sensitivity.append({"masked_fraction": fraction, "masked_genes": len(columns), "feature_coverage": 1 - len(columns) / len(genes),
                            "metrics": metrics(test_records, projected["assigned"], labels), "missingness_guard_rejected_profiles": int(projected["missing_rejected"].sum())})
    print(json.dumps({"reference": reference, "stage": "normal-test-opened", "macro_recall": measured["macro_recall"], "coverage": measured["coverage"], "gate": gates}), flush=True)
    stability = profile_stability(model, train_records, config["validation"]["stability_resamples"], config["seed"] + 301, config["validation"]["neighborhood_k"])
    pipeline_stability = full_training_stability(directory, model, train_records, genes, config) if reference == "hlca" else {"status": "untested", "reason": "GTEx bootstrap refits centroids/hierarchy only in frozen features/PCA; no whole-feature-universe/PCA reselection claim"}
    distances = cdist(model["centroids"], model["centroids"])
    np.fill_diagonal(distances, np.inf)
    centroids = []
    standardized_centroids = np.array([np.mean((x_train[[r["class_label"] == label for r in train_records]] - model["mean"]) / model["scale"], axis=0) for label in labels])
    for i, label in enumerate(labels):
        features = np.argsort(standardized_centroids[i])[::-1][:10]
        centroids.append({"class_label": label, "train_donors": per_class[i]["train_donors"], "coordinates": model["centroids"][i, :2].tolist(),
                          "neighbors": [labels[j] for j in np.argsort(distances[i])[:3]],
                          "descriptive_profile_features": [{"stable_id": genes[j]["stable_id"], "symbol": genes[j]["symbol"], "mean_training_standardized_log_expression": float(standardized_centroids[i, j])} for j in features],
                          "feature_interpretation": "Descriptive selected-gene profile features; not coordinated programs, specificity biomarkers or function evidence"})
    validation = {"gate_passed": all(gates.values()), "gate_checks": gates, "gate_scope": "Internal normal-reference development-to-test consistency only; not biological/clinical validation or permission for incompatible tumor projection",
                  "metric_scope": config["reporting_scope"]["metrics"],
                  "macro_class_coverage": {"represented": len(labels), "development_observed": lock["development_metrics"]["observed_truth_class_count"],
                                           "test_observed": measured["observed_truth_class_count"], "test_untested_classes": measured["zero_truth_classes"],
                                           "limitation": "Each macro statistic averages its observed represented truth classes; donor-bootstrap replicates can omit rare classes. Different development/test class coverage limits the gate; zero-test populations remain untested"},
                  "metrics": measured, "donor_bootstrap_intervals": intervals, "per_class": per_class,
                  "confusion": {"labels": labels, "prediction_columns": labels + ["unassigned"], "matrix": measured["confusion"]},
                  "negative_controls": {"independent_within_profile_gene_permutation": negative,
                                        "leave_class_out": leave_class_out(mapped, model, test_records, threshold, config["seed"] + 205, config["validation"]["interval_resamples"]),
                                        "centroid_label_permutation_null": {"resamples": 100, "macro_recall_95th_percentile": null_upper, "interpretation": "Descriptive global class-label remapping comparator; not an independent study or formal donor permutation p-value"}},
                  "coverage_sensitivity": sensitivity, "development_lock_sha256": file_hash(output / "development_lock.json"), "calibration_sha256": file_hash(output / "calibration.json")}
    write_json(output / "test_predictions.json", [{"profile_id": row["profile_id"], "donor_id": row["donor_id"], "class_label": row["class_label"],
                "assigned": str(mapped["assigned"][i]), "score": float(mapped["score"][i]), "coordinates": mapped["coordinates"][i].tolist()} for i, row in enumerate(test_records)])
    write_json(output / "validation.json", validation)
    report = {"reference_id": reference, "reference_version": config["version"], "source_id": reference,
              "source_contract_sha256": manifest["source_contract_sha256"], "prepared_manifest_sha256": file_hash(directory / "prepared_manifest.json"),
              "model_sha256": file_hash(output / "model.npz"), "config_sha256": file_hash(CONFIG), "status": "normal_reference_gate_passed" if validation["gate_passed"] else "normal_reference_gate_failed",
              "counts": manifest["counts"], "units": {"source": manifest["expression_units"], "transform": manifest["expression_units"], "distance": "Unitless Euclidean distance in weighted normal-training PCA coordinates"},
              "features": manifest["features"], "dimensions": len(model["components"]), "explained_variance_fraction": model["variance_fraction"].tolist(),
              "centroids": centroids, "hierarchy": {"leaf_labels": labels, "linkage": stability["linkage"],
                                                    "branch_support": pipeline_stability["branch_support"] if reference == "hlca" else stability["branch_support"],
                                                    "bootstrap_scope": pipeline_stability["scope"] if reference == "hlca" else stability["scope"],
                                                    "root": "Display convention; no ancestral or temporal meaning"},
              "development_lock": lock, "calibration": calibration, "validation": validation, "stability": stability, "training_pipeline_stability": pipeline_stability,
              "technical_covariates": technical_audit(test_records, mapped["assigned"], labels, mapped, model), "leave_study_out": leave_study_out(directory, records, config, manifest, projection=projection, develop=develop),
              "limitations": ["Expression profiles, not coordinated programs, cellular fractions or ancestors", "GTEx stability is conditional on frozen features/PCA; HLCA additionally refits the full training pipeline in 100 donor resamples, without refitting calibration/test", "Source sampling and cell composition limit interpretation", "Macro metrics and gate condition on represented truth classes; unsupported populations remain separately unvalidated", "Distance rejection sees retained PCA space; departures in discarded components may be invisible; no general biological OOD detection is validated", "No claim of transport to bulk tumors or different source pipelines", "Repeated donor records across classes remain donor-blocked; class counts are not independent donor totals"],
              "source_preparation": manifest["extra"], "tumor_projection": {"status": "blocked_pending_comparable_RNA", "reason": "No tumors opened or projected; matched processing, linkage and normal validation are separate requirements"}}
    write_json(output / "aggregate_reference.json", report)
    completed_files = ("model.npz", "model_metadata.json", "development_lock.json", "calibration.json", "test_predictions.json", "validation.json", "aggregate_reference.json")
    write_json(output / "completed_fit_manifest.json", {"schema": "normal-reference-completed-fit-v1", "reference_id": reference,
                                                       "prepared_manifest_sha256": file_hash(directory / "prepared_manifest.json"),
                                                       "files": {name: file_hash(output / name) for name in completed_files}})
    print(json.dumps({"reference": reference, "stage": "complete", "gate_passed": validation["gate_passed"], "output": str(output / "aggregate_reference.json")}), flush=True)
    return report


def export_report():
    reports = []
    bindings = {"configs/normal_reference_v0_1.json": file_hash(CONFIG)}
    for source in ("gtex", "hlca"):
        directory = HERE / "data" / source
        output = directory / "fit"
        if not (output / "aggregate_reference.json").exists():
            reports.append({"reference_id": source, "status": "pending_audited_source_and_normal_fit", "centroids": [], "validation": None,
                            "tumor_projection": {"status": "blocked_pending_comparable_RNA", "reason": "Normal-only reference not yet complete; no compatible tumor projection established"}})
            continue
        metadata = json.loads((output / "model_metadata.json").read_text())
        completion_path = output / "completed_fit_manifest.json"
        completed = json.loads(completion_path.read_text())
        if completed.get("schema") != "normal-reference-completed-fit-v1" or completed.get("reference_id") != source or completed["prepared_manifest_sha256"] != file_hash(directory / "prepared_manifest.json"):
            raise ValueError("Wrong/stale completed normal-reference fit")
        for name, digest in completed["files"].items():
            if file_hash(output / name) != digest:
                raise ValueError(f"Completed fit output changed before export: {name}")
        if metadata["prepared_manifest_sha256"] != file_hash(directory / "prepared_manifest.json") or metadata["config_sha256"] != file_hash(CONFIG) or metadata["model_sha256"] != file_hash(output / "model.npz"):
            raise ValueError("Stale fitted model/preparation/configuration")
        for name, digest in metadata["producer_sha256"].items():
            if file_hash(ROOT / name) != digest:
                raise ValueError(f"Producer changed since model fit: {name}")
        prepared = json.loads((directory / "prepared_manifest.json").read_text())
        for name, digest in prepared["files"].items():
            if file_hash(directory / name) != digest:
                raise ValueError(f"Prepared source-derived artifact changed before export: {name}")
        for name, digest in prepared["source_bindings"].items():
            if file_hash(ROOT / name) != digest:
                raise ValueError(f"Source metadata/producer changed since preparation: {name}")
            # Include compact provenance and donor metadata, never full RNA bytes.
            bindings[name] = digest
        for path in (directory / "prepared_manifest.json", completion_path, output / "model.npz", output / "model_metadata.json", output / "development_lock.json", output / "calibration.json", output / "validation.json", output / "aggregate_reference.json"):
            bindings[str(path.relative_to(ROOT))] = file_hash(path)
        reports.append(json.loads((output / "aggregate_reference.json").read_text()))
    for path in (CONFIG, HERE / "core.py", HERE / "prepare.py", HERE / "run.py", HERE / "display.py", HERE / "transfer.py", HERE / "stability.py", HERE / "freeze.py", HERE / "freeze_manifest.json", ROOT / "normal_reference" / "source" / "input_contract.json", ROOT / "normal_reference" / "source" / "eligibility_contract.json"):
        if path.exists():
            bindings[str(path.relative_to(ROOT))] = file_hash(path)
    aggregate = HERE / "aggregate_report.json"
    write_json(aggregate, {"schema": "normal-reference-validation-v1", "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "references": reports,
                           "interpretation": "Separate normal-only similarity reference models; no tumor placements, ancestry or coordinated programs are established"})
    bindings[str(aggregate.relative_to(ROOT))] = file_hash(aggregate)
    write_json(HERE / "output" / "display_manifest.json", {"schema": "normal-reference-display-bindings-v1", "files": bindings})
    return aggregate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", choices=["gtex", "hlca"])
    parser.add_argument("--export-only", action="store_true")
    args = parser.parse_args()
    if not args.export_only:
        if not args.reference:
            parser.error("--reference required unless --export-only")
        run_reference(args.reference)
    print(json.dumps({"aggregate_report": str(export_report())}), flush=True)


if __name__ == "__main__":
    main()
