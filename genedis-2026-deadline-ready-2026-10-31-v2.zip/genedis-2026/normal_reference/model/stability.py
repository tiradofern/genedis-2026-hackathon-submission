"""Whole training-donor feature/PCA/profile bootstrap for bounded HLCA input."""
from __future__ import annotations

from collections import Counter, defaultdict
import json

import numpy as np
from scipy.spatial.distance import cdist

from .core import (class_weights, fit_transform, hierarchy, weighted_statistics)
from .prepare import choose_features


def full_training_stability(directory, model, training_records, selected_genes, config):
    full_path = directory / "all_gene_expression.npy"
    if not full_path.exists():
        raise ValueError("Full feature/PCA bootstrap requires the complete prepared normal gene universe")
    all_records = json.loads((directory / "records.json").read_text())
    original_positions = {row["profile_id"]: i for i, row in enumerate(all_records)}
    all_genes = json.loads((directory / "gene_eligibility.json").read_text())
    matrix = np.load(full_path, mmap_mode="r", allow_pickle=False)
    donor_rows = defaultdict(list)
    for record in training_records:
        donor_rows[record["donor_id"]].append(record)
    donors = sorted(donor_rows)
    labels = model["labels"]
    label_index = {label: i for i, label in enumerate(labels)}
    k = min(config["validation"]["neighborhood_k"], len(labels) - 1)
    original_distance = cdist(model["centroids"], model["centroids"])
    np.fill_diagonal(original_distance, np.inf)
    neighbors = [{labels[j] for j in np.argsort(row)[:k]} for row in original_distance]
    _tree, original_clades = hierarchy(model["centroids"])
    clade_counts = Counter()
    feature_jaccard = []
    overlaps = []
    class_presence = Counter()
    resamples = config["validation"]["stability_resamples"]
    failures = Counter()
    missing_class_resamples = 0
    rng = np.random.default_rng(config["seed"] + 350)
    original_features = {row["stable_id"] for row in selected_genes}
    for replicate in range(resamples):
        draw = rng.choice(donors, len(donors), replace=True)
        # Eligibility still counts distinct source donors, not bootstrap copies.
        represented = defaultdict(set)
        for donor in set(draw):
            for record in donor_rows[donor]:
                represented[record["class_label"]].add(donor)
        supported = {label for label, observed in represented.items() if len(observed) >= config["profiles"]["minimum_training_donors_per_class"]}
        class_presence.update(supported)
        if supported != set(labels):
            missing_class_resamples += 1
        records = []
        positions = []
        for slot, donor in enumerate(draw):
            for record in donor_rows[donor]:
                if record["class_label"] not in supported:
                    continue
                # Explicit statistical resample slots, not invented source donors.
                records.append({**record, "donor_id": f"bootstrap_slot_{slot}", "profile_id": f"bootstrap_slot_{slot}:{record['class_label']}", "source_donor_id": donor})
                positions.append(original_positions[record["profile_id"]])
        if len(supported) < 2:
            failures["fewer_than_two_supported_classes"] += 1
            overlaps.append([0.] * len(labels))
            continue
        x = np.asarray(matrix[positions], dtype=np.float64)
        mean, variance, missing, positive = weighted_statistics(x, class_weights(records))
        stats = [{**row, "training_mean": float(mean[i]), "training_variance": float(variance[i]), "training_missing_fraction": float(missing[i]), "training_positive_fraction": float(positive[i])} for i, row in enumerate(all_genes)]
        selected = choose_features(stats, config)
        fitted = fit_transform(x[:, selected], records, config)
        features = {all_genes[i]["stable_id"] for i in selected}
        feature_jaccard.append(len(features & original_features) / len(features | original_features))
        distance = cdist(fitted["centroids"], fitted["centroids"])
        np.fill_diagonal(distance, np.inf)
        replicate_neighbors = {label: {fitted["labels"][j] for j in np.argsort(row)[:k]} for label, row in zip(fitted["labels"], distance)}
        overlaps.append([len(neighbors[i] & replicate_neighbors.get(label, set())) / k for i, label in enumerate(labels)])
        if set(fitted["labels"]) == set(labels):
            _replicate_tree, replicate_clades = hierarchy(fitted["centroids"])
            for clade in replicate_clades:
                clade_counts[frozenset(label_index[fitted["labels"][i]] for i in clade)] += 1
        if (replicate + 1) % 10 == 0:
            print(json.dumps({"reference": "hlca", "stage": "training-pipeline-donor-bootstrap", "replicates": replicate + 1, "planned": resamples}), flush=True)
    return {"status": "evaluated", "resamples": resamples, "successful_feature_pca_refits": len(feature_jaccard), "failed_refits": dict(failures), "missing_class_resamples": missing_class_resamples,
            "scope": "Whole training donors; reapply independent-donor class eligibility and all-gene selection, refit centering/scaling/PCA/centroids/neighborhoods/hierarchy; calibration and test not reused or refitted",
            "resample_identity": "Bootstrap slots are statistical copies of sampled source donors; all that donor's classes move together; class eligibility counts distinct original donors",
            "feature_jaccard": {"median": float(np.median(feature_jaccard)) if feature_jaccard else None,
                                "interval": np.quantile(feature_jaccard, [.025, .975]).tolist() if feature_jaccard else None,
                                "successful_refit_denominator": len(feature_jaccard)},
            "class_presence": [{"class_label": label, "count": class_presence[label], "denominator": resamples, "fraction": class_presence[label] / resamples} for label in labels],
            "neighborhood_k": k, "mean_neighbor_overlap": float(np.mean(overlaps)), "per_class_neighbor_overlap": np.mean(overlaps, axis=0).tolist(),
            "branch_support": [{"node": len(labels) + row, "leaves": sorted(clade), "count": clade_counts[clade], "denominator": resamples, "support": clade_counts[clade] / resamples} for clade, row in original_clades.items()],
            "branch_support_scope": "Exact original clades; a replicate lacking any original class contributes no clade support; all 100 draws remain denominator"}
