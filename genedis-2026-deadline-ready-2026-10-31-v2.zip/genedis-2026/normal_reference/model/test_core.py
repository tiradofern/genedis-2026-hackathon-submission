"""Scientific guard tests; genuine held-out normals establish performance."""
import unittest
from pathlib import Path
import tempfile
import json

import numpy as np

from .core import (align_query_genes, class_weights, donor_intervals, donor_split, finite_quantile,
                   file_hash, fit_transform, identity_mask, profile_stability, project, validate_records)
from .core import metrics
from .display import load_verified_report
from .stability import full_training_stability


class NormalReferenceGuards(unittest.TestCase):
    def records(self):
        return [{"profile_id": f"p{i}", "donor_id": f"d{i}", "class_label": "A" if i < 5 else "B",
                 "source_id": "fictional_normal", "normal_status": "source_eligible_normal", "role": "train"} for i in range(10)]

    def test_donor_split_is_order_independent_and_blocked(self):
        proportions = {"train": .6, "development": .15, "calibration": .1, "test": .15}
        split = donor_split([f"d{i}" for i in range(30)] * 3, "fictional", 1, proportions)
        self.assertEqual(split, donor_split(reversed(list(split)), "fictional", 1, proportions))
        self.assertEqual(len(split), 30)
        records = self.records()
        records.append(dict(records[0], profile_id="alternate", role="test"))
        with self.assertRaisesRegex(ValueError, "Donor leakage"):
            validate_records(records)

    def test_duplicate_gene_versions_are_all_excluded(self):
        keys, keep, report = identity_mask(["ENSG000001.1", "ENSG000001.9", "ENSG000002.1", "ABC", ""])
        self.assertEqual(keys[:2], ["ENSG000001", "ENSG000001"])
        self.assertEqual(keep.tolist(), [False, False, True, False, False])
        self.assertEqual(report["duplicate_stable_id_rows"], 2)

    def test_named_query_alignment_does_not_choose_first_duplicate_or_refit(self):
        aligned, report = align_query_genes(np.array([[1., 2., 3., 4.]]), ["ENSG000002.1", "ENSG000001.1", "ENSG000001.2", "ENSG000003"], ["ENSG000001", "ENSG000002", "ENSG000003"])
        self.assertTrue(np.isnan(aligned[0, 0]))
        self.assertEqual(aligned[0, 1:].tolist(), [1., 4.])
        self.assertEqual(report["matched_features"], 2)

    def test_non_normal_or_heldout_cannot_train(self):
        records = self.records()
        records[0]["normal_status"] = "tumor"
        with self.assertRaisesRegex(ValueError, "normal"):
            validate_records(records)
        records = self.records()
        records[0]["role"] = "test"
        with self.assertRaisesRegex(ValueError, "Non-training"):
            fit_transform(np.ones((10, 4)), records, {"transform": {"maximum_pca_dimensions": 2}})

    def test_equal_class_donor_weights_and_duplicate_replicate_rejection(self):
        records = self.records()[:5] + self.records()[5:7]
        weights = class_weights(records)
        self.assertAlmostEqual(weights[:5].sum(), .5)
        self.assertAlmostEqual(weights[5:].sum(), .5)
        with self.assertRaisesRegex(ValueError, "Collapse"):
            class_weights(records + [dict(records[0], profile_id="replicate")])

    def test_projection_fixed_source_missingness_and_rejection(self):
        rng = np.random.default_rng(42)
        x = rng.normal(size=(10, 8))
        model = fit_transform(x, self.records(), {"transform": {"maximum_pca_dimensions": 3}})
        original = model["components"].copy()
        query = x[:2].copy()
        query[0, :2] = np.nan
        mapped = project(query, model, units="log2TPM", expected_units="log2TPM", missing_limit=.05, threshold=0)
        self.assertEqual(mapped["assigned"].tolist(), ["unassigned", "unassigned"])
        self.assertTrue(mapped["missing_rejected"][0])
        np.testing.assert_array_equal(original, model["components"])
        with self.assertRaisesRegex(ValueError, "units"):
            project(x[:1], model, units="RSEM", expected_units="log2TPM", missing_limit=.05)
        with self.assertRaisesRegex(ValueError, "aligned"):
            project(x[:1, :5], model, units="log2TPM", expected_units="log2TPM", missing_limit=.05)

    def test_small_donor_gram_pca_matches_direct_weighted_svd(self):
        x = np.random.default_rng(69).normal(size=(10, 40))
        records = self.records()
        model = fit_transform(x, records, {"transform": {"maximum_pca_dimensions": 3}})
        standardized = (x - model["mean"]) / model["scale"]
        _u, singular, direct = np.linalg.svd(standardized * np.sqrt(class_weights(records)[:, None]), full_matrices=False)
        np.testing.assert_allclose(model["eigenvalues"], singular[:3] ** 2, rtol=1e-10, atol=1e-10)
        np.testing.assert_allclose(model["components"].T @ model["components"], direct[:3].T @ direct[:3], rtol=1e-9, atol=1e-9)

    def test_calibration_small_donors_never_silently_gives_infinite_acceptance(self):
        self.assertEqual(finite_quantile(np.arange(9), .8), 7)
        with self.assertRaisesRegex(ValueError, "Too few"):
            finite_quantile(np.arange(9), .99)

    def test_intervals_resample_donors_with_all_classes(self):
        records = self.records()
        intervals = donor_intervals(records, [r["class_label"] for r in records], ["A", "B"], 20, 4)
        self.assertEqual(intervals["intervals"]["macro_recall"], [1, 1])
        self.assertEqual(intervals["resamples"], 20)

    def test_unsupported_truth_is_reported_separately_and_never_credited_as_correct(self):
        records = self.records()[:2]
        records[1] = dict(records[1], class_label="untrained_population")
        result = metrics(records, ["A", "A"], ["A", "B"])
        self.assertEqual(result["known_class_profiles"], 1)
        self.assertEqual(result["unrepresented_class_profiles"], 1)
        self.assertEqual(result["unrepresented_class_rejected_profiles"], 0)

    def test_stability_moves_donor_profiles_together_and_keeps_full_denominator(self):
        records = self.records()
        x = np.random.default_rng(3).normal(size=(10, 8))
        model = fit_transform(x, records, {"transform": {"maximum_pca_dimensions": 3}})
        stability = profile_stability(model, records, 20, 8, 3)
        self.assertEqual(stability["resamples"], 20)
        self.assertEqual(stability["successful_resamples"] + stability["missing_class_resamples"], 20)
        self.assertIn("frozen", stability["scope"])

    def test_present_stale_or_wrong_source_report_fails_closed(self):
        workspace_temp = Path(__file__).resolve().parent / ".runtime" / "test-temp"
        workspace_temp.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=workspace_temp) as directory:
            root = Path(directory)
            model = root / "normal_reference" / "model"
            (model / "output").mkdir(parents=True)
            report_path = model / "aggregate_report.json"
            report_path.write_text(json.dumps({"schema": "normal-reference-validation-v1", "references": [{"reference_id": "gtex"}, {"reference_id": "hlca"}]}))
            manifest = {"schema": "normal-reference-display-bindings-v1", "files": {"normal_reference/model/aggregate_report.json": file_hash(report_path)}}
            (model / "output" / "display_manifest.json").write_text(json.dumps(manifest))
            self.assertEqual(len(load_verified_report(root)["references"]), 2)
            report_path.write_text("{}")
            with self.assertRaisesRegex(ValueError, "stale or changed"):
                load_verified_report(root)
            manifest["files"]["normal_reference/model/aggregate_report.json"] = file_hash(report_path)
            (model / "output" / "display_manifest.json").write_text(json.dumps(manifest))
            with self.assertRaisesRegex(ValueError, "wrong-source"):
                load_verified_report(root)

    def test_full_training_bootstrap_reselects_features_with_donor_block_denominators(self):
        workspace_temp = Path(__file__).resolve().parent / ".runtime" / "test-temp"
        workspace_temp.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=workspace_temp) as directory_name:
            directory = Path(directory_name)
            records = [{"profile_id": f"p{donor}:{label}", "donor_id": f"d{donor}", "class_label": label, "source_id": "fictional_normal", "normal_status": "source_eligible_normal", "role": "train"} for donor in range(10) for label in ("A", "B", "C")]
            matrix = np.random.default_rng(28).normal(size=(30, 40)) + 10
            genes = [{"stable_id": f"ENSG{i:011d}", "identity_eligible": True} for i in range(40)]
            (directory / "records.json").write_text(json.dumps(records))
            (directory / "gene_eligibility.json").write_text(json.dumps(genes))
            np.save(directory / "all_gene_expression.npy", matrix, allow_pickle=False)
            config = {"seed": 15, "transform": {"maximum_pca_dimensions": 2}, "profiles": {"minimum_training_donors_per_class": 5},
                      "features": {"max_missing_training_fraction": .05, "min_positive_training_fraction": .2, "min_weighted_variance": 1e-8, "maximum": 10},
                      "validation": {"stability_resamples": 5, "neighborhood_k": 2}}
            fitted = fit_transform(matrix[:, :10], records, config)
            result = full_training_stability(directory, fitted, records, genes[:10], config)
            self.assertEqual(result["resamples"], 5)
            self.assertEqual(result["successful_feature_pca_refits"] + sum(result["failed_refits"].values()), 5)
            self.assertTrue(all(row["denominator"] == 5 for row in result["class_presence"] + result["branch_support"]))
            self.assertIn("distinct original donors", result["resample_identity"])


if __name__ == "__main__":
    unittest.main()
