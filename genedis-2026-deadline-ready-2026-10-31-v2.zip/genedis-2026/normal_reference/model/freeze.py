"""Hash-bound normal-only eligibility/model protocol, frozen before fitting."""
from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
import platform

import numpy
import scipy

from .core import file_hash, write_json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def ensure_freeze(contract: Path) -> dict:
    producers = [ROOT / "configs" / "normal_reference_v0_1.json", contract.parent / "eligibility_contract.json"] + [HERE / name for name in ("core.py", "prepare.py", "run.py", "transfer.py", "stability.py", "freeze.py")]
    binding = {str(path.relative_to(ROOT)): file_hash(path) for path in producers}
    path = HERE / "freeze_manifest.json"
    if path.exists():
        value = json.loads(path.read_text())
        if value["files"] != binding or value["source_contract_sha256"] != file_hash(contract):
            raise ValueError("Frozen normal-only protocol/source changed; deliberately version a new analysis rather than silently refit")
        return value
    value = {"schema": "normal-reference-pre-fit-freeze-v1", "frozen_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
             "scope": "Normal-only eligibility, donor roles, feature selection, transformations, model, development/calibration/test sequence and stress-test protocol; no tumor values/results used",
             "source_contract_sha256": file_hash(contract), "files": binding,
             "software": {"python": platform.python_version(), "numpy": numpy.__version__, "scipy": scipy.__version__},
             "numerical_acceptance_gates": "Development-derived and separately locked before calibration/test assessment; this pre-fit protocol does not assert biological/clinical accuracy"}
    write_json(path, value)
    return value
