"""Refresh verified aggregates and canonicalize display transport paths.

This additive transport correction leaves every frozen scientific producer and
completed model result untouched. Windows native path separators from the
original exporter are normalized only in its ignored display manifest.
"""
from pathlib import Path
import json

from .core import file_hash, write_json
from .display import load_verified_report
from .run import export_report

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def refresh_display():
    # The original exporter checks completion/source/model hashes before export.
    aggregate = export_report()
    path = HERE / "output" / "display_manifest.json"
    manifest = json.loads(path.read_text(encoding="utf-8"))
    canonical = {}
    for relative, digest in manifest["files"].items():
        normalized = relative.replace("\\", "/")
        # The original exporter can contain forward/native aliases for the same
        # config path. Coalesce identical digests; reject conflicting aliases.
        if normalized in canonical and canonical[normalized] != digest:
            raise ValueError("Conflicting canonical display transport paths")
        resolved = (ROOT / normalized).resolve()
        if not resolved.is_relative_to(ROOT.resolve()):
            raise ValueError("Display transport path escapes the project root")
        if file_hash(resolved) != digest:
            raise ValueError("Bound display bytes changed during transport normalization")
        canonical[normalized] = digest
    canonical[Path(__file__).relative_to(ROOT).as_posix()] = file_hash(Path(__file__))
    manifest["files"] = canonical
    manifest["transport_correction"] = "Canonical forward-slash manifest keys; frozen scientific files and fitted outputs unchanged"
    write_json(path, manifest)
    report = load_verified_report(ROOT)
    return {"aggregate_sha256": file_hash(aggregate), "display_manifest_sha256": file_hash(path),
            "references": [{"reference_id": row["reference_id"], "status": row["status"]} for row in report["references"]]}


if __name__ == "__main__":
    print(json.dumps(refresh_display()))
