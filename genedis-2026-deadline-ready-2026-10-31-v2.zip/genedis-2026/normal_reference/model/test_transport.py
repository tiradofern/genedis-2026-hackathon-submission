"""Regression tests for the actual Windows display-manifest transport defect.

Fixtures are wholly fictional and local; these tests never export or refit a
scientific reference and sit outside the frozen scientific producer set.
"""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from .core import file_hash, write_json
from .display import load_verified_report
from . import refresh_display as transport


class DisplayTransportRegression(unittest.TestCase):
    def setUp(self):
        parent = Path(__file__).resolve().parent / ".runtime" / "test-temp"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = tempfile.TemporaryDirectory(dir=parent)
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.model = self.root / "normal_reference" / "model"
        (self.model / "output").mkdir(parents=True)
        (self.root / "configs").mkdir()
        self.report = self.model / "aggregate_report.json"
        write_json(self.report, {"schema": "normal-reference-validation-v1", "references": [{"reference_id": "gtex", "status": "fictional_pending"}, {"reference_id": "hlca", "status": "fictional_pending"}]})
        self.helper = self.model / "refresh_display.py"
        self.helper.write_text("# Fictional transport fixture; no scientific model\n")
        self.config = self.root / "configs" / "fictional.json"
        self.config.write_text("{}")
        self.manifest = self.model / "output" / "display_manifest.json"

    def invoke(self, files):
        write_json(self.manifest, {"schema": "normal-reference-display-bindings-v1", "files": files})
        with patch.multiple(transport, ROOT=self.root, HERE=self.model, __file__=str(self.helper)), patch.object(transport, "export_report", return_value=self.report):
            return transport.refresh_display()

    def test_native_aggregate_path_and_identical_aliases_become_usable(self):
        self.invoke({"normal_reference\\model\\aggregate_report.json": file_hash(self.report),
                     "normal_reference/model/aggregate_report.json": file_hash(self.report),
                     "configs\\fictional.json": file_hash(self.config), "configs/fictional.json": file_hash(self.config)})
        manifest = json.loads(self.manifest.read_text())
        self.assertEqual(set(manifest["files"]), {"normal_reference/model/aggregate_report.json", "configs/fictional.json", "normal_reference/model/refresh_display.py"})
        self.assertEqual(len(load_verified_report(self.root)["references"]), 2)
        self.assertEqual(manifest["files"]["normal_reference/model/refresh_display.py"], file_hash(self.helper))

    def test_conflicting_alias_digests_fail_without_usable_manifest(self):
        with self.assertRaisesRegex(ValueError, "Conflicting"):
            self.invoke({"normal_reference\\model\\aggregate_report.json": file_hash(self.report),
                         "normal_reference/model/aggregate_report.json": "0" * 64})
        with self.assertRaises(ValueError):
            load_verified_report(self.root)

    def test_escaped_path_fails_before_an_outside_file_can_be_read(self):
        with self.assertRaisesRegex(ValueError, "escapes"):
            self.invoke({"../../outside.txt": "0" * 64})
        with self.assertRaises(ValueError):
            load_verified_report(self.root)

    def test_changed_bound_bytes_are_not_reblessed_by_normalization(self):
        with self.assertRaisesRegex(ValueError, "bytes changed"):
            self.invoke({"normal_reference\\model\\aggregate_report.json": "0" * 64})
        with self.assertRaises(ValueError):
            load_verified_report(self.root)


if __name__ == "__main__":
    unittest.main()
