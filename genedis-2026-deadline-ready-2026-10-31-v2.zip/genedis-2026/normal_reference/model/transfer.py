"""Independent-study normal-only refits using full donor-pseudobulk features.

Every donor appearing in a held-out study is removed from *all* other-study
training/development/calibration records. Held-out-study expression cannot
select genes, fit PCA, choose the rejection quantile or set its threshold.
"""
from __future__ import annotations

from collections import Counter
import json

import numpy as np

from .core import (class_weights, donor_intervals, donor_maximum, donor_split,
                   finite_quantile, fit_transform, metrics, weighted_statistics)
from .prepare import choose_features


def leave_study_out(directory, records, config, manifest, *, projection, develop):
    full_path = directory / "all_gene_expression.npy"
    studies = sorted(set(study for row in records for study in row.get("study_ids", [row["study_id"]])))
    if len(studies) < 2:
        return {"status": "untestable_single_source_study", "studies": len(studies), "reason": "GTEx donor holdout cannot establish cross-study processing transfer"}
    if not full_path.exists():
        return {"status": "untested_missing_full_feature_matrix", "studies": len(studies), "reason": "No leak-free feature-reselection input; original selected features cannot substitute for a study-independent fit"}
    all_features = json.loads((directory / "gene_eligibility.json").read_text())
    matrix = np.load(full_path, mmap_mode="r", allow_pickle=False)
    folds = []
    for study_index, study in enumerate(studies):
        heldout_donors = set(row["donor_id"] for row in records if study in row.get("study_ids", [row["study_id"]]))
        other_donors = sorted(set(row["donor_id"] for row in records) - heldout_donors)
        roles = donor_split(other_donors, f"hlca_loso:{study}", config["seed"], config["donor_roles"])
        train_indices = [i for i, row in enumerate(records) if row["donor_id"] not in heldout_donors and roles[row["donor_id"]] == "train"]
        train_counts = Counter(records[i]["class_label"] for i in train_indices)
        evaluation_indices = [i for i, row in enumerate(records) if row["donor_id"] in heldout_donors and study in row.get("study_ids", [row["study_id"]])]
        evaluation_counts = Counter(records[i]["class_label"] for i in evaluation_indices)
        labels = sorted(label for label, count in train_counts.items() if count >= config["profiles"]["minimum_training_donors_per_class"])
        shared = [label for label in labels if evaluation_counts[label] >= 2]
        fold = {"study": study, "heldout_donors": len(heldout_donors), "shared_classes_at_least_two_test_donors": len(shared),
                "unrepresented_test_classes": sorted(set(evaluation_counts) - set(labels)),
                "cross_study_donor_rule": "Remove every held-out donor from all non-heldout study records"}
        if len(shared) < 2 or len(other_donors) < 20:
            folds.append({**fold, "status": "not_estimable", "reason": "Fewer than two eligible shared classes or too few non-heldout donors"})
            continue
        train_indices = [i for i in train_indices if records[i]["class_label"] in labels]
        train_records = [dict(records[i], role="train") for i in train_indices]
        x_training = np.asarray(matrix[train_indices], dtype=np.float64)
        mean, variance, missing, positive = weighted_statistics(x_training, class_weights(train_records))
        stats = [{**row, "training_mean": float(mean[i]), "training_variance": float(variance[i]), "training_missing_fraction": float(missing[i]), "training_positive_fraction": float(positive[i])} for i, row in enumerate(all_features)]
        selected = choose_features(stats, config)
        x_training = x_training[:, selected]
        model = fit_transform(x_training, train_records, config)
        train_mapped = projection(x_training, model, manifest, config)
        develop_indices = [i for i, row in enumerate(records) if row["donor_id"] not in heldout_donors and roles[row["donor_id"]] == "development"]
        calibrate_indices = [i for i, row in enumerate(records) if row["donor_id"] not in heldout_donors and roles[row["donor_id"]] == "calibration" and row["class_label"] in model["labels"]]
        develop_records = [dict(records[i], role="development") for i in develop_indices]
        calibrate_records = [dict(records[i], role="calibration") for i in calibrate_indices]
        calibration_donors = len(set(row["donor_id"] for row in calibrate_records))
        try:
            lock = develop(np.asarray(matrix[develop_indices][:, selected], dtype=np.float64), develop_records, train_mapped, train_records, model, manifest, config, calibration_donors)
        except ValueError as error:
            folds.append({**fold, "status": "not_estimable", "reason": str(error)})
            continue
        calibration_mapped = projection(np.asarray(matrix[calibrate_indices][:, selected], dtype=np.float64), model, manifest, config)
        threshold = finite_quantile(donor_maximum(calibration_mapped["score"], calibrate_records), lock["selected_quantile"])
        evaluation_records = [dict(records[i], role="test") for i in evaluation_indices]
        mapped = projection(np.asarray(matrix[evaluation_indices][:, selected], dtype=np.float64), model, manifest, config, threshold)
        measured = metrics(evaluation_records, mapped["assigned"], model["labels"])
        folds.append({**fold, "status": "evaluated", "training_donors": len(set(row["donor_id"] for row in train_records)),
                      "feature_count": len(selected), "dimensions": len(model["components"]), "classes": model["labels"],
                      "selected_rejection_quantile": lock["selected_quantile"], "calibration_threshold": threshold,
                      "metrics": measured, "donor_intervals": donor_intervals(evaluation_records, mapped["assigned"], model["labels"], config["validation"]["interval_resamples"], config["seed"] + 400 + study_index),
                      "fit_scope": "Full all-gene training-only eligibility/feature selection, centering/scaling/PCA/centroids, development choice and separate donor calibration refitted without held-out-study donors"})
        print(json.dumps({"reference": "hlca", "stage": "leave-study-out", "study": study, "macro_recall": measured["macro_recall"], "coverage": measured["coverage"]}), flush=True)
    return {"status": "evaluated" if any(fold["status"] == "evaluated" for fold in folds) else "not_estimable", "studies": len(studies), "folds": folds,
            "interpretation": "Study-transfer stress tests of independently refitted normal references; source annotations and shared upstream processing remain limitations; held-out-study differences are not causal batch estimates"}
