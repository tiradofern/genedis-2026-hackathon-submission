"""Auditable normal-only baseline. Independent units are blocked donors.

These are expression *profiles*, not coordinated programs or ancestors. Source
processing is checked by preparation; the two modalities never share a matrix.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from hashlib import sha256
import json
import math
from pathlib import Path
import re
from typing import Iterable

import numpy as np
from scipy.cluster.hierarchy import linkage
from scipy.linalg import eigh
from scipy.spatial.distance import cdist

ROLES = ("train", "development", "calibration", "test")
NORMAL_STATUS = "source_eligible_normal"


def file_hash(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def stable_gene_id(value: str) -> str | None:
    value = str(value).strip()
    match = re.fullmatch(r"(ENSG[0-9]+)(?:\.[0-9]+)?", value)
    return match.group(1) if match else None


def identity_mask(ids: Iterable[str]) -> tuple[list[str | None], np.ndarray, dict]:
    keys = [stable_gene_id(x) for x in ids]
    counts = Counter(keys)
    keep = np.array([x is not None and counts[x] == 1 for x in keys])
    return keys, keep, {"input_rows": len(keys), "invalid_rows": sum(x is None for x in keys),
                        "duplicate_stable_id_rows": sum(x is not None and counts[x] > 1 for x in keys),
                        "identity_eligible_rows": int(keep.sum())}


def donor_split(donors: Iterable[str], source_id: str, seed: int, proportions: dict) -> dict[str, str]:
    """All donors, never individual cells/samples, receive one immutable role."""
    ordered = sorted(set(donors), key=lambda d: sha256(f"{seed}|{source_id}|{d}".encode()).digest())
    if not ordered or abs(sum(proportions[r] for r in ROLES) - 1) > 1e-12:
        raise ValueError("Empty donors or invalid split proportions")
    boundaries = [round(len(ordered) * sum(proportions[r] for r in ROLES[:i])) for i in range(5)]
    return {donor: role for i, role in enumerate(ROLES) for donor in ordered[boundaries[i]:boundaries[i + 1]]}


def validate_records(records: list[dict], *, require_role: str | None = None) -> None:
    seen = set()
    donor_roles = defaultdict(set)
    for record in records:
        if record.get("normal_status") != NORMAL_STATUS:
            raise ValueError("Fitting accepts only source-eligible normal profiles")
        if record.get("role") not in ROLES or not all(record.get(k) for k in ("profile_id", "donor_id", "class_label", "source_id")):
            raise ValueError("Missing donor/class/source/role metadata")
        if record["profile_id"] in seen:
            raise ValueError("Duplicate profile identifier")
        seen.add(record["profile_id"])
        donor_roles[record["donor_id"]].add(record["role"])
        if require_role and record["role"] != require_role:
            raise ValueError("Non-training record reached a training-only operation")
    if any(len(roles) != 1 for roles in donor_roles.values()):
        raise ValueError("Donor leakage across roles")


def class_weights(records: list[dict]) -> np.ndarray:
    """One donor/class profile; equal class mass and donor mass within class."""
    units = [(r["donor_id"], r["class_label"]) for r in records]
    if len(set(units)) != len(units):
        raise ValueError("Collapse donor/class technical replicates before weighting")
    counts = Counter(r["class_label"] for r in records)
    return np.array([1 / (len(counts) * counts[r["class_label"]]) for r in records])


def weighted_statistics(x: np.ndarray, weights: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    valid = np.isfinite(x)
    observed = weights @ valid
    cleaned = np.where(valid, x, 0)
    mean = (weights @ cleaned) / np.maximum(observed, 1e-30)
    variance = np.maximum((weights @ (cleaned * cleaned)) / np.maximum(observed, 1e-30) - mean * mean, 0)
    positive = weights @ (valid & (x > 0))
    return mean, variance, 1 - observed, positive


def fit_transform(x: np.ndarray, records: list[dict], config: dict) -> dict:
    validate_records(records, require_role="train")
    if not np.isfinite(x).all():
        raise ValueError("Prepared selected-gene training matrix must be finite")
    weights = class_weights(records)
    mean = weights @ x
    scale = np.sqrt(np.maximum(weights @ ((x - mean) ** 2), 1e-16))
    standardized = (x - mean) / scale
    weighted = standardized * np.sqrt(weights[:, None])
    # The smaller exact Gram representation avoids unnecessary 2,000-square
    # eigensystems for donor-pseudobulk references with fewer training profiles.
    dual = len(standardized) < standardized.shape[1]
    covariance = weighted @ weighted.T if dual else weighted.T @ weighted
    maximum = min(config["transform"]["maximum_pca_dimensions"], len(covariance))
    eigenvalues, eigenvectors = eigh(covariance, subset_by_index=[len(covariance) - maximum, len(covariance) - 1], driver="evr")
    order = np.argsort(eigenvalues)[::-1]
    retained = order[eigenvalues[order] > 1e-10][:config["transform"]["maximum_pca_dimensions"]]
    if len(retained) < 2:
        raise ValueError("Reference has fewer than two nonzero normal-only dimensions")
    components = ((eigenvectors[:, retained].T @ weighted) / np.sqrt(eigenvalues[retained])[:, None]) if dual else eigenvectors[:, retained].T
    # A sign convention makes reproduction/display stable without biological meaning.
    for row in components:
        if row[np.argmax(np.abs(row))] < 0:
            row *= -1
    coordinates = standardized @ components.T
    labels = sorted(set(r["class_label"] for r in records))
    if len(labels) < 2:
        raise ValueError("Reference requires at least two supported normal classes")
    centroids = np.array([coordinates[[r["class_label"] == label for r in records]].mean(axis=0) for label in labels])
    radii = []
    for label, centroid in zip(labels, centroids):
        points = coordinates[[r["class_label"] == label for r in records]]
        # One record per donor/class: leave that donor out of its own centroid.
        loo_centroids = (points.sum(axis=0) - points) / (len(points) - 1)
        radii.append(float(np.median(np.linalg.norm(points - loo_centroids, axis=1))))
    floor = max(float(np.median(radii)) * .01, 1e-8)
    return {"mean": mean, "scale": scale, "components": components, "eigenvalues": eigenvalues[retained],
            "variance_fraction": eigenvalues[retained] / max(np.trace(covariance), 1e-30), "labels": labels,
            "centroids": centroids, "radii": np.maximum(radii, floor), "train_coordinates": coordinates}


def project(x: np.ndarray, model: dict, *, units: str, expected_units: str,
            missing_limit: float, threshold: float | None = None) -> dict:
    """Fixed projection never mutates/refits features, profiles or PCA."""
    if units != expected_units:
        raise ValueError("Expression units/source transform do not match frozen reference")
    if x.ndim != 2 or x.shape[1] != len(model["mean"]):
        raise ValueError("Query must be aligned to the exact frozen selected-gene universe")
    missing = (~np.isfinite(x)).mean(axis=1)
    prepared = np.where(np.isfinite(x), x, model["mean"])
    coordinates = ((prepared - model["mean"]) / model["scale"]) @ model["components"].T
    distances = cdist(coordinates, model["centroids"])
    nearest = np.argmin(distances, axis=1)
    score = distances[np.arange(len(x)), nearest] / model["radii"][nearest]
    rejected_missing = missing > missing_limit + 1e-12
    rejected_distance = np.zeros(len(x), dtype=bool) if threshold is None else score > threshold
    assigned = np.array([model["labels"][i] for i in nearest], dtype=object)
    assigned[rejected_missing | rejected_distance] = "unassigned"
    return {"coordinates": coordinates, "distances": distances, "nearest": nearest, "score": score,
            "assigned": assigned, "missing_fraction": missing, "missing_rejected": rejected_missing,
            "distance_rejected": rejected_distance}


def align_query_genes(x: np.ndarray, query_gene_ids: list[str], frozen_gene_ids: list[str]) -> tuple[np.ndarray, dict]:
    """Align stable IDs; every duplicate query key becomes unavailable.

    Expression has profile rows and gene columns. Missing/ambiguous genes become
    NaN for the fixed projector's explicit coverage guard and mean imputation.
    """
    if x.ndim != 2 or x.shape[1] != len(query_gene_ids):
        raise ValueError("Query gene dimensions do not match named identifiers")
    frozen_keys, frozen_keep, _ = identity_mask(frozen_gene_ids)
    if not frozen_keep.all():
        raise ValueError("Frozen reference identifiers must all be unique stable genes")
    query_keys, query_keep, losses = identity_mask(query_gene_ids)
    lookup = {key: i for i, (key, keep) in enumerate(zip(query_keys, query_keep)) if keep}
    aligned = np.full((len(x), len(frozen_gene_ids)), np.nan, dtype=np.float64)
    matched = 0
    for column, key in enumerate(frozen_keys):
        if key in lookup:
            aligned[:, column] = x[:, lookup[key]]
            matched += 1
    return aligned, {**losses, "reference_features": len(frozen_gene_ids), "matched_features": matched,
                     "unavailable_reference_features": len(frozen_gene_ids) - matched,
                     "feature_coverage": matched / len(frozen_gene_ids), "matching": "exact unversioned stable IDs; all duplicated query stable keys unavailable"}


def finite_quantile(values: np.ndarray, coverage: float) -> float:
    if not 0 < coverage < 1 or not len(values) or not np.isfinite(values).all():
        raise ValueError("Invalid finite calibration scores")
    rank = math.ceil((len(values) + 1) * coverage)
    if rank > len(values):
        raise ValueError("Too few independent calibration donors for requested coverage")
    return float(np.sort(values)[rank - 1])


def donor_maximum(scores: np.ndarray, records: list[dict]) -> np.ndarray:
    maxima = defaultdict(lambda: -math.inf)
    for score, record in zip(scores, records):
        maxima[record["donor_id"]] = max(maxima[record["donor_id"]], float(score))
    return np.array([maxima[donor] for donor in sorted(maxima)])


def metrics(records: list[dict], assigned: Iterable[str], labels: list[str], donor_counts: dict | None = None) -> dict:
    assigned = list(assigned)
    confusion = np.zeros((len(labels), len(labels) + 1), dtype=float)
    label_index = {label: i for i, label in enumerate(labels)}
    unknown_truth = 0
    unknown_rejected = 0
    for record, prediction in zip(records, assigned):
        weight = 1 if donor_counts is None else donor_counts.get(record["donor_id"], 0)
        if record["class_label"] not in label_index:
            unknown_truth += weight
            unknown_rejected += weight * (prediction == "unassigned")
            continue
        confusion[label_index[record["class_label"]], label_index.get(prediction, len(labels))] += weight
    totals = confusion.sum(axis=1)
    recalls = np.divide(np.diag(confusion[:, :-1]), totals, out=np.full(len(labels), np.nan), where=totals > 0)
    precision = np.divide(np.diag(confusion[:, :-1]), confusion[:, :-1].sum(axis=0), out=np.zeros(len(labels)), where=confusion[:, :-1].sum(axis=0) > 0)
    f1 = np.divide(2 * precision * np.nan_to_num(recalls), precision + np.nan_to_num(recalls), out=np.zeros(len(labels)), where=precision + np.nan_to_num(recalls) > 0)
    denominator = confusion.sum()
    accepted = confusion[:, :-1].sum()
    return {"macro_recall": float(np.nanmean(recalls)) if (totals > 0).any() else None,
            "represented_class_count": len(labels), "observed_truth_class_count": int(np.sum(totals > 0)),
            "macro_class_labels": [label for label, total in zip(labels, totals) if total > 0],
            "zero_truth_classes": [label for label, total in zip(labels, totals) if total == 0],
            "macro_f1": float(np.mean(f1[totals > 0])) if (totals > 0).any() else None,
            "accuracy_including_unassigned": float(np.trace(confusion[:, :-1]) / denominator) if denominator else None,
            "accepted_accuracy": float(np.trace(confusion[:, :-1]) / accepted) if accepted else None,
            "coverage": float(accepted / denominator) if denominator else None,
            "known_class_profiles": float(denominator), "unrepresented_class_profiles": int(unknown_truth),
            "unrepresented_class_rejected_profiles": int(unknown_rejected),
            "unrepresented_class_rejection": float(unknown_rejected / unknown_truth) if unknown_truth else None,
            "per_class_recall": [None if not np.isfinite(x) else float(x) for x in recalls], "confusion": confusion.tolist()}


def donor_intervals(records: list[dict], assigned: Iterable[str], labels: list[str], resamples: int, seed: int) -> dict:
    donors = sorted(set(r["donor_id"] for r in records))
    rng = np.random.default_rng(seed)
    draws = [metrics(records, assigned, labels, Counter(rng.choice(donors, size=len(donors), replace=True))) for _ in range(resamples)]
    scalar = {}
    for key in ("macro_recall", "macro_f1", "coverage", "accuracy_including_unassigned", "accepted_accuracy"):
        values = [row[key] for row in draws if row[key] is not None]
        scalar[key] = np.quantile(values, [.025, .975]).tolist() if values else None
    scalar["per_class_recall"] = [np.quantile([r["per_class_recall"][i] for r in draws if r["per_class_recall"][i] is not None], [.025, .975]).tolist()
                                       if any(r["per_class_recall"][i] is not None for r in draws) else None for i in range(len(labels))]
    return {"method": "whole-donor bootstrap; all donor records move together", "resamples": resamples, "intervals": scalar}


def hierarchy(centroids: np.ndarray) -> tuple[list[list[float]], dict[frozenset, int]]:
    if len(centroids) < 2:
        return [], {}
    tree = linkage(centroids, method="average", metric="euclidean")
    groups = {i: frozenset([i]) for i in range(len(centroids))}
    clades = {}
    for i, (left, right, _distance, _count) in enumerate(tree):
        group = groups[int(left)] | groups[int(right)]
        groups[len(centroids) + i] = group
        if len(group) < len(centroids):
            clades[group] = i
    return tree.tolist(), clades


def profile_stability(model: dict, records: list[dict], resamples: int, seed: int, k: int) -> dict:
    """Donor block bootstrap, fixed transform. No feature/PCA stability claim."""
    donors = sorted(set(r["donor_id"] for r in records))
    labels = model["labels"]
    coordinates = model["train_coordinates"]
    tree, clades = hierarchy(model["centroids"])
    distances = cdist(model["centroids"], model["centroids"])
    np.fill_diagonal(distances, np.inf)
    k = min(k, len(labels) - 1)
    original_neighbors = np.argsort(distances, axis=1)[:, :k]
    counts = Counter()
    overlaps = []
    missing_class_resamples = 0
    rng = np.random.default_rng(seed)
    for _ in range(resamples):
        multiplicity = Counter(rng.choice(donors, size=len(donors), replace=True))
        weights = np.array([multiplicity[r["donor_id"]] for r in records])
        points = []
        for label in labels:
            mask = np.array([r["class_label"] == label for r in records])
            if not weights[mask].sum():
                break
            points.append(np.average(coordinates[mask], weights=weights[mask], axis=0))
        if len(points) != len(labels):
            missing_class_resamples += 1
            continue
        centroids = np.array(points)
        _tree, replicate_clades = hierarchy(centroids)
        counts.update(replicate_clades.keys())
        distance = cdist(centroids, centroids)
        np.fill_diagonal(distance, np.inf)
        neighbors = np.argsort(distance, axis=1)[:, :k]
        overlaps.append([len(set(a) & set(b)) / k for a, b in zip(original_neighbors, neighbors)])
    return {"resamples": resamples, "successful_resamples": len(overlaps), "missing_class_resamples": missing_class_resamples,
            "scope": "whole training donors; centroids/neighborhoods/hierarchy in frozen features and PCA; feature/PCA reselection untested",
            "neighborhood_k": k, "mean_neighbor_overlap": float(np.mean(overlaps)) if overlaps else None,
            "per_class_neighbor_overlap": np.mean(overlaps, axis=0).tolist() if overlaps else [None] * len(labels),
            "branch_support": [{"node": len(labels) + row, "leaves": sorted(group), "count": counts[group], "denominator": resamples,
                                "support": counts[group] / resamples} for group, row in clades.items()], "linkage": tree}
