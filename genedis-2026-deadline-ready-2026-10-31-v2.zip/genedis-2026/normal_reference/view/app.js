import {hierarchyGeometry,displayValue,proteinContextUrl} from './helpers.mjs';
const $=id=>document.getElementById(id),NS='http://www.w3.org/2000/svg';
const percent=value=>Number.isFinite(value)?`${(value*100).toFixed(1)}%`:'Not assessed';
let data=null,current=null,selected=null;
const sourceLabel=r=>({gtex:'GTEx · body-wide native tissues',hlca:'Healthy HLCA · lung cell types'}[r.reference_id]||r.source_id||r.reference_id);
function node(tag,text,attrs={}){const e=document.createElement(tag);if(text!==null)e.textContent=text;Object.entries(attrs).forEach(([k,v])=>e.setAttribute(k,v));return e;}
function svg(tag,attrs,text){const e=document.createElementNS(NS,tag);Object.entries(attrs).forEach(([k,v])=>e.setAttribute(k,v));if(text!==undefined)e.textContent=text;return e;}
function text(id,value){$(id).textContent=value;}
function row(body,values){const tr=node('tr',null);values.forEach(v=>tr.append(v instanceof Node?v:node('td',displayValue(v))));$(body).append(tr);}
function choose(label){const focusPlot=document.activeElement?.closest('svg')?.id;selected=label;$('profile').value=label;renderPlots();renderInspector();if(focusPlot){Array.from($(focusPlot).querySelectorAll('.profile-target')).find(e=>e.getAttribute('data-profile')===label)?.focus({preventScroll:true});}}
function target(label,child){const g=svg('g',{'class':'profile-target',role:'button',tabindex:0,'data-profile':label,'aria-label':`Inspect ${label}`,'aria-pressed':String(label===selected)});g.append(svg('title',{},label),child);g.addEventListener('click',()=>choose(label));g.addEventListener('keydown',e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();choose(label);}});return g;}
function renderMap(){
  const plot=$('map');plot.replaceChildren();const points=current.centroids||[];if(!points.length)return;
  const finite=points.every(p=>p.coordinates?.length>=2&&p.coordinates.slice(0,2).every(Number.isFinite));if(!finite)throw Error('Reference coordinates are incomplete');
  const bounds=[0,1].map(k=>{const a=points.map(p=>p.coordinates[k]);let lo=Math.min(...a),hi=Math.max(...a);if(lo===hi){lo--;hi++;}const pad=(hi-lo)*.09;return [lo-pad,hi+pad];});
  const scale=(x,k)=>k===0?50+(x-bounds[k][0])/(bounds[k][1]-bounds[k][0])*460:365-(x-bounds[k][0])/(bounds[k][1]-bounds[k][0])*325;
  plot.append(svg('path',{d:'M50 35V365H515',class:'map-axis'}));
  for(let k=0;k<2;k++)for(let i=0;i<4;i++){const value=bounds[k][0]+(bounds[k][1]-bounds[k][0])*i/3,x=k===0?scale(value,0):42,y=k===0?384:scale(value,1)+4;plot.append(svg('text',{x,y,'text-anchor':k===0?'middle':'end',class:'plot-text'},value.toFixed(1)));}
  plot.append(svg('text',{x:280,y:410,'text-anchor':'middle',class:'plot-text'},'Normal-training PC1'),svg('text',{x:15,y:25,class:'plot-text'},'PC2'));
  points.forEach((p,i)=>{const x=scale(p.coordinates[0],0),y=scale(p.coordinates[1],1),g=target(p.class_label,svg('circle',{cx:x,cy:y,r:p.class_label===selected?6.5:4.5,class:`reference-point${p.class_label===selected?' selected':''}`}));plot.append(g);if(p.class_label===selected)plot.append(svg('text',{x:Math.min(x+10,360),y:Math.max(24,y-9),class:'hierarchy-label selected'},p.class_label));});
}
function renderHierarchy(){
  const plot=$('hierarchy');plot.replaceChildren();const h=current.hierarchy;if(!h?.leaf_labels?.length)return;
  const g=hierarchyGeometry(h.leaf_labels,h.linkage),height=Math.max(320,h.leaf_labels.length*21+65),width=700,max=Math.max(1e-12,g.nodes[g.root].distance),x=d=>445-d/max*410,y=r=>30+r*21;
  plot.setAttribute('viewBox',`0 0 ${width} ${height}`);
  for(const p of g.nodes){if(p.children.length){const [a,b]=p.children.map(i=>g.nodes[i]);plot.append(svg('path',{d:`M${x(a.distance)} ${y(a.row)}H${x(p.distance)}V${y(b.row)}H${x(b.distance)}`,class:'hierarchy-line'}));const support=(h.branch_support||[]).find(s=>s.node===p.id);if(support){const label=svg('text',{x:x(p.distance)+4,y:y(p.row)-4,class:'plot-text'},`${Math.round(support.support*100)}%`);label.append(svg('title',{},`${support.count}/${support.denominator} donor resamples; ${h.bootstrap_scope || "scope not reported"}`));plot.append(label);}}else plot.append(target(p.label,svg('text',{x:455,y:y(p.row)+4,class:`hierarchy-label${p.label===selected?' selected':''}`},p.label)));}
  const axisY=height-30;plot.append(svg('path',{d:`M35 ${axisY}H445`,class:'hierarchy-axis'}));[0,.5,1].forEach(t=>plot.append(svg('text',{x:x(max*t),y:axisY+19,'text-anchor':'middle',class:'plot-text'},displayValue(max*t))));
  const activeNode=g.nodes.find(p=>p.label===selected);if(activeNode){const pane=plot.parentElement;pane.scrollTop=Math.max(0,(y(activeNode.row)/height*plot.getBoundingClientRect().height)-pane.clientHeight/2);}
}
function renderPlots(){renderMap();renderHierarchy();}
function renderInspector(){
  const p=current.centroids.find(p=>p.class_label===selected);if(!p)return;
  text('profile-title',p.class_label);text('profile-evidence',`${displayValue(p.train_donors)} training donors. This is a normal-trained expression profile.`);
  const evidence=current.validation?.per_class?.find(r=>r.class_label===p.class_label);text('profile-validation',evidence?`${displayValue(evidence.test_donors)} test donors · recall ${percent(evidence.recall)}${evidence.recall_interval?` [${evidence.recall_interval.map(percent).join(', ')}]`:''}. ${evidence.claim||evidence.reason||evidence.status}.`:'Held-out evidence is not available for this profile.');
  text('profile-neighbors',`Nearest reference profiles: ${(p.neighbors||[]).map(x=>typeof x==='string'?x:x.class_label).join(', ')||'Not reported'}.`);
  $('features').replaceChildren();for(const f of p.descriptive_profile_features||[]){const id=f.stable_id,url=proteinContextUrl(id),td=node('td',null);td.append(url?node('a','HPA context',{href:url,target:'_blank',rel:'noopener noreferrer'}):node('span','No verified Ensembl link'));row('features',[f.symbol,id,f.mean_training_standardized_log_expression,td]);}
  if(!$('features').children.length)row('features',['Feature interpretation not reported',null,null,'No protein validation claimed']);
}
function renderValidation(){
  const v=current.validation||{};text('validation-status',`${v.gate_scope||'Normal assessment pending.'} ${v.metric_scope||''}`);
  $('roles').replaceChildren();const purposes={train:'Features, transform and reference profiles',development:'Development choices and acceptance lock',calibration:'Assignment/rejection calibration',test:'Held-out normal assessment'};
  Object.entries(current.counts?.roles||{}).forEach(([r,c])=>row('roles',[r,c.donors,c.profiles,purposes[r]||'See frozen configuration']));
  $('validation-metrics').replaceChildren();Object.entries(v.metrics||{}).filter(([,x])=>['number','boolean'].includes(typeof x)).forEach(([k,x])=>{const p=node('p',null),interval=v.donor_bootstrap_intervals?.intervals?.[k];p.append(node('strong',`${k.replaceAll('_',' ')}: `),document.createTextNode(displayValue(x)+(interval?` [${interval.map(displayValue).join(', ')}] · 95% donor interval`:'')));$('validation-metrics').append(p);});
  $('classes').replaceChildren();for(const p of v.per_class||[]){const i=v.confusion?.labels?.indexOf(p.class_label)??-1,values=i>=0?v.confusion.matrix[i]:null,rejected=p.rejected_profiles??values?.[values.length-1],recall=p.recall_interval?`${displayValue(p.recall)} [${p.recall_interval.map(displayValue).join(', ')}]`:displayValue(p.recall);row('classes',[p.class_label,p.test_donors,recall,p.test_profiles===0?'Not assessed (no test profiles)':rejected===undefined?null:`${displayValue(rejected)} / ${displayValue(p.test_profiles)}`,p.claim||p.reason||p.status?.replaceAll('_',' ')||'See validation report']);}
  if(!$('classes').children.length)row('classes',['Per-profile validation pending',null,null,null,'No acceptance claim']);
  $('controls').replaceChildren();for(const [key,label,scope] of [['independent_within_profile_gene_permutation','Gene permutation','Destructive synthetic control; biological off-reference detection remains unvalidated'],['leave_class_out','True centroid withheld','Frozen features/PCA still include the withheld class; a descriptive near-reference control']]){const c=v.negative_controls?.[key];if(c)row('controls',[label,c.donors,c.profiles,`${percent(c.donor_mean_rejection)}${c.interval?` [${c.interval.map(percent).join(', ')}]`:''}`,scope]);}if(!$('controls').children.length)row('controls',['Controls pending',null,null,null,'No rejection performance claimed']);
  text('unsupported-summary',(v.per_class||[]).filter(p=>p.status==='untrained_insufficient_training_donors').map(p=>`${p.class_label}: ${displayValue(p.train_donors)} training donors, ${displayValue(p.test_donors)} test donors; ${p.test_profiles?`${displayValue(p.rejected_profiles)}/${displayValue(p.test_profiles)} test profiles rejected`:'no test profiles'}. ${Object.entries(p.accepted_as_classes||{}).map(([label,n])=>`${n} falsely accepted as ${label}`).join('; ')||'No tested assignment claim'}. Population remains unvalidated.`).join(' '));
  $('study-transfers').replaceChildren();for(const f of current.leave_study_out?.folds||[]){const interval=f.donor_intervals?.intervals?.macro_recall;row('study-transfers',[f.study,f.heldout_donors,f.metrics?`${percent(f.metrics.macro_recall)}${interval?` [${interval.map(percent).join(', ')}]`:''}`:f.reason||f.status,f.metrics?percent(f.metrics.coverage):null,f.metrics?`${displayValue(f.metrics.observed_truth_class_count)} / ${displayValue(f.metrics.represented_class_count)}`:null]);}if(!$('study-transfers').children.length)row('study-transfers',[current.leave_study_out?.reason||current.leave_study_out?.status||'Study transfer pending',null,null,null,null]);
  text('validation-details',JSON.stringify({development_lock:current.development_lock,calibration:current.calibration,validation:v,stability:current.stability,training_pipeline_stability:current.training_pipeline_stability,leave_study_out:current.leave_study_out,technical_covariates:current.technical_covariates},null,2));
}
function renderTumor(){
  const h=$('histology').value,c=data?.inventory?.cohorts?.[h];
  text('tumor-cohort',c?`${h}: ${c.independent_patients} existing independent patients (${c.roles.training} training / ${c.roles.evaluation} evaluation), ${c.rna_gene_rows.toLocaleString()} RNA features. Existing measurements: ${data.inventory.measurement}.`:'Existing RNA inventory is not available. No tumor projection has been made.');
  text('tumor-status',current?.tumor_projection?.reason||'Tumor projection is pending a verified comparable RNA processing path and assessed normal validation. No tumor points or normal-class assignments are shown.');
}
function render(){
  current=data.references.find(r=>r.reference_id===$('reference').value);if(!current)return;
  selected=current.centroids?.some(p=>p.class_label===selected)?selected:current.centroids?.[0]?.class_label;
  text('reference-note',`${sourceLabel(current)} · ${current.reference_version||'Reference fit pending'} · ${current.status.replaceAll('_',' ')}. ${current.limitations?.[0]||'Reference similarity does not establish biological lineage.'}`);
  const pass=current.validation?.gate_passed;text('readiness-title',pass===true?'Internal consistency checks passed':pass===false?'Normal validation gate failed':'Normal checks pending');
  text('readiness',current.validation?.gate_scope||'Normal reference assessment is recorded below. Tumor transfer remains a separate requirement.');
  const metrics=current.validation?.metrics,interval=current.validation?.donor_bootstrap_intervals?.intervals?.macro_recall;if(metrics)text('readiness',`Held-out macro-recall ${percent(metrics.macro_recall)}${interval?` [${interval.map(percent).join(', ')}]`:''} across ${displayValue(metrics.observed_truth_class_count)} observed / ${displayValue(metrics.represented_class_count)} fitted classes. Assignment coverage ${percent(metrics.coverage)}; assignment does not imply a correct class. ${current.validation.gate_scope}`);
  const failures=Object.entries(current.validation?.gate_checks||{}).filter(([,v])=>v===false).map(([k])=>k.replaceAll('_',' '));if(failures.length)$('readiness').append(document.createTextNode(` Failed checks: ${failures.join('; ')}.`));
  text('denominators',`${displayValue(current.counts?.donors)} normal donors · ${displayValue(current.counts?.eligible_profiles)} eligible profiles · ${displayValue(current.counts?.supported_class_count)} fitted / ${displayValue(current.counts?.primary_class_count)} primary-source classes`);
  text('model-units',`${current.units?.source||''}. ${current.units?.distance||'Distances are unitless RNA similarity measurements.'}`);
  $('profile').replaceChildren(...(current.centroids||[]).map(p=>node('option',p.class_label,{value:p.class_label})));$('profile').disabled=!selected;if(selected)$('profile').value=selected;
  const hasProfiles=!!current.centroids?.length;$('plots').hidden=!hasProfiles;$('inspector').hidden=!hasProfiles;$('plots-empty').hidden=hasProfiles;
  const variance=current.explained_variance_fraction;text('pca-note',`Dots are normal training centroids. Distances use ${displayValue(current.dimensions)} PCs.${variance?` Display variance: PC1 ${(variance[0]*100).toFixed(1)}%, PC2 ${(variance[1]*100).toFixed(1)}%.`:''}`);
  text('hierarchy-note',`Unitless distance; the root is a display convention. Branch percentages: ${current.hierarchy?.bootstrap_scope||'bootstrap scope not reported; inspect the aggregate record'}.`);
  if(hasProfiles){renderPlots();renderInspector();}renderValidation();renderTumor();
  text('provenance',JSON.stringify({reference_id:current.reference_id,source_id:current.source_id,source_contract_sha256:current.source_contract_sha256,model_sha256:current.model_sha256,config_sha256:current.config_sha256,counts:current.counts,units:current.units,features:current.features,source_preparation:current.source_preparation,limitations:current.limitations,source_contracts:data.source_contracts,resource_roles:data.resource_roles},null,2));
  text('fingerprint',`Reference ${current.reference_id} · model ${current.model_sha256||'pending'}`);
}
async function load(){
  try{const response=await fetch('/api/bootstrap',{cache:'no-store'});const value=await response.json();if(!response.ok)throw Error(value.error||'Reference record could not be verified');data=value;
    if(!Array.isArray(data.references))throw Error('Reference response is incomplete');
    if(!data.references.length){$('download').hidden=true;text('readiness',data.reason||'Audited normal reference outputs are pending.');text('reference-note','Source acquisition and normal-only preparation precede model fitting.');renderTumor();text('provenance',JSON.stringify(data,null,2));return;}
    $('reference').replaceChildren(...data.references.map(r=>node('option',sourceLabel(r),{value:r.reference_id})));$('reference').disabled=false;render();
  }catch(error){$('error').hidden=false;text('error',`${error.message}. Check the source/model record and rerun the documented preparation before reloading.`);text('readiness-title','Reference unavailable');text('readiness','No unverified placements are displayed.');}
}
$('reference').addEventListener('change',()=>{selected=null;render();});$('profile').addEventListener('change',()=>choose($('profile').value));$('histology').addEventListener('change',renderTumor);load();
