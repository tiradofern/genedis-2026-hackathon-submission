import test from 'node:test';
import assert from 'node:assert/strict';
import {hierarchyGeometry,proteinContextUrl,displayValue} from './helpers.mjs';

test('hierarchy keeps every profile once without inventing a chronological order',()=>{
  const g=hierarchyGeometry(['lung','liver','brain'],[[1,2,2,2],[0,3,4,3]]);
  assert.deepEqual(g.order,[0,1,2]);assert.equal(g.nodes[g.root].distance,4);
  assert.equal(g.nodes[0].label,'lung');
});
test('malformed hierarchy cannot duplicate, omit or reverse distances',()=>{
  assert.throws(()=>hierarchyGeometry(['a','b','c'],[[0,0,1,2],[1,3,2,3]]));
  assert.throws(()=>hierarchyGeometry(['a','b'],[]));
  assert.throws(()=>hierarchyGeometry(['a','b','c'],[[0,1,3,2],[2,3,1,3]]));
});
test('zero distance does not manufacture separation',()=>{
  const g=hierarchyGeometry(['a','b'],[[0,1,0,2]]);assert.equal(g.nodes[g.root].distance,0);
});
test('only verified-format Ensembl identities make protein links',()=>{
  assert.equal(proteinContextUrl('ENSG00000141510.19'),'https://www.proteinatlas.org/ENSG00000141510');
  assert.equal(proteinContextUrl('7157'),null);assert.equal(proteinContextUrl('../../gene'),null);
});
test('unassessed values stay different from measured zero',()=>{
  assert.equal(displayValue(null),'Not assessed');assert.equal(displayValue(0),'0');
});
