"""Read-only loopback normal-reference workstation; rejects stale model artifacts."""
from __future__ import annotations

import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import importlib
import json
from pathlib import Path
import sys
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def bootstrap(root):
    report_path = root / "normal_reference/model/aggregate_report.json"
    if report_path.is_file():
        sys.path.insert(0, str(root))
        verifier = importlib.import_module("normal_reference.model.display")
        report = verifier.load_verified_report(root)
        if report.get("schema") != "normal-reference-validation-v1":
            raise ValueError("Unsupported normal-reference report schema")
    else:
        report = {"schema": "normal-reference-validation-v1", "status": "pending",
                  "reason": "Audited source acquisition and normal-only preparation are still in progress.",
                  "references": []}
    for key, name in (("inventory", "existing_rna_inventory.json"),
                      ("resource_roles", "resource_roles.json")):
        path = root / "normal_reference/compatibility" / name
        report[key] = read_json(path) if path.is_file() else None
    report["source_contracts"] = {}
    for name in ("input_contract.json", "eligibility_contract.json", "acquisition_amendment.json"):
        path = root / "normal_reference/source" / name
        if path.is_file():
            report["source_contracts"][name] = read_json(path)
    return report


def handler_for(root):
    static = {"/": (HERE / "index.html", "text/html; charset=utf-8"),
              "/styles.css": (HERE / "styles.css", "text/css; charset=utf-8"),
              "/app.js": (HERE / "app.js", "text/javascript; charset=utf-8"),
              "/helpers.mjs": (HERE / "helpers.mjs", "text/javascript; charset=utf-8"),
              "/source-styles.css": (root / "tracerx_routes/visualization/styles.css", "text/css; charset=utf-8")}

    class Handler(BaseHTTPRequestHandler):
        def reply(self, status, payload, content_type="application/json; charset=utf-8", download=False):
            if not isinstance(payload, bytes):
                payload = json.dumps(payload, allow_nan=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; object-src 'none'; frame-ancestors 'none'")
            if download:
                self.send_header("Content-Disposition", 'attachment; filename="normal-reference-aggregate.json"')
            self.end_headers()
            self.wfile.write(payload)

        def do_GET(self):
            try:
                host = self.headers.get("Host", "").split(":")[0]
                if host not in {"127.0.0.1", "localhost"}:
                    return self.reply(403, {"error": "Use the local loopback address"})
                path = urlsplit(self.path).path
                if path in static:
                    file, content_type = static[path]
                    return self.reply(200, file.read_bytes(), content_type)
                if path in {"/api/bootstrap", "/api/report"}:
                    report = bootstrap(root)
                    if path == "/api/report" and not report["references"]:
                        return self.reply(503, {"error": "No completed normal-reference report is available"})
                    return self.reply(200, report, download=path == "/api/report")
                return self.reply(404, {"error": "Unknown normal-reference resource"})
            except (ValueError, OSError, ImportError, KeyError) as error:
                return self.reply(409, {"error": f"Normal-reference record cannot be verified: {error}"})

        def do_POST(self):
            return self.reply(405, {"error": "This research view is read-only"})

    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--port", type=int, default=4005)
    args = parser.parse_args()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), handler_for(args.root.resolve()))
    print(f"Normal-reference workstation: http://127.0.0.1:{args.port}/", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
