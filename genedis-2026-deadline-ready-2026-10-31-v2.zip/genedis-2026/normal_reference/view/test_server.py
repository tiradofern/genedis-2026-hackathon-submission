"""Meaningful read-only/publication boundaries, with fictional temporary inputs."""
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Thread
import unittest

from .server import handler_for


class ServerBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), handler_for(self.root))
        self.thread = Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.temp.cleanup()

    def request(self, method, path, host=None):
        connection = HTTPConnection("127.0.0.1", self.server.server_port)
        connection.request(method, path, headers={} if host is None else {"Host": host})
        response = connection.getresponse()
        result = response.status, json.loads(response.read())
        connection.close()
        return result

    def test_absent_model_does_not_invent_reference_or_tumor_points(self):
        status, data = self.request("GET", "/api/bootstrap")
        self.assertEqual(status, 200)
        self.assertEqual(data["status"], "pending")
        self.assertEqual(data["references"], [])
        self.assertNotIn("tumors", data)
        self.assertEqual(self.request("GET", "/api/report")[0], 503)

    def test_present_unverifiable_report_fails_closed(self):
        path = self.root / "normal_reference/model/aggregate_report.json"
        path.parent.mkdir(parents=True)
        path.write_text('{"references": []}')
        self.assertEqual(self.request("GET", "/api/bootstrap")[0], 409)

    def test_donor_and_arbitrary_files_are_not_served(self):
        path = self.root / "normal_reference/source/donor-fixture.txt"
        path.parent.mkdir(parents=True)
        path.write_text("fictional donor")
        self.assertEqual(self.request("GET", "/normal_reference/source/donor-fixture.txt")[0], 404)
        self.assertEqual(self.request("GET", "/../AGENTS.md")[0], 404)

    def test_read_only(self):
        self.assertEqual(self.request("POST", "/api/bootstrap")[0], 405)

    def test_foreign_host_rejected(self):
        self.assertEqual(self.request("GET", "/api/bootstrap", "unrelated.example")[0], 403)


if __name__ == "__main__":
    unittest.main()
