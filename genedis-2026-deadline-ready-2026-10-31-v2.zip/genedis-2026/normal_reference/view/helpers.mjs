export function hierarchyGeometry(labels, linkage) {
  const n = labels.length;
  if (!n) return {nodes: [], order: [], root: null};
  const nodes = labels.map((label, i) => ({id:i, label, distance:0, children:[]}));
  linkage.forEach((row, i) => {
    const [a,b,distance] = row;
    if (![a,b].every(x=>Number.isInteger(x)&&x>=0&&x<n+i) || !Number.isFinite(distance) || distance<0) throw Error('Invalid similarity hierarchy');
    if(distance+1e-10<Math.max(nodes[a].distance,nodes[b].distance))throw Error('Similarity hierarchy distances are not monotonic');
    nodes.push({id:n+i,distance,children:[a,b]});
  });
  if (linkage.length!==Math.max(0,n-1)) throw Error('Incomplete similarity hierarchy');
  const order=[];
  const visit=id=>{const node=nodes[id];if(node.children.length)node.children.forEach(visit);else order.push(id);};
  const root=nodes.length-1;visit(root);
  if(new Set(order).size!==n || order.length!==n)throw Error('Repeated or absent hierarchy profiles');
  order.forEach((id,i)=>{nodes[id].row=i;});
  for(const node of nodes.slice(n))node.row=(nodes[node.children[0]].row+nodes[node.children[1]].row)/2;
  return {nodes,order,root};
}

export function displayValue(value) {
  if(value===undefined||value===null)return 'Not assessed';
  if(typeof value==='boolean')return value?'Yes':'No';
  if(typeof value==='number')return Number.isInteger(value)?value.toLocaleString():value.toLocaleString(undefined,{maximumFractionDigits:4});
  return String(value);
}

export function proteinContextUrl(geneId) {
  const stable=String(geneId??'').split('.')[0];
  return /^ENSG[0-9]{11}$/.test(stable)?`https://www.proteinatlas.org/${stable}`:null;
}
