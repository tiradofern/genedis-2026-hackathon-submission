"""Read-only inventory of the existing TCGA RNA; never fit or project tumors."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

import numpy as np


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def inventory(existing_root):
    data = existing_root / "data/processed/explorer_v0_1"
    manifest_path = data / "prepared_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    for name, expected in manifest["files"].items():
        if digest(data / name) != expected:
            raise ValueError(f"Existing prepared artifact changed: {name}")
    for name, expected in manifest["recipe_files"].items():
        if digest(existing_root / name) != expected:
            raise ValueError(f"Existing preparation recipe changed: {name}")
    bootstrap = json.loads((data / "bootstrap.json").read_text())
    if bootstrap["fingerprint"] != manifest["fingerprint"]:
        raise ValueError("Existing source and preparation fingerprints differ")
    cohorts = {}
    all_patients = set()
    for histology in ("LUAD", "LUSC"):
        cohort = bootstrap["cohorts"][histology]
        samples = cohort["samples"]
        patients = [sample["patient_id"] for sample in samples]
        if len(set(patients)) != len(patients) or all_patients.intersection(patients):
            raise ValueError("Existing patient independence or histology separation failed")
        all_patients.update(patients)
        genes = json.loads((data / f"{histology}_genes.json").read_text())
        ids = genes["rna_ids"]
        if len(set(ids)) != len(ids) or any(not key.isdigit() or int(key) <= 0 for key in ids):
            raise ValueError("Existing RNA stable identifiers are ambiguous")
        with np.load(data / f"{histology}_matrices.npz", allow_pickle=False) as arrays:
            rna = arrays["rna"]
            if rna.shape != (len(samples), len(ids)):
                raise ValueError("Existing RNA dimensions differ from specimen/gene catalogs")
            roles = Counter(sample["role"] for sample in samples)
            if roles != Counter(training=len(arrays["train"]), evaluation=len(arrays["evaluation"])):
                raise ValueError("Existing role denominators differ")
            cohorts[histology] = {
                "independent_patients": len(patients), "samples": len(samples),
                "roles": dict(sorted(roles.items())), "rna_gene_rows": len(ids),
                "missing_rna_measurements": int(np.count_nonzero(~np.isfinite(rna))),
                "existing_adjacent_normal_samples": len(cohort["normal_references"]),
                "source_feature_exclusions": cohort["excluded_feature_rows"],
                "matrix_sha256": manifest["files"][f"{histology}_matrices.npz"],
                "gene_catalog_sha256": manifest["files"][f"{histology}_genes.json"],
            }
    return {
        "status": "existing RNA inventory verified; no new tumor projection",
        "prepared_fingerprint": manifest["fingerprint"],
        "prepared_manifest_sha256": digest(manifest_path),
        "verified_prepared_files": len(manifest["files"]),
        "verified_recipe_files": len(manifest["recipe_files"]),
        "gene_key": "unversioned Entrez ID with original source symbols retained",
        "measurement": "log2(batch-normalized RNASeqV2 RSEM + 1); continuous, not integer counts",
        "cohorts": cohorts,
        "normal_reference_feature_selection_used_tumors": False,
        "tumor_placements_inspected": False,
        "gtex_tpm_comparability": "pending; different processing and units",
        "hlca_count_comparability": "pending; distinct modality and library normalization",
        "cross_resource_gene_mapping": "not attempted before source eligibility/identity audit",
        "adjacent_normals_are_healthy_donors": False,
        "evaluation_is_external_replication": False,
        "existing_artifacts_modified": False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--existing-root", type=Path, required=True)
    parser.add_argument("--out", type=Path,
                        default=Path(__file__).with_name("existing_rna_inventory.json"))
    args = parser.parse_args()
    report = inventory(args.existing_root.resolve())
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n",
                        encoding="utf-8", newline="\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
