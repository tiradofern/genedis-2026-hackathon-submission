# Fernanda–Justin joint reassessment — template

**Unfilled. No PI decision, Justin sign-off, analysis authorization or submission approval is recorded by this template.** Complete after Justin returns his independent review. Suggested result path: `reviews/pi-justin-reevaluation-2026-10-31.md`.

- Review participants and date/time/timezone:
- Original release: `c0599df2417e0d60126face89a054b1c18238c24`
- Justin's first-pass review commit/document:
- Revised plan/results/package under consideration:
- Remaining deadline and agreed scope:

## Response and decision matrix

| Justin issue ID | Evidence checked in reassessment | Justin's recommendation | PI decision: accept / reject / defer / investigate | Rationale or dissent | Authorized revision, owner and deadline | Resolution evidence |
|---|---|---|---|---|---|---|

Do not close an issue without its stated acceptance evidence. An investigated suggestion can remain inconclusive. Preserve rejected/deferred recommendations and the reason rather than silently deleting them.

## Scientific decisions requiring PI adjudication

- Current submission scope and exact claims:
- Broader MSI hypothesis and falsifiable next study:
- Operational definitions and acquired-resistance eligibility:
- Cohort gate decisions; any permitted descriptive versus inferential use:
- Proposed protocol amendments before any new effects, if applicable:
- Priorities before submission versus after the hackathon:
- Distribution/license issues relevant to the intended delivery:

No new scientific analysis is authorized unless the PI explicitly records its bounded scope. A recommendation or unresolved discussion is not approval. Existing outputs, frozen definitions and negative findings remain preserved.

## Re-evaluation after any authorized revision

| Acceptance check | Evidence and revised commit | Justin's second-pass assessment | PI assessment | Remaining limitation |
|---|---|---|---|---|
| Claims match actual measurements and completed work | | | | |
| Major scientific/technical concerns addressed or claims narrowed | | | | |
| Tested-negative, untested and inconclusive results distinguished | | | | |
| Reproducibility and artifact provenance accurately stated | | | | |
| Package/figures/terms and required checks consistent | | | | |

## Final disposition

- Joint recommendation: ready / revise / hold:
- Unresolved blockers or documented dissent:
- Exact final archive/commit/hash, if ready:
- Justin's second-pass review/sign-off:
- Fernanda's scientific decision:
- **Separate explicit PI authorization to send/upload this exact package:** pending unless recorded here or directly in the active conversation.

Retain earlier versions. If final claims or methods change, prepare a newly versioned package and review its changed content; do not overwrite the frozen original archive or infer submission approval from readiness alone.
