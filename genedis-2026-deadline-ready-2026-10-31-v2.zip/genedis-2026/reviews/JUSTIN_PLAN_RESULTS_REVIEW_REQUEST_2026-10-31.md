# Justin: independent plan and results review, followed by joint reassessment

**Requested by:** Fernanda, October 31, 2026.

**Status:** review requested; Justin's acceptance, findings and sign-off have not been received. Existing AI review reports are supporting material, not Justin's endorsement.

## Material under review

Review the scientific plan and actual results at frozen release commit **`c0599df2417e0d60126face89a054b1c18238c24`**, on `release/genedis-2026-10-31`. The coordination branch `review/justin-plan-results-2026-10-31` adds this request/templates; it does not replace or amend the scientific release.

The frozen archive is `genedis-2026-submission-review.zip`, SHA256 **`3404accaec3e5a8f42a65ee88d9f2198c9871efefcb6601edb922561950e53b2`**. Its reported size is 2,187,519 bytes. If reviewing a different snapshot, identify its exact commit/hash. If the archive is not available in your checkout, review the committed files and explicitly state that you did not inspect the archive bytes.

The immediate task is to evaluate, challenge and recommend. Preserve source code, outputs, frozen definitions, historical negatives and closed inference gates. Do not launch new biological discovery, retrieve new datasets, change cohort eligibility, edit the release, merge branches, change access or submit to organizers under this review request. Lightweight software checks may be run in an isolated workspace; distinguish checks actually executed from reports merely inspected.

## Read in this order

For a quick first pass, prioritize the scientific summary, recovery report, cohort feasibility report and figures. State that the full protocol/source audit is incomplete if you cannot perform it. Do not label a quick read a full independent reproduction.

1. [Scientific summary](../submission/SCIENTIFIC_SUMMARY.md), [reviewer entry point](../submission/REVIEWER_README.md) and [project inventory](../submission/PROJECT_INVENTORY.md).
2. [Broader recurrence-first plan](../docs/PAN_CANCER_MSI_RESEARCH_PLAN_2026-10-30.md), then [current paired-study protocol](../pilot/PROTOCOL_2026-10-31.md). Distinguish the overarching hypothesis, broader study and bounded pilot; the preserved older proposal is not evidence of execution.
3. [NSCLC recovery report](../release_recovery/README.md), [complete program definitions](../release_recovery/program_definitions_2026-10-31.tsv), [core comparison](../release_recovery/core_recovery_2026-10-31.json) and [software checks](../release_recovery/checks_2026-10-31.json).
4. [Cohort feasibility report](../pilot/cohorts/FEASIBILITY_REPORT_2026-10-31.md), per-cohort gates, sample/pair manifests and original-publication/accession references. Check the evidence behind the gate decisions independently.
5. [Figures and processed features](../submission/figures/), [accepted pinned archive replay](../submission/archive_replay_pinned_2026-10-31.json), [retained failed attempt](../submission/REPLAY_ATTEMPT_NOTES.md), [terms](../submission/RELEASE_TERMS_AND_PROVENANCE.md) and [organizer requirements](../submission/requirements_audit.md).
6. Historical aggregate route/normal-reference reports linked by the inventory; then [adversarial review](PAN_CANCER_MSI_ADVERSARIAL_REVIEW_2026-10-31.md) and [AI final review](../independent_review/FINAL_RELEASE_REVIEW.md). Form your own assessment rather than treating their verdicts as authoritative.

## Questions to answer independently

### Scientific rationale and plan

- Does the MSI hypothesis add a testable distributed-coordination question beyond known pathway activity, cancer hallmarks and ordinary cancer biology? What would disconfirm or materially narrow it?
- Are resistant-state recurrence, paired pre/post change, enrichment against non-resistant comparators, evidence of selection and functional causality kept distinct? Missing responder cohorts limits specificity; it is not inherently fatal to recurrence discovery.
- Are mutations, CNA, retained genomic regions, regulatory states and transcriptional programs defined and matched to the assays that can measure them? Is any RNA result being overstated as genomic conservation?
- Are coordination within a program and recurrence across independent cohorts tested separately? A fixed Hallmark mean score does not by itself establish a new coordinated MSI. Are lineage, gene/pathway size and overlap, cancer-associated background, immune/stromal composition and technical artifacts treated adequately?
- Are the six-program choice, common gene universe, coverage gates, rank scoring, paired estimand, sign-flip assumptions, directional multiplicity, replication rule and single-cohort fallback scientifically defensible? Identify power/precision limits and what would require an amendment before effects.

### Cohort decisions: challenge the gates

- Separate true patient/specimen ineligibility from unresolved metadata and from artifacts of the particular public retrieval route. Which blockers affect individuals, the whole cohort, inference only or descriptive use?
- For GSE65185, verify the Pt21 baseline exclusion, Pt22 identity conflict, Pt20 regimen conflict, Pt10 platform discrepancy, specimen timing, site and treatment-line evidence. Do not assume titles resolve contradictory descriptions.
- For GSE248249, verify the 13 candidate pairs, four same-broad-site pairs, clinical-response crosswalk, progression timing and actual technical-processing evidence. Matching organ labels is not verified same-lesion sampling; filename groups are not batch labels.
- Is a PR/CR-only acquired-resistance definition appropriate to each source and therapy, or could documented durable SD also qualify under a justified clinical definition? Do not silently equate SD with primary resistance or amend eligibility after results.
- Missing batch labels does not prove time-batch confounding. Missing the authors' final adjusted matrix alone is not an automatic veto. State what evidence demonstrates an invalid comparison, what remains unknown, and the smallest defensible remedy.
- Are current no-go decisions warranted, overly broad or insufficiently cautious? A recommendation to reopen must identify the evidence and prospective amendment needed; it does not itself reopen analysis.

### Results and reproducibility

- Verify the reported 507 LUAD/481 LUSC backbone, frozen roles, 25 provisional programs and 1,904 loading rows to the extent possible. Which claims are confirmed, uncertain or contradicted?
- Separate source integrity, same-environment reconstruction, historical aggregate agreement, exact historical membership identity, program stability/holdout preservation and biological validation. Which were actually demonstrated?
- Check that no paired program effects were run and all 12 planned directional hypotheses remain untested. Gate failure is not a negative molecular finding.
- Do the historical route negatives and failed HLCA rejection gate remain visible and correctly bounded? Their failure does not by itself refute distributed functional convergence.
- Do figures, summaries and the linked multi-omics explorer accurately represent measurements, uncertainty, missing data and scientific novelty? Is data-layer linkage being mistaken for a validated joint model?
- Is the package independently usable and appropriately licensed for the intended private evaluation? If you rerun anything, record environment, exact commands, results and blocked checks. Do not count inspected AI logs as your own reproduction.

## Return a prioritized recommendation

Use [the review template](JUSTIN_PLAN_RESULTS_REVIEW_TEMPLATE_2026-10-31.md) to create **`reviews/justin-plan-results-2026-10-31.md`** on a separate findings branch. Leave the supplied template unfilled in the shared coordination branch. A written review pasted back to Fernanda is also acceptable; do not block review on Git mechanics.

Give separate verdicts for:

1. The current NSCLC reconstruction/feasibility submission: ready, revise, or hold, with evidence.
2. The longer-term MSI research design: proceed, narrow, or redesign, with a falsifiable next study.
3. Any proposed new analysis: recommend, defer, or reject, with prerequisites and expected scientific value.

For each material issue include an ID, exact evidence, consequence, proposed correction, acceptance criterion, effort estimate and whether it matters before submission or afterward. Identify the three highest-priority actions. Explicitly identify disagreements with existing AI reviews; agreement is not required. A credible submission may remain a reconstruction/feasibility report if no resistance inference is justified.

## Joint reassessment with Fernanda

After the independent review is returned, Fernanda, Justin and Codex will review the findings together. Codex will distinguish supported corrections from unverified suggestions and prepare a response matrix using [the joint-decision template](PI_JUSTIN_REEVALUATION_TEMPLATE_2026-10-31.md). Fernanda retains scientific adjudication; recommendations do not automatically become decisions or authorize new analyses.

Agree which issues to accept, reject, defer or investigate; record dissent and evidence. Define any bounded revisions and owners. Re-evaluate the revised claims/results and unresolved blockers against acceptance criteria, then record whether the exact revised package is ready for final PI approval. Changes affecting claims, methods or eligibility require explicit decisions and versioned amendments; preserve the original release and negative findings. Justin should have an opportunity to check whether his substantive concerns were resolved.

If still targeting today's deadline, proposed checkpoints are first review by **13:00 Eastern**, joint reassessment by **15:00**, and analysis/code/claims freeze **16:00**, leaving packaging by **17:00**, target submission **17:30**, hard cutoff **18:00**. These are review targets for agreement, not an assertion that Justin accepted them. If time is shorter, narrow scope or claims instead of bypassing review or starting an unreviewed analysis.

**No organizer delivery before this review process and Fernanda's explicit approval of the exact final package.** No message to Justin or the organizers has been sent by creating this guide.

## Prompt Justin can paste into his own Codex session

> Open the private `tiradofern/genedis-survival-islands` repository and preserve any local changes. Fetch the `review/justin-plan-results-2026-10-31` branch, read AGENTS.md and `reviews/JUSTIN_PLAN_RESULTS_REVIEW_REQUEST_2026-10-31.md`, and independently evaluate the frozen scientific release at c0599df2417e0d60126face89a054b1c18238c24. Review both the plan and actual results; challenge existing AI conclusions, including cohort gates. Distinguish verified findings, assumptions and untested hypotheses. Give separate submission and longer-term research verdicts, evidence-linked issues and prioritized recommendations with effort/acceptance criteria. Use the supplied template to write `reviews/justin-plan-results-2026-10-31.md` on a new findings branch, or return the report as text. Do not change scientific code/results, run new biological analyses, download datasets, merge, change access or submit. Record any lightweight checks actually performed and all limitations. Prepare questions and decisions for a subsequent reassessment with Fernanda. The report requires my review and sign-off as Justin; do not invent my conclusions or approval.
