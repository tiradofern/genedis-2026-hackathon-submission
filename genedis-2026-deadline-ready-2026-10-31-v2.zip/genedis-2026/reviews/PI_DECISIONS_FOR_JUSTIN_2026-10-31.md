# Research-design decisions for Justin's review

**Status:** Fernanda's current scientific preferences, consolidated from the October 31 discussion for Justin to assess. They are not jointly signed off, a newly frozen operational protocol, or completed analyses. Fernanda requests one consolidated response before further scientific commitments or implementation.

The frozen scientific release remains **`c0599df2417e0d60126face89a054b1c18238c24`**. Its archive SHA256 remains **`3404accaec3e5a8f42a65ee88d9f2198c9871efefcb6601edb922561950e53b2`**. No source code, datasets, outputs, old protocols or archive bytes are changed by this memo.

Justin's [first findings draft, PR #12](https://github.com/tiradofern/genedis-survival-islands/pull/12), is at commit `ddf8ec2c021b1557ceb6cd84446ff51ce5b8281a`. It is available and has been discussed. The file still identifies itself as AI-assisted with Justin's personal sign-off pending; this memo does not infer endorsement from that draft or from its author account. These subsequent interview decisions are new material for his review.

## Proposed scientific direction

In reliably identified malignant cells from different **non-NSCLC cancer types** with clinically documented **acquired resistance to similar therapies**, identify recurring biological programs across independent patients. Begin with predefined published programs; examine shared contributing genes after the functional screen. Freeze externally selected candidates before testing them in independent NSCLC patients resistant to the same treatment family.

The order is **pan-cancer discovery outside NSCLC → recurrent functions → shared-gene characterization → independent NSCLC testing**. Cancer types and the first treatment family will depend on verified public-data feasibility. Breast and melanoma are examples, not selected or mandatory cohorts. No suitable new dataset combination has yet been verified.

## Decisions to assess together

These are PI preferences, not statements of Justin's agreement. Please identify each response by its decision ID.

| ID | Current PI preference | Boundary or implication for the protocol |
|---|---|---|
| D01 | Focus initially on programs operating within cancer cells. | A signal driven by immune/stromal admixture does not establish a malignant-cell-intrinsic program. Environmental signaling expressed within malignant cells can still be relevant. |
| D02 | Identify malignant cells first; prioritize suitable single-cell RNA data. | Audit how cells were identified, retain ambiguous labels and use independent patients as the biological replicates. Existing bulk NSCLC work remains supporting/exploratory material. |
| D03 | Search across multiple non-NSCLC cancer types before testing in NSCLC. | Reserve independent NSCLC patients for the follow-up. Do not use their results to select/tune the externally discovered candidates. Preserve the earlier 988-case project separately. |
| D04 | Candidate nomination requires recurrence in at least two different cancer types. | This is a minimum breadth rule, not a two-patient rule or a claim of universal conservation. Patient-level reproducibility, uncertainty and corrected statistical evidence still need specification. |
| D05 | Include only clinically documented acquired resistance initially: initial benefit followed by progression. | Primary resistance and scheduled on-treatment specimens are not interchangeable with acquired resistance. Source-compatible definitions, duration and durable-SD/lesion-level criteria remain to be operationalized. |
| D06 | Compare different cancers exposed to similar treatment mechanisms. | This changes the initial emphasis from different mechanisms to comparable mechanisms across tissues. Define similarity before selecting molecular results; broad labels such as 'targeted therapy' alone are insufficient. |
| D07 | Include paired pretreatment/resistance specimens and resistance-only specimens with adequate clinical histories. | Preserve pairing. Only paired patients contribute within-patient changes. Resistance-only samples can contribute resistant-state recurrence. |
| D08 | Compare resistance-stage programs between those two specimen-availability groups. | Missing a baseline is a data-availability distinction, not a separate biological resistance category. Assess cancer, treatment, site, sampling and processing comparability; do not manufacture missing baselines or unsupported adjustments. |
| D09 | Start with shared biological functions, then identify the genes contributing in common. | Functional convergence can involve different genes. RNA activity infers candidate programs; it is not direct proof of function, genomic conservation, selection or causality. |
| D10 | Use published gene groups for the primary analysis; keep other discovery tracks separate. | Choose a small justified panel before effects. Evaluate the existing 25 provisional NSCLC programs separately. Learn new groups only in suitable discovery data, then freeze/test in independent patients. Activity change alone does not establish coordination. |
| D11 | Choose the first treatment family using the strongest well-documented public datasets. | No treatment family or new accession is selected yet. Audit clinical histories, patient/specimen independence, malignant-cell identification, modalities, access/terms and sample-level metadata. Do not force a combination if the data gate fails. |
| D12 | Accept well-supported RNA-based identification of cancer cells. | Audit supporting evidence and uncertainty; separate DNA confirmation is not mandatory. Study labels are not accepted automatically or treated as genetic ground truth. |
| D13 | Do not require a program to occur in most malignant cells for candidate eligibility. | This explicitly withdraws the briefly adopted majority-cell requirement. Smaller malignant populations remain eligible when patient-level recurrence and measurement are supported. |
| D14 | Where measurable, report within-sample malignant-cell prevalence and uncertainty. | '>50%' means 'most'; '≥two-thirds' is a stricter sensitivity analysis, not an eligibility cutoff. Bulk RNA alone does not establish a percentage of cancer cells. Define program activity separately from individual-gene detection. |
| D15 | Include well-matched tumors still benefiting from the same therapy as an optional secondary comparison. | Recurrence among acquired-resistant tumors remains primary. Missing responders does not block recurrence discovery. Comparator enrichment is a separate endpoint; timing and treatment comparability still matter. |
| D16 | First NSCLC testing should use resistance to the same treatment family as external discovery. | Preserve treatment comparability while assessing transfer across tissue origins. LUAD/LUSC distinctions remain explicit; independent patients and sampling/technical QC are required. |

## Open choices: ask for Justin's recommendations, not another broad interview

1. **NSCLC replication criterion:** Is recurrence of the same program sufficient for initial replication, with shared genes strengthening it, or must both the program and a shared core gene set replicate? Fernanda has not answered this last question. Do not record an inferred default as her decision.
2. **Feasible cohorts and mechanism:** Which publicly accessible datasets can actually support D01–D12 and D16? None are newly adjudicated. Classify missing metadata separately from demonstrated invalidity and patient-specific exclusions.
3. **Statistical specification:** Recommend patient/sample minimums from precision and feasibility; define score/coordination/structural claims, background/null models, multiple-testing families and success/non-support/inconclusive outcomes. The old six-program/12-direction paired pilot and its sample-size arithmetic do not automatically apply to this new single-cell design.
4. **Background and comparators:** Make ordinary cancer biology, tissue lineage, technical factors and residual composition explicit. An ordinary-cancer reference is not automatically a documented non-resistant comparator. Background-excess analysis supplements the primary recurrence question.
5. **Track separation and leakage:** The 25 legacy programs were derived from bulk NSCLC. Specify how they can be investigated without silently influencing external discovery and then being called independently validated on reused NSCLC patients. Separate predefined testing, post-screen gene characterization and exploratory network learning.
6. **Practical scope:** Recommend the smallest defensible next study and what belongs after the hackathon. A new research direction is not a newly completed submission result. Preserve the current reconstruction/feasibility submission while reviewing any proposed revision.

## Requested return: one consolidated review

Please provide:

- A short overall verdict: **support / support with amendments / redesign / not feasible with available evidence**.
- A response to D01–D16: **support / amend / disagree / needs evidence**, with concise reasons and sources for substantive concerns.
- The three highest-priority amendments, each with evidence, consequence, proposed wording/design, acceptance criterion, dependency and estimated effort.
- Recommended answers to the six open items above, clearly identifying what is a preference, a methodological requirement, or an unverified feasibility assumption.
- What should change in the current submission, what should remain future work, and which additional PI decisions are genuinely necessary.
- Your personal review/sign-off status and any AI assistance/checks, distinguishing records inspected from checks actually rerun.

Suggested response path: `reviews/justin-response-to-pi-decisions-2026-10-31.md` on a separate findings branch. Returning the text to Fernanda is equally acceptable. No response or approval is pre-filled here. Use the [joint reassessment template](PI_JUSTIN_REEVALUATION_TEMPLATE_2026-10-31.md) after the response to record evidence, accept/amend/reject/defer decisions, dissent and any authorized revision scope.

## Preservation and authorization

This is review coordination only. No new dataset acquisition, molecular scoring, biological analysis, cohort-gate reopening, code modification, branch merge, permission change or organizer delivery is authorized by this memo. The existing two pilot gates remain closed, all 12 old directional hypotheses remain untested, and all provisional/negative findings are preserved. Scientific decisions remain under Fernanda's direction; Justin's recommendations receive joint reassessment before implementation. Final organizer delivery requires explicit approval of an exact package.

No direct message or review comment has been sent to Justin by preparing this document. The private repository link can be shared through the collaborators' existing access.

## Prompt for Justin's own session

> Read `reviews/PI_DECISIONS_FOR_JUSTIN_2026-10-31.md` on branch `review/pi-decisions-for-justin-2026-10-31`. These are Fernanda's updated preferences after discussion of PR #12, not jointly approved methods or new results. Assess all D01–D16 in one consolidated response, identify amendments and genuine evidence gaps, and recommend answers to the open items. Preserve the primary recurrence objective, the withdrawn majority-cell eligibility rule, patient independence and external discovery/NSCLC validation separation. Distinguish proposed research from the frozen release at c0599df. Do not run new biological analyses, download datasets, modify source/results, merge, change access or submit. Write your findings on a separate review branch or return text, disclose checks/tool assistance and leave personal sign-off pending until you have reviewed the report. Prepare the response for joint reassessment with Fernanda.
