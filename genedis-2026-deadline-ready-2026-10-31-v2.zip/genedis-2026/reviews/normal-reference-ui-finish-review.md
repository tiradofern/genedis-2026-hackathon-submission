# Normal-reference UI finish review

Reviewed October 18, 2026. Independent, bounded finish review of the normal-reference extension on `analysis/normal-reference-first`. No implementation, scientific model or source artifact was changed.

Evidence: applicable root `AGENTS.md`, `PRODUCT.md`, `DESIGN.md`, the surface brief, the opening direction contract in `normal_reference/view/index.html`, the four scoped frontend files, the implementation handoff, `docs/NORMAL_REFERENCE_VIEW.md`, and the craft floor. Visually inspected the actual supplied `normal-gtex-final.png`, `normal-hlca-final.png`, and `normal-validation-final.png` screenshots at 1564 × 736. No browser session or additional detector was run.

## Direction fidelity

The built surface follows the committed mineral-white, marine-teal scientific workstation. Flat ruled panels, restrained evidence amber, system typography and compact native controls preserve the established identity. The map/hierarchy/linked-profile composition is an additive analysis view. It does not introduce a competing visual concept or decorative scientific imagery.

## Quality bar and composition

The HLCA screenshot puts reference choice and an explicit **Normal validation gate failed** assessment before exploration. The side-by-side context sections leave the plots visible in the first viewport. The GTEx screenshot demonstrates selected Lung linkage between map, hierarchy and the evidence inspector; the long hierarchy scrolls within its panel. The validation screenshot keeps control scopes, unsupported populations and study-transfer denominators readable in ruled tables. No material clipping or horizontal page overflow is evident in the supplied desktop renders. The GTEx screenshot begins below the header, so it alone does not verify that header state.

## Craft floor and accessibility

The inspected desktop views retain readable contrast, clear hierarchy and consistent spacing without ornamental treatments. Standard labeled selectors provide an alternative to selecting small plot marks. The code supplies focusable SVG group buttons, Enter/Space activation, `aria-pressed`, visible focus treatment and focus restoration after selection. Native disclosures expose detailed evidence; loading, unavailable, empty and error copy is present. Builder-reported keyboard selection and desktop overflow checks are consistent with this source inspection; they were not independently rerun here.

Responsive rules are present, but **mobile rendering remains unverified** because the established browser did not accept the requested viewport override. This review makes no mobile, screen-reader or exhaustive accessibility certification.

## Task and content behavior

Reference selection keeps GTEx bulk and Healthy-only HLCA as separate models with their own units, distances and records. Profile selection links both plots, held-out evidence, neighbors and descriptive features. Donor roles, rejection controls, per-profile coverage, bootstrap scope, study transfers and exact provenance are findable through the evidence section and disclosures.

The high HLCA represented-class recall is accompanied by the failed locked gate, 9 fitted / 11 primary-source classes and explicit limited validation scope. The validation screenshot discloses all three unsupported mesothelium test profiles falsely accepted as fibroblast lineage, plus transfers ranging from 42.3% to 100% recall. It does not turn assignment coverage into correctness or imply general off-reference detection. GTEx limitations and failed checks are rendered through the same assessment/evidence path; the review did not independently recalculate its reported 67.6% macro-recall or rejection performance.

LUAD/LUSC readiness remains a separate control and record. No tumor placements, ancestry, cell-origin, cell-fraction, functional-program or biological-tier claims are introduced by the reviewed UI. Source/model correctness and scientific gate adequacy remain outside this visual finish review.

## Disposition and verdict

**Ship for the reviewed desktop, local research workflow. No material finish fix required.** Preserve the failed-gate and unsupported-population disclosures. Mobile remains unverified and must not be described as tested. This disposition approves the bounded interface finish; it does not declare either reference biologically validated or authorize tumor projection.
