# Justin project review

Reviewer: 

Review date: 

Codex session or other tools used, if relevant: 

Package reviewed: GeNeDis Justin Codex review package prepared October 15, 2026; audit snapshot October 14, 2026.

## Recommendation

Choose one: proceed conditionally / narrow the question / redirect.

Explain the main reason in a short paragraph. State whether the selected acquired-resistance focus is supportable and what must happen before analysis.

## Facts checked and unresolved claims

| Claim | Confirmed / uncertain / contradicted | Exact evidence | Implication |
|---|---|---|---|

## Critical validity blockers

For each: describe the issue, exact evidence, consequence for inference, concrete remedy or decision, and the condition for closing the item. Write “none identified in the reviewed scope” only if that is the actual conclusion.

## Major issues and useful improvements

| Priority | Finding | Evidence | Why it matters | Proposed action |
|---|---|---|---|---|

## Minimal analysis proposal

- Biological question and estimand:
- Samples and exclusions:
- Expression annotation and preprocessing:
- Pathway/module definition and reference baseline:
- Statistical model, effect, and uncertainty:
- Multiple-testing plan:
- Batch, sampling-site, and tissue-composition sensitivity:
- Independent comparison and permitted interpretation:
- Genomic context and exact integration claim:
- Criteria for proceeding, narrowing, or stopping:

## Proposed contributions

| Proposed contributor | Bounded work package | Inputs | Deliverables and acceptance criteria | Dependencies |
|---|---|---|---|---|

These proposals have not been assigned until the collaborators agree.

## Ordered next actions

1. 
2. 
3. 

## Review provenance

Files and publications inspected:

Commands actually executed and results:

Additional downloads or external checks, if any:

Items that could not be verified:

Working-copy changes, if any:

Questions for Fernanda and Justin to decide together:
