# PI resolutions following Justin's decision review

**Status:** four substantive scientific decisions made by Fernanda after reading the [response in PR #13](https://github.com/tiradofern/genedis-survival-islands/pull/13), reviewed at commit `88bac8252520387ebbec9ac7956528e24d6b8cab`. This records PI decisions; it does not claim Justin's subsequent agreement or personal sign-off. The source draft still marks his sign-off pending.

| Item | PI decision | Operational consequence |
|---|---|---|
| NSCLC replication | First test whether malignant cells use the same biological strategy; investigate individual-gene matching afterward. | Program-level recurrence is the primary replication endpoint. A shared core-gene set is additional evidence, not a mandatory conjunction. Fix confirmatory gene hypotheses before NSCLC results; label later characterization exploratory. RNA program recurrence does not establish a causal strategy. |
| Pre-existing programs | A program may qualify initially even if present before treatment. Pretreatment comparisons inform understanding and prioritization, not access to candidate status. | Keep observed recurrence and additional temporal evidence distinct. A difference from untreated/reference tumors is not mandatory for initial nomination. Calibrate measurements and relevant nulls, label ordinary-cancer-compatible observations, and reserve resistance-mechanism claims for functional evidence. Optional responder comparisons remain separate. |
| Initial clinical benefit | Durable stable disease counts alongside complete and partial responses. | Use therapy-specific, source-supported duration rules; preserve CR/PR/SD strata. Do not impose one universal six-month rule across therapies or equate missing information with primary resistance. |
| End-to-end feasibility | Verify a feasible non-NSCLC discovery plus independent NSCLC validation combination before molecular discovery. If it cannot be verified, revise scope before selecting candidates. | At least two distinct non-NSCLC discovery cancers and an independent NSCLC cohort under comparable treatment mechanisms must pass the clinical/access/measurement gate. No scoring or candidate selection while that gate is unresolved. |

## What is not adopted automatically

The new single-cell study has no approved numeric patient minimum, final panel, score threshold, coordination statistic, correction family or minimum meaningful effect. The old six-program/12-direction bulk pilot is not transferred automatically. Justin's proposed 6-, 10-/20- and NSCLC sample-size rules are planning suggestions requiring endpoint-specific justification, not universal eligibility criteria. An untreated reference is not made mandatory for observed recurrence. A patient's own pretreatment sample is appropriate for the paired-change estimand; independently learned calibration thresholds are a different issue.

Majority-cell presence remains withdrawn as candidate eligibility. Report prevalence among sampled malignant cells with uncertainty where reliably measurable: '>50%' is the descriptive meaning of 'most', and '≥two-thirds' is a sensitivity threshold. Smaller malignant populations remain eligible. Environment-responsive programs expressed within malignant cells are not automatically cell-autonomous mechanisms.

## Authorized next step and actual result

The latest instruction authorizes a public-record/clinical-metadata feasibility audit. The [bounded gate report](../docs/DISCOVERY_VALIDATION_GATE_2026-10-31.md) records the sources checked and the specific access, clinical-history, regimen and modality obstacles. **A complete qualifying combination is not yet verified.** This is an inconclusive feasibility result, not proof of absence or a negative molecular finding.

No new expression matrix or raw molecular dataset was downloaded, scored or analyzed. No new gene program or candidate list was selected. The frozen release `c0599df`, its archive and all previous negative findings remain unchanged; both old bulk-cohort gates stay closed.

## Request for the next joint reassessment

Justin can assess whether the gate evidence supports the proposed revised immediate scope: **metadata feasibility and the preserved NSCLC reconstruction, with molecular discovery deferred until the complete combination passes**. Any reduced discovery breadth, change in therapy matching, protein-only validation or substitution of scheduled treatment samples would change the scientific question and needs a documented PI decision before candidate selection.

No direct message, review comment, merge, access change or organizer submission is made by this record. External delivery still requires explicit PI approval of an exact package. The new study direction and feasibility report are planning evidence, not newly completed biological results for the frozen submission.
