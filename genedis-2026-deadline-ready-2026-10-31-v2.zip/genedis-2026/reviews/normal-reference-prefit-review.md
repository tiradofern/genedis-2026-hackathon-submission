# Normal-reference prefit independent review

Review date: October 18, 2026, America/New_York. Reviewer: independent review subagent. Checkout: `work/genedis-normal-reference`, branch `analysis/normal-reference-first`.

**Disposition: method review completed; actual source-readiness review remains pending. This document does not authorize freezing or fitting.** The root will request a separate final hash-chain/readiness review after the immutable per-resource source contracts and complete source checks exist, before the builder freezes or fits.

This was a bounded review of the investigator's supplied normal-reference handoff, repository instructions, new source contracts, and `normal_reference/model` and `normal_reference/source` code. No reference was fitted, no source was downloaded, and no scientific performance was measured by this reviewer. This review artifact is the reviewer's only edit. Other agents were implementing the pipeline during review; fixes below describe static code inspection, not executed evidence.

## Material findings and disposition

| Finding | Consequence | Disposition at the reviewed snapshot |
|---|---|---|
| HLCA preparation requested `age` and `smoking`, while the actual audited source fields are `age_or_mean_of_age_range` and `smoking_status`. | Available confounding covariates would silently appear unavailable. | Fixed in code: explicit source-to-canonical mapping in `model/prepare.py:261`; `read_h5_strings` handles numeric datasets/categories as well as strings (`prepare.py:239`). Actual field types and resulting strata still need confirmation from the completed source file. |
| The final GTEx sample audit initially dropped available center, RNA extraction batch, expression batch and autolysis fields already present in metadata preflight. | The implemented assessment could not perform the promised technical-covariate strata. | Fixed in code: `source/audit.py:23` retains these fields, plus source pathology notes and vendor QC annotation; `model/prepare.py:96` and `model/run.py:140` preserve/map the descriptive covariates. This does not establish adjusted effects or batch harmonization. |
| Preparation trusted mutable GTEx donor/class metadata and current source receipts without binding them fully to the completed audit. The global audit summary could also change when the other resource completed. | Changed donor/class assignments or a changed receipt could be accepted under an earlier ready status; unrelated source progress could invalidate preparation. | Substantially fixed in code: immutable per-resource audit paths; resource/normal readiness, eligibility and producer checks; receipt/model-input/audit input SHA and size agreement; actual matrix hashing; consumed GTEx sample-manifest hashing (`prepare.py:32`). Prepared source bindings and `run.py:32` rechecks are present. Final amended HLCA range-ledger binding is specifically pending below. |
| Export recomputed trust bindings for the current fit reports without first checking their original completed bytes. | Altered or accidentally replaced validation/aggregate results could be reblessed by `--export-only`. | Fixed in code: `run.py:299` writes a completed-fit manifest; `run.py:318` verifies it before export and also checks prepared/source bindings. No completed fit exists to exercise this chain yet. |
| Unsupported classes were pooled into one rejection count, while their accepted assignments were excluded from represented-class F1/precision denominators. | Readers could mistake conditional metrics for coverage of every atlas population. | Fixed in reporting code: explicit represented-truth metric scope; each unsupported class receives held-out donor/profile counts, rejection evidence, false-assignment classes and donor intervals where estimable (`run.py:243`; config `reporting_scope`). Classes without held-out donors remain unvalidated. |
| Raw-only extraction reused an old prefix and existing same-size cached ranges without persisted version/content proof; an existing on-demand byte file could disagree with its newly recorded hash. | With no whole-original-H5AD checksum, stale or changed cached bytes could acquire a fresh derived SHA and be presented as pinned input. | Fixed on static re-review: `source/download_segmented.py:28` binds and hashes cached ranges and refetches unreceipted ones; `source/extract_hlca_raw.py:44` compares every consumed legacy-prefix block with a freshly guarded read; on-demand bytes are atomically persisted and hashed; retained ledger paths are checked before publication (`extract_hlca_raw.py:195`). Actual completed extraction/range receipts remain pending. |

## Scientific invariants checked

- Donors receive one deterministic source-specific role before training-only selection. All classes/tissues belonging to that donor move together. Donor/class replicates are collapsed before weighting. No cell, sample, tissue or bootstrap slot is presented as a new independent source donor.
- Feature eligibility/ranking, class-balanced donor weights, centering/scaling, PCA, centroids and training radii use eligible supported normal training records. The GTEx and HLCA matrices, transformations and units remain separate. Existing tumor programs, outcomes and tumor values do not select the reference.
- The development numerical lock is written before calibration or test values enter model assessment. Calibration uses one maximum score per independent calibration donor and a finite-sample order statistic. The claimed scope explicitly depends on donor/profile exchangeability and does not imply transport across tissue availability or source shifts.
- Leave-study-out code starts from the complete prepared HLCA gene universe, removes every held-study donor from all nonheldout records, reassigns nonheldout donor roles, reselects features and refits the normal transform, development choice and calibration. Held-study expression does not train those operations. Source-derived annotations and shared upstream atlas processing still limit independence; unresolvable hidden donor overlap remains unknown.
- Intervals resample whole donors. Macro/per-class interpretation is conditional on the actual evaluated populations and supported truth classes. Unassigned predictions remain in represented-class recall denominators. Unsupported population rejection does not become successful class validation.
- Gene identity handling excludes every occurrence of an ambiguous stable key; query matching does not choose the first duplicated identifier. Query projection uses frozen selected genes and training-mean imputation with an explicit missingness guard.
- Gene permutations are destructive technical controls, centroid withholding is a descriptive near-reference control, and centroid-label remapping is a descriptive comparator. None proves cancer discrimination, general biological out-of-distribution sensitivity or an ancestry relationship. Distance rejection sees retained PCA coordinates; departures confined to discarded components can be invisible.
- Conditional donor bootstrap stability is explicitly scoped to frozen features/PCA. The added HLCA training-pipeline bootstrap reselects all-gene features and refits PCA/centroids/hierarchy in whole-donor draws, counts distinct original donors for class eligibility, and retains missing-class draws in support denominators. It does not refit development/calibration/test. GTEx full feature/PCA reselection stability remains untested.
- The empirical development-to-test gate measures internal consistency. It is not an accepted diagnostic/biological accuracy standard and cannot authorize incompatible tumor projection.

## Source state and conditions still pending

At the filesystem checkpoint `2026-10-18T22:40:33-04:00`, `source/gtex_audit.json`, `source/hlca_audit.json`, `source/raw_extraction_review.json` and `model/freeze_manifest.json` were absent. No `model/data` directory existed when checked during artifact preparation. These observations establish neither source completion nor fitted performance. Source acquisition and audit code were still being finalized.

Metadata-only preflight and the explicit eligibility contract report GTEx source coverage of 19,616 samples/946 donors/54 labels, with exact cultured/transformed-line exclusions leaving 18,637 samples/946 donors/52 native tissue labels. HLCA metadata report 584,944 source cells/107 donor IDs; blocking all records of the three tumor-adjacent donors excludes 60,982 cells and leaves 523,962 source-Healthy cells/104 donors before annotation/profile minimums. These are source metadata denominators, not completed matrix-integrity checks, fitting denominators or performance results. Globally healthy or mutation-free donors are not established.

The raw-only HLCA acquisition amendment is scientifically acceptable as a transport change: it retains the same immutable dataset version, original cell/gene population and raw-count units, while omitting normalized `X` and embeddings. It correctly distinguishes the derived subset SHA and guarded range ledger from a **missing full-original-H5AD SHA**. The first-1,000-entry round-trip smoke proof is explicitly insufficient for source readiness.

Before the first preparation/freeze/fit, the separate final review must establish:

1. Actual complete GTEx matrix integrity and the final raw-only HLCA extraction, including complete finite/nonnegative/integer raw-count checks and CSR shape, `indptr`, index-range, cell and gene identity checks. The implemented checks have not been exercised by this reviewer.
2. Final immutable per-resource audits with explicit actual local matrix keys/paths/SHA/sizes; original source contract, eligibility, acquisition amendment, extraction producers, actual retained range receipts and ledger must agree. No original full-H5AD content checksum may be inferred from a subset or multipart ETag.
3. The model loader must verify the actual `source_ranges_manifest_path`/SHA supplied by the final HLCA audit and retain that ledger binding in preparation/export provenance. At this review snapshot `prepare.py:74` bound the amendment but the final ledger-path integration was still pending coordination. This is a prefit completion condition, not a claim that a currently published ready audit is wrong.
4. Consumed GTEx metadata and all preparation/source producer hashes must match the final audited versions. Finalize shared source code before the first immutable audit/preparation/freeze: later producer changes correctly invalidate those artifacts and must not be silently accepted or repaired by reopening test results.
5. Recheck the final source/model/configuration hashes against this review, inspect material changes, then record a separate readiness disposition. **Do not treat this static review or synthetic software tests as permission to bypass that check.**

After those conditions, actual held-out normal validation, calibration, study-transfer checks and stability must run and be reported with any failures. At present there is no observed gate result. Existing TCGA normalized RSEM RNA remains incompatible with direct GTEx TPM/HLCA CPM projection, so tumor projection stays blocked. No RNA ancestry, coordinated-program, cell-of-origin, cellular-fraction or clinical-actionability claim is supported.

## Exact reviewed snapshot hashes

SHA256 inventory captured at `2026-10-18T22:40:56-04:00`. Builders remained active, so later file changes are outside these exact snapshot bindings and require the separate final review. File/line references above identify the inspected implementation around this checkpoint; they may shift with subsequent edits.

| File | SHA256 |
|---|---|
| `normal_reference/model/core.py` | `b4ad524aa8a960325f3bf1ef6fab0d3bcfcf8e265a46958e5d723bca7ad7326c` |
| `normal_reference/model/prepare.py` | `b5f89d2cf93bff1adde11cb720cc37a8954c404ca8afb408aaed82e75e0e2ad4` |
| `normal_reference/model/run.py` | `e8d35e4c0088096a17dc5fdea557adedd2e99fd853bf0497a605837818b18a61` |
| `normal_reference/model/transfer.py` | `02664d4e1daa87bc453413eb2f1fa32b8f1f4f06994667ecad6d1d7fbe0e8bb8` |
| `normal_reference/model/stability.py` | `e1872e227d8a34b87d0ee0008e4553dbb97a7458ff902929c118699d367315f4` |
| `normal_reference/model/freeze.py` | `460c1793f273d78caaee126ff5f53940d5ce1885f524f460e98aec295d1af212` |
| `normal_reference/model/display.py` | `bed840e53e7367e13851c4a212e04ce574ec09ab763755c554d76bb317406bff` |
| `normal_reference/source/audit.py` | `f3e2dff50294e56458302f02778c783792e21a817c0a19fe5ba9833cd304e234` |
| `normal_reference/source/download.py` | `249062b41563d2d7861a6cd7bca038ea31ec2d91f6b95e1d34190d5f6813dfaa` |
| `normal_reference/source/download_segmented.py` | `177f1cc4aafe25012eaba431975ab6ebffe3c9c5dacb88f7afb637769098b25b` |
| `normal_reference/source/metadata_preflight.py` | `66f91360ac8a8bf0a51b7a3361f84a8a22a7fbceabdcef519d03ff5091c0ad18` |
| `normal_reference/source/extract_hlca_raw.py` | `1bac6146eec9a11fab4ab286b1c46cd4b6b9c6618a2f10a5f4f6258ad3788b1b` |
| `normal_reference/source/input_contract.json` | `f3c6716e64158b60ab03dca32837a89de861d17c415ef1d743fcd2df7844189d` |
| `normal_reference/source/eligibility_contract.json` | `0ba1928c0eec4959e913f3c6480d50868cd3928a3eff1dadc66b375f7ec5e421` |
| `normal_reference/source/acquisition_amendment.json` | `d9e24101fa325a0975e4d21bf11d430393b740d2fb9381383b714f057eb79b36` |
| `configs/normal_reference_v0_1.json` | `9378a5ed5d70a1ba444962bc845956c89808d198e99fa49f3d9c5dec3163e08d` |

No tests were run by this reviewer. Existing software-test code was inspected as supporting implementation context; synthetic fixtures cannot establish actual normal-reference validity. No source-ready, frozen-model or fitted-result claim is made here.

## Live GTEx readiness gate, October 18 at 22:51 EDT

**GTEx disposition: PASS for the first normal-only preparation, protocol freeze and prescribed fit under the exact final configuration and producers below.** This supersedes the earlier pending readiness disposition for GTEx only. The ordinary preparation loader must still perform its implemented full matrix SHA check and fail closed if any dependency has changed. This is source/method readiness, not a successful model-validation result. **HLCA remains separately gated and may not be prepared/fitted under this GTEx sign-off.**

At `2026-10-19T02:51:31.024580+00:00`, the reviewer independently verified all 21 files in the final producer snapshot against their actual current bytes; there were zero mismatches. The snapshot is `normal_reference/model/.runtime/pre_fit_producers.json`, SHA256 `0907a4a63947089ef929b08a65eb6adcbebec7ff3ff1e0dd6ca3d32587a64fcd`. The current source producers also all match the completed GTEx audit. `model/freeze_manifest.json`, `model/data/` and `source/hlca_audit.json` remained absent at this check, preserving the before-preparation/freeze/fit boundary.

### Live provenance and source evidence

| Checked artifact or property | Independently checked evidence |
|---|---|
| Immutable ready audit | `source/gtex_audit.json` SHA256 `bfd9613f8100751d5b80b767f4f6d4d67fceaf487370634d1346c0b22ed5f038`; `resource == gtex`, `ready_for_normal_only_preparation == true`, explicit matrix input, input hashes and producer/eligibility bindings present. |
| Original source and eligibility contracts | Current bytes match the ready audit: original contract `f3c6716e64158b60ab03dca32837a89de861d17c415ef1d743fcd2df7844189d`; eligibility `0ba1928c0eec4959e913f3c6480d50868cd3928a3eff1dadc66b375f7ec5e421`. |
| Matrix identity | Ready audit, download receipt and explicit model input agree on `gtex_tpm`, exact local path, 2,592,177,330 bytes and SHA256 `41f2ddf062abc7fced13e01eca661af7e6ca9cc3613709fa3656892513d60555`. The receipt's CRC32C `nr0ZSA==` matches the pinned upstream contract. |
| Source value scan | Completed audit records all 1,463,902,848 TPM values scanned, with zero negative/nonfinite values. Audit completed at `2026-10-19T02:46:31.636947+00:00`. The reviewer inspected this completed evidence and did **not** gratuitously repeat the 2.6GB scan/hash; preparation independently rehashes the actual matrix before use. |
| Actual GCT header | Reviewer read only the header: `#1.2`, 74,628 genes by 19,616 samples, and exact source sample order matching the canonical audit manifest. No expression rows were read for model assessment. |
| Consumed sample manifest | Current SHA256 `e6c090c66b8ef60c6c08240dc8c85a848cfd006fec33cfc833d5fab730b96a34` matches the audit. All sample IDs are unique, identity fields are nonempty, and donor prefixes agree. Every consumed annotation was independently joined back to the original source sample/subject metadata with newline-preserving CSV reads: zero mismatches. |
| Gene manifest and handling | Current SHA256 `af6f705d7b447fee0645c8503eb96049242586ac3e76223754f24d55c54422e7` matches the audit. Independent checks found 74,628 model-valid stable-ID rows, zero invalid rows, zero duplicated stable-key rows and 231 repeated-symbol keys. Symbols remain annotations; first-row symbol selection is not used. Training-expression eligibility/variance losses and the final selected universe remain outputs of the forthcoming preparation. |
| Small original inputs | Reviewer recomputed hashes for the six GTEx metadata/dictionary/description inputs. Actual bytes, receipt and audit agree; pinned MD5/CRC fields agree wherever supplied. |
| Source producer bindings | All seven current audit producer hashes match: `audit.py`, `download.py`, `download_segmented.py`, `extract_hlca_raw.py`, `metadata_preflight.py`, `pin_sources.py`, `requirements-source.txt`. The source hashes in the earlier inventory remain current. |

### Independent donor-role and evaluation-coverage check

Using only canonical metadata and the final seeded SHA256 rule, the reviewer independently recomputed the complete blocked donor split. No donor-level role manifest or model matrix was written.

| Role | Independent donors | Eligible donor/tissue profiles |
|---|---:|---:|
| Training | 568 | 11,119 |
| Development | 142 | 2,908 |
| Calibration | 94 | 1,905 |
| Test | 142 | 2,705 |

Exactly 652 cultured-fibroblast and 327 EBV-transformed-lymphocyte samples are excluded, leaving 18,637 native samples, 946 donors and 52 tissue classes. There are no repeated donor/tissue sample groups. All 52 classes have at least eight training donors under this fixed split, so no class is dropped by the five-training-donor rule.

The split has a material evaluation limit, discovered before expression assessment:

| Class | Training donors | Development donors | Calibration donors | Test donors | Claim limit |
|---|---:|---:|---:|---:|---|
| Cervix - Ectocervix | 16 | 4 | 4 | 0 | Fitted reference population; held-out placement untested. |
| Cervix - Endocervix | 17 | 2 | 4 | 0 | Fitted reference population; held-out placement untested. |
| Kidney - Medulla | 8 | 1 | 2 | 0 | Fitted reference population; held-out placement untested. |
| Fallopian Tube | 19 | 2 | 6 | 2 | Descriptive held-out evidence only. |

The final code now exposes represented-class count, observed-truth macro denominator, included macro labels and zero-truth classes. It explicitly labels a fitted class without test donors `fitted_unvalidated_no_test_donors` and leaves recall/interval unavailable. The frozen split was retained. Test macro metrics will cover 49 observed classes, while development has all 52; comparing the development lower bound with this different class mixture remains a descriptive internal consistency screen, not an equal-population performance comparison or validation of all 52 reference populations. The configured gate, development-selected quantile and acceptance thresholds must not be revised after viewing future test results; a failed screen must remain reported as failed.

### Final model changes reviewed and exact hashes

Since the first review snapshot, the reviewer checked the completed raw-ledger path/SHA binding in preparation, explicit source/eligible profile exclusions, the technical-stratum geometry, observed macro-class denominators, zero-test class labels and final HLCA bootstrap/reporting changes. Technical geometry uses the fixed model and source-class centroids, with donor counts and explicit class/source/covariate confounding; it is descriptive and selects no correction or model parameter. The updated code preserves normal-only fitting, the development/calibration/test order and conditional GTEx stability limits.

| Final file | SHA256 |
|---|---|
| `configs/normal_reference_v0_1.json` | `f4deba242b967a3d8b14b17bc7556654f64cc5e5a1f73d9f70de7297f6f85955` |
| `normal_reference/model/core.py` | `964188dbd8bd1240eea83ba38d0bde3b9e15213371ea1e06093588b34811f103` |
| `normal_reference/model/prepare.py` | `e7c6259d30abbf79bb0d096db80d11bd5e70c307c4bf7a62be09620f122eef88` |
| `normal_reference/model/run.py` | `def0a1bf9eee1e1a5660d960966e60e34bb8f939a14802e4bb70b35ac460851e` |
| `normal_reference/model/stability.py` | `282f1997b3d7e4c605330c35eef8ebe3a60b06c37eeeef4f59c673f1f9d8789a` |
| `normal_reference/model/transfer.py` | `02664d4e1daa87bc453413eb2f1fa32b8f1f4f06994667ecad6d1d7fbe0e8bb8` |
| `normal_reference/model/freeze.py` | `460c1793f273d78caaee126ff5f53940d5ce1885f524f460e98aec295d1af212` |
| `normal_reference/model/display.py` | `bed840e53e7367e13851c4a212e04ce574ec09ab763755c554d76bb317406bff` |

The builder separately reported 13 model checks and compilation passing; the source agent separately reported 11 source guard checks passing. This reviewer did not execute those test suites and does not substitute their synthetic fixtures for actual normal validation. The live reviewer ran read-only metadata/header/hash checks and appended this review only. No preparation, protocol freeze, real model fit, held-out expression assessment or tumor projection was performed by the reviewer. Subsequent material producer/configuration changes invalidate this exact sign-off and require review before use.

## GTEx postfit evidence and display-transport review

After the authorized GTEx fit, the reviewer performed 76 independent checks of the frozen producer snapshot, source and preparation dependencies, prepared file bytes, model/completion/result bindings and saved test predictions: **zero failures**. The saved confusion matrix, macro recall/F1, coverage, accuracy including unassigned and accepted accuracy were independently recomputed from the 2,705 saved test predictions and match the reported values to floating-point precision. Test prediction order, truth labels and donor identities exactly match the saved test-role records. Every saved donor has exactly one role; donor/class profile keys are unique and every record remains source-eligible normal.

The actual preparation retains 946 donors, 18,637 profiles and 52 fitted classes, with the same 568/142/94/142 blocked donor roles and 11,119/2,908/1,905/2,705 profile roles verified before fitting. There are 45,653 training-eligible genes, of which 2,000 were selected; 28,975 genes failed the training positive-expression rule, and 43,653 eligible genes fell below the top-variance rank. Identity, missingness and variability exclusions are zero, and the disjoint feature-loss partition balances. The fitted 20 PCA dimensions explain 0.8330607631 of the weighted training variance.

### Actual results and limits

| Result | Actual saved evidence |
|---|---|
| Internal gate | All three declared checks pass. This remains the prespecified descriptive consistency screen, not a diagnostic or biological adequacy standard. |
| Development choice | Selected quantile 0.80, locked at `2026-10-19T03:02:27.910462+00:00`; development lower targets are macro recall 0.6536490107 and gene-permutation rejection 0.4177429556. No post-test threshold change was requested or made. |
| Calibration | 94 donors/1,905 profiles; fixed donor-maximum threshold 2.6891796978. Donor/profile availability exchangeability remains a transport limitation. |
| Test macro recall | 0.6757357622; reported 500 whole-donor bootstrap interval [0.6566957500, 0.7038927405]. |
| Test macro F1 | 0.6767151089; reported interval [0.6571981881, 0.7046131610]. |
| Test coverage | 0.9870609982; reported interval [0.9822541864, 0.9913922890]. |
| Test accuracy including unassigned | 0.7401109057; reported interval [0.7195624581, 0.7605244203]. Accepted accuracy is 0.7498127341, interval [0.7288340152, 0.7697696673]. |
| Observed class scope | 49 of the 52 fitted classes have test truth. Cervix - Ectocervix, Cervix - Endocervix and Kidney - Medulla remain explicitly untested. Fallopian Tube has two test donors and zero correct assignments; its [0,0] bootstrap interval is conditional on those two observed donors, not proof of a population zero. |
| Destructive gene-permutation rejection | Only 0.4500785598 donor-mean rejection, interval [0.4298190871, 0.4715881319]. The screen passes because this exceeds its development-derived lower target; roughly 55% of these destructive controls are nevertheless accepted. This does **not** establish strong off-reference detection. |
| True-centroid-withholding control | 0.2243429415 donor-mean rejection, interval [0.2077472496, 0.2431809523]. It is a descriptive near-reference control retaining the original features/PCA, not an independently excluded-population experiment. |
| Label-remapping comparator | 100 global remappings; macro-recall 95th percentile 0.04796830275. This is a descriptive comparator, not an independent-donor permutation p-value. |
| Missing-gene sensitivity | Masking 1% and 5% gives coverage 0.9878003697/0.9863216266 and macro recall 0.6795430596/0.6835229242. Masking 20% triggers the frozen missingness guard for all 2,705 profiles, yielding zero coverage. These are the frozen sensitivity outputs, not feature-retuning candidates. |

Fine tissue labels perform unevenly despite the pooled gate: Brain - Amygdala recall is 0.125 (24 test donors), Brain - Hippocampus 0.1578947368 (38), Brain - Caudate 0.1875 (48), Brain - Cortex 0.1951219512 (41), and Bladder 0.2222222222 (9). Those failures limit tissue-resolution claims. The saved per-class results and intervals must remain available alongside pooled metrics; the gate must not be presented as uniform validation of the body-wide atlas.

GTEx conditional stability has 99 successful centroid/hierarchy resamples and one draw with a missing class. The saved mean neighbor overlap **0.9348614349 averages only the 99 successful draws**; it is not an average over all 100. A separately derived conservative all-100 summary assigning zero overlap to the missing draw is 0.9255128205 (= saved mean × 99/100); this contextual calculation does not replace or alter the original result. Branch support uses all 100 draws and ranges from 0.11 to 0.99. Full feature/PCA reselection stability is untested for GTEx, and leave-study-out transfer is untestable because GTEx is one source study. This distinction corrects any broad prose implying the neighbor average also retained the missing draw in its denominator.

No tumor projection exists: the saved status remains `blocked_pending_comparable_RNA`. Retained-PCA rejection cannot see all departures in discarded components, and these normal-only results do not validate bulk-tumor transfer, coordinated programs, cellular fractions, cell of origin or ancestry.

### Frozen result identity

| Artifact | Independently verified SHA256 |
|---|---|
| `model/freeze_manifest.json` | `aa2cc4f8dafab00998ddf3be0ac2b63b830cba9be15880639632663ed0074d76` |
| `model/data/gtex/prepared_manifest.json` | `9cbf62ec55458934b23ece658f60d27fdb50dfd448ef749b0014d35da3c1cbb8` |
| `model/data/gtex/fit/model.npz` | `28edef730bc6c31f457aeb173931c0ce2374907409b084db121780206b888ef2` |
| `model/data/gtex/fit/development_lock.json` | `1199528ded99726706baa8e77dfc000daa3ea5cb2cf3666fb7e72e22783efd23` |
| `model/data/gtex/fit/calibration.json` | `518191c208629d60fc89ca3a7dc0be623300b43af6246b933c1df173d2df58fa` |
| `model/data/gtex/fit/validation.json` | `ae693f860adec2ca1b6861a78ec65b6468ca863779f3d0f8465fe8108107f8c5` |
| `model/data/gtex/fit/aggregate_reference.json` | `f0deb311ab71eedc02eb2aa30251db6de561998a356c9750dc2f2acded6598e2` |
| `model/data/gtex/fit/completed_fit_manifest.json` | `b18f9029d6f87228f8ec6a42ccd9cb01c00c32c4b18d216f4e18c881db6e8a06` |

### Windows display transport correction

The frozen exporter emitted native backslash keys, while the frozen display loader requires a forward-slash aggregate key. The additive `model/refresh_display.py` helper (SHA256 `91b0148df8361acc3c9aeda57b6a10ec06eca5674fd417042cffbc0b1487ae22`) calls the unchanged verified exporter and canonicalizes only the ignored display-manifest keys. It verifies path containment and each digest, coalesces only identical aliases, rejects conflicting aliases and binds its own hash. It leaves frozen producers and completed scientific outputs unchanged. The reviewer inspected the helper and independently verified all 30 actual canonical display bindings, helper/proof hashes and equality between the displayed GTEx scientific report and its completed scientific aggregate: zero failures.

At `2026-10-19T03:05:46.972044+00:00`, the exported global aggregate SHA was `0b6e138f55c4c125db9a6edbea2dd558ed9a3edb0c4cd4fcf9fec7e52066b2a6`, and the canonical ignored display-manifest SHA was `f34dcbb7908d4ab6560b08aae6428a21554b2a5b144f3070ea4910cfb36d0a0e`. The helper is accepted as a transport repair, not a scientific rerun or a modification of frozen results. Later exports can legitimately refresh the global wrapper/time and add HLCA; the completed GTEx scientific bytes must continue matching the completion manifest.

This reviewer did not train, refit, tune or rewrite any model/result. Point metrics were independently reconstructed from fixed saved predictions; the quoted bootstrap intervals were inspected in the saved, hash-bound output and were not independently rerun by this reviewer.

## Separate live HLCA readiness gate, October 18 at 23:07 EDT

**HLCA disposition: PASS for its first normal-only preparation and prescribed fit under the existing unchanged frozen configuration/producers.** The root was notified separately after actual verification, before `model/data/hlca` existed. The preparation loader must still hash the actual derived raw matrix, verify all source bindings and match the existing freeze. This clears source/method readiness only; no HLCA performance result existed at this gate, and GTEx was not refitted or retuned.

At `2026-10-19T03:07:05.435901+00:00`, 29 independent compact readiness/hash-chain checks passed with zero failures. The reviewer also streamed the canonical cell metadata and independently recomputed whole-donor eligibility, minimum profile-size losses and the prospective donor split without reading raw expression values or writing a model input.

| Evidence | Actual verified binding or scope |
|---|---|
| Immutable ready audit | `source/hlca_audit.json`, SHA256 `137d7e21fc561dbc649859d89b7137ce4424bbabab5479ac6decc390c3b487fc`; correct resource, ready flag, result, explicit local input and producer/eligibility bindings. |
| Original source/eligibility/amendment | All current hashes match the audit and earlier reviewed contracts. Same source dataset version `688185ad-11c2-4172-a53a-f4f1f4076860`; transport-only amendment SHA `d9e24101fa325a0975e4d21bf11d430393b740d2fb9381383b714f057eb79b36`. |
| Actual model input | `hlca_core_raw`, `data/downloads/hlca_core_raw_only_688185ad.h5ad`, 2,765,942,191 bytes, SHA256 `32edfa601c72673d4dc8cfc145dccf6a6fa84f2f2c2a5553999398b97c2ead49`. Audit, receipt, explicit model input and extraction ledger agree; actual file size agrees. |
| Retained source ranges | Consumed ledger `data/audit/hlca_source_ranges.json` SHA256 `accb9c01a05f979515532ecee2501e9c11859ad4155f266af167c5c214193069`; the versioned `source/hlca_source_ranges_manifest.json` is byte-identical. There are 185 ranges and 3,179,296,815 retained bytes with possible overlaps. Actual retained range sizes agree; the source audit has already rechecked full range hashes and derived matrix hash. The reviewer did not repeat those multi-GB scans. |
| Original-file claim | Both audit scope and ledger explicitly retain `full_source_file_retrieved: false` and no full original H5AD SHA. Only `obs` and `raw` are copied; normalized `X` is omitted. A derived subset checksum is not a whole-original checksum. |
| Count integrity | Completed audit scans all 1,138,668,948 stored raw entries: float32 storage, zero negative/nonfinite/noninteger values, valid dimensions/indices/indptr. This is completed source evidence, not the earlier 1,000-entry smoke proof. |
| Metadata/gene manifests | Actual cell, donor/class and gene manifest hashes match the audit. Independent gene checks find 27,402 model-valid unique stable IDs, zero invalid or duplicated stable-key rows, and eight repeated-symbol keys retained as annotation. Actual source age encoding is a float64 array, handled by the finalized numeric-aware reader. |
| Unchanged protocol | Current config still hashes to `f4deba242b967a3d8b14b17bc7556654f64cc5e5a1f73d9f70de7297f6f85955`; all seven source producer bytes match both immutable source audits. No scientific producer edit is part of this gate. |

The independently reproduced primary population contains 104 source-Healthy donors/523,962 cells. The three tumor-adjacent donors are blocked in their entirety, excluding 60,982 cells. Applying the frozen minimum 20 cells per donor/class leaves **103 donors, 508 donor/class profiles and 522,516 cells**; 1,446 healthy-source cells are excluded by annotation/profile-size rules, and one healthy-source donor has no eligible profile. Source donors/cells must not be substituted for eligible model denominators.

| Role | Eligible donors | Eligible profiles |
|---|---:|---:|
| Training | 62 | 289 |
| Development | 15 | 86 |
| Calibration | 11 | 51 |
| Test | 15 | 82 |

All 11 source broad classes remain accounted for, but only nine have enough training donors for fitted centroids:

| Broad class | Source-Healthy donors/cells | Eligible donors | Train / development / calibration / test profiles | Scope |
|---|---:|---:|---|---|
| Airway epithelium | 104 / 203,116 | 90 | 54 / 13 / 9 / 14 | Trainable. |
| Alveolar epithelium | 73 / 64,882 | 59 | 37 / 9 / 5 / 8 | Trainable. |
| Blood vessels | 84 / 27,428 | 69 | 41 / 12 / 6 / 10 | Trainable. |
| Fibroblast lineage | 83 / 17,270 | 47 | 26 / 9 / 4 / 8 | Trainable. |
| Hematopoietic stem cells | 19 / 55 | 1 | 0 / 1 / 0 / 0 | No training centroid or eligible test donor; unvalidated. |
| Lymphatic EC | 68 / 4,132 | 23 | 11 / 4 / 2 / 6 | Trainable. |
| Lymphoid | 98 / 64,119 | 73 | 42 / 12 / 8 / 11 | Trainable. |
| Mesothelium | 19 / 197 | 4 | 0 / 1 / 0 / 3 | No training centroid; any test rejection evidence is descriptive. |
| Myeloid | 93 / 135,379 | 86 | 52 / 13 / 9 / 12 | Trainable. |
| Smooth muscle | 71 / 2,712 | 29 | 14 / 7 / 4 / 4 | Trainable; fewer than five test donors, so class performance is descriptive. |
| Submucosal Gland | 44 / 4,672 | 27 | 12 / 5 / 4 / 6 | Trainable. |

The HSC development profile and three Mesothelium test profiles must remain separate unsupported-population evidence; they cannot become correctly classified normal profiles or expand the nine-class recall denominator. Harmonized donor IDs do not cross source studies in the actual metadata, but hidden cross-study donor reuse remains unresolved beyond those source IDs. The source integrated annotation/embedding history is not independent processing validation, and uncorrected donor/class counts remain distinct from bulk GTEx TPM and historical tumor RSEM.

The existing full-training-pipeline HLCA donor bootstrap and full leave-study-out refits may now run as prescribed. Their actual estimability, performance, stability and negative findings remain pending and must not be assumed from this readiness gate. No claim of a full original H5AD checksum, globally healthy donors, tumor transfer, RNA ancestry or biological/clinical validation follows from source readiness.

## Final HLCA postfit independent review

**Disposition: completed results are hash-consistent and accurately report an HLCA gate failure. The lung reference must not be called validated or treated as passing its declared rejection gate.** No retraining, threshold adjustment or scientific producer edit was performed by this reviewer.

At `2026-10-19T03:13:55.055298+00:00`, the reviewer independently completed 208 frozen/source/preparation/completion/display/prediction/fold-metadata checks with zero failures. This includes all original frozen producers, both references' completed scientific outputs and their completion-manifest bindings, the final global aggregate/display proof, normal-only records, unique donor/class keys and single donor roles. The saved HLCA test predictions exactly match test record order, donor IDs and truth labels. A further independent reconstruction of all ten study-fold point metrics from their saved confusion matrices and five stability-denominator/arithmetic checks also passed.

The actual model preserves the source and role counts verified before fitting: 104 source-Healthy donors/523,962 cells, 103 eligible profile donors/508 profiles/522,516 cells, 62/15/11/15 role donors and 289/86/51/82 role profiles. There are nine fitted classes and two unsupported source populations. It selects 2,000 of 18,056 training-eligible genes from 27,402 unique stable IDs; 9,346 genes fail the training positive-expression criterion, 16,056 eligible genes fall below the selected rank, and the disjoint feature-loss partition balances. Twenty retained PCA dimensions explain 0.8339273888 of weighted training variance. Neither the source population nor thresholds were altered after test assessment.

### Reconstructed test denominators and failed gate

Independent reconstruction from saved predictions gives **79 represented-class test profiles: 77 correctly accepted and two unassigned**. The two unassigned profiles are Myeloid. There are another **three unsupported Mesothelium profiles, all accepted as Fibroblast lineage**. The latter are explicitly absent from the represented-class accuracy/F1 denominators and must be shown separately. Thus accepted accuracy 1.0 is conditional on the trained truth classes; it is not perfect accuracy across all 82 test profiles or all 11 source populations. HSC has no eligible test profile and remains untested; Smooth muscle has only four test donors and remains descriptive.

| Prespecified result | Saved output, independently checked for consistency |
|---|---|
| Overall declared gate | **Failed.** Normal development consistency passes; gene-permutation development consistency fails; recall interval above label-remapping comparator passes. |
| Development lock | `2026-10-19T03:10:29.873015+00:00`; selected quantile 0.80; normal recall lower target 0.8865641534 and destructive-control rejection lower target 0.6002996032. Quantiles 0.80 and 0.90 were the feasible development candidates for the independent calibration donor count. |
| Calibration | 11 donors/51 profiles; fixed donor-maximum threshold 1.8961226213. No post-test calibration change. |
| Represented-class macro recall | 0.9814814815; saved 500 whole-donor bootstrap interval [0.9514941077, 1.0], nine observed trained truth classes. |
| Represented-class macro F1 | 0.9898989899; saved interval [0.9689542484, 1.0]. |
| Represented-class coverage/accuracy including unassigned | Both 0.9746835443 (= 77/79); saved interval [0.9264006057, 1.0]. |
| Represented-class accepted accuracy | 1.0 (= 77/77), saved interval [1.0,1.0], conditional on these observed donors/classes and excluding the three unsupported false assignments. It is not a population guarantee. |
| Destructive gene-permutation rejection | 0.4580423280 donor-mean rejection across 82 profiles/15 donors; saved interval [0.3796468254, 0.5438452381]. It is below the locked 0.6002996032 target, independently reproducing the failed gate. |
| True-centroid-withholding rejection | 0.6279365079 across the 79 represented profiles/15 donors, saved interval [0.4205992063, 0.7771468254]. This retains the original features/PCA and is descriptive, not a full excluded-population refit. |
| Global label-remapping comparator | 100 remappings; macro-recall 95th percentile 0.4259259259. It remains a descriptive comparator, not a formal independent-donor p-value. |
| Unsupported Mesothelium | Three donors/profiles; zero rejected, all three falsely accepted as Fibroblast lineage. The observed [0,0] rejection interval reflects only these three donors, not a precise population estimate. |

The normal-recognition result does not rescue the rejection failure. The broad classes are easier than GTEx's finer tissues, and neither their high internal recognition nor a failed destructive control establishes reliable mapping of unseen populations or tumors. These results should be presented together, without hiding the unsupported-population assignments or relaxing the frozen gate.

### Actual donor-resampling stability

| Assessment | Actual output and denominator |
|---|---|
| Conditional features/PCA bootstrap | 100 successful training-donor centroid/hierarchy draws, zero missing-class draws; mean nearest-three overlap 0.9459259259 over all 100. This conditional result does not include feature/PCA reselection. |
| Full training-pipeline bootstrap | 100 successful all-gene selection/PCA/profile refits, zero failed refits; seven draws omit at least one original class after distinct-source-donor eligibility. |
| Selected-feature stability | Median Jaccard 0.8943879821; empirical 2.5th–97.5th percentile range [0.7964430609, 0.9180283769] across the 100 refits. This describes resampling variability, not a clinical accuracy interval. |
| Full-pipeline neighbor stability | Mean 0.9303703704 over all 100 draws, with missing original classes receiving zero neighbor credit as implemented. The per-class average independently reproduces the saved overall mean. |
| Full-pipeline class presence | Lymphatic EC 97/100, Smooth muscle 99/100, Submucosal Gland 96/100; each other fitted class 100/100. |
| Full-pipeline branch support | Exact original-clade recurrence ranges 0.54–0.93. All branch denominators are 100; any draw lacking an original class contributes no clade support, as disclosed. These are similarity-hierarchy stability values, not ancestry support. |

Calibration/test were not refitted in either bootstrap. The saved aggregate contains summaries rather than each replicate's selected genes/model; the reviewer checked arithmetic, frozen implementation and bound outputs without independently replaying these fits.

### Leave-study-out validation: checked independence and observed failures

The reviewer independently reconstructed every study's held-out donor set and source-specific seeded split of the remaining donors. For all ten folds, reported held-out/training donor counts, fitted class labels, shared-class criteria, represented/unsupported profile denominators and observed macro-class counts match the saved metadata. Held-out donors are disjoint from each fold's training, development and calibration donors. The unchanged frozen `transfer.py` starts from the full gene universe and refits eligibility/selection, scaling, PCA, profiles, development choice and calibration without held-study donors; it does not substitute the original selected-gene matrix. Independent confusion-matrix arithmetic matches every saved fold's reported point metrics.

| Held-out study | Donors | Trained donor count | Observed macro classes | Represented test profiles | Macro recall | Represented coverage |
|---|---:|---:|---:|---:|---:|---:|
| Banovich_Kropski_2020 | 37 | 40 | 8 | 197 | 0.9926470588 | 1.0 |
| Barbry_Leroy_2020 | 10 | 56 | 8 | 59 | 0.5545634921 | 0.6271186441 |
| Jain_Misharin_2021 | 7 | 58 | 4 | 21 | 0.4226190476 | 0.5238095238 |
| Lafyatis_Rojas_2019 | 6 | 58 | 8 | 35 | 1.0 | 1.0 |
| Meyer_2019 | 3 | 60 | 8 | 23 | 1.0 | 1.0 |
| Misharin_2021 | 2 | 61 | 9 | 16 | 1.0 | 1.0 |
| Misharin_Budinger_2018 | 8 | 57 | 7 | 43 | 0.9591836735 | 0.9534883721 |
| Nawijn_2021 | 10 | 56 | 8 | 55 | 0.9861111111 | 0.9818181818 |
| Seibold_2020 | 14 | 53 | 2 | 24 | 0.9642857143 | 0.9583333333 |
| Teichmann_Meyer_2019 | 6 | 58 | 8 | 30 | 0.6979166667 | 0.7 |

These macros span **different observed class mixtures, from two to nine classes**, so they cannot be averaged or compared as if each tested the same complete nine-class population. Some observed classes have one donor: Alveolar epithelium in Barbry; Fibroblast lineage in Jain; Blood vessels and Submucosal Gland in Misharin_2021; Lymphatic EC in Nawijn; Smooth muscle in Teichmann. The minimum shared-class criterion makes a fold estimable; it does not give every included class an adequate donor denominator. Perfect point estimates/[1,1] bootstrap intervals from two- or three-donor studies remain conditional small-sample findings.

The poor transfers are material: Jain macro recall 0.4226190476 has saved donor interval [0.3183035714,0.7142857143]; Barbry 0.5545634921 has [0.3795578231,0.7363281250]; Teichmann 0.6979166667 has [0.4216145833,0.9761904762]. These results prevent a claim of reliable study-wide transfer. Banovich additionally has three unsupported Mesothelium profiles, none rejected; Meyer has one unsupported HSC profile, not rejected; Teichmann has one unsupported Mesothelium profile, rejected. Those unsupported profiles remain outside the conditional trained-class metrics.

Per-fold trained matrices, selected-gene lists and individual predictions were not persisted separately by the frozen transfer routine. The reviewer therefore verifies the frozen refit logic, independently reconstructed fold independence/denominators and bound confusion outputs, rather than claiming an independent numeric re-projection of saved fold models. No fold was refitted during this review. Shared upstream atlas annotation/integration and unidentified donor reuse beyond harmonized source IDs remain limits on external-independence claims.

### Final bound artifact identity and remaining limits

| Final artifact | Independently verified SHA256 |
|---|---|
| `model/data/hlca/prepared_manifest.json` | `4c9363955056d02cf2e35e62970b8e8bad047414efd94d140d6702273cb28a2d` |
| `model/data/hlca/fit/model.npz` | `4e57edddc1a8f29b6202e572d5b44fba46efd069e19b353d906e95207292de2e` |
| `model/data/hlca/fit/development_lock.json` | `220ed1b099de07c484f1abdfd941fc060630a8842c056238cddeda7d4a79bbfa` |
| `model/data/hlca/fit/calibration.json` | `573e4e9c6ba563845ce31344dbce5c3008387c865de370dfda3906c001b9915c` |
| `model/data/hlca/fit/validation.json` | `8a2819606d53c744694759c7faef41734cf75eb922c6ad15f164eeafad3357fb` |
| `model/data/hlca/fit/aggregate_reference.json` | `6380f07124ff56abbd09fd81e3270063945aa499414d396fd4e031ab624d192b` |
| `model/data/hlca/fit/completed_fit_manifest.json` | `4b269e14950349a6d64d40c314b5898d22fae2cf110ae01877ebdb9488c27b3d` |
| Final global `model/aggregate_report.json` | `b448e3b5acd80b8323356a0099c5df796694213e28b7da403e791248c777cce9` |
| Final ignored canonical display manifest | `c058cdb46b97169af86a9d895cc0f7f1200a8175912169353a3af0e75fb74355` |

The final display transport proof matches both completion manifests, both reference models, the global aggregate and current normalized display bindings. All frozen scientific producer bytes and completed GTEx bytes remain unchanged. The additive display helper remains the previously reviewed transport-only correction.

The first normal-only analyses have now actually run; the deliverable is an honest baseline with documented negative findings, **not two universally validated references**. The HLCA rejection gate remains failed; unsupported HSC/Mesothelium, small per-class and per-study samples, uneven study transfer, GTEx fine-tissue failures/three untested classes and conditional-only GTEx transform stability remain unresolved scientific limits. Exact tumor RNA comparability, fixed patient/specimen linkage, tumor composition/purity assessment and tumor transfer validation remain pending, and both references still report tumor projection blocked. No protein/functional tier, cellular fraction or RNA ancestry is established.

The source agent is separately preparing additive input-restoration helpers and an exact replay in isolated ignored staging. This reviewer has not inspected those new helpers or witnessed their replay proof at this checkpoint, so no independent restoration/rebuild claim is made here. That separate reproducibility check does not alter the existing completed-fit hashes or erase the reported HLCA failure. The review's remaining evidence gap is repeatable replay provenance, not permission to retune the observed models.

## Final bounded input-restoration review

**Disposition: PASS for the additive restoration helpers and the specifically demonstrated local replay scope.** This supersedes the preceding pending restoration-review note. No frozen scientific producer, contract, completed audit, fitted model or result was changed. This is a reproducibility finding; the HLCA rejection gate remains failed and all scientific limitations above still apply.

The reviewer inspected the complete new `source/restore_metadata.py` and `source/recreate_hlca_input.py` implementations and their focused tests. No material static blocker was found:

- Both wrappers bind the original immutable audit, current source/eligibility/amendment hashes, frozen producer bytes and actual expected input/manifest identities. Work starts in a new ignored directory under `source/data`; resolved paths cannot escape their specified root.
- Cached payloads must match historical length and SHA before use. The fresh-range path requires the exact pinned version/ETag, HTTP 206, Content-Range and length, then the expected content SHA. A correct-looking header with wrong payload is rejected.
- `LedgerFile` reads only covered historical offsets and fails on a gap or truncation. Missing bytes are not zero-filled or guessed. The recreated HDF5 must match the entire frozen derived-container hash tuple before its historical ledger can be restored or any publication considered.
- Historical ledger bytes remain historical evidence. Newly verified/acquired range records and the new input receipt use separate files and current verification timestamps; original receipt timestamps are not fabricated.
- Metadata restoration reruns the unchanged audit callback into staging, compares every deterministic result field and each expected manifest SHA, and checks existing canonical destinations before optional publication. Both helpers reject differing existing targets. Missing-file publication uses atomic no-replace hard links; it cannot overwrite an existing target.
- Actual runs used staging without `--publish-missing`. The canonical files already matched; real missing-target publication was tested with fictional fixtures, rather than by deleting or replacing canonical scientific inputs.

### Independently executed focused checks

The reviewer independently ran all **21 tests: PASS** (11 original source guards, three metadata-restoration guards, seven exact-range replay guards). They cover altered same-length caches, wrong version/ETag/offset/length/content, missing range coverage, invalid CSR counts/structure, duplicate stable IDs, numeric metadata and preservation of differing existing targets. All HTTP interactions in these tests are mocked; no real download, model fit or source rescan occurs.

The first attempt with the system Python could not import NumPy and executed no actual fixture tests. The successful run used the existing pinned A18 environment, without installing anything:

```powershell
& 'C:\Users\tirad\CODEX HOME\Active Projects\A18- GeNeDis 2026\.venv\Scripts\python.exe' -B -m unittest normal_reference.source.test_source normal_reference.source.test_restore_metadata normal_reference.source.test_recreate_hlca_input -v
```

### Actual proof and exact scope

The source-run [metadata restoration proof](../normal_reference/source/metadata_restoration_review.json), SHA256 `0f410553f8a99624e6874feaf7d10c516b360f76acde5303d5c1d777c1f2ca9f`, embeds one completed full metadata replay for each resource. GTEx completed at `2026-10-19T03:19:31.145160+00:00`; HLCA at `2026-10-19T03:17:06.408447+00:00`. Every deterministic audit result and all five staged manifest hashes match the original audited canonical files. The reviewer independently rehashed those staged metadata files and compared the combined proof with the detailed staging proofs. There were no canonical publications or source/model mutations.

The source-run [HLCA input replay proof](../normal_reference/source/hlca_input_restoration_review.json), SHA256 `ce4d1c49f43549cd0d8311e39d1821d97188d19ff04948a66fc6af56da6e9588`, records a complete **cached-range** replay completed at `2026-10-19T03:15:37.998929+00:00`: all 185 retained payloads were rehashed, totaling 3,179,296,815 bytes with overlaps, with **zero new network bytes** in that complete replay. It rebuilt a separate 2,765,942,191-byte derived container with the exact original SHA256 `32edfa601c72673d4dc8cfc145dccf6a6fa84f2f2c2a5553999398b97c2ead49`. Its runtime was h5py 3.15.1/HDF5 1.14.6/NumPy 2.3.3. The reviewer checked the 185 new receipt bindings, range lengths/version/offset/hash identities, staged historical-ledger bytes, distinct reconstructed container identity/size and separation of new receipts from historical evidence. The multi-GB payload/container scans already completed by the source helper were not gratuitously repeated by this reviewer.

The same proof separately records **one new 262,144-byte public endpoint read**, with the pinned real ETag, exact `bytes 0-262143/5873612847` response range and payload SHA256 `def56cee974fe8bf12a9e3a85fab2607a6f8c4f5911fae04329f7ff1ed4da161`. The reviewer independently checked its actual staged payload hash and its receipt against the versioned proof. This is a bounded fresh endpoint check, **not** a second full 185-range network retrieval.

| Reviewed helper/proof | SHA256 |
|---|---|
| `source/restore_metadata.py` | `ebec8e0214c12bca37269ac4b4d6329d7defdc11b48b0d7b37af0a54fe8efc77` |
| `source/recreate_hlca_input.py` | `b41157156dc3c98e38c689cdd9f5c180d3a826550bc8a46f1f589be40bc3ee9f` |
| `source/test_restore_metadata.py` | `7641dd6b1446a08241e50e2157d328f09b97ba8b7908508a069bbb5609310bb8` |
| `source/test_recreate_hlca_input.py` | `bed9f33fb139ff46ee1f167d3722ff06967e94d523224aa8d78ab06cf045558e` |
| Detailed raw `input_replay_review.json` | `969e3ddea93771331258df3347122e377a760a73ec1f510d1336b27c28acbfe7` |
| Detailed `new_range_replay_receipts.json` | `dc9a1ac7fe24fba1a725f9d12e3a000190b6556e23d18b8a5cf153b624cbabbb` |
| Detailed `new_model_input_receipt.json` | `75aa49decf825657b855bea5dfa2e742e4ad19947c2a36f6136362546ea87568` |
| Detailed GTEx `restoration_review.json` | `088c00a379557330d8bc58c433a4d93dce9ae3b646ac757fdba528053c226186` |
| Detailed HLCA `restoration_review.json` | `686b6025a2f1bd41db7e84d33440e2398770c232f14c3b734127e2c034951a96` |

Detailed raw proofs are in ignored `source/data/replay/hlca-full-input-verification/`; metadata proofs are in `source/data/replay/{gtex,hlca}-metadata-verification/`. Actual endpoint bytes/receipt are in `source/data/replay/public-range-endpoint-verification/`. These staging files are not intended as patient-level Git artifacts; the compact linked versioned proofs are patient-free.

At `2026-10-19T03:21:10.675992+00:00`, 33 final compact producer/completion/proof checks passed with zero failures. Both immutable source audits, all seven frozen source producers, frozen model/configuration and both completed scientific outputs remained unchanged. The freeze manifest still hashes to `aa2cc4f8dafab00998ddf3be0ac2b63b830cba9be15880639632663ed0074d76`, and the final global aggregate remains `b448e3b5acd80b8323356a0099c5df796694213e28b7da403e791248c777cce9`.

The demonstrated claim is exact local restoration on this pinned runtime from verified cached HLCA ranges, plus actual deterministic metadata replay for both sources and a separate small fresh HTTP check. A full new public-range transfer, exact cross-platform container reproduction, real missing-canonical publication and model refitting from a fresh checkout were not exercised here. No full-original-H5AD checksum, biological validation or improvement in the failed rejection result is inferred.
