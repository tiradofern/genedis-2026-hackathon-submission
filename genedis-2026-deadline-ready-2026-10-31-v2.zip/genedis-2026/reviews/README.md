# Scientific and technical reviews

Justin's first review should use `REVIEW_PROMPT.txt` and `REVIEW_TEMPLATE.md`, then save `justin-initial-review.md` on a review branch. No completed review has been received yet. Keep the template unchanged for reuse.

Link each review to the source files, sample identifiers, source publications, and code revision it assessed. Separate verified errors, unresolved validity risks, and method preferences. Return actionable remedies and conditions for proceeding. Scientific analysis results must not be invented to complete a review.
