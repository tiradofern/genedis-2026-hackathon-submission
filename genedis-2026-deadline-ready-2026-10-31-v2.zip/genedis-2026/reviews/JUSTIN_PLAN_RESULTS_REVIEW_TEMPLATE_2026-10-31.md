# Justin's independent plan and results review — template

**Unfilled template. No review, endorsement or findings are implied.** Copy to `reviews/justin-plan-results-2026-10-31.md` on a findings branch or return the completed text to Fernanda.

- Reviewer and sign-off:
- Date/time/timezone:
- Commit reviewed:
- Archive filename/hash, if actually inspected:
- Review scope and time available:
- AI/tools used and extent of personal verification:

## Executive assessment

State the strongest supported contribution, the main validity risk, and the three highest-priority recommendations. Distinguish demonstrated results from proposals and untested hypotheses.

## Separate verdicts

| Decision | Verdict | Main reason | Conditions |
|---|---|---|---|
| Current NSCLC reconstruction/feasibility submission | Ready / revise / hold | | |
| Longer-term MSI research plan | Proceed / narrow / redesign | | |
| Any new analysis before submission | Recommend / defer / reject | | |

## Facts and claims checked

| Claim | Confirmed / uncertain / contradicted / not checked | Exact source/artifact evidence | Permitted interpretation or correction |
|---|---|---|---|

Include cohort/patient counts, program definitions, reproduction status, absent longitudinal tests, coordination/recurrence distinction and relevant historical negatives. Treat AI audit reports as evidence to inspect, not your own reruns.

## Material findings and recommendations

| ID | Priority: blocker / major / minor | Finding and exact evidence | Consequence | Proposed action and acceptance criterion | Effort/dependency | Before submission / later |
|---|---|---|---|---|---|---|

For cohort issues, identify affected patients/cohort, whether the issue is confirmed or unknown, whether inference/descriptive use is affected, and the minimum evidence needed to resolve it. Explain any disagreement with the existing no-go decisions or AI reviews. Do not replace uncertain metadata with assumptions.

## Statistical and biological design assessment

- Operational meaning of conserved/recurrent and match to measurement:
- Independent tests of coordination and cross-cohort recurrence:
- Resistant-state recurrence versus paired change versus specificity/selection/function:
- Ordinary cancer/lineage/composition/technical background and appropriate nulls:
- Definition of acquired resistance, including any durable-SD concern:
- Gene mapping, common universe, coverage, program overlap and scoring:
- Patient independence, pairing, split/leakage, multiplicity, power and uncertainty:
- Success, tested-negative and inconclusive outcome definitions:
- Smallest defensible next study and prerequisites:

## Proposed wording changes

| Current statement/location | Recommended wording | Supporting evidence and reason |
|---|---|---|

## Review provenance

- Files/publications/accession records inspected:
- Commands actually run, environment and outcomes:
- Package/source availability and checks not performed:
- Unresolved contradictions and evidence that could change your conclusion:
- Working-copy changes, if any:

## Questions for joint reassessment

1. Which claims and deliverables should be retained, narrowed or removed?
2. Which recommendations are essential before submission, and which belong after it?
3. Does any pilot reopening have adequate clinical/technical evidence and a prospective amendment?
4. What should Fernanda and Justin decide together before the next revision?

## Second-pass reviewer response

Complete only after revisions are available: revised commit/package; material findings resolved or unresolved; reasons; updated verdict; Justin's sign-off. Preserve the first-pass review rather than replacing it.
