# Plot color visibility update

The investigator reported pale dots and hard-to-distinguish stage colors during the LUAD walkthrough. The update keeps the existing workspace and changes only the scientific color/marker presentation.

- Stage I: blue `#0072ce`; II: orange `#d97706`; III: green `#009e73`; IV: purple `#a23fc0`; unknown: gray `#64748b`. Filter swatches and plot legends use the same values.
- Activity and purity: piecewise cyan `#40c4f4`, blue `#1684e8`, purple `#4a16ad`, with lower/mid/higher keys. The score and purity mappings retain their previous domains and clamping. Missing purity remains a separate gray state.
- Reported-event coloring: orange versus blue, retaining the explicit no-reported-event wording.
- Tumor radius increases from 3.5 to 4.5 SVG units and unselected opacity from .82 to 1. Brush context still fades to .15. Dark borders, hover, selected rings and normal-reference triangles retain their existing roles. Legend dots increase from 7px to 11px.

Verification on October 18, 2026:

- All 28 Python tests and five existing frontend tests pass. Both edited JavaScript modules pass `node --check`; `git diff --check` passes.
- An offline Node VM ran the actual old/new `renderPlot` functions against prepared LUAD/LUSC data in all four color modes. All sample identifiers and PCA coordinates match exactly. All 507/481 tumors remain present, and selection opacity is preserved. The filter and legend swatches match.
- The continuous scale has decreasing luminance at 101 evenly spaced samples. Stage fill/white contrast ranges from 3.19:1 to 5.24:1; the dark marker boundary/white contrast is 8.41:1. Table labels and source stage text remain available independently of color. These checks do not constitute a complete accessibility certification.
- Reviewed offline rasterizations of the actual SVG plot output at desktop and mobile widths, including before/after stage and program-02 activity views. Ignored QA artifacts are under `work/qa/brighter-colors/`.
- The existing browser-policy block prevented a live in-app browser reload or a new browser interaction test. No alternate browser route was used. Full-page layout and live interactions were not re-audited for this display-only update. The backend health endpoint still reports ready with the unchanged dataset fingerprint.

No source molecular data, scientific criteria, scores, model parameters, thresholds or candidate evidence tiers changed.
