# Review questions and evidence locations

The initial review should answer whether the chosen acquired-resistance study is worth advancing, what must be resolved first, and how Justin can contribute. A useful recommendation may be conditional or negative.

| Priority | Question | Evidence in this package | Useful answer |
|---|---|---|---|
| Critical | Can 13 longitudinal pairs with organ changes support the intended inference? | `manifests/GSE248249_pairs.tsv`; `docs/scientific_decision_report.md` | State the credible estimand, confounding limits, and a stop/narrow/proceed criterion |
| Critical | How should unconfirmed batches and unavailable final correction be handled? | `data/external/GSE248249/GSE248249_matrix_metadata.txt`; sample CEL references; decision report | Specify diagnostics, minimum missing information, and defensible sensitivity options |
| Major | How will array features map to a defensible gene universe? | `data/external/GSE248249/GPL23126_preview.soft`; data dictionary | Full annotation acquisition plan; controls and ambiguous mappings; independent aggregation rule |
| Major | What is the smallest statistical result worth generating? | Decision report minimum analysis; `results/reports/audit_summary_2026-10-14.json` | Score definition, paired effect/uncertainty, multiplicity, robustness, and failure conditions |
| Major | Does the baseline comparison add meaningful biological evidence? | `manifests/GSE207422_bulk_RNAseq_samples.tsv`; feasibility report | Distinguish endpoint concordance from replication; address histology, regimens, and small subgroups |
| Major | What multi-omics claim can be supported? | Dataset manifest; dbGaP and TCGA links in decision report | Separate inaccessible matched exomes, within-TCGA modality matching, and cross-cohort context |
| Major | Can an independent reviewer reproduce the audit correctly? | `scripts/`; `tests/`; `docs/reproducibility.md` | Actual bugs/checks, reproducible steps, and limitations of metadata-only reruns |
| Improvement | Is FMSI a useful operational term? | `docs/scientific_rationale.md`; original handoff | Testable definition, novelty limits, reference baselines, and language for uncertain results |
| Improvement | What work should each collaborator take? | `docs/TEAM_WORKFLOW.md` | Bounded proposals with inputs, outputs, dependencies, and completion criteria |

## Evidence standards

Point to the exact included file and, where possible, its line, row, sample code, or JSON key. A general literature citation cannot by itself verify this package's sample crosswalk. Label new external searches and their access dates. Distinguish an observed error, an unresolved validity risk, and a preference between defensible methods.

Use patient-level independence. Do not pool all 42 arrays as 42 unrelated people, count single cells as patients, or treat three different parental models as within-model replicates. A technical filename token does not become a confirmed batch because it is convenient for a model.

## Suggested reading time

A quick orientation is the brief plus the decision report. A deeper code and source check can follow in a separate working copy. These are suggested review levels, not an agreed deadline or an estimate of Justin's available time.

## Completion criteria for this review

Return one clear recommendation, the major evidence behind it, the conditions for proceeding, and a short prioritized action list. Include at least one concrete proposal for how Justin could contribute. State what was and was not checked. No new biological results are required to complete the review. Save the completed report as `reviews/justin-initial-review.md`, retaining the blank template for future reviews.
