# Audit verification — October 14, 2026

**Passed:** metadata reconstruction and source-matrix integrity checks with Python 3.13.15 and bundled Python 3.12.14; seven parser tests passed on both runtimes. No third-party packages required. These checks verify audit parsing, not biological analysis validity.

| Source | Features × profiles | Metadata column match | Missing/invalid numeric cells | Duplicate source feature IDs |
|---|---|---|---|---|
| GSE248249 deposited SST-RMA matrix | 138,745 ×42 | Exact GSM set match | 0 / 0 | 0 |
| GSE207422 bulk log2(TPM+1) | 58,387 ×24 | Exact library-ID set match | 0 / 0 | 0 |
| GSE156054 TPM | 21,463 ×6 | Exact source model-title match after explicit hyphen removal | 0 / 0 | 0 |

The GSE156054 source has 698 valid thousands-separated numeric values and an empty trailing field; both are handled without changing the source file. Array features include controls and complex transcript annotations, so feature count is not a count of uniquely mapped genes.

Patient identity checks recovered 13 unique complete acquired-resistance pairs among 29 GSE248249 patients; title/timepoint agreement was required. The site flags identify 4 pairs with the same anatomic-site string. Filename preparation tokens identify 11 pairs in the same technical group; these are not confirmed batch labels. GSE207422 has no duplicate patient within either assay, and its modalities share P05/P07/P08. Additional RNA–methylation patient codes match in 16 cases with agreeing response labels.

Tests cover rejecting inconsistent expression widths, duplicate columns, invalid thousands grouping, and mismatched metadata widths; retaining late-added samples; correctly parsing matrix delimiters; and handling trailing empty columns. All fixtures are fictional and were excluded from scientific outputs. Tests were rerun using workspace scratch storage after the host's temporary directory refused access; no scientific source change was needed.

No DE, pathway significance, batch correction, outlier exclusion, module stability, replication, genomic association, or clinical-performance claim has been tested. No inferential figures were generated. Source byte hashes and downloaded URLs are recorded in the inventory. The archive is checked for excluded large files, safe paths, intact member CRCs, and an independent extracted metadata/test rerun.
