const $ = (id) => document.getElementById(id);
const NS = 'http://www.w3.org/2000/svg';
let model;
let selected;
let parents;
const selectedModel = new URLSearchParams(window.location.search).get('model') || 'baseline';
const modelQuery = `?model=${encodeURIComponent(selectedModel)}`;
const pct = (value) => value === null || value === undefined ? 'NR' : `${(value * 100).toFixed(1)}%`;
const number = (value) => value === null || value === undefined ? 'NR' : Number(value).toPrecision(3);
const delta = (value) => value === null || value === undefined ? 'NR' : `${value >= 0 ? '+' : ''}${(value * 100).toFixed(1)} pp`;
const bootstrap = (edge) => edge.bootstrap_selected !== undefined && edge.bootstrap_successful !== undefined ? `${edge.bootstrap_selected} / ${edge.bootstrap_successful} (${pct(edge.bootstrap_support)})` : pct(edge.bootstrap_support);
const nullFits = (edge) => edge.null_selected !== undefined && edge.null_successful !== undefined ? `${edge.null_selected} / ${edge.null_successful} (${pct(edge.burden_null_selection_frequency)})` : pct(edge.burden_null_selection_frequency);
const counts = (node, prefix) => `${node[`${prefix}_present`]} / ${node[`${prefix}_n`]}${node[`${prefix}_n`] ? ` (${pct(node[`${prefix}_present`] / node[`${prefix}_n`])})` : ' (NR)'}`;
function el(tag, text, attrs = {}) { const element = document.createElement(tag); if (text !== undefined) element.textContent = text; for (const [key, value] of Object.entries(attrs)) element.setAttribute(key, value); return element; }
function svg(tag, attrs = {}, text) { const element = document.createElementNS(NS, tag); for (const [key, value] of Object.entries(attrs)) element.setAttribute(key, value); if (text !== undefined) element.textContent = text; return element; }
function filledColor(node) { const prefix = $('fill').value; const n = node[`${prefix}_n`]; if (!n) return '#d9e0e5'; const f = node[`${prefix}_present`] / n; const a = [230, 241, 241], b = [64, 196, 244]; return `rgb(${a.map((value, i) => Math.round(value + f * (b[i] - value))).join(',')})`; }
function selectEvent(id) { const restoreFocus = document.activeElement?.getAttribute('data-graph-event') === id; selected = id; renderGraph(); renderInspector(); for (const row of $('events').children) row.classList.toggle('selected-row', row.dataset.eventId === id); if (restoreFocus) [...$('graph').querySelectorAll('[data-graph-event]')].find((node) => node.getAttribute('data-graph-event') === id)?.focus(); }
function eventButton(node) { const button = el('button', node.label, {class: 'event-button', type: 'button'}); button.addEventListener('click', () => selectEvent(node.id)); return button; }
function renderInspector() {
  const node = model.nodes.find((item) => item.id === selected);
  $('event-detail').replaceChildren();
  if (!node) { $('event-heading').textContent = 'No events supplied'; $('event-detail').append(el('p', 'The source model contains no event nodes. No events or relations were invented for display.')); return; }
  $('event-heading').textContent = node.label;
  if (node.event_definition) $('event-detail').append(el('p', node.event_definition));
  const dl = el('dl', undefined, {class: 'measurements'});
  for (const [label, value] of [['Event ID', node.id], ['Discovery', counts(node, 'discovery')], ['Evaluation', counts(node, 'evaluation')]]) dl.append(el('dt', label), el('dd', value));
  $('event-detail').append(dl, el('h3', 'Complete selected-parent set'));
  const parentNames = parents[node.id].map((id) => model.nodes.find((item) => item.id === id).label);
  $('event-detail').append(el('p', parentNames.join(', ') || 'No selected incoming relations', {class: 'parent-list'}));
  $('event-detail').append(el('p', model.method.parent_semantics || 'Parents form a joint conditioning set in the fitted graph. They are not automatically deterministic prerequisites or an AND gate.'));
  const incoming = model.edges.filter((edge) => edge.target === node.id);
  if (incoming.length) { $('event-detail').append(el('h3', 'Incoming relation diagnostics')); const list = el('ul'); for (const edge of incoming) list.append(el('li', `${edge.source} → ${node.id}: bootstrap ${bootstrap(edge)}; burden-null ${nullFits(edge)}; permutation p ${number(edge.permutation_probability_raising_p)}, BH q ${number(edge.permutation_probability_raising_BH_q)}; evaluation Δ ${delta(edge.evaluation_observations?.probability_raising_delta)}.`)); $('event-detail').append(list); }
  $('event-detail').append(el('h3', 'Interpretation'), el('p', 'This is an event variable in a cross-sectional population model. It is not an observed ancestral tumour, a patient, or a clone. Event frequency alone does not establish temporal order.'));
}
function layout() {
  const indegree = Object.fromEntries(model.nodes.map((node) => [node.id, parents[node.id].length]));
  const children = Object.fromEntries(model.nodes.map((node) => [node.id, []]));
  for (const edge of model.edges) children[edge.source].push(edge.target);
  const depth = Object.fromEntries(model.nodes.map((node) => [node.id, 0]));
  const ready = model.nodes.filter((node) => !indegree[node.id]).map((node) => node.id);
  while (ready.length) { const id = ready.shift(); for (const child of children[id]) { depth[child] = Math.max(depth[child], depth[id] + 1); if (!--indegree[child]) ready.push(child); } }
  const layers = new Map();
  const connected = new Set(model.edges.flatMap((edge) => [edge.source, edge.target]));
  const isolated = model.nodes.filter((node) => !connected.has(node.id));
  for (const node of model.nodes.filter((node) => connected.has(node.id))) { const key = depth[node.id]; if (!layers.has(key)) layers.set(key, []); layers.get(key).push(node); }
  const positions = new Map();
  let tallest = 1;
  for (const [column, nodes] of layers) { tallest = Math.max(tallest, nodes.length); nodes.forEach((node, i) => positions.set(node.id, {x: 35 + column * 260, y: 48 + i * 114})); }
  const isolatedStart = layers.size ? Math.max(220, tallest * 114 + 90) : 50;
  isolated.forEach((node, i) => positions.set(node.id, {x:35 + (i % 3) * 260, y:isolatedStart + Math.floor(i / 3) * 114}));
  const height = isolated.length ? isolatedStart + Math.ceil(isolated.length / 3) * 114 + 25 : Math.max(260,tallest * 114 + 70);
  return {positions, layers, isolated, isolatedStart, width: Math.max(850, 70 + layers.size * 260), height};
}
function renderGraph() {
  const graph = $('graph');
  graph.replaceChildren(svg('title', {id:'graph-title'}, 'Selected population event DAG'), svg('desc', {id:'graph-description'}, 'Every selected event and relation appears; multiple incoming edges and merges are preserved. Columns are dependency-depth layout, not time.'));
  const {positions, layers, isolated, isolatedStart, width, height} = layout();
  graph.setAttribute('viewBox', `0 0 ${width} ${height}`); graph.setAttribute('width', width); graph.setAttribute('height', height);
  const defs = svg('defs'); const marker = svg('marker', {id:'arrow', viewBox:'0 0 10 10', refX:9, refY:5, markerWidth:7, markerHeight:7, orient:'auto-start-reverse'}); marker.append(svg('path', {d:'M 0 0 L 10 5 L 0 10 z', fill:'#637783'})); defs.append(marker); graph.append(defs);
  if (!model.nodes.length) { graph.append(svg('text', {x:35,y:75,class:'empty-label'}, 'No event model available'), svg('text',{x:35,y:105,class:'empty-sub'}, 'Readiness or no-event results are shown without invented nodes.')); return; }
  for (const column of layers.keys()) graph.append(svg('text',{x:35 + column * 260,y:24,class:'depth-label'}, `Dependency layout level ${column}`));
  if (isolated.length) graph.append(svg('text', {x:35,y:isolatedStart - 18,class:'depth-label'}, 'Events with no selected relations · grid position has no ordering meaning'));
  for (const edge of model.edges) {
    const from = positions.get(edge.source), to = positions.get(edge.target), x1 = from.x + 185, y1 = from.y + 37, x2 = to.x, y2 = to.y + 37;
    const related = edge.source === selected || edge.target === selected;
    const path = svg('path', {d:`M${x1},${y1} C${x1+40},${y1} ${x2-40},${y2} ${x2-7},${y2}`,class:`edge ${selected ? (related ? 'related' : 'dimmed') : ''}`,'marker-end':'url(#arrow)'});
    path.append(svg('title', {}, `${edge.source} → ${edge.target}; ${edge.relation}; bootstrap ${pct(edge.bootstrap_support)}; ${edge.direction_basis}`)); graph.append(path);
    if (edge.bootstrap_support !== null && edge.bootstrap_support !== undefined) graph.append(svg('text',{x:(x1+x2)/2,y:(y1+y2)/2-7,'text-anchor':'middle',class:'edge-support'}, pct(edge.bootstrap_support)));
  }
  for (const node of model.nodes) {
    const {x,y} = positions.get(node.id);
    const group = svg('g', {class:`event-node ${node.id === selected ? 'selected' : ''}`, transform:`translate(${x},${y})`, role:'button',tabindex:0,'data-graph-event':node.id,'aria-label':`${node.label}; discovery ${counts(node,'discovery')}; evaluation ${counts(node,'evaluation')}; ${parents[node.id].length} selected parents`,'aria-pressed':node.id === selected ? 'true' : 'false'});
    group.append(svg('rect',{x:0,y:0,width:185,height:76,rx:5,fill:filledColor(node)}));
    group.append(svg('title',{},node.label),svg('text',{x:12,y:23,class:'event-name'},node.id),svg('text',{x:12,y:44,class:'event-count'},`Discovery ${counts(node,'discovery')}`),svg('text',{x:12,y:62,class:'event-count'},`Evaluation ${counts(node,'evaluation')}`));
    group.addEventListener('click', () => selectEvent(node.id)); group.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); selectEvent(node.id); } }); graph.append(group);
  }
}
function renderTables() {
  $('events').replaceChildren();
  for (const node of model.nodes) { const row = el('tr'); row.dataset.eventId = node.id; const name = el('td'); name.append(eventButton(node)); row.append(name,el('td',counts(node,'discovery')),el('td',counts(node,'evaluation')),el('td',parents[node.id].map((id)=>model.nodes.find((item)=>item.id===id).label).join(', ') || 'No selected parents')); $('events').append(row); }
  $('edges').replaceChildren();
  for (const edge of model.edges) { const row = el('tr'); const relation = el('td'); relation.append(el('strong',`${edge.source} → ${edge.target}`)); const details = el('details'); details.append(el('summary','Relation and direction basis'),el('p',`${edge.relation}: ${edge.direction_basis}`)); relation.append(details); row.append(relation); for (const value of [bootstrap(edge),nullFits(edge),number(edge.permutation_probability_raising_p),number(edge.permutation_probability_raising_BH_q),delta(edge.evaluation_observations?.probability_raising_delta),edge.meets_display_stability_threshold === undefined ? 'NR' : edge.meets_display_stability_threshold ? 'Meets criterion' : 'Does not meet']) row.append(el('td',value)); $('edges').append(row); }
  if (!model.edges.length) { const row = el('tr'); row.append(el('td','No selected relations were supplied. This is a valid negative or readiness result.',{colspan:7})); $('edges').append(row); }
}
function renderAssessment() {
  $('assessment').hidden = false;
  const total = model.edges.length;
  const stableKnown = model.edges.filter((edge) => typeof edge.meets_display_stability_threshold === 'boolean');
  const stable = stableKnown.filter((edge) => edge.meets_display_stability_threshold).length;
  const qKnown = model.edges.filter((edge) => edge.permutation_probability_raising_BH_q !== null && edge.permutation_probability_raising_BH_q !== undefined);
  const qBelow = qKnown.filter((edge) => edge.permutation_probability_raising_BH_q < 0.05).length;
  const threshold = model.validation?.stability_display_threshold;
  const holdout = model.validation?.holdout;
  const interval = holdout?.conditional_descriptive_95_percent_interval;
  const metrics = $('assessment-metrics'); metrics.replaceChildren();
  const addMetric = (label,value) => metrics.append(el('dt',label),el('dd',value));
  addMetric(`Bootstrap stability${threshold !== undefined ? ` ≥ ${threshold}` : ' (source criterion)'}`,stableKnown.length ? `${stable} / ${stableKnown.length} selected relations meet criterion` : 'NR');
  addMetric('Burden-stratified permutation BH q < 0.05',qKnown.length ? `${qBelow} / ${qKnown.length} selected relations` : 'NR');
  if (holdout) addMetric('Frozen evaluation gain vs independence',`${number(holdout.graph_minus_independence_mean_nats)} nats / participant`);
  if (interval) addMetric('Descriptive 95% interval',`[${number(interval[0])}, ${number(interval[1])}]${interval[0] <= 0 && interval[1] >= 0 ? ' · includes zero' : ''}`);
  $('assessment-conclusion').textContent = !total ? 'No relations were selected. None were invented for display.' : stableKnown.length === total && !stable && qKnown.length === total && !qBelow ? 'The selected graph is exploratory: no selected relation meets the source stability criterion or BH q < 0.05. These results do not demonstrate robust evolutionary routes.' : 'The fitted relations remain exploratory statistical hypotheses; inspect their individual diagnostics and the frozen evaluation result.';
  $('assessment-limit').textContent = holdout?.interval_limitation || 'Bootstrap selection and association diagnostics do not establish chronology, causality or clonal ancestry.';
}
async function start() {
  try {
    const availableResponse = await fetch('available-models.json'); const available = await availableResponse.json();
    const selector = $('model-select'); selector.replaceChildren();
    for (const option of available.models) { const item = el('option',`${option.label}${option.available ? ` (${option.discovery_n} + ${option.evaluation_n})` : ' (not ready)'}`,{value:option.id}); item.disabled = !option.available; item.selected = option.id === selectedModel; selector.append(item); }
    selector.disabled = false; selector.addEventListener('change',()=>{ window.location.search = `?model=${encodeURIComponent(selector.value)}`; });
    const response = await fetch(`model.json${modelQuery}`); if (!response.ok) throw new Error(`Model is not ready (${response.status}).`); const payload = await response.json(); model = payload.model;
    parents = Object.fromEntries(model.nodes.map((node)=>[node.id,[]])); for (const edge of model.edges) parents[edge.target].push(edge.source);
    const modelLabel = available.models.find((item)=>item.id === selectedModel)?.label || selectedModel;
    $('cohort-summary').textContent = `${modelLabel} · TCGA ${model.cohort.histology} · discovery ${model.cohort.discovery_n} · evaluation ${model.cohort.evaluation_n} · ${model.nodes.length} events · ${model.edges.length} selected relations`;
    $('native-link').href = selectedModel === 'pathology_sensitivity' ? 'http://127.0.0.1:4000/tcga/luad/population/edges/pathology/sensitivity' : 'http://127.0.0.1:4000/tcga/luad/population/edges';
    if (!model.nodes.length) $('native-link').hidden = true;
    $('method-description').textContent = `${model.method.name}: ${model.method.semantics}`;
    $('model-status').textContent = `Source status: ${model.model_status || 'Not supplied'}${model.edges.length ? '' : ' · No selected relations; none were invented.'}`;
    $('fingerprint').textContent = `Source model SHA256 ${payload.sha256}`;
    $('audit').textContent = JSON.stringify({method:model.method,cohort:model.cohort,validation:model.validation,parameters:model.parameters},null,2);
    $('edge-testing-note').textContent = `${model.validation?.multiple_testing || 'Multiple-testing scope not supplied.'}${model.validation?.ordered_pair_tests !== undefined ? ` ${model.validation.ordered_pair_tests} ordered event pairs tested.` : ''}`;
    $('limitations').replaceChildren(...(model.limitations || []).map((item)=>el('li',item)));
    renderTables(); renderAssessment(); selected = model.nodes[0]?.id; renderGraph(); renderInspector();
    $('fill').addEventListener('change',renderGraph);
    $('download').disabled = false; $('download').addEventListener('click',()=>{ const a = el('a',undefined,{href:`source-model.json${modelQuery}`,download:`population-event-model-${selectedModel}.json`}); a.click(); });
  } catch(error) { $('error').hidden = false; $('error').textContent = `${error.message} Prepare and validate a source model, then reload. No reconstruction is substituted.`; $('cohort-summary').textContent = 'Source model unavailable'; }
}
start();
