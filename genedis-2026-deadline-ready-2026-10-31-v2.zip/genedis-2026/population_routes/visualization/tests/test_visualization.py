"""Scientific projection checks with explicitly fictional graph fixtures."""
from pathlib import Path
import copy
import importlib.util
import json
import sys
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "population_routes" / "visualization"))
sys.path.insert(0, str(ROOT / "nextstrain" / "tests"))
from adapter import ModelError, convert, validate_model, validate_projection
from schema_validation import validate_dataset
from server import make_handler


def fixture():
    # A->C<-B and C->D is a merge, with E explicitly isolated.
    return {
        "schema_version": "fictional_test_only",
        "model_status": "FICTIONAL TEST FIXTURE, never user research data",
        "method": {"name": "Fictional method fixture", "semantics": "Fictional conditional-dependence graph for adapter tests", "parent_semantics": "Joint conditioning set, not deterministic AND"},
        "cohort": {"histology": "FICTIONAL", "discovery_n": 100, "evaluation_n": 40},
        "nodes": [{"id": key, "label": f"Fictional {key}", "discovery_present": count, "discovery_n": n, "evaluation_present": 5, "evaluation_n": 37} for key, count, n in [("A", 60, 100), ("B", 50, 99), ("C", 30, 95), ("D", 20, 100), ("E", 22, 98)]],
        "edges": [{"source": source, "target": target, "relation": "conditional_dependence", "direction_basis": "Fictional direction fixture", "bootstrap_support": support, "permutation_support": None, "heldout_direction_support": 0.62} for source, target, support in [("A", "C", 0.9), ("B", "C", 0.8), ("C", "D", 0.7)]],
        "validation": {"fixture": True}, "limitations": ["Entirely fictional graph used for meaningful fidelity tests"],
    }


class EdgeForestTests(unittest.TestCase):
    def test_merge_and_complete_parent_set_survive_without_path_unfolding(self):
        model = fixture()
        dataset = convert(model, source_sha256="a" * 64)
        # Three single-edge components + one isolated event, never a shared root.
        self.assertIsInstance(dataset["tree"], list)
        self.assertEqual(len(dataset["tree"]), 4)
        shown_edges = []
        for component in dataset["tree"]:
            self.assertEqual(component["node_attrs"]["div"], 0)
            self.assertLessEqual(len(component.get("children", [])), 1)
            if component.get("children"):
                child = component["children"][0]
                self.assertEqual(child["node_attrs"]["div"], 1)
                self.assertNotIn("children", child)
                shown_edges.append((component["node_attrs"]["event_id"]["value"], child["node_attrs"]["event_id"]["value"]))
                if child["node_attrs"]["event_id"]["value"] == "C":
                    self.assertEqual(child["node_attrs"]["full_parent_set"]["value"], "A; B")
        self.assertEqual(shown_edges, [("A", "C"), ("B", "C"), ("C", "D")])
        self.assertEqual(dataset["meta"]["extensions"]["population_routes"]["authoritative_model"], model)
        validate_dataset(dataset)

    def test_exact_event_specific_denominators_support_and_no_invented_dates(self):
        model = fixture()
        dataset = convert(model, source_sha256="a" * 64)
        child = dataset["tree"][0]["children"][0]
        self.assertEqual(child["node_attrs"]["discovery_count"]["value"], 30)
        self.assertEqual(child["node_attrs"]["discovery_denominator"]["value"], 95)
        self.assertAlmostEqual(child["node_attrs"]["discovery_frequency"]["value"], 30 / 95)
        self.assertEqual(child["node_attrs"]["bootstrap_support"]["value"], 0.9)
        self.assertNotIn("permutation_support", child["node_attrs"])
        for component in dataset["tree"]:
            for node in [component, *component.get("children", [])]:
                self.assertNotIn("num_date", node["node_attrs"])
                self.assertNotIn("mutations", node["branch_attrs"])
        self.assertEqual(dataset["meta"]["panels"], ["tree"])

    def test_no_edge_negative_result_invents_no_relations(self):
        model = fixture()
        model["edges"] = []
        dataset = convert(model, source_sha256="a" * 64)
        self.assertEqual(len(dataset["tree"]), 5)
        self.assertFalse(any(component.get("children") for component in dataset["tree"]))
        report = validate_projection(model, dataset)
        self.assertEqual(report["source_selected_edges"], 0)
        validate_dataset(dataset)

    def test_boolean_source_flags_are_legible_strings_but_raw_model_is_unchanged(self):
        model = fixture()
        model["edges"][0].update(meets_display_stability_threshold=False, heldout_descriptive_direction_compatible=True, burden_null_selection_frequency=0.12, permutation_probability_raising_p=0.04, permutation_probability_raising_BH_q=0.4)
        model["edges"][0]["evaluation_observations"] = {"probability_raising_delta": -0.12}
        dataset = convert(model, source_sha256="a" * 64)
        attrs = dataset["tree"][0]["children"][0]["node_attrs"]
        self.assertEqual(attrs["meets_display_stability_threshold"]["value"], "No")
        self.assertEqual(attrs["heldout_descriptive_direction_compatible"]["value"], "Yes")
        self.assertEqual(attrs["permutation_probability_raising_BH_q"]["value"], 0.4)
        self.assertEqual(attrs["evaluation_probability_raising_delta"]["value"], -0.12)
        self.assertIs(dataset["meta"]["extensions"]["population_routes"]["authoritative_model"]["edges"][0]["meets_display_stability_threshold"], False)
        validate_dataset(dataset)

    def test_no_event_readiness_result_has_no_fabricated_dataset(self):
        model = fixture()
        model["nodes"] = []
        model["edges"] = []
        self.assertIsNone(convert(model, source_sha256="a" * 64))

    def test_reject_cycles_unknown_nodes_duplicates_missing_semantics_and_counts(self):
        changes = [
            lambda m: m["edges"].append(dict(m["edges"][0], source="D", target="A")),
            lambda m: m["edges"][0].update(source="UNKNOWN"),
            lambda m: m["edges"].append(copy.deepcopy(m["edges"][0])),
            lambda m: m["method"].pop("semantics"),
            lambda m: m["nodes"][0].update(discovery_present=101),
            lambda m: m["edges"][0].update(bootstrap_support=95),
            lambda m: m["edges"][0].update(selected=False),
        ]
        for change in changes:
            model = fixture()
            change(model)
            with self.assertRaises(ModelError):
                validate_model(model)

    def test_audit_detects_dropped_parent_edge_count_support_or_embedded_model(self):
        model = fixture()
        changes = [
            lambda d: d["tree"][0]["children"][0]["node_attrs"]["full_parent_set"].update(value="A"),
            lambda d: d["tree"].pop(1),
            lambda d: d["tree"][0]["children"][0]["node_attrs"]["discovery_denominator"].update(value=100),
            lambda d: d["tree"][0]["children"][0]["node_attrs"]["bootstrap_support"].update(value=1),
            lambda d: d["meta"]["extensions"]["population_routes"]["authoritative_model"]["edges"].pop(),
            lambda d: d["tree"][0]["children"][0]["node_attrs"].update(div=50),
        ]
        for change in changes:
            dataset = convert(model, source_sha256="a" * 64)
            change(dataset)
            with self.assertRaises(ModelError):
                validate_projection(model, dataset)

    def test_actual_model_when_available_is_schema_valid_and_loss_audited(self):
        folder = ROOT / "population_routes" / "inference" / "output"
        paths = [folder / "model.json", folder / "pathology_sensitivity" / "model.json"]
        if not paths[0].exists():
            self.skipTest("Actual inferred model has not been generated; fictional fixtures are not scientific results")
        for path in paths:
            if path.exists():
                with self.subTest(model_path=path):
                    model = json.loads(path.read_text(encoding="utf-8"))
                    dataset = convert(model, source_sha256="b" * 64)
                    if dataset:
                        validate_dataset(dataset)
                        validate_projection(model, dataset)


class CompanionServerTests(unittest.TestCase):
    def test_serves_exact_validated_model_and_rejects_other_paths_or_invalid_model(self):
        runtime = ROOT / "population_routes" / "visualization" / ".runtime"
        runtime.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="fictional-http-test-", dir=runtime) as temporary:
            path = Path(temporary).resolve() / "fictional-model.json"
            self.assertTrue(path.is_relative_to(runtime.resolve()))
            source = fixture()
            path.write_text(json.dumps(source), encoding="utf-8")
            sensitivity_path = path.parent / "fictional-sensitivity.json"
            sensitivity = copy.deepcopy(source)
            sensitivity["model_status"] = "FICTIONAL SEPARATE SENSITIVITY FIXTURE"
            sensitivity_path.write_text(json.dumps(sensitivity), encoding="utf-8")
            handler = make_handler(path, sensitivity_path)
            handler.log_message = lambda *args: None
            server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            url = f"http://127.0.0.1:{server.server_port}"
            try:
                with urllib.request.urlopen(url + "/model.json") as response:
                    payload = json.load(response)
                    self.assertEqual(payload["model"], source)
                    self.assertEqual(response.headers["Cache-Control"], "no-store")
                    self.assertIn("default-src 'self'", response.headers["Content-Security-Policy"])
                with urllib.request.urlopen(url + "/source-model.json") as response:
                    self.assertEqual(response.read(), path.read_bytes())
                    self.assertIn("attachment", response.headers["Content-Disposition"])
                with urllib.request.urlopen(url + "/model.json?model=pathology_sensitivity") as response:
                    self.assertEqual(json.load(response)["model"], sensitivity)
                with urllib.request.urlopen(url + "/available-models.json") as response:
                    self.assertEqual([item["id"] for item in json.load(response)["models"]], ["baseline", "pathology_sensitivity"])
                with self.assertRaises(urllib.error.HTTPError) as error:
                    urllib.request.urlopen(url + "/../inference/output/model.json")
                self.assertEqual(error.exception.code, 404)
                source["edges"][0]["target"] = "UNKNOWN"
                path.write_text(json.dumps(source), encoding="utf-8")
                with self.assertRaises(urllib.error.HTTPError) as error:
                    urllib.request.urlopen(url + "/model.json")
                self.assertEqual(error.exception.code, 503)
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=2)


if __name__ == "__main__":
    unittest.main()
