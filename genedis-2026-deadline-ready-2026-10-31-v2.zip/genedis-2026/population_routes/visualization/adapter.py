"""Loss-audited population DAG -> genuine Auspice edge-forest adapter.

The authoritative object is the statistical event DAG. Each selected edge gets
one independent two-event component in Auspice. Event copies never represent
patients, clones or ancestry; full parent sets remain attached to every copy.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
from urllib.parse import quote


class ModelError(ValueError):
    pass


SUPPORTS = ("bootstrap_support", "permutation_support", "heldout_direction_support")
EDGE_DISPLAY_FIELDS = {
    "bootstrap_selected": "Bootstrap selected fits",
    "bootstrap_successful": "Bootstrap successful fits",
    "burden_null_selection_frequency": "Burden-stratified null selection frequency",
    "null_selected": "Burden null selected fits",
    "null_successful": "Burden null successful fits",
    "permutation_probability_raising_p": "Burden-stratified permutation p",
    "permutation_probability_raising_BH_q": "Burden-stratified permutation BH q",
    "meets_display_stability_threshold": "Meets source stability criterion",
    "heldout_descriptive_direction_compatible": "Held-out descriptive compatibility; not timing confidence",
}


def edge_display_traits(edge: dict) -> dict:
    # Auspice's stock popup can suppress boolean false/true values. Render these
    # source flags explicitly, retaining original booleans in the embedded model.
    traits = {key: ("Yes" if edge[key] else "No") if isinstance(edge[key], bool) else edge[key] for key in EDGE_DISPLAY_FIELDS if edge.get(key) is not None}
    for prefix in ("training", "evaluation"):
        observation = edge.get(f"{prefix}_observations", {})
        if observation.get("probability_raising_delta") is not None:
            traits[f"{prefix}_probability_raising_delta"] = observation["probability_raising_delta"]
    return traits


def validate_model(model: dict) -> tuple[dict[str, dict], dict[str, list[str]]]:
    if not isinstance(model, dict):
        raise ModelError("Model must be a JSON object")
    if not isinstance(model.get("method"), dict) or not model["method"].get("name") or not model["method"].get("semantics"):
        raise ModelError("Method name and explicit edge semantics are required")
    cohort = model.get("cohort", {})
    if not cohort.get("histology"):
        raise ModelError("An explicit, separate histology is required")
    for field in ("discovery_n", "evaluation_n"):
        if isinstance(cohort.get(field), bool) or not isinstance(cohort.get(field), int) or cohort[field] < 0:
            raise ModelError(f"cohort.{field} must be a nonnegative integer")
    if not isinstance(model.get("nodes"), list) or not isinstance(model.get("edges"), list):
        raise ModelError("nodes and edges must be arrays; an empty selected graph is valid")
    nodes = {}
    for row in model["nodes"]:
        node_id = row.get("id")
        if not isinstance(node_id, str) or not node_id:
            raise ModelError("Event IDs must be nonempty strings")
        if node_id in nodes:
            raise ModelError(f"Duplicate event ID {node_id}")
        if not isinstance(row.get("label"), str) or not row["label"]:
            raise ModelError(f"Missing event label: {node_id}")
        for prefix in ("discovery", "evaluation"):
            present, denominator = row.get(f"{prefix}_present"), row.get(f"{prefix}_n")
            if isinstance(denominator, bool) or not isinstance(denominator, int) or denominator < 0 or denominator > cohort[f"{prefix}_n"]:
                raise ModelError(f"Invalid {prefix} denominator at {node_id}")
            if isinstance(present, bool) or not isinstance(present, int) or not 0 <= present <= denominator:
                raise ModelError(f"Invalid {prefix} event count at {node_id}")
        nodes[node_id] = row
    parents = {key: [] for key in nodes}
    children = {key: [] for key in nodes}
    seen = set()
    for edge in model["edges"]:
        pair = (edge.get("source"), edge.get("target"))
        if pair[0] not in nodes or pair[1] not in nodes:
            raise ModelError(f"Unknown endpoint in edge {pair}")
        if pair[0] == pair[1] or pair in seen:
            raise ModelError(f"Self edge or duplicate edge {pair}")
        if edge.get("selected") is False:
            raise ModelError("edges must contain the selected graph; unselected candidates belong in a separate audit")
        if not edge.get("relation") or not edge.get("direction_basis"):
            raise ModelError(f"Relation and explicit direction_basis required for {pair}")
        for field in SUPPORTS:
            value = edge.get(field)
            if value is not None and (isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= 1):
                raise ModelError(f"{field} must be null or a fraction from 0 to 1")
        seen.add(pair)
        parents[pair[1]].append(pair[0])
        children[pair[0]].append(pair[1])
    indegree = {key: len(value) for key, value in parents.items()}
    ready = [key for key in nodes if not indegree[key]]
    visited = []
    while ready:
        current = ready.pop(0)
        visited.append(current)
        for child in children[current]:
            indegree[child] -= 1
            if indegree[child] == 0:
                ready.append(child)
    if len(visited) != len(nodes):
        raise ModelError("Selected event graph contains a cycle; no DAG projection will be made")
    for event_id, row in nodes.items():
        if "incoming_parents" in row and set(row["incoming_parents"]) != set(parents[event_id]):
            raise ModelError(f"Declared parent set disagrees with source DAG for {event_id}")
    validation = model.get("validation", {})
    threshold = validation.get("stability_display_threshold")
    if threshold is not None:
        if isinstance(threshold, bool) or not isinstance(threshold, (int, float)) or not 0 <= threshold <= 1:
            raise ModelError("Invalid source stability threshold")
        for edge in model["edges"]:
            if isinstance(edge.get("meets_display_stability_threshold"), bool) and edge.get("bootstrap_support") is not None and edge["meets_display_stability_threshold"] != (edge["bootstrap_support"] >= threshold):
                raise ModelError("Source stability flag disagrees with its reported threshold/support")
    if "selected_edges_meeting_stability_count" in validation:
        flags = [edge["meets_display_stability_threshold"] for edge in model["edges"] if isinstance(edge.get("meets_display_stability_threshold"), bool)]
        if len(flags) != len(model["edges"]) or validation["selected_edges_meeting_stability_count"] != sum(flags):
            raise ModelError("Source aggregate stability count disagrees with edge flags")
    return nodes, parents


def _encoded(value: str) -> str:
    return quote(value, safe="-_.~")


def convert(model: dict, *, source_sha256: str, updated: str = "2026-10-18", companion_url: str = "http://127.0.0.1:4001/") -> dict | None:
    nodes, parents = validate_model(model)
    if not nodes:
        return None  # Never invent an event or edge to make an empty model render.
    cohort = model["cohort"]
    name = model["method"]["name"]
    components = []
    mapping = []
    used = set()

    def make_copy(event_id: str, copy_id: str, position: int, edge: dict | None) -> dict:
        row = nodes[event_id]
        edge_label = f"{edge['source']} → {edge['target']}" if edge else f"Isolated event: {event_id}"
        attrs = {
            "div": position,
            "event_id": {"value": event_id},
            "event_label": {"value": row["label"]},
            "edge_label": {"value": edge_label},
            "representation": {"value": "Event copy in an independent edge component" if edge else "Isolated event; no selected edge"},
            "full_parent_set": {"value": "; ".join(parents[event_id]) or "No selected parents"},
            "parent_semantics": {"value": str(model["method"].get("parent_semantics", "Joint conditioning set; no deterministic AND or necessity claim"))},
            "sequence_calls_status": {"value": "Not supplied; this is a statistical event model"},
            "distance_units": {"value": "Unitless component layout position; no time or mutation-length meaning"},
        }
        for prefix in ("discovery", "evaluation"):
            attrs[f"{prefix}_count"] = {"value": row[f"{prefix}_present"]}
            attrs[f"{prefix}_denominator"] = {"value": row[f"{prefix}_n"]}
            if row[f"{prefix}_n"]:
                attrs[f"{prefix}_frequency"] = {"value": row[f"{prefix}_present"] / row[f"{prefix}_n"]}
        if edge:
            attrs["relation"] = {"value": edge["relation"]}
            attrs["direction_basis"] = {"value": edge["direction_basis"]}
            for field in SUPPORTS:
                if edge.get(field) is not None:
                    attrs[field] = {"value": edge[field]}
            for field, value in edge_display_traits(edge).items():
                attrs[field] = {"value": value}
        node = {"name": copy_id, "node_attrs": attrs, "branch_attrs": {"labels": {"event": str(row["label"])}}}
        mapping.append({"auspice_node_name": copy_id, "event_id": event_id, "component_edge": [edge["source"], edge["target"]] if edge else None})
        return node

    for i, edge in enumerate(model["edges"]):
        source, target = edge["source"], edge["target"]
        parent = make_copy(source, f"edge_{i}_from_{_encoded(source)}", 0, edge)
        child = make_copy(target, f"edge_{i}_to_{_encoded(target)}", 1, edge)
        parent["children"] = [child]
        components.append(parent)
        used.update((source, target))
    for event_id in nodes:
        if event_id not in used:
            components.append(make_copy(event_id, f"isolated_{_encoded(event_id)}", 0, None))
    description = (
        f"## Statistical population event model: {cohort['histology']}\n\n"
        f"**Source model:** {model.get('title', 'Source title not supplied')}.\n\n"
        f"Method: **{name}**. {model['method']['semantics']}\n\n"
        f"Discovery participants: **{cohort['discovery_n']}**. Evaluation participants: **{cohort['evaluation_n']}**. "
        f"Per-event eligible denominators and support values are preserved in node metadata.\n\n"
        f"## Read this view as an edge list\n\n"
        f"Every selected directed model edge appears exactly once as an **independent two-event component**. "
        f"Repeated event labels are explicit display copies. Isolated events appear as singleton components. "
        f"The tree-shaped components do not represent tumours, patients, clones or biological ancestors. "
        f"There is no common biological root and no invented patient tips.\n\n"
        f"Support metadata on either event copy applies to its component's selected edge, not to the "
        f"event identity. Bootstrap selection frequency is not a probability of true temporal order.\n\n"
        f"**Horizontal position 0→1 is a unitless layout convention**, not elapsed time, mutation burden or "
        f"evidence strength. Auspice's stock 'Divergence', 'genomes' and sequence-popup wording does not carry "
        f"those biological meanings here. 'No sequence changes observed' means sequence strings were not supplied.\n\n"
        f"**Projection loss:** The native forest does not draw merged events once, connect edges into multistep "
        f"paths, or visually show joint conditioning sets. No parent is discarded or preferred. Each event copy "
        f"retains its full selected-parent set; multiple parents are not automatically an AND gate or necessary "
        f"prerequisites. [Open the authoritative exact DAG and model audit]({companion_url}) for the merged graph. "
        f"The complete source model is also embedded unchanged in this dataset's meta.extensions.population_routes.\n\n"
        f"**Limitations:** " + " ".join(str(item) for item in model.get("limitations", [])) +
        f"\n\nSource model SHA256: `{source_sha256}`. Build date {updated} is not a patient sampling date."
    )
    stable_flags = [edge["meets_display_stability_threshold"] for edge in model["edges"] if isinstance(edge.get("meets_display_stability_threshold"), bool)]
    known_q = [edge["permutation_probability_raising_BH_q"] for edge in model["edges"] if edge.get("permutation_probability_raising_BH_q") is not None]
    assessment = ""
    threshold = model.get("validation", {}).get("stability_display_threshold")
    if stable_flags:
        criterion = f"≥{threshold}" if threshold is not None else "source criterion"
        assessment += f"{sum(stable_flags)}/{len(stable_flags)} selected relations meet bootstrap stability {criterion}. "
    if known_q:
        assessment += f"{sum(q < 0.05 for q in known_q)}/{len(known_q)} have burden-stratified permutation BH q<0.05. "
    if assessment:
        description += "\n\n**Source diagnostic assessment:** " + assessment
    holdout = model.get("validation", {}).get("holdout", {})
    if "graph_minus_independence_mean_nats" in holdout:
        description += f"\n\n**Frozen evaluation:** graph-minus-independence gain {holdout['graph_minus_independence_mean_nats']:.6g} nats per participant. "
        interval = holdout.get("conditional_descriptive_95_percent_interval")
        if interval:
            description += f"Descriptive 95% interval [{interval[0]:.6g}, {interval[1]:.6g}]" + (" includes zero. " if interval[0] <= 0 <= interval[1] else ". ")
        description += str(holdout.get("interval_limitation", ""))
    colorings = [
        {"key": "event_label", "title": "Model event", "type": "categorical"},
        {"key": "edge_label", "title": "Selected edge / isolated event", "type": "categorical"},
        {"key": "event_id", "title": "Event ID", "type": "categorical"},
        {"key": "full_parent_set", "title": "Full selected-parent set", "type": "categorical"},
        {"key": "parent_semantics", "title": "Parent-set interpretation", "type": "categorical"},
        {"key": "representation", "title": "Display representation", "type": "categorical"},
        {"key": "distance_units", "title": "Display distance units", "type": "categorical"},
        {"key": "sequence_calls_status", "title": "Sequence calls (integration status)", "type": "categorical"},
        {"key": "relation", "title": "Model relation", "type": "categorical"},
        {"key": "direction_basis", "title": "Direction basis", "type": "categorical"},
    ]
    for prefix in ("discovery", "evaluation"):
        colorings.extend([
            {"key": f"{prefix}_count", "title": f"{prefix.capitalize()} event count", "type": "continuous"},
            {"key": f"{prefix}_denominator", "title": f"{prefix.capitalize()} eligible denominator", "type": "continuous"},
            {"key": f"{prefix}_frequency", "title": f"{prefix.capitalize()} event frequency", "type": "continuous", "scale": [[0, "#40C4F4"], [0.5, "#1684E8"], [1, "#4A16AD"]]},
        ])
    for field in SUPPORTS:
        if any(edge.get(field) is not None for edge in model["edges"]):
            title = {"bootstrap_support": "Edge bootstrap selection frequency", "permutation_support": "Reported edge permutation support", "heldout_direction_support": "Reported held-out direction support"}[field]
            colorings.append({"key": field, "title": title, "type": "continuous", "scale": [[0, "#B5BEC7"], [1, "#16656C"]]})
    for field, title in EDGE_DISPLAY_FIELDS.items():
        values = [edge_display_traits(edge)[field] for edge in model["edges"] if edge.get(field) is not None]
        if values:
            colorings.append({"key": field, "title": title, "type": "categorical" if any(isinstance(value, str) for value in values) else "continuous"})
    for prefix in ("training", "evaluation"):
        if any(f"{prefix}_probability_raising_delta" in edge_display_traits(edge) for edge in model["edges"]):
            colorings.append({"key": f"{prefix}_probability_raising_delta", "title": f"{prefix.capitalize()} probability-raising Δ (probability units)", "type": "continuous"})
    result = {
        "version": "v2",
        "meta": {
            "title": f"TCGA {model.get('title', cohort['histology'] + ' population event relations')} — independent edge components",
            "updated": updated,
            "warning": "STATISTICAL EVENT MODEL, not a tumour phylogeny. " + assessment + "Each connected component is one selected edge; isolated events are shown separately. Repeated events are copies. Distance is unitless layout. The exact DAG is authoritative for merges and conditioning sets.",
            "description": description,
            "panels": ["tree"], "stream_labels": [],
            "filters": ["event_label", "relation"],
            "colorings": colorings,
            "display_defaults": {"distance_measure": "div", "layout": "rect", "color_by": "discovery_frequency", "branch_label": "none", "tip_label": "edge_label", "sidebar": "open"},
            "maintainers": [{"name": "GeNeDis exploratory population-model integration"}],
            "extensions": {"population_routes": {"representation": "all_selected_edges_as_independent_components", "source_model_sha256": source_sha256, "authoritative_model": copy.deepcopy(model), "copy_mapping": mapping}},
        },
        "tree": components,
    }
    validate_projection(model, result)
    return result


def validate_projection(model: dict, dataset: dict) -> dict:
    nodes, parents = validate_model(model)
    forest = dataset["tree"]
    if not isinstance(forest, list):
        raise ModelError("Population relation view must be an explicit forest")
    actual_edges = []
    displayed_events = set()
    names = set()
    for component in forest:
        copies = [component, *component.get("children", [])]
        if len(copies) > 2:
            raise ModelError("A component may contain only one model edge")
        if component["node_attrs"]["div"] != 0:
            raise ModelError("Independent component origin must be display position zero")
        if component.get("children"):
            child = component["children"][0]
            if child.get("children") or child["node_attrs"]["div"] != 1:
                raise ModelError("No multistep path or meaningful branch length may be invented")
            actual_edges.append((component["node_attrs"]["event_id"]["value"], child["node_attrs"]["event_id"]["value"]))
        for node in copies:
            attrs = node["node_attrs"]
            event_id = attrs["event_id"]["value"]
            if event_id not in nodes or node["name"] in names:
                raise ModelError("Unknown event copy or repeated Auspice name")
            names.add(node["name"])
            displayed_events.add(event_id)
            if attrs["full_parent_set"]["value"] != ("; ".join(parents[event_id]) or "No selected parents"):
                raise ModelError("A selected parent was omitted or added in display metadata")
            for prefix in ("discovery", "evaluation"):
                if attrs[f"{prefix}_count"]["value"] != nodes[event_id][f"{prefix}_present"] or attrs[f"{prefix}_denominator"]["value"] != nodes[event_id][f"{prefix}_n"]:
                    raise ModelError("Event counts or eligible denominators changed")
            if "num_date" in attrs or "mutations" in node.get("branch_attrs", {}):
                raise ModelError("Dates and sequence-level mutations must not be invented")
    expected_edges = [(edge["source"], edge["target"]) for edge in model["edges"]]
    if sorted(actual_edges) != sorted(expected_edges) or displayed_events != set(nodes):
        raise ModelError("Projection loses or invents events/selected edges")
    edge_lookup = {(edge["source"], edge["target"]): edge for edge in model["edges"]}
    for component in forest:
        if not component.get("children"):
            continue
        child = component["children"][0]
        pair = (component["node_attrs"]["event_id"]["value"], child["node_attrs"]["event_id"]["value"])
        edge = edge_lookup[pair]
        for node in (component, child):
            for field in (*SUPPORTS, "relation", "direction_basis"):
                actual = node["node_attrs"].get(field, {}).get("value")
                if actual != edge.get(field):
                    raise ModelError(f"Edge {field} changed in the native projection")
            for field, value in edge_display_traits(edge).items():
                if node["node_attrs"].get(field, {}).get("value") != value:
                    raise ModelError(f"Edge diagnostic {field} changed in the native projection")
    embedded = dataset["meta"]["extensions"]["population_routes"]["authoritative_model"]
    if embedded != model:
        raise ModelError("Embedded authoritative DAG differs from source model")
    return {"source_events": len(nodes), "source_selected_edges": len(expected_edges), "rendered_components": len(forest), "rendered_event_copies": len(names), "all_selected_edges_preserved": True, "all_event_counts_and_denominators_preserved": True, "full_parent_sets_preserved": True, "model_embedded_unchanged": True, "ancestry_inferred_by_adapter": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, default=Path("population_routes/inference/output/model.json"))
    parser.add_argument("--output", type=Path, default=Path("nextstrain/datasets/tcga_luad_population_edges.json"))
    parser.add_argument("--report", type=Path, default=Path("population_routes/visualization/output/projection_audit.json"))
    parser.add_argument("--updated", default="2026-10-18")
    parser.add_argument("--companion-url", default="http://127.0.0.1:4001/")
    args = parser.parse_args()
    raw = args.model.read_bytes()
    model = json.loads(raw)
    sha256 = hashlib.sha256(raw).hexdigest()
    dataset = convert(model, source_sha256=sha256, updated=args.updated, companion_url=args.companion_url)
    report = validate_projection(model, dataset) if dataset else {"source_events": 0, "source_selected_edges": 0, "native_export_status": "No events supplied; no fabricated dataset written"}
    report["source_model_sha256"] = sha256
    args.report.parent.mkdir(parents=True, exist_ok=True)
    if dataset:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(dataset, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
        report["dataset_sha256"] = hashlib.sha256(args.output.read_bytes()).hexdigest()
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
