"""Read-only localhost companion for the exact statistical event DAG."""
from pathlib import Path
import argparse
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from urllib.parse import parse_qs, urlparse

from adapter import validate_model


def make_handler(model_path: Path, sensitivity_path: Path | None = None):
    static = Path(__file__).resolve().parent
    model_paths = {"baseline": model_path}
    if sensitivity_path is not None:
        model_paths["pathology_sensitivity"] = sensitivity_path

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urlparse(self.path)
            path = parsed.path
            model_key = parse_qs(parsed.query).get("model", ["baseline"])[0]
            if model_key not in model_paths:
                self.send_error(404, "Unknown model selection")
                return
            if path == "/available-models.json":
                options = []
                for key, source_path in model_paths.items():
                    option = {"id": key, "label": "Baseline source cohort" if key == "baseline" else "Pathology exclusion sensitivity", "available": False}
                    try:
                        model = json.loads(source_path.read_bytes())
                        validate_model(model)
                        option.update({"available": True, "discovery_n": model["cohort"]["discovery_n"], "evaluation_n": model["cohort"]["evaluation_n"]})
                    except (OSError, ValueError):
                        pass
                    options.append(option)
                data = json.dumps({"models": options}).encode("utf-8")
                content_type = "application/json; charset=utf-8"
            elif path in {"/model.json", "/source-model.json"}:
                try:
                    raw = model_paths[model_key].read_bytes()
                    model = json.loads(raw)
                    validate_model(model)
                    data = raw if path == "/source-model.json" else json.dumps({"model": model, "sha256": hashlib.sha256(raw).hexdigest()}, allow_nan=False).encode("utf-8")
                    content_type = "application/json; charset=utf-8"
                except (OSError, ValueError) as error:
                    self.send_error(503, f"A valid model is not ready: {error}")
                    return
            elif path in {"/", "/index.html", "/app.js", "/styles.css"}:
                filename = "index.html" if path == "/" else path[1:]
                data = (static / filename).read_bytes()
                content_type = {"index.html": "text/html; charset=utf-8", "app.js": "text/javascript; charset=utf-8", "styles.css": "text/css; charset=utf-8"}[filename]
            else:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            if path == "/source-model.json":
                self.send_header("Content-Disposition", f'attachment; filename="population-event-model-{model_key}.json"')
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self'; script-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(data)

    return Handler


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, default=Path("population_routes/inference/output/model.json"))
    parser.add_argument("--sensitivity-model", type=Path, help="Separate pathology-exclusion model; defaults to MODEL_DIR/pathology_sensitivity/model.json")
    parser.add_argument("--port", type=int, default=4001)
    args = parser.parse_args()
    sensitivity_path = args.sensitivity_model or (args.model.parent / "pathology_sensitivity" / "model.json")
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(args.model.resolve(), sensitivity_path.resolve()))
    print(f"Exact population event DAG: http://127.0.0.1:{args.port}/", flush=True)
    server.serve_forever()
