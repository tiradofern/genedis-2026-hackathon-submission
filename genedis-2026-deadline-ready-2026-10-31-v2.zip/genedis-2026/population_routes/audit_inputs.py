"""Audit the frozen TCGA NSCLC input universe without inferring event chronology.

Only standard-library dependencies are needed. Source files are read-only.
Patient/sample/variant records are written only to the ignored output directory.
"""
from __future__ import annotations

import argparse
from bisect import bisect_right
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import urllib.request

HERE = Path(__file__).resolve().parent
REPOSITORY = HERE.parent
STUDIES = {"LUAD": "luad_tcga_pan_can_atlas_2018", "LUSC": "lusc_tcga_pan_can_atlas_2018"}
EXPECTED = {"LUAD": 507, "LUSC": 481}
MISSING = {"", ".", "NA", "N/A", "NAN", "NULL", "NONE"}
VARIANT_COLUMNS = ["cohort", "sample_id", "patient_id", "role", "gene", "entrez_id", "build", "chromosome", "start", "end", "ref", "alt", "variant_type", "variant_classification", "filter", "annotation_status", "t_ref_count", "t_alt_count", "t_depth", "n_ref_count", "n_alt_count", "n_depth", "hgvsp_short", "hotspot", "valid_tumor_readcounts", "valid_coordinates_alleles", "source_row", "mutation_status", "source_somatic_annotation"]


def sha256(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            value.update(chunk)
    return value.hexdigest()


def table(path: Path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        yield from csv.DictReader((line for line in stream if not line.startswith("#")), delimiter="\t")


def integer(value):
    try:
        n = float(value)
        return int(n) if math.isfinite(n) and n >= 0 and n == int(n) else None
    except (TypeError, ValueError, OverflowError):
        return None


def number(value):
    try:
        n = float(value)
        return n if math.isfinite(n) else None
    except (TypeError, ValueError):
        return None


def download_public_inputs(raw_dir: Path):
    """Retrieve only the four pinned open-access resources; never controlled MAF."""
    manifest = json.loads((HERE / "source/public_source_manifest.json").read_text())
    raw_dir.mkdir(parents=True, exist_ok=True)
    for entry in manifest:
        destination = raw_dir / entry["filename"]
        if not destination.exists():
            partial = destination.with_name(destination.name + ".partial")
            print(f"Downloading public processed input: {entry['filename']}", flush=True)
            with urllib.request.urlopen(entry["url"], timeout=120) as source, partial.open("wb") as output:
                while chunk := source.read(1024 * 1024):
                    output.write(chunk)
            if partial.stat().st_size != entry["bytes"] or sha256(partial) != entry["sha256"]:
                raise ValueError("Downloaded public source differs from pinned bytes")
            partial.replace(destination)
        if destination.stat().st_size != entry["bytes"] or sha256(destination) != entry["sha256"]:
            raise ValueError("Public source input integrity mismatch")


def audit_public_timing_inputs(output: Path, mapping: dict, report: dict):
    manifest_path = HERE / "source/public_source_manifest.json"
    if not manifest_path.exists():
        report["public_timing_inputs"] = {"status": "not_retrieved"}
        return
    manifest = json.loads(manifest_path.read_text())
    for entry in manifest:
        path = output / entry["filename"]
        if not path.exists():
            report["public_timing_inputs"] = {"status": "not_retrieved", "required_file": entry["filename"]}
            return
        if sha256(path) != entry["sha256"] or path.stat().st_size != entry["bytes"]:
            raise ValueError(f"Public processed timing source mismatch: {path.name}")
    report["public_timing_sources"] = manifest
    segments_path = output / "TCGA_mastercalls.abs_segtabs.fixed.txt"
    segments = defaultdict(lambda: defaultdict(list))
    stats = {code: Counter() for code in STUDIES}
    headers = None
    with segments_path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        headers = reader.fieldnames
        for row in reader:
            sid = row["Sample"]
            if sid not in mapping:
                continue
            cohort = mapping[sid]["cohort"]
            stats[cohort]["core_segment_rows"] += 1
            start, end = integer(row["Start"]), integer(row["End"])
            chrom = integer(row["Chromosome"])
            if start is None or end is None or chrom is None or end < start:
                stats[cohort]["invalid_segment_coordinate_rows"] += 1
                continue
            c1, c2, total = (number(row[x]) for x in ["Modal_HSCN_1", "Modal_HSCN_2", "Modal_Total_CN"])
            stats[cohort]["modal_diploid_segment_rows"] += (c1, c2, total) == (1, 1, 2)
            segments[sid][str(chrom)].append((start, end, c1, c2, total))
    for sid, chromosomes in segments.items():
        stats[mapping[sid]["cohort"]]["samples_with_segments"] += 1
        for intervals in chromosomes.values():
            intervals.sort()
            for first, second in zip(intervals, intervals[1:]):
                if first[1] >= second[0]:
                    stats[mapping[sid]["cohort"]]["overlapping_source_segments"] += 1
    starts = {sid: {chrom: [segment[0] for segment in intervals] for chrom, intervals in chromosomes.items()} for sid, chromosomes in segments.items()}
    for code in STUDIES:
        for row in table(output / f"{code}_raw_variants.tsv"):
            sid = row["sample_id"]
            chrom = row["chromosome"].removeprefix("chr")
            if chrom == "X": chrom = "23"
            if chrom == "Y": chrom = "24"
            intervals = segments.get(sid, {}).get(chrom, [])
            position, end = integer(row["start"]), integer(row["end"])
            if position is None or end is None or not intervals:
                stats[code]["variant_rows_without_numeric_segment_overlap"] += 1
                continue
            index = bisect_right(starts[sid][chrom], position) - 1
            if index < 0 or intervals[index][1] < end:
                stats[code]["variant_rows_without_numeric_segment_overlap"] += 1
                continue
            segment = intervals[index]
            stats[code]["variant_rows_with_numeric_segment_overlap"] += 1
            stats[code]["variant_rows_overlapping_modal_diploid_segment"] += segment[2:] == (1, 1, 2)
    quality = defaultdict(list)
    for row in table(output / "merged_sample_quality_annotations.tsv"):
        if row["aliquot_barcode"][:15] in mapping:
            quality[row["aliquot_barcode"]].append(row)
    pathology_reasons = {code: Counter() for code in STUDIES}
    quality_by_split = {code: defaultdict(Counter) for code in STUDIES}
    pathology_by_split = {code: Counter() for code in STUDIES}
    annotation_counts = {code: defaultdict(Counter) for code in STUDIES}
    for sid, sample in mapping.items():
        matches = quality.get(sample["absolute_dna_aliquot"], [])
        code = sample["cohort"]
        excluded = any(number(row["AWG_excluded_because_of_pathology"]) == 1 for row in matches)
        do_not_use = any(row["Do_not_use"].lower() == "true" for row in matches)
        reasons = sorted({row["AWG_pathology_exclusion_reason"] for row in matches if number(row["AWG_excluded_because_of_pathology"]) == 1})
        sample["source_quality_metadata_exact_aliquot_match"] = bool(matches)
        sample["source_awg_pathology_exclusion"] = excluded if matches else None
        sample["source_awg_pathology_reason"] = " | ".join(reasons)
        sample["source_do_not_use"] = do_not_use if matches else None
        sample["quality_mapping_status"] = "unknown" if not matches else ("flagged" if excluded or do_not_use else "mapped_not_flagged")
        sample["source_do_not_use_raw"] = " | ".join(sorted({row["Do_not_use"] for row in matches}))
        sample["source_awg_pathology_exclusion_raw"] = " | ".join(sorted({row["AWG_excluded_because_of_pathology"] for row in matches}))
        for field in ["patient_annotation", "sample_annotation", "aliquot_annotation", "aliquot_annotation_updated"]:
            sample[f"source_{field}_raw"] = " | ".join(sorted({row[field] for row in matches if row[field]}))
            # Keep full published narrative annotations only in ignored mapping.
            # The versioned report contains broad source annotation categories.
            annotation_counts[code][field].update({":".join(row[field].split(":")[:2]) for row in matches if row[field]})
        quality_by_split[code][sample["role"]][sample["quality_mapping_status"]] += 1
        if excluded:
            pathology_by_split[code][sample["role"]] += 1
        stats[code]["absolute_dna_aliquot_exact_quality_metadata_match"] += bool(matches)
        stats[code]["absolute_dna_aliquot_any_do_not_use_flag"] += do_not_use
        stats[code]["absolute_dna_aliquot_any_awg_pathology_exclusion"] += excluded
        pathology_reasons[code].update(reasons)
    report["public_timing_inputs"] = {
        "status": "audited_public_processed_data",
        "segment_headers": headers,
        "cohorts": {code: dict(values) for code, values in stats.items()},
        "source_awg_pathology_exclusion_reasons": {code: dict(values) for code, values in pathology_reasons.items()},
        "source_awg_pathology_exclusions_by_frozen_split": {code: dict(values) for code, values in pathology_by_split.items()},
        "quality_mapping_status_by_frozen_split": {code: {split: dict(values) for split, values in groups.items()} for code, groups in quality_by_split.items()},
        "other_exact_aliquot_source_annotation_counts": {code: {field: dict(values) for field, values in fields.items()} for code, fields in annotation_counts.items()},
        "quality_flag_handling": "Preserve the existing cohort and roles; export historical source flags/reasons without applying exclusions. Flagged and unflagged are not a new confirmed histologic adjudication.",
        "numeric_overlap_qualification": "Coordinate overlap is a feasibility calculation under a common-reference assumption; the public segmentation header does not specify assembly, the MAF lacks full mutation aliquots, and no cross-platform timing-quality validation was performed. It is not a validated mutation-to-copy-number link.",
        "ccf_fields_semantics": "Cancer_cell_frac_a1/a2 and CI fields describe subclonal COPY-NUMBER states; they are not CCF annotations of the MAF's somatic point mutations.",
        "copy_number_state_qualification": "Modal allele counts 1+1=2 identify modal diploid segments, not proof that no minor subclonal CN state exists or that a mutation's multiplicity is known.",
        "mutation_ccf_annotated_maf": {"access": "controlled", "filename": "TCGA_consolidated.abs_mafs_truncated.fixed.txt.gz", "gdc_id": "4d34ef36-dd77-4d6d-9e65-c4f51ae09c23", "bytes": 1204979698, "md5": "0b789095c75701c3e513c1a68baa1172", "controlled_payload_requested": False, "evidence_url": "https://gdc.cancer.gov/system/files/public/file/PanCan-General_Controlled_GDC-Manifest.txt"},
        "current_mutation_ccf_gate_passed": False,
    }


def audit(data_root: Path, prepared_root: Path, output: Path, report_path: Path):
    output.mkdir(parents=True, exist_ok=True)
    pinned_files = list(table(REPOSITORY / "manifests/public_tcga_files_2026-10-17.tsv"))
    crosswalk = list(table(REPOSITORY / "manifests/public_tcga_samples_2026-10-17.tsv"))
    bootstrap_path = prepared_root / "bootstrap.json"
    bootstrap = json.loads(bootstrap_path.read_text(encoding="utf-8"))
    mapping = {}
    report = {"schema_version": "1.0", "purpose": "Timing-input and fixed-cohort feasibility audit; no event ordering, fit, or biological inference", "prepared_fingerprint": bootstrap["fingerprint"], "sources": [], "cohorts": {}, "readiness": {}, "prohibited_shortcuts": ["VAF is not CCF", "GISTIC categories are not absolute locus copy number", "stage and RNA program scores are not chronology", "sample-key linkage is not aliquot identity", "patients are not descendants of one another"]}

    def checked_source(study, resource, path):
        matches = [x for x in pinned_files if x["study"] == study and x["resource"] == resource]
        if len(matches) != 1:
            raise ValueError(f"Missing or ambiguous pinned source: {study}/{resource}")
        pin = matches[0]
        digest = sha256(path)
        if digest != pin["sha256"] or path.stat().st_size != int(pin["bytes"]):
            raise ValueError(f"Changed pinned source: {path.name}")
        report["sources"].append({"study": study, "resource": resource, "url": pin["url"], "source_commit": pin["source_commit"], "bytes": path.stat().st_size, "sha256": digest, "verified_against_existing_manifest": True})

    purity_path = data_root / "TCGA_mastercalls.abs_tables_JSedit.fixed.txt"
    checked_source("GDC_PANCAN", purity_path.name, purity_path)
    purity_rows = list(table(purity_path))
    purity_by_sample = defaultdict(list)
    for row in purity_rows:
        purity_by_sample[row["array"]].append(row)

    for cohort, study in STUDIES.items():
        samples = bootstrap["cohorts"][cohort]["samples"]
        core = [x for x in crosswalk if x["study"] == study and x["proposed_core"] == "True"]
        expected_ids = {x["sample_id"] for x in core}
        if len(core) != EXPECTED[cohort] or len(samples) != EXPECTED[cohort] or {x["id"] for x in samples} != expected_ids:
            raise ValueError(f"Changed frozen cohort: {cohort}")
        if len({x["patient_id"] for x in samples}) != len(samples):
            raise ValueError("Participants are not independent")
        for row in samples:
            if row["role"] not in ("training", "evaluation"):
                raise ValueError("Unknown frozen split")
            candidates = purity_by_sample[row["id"]]
            if len(candidates) > 1:
                raise ValueError("Ambiguous ABSOLUTE sample-key match")
            purity = candidates[0] if candidates else {}
            p = number(purity.get("purity"))
            ploidy = number(purity.get("ploidy"))
            mapping[row["id"]] = {"cohort": cohort, "sample_id": row["id"], "patient_id": row["patient_id"], "role": row["role"], "absolute_purity": p, "absolute_ploidy": ploidy, "absolute_dna_aliquot": purity.get("sample", ""), "absolute_call_status": purity.get("call status", ""), "maf_aliquot_identity_established": False, "variant_rows": 0, "valid_tumor_readcount_rows": 0, "purity_valid": p is not None and 0 < p <= 1, "ploidy_valid": ploidy is not None and ploidy > 0}

        maf_path = data_root / study / "data_mutations.txt"
        checked_source(study, "data_mutations.txt", maf_path)
        counts, field_counts = Counter(), Counter()
        barcode_lengths, classifications, filters, builds, types = Counter(), Counter(), Counter(), Counter(), Counter()
        mutation_statuses, somatic_annotations = Counter(), Counter()
        per_sample_keys = defaultdict(set)
        seen_samples = set()
        maf_headers = []
        variant_output = output / f"{cohort}_raw_variants.tsv"
        partial_variant_output = variant_output.with_name(variant_output.name + ".partial")
        with maf_path.open(encoding="utf-8", newline="") as stream, partial_variant_output.open("w", encoding="utf-8", newline="") as target:
            reader = csv.DictReader((line for line in stream if not line.startswith("#")), delimiter="\t")
            maf_headers = reader.fieldnames
            timing_fields = [x for x in maf_headers if re.search(r"ccf|cell.?fraction|multiplicity|absolute|major.?copy|minor.?copy|purity|ploidy|aliquot|uuid", x, re.I)]
            writer = csv.DictWriter(target, fieldnames=VARIANT_COLUMNS, delimiter="\t")
            writer.writeheader()
            for row_num, row in enumerate(reader, 2):
                counts["source_maf_rows"] += 1
                sid = row["Tumor_Sample_Barcode"][:15]
                if sid not in expected_ids:
                    counts["rows_outside_frozen_core"] += 1
                    continue
                counts["core_maf_rows"] += 1
                seen_samples.add(sid)
                record = mapping[sid]
                record["variant_rows"] += 1
                barcode_lengths[len(row["Tumor_Sample_Barcode"])] += 1
                classifications[row["Variant_Classification"]] += 1
                filters[row.get("FILTER", "")] += 1
                builds[row.get("NCBI_Build", "")] += 1
                types[row.get("Variant_Type", "")] += 1
                mutation_statuses[row.get("Mutation_Status", "")] += 1
                somatic_value = str(row.get("SOMATIC", ""))
                somatic_annotations["missing" if somatic_value.upper() in MISSING else ("contains_existing_somatic_annotation" if "1" in somatic_value.split(",") else "other")] += 1
                for field in ["t_ref_count", "t_alt_count", "t_depth", "n_ref_count", "n_alt_count", "n_depth"] + timing_fields:
                    if str(row.get(field, "")).upper() not in MISSING:
                        field_counts[field] += 1
                ref, alt = integer(row.get("t_ref_count")), integer(row.get("t_alt_count"))
                depth = integer(row.get("t_depth"))
                valid_counts = ref is not None and alt is not None and ref + alt > 0
                if valid_counts:
                    counts["valid_tumor_readcount_rows"] += 1
                    record["valid_tumor_readcount_rows"] += 1
                    counts["positive_tumor_alt_rows"] += alt > 0
                    counts["reported_depth_matches_ref_plus_alt"] += depth == ref + alt
                    counts["depth_at_least_20_rows"] += ref + alt >= 20
                    counts["depth_at_least_50_rows"] += ref + alt >= 50
                    counts["alt_at_least_3_rows"] += alt >= 3
                    if record["purity_valid"]:
                        counts["valid_readcounts_and_purity_rows"] += 1
                else:
                    counts["invalid_or_missing_tumor_readcount_rows"] += 1
                start, end = integer(row.get("Start_Position")), integer(row.get("End_Position"))
                valid_variant = start is not None and end is not None and start > 0 and end >= start and row["Reference_Allele"].upper() not in MISSING and row["Tumor_Seq_Allele2"].upper() not in MISSING
                counts["valid_coordinate_and_allele_rows"] += valid_variant
                key = tuple(row.get(x, "") for x in ["NCBI_Build", "Chromosome", "Start_Position", "End_Position", "Reference_Allele", "Tumor_Seq_Allele2"])
                counts["duplicate_exact_variant_rows_within_sample"] += key in per_sample_keys[sid]
                per_sample_keys[sid].add(key)
                writer.writerow(dict(zip(VARIANT_COLUMNS, [cohort, sid, record["patient_id"], record["role"], row["Hugo_Symbol"], row.get("Entrez_Gene_Id", ""), row.get("NCBI_Build", ""), row["Chromosome"], row["Start_Position"], row["End_Position"], row["Reference_Allele"], row["Tumor_Seq_Allele2"], row["Variant_Type"], row["Variant_Classification"], row.get("FILTER", ""), row.get("Annotation_Status", ""), row.get("t_ref_count", ""), row.get("t_alt_count", ""), row.get("t_depth", ""), row.get("n_ref_count", ""), row.get("n_alt_count", ""), row.get("n_depth", ""), row.get("HGVSp_Short", ""), row.get("Hotspot", ""), valid_counts, valid_variant, row_num, row.get("Mutation_Status", ""), row.get("SOMATIC", "")])))
        partial_variant_output.replace(variant_output)
        records = [mapping[x] for x in expected_ids]
        report["cohorts"][cohort] = {"core_samples": len(samples), "independent_patients": len(samples), "frozen_split": dict(Counter(x["role"] for x in samples)), "samples_with_maf_rows": len(seen_samples), "profiled_samples_without_maf_rows": len(expected_ids - seen_samples), "counts": dict(counts), "maf_header_count": len(maf_headers), "maf_headers": maf_headers, "candidate_timing_fields": timing_fields, "nonmissing_field_rows": dict(field_counts), "tumor_barcode_length_rows": dict(barcode_lengths), "variant_classifications": dict(classifications), "variant_types": dict(types), "filters": dict(filters), "reference_builds": dict(builds), "samples_with_valid_purity": sum(x["purity_valid"] for x in records), "samples_with_valid_purity_and_ploidy": sum(x["purity_valid"] and x["ploidy_valid"] for x in records), "samples_with_full_absolute_dna_aliquot": sum(len(x["absolute_dna_aliquot"]) == 28 for x in records), "maf_full_aliquot_linked_samples": 0, "author_provided_ccf_rows": 0, "raw_variant_export": variant_output.name, "raw_variant_export_sha256": sha256(variant_output)}
        report["cohorts"][cohort]["source_mutation_status_rows"] = dict(mutation_statuses)
        report["cohorts"][cohort]["absolute_call_status_samples"] = dict(Counter(x["absolute_call_status"] for x in records))
        report["cohorts"][cohort]["source_somatic_annotation_rows"] = dict(somatic_annotations)
        report["cohorts"][cohort]["source_somatic_annotation_semantics"] = "VEP annotation of existing variant somatic status; not evidence of this specimen's somatic call origin and not a row-inclusion predicate"

    audit_public_timing_inputs(output, mapping, report)
    cohort_output = output / "cohort_mapping.tsv"
    with cohort_output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(next(iter(mapping.values()))), delimiter="\t")
        writer.writeheader()
        writer.writerows(mapping[sid] for sid in sorted(mapping))
    report["frozen_cohort_mapping_sha256"] = sha256(cohort_output)
    report["readiness"] = {
        "fixed_cohort_and_split": {"passed": True, "basis": "Exact original prepared sample/patient IDs and training/evaluation roles, unchanged 507 LUAD + 481 LUSC"},
        "mutation_presence_matrix": {"passed": True, "basis": "Mutation-assay eligibility and original variant rows are available; event definition and missingness handling must be frozen before fitting"},
        "direct_ccf_input": {"passed": False, "basis": "No CCF, multiplicity, absolute locus copy number, or full mutation aliquot identifier in current 114-column cBioPortal MAF"},
        "vaf_to_ccf_conversion": {"passed": False, "basis": "No conversion performed; purity, locus/allele-specific CN, mutant multiplicity, exact linkage and an uncertainty model are separate requirements"},
        "cross_sectional_progression_pilot": {"passed": True, "basis": "Technically supports a separate explicitly assumption-based binary-event progression model, not directly observed chronology or lineage between patients"},
        "ascetic_single_biopsy_timing": {"passed": False, "basis": "CCF/event-order input not established; mutation counts, clinical stage, RNA scores and GISTIC are not substitutes"},
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--prepared-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=HERE / "source/raw")
    parser.add_argument("--report", type=Path, default=HERE / "source/input_readiness_audit.json")
    parser.add_argument("--download-public", action="store_true", help="Download pinned open ABSOLUTE segments, sample-quality metadata and tiny access manifests; never the controlled mutation MAF")
    args = parser.parse_args()
    if args.download_public:
        download_public_inputs(args.output)
    result = audit(args.data_root, args.prepared_root, args.output, args.report)
    print(json.dumps({code: {k: v for k, v in data.items() if k not in ["maf_headers", "variant_classifications"]} for code, data in result["cohorts"].items()}, indent=2))


if __name__ == "__main__":
    main()
