"""Apply the prespecified pathology-flag sensitivity without reselecting events."""
from __future__ import annotations

import argparse
from collections import Counter
import copy
import csv
import json
from pathlib import Path

from prepare_inputs import HERE, ROOT, quantile, sha256


def quality_summary(rows: list[dict]) -> dict:
    flagged = [row for row in rows if row["source_awg_pathology_exclusion"] == "True"]
    unknown = [row for row in rows if row["source_quality_metadata_exact_aliquot_match"] != "True"]
    notification_fields = ["source_patient_annotation_raw", "source_sample_annotation_raw", "source_aliquot_annotation_raw", "source_aliquot_annotation_updated_raw"]
    neoadjuvant = [row for row in rows if any("neoadjuvant" in row.get(field, "").lower() for field in notification_fields)]
    return {"known_historical_AWG_pathology_flags": len(flagged),
            "known_flags_by_role": dict(Counter(row["role"] for row in flagged)),
            "source_pathology_flag_reasons": dict(Counter(row["source_awg_pathology_reason"] for row in flagged)),
            "unknown_quality_linkage": len(unknown), "unknown_quality_by_role": dict(Counter(row["role"] for row in unknown)),
            "source_neoadjuvant_notifications": len(neoadjuvant),
            "source_neoadjuvant_notifications_by_role": dict(Counter(row["role"] for row in neoadjuvant)),
            "interpretation": "Historical source flags/notifications with limited metadata linkage; absence of a flag is not new histologic adjudication or confirmed untreated status"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-config", type=Path, default=ROOT / "configs/population_routes_v0_1_1.json")
    parser.add_argument("--sensitivity-config", type=Path, default=ROOT / "configs/population_routes_pathology_sensitivity_v0_1.json")
    parser.add_argument("--baseline", type=Path, default=HERE / "output")
    parser.add_argument("--mapping", type=Path, default=HERE.parent / "source/raw/cohort_mapping.tsv")
    parser.add_argument("--output", type=Path, default=HERE / "output/pathology_sensitivity")
    args = parser.parse_args()
    config = json.loads(args.baseline_config.read_text(encoding="utf-8"))
    specification = json.loads(args.sensitivity_config.read_text(encoding="utf-8"))
    preparation = json.loads((args.baseline / "event_preparation.json").read_text(encoding="utf-8"))
    if sha256(args.baseline_config) != specification["baseline_config_sha256"] or preparation["configuration_sha256"] != specification["baseline_config_sha256"]:
        raise ValueError("Frozen sensitivity does not match the baseline configuration")
    if sha256(args.mapping) != preparation["cohort_mapping_sha256"] or sha256(args.baseline / "event_matrix.tsv") != preparation["matrix_sha256"]:
        raise ValueError("Baseline source mapping/matrix changed")
    with args.mapping.open(newline="", encoding="utf-8") as handle:
        mapping = [row for row in csv.DictReader(handle, delimiter="\t") if row["cohort"] == "LUAD"]
    with (args.baseline / "event_matrix.tsv").open(newline="", encoding="utf-8") as handle:
        matrix = list(csv.DictReader(handle, delimiter="\t"))
    flagged = {row["sample_id"] for row in mapping if row["source_awg_pathology_exclusion"] == "True"}
    if len(flagged) != specification["known_flagged_participants"]:
        raise ValueError("Historical source-flag count differs from the prefit sensitivity specification")
    retained = [row for row in matrix if row["sample_id"] not in flagged]
    retained_mapping = [row for row in mapping if row["sample_id"] not in flagged]
    roles = Counter(row["role"] for row in retained)
    if dict(roles) != {"training": 316, "evaluation": 139}:
        raise ValueError("Prespecified sensitivity role counts changed")
    cuts = [quantile([int(row["protein_altering_burden"]) for row in retained if row["role"] == "training"], fraction) for fraction in (.25,.5,.75)]
    for row in retained:
        row["burden_quartile"] = 1 + sum(int(row["protein_altering_burden"]) > cutoff for cutoff in cuts)
    genes = preparation["selected_events"]
    candidate_audit = []
    for candidate in preparation["candidate_events"]:
        gene = candidate["id"]
        if gene in genes:
            train_present = sum(int(row[gene]) for row in retained if row["role"] == "training")
            evaluation_present = sum(int(row[gene]) for row in retained if row["role"] == "evaluation")
            candidate_audit.append({"id": gene, "selected": True, "training_present": train_present, "training_n": roles["training"],
                                    "evaluation_present": evaluation_present, "evaluation_n": roles["evaluation"],
                                    "reason": "Baseline training-eligible event retained without reselection",
                                    "below_original_training_frequency_gate": train_present < config["events"]["minimum_training_carriers"] or roles["training"] - train_present < config["events"]["minimum_training_noncarriers"]})
        else:
            candidate_audit.append({"id": gene, "selected": False, "reason": "Excluded by baseline training gate; not reconsidered in sensitivity"})
    resolved = copy.deepcopy(config)
    resolved["version"] = config["version"] + "+pathology-sensitivity-" + specification["version"]
    resolved["sample_universe"] = "Known historical AWG pathology flags excluded; unknown quality retained"
    resolved["split"]["training_participants"] = roles["training"]
    resolved["split"]["evaluation_participants"] = roles["evaluation"]
    resolved["events"]["selection_scope"] = "Fixed baseline training-eligible event universe; no reselection"
    resolved["sensitivity_specification"] = specification
    resolved["sensitivity_specification_sha256"] = sha256(args.sensitivity_config)
    resolved["baseline_configuration_sha256"] = sha256(args.baseline_config)
    args.output.mkdir(parents=True, exist_ok=True)
    resolved_path = args.output / "configuration_resolved.json"
    resolved_path.write_text(json.dumps(resolved, indent=2) + "\n", encoding="utf-8")
    matrix_path = args.output / "event_matrix.tsv"
    with matrix_path.open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=list(matrix[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(retained)
    summary = copy.deepcopy(preparation)
    summary.update({"training_n": roles["training"], "evaluation_n": roles["evaluation"], "candidate_events": candidate_audit,
                    "configuration_sha256": sha256(resolved_path), "configuration_version": resolved["version"],
                    "baseline_configuration_sha256": sha256(args.baseline_config), "sensitivity_specification_sha256": sha256(args.sensitivity_config),
                    "baseline_event_matrix_sha256": preparation["matrix_sha256"], "matrix_sha256": sha256(matrix_path),
                    "selected_events": genes, "event_selection_uses_evaluation": False, "event_universe_reselected": False,
                    "training_burden_quartile_cutoffs": cuts, "quality_summary": quality_summary(retained_mapping),
                    "baseline_quality_summary": quality_summary(mapping),
                    "excluded_by_pathology_flag": len(flagged),
                    "profiled_samples_without_MAF_rows": sum(int(row["variant_rows"]) == 0 for row in retained_mapping),
                    "training_burden_stratum_n": dict(Counter(row["burden_quartile"] for row in retained if row["role"] == "training"))})
    (args.output / "event_preparation.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key:summary[key] for key in ("training_n", "evaluation_n", "selected_events", "excluded_by_pathology_flag", "quality_summary", "configuration_sha256")}, indent=2))


if __name__ == "__main__":
    main()
