"""Run hash-bound published CAPRI inference and frozen held-out diagnostics.

The published R engine selects the DAG. Python performs input checks, applies
no edge selection of its own, and evaluates frozen conditional probabilities.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess
import sys

from install_runtime import rscript_path
from prepare_inputs import ROOT, HERE, sha256


def verify_bindings(config_path: Path, preparation: dict, matrix_path: Path) -> None:
    if preparation["configuration_sha256"] != sha256(config_path) or preparation["matrix_sha256"] != sha256(matrix_path):
        raise ValueError("Configuration or event matrix changed after preparation")


def bh_adjust(values: list[float]) -> list[float]:
    """Benjamini-Hochberg adjustment over the complete declared pair family."""
    if any(not math.isfinite(value) or not 0 <= value <= 1 for value in values):
        raise ValueError("Invalid p-value")
    order = sorted(range(len(values)), key=lambda index: values[index])
    result = [1.0] * len(values)
    running = 1.0
    for position in range(len(order) - 1, -1, -1):
        index = order[position]
        running = min(running, values[index] * len(values) / (position + 1))
        result[index] = min(1.0, running)
    return result


def binary_table(rows: list[dict], source: str, target: str) -> dict:
    cells = {"00": 0, "01": 0, "10": 0, "11": 0}
    for row in rows:
        cells[f"{int(row[source])}{int(row[target])}"] += 1
    source_n = cells["10"] + cells["11"]
    target_n = cells["01"] + cells["11"]
    no_source_n = cells["00"] + cells["01"]
    delta = cells["11"] / source_n - cells["01"] / no_source_n if source_n and no_source_n else None
    return {"n": len(rows), "source_present": source_n, "target_present": target_n, "cooccurring": cells["11"],
            "table": cells, "probability_raising_delta": delta,
            "source_more_prevalent": source_n > target_n}


def predictive_check(training: list[dict], evaluation: list[dict], genes: list[str], edges: list[tuple[str, str]]) -> dict:
    """Estimate every graph CPT on training; score evaluation without refitting.

    All incoming parent states are jointly conditioned, not converted into an
    AND gate. Unseen training parent states use the declared Beta(1,1) prior.
    """
    parents = {gene: sorted(source for source, target in edges if target == gene) for gene in genes}
    cpts = {}
    marginal = {}
    parameter_records = []
    for gene in genes:
        marginal[gene] = (1 + sum(int(row[gene]) for row in training)) / (2 + len(training))
        table = {}
        for row in training:
            state = tuple(int(row[parent]) for parent in parents[gene])
            counts = table.setdefault(state, [0, 0])
            counts[0] += int(row[gene])
            counts[1] += 1
        cpts[gene] = {state: (1 + present) / (2 + count) for state, (present, count) in table.items()}
        parameter_records.append({"event": gene, "parents": parents[gene], "independence_probability": marginal[gene],
                                  "unseen_parent_configuration_probability": .5,
                                  "configurations": [{"parent_states": list(state), "training_present": counts[0], "training_n": counts[1],
                                                       "event_probability": cpts[gene][state]} for state, counts in sorted(table.items())]})
    differences, graph_logs, baseline_logs = [], [], []
    for row in evaluation:
        graph_log = baseline_log = 0.0
        for gene in genes:
            state = tuple(int(row[parent]) for parent in parents[gene])
            graph_probability = cpts[gene].get(state, .5)
            baseline_probability = marginal[gene]
            observed = int(row[gene])
            graph_log += math.log(graph_probability if observed else 1 - graph_probability)
            baseline_log += math.log(baseline_probability if observed else 1 - baseline_probability)
        graph_logs.append(graph_log)
        baseline_logs.append(baseline_log)
        differences.append(graph_log - baseline_log)
    mean = statistics.mean(differences)
    standard_error = statistics.stdev(differences) / math.sqrt(len(differences)) if len(differences) > 1 else None
    return {"evaluation_n": len(evaluation), "training_n": len(training), "smoothing": "Beta(1,1), training only",
            "metric": "Held-out joint log probability, natural-log nats per participant; higher is better",
            "graph_mean_log_probability": statistics.mean(graph_logs), "independence_mean_log_probability": statistics.mean(baseline_logs),
            "graph_minus_independence_mean_nats": mean, "paired_difference_standard_error": standard_error,
            "conditional_descriptive_95_percent_interval": [mean - 1.96 * standard_error, mean + 1.96 * standard_error] if standard_error is not None else None,
            "interval_limitation": "Normal approximation across fixed evaluation participants, conditional on the frozen training graph and fitted probabilities; does not include model-selection uncertainty",
            "no_evaluation_refit": True, "no_evaluation_edge_selection": True, "training_fitted_conditional_probabilities": parameter_records}


def assemble(config: dict, preparation: dict, raw: dict, matrix: list[dict]) -> dict:
    genes = raw["genes"]
    if genes != preparation["selected_events"]:
        raise ValueError("Published engine event universe changed")
    training = [row for row in matrix if row["role"] == "training"]
    evaluation = [row for row in matrix if row["role"] == "evaluation"]
    if len(training) != preparation["training_n"] or len(evaluation) != preparation["evaluation_n"]:
        raise ValueError("Engine input split changed")
    pairs = raw["pairs"]
    if len(pairs) != len(genes) * (len(genes) - 1):
        raise ValueError("Incomplete ordered-pair diagnostics")
    permutation_p = [(1 + row["permutation_delta_exceedances"]) / (1 + row["permutation_attempts"]) for row in pairs]
    permutation_q = bh_adjust(permutation_p)
    internal_tp_q = bh_adjust([row["capri_internal_temporal_priority_p"] for row in pairs])
    internal_pr_q = bh_adjust([row["capri_internal_probability_raising_p"] for row in pairs])
    edges = []
    pair_diagnostics = []
    for index, pair in enumerate(pairs):
        diagnostic = dict(pair)
        diagnostic.update({"permutation_probability_raising_p": permutation_p[index], "permutation_probability_raising_BH_q": permutation_q[index],
                           "capri_internal_temporal_priority_BH_q": internal_tp_q[index], "capri_internal_probability_raising_BH_q": internal_pr_q[index]})
        pair_diagnostics.append(diagnostic)
        if not pair["selected"]:
            continue
        training_table = binary_table(training, pair["source"], pair["target"])
        evaluation_table = binary_table(evaluation, pair["source"], pair["target"])
        stability = pair["bootstrap_selected"] / pair["bootstrap_successful"] if pair["bootstrap_successful"] else None
        null_frequency = pair["null_selected"] / pair["null_successful"] if pair["null_successful"] else None
        edges.append({"source": pair["source"], "target": pair["target"], "relation": "selectivity_relation",
                      "direction_basis": "CAPRI cross-sectional prevalence-based priority, probability raising and BIC conditional-dependence selection; no measured chronology",
                      "bootstrap_support": stability, "bootstrap_successful": pair["bootstrap_successful"], "bootstrap_selected": pair["bootstrap_selected"],
                      "bootstrap_monte_carlo_standard_error": math.sqrt(stability * (1 - stability) / pair["bootstrap_successful"]) if stability is not None else None,
                      "meets_display_stability_threshold": stability is not None and stability >= config["evaluation"]["stability_display_threshold"],
                      "permutation_support": None, "heldout_direction_support": None,
                      "burden_null_selection_frequency": null_frequency, "null_selected": pair["null_selected"], "null_successful": pair["null_successful"],
                      "permutation_probability_raising_p": permutation_p[index], "permutation_probability_raising_BH_q": permutation_q[index],
                      "capri_internal_temporal_priority_p": pair["capri_internal_temporal_priority_p"],
                      "capri_internal_probability_raising_p": pair["capri_internal_probability_raising_p"],
                      "training_observations": training_table, "evaluation_observations": evaluation_table,
                      "heldout_descriptive_direction_compatible": evaluation_table["source_more_prevalent"] and evaluation_table["probability_raising_delta"] is not None and evaluation_table["probability_raising_delta"] > 0,
                      "status": "Exploratory published-engine selection; retained regardless of resampling or holdout result"})
    if len(edges) != raw["selected_edge_count"]:
        raise ValueError("Published engine edges were dropped or invented")
    nodes = [{"id": gene, "label": f"{gene}: reported protein-altering event", "discovery_present": sum(int(row[gene]) for row in training),
              "discovery_n": len(training), "evaluation_present": sum(int(row[gene]) for row in evaluation), "evaluation_n": len(evaluation),
              "event_definition": config["events"]["definition"],
              "incoming_parents": sorted(edge["source"] for edge in edges if edge["target"] == gene)} for gene in genes]
    prediction = predictive_check(training, evaluation, genes, [(edge["source"], edge["target"]) for edge in edges])
    null_edge_counts = raw["burden_stratified_null"]["selected_edge_counts"]
    graph_null_p = (1 + sum(count >= len(edges) for count in null_edge_counts)) / (1 + len(null_edge_counts)) if null_edge_counts else None
    return {"schema_version": "1.0", "title": "LUAD reported-event selectivity: frozen cross-sectional CAPRI pilot",
            "model_status": "exploratory_model" if edges else "no_selected_edges", "created": config["date"],
            "method": {"name": "TRONCO CAPRI", "version": raw["engine_version"],
                       "source": "https://bioconductor.org/packages/3.21/bioc/html/TRONCO.html",
                       "publication": "https://doi.org/10.1093/bioinformatics/btv296", "parameters": raw["parameters"],
                       "semantics": config["engine"]["semantics"],
                       "parent_semantics": "All incoming parents jointly condition a Bayesian DAG event probability. They do not establish a deterministic AND requirement, physical cell ancestry or a measured temporal sequence.",
                       "edge_selection": "Exactly the genuine unmodified TRONCO::tronco.capri BIC graph; no post hoc edge pruning or additions"},
            "cohort": {"histology": "LUAD", "discovery_n": len(training), "evaluation_n": len(evaluation), "total_n": len(matrix),
                       "independent_participants": True, "split": "Existing frozen explorer roles, unchanged", "pooled_histologies": False,
                       "profiled_samples_without_MAF_rows_retained": preparation["profiled_samples_without_MAF_rows"],
                       "source_label": "TCGA/cBioPortal source-labeled LUAD; not a new pathology-adjudicated cohort",
                       "quality_summary": preparation.get("quality_summary", {})},
            "nodes": nodes, "edges": edges, "candidate_events": preparation["candidate_events"],
            "validation": {"patient_bootstrap": raw["patient_bootstrap"], "burden_stratified_null": raw["burden_stratified_null"],
                           "stability_display_threshold": config["evaluation"]["stability_display_threshold"],
                           "selected_edges_meeting_stability_count": sum(edge["meets_display_stability_threshold"] for edge in edges),
                           "burden_stratified_null_edge_count_comparison_p": graph_null_p,
                           "null_edge_count_interpretation": "Exploratory comparison of complete graph edge count against burden-stratified permuted-event fits; not a chronology test",
                           "ordered_pair_tests": len(pairs), "multiple_testing": "BH across all retained ordered event pairs, including pairs not selected by CAPRI",
                           "pvalue_limitation": "CAPRI internal bootstrap Wilcoxon p-values depend on its resampling distribution; permutation delta tests describe positive association after the specified burden stratification. Neither tests biological chronology.",
                           "holdout": prediction, "pair_diagnostics": pair_diagnostics},
            "provenance": {"configuration_version": config["version"], "configuration_sha256": preparation["configuration_sha256"],
                           "event_matrix_sha256": preparation["matrix_sha256"], "source_variants_sha256": preparation["source_variants_sha256"],
                           "cohort_mapping_sha256": preparation["cohort_mapping_sha256"], "input_readiness_audit_sha256": preparation["input_readiness_audit_sha256"],
                           "current_input_audit_metadata_sha256": preparation.get("current_input_audit_metadata_sha256", preparation["input_readiness_audit_sha256"]),
                           "audit_metadata_refresh_note": preparation.get("audit_metadata_refresh_note"),
                           "somatic_callset_basis": config["events"]["somatic_callset_basis"]},
            "limitations": [config["events"]["absence_semantics"],
                            "One source gene event aggregates protein-altering calls; it does not establish every variant as a functional driver or distinguish gain/loss of function.",
                            "Prevalence is not directly observed time; persistence, selection and detection assumptions may be violated.",
                            "CAPRI's closed-world assumption is not established: this limited gene-event panel omits other mutations, fusions, copy-number, epigenetic and functional events, so omitted variables can create or change apparent relations.",
                            "Published-engine false-positive/false-negative error parameters remain at their zero defaults; this is not evidence that assay calls are error-free.",
                            "No mutation CCF or aliquot-level timing input is established; ASCETIC was not run and VAF was not substituted for CCF.",
                            "Burden stratification does not control all smoking, histology, specimen, ascertainment or technical confounding.",
                            "Bootstrap stability, predictive association and permutation results do not establish causality, clinical actionability, or ancestry between patients.",
                            "Every selected edge remains visible regardless of uncertainty; no biological tiers, survival tests or RNA-program discovery are performed."]}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=ROOT / "configs/population_routes_v0_1_1.json")
    parser.add_argument("--output", type=Path, default=HERE / "output")
    parser.add_argument("--rscript")
    parser.add_argument("--summarize-only", action="store_true", help="Use an existing engine output without another inference")
    args = parser.parse_args()
    preparation_path = args.output / "event_preparation.json"
    matrix_path = args.output / "event_matrix.tsv"
    config = json.loads(args.config.read_text(encoding="utf-8"))
    preparation = json.loads(preparation_path.read_text(encoding="utf-8"))
    verify_bindings(args.config, preparation, matrix_path)
    if not args.summarize_only:
        subprocess.run([rscript_path(args.rscript), "--vanilla", str(HERE / "run_capri.R"), str(args.config.resolve()),
                        str(matrix_path.resolve()), str(args.output.resolve()), str(HERE / "runtime_lock.json")], check=True)
    raw = json.loads((args.output / "engine_output.json").read_text(encoding="utf-8"))
    with matrix_path.open(newline="", encoding="utf-8") as handle:
        matrix = list(csv.DictReader(handle, delimiter="\t"))
    model = assemble(config, preparation, raw, matrix)
    quality = preparation.get("quality_summary", {})
    if quality:
        model["limitations"].append(
            f"This run retains {quality['known_historical_AWG_pathology_flags']} known historical AWG pathology flags and "
            f"{quality['unknown_quality_linkage']} participants with unknown source-quality linkage; unflagged does not establish confirmed LUAD histology."
        )
        model["limitations"].append(
            f"Historical source metadata retain {quality['source_neoadjuvant_notifications']} neoadjuvant treatment notifications; this is not established untreated natural history."
        )
    if "sensitivity_specification" in config:
        model["title"] = "LUAD source-quality sensitivity: known pathology flags excluded"
        model["cohort"]["split"] = "Original training/evaluation roles retained after prespecified source-flag exclusions"
        model["provenance"]["baseline_configuration_sha256"] = config["baseline_configuration_sha256"]
        model["provenance"]["sensitivity_specification_sha256"] = config["sensitivity_specification_sha256"]
        model["limitations"].append("Known historical pathology flags are excluded in this sensitivity; unknown linkage is retained. The same baseline event universe is used without reselection.")
    model["provenance"]["runtime_lock_sha256"] = sha256(HERE / "runtime_lock.json")
    model["provenance"]["published_engine_output_sha256"] = sha256(args.output / "engine_output.json")
    model_path = args.output / "model.json"
    model_path.write_text(json.dumps(model, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"model": str(model_path), "nodes": len(model["nodes"]), "edges": len(model["edges"]),
                      "bootstrap": raw["patient_bootstrap"], "null": {key: value for key, value in raw["burden_stratified_null"].items() if key != "selected_edge_counts"},
                      "heldout_graph_minus_independence_nats": model["validation"]["holdout"]["graph_minus_independence_mean_nats"]}, indent=2))


if __name__ == "__main__":
    main()
