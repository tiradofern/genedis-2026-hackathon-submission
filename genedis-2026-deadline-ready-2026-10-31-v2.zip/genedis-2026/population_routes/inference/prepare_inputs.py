"""Build outcome-blind reported-event inputs on the existing frozen LUAD split."""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def quantile(values: list[int], fraction: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * fraction
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


def build(config: dict, samples: list[dict], variants, audit: dict) -> tuple[list[dict], dict]:
    cohort = config["primary_cohort"]
    if cohort != "LUAD":
        raise ValueError("This frozen pilot supports LUAD only; LUSC is not pooled")
    for gate in ("fixed_cohort_and_split", "mutation_presence_matrix", "cross_sectional_progression_pilot"):
        if not audit["readiness"][gate]["passed"]:
            raise ValueError(f"Source audit did not pass {gate}")
    settings = config["events"]
    provenance = settings.get("somatic_callset_basis", {})
    if settings.get("source_mutation_status") is not None:
        raise ValueError("Current audited source has no row-level Mutation_Status; do not improvise a replacement")
    if provenance.get("mode") != "verified_somatic_callset" or not provenance.get("provenance_url"):
        raise ValueError("Explicit verified somatic-callset provenance is required")
    core = [row for row in samples if row["cohort"] == cohort]
    ids = [row["sample_id"] for row in core]
    patients = [row["patient_id"] for row in core]
    if len(set(ids)) != len(ids) or len(set(patients)) != len(patients):
        raise ValueError("Repeated sample/participant in the frozen split")
    roles = Counter(row["role"] for row in core)
    expected_roles = {"training": config["split"]["training_participants"], "evaluation": config["split"]["evaluation_participants"]}
    if dict(roles) != expected_roles or len(core) != audit["cohorts"][cohort]["core_samples"]:
        raise ValueError("Frozen participant split/cohort changed")
    by_id = {row["sample_id"]: row for row in core}
    genes = settings["candidate_genes"]
    if len(set(genes)) != len(genes):
        raise ValueError("Duplicate candidate event")
    allowed_classes = set(settings["variant_classifications"])
    events = {key: set() for key in ids}
    burden = Counter({key: 0 for key in ids})
    source_rows = Counter({key: 0 for key in ids})
    exclusions = Counter()
    qualifying_rows = 0
    for row in variants:
        sample_id = row["sample_id"]
        if sample_id not in by_id:
            raise ValueError("Variant export contains a sample outside the frozen LUAD universe")
        sample = by_id[sample_id]
        if row["cohort"] != cohort or row["patient_id"] != sample["patient_id"] or row["role"] != sample["role"]:
            raise ValueError("Variant export sample/patient/split mapping changed")
        source_rows[sample_id] += 1
        if row["filter"] != settings["source_filter"]:
            exclusions["non_PASS_rows"] += 1
            continue
        if row["variant_classification"] not in allowed_classes:
            exclusions["outside_protein_altering_classes"] += 1
            continue
        # Row Mutation_Status is missing and SOMATIC is a VEP database annotation.
        # Neither is used as a substitute somatic-call inclusion filter.
        burden[sample_id] += 1
        qualifying_rows += 1
        if row["gene"] in genes:
            events[sample_id].add(row["gene"])
    if sum(source_rows.values()) != audit["cohorts"][cohort]["counts"]["core_maf_rows"]:
        raise ValueError("Variant row count differs from the input audit")
    for sample_id, sample in by_id.items():
        if source_rows[sample_id] != int(sample["variant_rows"]):
            raise ValueError("Sample variant counts changed relative to the fixed cohort map")
    training_ids = [row["sample_id"] for row in core if row["role"] == "training"]
    evaluation_ids = [row["sample_id"] for row in core if row["role"] == "evaluation"]
    retained, event_audit = [], []
    for gene in genes:
        carriers = sum(gene in events[key] for key in training_ids)
        noncarriers = len(training_ids) - carriers
        selected = carriers >= settings["minimum_training_carriers"] and noncarriers >= settings["minimum_training_noncarriers"]
        if selected:
            retained.append(gene)
        event_audit.append({"id": gene, "selected": selected, "training_present": carriers, "training_n": len(training_ids),
                            "evaluation_present": sum(gene in events[key] for key in evaluation_ids), "evaluation_n": len(evaluation_ids),
                            "reason": "Passed frozen training-only gates" if selected else "Below frozen training carrier/noncarrier gate"})
    if len(retained) < 2:
        raise ValueError("Fewer than two events pass the frozen gates; no population DAG can be fitted")
    # Distinct events with identical training patterns are unidentifiable. Fail
    # explicitly rather than merging event meanings or silently dropping a gene.
    signatures = [tuple(gene in events[key] for key in training_ids) for gene in retained]
    if len(set(signatures)) != len(signatures):
        raise ValueError("Identical retained training event columns require scientific review; no automatic merge")
    cuts = [quantile([burden[key] for key in training_ids], fraction) for fraction in (.25, .5, .75)]
    matrix = []
    for sample in core:
        key = sample["sample_id"]
        row = {"sample_id": key, "patient_id": sample["patient_id"], "role": sample["role"],
               "protein_altering_burden": burden[key], "burden_quartile": 1 + sum(burden[key] > cutoff for cutoff in cuts)}
        row.update({gene: int(gene in events[key]) for gene in retained})
        matrix.append(row)
    summary = {"schema_version": "1.0", "cohort": cohort, "training_n": len(training_ids), "evaluation_n": len(evaluation_ids),
               "selected_events": retained, "candidate_events": event_audit, "qualifying_protein_altering_rows": qualifying_rows,
               "row_exclusions": dict(exclusions), "profiled_samples_without_MAF_rows": sum(value == 0 for value in source_rows.values()),
               "absence_semantics": settings["absence_semantics"], "burden_definition": "Count of PASS protein-altering reported variants across all genes in the fixed nine classes; no VEP SOMATIC filter",
               "training_burden_quartile_cutoffs": cuts,
               "training_burden_stratum_n": dict(Counter(row["burden_quartile"] for row in matrix if row["role"] == "training")),
               "somatic_callset_basis": provenance, "inference_performed": False, "event_selection_uses_evaluation": False}
    return matrix, summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=ROOT / "configs/population_routes_v0_1_1.json")
    parser.add_argument("--source-dir", type=Path, default=HERE.parent / "source")
    parser.add_argument("--output", type=Path, default=HERE / "output")
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding="utf-8"))
    audit_path = args.source_dir / "input_readiness_audit.json"
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    mapping_path = args.source_dir / "raw/cohort_mapping.tsv"
    variants_path = args.source_dir / f"raw/{config['primary_cohort']}_raw_variants.tsv"
    if sha256(mapping_path) != audit["frozen_cohort_mapping_sha256"]:
        raise ValueError("Cohort mapping SHA256 mismatch")
    if sha256(variants_path) != audit["cohorts"][config["primary_cohort"]]["raw_variant_export_sha256"]:
        raise ValueError("Raw variant export SHA256 mismatch")
    with mapping_path.open(newline="", encoding="utf-8") as mapping, variants_path.open(newline="", encoding="utf-8") as variants:
        matrix, summary = build(config, list(csv.DictReader(mapping, delimiter="\t")), csv.DictReader(variants, delimiter="\t"), audit)
    args.output.mkdir(parents=True, exist_ok=True)
    matrix_path = args.output / "event_matrix.tsv"
    with matrix_path.open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=list(matrix[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(matrix)
    summary.update({"configuration_sha256": sha256(args.config), "configuration_version": config["version"],
                    "cohort_mapping_sha256": sha256(mapping_path), "source_variants_sha256": sha256(variants_path),
                    "input_readiness_audit_sha256": sha256(audit_path), "matrix_sha256": sha256(matrix_path)})
    (args.output / "event_preparation.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
