"""Focused scientific safeguards; fictional fixtures are never research inputs."""
from __future__ import annotations

from collections import Counter
import copy
import csv
import json
from pathlib import Path
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from prepare_inputs import build, sha256
from run import bh_adjust, predictive_check, verify_bindings


def fixture():
    config = {"primary_cohort": "LUAD", "split": {"training_participants": 3, "evaluation_participants": 2},
              "events": {"candidate_genes": ["FICTIONAL_A", "FICTIONAL_B", "FICTIONAL_C"], "variant_classifications": ["Missense_Mutation"],
                         "source_filter": "PASS", "source_mutation_status": None,
                         "somatic_callset_basis": {"mode": "verified_somatic_callset", "provenance_url": "https://example.org/fictional-fixture"},
                         "minimum_training_carriers": 2, "minimum_training_noncarriers": 1,
                         "absence_semantics": "Fictional reported-call absence, not verified wild type"}}
    patterns = [(1,1,1),(1,0,0),(0,0,1),(0,1,0),(0,1,0)]
    samples, variants = [], []
    for index, pattern in enumerate(patterns):
        sample_id, role = f"FICTIONAL_{index}", "training" if index < 3 else "evaluation"
        for gene, value in zip(config["events"]["candidate_genes"], pattern):
            if value:
                variants.append({"sample_id":sample_id, "patient_id":sample_id, "role":role, "cohort":"LUAD", "gene":gene,
                                 "filter":"PASS", "variant_classification":"Missense_Mutation", "mutation_status":".",
                                 "source_somatic_annotation":"0"})
        samples.append({"sample_id":sample_id,"patient_id":sample_id,"role":role,"cohort":"LUAD","variant_rows":str(sum(pattern))})
    audit = {"readiness": {key:{"passed":True} for key in ("fixed_cohort_and_split","mutation_presence_matrix","cross_sectional_progression_pilot")},
             "cohorts":{"LUAD":{"core_samples":5,"counts":{"core_maf_rows":len(variants)}}}}
    return config, samples, variants, audit


class InferenceSafeguards(unittest.TestCase):
    def test_event_eligibility_uses_training_only_not_evaluation_prevalence(self):
        config, samples, variants, audit = fixture()
        _, summary = build(config, samples, variants, audit)
        self.assertEqual(summary["selected_events"], ["FICTIONAL_A","FICTIONAL_C"])
        b = next(row for row in summary["candidate_events"] if row["id"] == "FICTIONAL_B")
        self.assertEqual((b["training_present"], b["evaluation_present"], b["selected"]), (1,2,False))

    def test_vep_somatic_database_annotation_is_not_a_specimen_call_filter(self):
        config, samples, variants, audit = fixture()
        # Every row has missing Mutation_Status and VEP SOMATIC=0. The explicit
        # fictional somatic-callset provenance governs inclusion, as in the real schema.
        matrix, summary = build(config, samples, variants, audit)
        self.assertEqual(summary["qualifying_protein_altering_rows"], len(variants))
        self.assertEqual(matrix[0]["FICTIONAL_A"], 1)
        config["events"].pop("somatic_callset_basis")
        with self.assertRaises(ValueError): build(config, samples, variants, audit)

    def test_missing_assay_readiness_and_duplicate_patients_fail(self):
        config, samples, variants, audit = fixture()
        audit["readiness"]["mutation_presence_matrix"]["passed"] = False
        with self.assertRaises(ValueError): build(config, samples, variants, audit)
        audit["readiness"]["mutation_presence_matrix"]["passed"] = True
        samples[1]["patient_id"] = samples[0]["patient_id"]
        with self.assertRaises(ValueError): build(config, samples, variants, audit)

    def test_mutation_export_role_changes_and_missing_rows_fail(self):
        config, samples, variants, audit = fixture()
        changed = copy.deepcopy(variants)
        changed[0]["role"] = "evaluation"
        with self.assertRaises(ValueError): build(config, samples, changed, audit)
        with self.assertRaises(ValueError): build(config, samples, variants[:-1], audit)

    def test_heldout_labels_never_refit_training_CPTs(self):
        train = [{"A":1},{"A":1},{"A":1},{"A":0}]
        first = predictive_check(train,[{"A":1},{"A":1}],["A"],[])
        changed = predictive_check(train,[{"A":0},{"A":0}],["A"],[])
        self.assertEqual(first["training_fitted_conditional_probabilities"], changed["training_fitted_conditional_probabilities"])
        self.assertAlmostEqual(first["training_fitted_conditional_probabilities"][0]["independence_probability"], 4/6)
        self.assertNotEqual(first["graph_mean_log_probability"], changed["graph_mean_log_probability"])
        self.assertTrue(first["no_evaluation_refit"])

    def test_multiple_parents_jointly_condition_CPT_without_AND_requirement(self):
        # Fictional XOR pattern: target can be present with either parent alone.
        train = [{"A":0,"B":0,"C":0},{"A":1,"B":0,"C":1},{"A":0,"B":1,"C":1},{"A":1,"B":1,"C":0}]
        result = predictive_check(train,train,["A","B","C"],[("A","C"),("B","C")])
        target = next(row for row in result["training_fitted_conditional_probabilities"] if row["event"] == "C")
        self.assertEqual(target["parents"], ["A","B"])
        probabilities = {tuple(row["parent_states"]):row["event_probability"] for row in target["configurations"]}
        self.assertAlmostEqual(probabilities[(1,0)], 2/3)
        self.assertAlmostEqual(probabilities[(1,1)], 1/3)

    def test_BH_corrects_the_complete_pair_family(self):
        values = [.01,.04,.03,.002]
        for got, expected in zip(bh_adjust(values), [.02,.04,.04,.008]): self.assertAlmostEqual(got,expected)
        # Including unselected tests changes q: adjustment is not selection-only.
        self.assertGreater(bh_adjust([.01]+[1]*109)[0], bh_adjust([.01])[0])
        with self.assertRaises(ValueError): bh_adjust([float("nan")])

    def test_hash_binding_detects_changed_matrix_or_configuration(self):
        (HERE/"output").mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=HERE/"output", prefix="safeguard-fixture-") as folder:
            root = Path(folder)
            config, matrix = root/"config.json", root/"matrix.tsv"
            config.write_text('{"fictional":true}')
            matrix.write_text('A\n1\n')
            bound = {"configuration_sha256":sha256(config),"matrix_sha256":sha256(matrix)}
            verify_bindings(config,bound,matrix)
            matrix.write_text('A\n0\n')
            with self.assertRaises(ValueError): verify_bindings(config,bound,matrix)
            bound["matrix_sha256"] = sha256(matrix)
            config.write_text('{"fictional":false}')
            with self.assertRaises(ValueError): verify_bindings(config,bound,matrix)


class ActualPublishedEngineOutputs(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not (HERE/"output/model.json").exists() or not (HERE/"output/sensitivity_model.json").exists():
            raise unittest.SkipTest("Actual fixed-cohort engine outputs require source preparation and the real published engine")
        cls.models = [json.loads((HERE/path).read_text()) for path in ("output/model.json","output/sensitivity_model.json")]

    def test_actual_graphs_preserve_every_genuine_engine_edge_and_sampling_denominator(self):
        for model, folder in zip(self.models,(HERE/"output",HERE/"output/pathology_sensitivity")):
            engine = json.loads((folder/"engine_output.json").read_text())
            expected = {(pair["source"],pair["target"]) for pair in engine["pairs"] if pair["selected"]}
            actual = {(edge["source"],edge["target"]) for edge in model["edges"]}
            self.assertEqual(expected,actual)
            self.assertEqual(len(model["validation"]["pair_diagnostics"]),110)
            self.assertEqual(model["validation"]["patient_bootstrap"]["successful"],100)
            self.assertEqual(model["validation"]["burden_stratified_null"]["successful"],100)
            for pair in model["validation"]["pair_diagnostics"]:
                self.assertAlmostEqual(pair["permutation_probability_raising_p"],(1+pair["permutation_delta_exceedances"])/101)
            # Every arrow respects the engine's source-frequency priority; a
            # strict decreasing prevalence also rules out a directed cycle.
            counts = {node["id"]:node["discovery_present"] for node in model["nodes"]}
            for edge in model["edges"]: self.assertGreater(counts[edge["source"]],counts[edge["target"]])

    def test_sensitivity_is_exact_baseline_minus_known_flags_with_roles_and_events_fixed(self):
        with (HERE/"output/event_matrix.tsv").open() as handle: baseline = list(csv.DictReader(handle,delimiter="\t"))
        with (HERE/"output/pathology_sensitivity/event_matrix.tsv").open() as handle: sensitivity = list(csv.DictReader(handle,delimiter="\t"))
        with (HERE.parent/"source/raw/cohort_mapping.tsv").open() as handle: mapping = list(csv.DictReader(handle,delimiter="\t"))
        flagged = {row["sample_id"] for row in mapping if row["cohort"]=="LUAD" and row["source_awg_pathology_exclusion"]=="True"}
        source = {row["sample_id"]:row for row in baseline}
        self.assertEqual(set(source)-flagged,{row["sample_id"] for row in sensitivity})
        self.assertEqual(dict(Counter(row["role"] for row in sensitivity)),{"training":316,"evaluation":139})
        genes = [node["id"] for node in self.models[0]["nodes"]]
        self.assertEqual(genes,[node["id"] for node in self.models[1]["nodes"]])
        for row in sensitivity:
            for key in ["patient_id","role","protein_altering_burden"]+genes: self.assertEqual(row[key],source[row["sample_id"]][key])
        self.assertEqual(self.models[1]["cohort"]["quality_summary"]["unknown_quality_linkage"],16)

    def test_frozen_holdout_scores_recompute_from_training_only(self):
        for model, folder in zip(self.models,(HERE/"output",HERE/"output/pathology_sensitivity")):
            with (folder/"event_matrix.tsv").open() as handle: rows = list(csv.DictReader(handle,delimiter="\t"))
            recomputed = predictive_check([row for row in rows if row["role"]=="training"],[row for row in rows if row["role"]=="evaluation"],
                                         [node["id"] for node in model["nodes"]],[(edge["source"],edge["target"]) for edge in model["edges"]])
            self.assertEqual(recomputed,model["validation"]["holdout"])


if __name__ == "__main__": unittest.main()
