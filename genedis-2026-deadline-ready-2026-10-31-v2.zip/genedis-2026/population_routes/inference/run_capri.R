# Invoke the genuine, unmodified published TRONCO CAPRI engine. This wrapper
# controls sampling and records outputs; it does not implement a substitute DAG.
args <- commandArgs(trailingOnly=TRUE)
if (length(args) != 4) stop("Usage: run_capri.R CONFIG MATRIX OUTPUT_DIRECTORY RUNTIME_LOCK")
if (!startsWith(as.character(getRversion()), "4.5.")) stop("The locked official Windows binaries require R4.5.x")
script_arg <- grep("^--file=", commandArgs(), value=TRUE)[1]
here <- dirname(normalizePath(sub("^--file=", "", script_arg), winslash="/"))
if (!dir.exists(file.path(here, ".rlibrary"))) stop(paste("Local runtime library not found under", here))
.libPaths(c(file.path(here, ".rlibrary"), .Library))
cat("Runtime library:", file.path(here, ".rlibrary"), "\n")
suppressPackageStartupMessages(library(jsonlite))
suppressPackageStartupMessages(library(TRONCO))
config <- fromJSON(args[1], simplifyVector=FALSE)
lock <- fromJSON(args[4], simplifyVector=FALSE)
for (item in lock$packages) {
  description_file <- file.path(here, ".rlibrary", item$name, "DESCRIPTION")
  installed <- read.dcf(description_file, fields="Version")[1,1]
  if (installed != item$version) stop(paste("Locked runtime version mismatch", item$name, installed))
}
if (as.character(packageVersion("TRONCO")) != config$engine$version) stop("Wrong published engine version")
output <- args[3]
dir.create(output, recursive=TRUE, showWarnings=FALSE)
tab <- read.delim(args[2], check.names=FALSE, stringsAsFactors=FALSE)
metadata_names <- c("sample_id", "patient_id", "role", "protein_altering_burden", "burden_quartile")
genes <- setdiff(colnames(tab), metadata_names)
train <- as.matrix(tab[tab$role == "training", genes, drop=FALSE])
evaluation <- as.matrix(tab[tab$role == "evaluation", genes, drop=FALSE])
storage.mode(train) <- "numeric"
storage.mode(evaluation) <- "numeric"
if (ncol(train) < 2 || any(!train %in% c(0,1)) || any(!evaluation %in% c(0,1))) stop("Invalid binary event matrix")
if (any(colSums(train) == 0) || any(colSums(train) == nrow(train))) stop("Nonvarying event after cohort restriction; no silent removal")
strata <- tab$burden_quartile[tab$role == "training"]
seed <- config$engine$seed

fit_one <- function(matrix, fit_seed) {
  set.seed(fit_seed)
  imported <- TRONCO::import.genotypes(matrix, event.type="reported_candidate_gene_event")
  TRONCO::tronco.capri(imported,
    command=config$engine$search, regularization=config$engine$regularization,
    do.boot=TRUE, nboot=config$engine$internal_bootstrap_runs,
    pvalue=config$engine$internal_pvalue, min.boot=3, min.stat=TRUE,
    boot.seed=fit_seed, silent=TRUE, epos=0, eneg=0, restart=100)
}
adjacency <- function(fit) TRONCO::as.adj.matrix(fit, models="capri_bic")[[1]]
delta_matrix <- function(matrix) {
  result <- matrix(0, ncol(matrix), ncol(matrix))
  for (i in seq_len(ncol(matrix))) for (j in seq_len(ncol(matrix))) {
    if (i == j) next
    exposed <- matrix[,i] == 1
    if (all(exposed) || !any(exposed)) { result[i,j] <- NA_real_; next }
    result[i,j] <- mean(matrix[exposed,j]) - mean(matrix[!exposed,j])
  }
  result
}

cat("Starting official TRONCO CAPRI on", nrow(train), "training participants,", ncol(train), "fixed events\n")
started <- proc.time()
fit <- fit_one(train, seed)
adj <- adjacency(fit)
confidence <- TRONCO::as.confidence(fit, conf=c("tp", "pr", "hg"))
saveRDS(fit, file.path(output, "published_capri_fit.rds"))
writeLines(capture.output(sessionInfo()), file.path(output, "R_session_info.txt"))
cat("Base published-engine fit selected", sum(adj), "edges\n")

boot_counts <- adj * 0
boot_success <- 0L
boot_failures <- list()
for (b in seq_len(config$evaluation$patient_bootstrap_runs)) {
  set.seed(seed + 1000L + b)
  sampled <- train[sample.int(nrow(train), nrow(train), replace=TRUE),,drop=FALSE]
  # Row identifiers in this in-memory bootstrap identify draws, not new patients.
  rownames(sampled) <- paste0("BOOT_DRAW_", seq_len(nrow(sampled)))
  result <- tryCatch(adjacency(fit_one(sampled, seed + 2000L + b)), error=function(error) error)
  if (inherits(result, "error")) boot_failures[[length(boot_failures)+1L]] <- list(iteration=b, error=conditionMessage(result))
  else { boot_counts <- boot_counts + result; boot_success <- boot_success + 1L }
  if (b %% 10 == 0) cat("Patient bootstrap", b, "of", config$evaluation$patient_bootstrap_runs, "; successful", boot_success, "\n")
}

null_counts <- adj * 0
null_exceedance <- adj * 0
null_success <- 0L
null_failures <- list()
null_edge_counts <- c()
observed_delta <- delta_matrix(train)
for (b in seq_len(config$evaluation$null_permutations)) {
  set.seed(seed + 3000L + b)
  permuted <- train
  for (stratum in sort(unique(strata))) {
    indices <- which(strata == stratum)
    for (j in seq_len(ncol(train))) permuted[indices,j] <- sample(train[indices,j], length(indices), replace=FALSE)
  }
  # Every event's stratum prevalence is retained exactly by construction.
  null_exceedance <- null_exceedance + (delta_matrix(permuted) >= observed_delta - 1e-12)
  result <- tryCatch(adjacency(fit_one(permuted, seed + 4000L + b)), error=function(error) error)
  if (inherits(result, "error")) null_failures[[length(null_failures)+1L]] <- list(iteration=b, error=conditionMessage(result))
  else {
    null_counts <- null_counts + result
    null_success <- null_success + 1L
    null_edge_counts <- c(null_edge_counts, sum(result))
  }
  if (b %% 10 == 0) cat("Burden-stratified null", b, "of", config$evaluation$null_permutations, "; successful", null_success, "\n")
}

pairs <- list()
for (i in seq_along(genes)) for (j in seq_along(genes)) {
  if (i == j) next
  pairs[[length(pairs)+1L]] <- list(source=genes[i], target=genes[j], selected=as.logical(adj[i,j]),
    capri_internal_temporal_priority_p=unname(confidence$tp[i,j]),
    capri_internal_probability_raising_p=unname(confidence$pr[i,j]),
    capri_internal_hypergeometric_p=unname(confidence$hg[i,j]),
    training_probability_raising_delta=unname(observed_delta[i,j]),
    bootstrap_selected=unname(boot_counts[i,j]), bootstrap_successful=boot_success,
    null_selected=unname(null_counts[i,j]), null_successful=null_success,
    permutation_delta_exceedances=unname(null_exceedance[i,j]), permutation_attempts=config$evaluation$null_permutations)
}
raw <- list(schema_version="1.0", published_engine="TRONCO::tronco.capri",
  engine_version=as.character(packageVersion("TRONCO")), R_version=R.version.string,
  parameters=list(command=config$engine$search, regularization=config$engine$regularization,
    do_boot=TRUE, internal_nboot=config$engine$internal_bootstrap_runs, internal_pvalue=config$engine$internal_pvalue,
    restart=100, min_boot=3, min_stat=TRUE, false_positive_error=0, false_negative_error=0, seed=seed),
  genes=as.list(genes), pairs=pairs,
  selected_edge_count=sum(adj), published_engine_BIC_score=unname(fit$model$capri_bic$score),
  published_engine_log_likelihood=unname(fit$model$capri_bic$logLik),
  patient_bootstrap=list(attempted=config$evaluation$patient_bootstrap_runs, successful=boot_success, failures=boot_failures),
  burden_stratified_null=list(attempted=config$evaluation$null_permutations, successful=null_success, failures=null_failures,
    selected_edge_counts=as.list(null_edge_counts)),
  elapsed_seconds=unname((proc.time()-started)[3]), no_evaluation_refit=TRUE)
write_json(raw, file.path(output, "engine_output.json"), pretty=TRUE, auto_unbox=TRUE, digits=NA, na="null")
cat("Completed genuine CAPRI inference/resampling in", raw$elapsed_seconds, "seconds\n")
