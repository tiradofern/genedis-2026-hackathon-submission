"""Install hash-locked official TRONCO binaries in this workspace only (Windows/R4.5)."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import urllib.request

HERE = Path(__file__).resolve().parent


def rscript_path(explicit: str | None = None) -> str:
    if explicit:
        path = Path(explicit)
        if not path.is_file():
            raise FileNotFoundError(path)
        return str(path)
    found = shutil.which("Rscript")
    if found:
        return found
    candidates = sorted(Path("C:/Program Files/R").glob("R-4.5.*/bin/Rscript.exe"))
    if candidates:
        return str(candidates[-1])
    raise FileNotFoundError("Rscript for existing R4.5 is required; pass --rscript PATH")


def checked(path: Path, item: dict) -> None:
    data = path.read_bytes()
    if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
        raise ValueError(f"Locked package archive mismatch: {path.name}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rscript")
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()
    binary = rscript_path(args.rscript)
    version = subprocess.check_output([binary, "--version"], text=True, stderr=subprocess.STDOUT)
    if "4.5." not in version:
        raise RuntimeError("The locked Windows package binaries require R4.5.x")
    manifest = json.loads((HERE / "runtime_lock.json").read_text(encoding="utf-8"))
    cache = HERE / ".downloads"
    cache.mkdir(exist_ok=True)
    library = HERE / ".rlibrary"
    library.mkdir(exist_ok=True)
    paths = []
    for item in manifest["packages"]:
        path = cache / item["filename"]
        if not path.exists():
            if args.offline:
                raise FileNotFoundError(path)
            partial = path.with_suffix(path.suffix + ".partial")
            with urllib.request.urlopen(item["url"], timeout=120) as source, partial.open("wb") as output:
                shutil.copyfileobj(source, output)
            checked(partial, item)
            partial.replace(path)
        checked(path, item)
        paths.append(str(path).replace("\\", "/"))
    # Passing argv directly avoids any shell interpretation. The JSON-quoted
    # controlled Windows paths are also valid R character literals.
    vector = "c(" + ",".join(json.dumps(path) for path in paths) + ")"
    lib_literal = json.dumps(str(library).replace("\\", "/"))
    expression = f'install.packages({vector},repos=NULL,type="win.binary",lib={lib_literal})'
    subprocess.run([binary, "--vanilla", "-e", expression], check=True)
    print(f"Installed {len(paths)} locked official package archives in {library}")


if __name__ == "__main__":
    main()
