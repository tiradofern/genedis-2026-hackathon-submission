"""Refresh source-quality labels and write aggregate evidence without refitting."""
from __future__ import annotations

import csv
import json
from pathlib import Path
import shutil
import subprocess
import sys

from prepare_inputs import HERE, ROOT, sha256
from prepare_sensitivity import quality_summary


def compact(model: dict) -> dict:
    selected_fields = ("source", "target", "bootstrap_support", "bootstrap_successful", "bootstrap_selected", "burden_null_selection_frequency",
                       "permutation_probability_raising_p", "permutation_probability_raising_BH_q", "heldout_descriptive_direction_compatible")
    holdout = model["validation"]["holdout"]
    return {"model_sha256": sha256(HERE / "output" / ("sensitivity_model.json" if "sensitivity_specification_sha256" in model["provenance"] else "model.json")),
            "cohort": model["cohort"], "event_count": len(model["nodes"]), "selected_edge_count": len(model["edges"]),
            "selected_edges": [{key:edge[key] for key in selected_fields} for edge in model["edges"]],
            "selected_edges_meeting_0_8_stability": model["validation"]["selected_edges_meeting_stability_count"],
            "selected_edges_with_burden_permutation_BH_q_below_0_05": sum(edge["permutation_probability_raising_BH_q"] < .05 for edge in model["edges"]),
            "patient_bootstrap": model["validation"]["patient_bootstrap"],
            "burden_null": {key:value for key,value in model["validation"]["burden_stratified_null"].items() if key != "selected_edge_counts"},
            "graph_edge_count_null_comparison_p": model["validation"]["burden_stratified_null_edge_count_comparison_p"],
            "holdout": {key:value for key,value in holdout.items() if key != "training_fitted_conditional_probabilities"},
            "provenance": model["provenance"]}


def main() -> None:
    output = HERE / "output"
    mapping_path = HERE.parent / "source/raw/cohort_mapping.tsv"
    audit_path = HERE.parent / "source/input_readiness_audit.json"
    with mapping_path.open(newline="", encoding="utf-8") as handle:
        mapping = [row for row in csv.DictReader(handle, delimiter="\t") if row["cohort"] == "LUAD"]
    for folder, rows in ((output, mapping), (output / "pathology_sensitivity", [row for row in mapping if row["source_awg_pathology_exclusion"] != "True"])):
        prep_path = folder / "event_preparation.json"
        prep = json.loads(prep_path.read_text(encoding="utf-8"))
        if sha256(mapping_path) != prep["cohort_mapping_sha256"] or sha256(folder / "event_matrix.tsv") != prep["matrix_sha256"]:
            raise ValueError("Source mapping or fitted matrix changed; metadata-only finalization is not allowed")
        original = folder / "event_preparation_at_first_fit.json"
        if not original.exists():
            shutil.copyfile(prep_path, original)
        prep["quality_summary"] = quality_summary(rows)
        prep["current_input_audit_metadata_sha256"] = sha256(audit_path)
        if prep["current_input_audit_metadata_sha256"] != prep["input_readiness_audit_sha256"]:
            prep["audit_metadata_refresh_note"] = "Source audit metadata were supplemented after event preparation (aggregate ABSOLUTE call statuses and generalized notification categories). Original audit SHA256 remains recorded; matrix, raw variant and cohort-mapping bytes were unchanged. Previous full audit bytes were not retained. No configuration or fit changed."
        prep_path.write_text(json.dumps(prep, indent=2) + "\n", encoding="utf-8")
    snapshot = output / "reproducibility_snapshot"
    snapshot.mkdir(exist_ok=True)
    for source in (mapping_path, audit_path, ROOT / "configs/population_routes_v0_1_1.json", ROOT / "configs/population_routes_pathology_sensitivity_v0_1.json", HERE / "runtime_lock.json"):
        shutil.copyfile(source, snapshot / source.name)
    subprocess.run([sys.executable, str(HERE / "run.py"), "--summarize-only"], check=True)
    sensitivity = output / "pathology_sensitivity"
    subprocess.run([sys.executable, str(HERE / "run.py"), "--summarize-only", "--config", str(sensitivity / "configuration_resolved.json"), "--output", str(sensitivity)], check=True)
    shutil.copyfile(sensitivity / "model.json", output / "sensitivity_model.json")
    baseline_model = json.loads((output / "model.json").read_text(encoding="utf-8"))
    sensitivity_model = json.loads((output / "sensitivity_model.json").read_text(encoding="utf-8"))
    baseline_edges = {(edge["source"], edge["target"]) for edge in baseline_model["edges"]}
    sensitivity_edges = {(edge["source"], edge["target"]) for edge in sensitivity_model["edges"]}
    common, union = baseline_edges & sensitivity_edges, baseline_edges | sensitivity_edges
    report = {"schema_version": "1.0", "date": "2026-10-18", "purpose": "Aggregate reproducible result; no patient-level matrices or identifiers included",
              "method": baseline_model["method"], "baseline": compact(baseline_model), "pathology_sensitivity": compact(sensitivity_model),
              "candidate_events": baseline_model["candidate_events"],
              "comparison": {"same_fixed_events": [node["id"] for node in baseline_model["nodes"]] == [node["id"] for node in sensitivity_model["nodes"]],
                             "common_selected_edges": [list(edge) for edge in sorted(common)], "selected_edge_jaccard": len(common)/len(union) if union else None,
                             "baseline_only_edges": [list(edge) for edge in sorted(baseline_edges-sensitivity_edges)],
                             "sensitivity_only_edges": [list(edge) for edge in sorted(sensitivity_edges-baseline_edges)],
                             "interpretation": "The sensitivity shares participants and the frozen baseline event universe; it is not independent validation or a holdout-based model choice"},
              "scientific_conclusion": "An operational published CAPRI exploratory model was fitted. Neither run has an edge meeting 0.8 bootstrap stability or burden-permutation BH q below 0.05; these data/results do not establish a robust shared evolutionary route or mutation chronology.",
              "limitations": baseline_model["limitations"]}
    destination = HERE / "results_summary.json"
    destination.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(f"Wrote aggregate evidence {destination}")


if __name__ == "__main__":
    main()
