"""Replay the bounded core from an extracted, verified archive and cached inputs.

This tests archive transport and reconstruction. It is not a second complete
network acquisition, fresh environment install, or independent biological study.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import zipfile

from verify_archive import verify


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--workdir", type=Path, required=True)
    parser.add_argument("--cached-sources", type=Path, required=True)
    parser.add_argument("--python", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--logs", type=Path, required=True)
    args = parser.parse_args()
    if args.workdir.exists() or args.report.exists() or args.logs.exists():
        parser.error("Preserve previous replay artifacts; choose fresh workdir/report/logs")
    checked = verify(args.archive)
    args.workdir.mkdir(parents=True)
    args.logs.mkdir(parents=True)
    with zipfile.ZipFile(args.archive) as archive:
        archive.extractall(args.workdir)
    checkout = args.workdir / "genedis-2026"
    destination = checkout / "data/external/public_tcga_2026-10-17"
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(args.cached_sources, destination)
    # Preserve a venv's invocation path: resolving its executable symlink would
    # select the base interpreter and silently bypass the pinned environment.
    python = str(args.python.absolute())
    records = []
    environment = dict(os.environ, OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")

    def run(name, command):
        started = time.monotonic()
        result = subprocess.run(command, cwd=checkout, env=environment, capture_output=True, text=True)
        log = args.logs / f"{name}.log"
        log.write_text(result.stdout + result.stderr)
        records.append({"check": name, "command": command, "returncode": result.returncode,
                        "seconds": round(time.monotonic()-started, 3), "log": str(log)})
        if result.returncode:
            raise RuntimeError(f"Replay failed: {name}; see {log}")

    run("pinned_environment", [python, "-c", "import sys,numpy,scipy,json; print(json.dumps(dict(executable=sys.executable,numpy=numpy.__version__,scipy=scipy.__version__))); assert numpy.__version__=='2.3.3' and scipy.__version__=='1.16.2', 'Use requirements-app.txt pinned environment'"])
    run("cached_source_hashes", [python, "release_recovery/retrieve_core_sources.py", "--report", "work/source_verification.json"])
    run("core_python", [python, "-m", "unittest", "discover", "-s", "tests", "-v"])
    run("frontend", ["node", "--test", "tests/frontend.test.mjs"])
    run("program_definition_hashes", [python, "pilot/programs/freeze_panel.py", "--verify-only"])
    run("fresh_core_preparation", [python, "scripts/prepare_explorer.py", "--destination", "data/processed/package_replay"])
    prepared = checkout / "data/processed/package_replay"
    reference = json.loads((checkout / "release_recovery/core_recovery_2026-10-31.json").read_text())
    bootstrap = json.loads((prepared / "bootstrap.json").read_text())
    bootstrap.pop("created_utc", None)
    semantic = hashlib.sha256(json.dumps(bootstrap, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    file_checks = {}
    for name, record in reference["file_comparisons"].items():
        if name == "bootstrap.json":
            continue
        digest = hashlib.sha256((prepared / name).read_bytes()).hexdigest()
        file_checks[name] = {"sha256": digest, "matches_first_recovery_bytes": digest == record["first_sha256"]}
    scientific_equal = semantic == reference["first_semantic_bootstrap_sha256"]
    passed = scientific_equal and all(r["matches_first_recovery_bytes"] for r in file_checks.values())
    report = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "status": "passed" if passed else "review_required", "archive_integrity": checked,
        "checks": records, "scientific_bootstrap_equal_excluding_created_utc": scientific_equal,
        "prepared_artifact_checks": file_checks,
        "comparison_reference": "release_recovery/core_recovery_2026-10-31.json",
        "inputs": "Copied previously recovered public inputs; all47SHA256s reverified in isolated extracted directory",
        "environment": "Existing pinned core Python environment reused; no fresh dependency installation",
        "limits": ["No second complete network acquisition", "No independent cohort/biological validation", "Heavy historical R/phylogeny/normal-reference pipelines not replayed", "Final archive may add review records/docs; core reconstruction code and source manifests must remain unchanged"]}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "report": str(args.report), "checks": len(records)}, indent=2))
    raise SystemExit(not passed)


if __name__ == "__main__":
    main()
