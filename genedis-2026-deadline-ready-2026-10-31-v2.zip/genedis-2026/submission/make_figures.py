"""Render aggregate evidence figures; never read patient expression or scores."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import platform
import tempfile

os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "genedis-mpl"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "submission/figures")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Preserve existing figures; choose a new --output directory")
    args.output.mkdir(parents=True)
    recovery_path = ROOT / "release_recovery/core_recovery_2026-10-31.json"
    old_path = ROOT / "results/reports/explorer_preparation_2026-10-17.json"
    overlap_path = ROOT / "pilot/programs/program_overlap.tsv"
    recovery = json.loads(recovery_path.read_text())
    old = json.loads(old_path.read_text())
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                         "svg.fonttype": "none", "axes.spines.top": False,
                         "axes.spines.right": False})
    colors = {"LUAD": "#197278", "LUSC": "#9A581F"}
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 5), gridspec_kw={"width_ratios": [1, 1.8]})
    names = list(recovery["cohorts"])
    train = [recovery["cohorts"][c]["roles"]["training"] for c in names]
    evaluation = [recovery["cohorts"][c]["roles"]["evaluation"] for c in names]
    axes[0].bar(names, train, label="Training", color="#28566B")
    axes[0].bar(names, evaluation, bottom=train, label="Evaluation", color="#C2D6DE")
    for i, (a, b) in enumerate(zip(train, evaluation)):
        axes[0].text(i, a / 2, str(a), ha="center", va="center", color="white")
        axes[0].text(i, a + b / 2, str(b), ha="center", va="center")
        axes[0].text(i, a + b + 12, str(a + b), ha="center")
    axes[0].set_ylim(0, 590)
    axes[0].set_ylabel("Independent primary-tumor participants")
    axes[0].set_title("Frozen patient split")
    axes[0].legend(frameon=False, loc="upper center")
    position = 0
    ticks, labels, feature_rows = [], [], []
    for cohort in names:
        programs = old["cohorts"][cohort]["programs"]
        for p in programs:
            axes[1].bar(position, p["gene_count"], color=colors[cohort], width=.8)
            ticks.append(position)
            labels.append(p["id"].split("-")[1])
            feature_rows.append({"cohort": cohort, "program": p["id"], "genes": p["gene_count"],
                                 "training_pc1_variance": p["pc1_variance"],
                                 "training_coordination_fraction": p["coordinated_fraction"],
                                 "status": "provisional; validation not run"})
            position += 1
        center = position - len(programs) / 2 - .5
        axes[1].text(center, 251, f"{cohort}: {len(programs)} programs", ha="center", color=colors[cohort])
        position += 1
    axes[1].set_xticks(ticks, labels, rotation=90, fontsize=8)
    axes[1].set_ylabel("Genes per provisional program")
    axes[1].set_ylim(0, 280)
    axes[1].set_title("Recovered program sizes")
    fig.suptitle("NSCLC explorer: computational recovery, not biological validation", y=1.02, fontsize=14)
    fig.text(.5, -.01, "25 provisional RNA programs. Resampling, holdout preservation and resistance validation remain unperformed.", ha="center", fontsize=9)
    fig.tight_layout()
    for extension in ("svg", "png"):
        fig.savefig(args.output / f"01_nsclc_recovery.{extension}", dpi=180, bbox_inches="tight")
    plt.close(fig)
    with (args.output / "program_feature_summary.tsv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(feature_rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(feature_rows)

    with overlap_path.open() as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    programs = list(dict.fromkeys(r["program_a"] for r in rows))
    lookup = {(r["program_a"], r["program_b"]): float(r["jaccard"]) for r in rows}
    values = np.array([[lookup[a, b] for b in programs] for a in programs])
    labels = ["IFN alpha", "IFN gamma", "EMT", "Hypoxia", "OXPHOS", "G2M"]
    fig, ax = plt.subplots(figsize=(7.5, 6))
    plot = ax.imshow(values, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(6), labels, rotation=35, ha="right")
    ax.set_yticks(range(6), labels)
    for i in range(6):
        for j in range(6):
            ax.text(j, i, f"{values[i,j]:.2f}", ha="center", va="center",
                    color="white" if values[i,j] > .5 else "#182B37")
    fig.colorbar(plot, ax=ax, label="Gene-membership Jaccard overlap")
    ax.set_title("Frozen published programs share genes\nThis is gene-set overlap; no tumor effects were tested", pad=14)
    fig.text(.5, -.01, "MSigDB 2024.1.Hs; six intact Hallmarks. IFN alpha/gamma share 73 genes (75.3% of IFN alpha).", ha="center", fontsize=9)
    fig.tight_layout()
    for extension in ("svg", "png"):
        fig.savefig(args.output / f"02_published_program_overlap.{extension}", dpi=180, bbox_inches="tight")
    plt.close(fig)
    hashes = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in (recovery_path, old_path, overlap_path)}
    (args.output / "figure_provenance.json").write_text(json.dumps({
        "producer": "submission/make_figures.py", "python": platform.python_version(),
        "numpy": np.__version__, "matplotlib": matplotlib.__version__, "inputs_sha256": hashes,
        "patient_expression_read": False, "paired_effects_computed": False,
        "interpretation": "Aggregate inventory and fixed gene-set overlap only"}, indent=2) + "\n")


if __name__ == "__main__":
    main()
