"""Build a deterministic review archive from a bounded, audited allowlist."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import fnmatch
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PREFIX = "genedis-2026"
VERSION = "2026-10-31-v2"
CELLULAR = "pilot/cellular_2026-10-31/"
LEGACY_REQUIRED = {
    "submission/REVIEWER_README.md", "submission/SCIENTIFIC_SUMMARY.md",
    "release_recovery/program_definitions_2026-10-31.tsv",
    "pilot/cohorts/FEASIBILITY_REPORT_2026-10-31.md",
}
V2_REQUIRED = LEGACY_REQUIRED | {
    "README.md", "package.json", "pyproject.toml", "requirements-app.txt",
    "release_recovery/README.md", "scripts/prepare_explorer.py", "scripts/run_explorer.py",
    "pilot/programs/sources/h.all.v2024.1.Hs.symbols.gmt",
    "pilot/programs/sources/h.all.v2024.1.Hs.json",
    "pilot/programs/sources/msigdb_license_terms_2026-10-31.html",
    "pilot/programs/sources/license_terms_list_2026-10-31.html",
    "pilot/programs/TERMS_AND_CITATION.md",
} | {CELLULAR + p for p in (
    "README.md", "MEASUREMENT_PROTOCOL.md", "RNA_MEASUREMENT_PROTOCOL.json",
    "RNA_EXECUTION_GATE.json", "RNA_EXECUTION_QC.json", "FROZEN_PRIMARY_RNA_INPUT_MANIFEST.json",
    "PRIMARY_RNA_INPUT_QC.json", "FRESH_RECONSTRUCTION_QC.json", "readiness.json",
    "EXECUTION_REPRODUCIBILITY.md", "EXECUTION_SOURCE_MANIFEST.json", "retrieve_execution_sources.py",
    "prepare_primary_rna.py", "run_primary_rna.py", "rna_coordination.py", "program_scores.py",
    "regenerate_quek_pre_anchor.py", "audit_quek_count_identity.py", "identify_quek_cells.py",
    "QUEK_CELL_ID_PROTOCOL.json", "QUEK_CELL_ID_QC.json", "QUEK_COUNT_STRUCTURE_QC.json",
    "CLINICAL_ELIGIBILITY.md", "RESULTS_2026-10-31.md", "RESULTS_ADVERSARIAL_REVIEW.md",
    "NSCLC_COMPONENT_EXECUTION_GATE.json", "NSCLC_COMPONENT_PROTOCOL_PROPOSED.json",
    "NSCLC_ID_CROSSWALK_QC.json", "NSCLC_NUMERIC_QC.json", "NSCLC_READINESS_EXECUTION.md",
    "results/primary_full_result.json", "results/primary_all_programs_by_patient.csv",
    "results/primary_conditional_by_family.csv", "results/quek_three_gene_full_result.json",
    "results/quek_three_gene_all_programs_by_patient.csv", "results/quek_three_gene_conditional_by_family.csv",
    "figures/README.md", "figures/figure_manifest.json", "plot_program_measurements.py",
    "requirements-figures.txt", "figures/01_rna_program_activity.png", "figures/01_rna_program_activity.svg",
    "figures/02_rna_coordination_T.png", "figures/02_rna_coordination_T.svg",
    "figures/03_rna_coordination_excess.png", "figures/03_rna_coordination_excess.svg",
)}


def eligible(name, rules):
    path = PurePosixPath(name)
    if (not path.parts or path.is_absolute() or ".." in path.parts or "\\" in name
            or any(ord(c) < 32 for c in name) or path.parts[0] == "data"):
        return False
    if any(part.startswith((".venv", ".env")) or part in {".git", ".aws", ".ssh", "credentials", "secrets"}
           for part in path.parts):
        return False
    if any("gmail" in part.lower() for part in path.parts):
        return False
    if any(part in rules["exclude_parts"] or part.startswith(".env") for part in path.parts):
        return False
    if any(fnmatch.fnmatchcase(name, pattern) for pattern in rules["exclude_globs"]):
        return False
    if name in rules["root_files"]:
        return True
    if any(fnmatch.fnmatchcase(name, pattern) for pattern in rules.get("extra_globs", [])):
        return True
    inside = any(name.startswith(prefix + "/") for prefix in rules["roots"])
    return inside and (path.suffix in rules["extensions"] or path.name == ".gitignore")


def required_materials(rules):
    return (V2_REQUIRED | set(rules.get("required_files", []))
            if rules.get("version") == VERSION else LEGACY_REQUIRED)


def validate_v2_evidence(contents):
    """Check frozen bindings and complete public definitions, not biological validity."""
    protocol_path = CELLULAR + "RNA_MEASUREMENT_PROTOCOL.json"
    protocol = json.loads(contents[protocol_path])
    gate = json.loads(contents[CELLULAR + "RNA_EXECUTION_GATE.json"])
    nsclc = json.loads(contents[CELLULAR + "NSCLC_COMPONENT_EXECUTION_GATE.json"])
    if (gate.get("protocol_sha256") != hashlib.sha256(contents[protocol_path]).hexdigest()
            or gate.get("primary_nomination_enabled") is not False
            or gate.get("complete_primary_discovery_validation_claim_gate") != "HOLD_INCONCLUSIVE"
            or nsclc.get("decision") != "HOLD" or nsclc.get("stage") != "NOT_REACHED"):
        raise ValueError("Current conditional/inconclusive scientific scope or frozen gate binding differs")
    source = "pilot/programs/sources/"
    gmt = contents[source + "h.all.v2024.1.Hs.symbols.gmt"]
    definitions = json.loads(contents[source + "h.all.v2024.1.Hs.json"])
    entries = [line.split("\t") for line in gmt.decode().splitlines() if line]
    if (len(entries) != 50 or len({r[0] for r in entries}) != 50 or len(definitions) != 50
            or protocol["programs"].get("family_size") != 50
            or protocol["programs"].get("gmt_sha256") != hashlib.sha256(gmt).hexdigest()):
        raise ValueError("Complete frozen 50-program definitions are required")
    for entry in entries:
        if len(entry) < 3 or len(set(entry[2:])) != len(entry[2:]) or definitions.get(entry[0], {}).get("geneSymbols") != entry[2:]:
            raise ValueError("Full GMT/JSON program membership disagreement")
    binding = protocol["input_manifest"]
    if hashlib.sha256(contents[binding["path"]]).hexdigest() != binding["sha256"]:
        raise ValueError("Frozen input-manifest identity differs")


def committed_snapshot():
    """Require a clean worktree and read only exact recorded commit blobs."""
    if subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=normal"], cwd=ROOT).strip():
        raise ValueError("Build requires a clean committed source tree, including untracked files")
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip()
    branch = subprocess.check_output(["git", "branch", "--show-current"], cwd=ROOT).decode().strip()
    entries = []
    for row in subprocess.check_output(["git", "ls-tree", "-r", "-z", head], cwd=ROOT).split(b"\0"):
        if row:
            metadata, name = row.split(b"\t", 1)
            mode, kind, oid = metadata.decode().split()
            entries.append((name.decode(), mode, kind, oid))
    return head, branch, entries


def build(destination):
    if destination.exists():
        raise ValueError("Preserve existing archives; choose a new --output path")
    head, branch, entries = committed_snapshot()
    rules = json.loads(subprocess.check_output(["git", "show", head + ":submission/package_allowlist.json"], cwd=ROOT))
    if rules.get("version") != VERSION:
        raise ValueError("New builds require the reviewed v2 package policy")
    selected_entries = sorted((row for row in entries if eligible(row[0], rules)), key=lambda row: row[0])
    selected = [row[0] for row in selected_entries]
    if not selected:
        raise ValueError("Empty archive selection")
    contents = {}
    for name, mode, kind, oid in selected_entries:
        if mode not in {"100644", "100755"} or kind != "blob":
            raise ValueError(f"Symlink or escaped source path: {name}")
        data = subprocess.check_output(["git", "cat-file", "blob", oid], cwd=ROOT)
        if len(data) > rules["max_file_bytes"]:
            raise ValueError(f"Unexpectedly large selected file: {name}")
        contents[name] = data
    required = required_materials(rules)
    if not required.issubset(contents):
        raise ValueError(f"Missing required reviewer evidence: {sorted(required-set(contents))}")
    validate_v2_evidence(contents)
    if (subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip() != head
            or subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=normal"], cwd=ROOT).strip()):
        raise ValueError("Source tree changed during packaging")
    dirty = False
    records = [{"path": n, "bytes": len(contents[n]), "sha256": hashlib.sha256(contents[n]).hexdigest()} for n in selected]
    manifest = {
        "package": PREFIX, "package_version": VERSION, "source_commit": head, "source_branch": branch,
        "source_tree_had_uncommitted_changes": dirty,
        "source_date": "2026-10-31", "allowlist": "submission/package_allowlist.json",
        "file_count": len(records), "files": records,
        "entrypoint": "submission/REVIEWER_README.md",
        "scope": "Preserved NSCLC explorer plus fixed-50-program RNA measurements and exploratory conditional technical diagnostics; primary MSI nomination inconclusive; NSCLC protein validation not reached",
        "source_selection": "Tracked blobs from the exact clean recorded commit; no untracked or ignored files",
        "required_artifact_sha256": {n: hashlib.sha256(contents[n]).hexdigest() for n in sorted(required)},
        "submission_status": "Prepared for investigator review; not sent to organizers",
        "checksums_note": "SHA256SUMS.tsv covers payload plus PACKAGE_MANIFEST.json; checksum file cannot hash itself."
    }
    contents["PACKAGE_MANIFEST.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    sums = "path\tsha256\n" + "".join(f"{n}\t{hashlib.sha256(contents[n]).hexdigest()}\n" for n in sorted(contents))
    contents["SHA256SUMS.tsv"] = sums.encode()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(contents):
            item = zipfile.ZipInfo(f"{PREFIX}/{name}", date_time=(2026, 10, 31, 0, 0, 0))
            item.create_system = 3
            item.compress_type = zipfile.ZIP_DEFLATED
            item.external_attr = 0o100644 << 16
            archive.writestr(item, contents[name])
    return {"archive": str(destination), "bytes": destination.stat().st_size,
            "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
            "payload_files": len(records), "source_commit": head, "source_tree_dirty": dirty,
            "created_utc": datetime.now(timezone.utc).isoformat()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    print(json.dumps(build(arguments.output.resolve()), indent=2))
