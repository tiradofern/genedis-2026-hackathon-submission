# Verified project inventory and preservation decisions

Source branch: `analysis/normal-reference-first`, commit `a4edb2ba85daef38f38b4d9a3c4cbaa1516df0b9`. Work is additive on `release/genedis-2026-10-31`; no branches were merged. The older `main` was an audit snapshot and does not represent the cumulative project. Prior planning documents were recovered verbatim from `docs/pan-cancer-msi-plan-2026-10-30` commit `92408ee80ef0c0af2d7b385b3bee5461d27e0a96` without merging its older shared files.

| Component | Verified contents and actual status | Decision |
|---|---|---|
| Early GEO audit | `scripts/audit_metadata.py`, curated manifests and dated October 14 audit. This release preserves that report; it does not rerun its writing producer over the historical state. | Preserve as historical feasibility/source work. |
| NSCLC backbone | Frozen 507 LUAD/481 LUSC sample-key cohort; RNA/CNA/MAF coverage, clinical/purity/slide linkage. All 47 source files recovered and verified. | Primary release backbone; no clinical resistance labels inferred. |
| Program discovery | Unchanged `scripts/prepare_explorer.py`, `src/survival_islands/explorer_model.py`, original configs/splits. Freshly reconstructed 14/11 provisional programs and 1,904 exported gene-loading rows. | Preserve recipe; full stability/preservation and composition validation remain later work. |
| Explorer | `web/`, local read-only server and export workflow. Core tests plus real-data desktop/mobile smoke pass. No supervised clinical predictor or IHC measurements. | Runnable submission demonstration. |
| TCGA population routes | `population_routes/` code, runtime lock and aggregate report. Selected dependencies did not pass required stability/adjusted-null support. | Preserve negative result; heavy engine not freshly rerun. |
| TRACERx mutation routes | `tracerx_routes/`, `tracerx_expanded/`, separate LUAD/LUSC frozen roles and aggregate reports; no reliable common route. Same patients reused across extensions. | Preserve and clearly label historical/exploratory, not resistance or external replication. |
| TRACERx CNA routes | `tracerx_cna_phylo/` code and aggregate review records; no adjusted shared-order signal; inferred histories retain model/ambiguity limits. | Preserve; no new engine installation or refit. |
| Nextstrain prototype | Published within-tumor tree adapter, upstream schema licenses and pinned Auspice instructions. | Preserve as source-topology demonstration, not new population inference; installed vendor app excluded. |
| Normal references | `normal_reference/` aggregate GTEx/HLCA reports and code. HLCA rejection gate failed; unsupported mesothelium falsely accepted; no tumors projected. | Preserve negative gate and comparability limits; no huge downloads or late repair. |
| Prior plans/review | Broad recurrence-first plan, paired pilot proposal and adversarial review under `docs/`/`reviews/`. Their planning-only authorization notices are historical. | Preserve; current authorization/protocol and release entry point govern this execution. |
| Longitudinal pilot | `pilot/cohorts/` verifies candidate public records for GSE65185/GSE248249. Both gates fail; primary molecular effects untested. | Include feasibility report; no scores, P values or convergence claim. |
| Published panel | Six intact human MSigDB Hallmarks, release2024.1.Hs, version/hash/CC-BY attribution; 985 unique genes. | Preserve complete fixed definitions for later gated analysis. |
| Source licensing | Root project license pending; data/dependency-specific source terms documented. | Private review candidate; no automatic public software/data grant. |

No previous dataset, split, program, negative report or analysis branch is deprecated by this release. Potential future changes should be separate, versioned analyses: robust program validation, annotated longitudinal resistance data, improved comparability/rejection, or a different validated evolutionary model. The old recursive `scripts/package_audit.py` is retained historically but is **not used** for this archive; the new explicit allowlist excludes raw/local data and personal correspondence.

Fresh software/source reconstruction is distinguished from historical biological results throughout. Exact old full membership identity, cross-platform reproducibility, holdout program preservation and resistance-specific/causal interpretation remain unvalidated.
