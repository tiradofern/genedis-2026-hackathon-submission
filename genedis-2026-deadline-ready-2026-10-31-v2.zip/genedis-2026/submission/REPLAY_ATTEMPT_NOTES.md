# Archive replay attempts

The first preflight archive (`genedis-2026-preflight-v1.zip`, SHA256 `1a842d1f6cbcfa125ecbf3410f8f9b7383fea49b6dab01676a0b0af47d7f31ab`) passed content/hash review. Its reconstruction helper incorrectly resolved the virtual-environment Python symlink to the system interpreter. Consequently the first attempt used system NumPy 2.3.5/SciPy 1.17.0, rather than pinned NumPy 2.3.3/SciPy 1.16.2. The helper's static environment-description field in `archive_replay_2026-10-31.json` is inaccurate for this attempt.

That report is retained with its `review_required` result and logs, but **is not accepted as a successful pinned reconstruction**. Passing parser/frontend checks in that attempt do not override the environment mismatch. No new biological hypothesis test was run.

The helper now preserves the supplied virtual-environment invocation path and checks the exact NumPy/SciPy versions before source verification or reconstruction. The repeat uses a separate extracted directory, output report and logs; it does not replace the first attempt. The authoritative repeat report is `archive_replay_pinned_2026-10-31.json` once completed, with logs in `replay_logs_pinned/`.

Both transport checks use previously recovered public source files with strict hash re-verification and an existing environment. They are not fresh complete network acquisitions, independent dependency installations or biological replication. The final archive adds review/status records to the reviewed preflight payload; its own manifest and checksum verification remain separate from the reconstruction report.
