# GeNeDis 2026 submission requirements audit

## Update: organizer brief supplied by the investigator

The investigator pasted the October 14 email titled **GeNeDis 2026 Satellite Hackathon – Challenge Brief and Participation Instructions** during preparation. This is user-supplied organizer correspondence, not a separately authenticated email retrieval. Its scientific/submission instructions resolve the format and template questions below; the personal email text is not bundled.

- The brief acknowledges registration and permits NSCLC, RA, or both. A reproducible multi-omics pipeline or focused knowledge-mining model qualifies; no supervised classifier is required.
- Submit to **aris.vrahatis@ionio.gr** as a **compressed archive or repository/storage link**. Organizers need access if a private repository is used. An archive therefore avoids changing private-repository permissions.
- Include a short installation/execution README, source/accession list, code/pipeline, processed feature tables or representative samples, key figures/outputs, QC/model report, objectives, methodology, results, reproducibility and limitations.
- Keep large raw datasets outside the submission; provide accession details and retrieval/reconstruction scripts. Use open or already legitimately accessible resources.
- Results are exploratory research, not clinical predictions. Evaluation emphasizes data organization, methodological quality, biological grounding and reproducibility.
- **No Springer manuscript template is required** for the initial hackathon entry. It applies only to a possible subsequent book chapter.
- The email says the deadline/presentation details would be communicated separately. It does not independently establish a cutoff time. Continue to use the investigator's **18:00 EDT / 22:00 UTC** hard deadline.

The remaining delivery decisions are final claim/package approval, intended private distribution terms, and permission to send/upload. Registration-specific template retrieval is no longer a blocker. The webpage-only audit below is retained as the earlier verification record.

Status: preparation only; no registration, organizer contact, upload or access change performed by this workstream.

Verified 31 October 2026 at 06:39 UTC (02:39 EDT). Repository work is additive on `release/genedis-2026-10-31`, based on `a4edb2ba85daef38f38b4d9a3c4cbaa1516df0b9`. The existing `submission/README.md` is preserved as historical evidence.

## Official requirements and their limits

Primary source: [official hackathon page](https://2026.genedis.org/hackathon/), sections Important dates, Registration, Submission, Deliverables, Data and ethics, and Evaluation.

The official page specifies **31 October 2026**, submission to **aris.vrahatis@ionio.gr**, and rejection of late submissions. It does **not specify a cutoff time or timezone**. Registration supplies the challenge brief and submission template; those additional instructions were not verified here. Required materials are a README, documented sources/accessions, code or pipeline, processed feature tables, key outputs or a sample, a QC/model report, and limitations.

The scope permits NSCLC alone, preferably LUAD/LUSC. Evaluation emphasizes data organization, appropriate methods, biological grounding and reproducibility. It requests install instructions, provenance/access terms, practical checksums, versioned processed outputs, and explicit ready/exploratory/unavailable states. Data must be secondary, open or properly licensed, anonymised, and free of credentials or identifiable clinical information. Newly sought controlled-access approvals cannot be relied upon.

The page conflicts on the later event date (20 versus 21 November); this does not alter its 31 October submission date. It does not establish archive-versus-link mechanics.

The separate [conference paper guidelines](https://2026.genedis.org/registration/dates-and-deadlines/) describe the conference-paper/EasyChair process. They do not replace the hackathon instructions.

The [registration form](https://forms.gle/RS78bDiW3BJw2dgv7) resolves to a Google Form. The read-only web tool could not retrieve its contents. No form was submitted. **Unknown template and cutoff details do not prevent package preparation.** The PI should compare any already received brief/template with this audit before approving delivery.

## Operational schedule authorized by the investigator

All Eastern times below are **EDT, UTC−04:00, on 31 October 2026**. The investigator's 18:00 cutoff is an operational hard deadline, not a publicly verified organizer cutoff. Do not substitute the earlier historical estimate of local midnight.

| Checkpoint | Eastern | UTC | Required decision or output |
|---|---:|---:|---|
| Requirements, release structure and protocol | 06:00 | 10:00 | Record verified requirements, unknowns and reproducible release commands |
| Data/QC gate | 09:00 | 13:00 | Drop blocked pilot branches; retain reasons and denominators |
| Analyses and draft figures | 13:00 | 17:00 | Produce supported results with all tests and limitations |
| Sensitivity and claims review | 15:00 | 19:00 | Resolve material discrepancies; narrow claims where required |
| Analysis freeze | **16:00** | **20:00** | Stop new analyses/features; preserve final configuration and outputs |
| Package and reproduction review | 17:00 | 21:00 | Check materials, provenance, exclusions and actual replay status |
| Target final approval and delivery | **17:30** | **21:30** | PI reviews concrete package and explicitly approves external delivery |
| Investigator hard deadline | **18:00** | **22:00** | Operational stop; do not assume an extension |

## Package acceptance checklist

These are preparation checks, not assertions that the materials already pass. The release manifest and final QC report must link each completed item to its actual path, command, result and commit/hash.

| Item | Acceptance evidence |
|---|---|
| Scientific summary | Existing NSCLC project is the minimum deliverable; exploratory claims match the measured modalities and completed work |
| README and environment | Exact installation/run commands, dependency versions, expected outputs and measured runtime; unavailable runtimes stated |
| Source and access manifest | Accessions, URLs, source versions/checksums, retrieval dates, transformations, source terms and permitted redistribution |
| Processed data and metadata | Tables needed for supported outputs; identifiers and pair manifests included only where permitted and appropriate |
| Results and figures | Reproducible exports, full testing families, uncertainty, final patient denominators, negative and incomplete outcomes |
| QC and reproducibility | Exact tests and clean-reconstruction attempts distinguished from historical reports; failures retained |
| Limitations | Pairing/site/batch/composition and resistance-label limitations; provisional programs not presented as validated islands |
| Portable delivery | Archive or reviewable link prepared only to the extent allowed by confirmed template/access terms; no assumption that private GitHub is organizer-accessible |
| Release authorization | PI checks final claims, licensing, recipient/template, actual package contents and explicit permission for external submission |

## Repository and distribution boundaries

The checked-in `LICENSE` currently records that the project release license is pending selection by the research lead. It grants no rights over third-party data. Preserve that record; do not invent a permissive release license or equate public accessibility with redistribution permission. The PI must adjudicate the intended distribution terms for the final package. Preparation and private local review can continue while this decision remains open.

Use the existing collaborator access. Do not change repository visibility or permissions, merge branches, send messages, register, or submit to organizers as part of this workstream. A private repository link alone is not proof that external reviewers can retrieve the deliverables. Preserve an appropriate portable review package or an approved accessible route, subject to source terms and the submission template.

## Outstanding investigator checks

1. Organizer brief has now been supplied; its registration acknowledgment and archive/link route are recorded above. No Springer template is required.
2. Confirm organizer cutoff/timezone from that material if available; retain 18:00 EDT as the operational hard deadline regardless.
3. Choose the archive or an already accessible link; an archive requires no repository-access change.
4. Select or explicitly adjudicate project release terms separately from third-party source permissions.
5. Review the concrete frozen package before authorizing organizer delivery. No external submission is claimed here.
