"""Verify the deadline archive and run extracted-tree fixtures, never real assays.

Uses the existing package-integrity verifier first. The historical core producer
is compared byte-for-byte with the archive whose pinned reconstruction passed;
no large source retrieval, RNA scoring or core reconstruction is launched here.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tempfile
import time
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
from verify_archive import verify as verify_archive
from build_archive import PREFIX, eligible

CELL = 'pilot/cellular_2026-10-31/'
REFERENCE_SHA = '1ab5251e2c28612eb1428e233a70112741b3403ed1435f74be3de5331b4e5826'
FRONTEND_COMMAND = ('node', '--test', '--test-reporter=tap', 'tests/frontend.test.mjs')
CORE_REFERENCE_FILES = (
    'configs/candidate_island_v0_1.json', 'configs/explorer_build_v0_1.json',
    'manifests/public_tcga_samples_2026-10-17.tsv',
    'manifests/public_tcga_gdc_slides_2026-10-17.tsv', 'scripts/prepare_explorer.py',
    'src/survival_islands/explorer_model.py', 'requirements-app.txt',
    'manifests/public_tcga_files_2026-10-17.tsv', 'scripts/audit_public_tcga.py',
    'release_recovery/retrieve_core_sources.py',
    'release_recovery/program_definitions_2026-10-31.tsv')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def safe_inventory(archive):
    """Bound resource use and reject unsafe names/types before any extraction."""
    entries = archive.infolist()
    if not entries or len(entries) > 10000 or sum(x.file_size for x in entries) > 256 * 1024 * 1024:
        raise ValueError('Empty or unexpectedly large review archive')
    names = [entry.filename for entry in entries]
    if len(names) != len(set(names)):
        raise ValueError('Duplicate archive paths')
    for entry in entries:
        name, path = entry.filename, PurePosixPath(entry.filename)
        if ('\\' in name or '\x00' in name or path.is_absolute() or '..' in path.parts
                or not path.parts or path.parts[0] != PREFIX or len(path.parts) < 2
                or path.as_posix() != name):
            raise ValueError(f'Unsafe archive path: {name}')
        if not stat.S_ISREG(entry.external_attr >> 16):
            raise ValueError(f'Nonregular archive entry: {name}')
        relative = PurePosixPath(*path.parts[1:])
        if relative.parts[0] in {'data', 'runtime', '.git', '.venv', 'node_modules'}:
            raise ValueError(f'Excluded source/runtime payload: {relative}')
        if relative.suffix.lower() in {'.rds', '.rdata', '.h5ad', '.h5', '.gz', '.zip', '.pdf', '.xlsx', '.npz', '.parquet', '.feather'}:
            raise ValueError(f'Large/raw assay or publication blob: {relative}')
    return entries


def read_archive(path):
    with zipfile.ZipFile(path) as archive:
        safe_inventory(archive)
    integrity = verify_archive(path)
    with zipfile.ZipFile(path) as archive:
        payload = {name[len(PREFIX) + 1:]: archive.read(name) for name in archive.namelist()}
    return payload, integrity


def parsed_json(payload, name):
    if name not in payload:
        raise ValueError(f'Missing required archive artifact: {name}')
    return json.loads(payload[name])


def check_hash(payload, path, expected):
    if path not in payload or digest(payload[path]) != expected:
        raise ValueError(f'Internal frozen SHA256 mismatch/missing artifact: {path}')


def program_members(payload, specification):
    check_hash(payload, specification['gmt_path'], specification['gmt_sha256'])
    programs = {}
    for line in payload[specification['gmt_path']].decode().splitlines():
        if not line.strip():
            continue
        values = line.split('\t')
        if len(values) < 3 or values[0] in programs or len(values[2:]) != len(set(values[2:])):
            raise ValueError('Invalid complete GMT family')
        programs[values[0]] = values[2:]
    canonical = json.dumps(programs, sort_keys=True, separators=(',', ':')).encode()
    if len(programs) != 50 or specification['family_size'] != 50 or digest(canonical) != specification['members_sha256']:
        raise ValueError('Frozen 50-program membership mismatch')
    return programs


def check_csv_family(payload, prefix, programs, patients):
    patient_name = CELL + 'results/' + prefix + '_all_programs_by_patient.csv'
    family_name = CELL + 'results/' + prefix + '_conditional_by_family.csv'
    patient_rows = list(csv.DictReader(io.StringIO(payload[patient_name].decode())))
    family_rows = list(csv.DictReader(io.StringIO(payload[family_name].decode())))
    pairs = [(row['program'], row['patient_id']) for row in patient_rows]
    expected = {(program, patient) for program in programs for patient in patients}
    if len(patient_rows) != 150 or len(set(pairs)) != 150 or set(pairs) != expected:
        raise ValueError(f'{prefix}: complete 50×3 patient CSV is missing, duplicated or relabelled')
    if len(family_rows) != 50 or {row['program'] for row in family_rows} != set(programs):
        raise ValueError(f'{prefix}: complete 50-program family CSV is missing or duplicated')
    return {'run': prefix, 'patient_rows': len(patient_rows), 'family_rows': len(family_rows),
            'patient_csv_sha256': digest(payload[patient_name]), 'family_csv_sha256': digest(payload[family_name])}


def source_bindings(cohorts, source_manifest, protocol):
    artifacts = source_manifest.get('artifacts', [])
    source_by_name = {Path(item['path']).name: item for item in artifacts}
    if not artifacts or len(source_by_name) != len(artifacts):
        raise ValueError('Missing or ambiguous public source artifact inventory')
    matched = 0
    for cohort in cohorts:
        for item in cohort['inputs']:
            name = Path(item['path']).name
            if name == 'quek_cell_identity_mask.csv':
                if item['sha256'] != protocol['sensitivity']['cell_mask_sha256']:
                    raise ValueError('Derived cell mask differs from frozen sensitivity identity')
                continue
            source = source_by_name.get(name)
            if source is None or source['sha256'] != item['sha256'] or source['bytes'] != item['bytes']:
                raise ValueError(f'Frozen input and public source inventory disagree: {name}')
            matched += 1
    return matched


def scientific_contract(payload):
    protocol_path, gate_path = CELL + 'RNA_MEASUREMENT_PROTOCOL.json', CELL + 'RNA_EXECUTION_GATE.json'
    protocol, gate = parsed_json(payload, protocol_path), parsed_json(payload, gate_path)
    qc = parsed_json(payload, CELL + 'RNA_EXECUTION_QC.json')
    if (protocol['analysis_id'] != 'PAN_CANCER_FIXED_PROGRAMS_20261031'
            or protocol['status'] != 'FROZEN_BEFORE_REAL_PROGRAM_EFFECTS'
            or gate['analysis_id'] != protocol['analysis_id']
            or gate['decision'] != 'GO_DESCRIPTIVE_CONDITIONAL'
            or protocol['primary_nomination_enabled'] is not False
            or gate['primary_nomination_enabled'] is not False
            or gate['complete_primary_discovery_validation_claim_gate'] != 'HOLD_INCONCLUSIVE'
            or protocol['conditional_q_reporting_threshold'] != .05):
        raise ValueError('RNA scope, frozen status, q threshold or nomination gate mismatch')
    check_hash(payload, protocol_path, gate['protocol_sha256'])
    check_hash(payload, protocol_path, qc['protocol_sha256'])
    check_hash(payload, gate_path, qc['gate_sha256'])
    for path, expected in protocol['execution_artifacts'].items():
        check_hash(payload, path, expected)
    manifest = protocol['input_manifest']
    check_hash(payload, manifest['path'], manifest['sha256'])
    frozen = parsed_json(payload, manifest['path'])
    cohorts = frozen['cohorts']
    if (len(cohorts) != 3 or {x['cohort'] for x in cohorts} != set(protocol['cohort_ids'])
            or len(protocol['cohort_ids']) != 3 or len(set(protocol['cohort_cancer_types'].values())) != 2):
        raise ValueError('Expected exactly three discovery specimens in two cancer types')
    patients = [patient for cohort in cohorts for patient in cohort['patients']]
    if len(patients) != 3 or len(set(patients)) != 3:
        raise ValueError('Expected three independent patient identifiers')
    programs = program_members(payload, protocol['programs'])
    if protocol['engine_parameters']['expected_family_size'] != 50:
        raise ValueError('Engine family must remain all 50 programs')
    source_manifest = parsed_json(payload, CELL + 'EXECUTION_SOURCE_MANIFEST.json')
    if not source_manifest.get('artifacts'):
        raise ValueError('Missing documented public source artifact inventory')
    for item in source_manifest['artifacts']:
        if not item.get('url') or len(item.get('sha256', '')) != 64 or not item.get('bytes'):
            raise ValueError('Incomplete source accession/retrieval record')
    public_inputs_bound = source_bindings(cohorts, source_manifest, protocol)
    csv_checks = []
    for prefix in ('primary', 'quek_three_gene'):
        result = parsed_json(payload, CELL + 'results/' + prefix + '_full_result.json')
        if (result['patient_count'] != 3 or result['parameters']['family_size'] != 50
                or result['primary_nomination_enabled'] is not False
                or len(result['programs']) != 50
                or {row['program'] for row in result['programs']} != set(programs)
                or {row['patient_id'] for row in result['patients']} != set(patients)):
            raise ValueError(f'{prefix}: full JSON patient/program/scope mismatch')
        check_hash(payload, protocol_path, result['provenance']['protocol']['sha256'])
        check_hash(payload, gate_path, result['provenance']['gate']['sha256'])
        csv_checks.append(check_csv_family(payload, prefix, programs, patients))
    for replay in qc['replay_checks']:
        for item in replay['CSV_checks']:
            check_hash(payload, item['path'], item['sha256'])
    nsclc = parsed_json(payload, CELL + 'NSCLC_COMPONENT_EXECUTION_GATE.json')
    if (nsclc['decision'] != 'HOLD' or nsclc['stage'] != 'NOT_REACHED'
            or qc['robust_MSI_nominations'] != 0 or qc['primary_nomination_enabled'] is not False
            or qc['real_protein_program_effects_calculated'] is not False):
        raise ValueError('NSCLC hold or no-nomination evidence was changed')
    check_hash(payload, gate_path, nsclc['RNA_gate_sha256'])
    figures = parsed_json(payload, CELL + 'figures/figure_manifest.json')
    if figures['program_count'] != 50 or len(figures['figures']) != 6:
        raise ValueError('Expected full-family scientific figures')
    check_hash(payload, CELL + 'plot_program_measurements.py', figures['generator_sha256'])
    for item in figures['figures']:
        check_hash(payload, CELL + 'figures/' + item['file'], item['sha256'])
    for item in figures['inputs']:
        check_hash(payload, CELL + 'results/' + item['file'], item['sha256'])
    for item in figures['frozen_context']['artifact_files']:
        check_hash(payload, item['file'], item['sha256'])
    for path in ('PRIMARY_RNA_INPUT_QC.json', 'FRESH_RECONSTRUCTION_QC.json',
                 'QUEK_CELL_ID_QC.json', 'FINAL_EVIDENCE_REVIEW.md', 'RESULTS_2026-10-31.md'):
        if CELL + path not in payload:
            raise ValueError(f'Missing scientific/QC report: {path}')
    if parsed_json(payload, CELL + 'FRESH_RECONSTRUCTION_QC.json')['status'] != 'PASS':
        raise ValueError('Fresh reconstruction was not verified')
    return {'scope': 'descriptive and conditional diagnostics only', 'family_size': 50,
        'independent_patients': 3, 'cancer_types': 2, 'conditional_q_threshold': .05,
        'primary_nomination_enabled': False, 'NSCLC_validation': 'HOLD_NOT_REACHED',
        'CSV_checks': csv_checks, 'figures_verified': 6,
        'frozen_execution_artifacts_verified': len(protocol['execution_artifacts']),
        'public_source_input_hashes_bound': public_inputs_bound}


def current_files(payload, source_root):
    rules = json.loads((source_root / 'submission/package_allowlist.json').read_text())
    required = set(CORE_REFERENCE_FILES) | {'submission/verify_deadline_package.py'}
    for prefix in ('src', 'scripts', 'tests', 'web', 'pilot/cellular_2026-10-31'):
        for path in (source_root / prefix).rglob('*'):
            if path.is_file():
                name = path.relative_to(source_root).as_posix()
                if eligible(name, rules):
                    required.add(name)
    for name in sorted(required):
        check_hash(payload, name, file_digest(source_root / name))
    return {'current_core_and_cellular_artifacts_byte_verified': len(required)}


def core_reference(payload, reference_archive):
    if file_digest(reference_archive) != REFERENCE_SHA:
        raise ValueError('Reference is not the successfully replayed pinned preflight archive')
    with zipfile.ZipFile(reference_archive) as archive:
        safe_inventory(archive)
        comparisons = []
        for name in CORE_REFERENCE_FILES:
            old = archive.read(PREFIX + '/' + name)
            new = payload.get(name)
            comparisons.append({'path': name, 'old_sha256': digest(old),
                'new_sha256': digest(new) if new is not None else None, 'unchanged': new == old})
    if not all(item['unchanged'] for item in comparisons):
        raise ValueError('Historical core producer/source/definition bytes changed; prior replay alone is insufficient')
    return {'reference_archive': str(reference_archive), 'reference_sha256': REFERENCE_SHA,
        'unchanged_files': comparisons, 'large_core_preparation_rerun': False,
        'basis': 'Previously passed pinned extracted reconstruction plus unchanged producer/source-definition bytes'}


def extract_fresh(path, parent):
    work = Path(tempfile.mkdtemp(prefix='genedis-deadline-verification-', dir=parent))
    with zipfile.ZipFile(path) as archive:
        entries = safe_inventory(archive)
        for info in entries:
            target = work.joinpath(*PurePosixPath(info.filename).parts)
            if not target.resolve().is_relative_to(work.resolve()):
                raise ValueError('Extraction target escaped the fresh verification directory')
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, target.open('xb') as destination:
                while block := source.read(1024 * 1024):
                    destination.write(block)
    return work, work / PREFIX


def run_fixture(command, cwd, log):
    started = time.monotonic()
    env = os.environ.copy()
    env.update(PYTHONPATH='', PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', OPENBLAS_NUM_THREADS='1')
    with log.open('x') as stream:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=120)
    record = {'command': command, 'cwd': str(cwd), 'returncode': result.returncode,
              'seconds': round(time.monotonic() - started, 3), 'log': str(log)}
    if result.returncode:
        raise ValueError(f'Extracted-tree fixture failed; see {log}')
    return record


def frontend_pass_count(log):
    passed = re.search(r'^# pass (\d+)\s*$', log, re.MULTILINE)
    failed = re.search(r'^# fail (\d+)\s*$', log, re.MULTILINE)
    if not passed or not failed or int(passed.group(1)) < 5 or int(failed.group(1)) != 0:
        raise ValueError('Extracted-tree TAP frontend did not pass the five established checks')
    return int(passed.group(1))


def verify_package(archive, reference_archive, python, report_path, work_parent, source_root=ROOT):
    if report_path.exists():
        raise ValueError('Preserve prior verification reports; choose a fresh report path')
    report = {'status': 'FAIL', 'archive': str(archive), 'real_assay_analyses_run': False,
              'submission_or_Gmail_action_performed': False}
    try:
        payload, report['archive_integrity'] = read_archive(archive)
        report['scientific_contract'] = scientific_contract(payload)
        report['current_sources'] = current_files(payload, source_root)
        report['historical_core'] = core_reference(payload, reference_archive)
        work, extracted = extract_fresh(archive, work_parent)
        report['fresh_extraction'] = str(extracted)
        # Keep the supplied venv path; resolving its symlink would lose venv identity.
        python = str(Path(python).absolute())
        pin_command = [python, '-c', "import sys,numpy,scipy; print(sys.executable,numpy.__version__,scipy.__version__); assert numpy.__version__=='2.3.3' and scipy.__version__=='1.16.2'"]
        report['fixture_checks'] = [run_fixture(pin_command, extracted, work/'pinned_environment.log')]
        report['fixture_checks'].append(run_fixture([python, '-m', 'unittest', 'discover', '-s', 'tests', '-v'], extracted, work/'python_tests.log'))
        log = (work/'python_tests.log').read_text()
        match = re.search(r'Ran (\d+) tests?', log)
        if not match or int(match.group(1)) < 95:
            raise ValueError('Extracted-tree suite ran fewer than the 95 established Python tests')
        report['Python_tests_passed'] = int(match.group(1))
        report['fixture_checks'].append(run_fixture(list(FRONTEND_COMMAND), extracted, work/'frontend_tests.log'))
        frontend_log = (work/'frontend_tests.log').read_text()
        report['frontend_tests_passed'] = frontend_pass_count(frontend_log)
        report['status'] = 'PASS'
    except Exception as error:
        report['failure'] = {'type': type(error).__name__, 'message': str(error)}
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with report_path.open('x') as stream:
        json.dump(report, stream, indent=2); stream.write('\n')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--reference-archive', type=Path, default=Path('/workspace/genedis-2026-preflight-v2.zip'))
    parser.add_argument('--python', default=str(ROOT / '.venv/bin/python'))
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--work-parent', type=Path, default=Path('/tmp'))
    args = parser.parse_args()
    report = verify_package(args.archive, args.reference_archive, args.python, args.report, args.work_parent)
    print(json.dumps({'status': report['status'], 'report': str(args.report), 'failure': report.get('failure')}))
    raise SystemExit(0 if report['status'] == 'PASS' else 1)


if __name__ == '__main__':
    main()
