# GeNeDis 2026 reviewer entry point

**Project: Molecular Survival Islands — an NSCLC multi-omics explorer and an exploratory cross-cancer molecular-program study.**

The package contains a reconstructed **988-tumor NSCLC explorer**, complete definitions of **25 provisional RNA programs**, and newly executed measurements of **50 published programs in acquired-resistant MCC and melanoma specimens**. The primary molecular-discovery objective remains **inconclusive**: **no MSI was nominated, and independent NSCLC validation was not reached**. Numerical execution and reproducibility are established; resistance specificity, convergent selection and causality are not.

This is the current organizer-facing entry point. Earlier submission documents and archive-replay reports remain historical where their scope differs. **Preparation and an unsent Gmail draft are authorized; sending or submitting is expressly withheld.** This package does not represent Justin's personal scientific approval.

## Review the submission

- [Scientific summary](SCIENTIFIC_SUMMARY.md): question, datasets, integration, methods, results and limitations.
- [NSCLC reconstruction guide](../release_recovery/README.md): pinned installation, source/accession/hash inventory, preparation, execution and comparison. [Full provisional program definitions](../release_recovery/README.md) and the aggregate [program feature table](figures/program_feature_summary.tsv) preserve all 1,904 gene/loading rows.
- [Executed cellular study](../pilot/cellular_2026-10-31/README.md): verified cohorts, code, frozen protocols, source manifests, all 50-program results, clinical/identity/QC decisions and limitations. Start with its [results](../pilot/cellular_2026-10-31/RESULTS_2026-10-31.md).
- [Complete processed patient table](../pilot/cellular_2026-10-31/results/primary_all_programs_by_patient.csv), [family table](../pilot/cellular_2026-10-31/results/primary_conditional_by_family.csv), full JSON and stricter-mask outputs: complete negative and unavailable states, rather than selected favorable pathways.
- [Core figures](figures/01_nsclc_recovery.png), [published-program overlap](figures/02_published_program_overlap.png), and [three cellular program figures](../pilot/cellular_2026-10-31/figures/README.md): inventory, expression, conditional coordination and matched-null excess, with actual denominators and missingness.
- [Cellular reconstruction instructions](../pilot/cellular_2026-10-31/EXECUTION_REPRODUCIBILITY.md), [fresh reconstruction QC](../pilot/cellular_2026-10-31/FRESH_RECONSTRUCTION_QC.json) and [exact analysis replay/QC](../pilot/cellular_2026-10-31/RNA_EXECUTION_QC.json).
- Independent AI-assisted [pre-effect review](../pilot/cellular_2026-10-31/INDEPENDENT_EXECUTION_REVIEW.md), [post-effect adversarial review](../pilot/cellular_2026-10-31/RESULTS_ADVERSARIAL_REVIEW.md), [final evidence audit](../pilot/cellular_2026-10-31/FINAL_EVIDENCE_REVIEW.md), and earlier [longitudinal feasibility report](../pilot/cohorts/FEASIBILITY_REPORT_2026-10-31.md).
- [Requirements coverage](DELIVERY_CHECKLIST.md) and [source/distribution terms](RELEASE_TERMS_AND_PROVENANCE.md).

## Install and run the NSCLC explorer

The tested core runtime is Python **3.12.14**, NumPy **2.3.3**, SciPy **1.16.2**. Use a fresh checkout/output directory to preserve previous evidence. Core preparation retrieves approximately 647 MB of public processed sources and produces about 117 MiB per prepared run, plus the environment.

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-app.txt
.venv/bin/python release_recovery/retrieve_core_sources.py --report release_recovery/source_recovery_local.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python scripts/prepare_explorer.py --destination data/processed/explorer_local
.venv/bin/python scripts/run_explorer.py --data data/processed/explorer_local --port 8766
```

Open **http://127.0.0.1:8766**. Windows uses `.venv\Scripts\python.exe`; see the reconstruction guide for platform details. No raw sequencing, GTEx/HLCA, R or phylogeny-engine installation is needed for this bounded explorer. The old 25 programs remain provisional; their appearance in the interface does not establish treatment resistance.

## Reproduce the new cellular measurements

Follow the exact commands in [EXECUTION_REPRODUCIBILITY.md](../pilot/cellular_2026-10-31/EXECUTION_REPRODUCIBILITY.md). The public source manifest provides URLs, lengths and SHA256s for 12 processed inputs. The sequence is source retrieval/verification, deterministic pretreatment identity anchor, frozen RNA cell identification, technical preparation and hash-bound complete-family calculation. Large sources remain outside Git. Canonical reconstruction commands belong in a fresh checkout; preparation can overwrite existing derived outputs.

The frozen pre-effect commits are `74cf912` and `85b3694`. The original tracked input manifest permits exact verification of reconstructed arrays while fresh receipt timestamps remain separate. **All 15 checked reconstructed payloads matched**, and a separate analysis replay matched all scientific JSON fields and all four CSV files. These checks used previously retrieved, hash-verified sources; they were not a second complete network download or independent biological replication.

```bash
.venv/bin/python -m unittest discover -s tests -v
node --test tests/frontend.test.mjs
.venv/bin/python pilot/programs/freeze_panel.py --verify-only
```

The recorded scientific-build suite passed **95 Python tests and five frontend tests**; deadline packaging adds integrity fixtures whose current extracted-tree counts are recorded in the external final verification receipt. Node is needed for frontend tests, not basic application use. Earlier browser desktop/mobile checks passed for the core explorer. Plotting dependencies are separate from the frozen numerical runtime; use the figure guides for regeneration. No supervised clinical predictor was trained.

## Package integrity and delivery status

The current deadline-ready archive target is `/workspace/genedis-2026-deadline-ready-2026-10-31-v2.zip`. Its exact final commit, size, SHA256 and verification receipt must be taken from the final build records; this document does not invent them. Verify a completed archive with:

```bash
.venv/bin/python submission/verify_archive.py /workspace/genedis-2026-deadline-ready-2026-10-31-v2.zip
```

The archive includes `PACKAGE_MANIFEST.json` and `SHA256SUMS.tsv`. The explicit allowlist excludes downloaded expression matrices, cell-level intermediate matrices, environments, credentials, correspondence and Git internals; sources remain reconstructable from accession/URL/hash manifests and code. Complete small processed result tables, representative artifacts, figures and QC are included. Large raw datasets are not uploaded.

The earlier 07:04 review archive and its [pinned replay](archive_replay_pinned_2026-10-31.json) remain preserved. That report's **28-test** count and cached-input transport scope describe the earlier archive, not the newly expanded study. Do not use its old archive filename or hash to identify the deadline-ready package.

Root software licensing remains pending; retain separate third-party terms. The organizer brief accepts an archive, so no private-repository access change is required. The operational deadline is **18:00 EDT / 22:00 UTC on October 31, 2026**. The recipient specified by the organizers is `aris.vrahatis@ionio.gr`. **The user requested everything prepared but no submission: the Gmail draft must remain unsent.**
