"""Verify ZIP paths, entry types, allowlist and every content SHA256 before use."""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
from pathlib import PurePosixPath
import stat
import zipfile

from build_archive import PREFIX, VERSION, eligible, required_materials, validate_v2_evidence


def verify(path):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate archive entries")
        for info in archive.infolist():
            p = PurePosixPath(info.filename)
            if len(p.parts) < 2 or p.is_absolute() or ".." in p.parts or "\\" in info.filename or p.parts[0] != PREFIX:
                raise ValueError("Unsafe archive path")
            if not stat.S_ISREG(info.external_attr >> 16):
                raise ValueError("Archive entry is not a regular file")
            if info.file_size > 10000000:
                raise ValueError("Archive entry exceeds fixed 10 MB size guard")
        if sum(i.file_size for i in archive.infolist()) > 100 * 1024 * 1024:
            raise ValueError("Archive exceeds bounded total uncompressed size")
        payload = {n[len(PREFIX)+1:]: archive.read(n) for n in names}
    manifest = json.loads(payload["PACKAGE_MANIFEST.json"])
    if manifest["package"] != PREFIX:
        raise ValueError("Unexpected package identity")
    rules = json.loads(payload["submission/package_allowlist.json"])
    rows = list(csv.DictReader(io.StringIO(payload["SHA256SUMS.tsv"].decode()), delimiter="\t"))
    hashes = {r["path"]: r["sha256"] for r in rows}
    if len(hashes) != len(rows) or set(hashes) != set(payload) - {"SHA256SUMS.tsv"}:
        raise ValueError("Checksum inventory mismatch")
    for name, expected in hashes.items():
        if hashlib.sha256(payload[name]).hexdigest() != expected:
            raise ValueError(f"Checksum mismatch: {name}")
    records = manifest["files"]
    if len({r["path"] for r in records}) != len(records) or len(records) != manifest["file_count"]:
        raise ValueError("Manifest duplicate/count mismatch")
    if {r["path"] for r in records} != set(payload) - {"PACKAGE_MANIFEST.json", "SHA256SUMS.tsv"}:
        raise ValueError("Manifest payload mismatch")
    for item in records:
        name = item["path"]
        if not eligible(name, rules):
            raise ValueError(f"Disallowed payload: {name}")
        if len(payload[name]) != item["bytes"] or item["bytes"] > rules["max_file_bytes"] or hashes[name] != item["sha256"]:
            raise ValueError(f"Manifest metadata mismatch: {name}")
    required = required_materials(rules)
    if not required.issubset(payload):
        raise ValueError("Missing required reviewer materials")
    if rules.get("version") == VERSION:
        if manifest.get("package_version") != VERSION or manifest["source_tree_had_uncommitted_changes"] is not False:
            raise ValueError("New package must identify v2 and a clean committed source")
        expected = {name: hashlib.sha256(payload[name]).hexdigest() for name in sorted(required)}
        if manifest.get("required_artifact_sha256") != expected:
            raise ValueError("Required-evidence hash bindings differ")
        validate_v2_evidence(payload)
    elif rules.get("version") != "2026-10-31-v1":
        raise ValueError("Unknown package-policy version")
    with open(path, "rb") as source:
        archive_hash = hashlib.sha256(source.read()).hexdigest()
    return {"status": "passed", "archive": str(path), "payload_files": len(records),
            "sha256": archive_hash,
            "source_commit": manifest["source_commit"],
            "source_tree_dirty": manifest["source_tree_had_uncommitted_changes"],
            "scope": "content integrity, safe paths, entry types and declared allowlist"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive")
    args = parser.parse_args()
    print(json.dumps(verify(args.archive), indent=2))
