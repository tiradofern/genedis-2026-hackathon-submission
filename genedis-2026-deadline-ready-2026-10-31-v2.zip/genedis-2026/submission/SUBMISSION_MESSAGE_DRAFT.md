# Unsent organizer message for PI review

**Status:** draft only. No message or attachment has been sent. The PI must approve the exact final archive and external delivery first. An archive route avoids changing private-repository access.

**To:** aris.vrahatis@ionio.gr

**Subject:** GeNeDis 2026 Hackathon — Molecular Survival Islands: NSCLC research workflow

Dear GeNeDis 2026 Hackathon Committee,

Please find our project, **Molecular Survival Islands: an NSCLC multi-omics explorer and exploratory cross-cancer program study**, attached as `genedis-2026-deadline-ready-2026-10-31-v2.zip`.

The NSCLC workflow links RNA, copy-number, reported-variant and clinical/specimen metadata for 507 LUAD and 481 LUSC tumors. It includes an interactive local explorer, complete definitions of 25 provisional RNA programs, source-reconstruction code, processed summaries, figures, QC and reproducibility reports.

A separate frozen analysis measures all 50 published Hallmark programs in three acquired-resistant patients across MCC and melanoma. The melanoma endpoint contains six lineage-positive putative malignant cells, and its stricter five-cell coordination sensitivity is unassessable. No MSI was nominated; independent NSCLC validation was not reached. The results remain exploratory and do not establish resistance specificity, convergent selection, causality or clinical prediction. Earlier negative findings and unavailable results are preserved.

Please begin with `genedis-2026/submission/REVIEWER_README.md`. The archive includes installation/execution instructions, documented accessions and source terms, complete small result tables, key outputs, limitations and internal checksums. Large raw/source datasets and installed environments are excluded.

The attached archive and the source commit recorded in its `PACKAGE_MANIFEST.json` identify the version offered for evaluation. Repository development may continue afterward; this snapshot will remain available unchanged. Project and third-party distribution terms are documented separately.

Best regards,

Fernanda Tirado and Justin

---

This is the archived message template, not evidence of delivery. The live Gmail draft will also identify the verified final source commit, ZIP size and SHA256 after the archive is built. Those external identifiers are deliberately not embedded in the archive that they identify. The user explicitly requested **DO NOT SUBMIT**; create/update the draft only, never send it.
