# Deadline-ready package checklist

**Authorized: prepare the complete current package and an unsent Gmail draft. Explicitly not authorized: send or submit.** Deadline: **18:00 EDT / 22:00 UTC, October 31, 2026**. Organizer recipient: `aris.vrahatis@ionio.gr`.

This checklist covers the expanded current materials, not only the earlier 07:04 archive. Submission readiness does not imply scientific validation or external delivery. Justin's personal approval is not claimed.

| Organizer requirement | Current evidence |
|---|---|
| NSCLC/RA biological or computational objective | [Scientific summary](SCIENTIFIC_SUMMARY.md): NSCLC multi-omics explorer plus bounded pan-cancer hypothesis study with independent NSCLC validation explicitly not reached |
| Installation/execution README | [Reviewer README](REVIEWER_README.md), [core reconstruction](../release_recovery/README.md), [cellular reconstruction](../pilot/cellular_2026-10-31/EXECUTION_REPRODUCIBILITY.md), pinned dependencies and exact commands |
| Source/accession/provenance list | Core 47-file TCGA inventory; cellular 12-input public URL/length/SHA manifest; GEO, TISCH, Mendeley v1 and Zenodo clinical/source audits; fixed MSigDB release and terms |
| Code/pipeline and preprocessing/QC | Core preparation/model/server/frontend; new deterministic identity anchor, frozen cell classifier, full count validation, technical preparation, conditional program engine, gated runner and reproducibility helpers |
| Processed features or representative samples | Full 1,904 provisional program-gene/loading rows and aggregate feature table; complete 50-program patient/family CSVs and primary/strict JSON results; representative artifacts; large source/cell matrices reconstructed locally |
| Key figures/outputs | Core inventory/overlap figures; three new complete-family activity/coordination/excess figures with NA states and patient/cell denominators |
| QC/model and reproducibility report | Source checks, core recovery evidence, fresh 15-payload hash agreement, exact scientific JSON/four-CSV replay, 95 scientific-build Python and five frontend passes, with subsequent packaging fixtures checked separately; earlier browser checks identified separately |
| Results and limitations | 507 LUAD + 481 LUSC, 25 provisional programs; new 50-Hallmark measurements in two MCC patients and one six-cell melanoma endpoint; 46 activity/31 coordination/19 coordination-unassessable; conditional OXPHOS Q=0.044992; no MSI nomination, NSCLC NOT_REACHED |
| Negative and unavailable results | All tested/unassessable rows retained; five-cell sensitivity unassessable; earlier paired cohorts/12 directional tests remain untested; prior route/normal-reference failures preserved |
| Multi-omics and claim boundaries | NSCLC layers linked by source sample key; new cross-cancer RNA observations remain transcriptomic; restricted protein readiness is not whole-program validation; no clinical prediction, resistance specificity, selection or causal claim |
| No large raw-data upload | Explicit archive allowlist excludes downloaded expression matrices, cell-level intermediate matrices, environments, credentials, correspondence and Git internals; retrieval/reconstruction information included |
| Distribution/access | Portable archive avoids private-repository access changes; source/dependency terms retained; root software licensing pending, with private research/evaluation intent stated |
| External delivery | **Unsent draft only. User explicitly said DO NOT SUBMIT. No send action may be inferred from package completion.** |

## Final archive and draft verification

The intended current package is `/workspace/genedis-2026-deadline-ready-2026-10-31-v2.zip`. The final builder/verification records must establish its actual source commit, file inventory, size and external SHA256. Do not reuse the earlier archive's hash or invent a final value before building. Its internal `PACKAGE_MANIFEST.json` and `SHA256SUMS.tsv` identify included files; the completed ZIP's own SHA256 belongs beside it.

Before marking the preparation complete:

- Freeze the final current materials and include the cellular source/protocol/result/figure/QC/reconstruction artifacts in the package allowlist.
- Build and verify the exact deadline-ready archive. Check that every linked current artifact is present and large downloaded inputs are excluded.
- Preserve the earlier 07:04 archive, its verification receipts and historical results. Its 28-test report describes that earlier artifact; current full testing is 95 Python/five frontend.
- Record the new archive's actual filename, size, SHA256, source commit and verification outcome in the final handoff.
- Prepare the authorized Gmail draft to the organizer, with the correct current archive attached or a verified accessible delivery link. Check recipient, subject, objective, results, limitations and attachment identity. Keep the draft **unsent**.
- Report draft status and remaining scientific limitations to the investigator. Sending, repository access changes, merging or external submission require a later explicit instruction; none is implied here.

## Evidence and operational limits

The new measurements remain exploratory: OXPHOS's conditional threshold crossing cannot override the pre-effect six-cell robustness HOLD. NSCLC protein validation remains not reached. Preparing a submission does not authorize further molecular discovery, post-effect retuning or an unsupported convergence claim.

Fresh reconstruction verified 15 payloads from already retrieved hash-verified public sources, followed by exact frozen-analysis replay. It does not claim a second full network acquisition, a new independent environment or independent biological replication. Historical heavy pipelines were not rerun. Network speeds, dependency installation and runtime on other machines can differ; use the pinned instructions and preserve any reconstruction failure.

Earlier [archive replay](archive_replay_pinned_2026-10-31.json) and [attempt notes](REPLAY_ATTEMPT_NOTES.md) remain useful transport history, but they do not verify the new archive. Final current verification belongs to the deadline-ready build records.
