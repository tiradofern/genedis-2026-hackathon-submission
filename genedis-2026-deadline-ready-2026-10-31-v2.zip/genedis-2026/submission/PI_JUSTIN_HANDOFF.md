# PI and Justin handoff for 31 October 2026

**Latest request:** Fernanda wants all subsequent interview decisions run by Justin. Use [the single consolidated decision memo](../reviews/PI_DECISIONS_FOR_JUSTIN_2026-10-31.md), which asks for one response to 16 current preferences and the remaining operational issues. This supersedes the earlier broad interview stage. His findings draft in PR #12 is available; these new preferences and a joint protocol are not yet signed off. The current submission archive and scientific release remain unchanged.


**Current review sequence requested by Fernanda:** Justin independently evaluates the plan and actual results, returns prioritized recommendations, and then reassesses the findings/revisions with Fernanda. Use [the current review request](../reviews/JUSTIN_PLAN_RESULTS_REVIEW_REQUEST_2026-10-31.md), its review template and joint-decision template. Justin's report/sign-off has not yet been received. The frozen scientific release/archive remains unchanged; this coordination update does not authorize new biological analyses or organizer delivery. Earlier proposed task ownership below is retained as background.

**Requirements update:** the PI supplied the October 14 organizer email. Archive or repository/storage link delivery is confirmed, NSCLC alone qualifies, and no Springer template is required. Use `requirements_audit.md`'s update above its preserved webpage-only record. An archive is the prepared route and needs no repository-permission changes. Final sending remains unapproved.

This is a proposed division of review work for investigator consideration. It has not been sent to Justin or the organizers, and it does not establish that Justin accepted a task. Use the existing project access; no permission, visibility or branch-merge changes are requested.

The working release branch is `release/genedis-2026-10-31`, based on `a4edb2ba85daef38f38b4d9a3c4cbaa1516df0b9`. Historical artifacts, the 988-case LUAD/LUSC backbone, provisional RNA programs and negative findings remain preserved. Current completion status must come from the release records and actual rerun evidence, not from this handoff.

## Priority and scope

The minimum submission is a reproducible, accurately bounded presentation of the existing NSCLC multi-omics project. The optional paired-expression pilot must earn inclusion through clinical, pairing, technical and statistical readiness gates. Two eligible cohorts are preferred; one supports a single-cohort result. If neither passes, submit the existing-project assessment and feasibility findings. Failed reconstruction must be labeled incomplete rather than described as a clean replay.

The immediate pilot question is: **Do predefined molecular programs show recurring changes between pretreatment and acquired-resistance biopsies in independently collected cohorts?** A successful two-cohort result concerns recurring paired score changes in those contexts. It does not by itself establish genomic conservation, treatment selection, resistance specificity, coordinated cooperation or causality. The broader Molecular Survival Islands hypothesis remains exploratory.

## Proposed human review ownership

| Proposed reviewer | Bounded task | Return artifact or decision | Escalation |
|---|---|---|---|
| PI | Confirm final clinical/scientific scope and adjudicate acquired-resistance eligibility or important site/composition ambiguity | Written acceptance, narrowing or exclusion decision with rationale | Unresolved eligibility blocks inference for the affected patients/cohort |
| PI | Check any existing registration template, cutoff, delivery format and release/source terms | Requirements decisions recorded against `requirements_audit.md` | Unknown details do not stop preparation; unsupported distribution must not be assumed approved |
| Justin, if accepted | Independently execute the minimum release workflow from a clean checkout/environment | Exact commit, commands, input availability, runtimes, results, discrepancies and reproducibility verdict | Report blocked/missing inputs rather than borrowing another run's success |
| Justin, if accepted | Audit final pair manifest, clinical evidence and site/processing exclusions independently of program results | Patient-level eligibility discrepancy list with source references and retained exclusions | Return clinical ambiguities to PI; do not silently relax gates |
| Justin, if accepted | Check exported figures/tables and final claims against frozen reports | Concise review of denominators, all tests, uncertainty and negative/incomplete findings | Material mismatch requires correction or narrower presentation |
| PI | Review final package contents and submission wording | Explicit final approval for organizer delivery | No organizer upload/email without this approval |

The repository already provides an initial independent-review workflow in `docs/TEAM_WORKFLOW.md` and `reviews/REVIEW_PROMPT.txt`. Reuse its conventions where practical. Avoid competing writes to another stream's manifests, configuration or generated results. Review comments should identify the exact file, commit and affected claim. Proposed owners remain proposed until accepted.

## Parallel implementation streams and interfaces

| Stream | Owns | Supplies to reviewers |
|---|---|---|
| Release recovery | Additive NSCLC reconstruction/run recipe and current reconstruction evidence | Declared inputs, commands, outputs, checksums and ready/incomplete states |
| Cohort readiness | Verified treatment/timing/patient/pair metadata and exclusions | Source-linked eligibility evidence, technical/site concerns and inferential/descriptive/stop recommendation |
| Program analysis, conditional on gates | Frozen published program definitions, scoring/testing and sensitivities | Gene coverage, fixed testing family, all patient changes, effect sizes, uncertainty and complete results |
| Release integration | README, package manifest, scientific summary, figures and final review bundle | One concrete package whose claims and evidence can be checked |
| Requirements audit | Official-source requirements and operational schedule | `submission/requirements_audit.md`; unknown template/cutoff details explicitly retained |

Each producer should expose a stable report or manifest rather than relying on conversation history. Analysis must consume the adjudicated pair manifest and fixed program configuration, not independently redefine the sample universe. Interface changes must be recorded and returned to the owning stream; preserve failed/unknown/excluded states.

## Same-day review schedule

Times are EDT (UTC−04:00) on 31 October 2026. See `requirements_audit.md` for UTC conversions and official-source distinctions.

| Time | Review focus |
|---|---|
| 06:00 | Requirements, bounded release recipe, shared protocol and file contracts available for review |
| 09:00 | PI/cohort review resolves go/descriptive/stop gates; drop blocked pilot scope |
| 13:00 | Review completed analyses, all testing outcomes and draft figures |
| 15:00 | Independent sensitivity/claim review; finish material corrections |
| **16:00** | Analysis freeze: no expansion of cohorts, programs or features |
| 17:00 | Final reproducibility/materials review; document remaining failures honestly |
| **17:30** | Target PI approval and approved delivery |
| **18:00** | Investigator operational hard deadline |

After the freeze, prioritize repairing packaging, broken links, transcription errors and material reproducibility defects in the frozen scope. A serious unresolved defect should narrow or remove a claim; it should not trigger an unreviewed late analytical expansion.

## Final review questions

1. Which results were reconstructed now, which are historical records, and which remain unavailable?
2. Are all participant/sample denominators, exclusions, missing states and modality limits explicit?
3. Do treatment-response claims rely on verified treatment-response data rather than the cross-sectional TCGA backbone?
4. Are provisional RNA programs, exploratory dependencies, failed normal-reference gates and negative evolutionary findings represented accurately?
5. Does every included inferential pilot pass its documented eligibility and technical gates, retain its complete testing family, and disclose uncertainty?
6. Can an independent reviewer follow the documented commands and obtain the stated supported outputs with permitted inputs?
7. Has the PI reviewed the exact package and explicitly authorized external delivery?

No task in this document authorizes sending the package or a message to another person. The investigator retains scientific adjudication and final submission authority.
