"""Exercise archive rejection on corrupted bytes, paths, types and duplicates."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import tempfile
import warnings
import zipfile

from verify_archive import verify


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    if args.report.exists():
        parser.error("Preserve the prior guard report; use a new --report")
    verify(args.archive)
    with zipfile.ZipFile(args.archive) as archive:
        entries = [(info, archive.read(info.filename)) for info in archive.infolist()]
    results = []
    with tempfile.TemporaryDirectory(prefix="genedis-archive-guards-") as directory:
        for scenario in ("changed_bytes", "parent_traversal", "symlink", "duplicate_path"):
            changed = Path(directory) / f"{scenario}.zip"
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", UserWarning)
                with zipfile.ZipFile(changed, "x", compression=zipfile.ZIP_DEFLATED) as archive:
                    for info, data in entries:
                        if scenario == "changed_bytes" and info.filename == "genedis-2026/README.md":
                            data += b"\nSIMULATED CORRUPTION FOR GUARD CHECK\n"
                        archive.writestr(info, data)
                    if scenario == "parent_traversal":
                        extra = zipfile.ZipInfo("genedis-2026/../escaped.txt")
                        extra.external_attr = 0o100644 << 16
                        archive.writestr(extra, b"synthetic")
                    elif scenario == "symlink":
                        extra = zipfile.ZipInfo("genedis-2026/synthetic_link.txt")
                        extra.external_attr = 0o120777 << 16
                        archive.writestr(extra, b"synthetic_target")
                    elif scenario == "duplicate_path":
                        archive.writestr(entries[0][0], entries[0][1])
            try:
                verify(changed)
            except ValueError as error:
                results.append({"scenario": scenario, "status": "rejected_as_required", "reason": str(error)})
            else:
                raise RuntimeError(f"Guard failed to reject {scenario}")
    args.report.write_text(json.dumps({"created_utc": datetime.now(timezone.utc).isoformat(),
        "status": "passed", "source_archive": str(args.archive), "checks": results,
        "scope": "Synthetic fault injection into disposable archive copies; no biological analysis"}, indent=2) + "\n")
    print(json.dumps({"status": "passed", "rejection_scenarios": len(results)}))


if __name__ == "__main__":
    main()
