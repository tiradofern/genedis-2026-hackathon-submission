"""Local read-only HTTP service for the verified Molecular Survival Island Explorer."""
from __future__ import annotations

import csv
import hashlib
import json
import sqlite3
from contextlib import closing
from functools import lru_cache
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

import numpy as np

from .explorer_model import descriptive_comparison

ROOT = Path(__file__).resolve().parents[2]


def file_hash(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def nullable_values(values):
    """JSON null preserves an unmeasured value; it must never become zero."""
    return [float(value) if np.isfinite(value) else None for value in values]


class ExplorerStore:
    def __init__(self, directory, root=ROOT, verify=True):
        self.directory, self.root = Path(directory), Path(root)
        manifest = json.loads((self.directory / "prepared_manifest.json").read_text())
        for name, key in (("candidate_island_v0_1.json", "criteria_sha256"), ("explorer_build_v0_1.json", "build_sha256")):
            if file_hash(self.root / "configs" / name) != manifest[key]:
                raise ValueError("Prepared data do not match the current criteria; rerun scripts/prepare_explorer.py")
        for name, expected in manifest.get("recipe_files", {}).items():
            if file_hash(self.root / name) != expected:
                raise ValueError("Prepared data do not match the current preparation recipe; rerun scripts/prepare_explorer.py")
        if verify:
            for name, expected in manifest["files"].items():
                if file_hash(self.directory / name) != expected:
                    raise ValueError(f"Prepared artifact checksum mismatch: {name}")
        self.bootstrap = json.loads((self.directory / "bootstrap.json").read_text())
        if self.bootstrap["fingerprint"] != manifest["fingerprint"]:
            raise ValueError("Prepared data fingerprint mismatch")

    def cohort(self, code):
        if code not in self.bootstrap["cohorts"]:
            raise ValueError("Choose LUAD or LUSC")
        return self.bootstrap["cohorts"][code]

    @lru_cache(maxsize=2)
    def matrices(self, code):
        self.cohort(code)
        with np.load(self.directory / f"{code}_matrices.npz", allow_pickle=False) as arrays:
            result = {name: arrays[name] for name in ("rna", "cna")}
        result["catalog"] = json.loads((self.directory / f"{code}_genes.json").read_text())
        return result

    def connection(self):
        return sqlite3.connect((self.directory / "measurements.sqlite").resolve().as_uri() + "?mode=ro", uri=True)

    def gene(self, code, query):
        cohort, matrices = self.cohort(code), self.matrices(code)
        catalog = matrices["catalog"]
        exact = [i for i, symbol in enumerate(catalog["rna_symbols"]) if symbol.upper() == query.upper()]
        if query in catalog["rna_ids"]:
            index = catalog["rna_ids"].index(query)
        elif len(exact) == 1:
            index = exact[0]
        else:
            raise KeyError("Gene was not found uniquely in the verified RNA feature universe")
        identity, symbol = catalog["rna_ids"][index], catalog["rna_symbols"][index]
        cna_index = catalog["cna_ids"].index(identity) if identity in catalog["cna_ids"] else None
        with closing(self.connection()) as database:
            carriers = [row[0] for row in database.execute(
                "SELECT DISTINCT sample FROM variants WHERE study=? AND gene=? ORDER BY sample", (code, identity))]
        return dict(id=identity, symbol=symbol, expression_unit="log2(batch-normalized RSEM + 1)",
                    expression=nullable_values(matrices["rna"][:, index]),
                    cna=nullable_values(matrices["cna"][:, cna_index]) if cna_index is not None else [None] * len(cohort["samples"]),
                    reported_variant_samples=carriers,
                    note="Any reported MAF classification; no reported event does not establish wild-type at every locus")

    def specimen(self, code, sid):
        cohort = self.cohort(code)
        sample = next((row for row in cohort["samples"] if row["id"] == sid), None)
        if sample is None:
            raise KeyError("Specimen is outside the verified core cohort")
        with closing(self.connection()) as database:
            count = database.execute("SELECT COUNT(*) FROM variants WHERE study=? AND sample=?", (code, sid)).fetchone()[0]
            rows = database.execute("SELECT symbol,classification,protein,chromosome,position,reference,alternate FROM variants WHERE study=? AND sample=? ORDER BY symbol,classification LIMIT 60", (code, sid)).fetchall()
        columns = ["symbol", "classification", "protein", "chromosome", "position", "reference", "alternate"]
        slides = json.loads((self.directory / f"{code}_slides.json").read_text())
        selected = [dict(row, linkage="sample-key" if row["sample_key"] == sid else "patient-only")
                    for row in slides if row["patient_id"] == sample["patient_id"]]
        selected.sort(key=lambda row: (row["linkage"] != "sample-key", row["diagnostic_slide"] != "True", row["file_name"]))
        return dict(sample=sample, variants=[dict(zip(columns, row)) for row in rows],
                    variant_record_count=count, displayed_variant_limit=60, genome_build="GRCh37", slides=selected)

    def compare(self, code, a, b):
        cohort = self.cohort(code)
        if not isinstance(a, list) or not isinstance(b, list) or len(a) > 1000 or len(b) > 1000:
            raise ValueError("Provide two bounded specimen-ID lists")
        if not all(isinstance(sid, str) for sid in a + b):
            raise ValueError("Specimen IDs must be strings")
        return descriptive_comparison(cohort["samples"], cohort["scores"], a, b)

    def provenance(self):
        with (self.root / "manifests/public_tcga_files_2026-10-17.tsv").open(newline="") as stream:
            inventory = list(csv.DictReader(stream, delimiter="\t"))
        return dict(inventory=inventory, criteria=self.bootstrap["criteria"], build=self.bootstrap["build"],
                    fingerprint=self.bootstrap["fingerprint"], linkage=self.bootstrap["linkage"],
                    exclusions=json.loads((self.directory / "feature_exclusions.json").read_text()))


def handler_for(store, web_directory):
    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=str(web_directory), **kwargs)

        def end_headers(self):
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
            super().end_headers()

        def json_response(self, value, status=200):
            body = json.dumps(value, allow_nan=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            parsed = urlsplit(self.path)
            if not parsed.path.startswith("/api/"):
                if parsed.path == "/":
                    self.path = "/index.html"
                return super().do_GET()
            query = parse_qs(parsed.query)
            code = query.get("study", ["LUAD"])[0]
            try:
                if parsed.path == "/api/health":
                    value = dict(status="ready", version=store.bootstrap["version"], fingerprint=store.bootstrap["fingerprint"])
                elif parsed.path == "/api/bootstrap":
                    value = store.bootstrap
                elif parsed.path == "/api/gene":
                    value = store.gene(code, query.get("gene", [""])[0][:80])
                elif parsed.path == "/api/specimen":
                    value = store.specimen(code, query.get("id", [""])[0])
                elif parsed.path == "/api/provenance":
                    value = store.provenance()
                else:
                    raise KeyError("Unknown API route")
                self.json_response(value)
            except (ValueError, KeyError) as exc:
                self.json_response(dict(error=str(exc).strip("'")), 400)
            except Exception:
                self.json_response(dict(error="The local dataset could not be read. Restart after checking the prepared-data manifest."), 500)

        def do_POST(self):
            if self.path != "/api/compare":
                return self.json_response(dict(error="Unknown API route"), 404)
            try:
                size = int(self.headers.get("Content-Length", "0"))
                if not 0 < size <= 200000:
                    raise ValueError("Comparison request is empty or too large")
                value = json.loads(self.rfile.read(size))
                if not isinstance(value, dict):
                    raise ValueError("Provide a comparison object")
                self.json_response(store.compare(value.get("study"), value.get("a"), value.get("b")))
            except (ValueError, KeyError, TypeError) as exc:
                self.json_response(dict(error=str(exc)), 400)

    return Handler


def serve(directory, port=8766):
    store = ExplorerStore(directory)
    server = ThreadingHTTPServer(("127.0.0.1", port), handler_for(store, ROOT / "web"))
    print(f"Molecular Survival Island Explorer: http://127.0.0.1:{port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
