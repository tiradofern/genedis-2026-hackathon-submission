"""Analysis package scaffold; analysis methods are not yet implemented."""
__version__ = "0.1.0"
