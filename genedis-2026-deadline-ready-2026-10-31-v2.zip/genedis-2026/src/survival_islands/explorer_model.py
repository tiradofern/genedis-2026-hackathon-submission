"""Outcome-blind preparation helpers for the first local research explorer."""
from __future__ import annotations

import hashlib
import math

import numpy as np
from scipy.cluster.hierarchy import fcluster, linkage
from scipy.spatial.distance import squareform


def participant_split(identifiers, seed, fraction=0.7):
    if len(set(identifiers)) != len(identifiers):
        raise ValueError("Repeated participant in discovery input")
    order = sorted(range(len(identifiers)), key=lambda i: hashlib.sha256(
        f"{seed}:{identifiers[i]}".encode()).hexdigest())
    count = math.floor(len(order) * fraction)
    return np.array(order[:count], dtype=int), np.array(order[count:], dtype=int)


def fit_features(values, train, gene_ids, settings, cap):
    """All learned choices use training rows; matrix is samples by genes, raw RSEM."""
    if np.any(np.isfinite(values) & (values < 0)):
        raise ValueError("Negative RSEM value")
    logged = np.log2(values + 1)
    training = logged[train]
    missing = np.mean(~np.isfinite(training), axis=0)
    positive = np.mean(training > 0, axis=0)
    median = np.nanmedian(training, axis=0)
    mad = np.nanmedian(np.abs(training - median), axis=0)
    eligible = np.flatnonzero((missing <= settings["maximum_missing_fraction_per_gene"]) &
        (positive >= settings["minimum_fraction_expression_above_zero"]) &
        np.isfinite(mad) & (mad > settings["minimum_training_mad"]))
    ranked = sorted(eligible, key=lambda i: (-mad[i], str(gene_ids[i])))[:cap]
    selected = np.array(ranked, dtype=int)
    if len(selected) < settings["minimum_module_genes"]:
        raise ValueError("Too few eligible genes for the configured exploration")
    impute = median[selected]
    selected_values = logged[:, selected]
    selected_values = np.where(np.isfinite(selected_values), selected_values, impute)
    center = selected_values[train].mean(axis=0)
    scale = selected_values[train].std(axis=0, ddof=1)
    if np.any(scale <= 0):
        raise ValueError("Constant training feature survived filtering")
    normalized = (selected_values - center) / scale
    return dict(selected=selected, eligible_count=len(eligible), impute=impute,
                center=center, scale=scale, normalized=normalized, logged=logged)


def project(values, transform):
    logged = np.log2(values + 1)
    x = logged[:, transform["selected"]]
    x = np.where(np.isfinite(x), x, transform["impute"])
    return (x - transform["center"]) / transform["scale"]


def fit_components(training, count):
    # Gram eigendecomposition avoids a very wide full-matrix SVD.
    eigenvalues, vectors = np.linalg.eigh(training @ training.T)
    order = np.argsort(eigenvalues)[::-1][:count]
    positive = np.maximum(eigenvalues[order], 0)
    loadings = training.T @ vectors[:, order]
    loadings /= np.sqrt(np.maximum(positive, 1e-12))
    for column in range(loadings.shape[1]):
        largest = np.argmax(np.abs(loadings[:, column]))
        if loadings[largest, column] < 0:
            loadings[:, column] *= -1
    explained = positive / max(float(np.sum(np.maximum(eigenvalues, 0))), 1e-12)
    return loadings, explained


def provisional_modules(normalized, train, build, criteria, gene_ids=None):
    training = normalized[train]
    correlation = np.clip(training.T @ training / (len(train) - 1), -1, 1)
    distance = 1 - ((1 + correlation) / 2) ** build["signed_network_power"]
    distance = (distance + distance.T) / 2
    np.fill_diagonal(distance, 0)
    hierarchy = linkage(squareform(distance, checks=False), method="average")
    labels = fcluster(hierarchy, t=build["module_distance_cut"], criterion="distance")
    result = []
    for label in sorted(set(labels)):
        indices = np.flatnonzero(labels == label)
        if len(indices) < criteria["minimum_module_genes"]:
            continue
        x = training[:, indices]
        weights, explained = fit_components(x, 1)
        weights = weights[:, 0]
        training_score = x @ weights
        orientation = np.dot(training_score, x.mean(axis=1))
        if orientation == 0:
            identities = gene_ids if gene_ids is not None else [str(i) for i in range(normalized.shape[1])]
            first = next(i for i in sorted(range(len(indices)), key=lambda i: identities[indices[i]]) if weights[i] != 0)
            orientation = weights[first]
        if orientation < 0:
            weights *= -1
            training_score *= -1
        score_scale = max(float(training_score.std(ddof=1)), 1e-12)
        scores = normalized[:, indices] @ weights / score_scale
        membership = x.T @ (training_score / score_scale) / (len(train) - 1)
        coordinated = float(np.mean(membership >= 0.5))
        passes = bool(explained[0] >= criteria["minimum_training_pc1_variance_fraction"] and
                      coordinated >= criteria["minimum_fraction_genes_with_positive_score_correlation_at_least_0_5"])
        result.append(dict(indices=indices, weights=weights, scores=scores, score_scale=score_scale,
                           pc1_variance=float(explained[0]), coordinated_fraction=coordinated,
                           coordination_pass=passes, broad=len(indices) > criteria["maximum_default_module_genes"],
                           high_threshold=float(np.quantile(scores[train], 0.75))))
    result.sort(key=lambda m: (not m["coordination_pass"], m["broad"], -m["pc1_variance"], -len(m["indices"])))
    return result


def descriptive_comparison(samples, scores, group_a, group_b):
    known = {sample["id"] for sample in samples}
    a, b = set(group_a), set(group_b)
    if not a.issubset(known) or not b.issubset(known):
        raise ValueError("Comparison contains specimens outside this cohort")
    overlap = a & b
    a, b = a - overlap, b - overlap
    index = {sample["id"]: i for i, sample in enumerate(samples)}
    def describe(ids, values):
        numbers = [values[index[sid]] for sid in sorted(ids) if values[index[sid]] is not None]
        return dict(n=len(numbers), mean=float(np.mean(numbers)) if numbers else None,
                    median=float(np.median(numbers)) if numbers else None)
    rows = []
    for key, values in scores.items():
        left, right = describe(a, values), describe(b, values)
        rows.append(dict(id=key, a=left, b=right, difference=left["mean"] - right["mean"]
                        if left["mean"] is not None and right["mean"] is not None else None))
    return dict(a_count=len(a), b_count=len(b), overlap_count=len(overlap),
                excluded_overlap=sorted(overlap), programs=rows,
                interpretation="Descriptive comparison only; no hypothesis test or survival-tier promotion")
