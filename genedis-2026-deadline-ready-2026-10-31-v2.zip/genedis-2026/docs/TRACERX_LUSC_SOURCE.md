# Separate TRACERx squamous source audit

The investigator selected **adenocarcinoma and squamous analyses separately**. This extension prepares an independent LUSC cohort from the same public processed TRACERx release. It does not pool the histologies, alter the frozen LUAD analysis, or reconstruct new patient trees from raw sequencing. The shared source terms, original publication and mapping definitions are detailed in [TRACERX_ROUTE_SOURCE.md](TRACERX_ROUTE_SOURCE.md).

## Source and independent cohort

The deposited material accompanies Karasaki et al., *Evolutionary characterization of lung adenocarcinoma morphology in TRACERx*, *Nature Medicine* (2023), [DOI 10.1038/s41591-023-02230-w](https://doi.org/10.1038/s41591-023-02230-w). Its [Zenodo record 7683605](https://zenodo.org/records/7683605) also contains processed LUSC phylogenetic objects and curated mutation annotations. The data remain restricted to academic non-commercial use. The raw and derived patient-level files stay local and excluded from Git; no controlled EGA payloads were retrieved.

The source is the same pinned tree file, SHA256 `7111c189edfc104eccff83c0b871d25ed3c0ecba9db64a04e1147cc963d9c02b`, and mutation table, SHA256 `8bd22ad71613aaa65e12d875561d5669824499282e09c4e9fa8f77df882ae063`. The unchanged `extract_sources.R` translation already covers all 403 deposited tumours from 394 patients. This extension reuses and verifies those native translation bytes rather than modifying the R translator or any LUAD output.

Of the 129 deposited LUSC tumours, four belong to patients with multiple deposited tumours across any histology and are excluded by the same independence rule as LUAD. All remaining **125 independent single-tumour patients** have at least two distinct primary `R` regions. Surgery lymph nodes remain in the full source trees but do not qualify the primary-region gate. No mutation, outcome or evaluation result chooses among multiple primaries.

| Distinct primary R regions | Patients |
|---:|---:|
| 2 | 36 |
| 3 | 30 |
| 4 | 32 |
| 5 | 11 |
| 6 | 6 |
| 7 | 6 |
| 8 | 4 |

The metadata-only readiness record, `tracerx_routes/source/lusc_cohort_readiness.json`, was written before LUSC candidate-gene frequencies or gene-pair ordering results were inspected. Configuration `configs/tracerx_routes_lusc_v0_1.json`, SHA256 `27a8f619cb39f8a807c569eee4f0a374c80af6bd061572cdda00bf7e530f30b8`, then froze the eligibility rules, ten literature candidates, training-only event gate and **88 training / 37 evaluation** allocation. Allocation uses the same approximately 70% training convention as LUAD, with nearest-integer half-up rounding. The LUSC-specific SHA256 salt defines the participant roles. The source exporter itself does not select genes or fit a model.

## Driver mapping and topology resolution

Only source `DriverMut == TRUE` mutation rows contribute reported gene presence. The exact full key contains tumour, chromosome with only a literal `chr` prefix removed, position, reference and alternate alleles. Its unique embedded PyClone cluster must agree with the mutation table's corrected cluster and remain in the corrected tree. Gene names and short mutation identifiers cannot substitute for that join.

Across the 125 eligible patients, the 801 source-curated driver mutation records, covering all source genes before candidate selection, have these placement states:

| Source placement | Variants | Use |
|---|---:|---|
| Exact retained mapping | 708 | May contribute order if all same-gene variants share this one cluster |
| Source cluster removed from the corrected tree | 21 | Presence retained; order unresolved |
| Full variant absent from embedded mapping | 72 | Presence retained; order unresolved |

All 708 retained and 21 removed mappings have source `cleanCluster_SC == TRUE`. Among the 72 absent mappings, 43 have FALSE and 29 have a missing flag. No new filtering rule is derived from this flag. A zero remains absence of a reported curated mutation, rather than verified wild type, assay callability or lack of CNA, methylation, structural or other mechanisms.

The frozen literature alias `MLL2 -> KMT2D` is applied only to the separate LUSC export. Every LUSC driver preserves its literal `raw_source_gene`; its variant key and cluster mapping are unchanged. Gene-level events and branch annotations use the canonical symbol consistently. No additional alias guessing or functional equivalence is introduced. The default LUAD mapping behavior and frozen LUAD source bytes are preserved.

All 403 source trees again pass complete rooted-node coverage, single-parent and acyclicity checks across every deposited alternative, exact agreement with both source consensus fields, and membership of the authors' corrected representative among the alternatives. In the LUSC cohort, **21 patients have one deposited topology and 104 have multiple**. A strict ancestry vote requires unanimity across all alternatives. Same-cluster order, separate branches, topology disagreement, repeated genes across clusters and failed/removed mappings remain distinct unresolved states. Alternatives and regions never become independent patients.

Two eligible LUSC trees use the exact published single-cluster `1:1` sentinel. They become one retained node with zero intercluster edges only when corrected topology, every alternative, trunk, consensus fields and named SNV-count fields all match that exact signature. The literal fields remain in the patient export. This supplies no within-cluster order and does not repair arbitrary self-loops.

## Isolated outputs and frozen evidence

The LUSC source-derived population input is `tracerx_routes/source/output/lusc/cohort_trees.json`, SHA256 **`fd1d582ab768b8938ee21a9aeeb9d9e0be243f960f47d5967348ba1321349bb9`**. The aggregate mapping/structural audit is `tracerx_routes/source/lusc_source_audit.json`, SHA256 `e9be6fdacadc1abcc14670e83a8906c5a11c10d1e230d93ff654102342e457e8`. `lusc_cohort_export_lock.json` records those hashes and exact frozen configuration, source-manifest and auditor bytes.

Before population fitting, byte-for-byte snapshots of configuration, manifest, source audit, cohort input and Python auditor were saved in ignored `source/output/lusc/at_freeze/`. The 125 source patient display exports are in `source/output/lusc/patient_trees/`. They preserve the authors' corrected representative topology, cluster IDs, source SNV-count lengths, specimen labels, curated driver annotations, alternative-edge counts and CCF values. An explicit display origin is only an aid to expose the source root stem; it is not a biological normal ancestor. The displayed representative cannot substitute for unanimous source ancestry in population evidence.

The source morphology table is LUAD-specific. Missing LUSC regional morphology is left unknown; no adenocarcinoma pattern is transferred to a squamous clone. Per-patient neoadjuvant status is not supplied in the inspected tables and is not imputed from the separate adjuvant-treatment field. The same-surgery source context is preserved.

The original LUAD population input remains SHA256 `33f80810a7fb7f025d3c93371760c245a9e9a797534af9235b51f0c2471c02c2`; its configuration, source audit, original translation and native patient datasets remain independent. Distinct histology-specific candidate universes and held-out sets do not support a formal between-histology route-difference claim.

## Reproduction and source checks

Reproduce the shared pinned inputs and unchanged native translation as documented in `TRACERX_ROUTE_SOURCE.md`, then run:

```powershell
python tracerx_routes/audit_sources.py --config configs/tracerx_routes_lusc_v0_1.json --output tracerx_routes/source/output/lusc --audit-output tracerx_routes/source/lusc_source_audit.json
python -m unittest discover -s tracerx_routes/source -p 'test*source*.py' -v
```

The auditor requires explicit separate output and aggregate-audit paths for LUSC and refuses the original LUAD output/audit locations. It checks raw source checksums, native translator input MD5s and the frozen participant count. It does not write into the shared native translation. Four new source tests cover cohort path isolation, the minimum primary-region gate, alias/source-symbol preservation and actual LUSC independence, depth, histology, disjointness from LUAD and locked input hash. All **12 source tests** passed, including the original eight LUAD/source contracts. These are implementation and source-fidelity checks, not biological validation of patient ancestry or a common route.

A separate read-only review, recorded in `tracerx_routes/source/lusc_model_review.json`, independently re-read all 125 native source translations. It rederived every alternative's strict/possible ancestor closure, exact curated-variant placements and gene-symbol mapping, patient event/unique-placement sets, strict order matrices, the 88/37 roles, the training-only ten-candidate to five-event gate, every pair category and denominator, all 20 directional statistics and P-value/BH arithmetic, full selected parent sets, and held-out joint/marginal scores. The official saved RDS contains exactly the 88 training event rows and 88 matching patient temporal matrices, excludes all 37 evaluation patients, and preserves the original numeric event indices for all three exported selected edges. The final reviewed model SHA256 is `2cb08b9ac6a022cf5e3b0280c1e4c3f0b78d7a8b7150d6b14191c20ba886a1c2`. No blocking implementation discrepancy was found. The source supplies 25 KMT2D driver variants under its existing canonical symbol and zero under MLL2; the explicit historical alias does not create additional variants.
