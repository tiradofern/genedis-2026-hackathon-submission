# GeNeDis 2026 — Pan-Cancer Molecular Survival Islands

> **Latest operative decisions, October 31:** retain malignant-cell program discovery across at least two qualifying non-NSCLC cancers, followed by independent NSCLC testing under a justified comparable therapy family. The PI approved restricted protein measurements for the NSCLC step. Primary discovery requires treatment-specific acquired-resistance support; uncertain cases remain separately labelled exploratory and do not fill the discovery-cohort gate. See [current clinical eligibility](../pilot/cellular_2026-10-31/CLINICAL_ELIGIBILITY.md), [implementation/readiness](../pilot/cellular_2026-10-31/README.md) and [current status](CURRENT_STATUS.md). Execution is authorized within those boundaries; no real program effects or molecular candidates have been generated. The earlier paired-only and automatic-fallback framing below is preserved history, not the current scientific scope.

> Historical planning/review record preserved from commit `92408ee`. The subsequent investigator authorization permits the October31 bounded release work. Current execution protocol and QC decision: `pilot/PROTOCOL_2026-10-31.md` and `pilot/cohorts/FEASIBILITY_REPORT_2026-10-31.md`; both cohorts failed inference readiness and no paired effects were tested. See `submission/REVIEWER_README.md` for the current deliverable.

## Revised research and implementation plan

## October 31 immediate scope update — tonight's proposed paired test

> **Do predefined molecular programs show recurring changes between pretreatment and acquired-resistance biopsies in two independently collected cancer cohorts?**

Read [Tonight's proposed paired-program protocol](TONIGHT_PAIRED_PROGRAM_PLAN_2026-10-31.md) first. It makes pairing, acquired-resistance phenotype, biopsy site and processing binding readiness gates; proposes a small published six-Hallmark family; and specifies patient-level paired effects, uncertainty and complete directional replication testing.

The broader numbered plan below remains the **longer-term recurrence-first roadmap**. Its primary unpaired resistant-state endpoint, 25 legacy program family, structural coordination statistic and C=0.10 proposal are not tonight's primary analysis. The two scopes must not be mixed.

If the paired-data gate fails, tonight's output is descriptive/feasibility evidence or the existing NSCLC reproducibility/prototype assessment—not an inferential convergence claim. The original proposal remains in [commit 3140da6](https://github.com/tiradofern/genedis-survival-islands/blob/3140da6ef617af873d6413a329d1abaa73913d48/docs/PAN_CANCER_MSI_RESEARCH_PLAN_2026-10-30.md).

This is a documentation update only. The endpoint is investigator-recommended; numerical/method defaults remain proposed and implementation remains pending explicit approval.

**Revision:** October 31, 2026. This replaces the October 30 plan on this review branch; the earlier text remains in [commit 1167e2f](https://github.com/tiradofern/genedis-survival-islands/blob/1167e2fe22e30ba33e57b7f2b32e4f7b351ddf3e/docs/PAN_CANCER_MSI_RESEARCH_PLAN_2026-10-30.md).

**Scientific direction confirmed by the investigator:** recurrence among documented resistant tumors is the primary discovery objective. Resistance-specific enrichment and functional contribution are separate evidence levels.

**Approval boundary:** this revision updates research documents only. Cohort adoption, numerical defaults, statistical procedures and implementation remain proposals for scientific review. No new dataset acquisition, bioinformatics analysis, source-code change, merge or submission is authorized by publication of this plan.

Read the companion [revised adversarial review](../reviews/PAN_CANCER_MSI_ADVERSARIAL_REVIEW_2026-10-31.md).

## 1. Executive summary

The primary discovery question is:

> **Do independently collected tumors with documented treatment resistance share recurrent genomic features or coordinated molecular programs across different cancer types and therapeutic exposures?**

The study searches for candidate conserved features among resistant tumors. Missing responder cohorts do not invalidate recurrence discovery. They limit testing whether a finding is specifically enriched in resistance.

The most immediately feasible extension is a fixed-program transcriptomic recurrence study using human melanoma and NSCLC resistance cohorts. Genomic, retained-region and directly measured regulatory-state conclusions remain conditional on the necessary measurements and specimen crosswalks.

Use one eligible resistant specimen per independent patient. Source inventories potentially provide up to 19 melanoma patients and 29 NSCLC patients, subject to clinical and technical eligibility. The 18 baseline-bearing melanoma patients and 13 NSCLC pairs support separate temporal analyses; they do not define the primary recurrence denominator.

Preserve the implemented 988-case NSCLC multi-omics explorer, 25 provisional programs, frozen patient roles, evolutionary analyses, failed validation gates and negative results. These provide hypotheses and infrastructure, without becoming resistant-tumor observations by association with this extension.

## 2. Scientific rationale and three evidence levels

Independent tumors may reach clinically resistant states while sharing individual alterations, regulatory features or distributed molecular programs. Their recurrence nominates candidates for conserved survival adaptations. It does not establish selective origin, resistance specificity or causality.

| Evidence level | Question | Required evidence |
|---|---|---|
| **1. Recurrence among resistant tumors** | Does the same defined feature or coordinated program recur across independent resistant patients and cohorts? | Documented resistant specimens, reliable measurements, patient independence, explicit recurrence tests and relevant backgrounds |
| **2. Resistance-associated enrichment** | Is the feature more frequent or active than in appropriate non-resistant comparators? | Independently defined clinical labels, comparable treatment/exposure and sampling, confounding assessment |
| **3. Functional contribution** | Does the feature or coordinated program contribute to resistance? | Relevant perturbation evidence, treatment-dependent effects and appropriate controls; rescue or complementary evidence where feasible |

Within Level 1, distinguish:

- **Observed recurrence:** repeated reliable measurement.
- **Background-adjusted recurrence:** recurrence or coordination exceeds an explicitly specified molecular or ordinary-cancer background.

A feature may genuinely recur while remaining compatible with ordinary cancer biology. Keep that observation; do not portray it as evidence that therapy selected the feature.

These evidence levels supplement the existing computational statuses and investigator-defined biological Tiers I–III. Level 1 does not automatically confer Tier II. Tier III requires the agreed reproducibility evidence, and Tier I requires specific functional support.

Paired bulk specimens generally cannot distinguish selection of an undetected pre-existing population from induced adaptation. That distinction requires additional temporal, clonal or experimental evidence.

## 3. Novelty and relationship to existing work

The study does not claim to originate shared cancer-cell states, drug tolerance, resistance programs or the microbial analogy. Relevant benchmarks include [Gavish et al., 2023](https://www.nature.com/articles/s41586-023-06130-4), [Hugo et al., 2015](https://pubmed.ncbi.nlm.nih.gov/26359985/), [Ruoff et al., 2025](https://www.oaepublish.com/articles/cdr.2025.112) and [Keddar et al., 2026](https://pubmed.ncbi.nlm.nih.gov/42156138/).

Freeze published benchmark definitions and reference versions before discovery. Report findings as replication, contextual extension, network refinement or new biology as supported.

**Novelty is not an entry criterion for Level 1.** Reproduction of a known coordinated program can be a successful result. A familiar lineage, immune, stromal or proliferation program must not be discarded merely because it is known; its interpretation and contribution to resistance remain separate.

Use “MSI program” to distinguish this research concept from microsatellite instability. The functional analogy does not imply genomic contiguity, horizontal transfer or demonstrated evolutionary homology.

## 4. Verified existing project inventory and preservation

The repository's default branch is a preserved October 15 audit baseline. Later development branches contain the implemented project. A cumulative scientific snapshot is [analysis/normal-reference-first at a4edb2b](https://github.com/tiradofern/genedis-survival-islands/tree/a4edb2ba85daef38f38b4d9a3c4cbaa1516df0b9); the [explorer implementation snapshot](https://github.com/tiradofern/genedis-survival-islands/tree/e4352f4662193deeda13cd26997db3949f576d67) is a separate bounded reference. The documentation branch is not itself a merged runnable release.

| Component | Verified repository record | Boundary |
|---|---|---|
| NSCLC core | 507 LUAD + 481 LUSC primary tumors, one per participant; RNA/CNA/mutation-profile intersection at tumor-sample keys | Cross-sectional TCGA, not documented longitudinal resistance |
| Frozen roles | LUAD 354 training / 153 evaluation; LUSC 336 / 145 | Internal evaluation; upstream normalization may have used broader cohorts |
| Programs | 14 LUAD + 11 LUSC; 22–225 and 24–206 genes | Provisional and untiered |
| Fitting | Training-only 2,000-gene MAD selection, signed weighted correlation power 6, average linkage cut 0.92, then frozen oriented PC1 scores | Not simply 25 leading cohort PCs |
| Supporting measurements | ABSOLUTE purity 497/476; RPPA 355/313; slide-record links for all 988 | RPPA is not IHC; identical molecular aliquot/section is not established |
| Application | Linked molecular views, filters, gene/program inspection, descriptive comparisons and exports | Research explorer without established clinical validity |
| Validation | Training coordination screens passed; resampling, preservation, composition and clinical validation remain pending | Software checks do not validate biological conclusions |

Source: [dated preparation report](https://github.com/tiradofern/genedis-survival-islands/blob/a4edb2ba85daef38f38b4d9a3c4cbaa1516df0b9/results/reports/explorer_preparation_2026-10-17.json).

Preserve the completed TCGA/TRACERx event-route work and its negative findings. The TRACERx branches reuse 217 LUAD and 125 LUSC patients; they are not independent replication cohorts or verified treatment-longitudinal cohorts. No reliable shared evolutionary route was established by the recorded mutation/CNA tests.

Preserve the GTEx/HLCA normal-reference work, including the failed HLCA rejection gate and the absence of validated tumor projection. These results neither validate nor disprove distributed-program recurrence.

Complete matrices and full program definitions are principally ignored local artifacts. Recover them or reconstruct them from pinned sources only after implementation approval. If regeneration materially changes memberships/loadings, version a new specification rather than calling it the unchanged historical 25 programs.

The branch-aware inventory and existing test/CI records were inspected read-only. No biological analyses or tests were rerun for this revision.

## 5. Operational definition of “conserved”

“Conserved” means operational recurrence across the tested patients and contexts. It does not imply universal conservation, evolutionary selection or causal necessity.

| Feature class | Operational meaning | Required measurement | Current support |
|---|---|---|---|
| Exact somatic variant | Same normalized genomic alteration in independent patients | DNA calls, common build, callable loci and reliable somatic classification | Gated; resistant expression alone is insufficient |
| Gene-level alteration | Different variants affect the same gene in a predefined functional class | Consequence annotation and gene-specific coverage | Gated pending usable DNA and specimen links |
| CNA | Same predefined focal/arm gain, loss, amplification, deletion or LOH state | Segmented DNA, purity/ploidy; allele-specific data for LOH | TCGA/TRACERx context exists, but is not resistant-cohort replication |
| Retained region | Predefined, reliably measured copy/allelic state in resistant tumors | Appropriate DNA coverage and copy/allelic measurements | Not established in selected resistant expression cohorts |
| Persistence through treatment | Specified genomic feature remains detectable from baseline to resistance | Paired DNA with comparable sensitivity | Requires additional matched measurements |
| Measured regulatory state | Recurrent methylation, accessibility or chromatin pattern | Suitable epigenomic assay | Melanoma methylation is a conditional extension |
| Inferred regulator activity | Similar predefined target-gene activity | RNA plus fixed regulon/scoring | Feasible, labelled inferred |
| Distributed program | Fixed multigene structure is reproducibly coordinated across resistant patients/cohorts | Covered expression and independent coordination testing | Most immediately feasible |
| Different genomic routes to one program | Distinct measured genomic configurations accompany the same program in corresponding tumors | Matched DNA–RNA and predefined configurations | Later gated hypothesis |

Most genomic regions are present in most tumors. Missing deletion reports do not establish selective retention. “Present at resistance,” “persisted through treatment” and “retained more than expected” are distinct claims.

For discrete features, a proposed minimum reportable recurrence is at least two independent patients in each of two contexts, with assayed denominators and confidence intervals. This is not a significance or biological-importance threshold.

For continuous programs, distinguish cohort-level structural recurrence from specimen-level prevalence, activation or suppression. Each needs its own operational measurement.

## 6. Cohort suitability and source verification

The initial recommendation is two human resistant-state cohorts. A clean third cancer cohort is not yet verified. All counts are upper source inventories before eligibility/QC, not guaranteed analytical denominators.

| Cohort | Verified source structure | Revised role |
|---|---|---|
| **GSE65185 melanoma** | 62 clinical biopsies from 19 patient IDs plus 8 cell-line entries; 18 have genuine pretreatment baselines; resistant biopsies document BRAFi or BRAFi/MEKi exposure | Up to 19 independent resistant patients for primary recurrence; paired subset for secondary temporal analysis |
| **GSE248249 NSCLC** | 29 post-treatment specimens from 29 patients plus 13 pretreatment profiles; post-treatment lesions sampled after radiographic progression | Up to 29 study-defined resistant patients, with response subclasses preserved; 13 pairs for temporal analysis |
| **GSE111563 / related endocrine cohorts** | Extended letrozole study includes acquired-resistance labels, related accessions and some expression-assisted classification | Conditional third cancer; require independent clinical resistance labels and deduplication |
| GSE59515 breast | 25 scheduled pretreatment/two-week/three-month triplets | Exposure/response context; not automatically resistant |
| GSE165019 NSCLC | 8 baseline/early rebiopsy pairs, heterogeneous actual intervals | Early EGFR-treatment context, not resistance-state discovery |
| GSE295041 HGSOC | 24 primary/first-recurrence RNA pairs | Recurrence context until individual treatment failure is verified |
| GSE207422 bulk NSCLC | 24 pretreatment profiles; later 9 MPR / 15 NMPR | Baseline response comparison, not resistant-state sampling |

Primary records: [GSE65185](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE65185), [Hugo publication](https://pubmed.ncbi.nlm.nih.gov/26359985/); [GSE248249](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE248249), [Memon publication](https://pmc.ncbi.nlm.nih.gov/articles/PMC11249385/); [GSE111563](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE111563), [Selli publication](https://pmc.ncbi.nlm.nih.gov/articles/PMC6323855/); [GSE59515](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE59515), [GSE165019](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE165019), [GSE295041](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE295041), [GSE207422](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE207422).

**Correction to the previous NSCLC summary:** Memon's molecular cohort includes a stable-disease subgroup; the paper reports best overall CR/PR in 22 of 29 molecular patients. That publication-level figure is not an already reconciled strict-AR specimen crosswalk. Preserve study-defined resistance, best overall response and lesion-level rebound/de novo progression separately. Do not silently classify all 29 as identical PR/CR-based acquired resistance, or label SD cases primary resistant by assumption.

**Melanoma Patient 21:** an already resistant surrogate reference is not an untreated baseline. A genuinely documented resistant specimen can nevertheless enter resistant-state recurrence under a frozen index-treatment rule.

**Same-site NSCLC pairs:** four same-site pairs limit temporal inference; they do not restrict primary resistant-state recurrence to four patients.

Public processed expression is accessible for the two proposed core cohorts. File-specific reuse/redistribution terms remain to be documented. Memon matched WES is controlled; melanoma methylation/other genomic sources require modality-specific specimen audit. No new controlled-access approval is assumed.

## 7. Patient units, resistance definitions and experimental design

Primary unit: one eligible resistant tumor specimen per independent patient. A pretreatment pair is not required.

Before molecular inspection, freeze a manifest containing patient/specimen/study IDs, cancer/subtype, index regimen and line, source resistance definition, best response, progression and sampling dates, subsequent treatment, biopsy site, assay/units, clinical evidence source, independence status and exclusion reasons.

Keep separate:

- Acquired resistance with documented initial benefit followed by progression.
- Primary resistance using an explicit source-appropriate clinical definition.
- Other documented treatment failure with subclass unresolved.
- Scheduled on-treatment sampling.
- Pretreatment sampling and later recurrence without verified treatment failure.

The initial resistant-state question can include documented treatment failure while retaining those distinctions. Report strict-AR and other source-defined subgroups separately where the clinical crosswalk permits. A newly found primary-resistance cohort requires a separately declared stratum; it is not silently pooled with acquired resistance.

Select the first eligible documented resistant specimen on the chosen index regimen before a new systemic treatment. Resolve multiple lesions/ties using a prespecified clinical/QC rule rather than molecular results. Preserve alternative specimens for patient-blocked sensitivity. Ambiguous index therapy or chronology makes that specimen ineligible for the corresponding core contrast.

Exclude cell lines from clinical analysis and deduplicate related accessions. Source titles/GSM identifiers alone do not establish clinical eligibility or independent replication.

The first fixed-program pilot uses externally defined hypotheses in both resistant cohorts. New de novo programs require a separate discovery cohort, frozen definitions and independent replication.

## 8. Background and comparator models

Different cancers and therapies do not eliminate shared background biology.

| Background | Required handling |
|---|---|
| Ordinary cancer alterations | Account for lineage, stage, common driver frequencies and cohort-enrolling genotypes; an entry requirement cannot be claimed as unexpectedly recurrent |
| Inherited variation | Prefer matched-normal DNA; keep uncertain tumor-only calls separate; population filtering does not remove all germline uncertainty |
| Mutation opportunity | Callable sequence, depth/sensitivity, gene length, context/local rate, patient burden and mutational signatures |
| CNA opportunity | Separate focal/arm events, gain/loss, WGD/relative gain and LOH/deletion; preserve event blocks and missingness |
| Genomic retention | Model expected non-deletion or persistence, rather than treating unchanged regions as exceptional |
| Gene/pathway size | Measured universe, set size and gene overlap |
| Tissue lineage | Ordinary-cancer and normal-cell references; label lineage-compatible recurrence |
| Composition | Immune/stromal/malignant contributions; retain mixed or unresolved compartment labels |
| Technical artifacts | Platform, batch, preservation/RNA quality, probe mapping and detection limits |
| Program/network structure | Published programs, baseline coexpression and network degree where topology is tested |

[MutSigCV](https://pubmed.ncbi.nlm.nih.gov/23770567/), [dNdScv](https://www.sanger.ac.uk/tool/dndscv/) and [GISTIC2](https://pubmed.ncbi.nlm.nih.gov/21527027/) illustrate mutation-opportunity and CNA-background principles. They do not establish resistance specificity. Small cohorts may need externally estimated backgrounds or descriptive reporting.

Keep three comparator roles distinct:

1. **Molecular null:** could measurement opportunity or chance produce the observation?
2. **Ordinary-cancer reference:** is recurrence unusual relative to comparable cancer biology?
3. **Clinically non-resistant comparator:** is the feature enriched specifically in resistance?

TCGA can inform ordinary-cancer context; it must not be labelled non-resistant without clinical evidence. Paired pretreatment samples support temporal change, not a claim that the patient is a durable responder.

Known lineage/TME/stress/proliferation programs remain eligible. Composition-explained recurrence can be an ecosystem feature; it does not become a tumor-cell-intrinsic adaptation.

## 9. Harmonization and measurement gates

Preserve existing Entrez-keyed definitions and build versioned crosswalks retaining source symbols/builds/annotations. Record ambiguous, repeated, unmapped and excluded features.

Complete array annotation and outcome-independent gene aggregation. Use count models only for genuine counts; RSEM, FPKM, TPM, log-TPM and array intensities require their own handling. Do not apply cross-cancer ComBat as a universal correction or infer confirmed batches from filenames.

For the primary structural test, calculate within-cohort gene relationships rather than directly comparing raw expression across platforms.

Proposed coverage gates per fixed program:

- At least 80% of member genes.
- At least 80% of absolute loading mass.
- At least 20 measured genes.
- The same eligible gene subset in both cohorts for the conjunction hypothesis.
- No imputation of unmeasured genes or favorable refitting.

These are proposed research defaults, not validated biological standards. Freeze them before resistant-cohort testing.

Original PC1 scores remain valid only for compatible measurements. A rank-based transported activity score is a distinct measurement model. Its formula, universe, ties, missing-gene handling and acceptance criteria must be frozen before external testing. Agreement with PC1 in TCGA training data assesses representation consistency, not proven cross-platform equivalence.

Unknown clinical/assay states remain unknown. No missing variant is converted to wild type. Failed coverage/transport means “not reliably measurable,” not a search for a more favorable score.

## 10. Molecular Survival Island discovery and separate recurrence tests

MSIs need not be physically contiguous. Different genomic configurations may support the same distributed program, but that genomic-route claim needs matched measurements.

### Gene and pathway levels

For genuine DNA inputs, test exact variants and predefined functional alteration classes separately. For RNA, report recurrent expression/regulon/pathway features as transcriptomic or inferred activity.

Use a frozen benchmark family of published signatures and pathways. Different genes mapping to a common function can motivate a functional-equivalence hypothesis; broad pathway annotation alone is not evidence of coordinated MSI structure.

### Primary fixed-program family

Test the complete 25 legacy programs as externally specified hypotheses. Their existing training screens do not establish external recurrence. Preserve historical size/PC1/correlation/stability settings rather than silently replacing them.

Proposed within-cohort statistic:

> Weighted mean signed **off-diagonal** Spearman correlation among measured member genes across independent resistant patients.

For fixed weights w and cohort c:

C(p,c) = sum over g<h of [w_g w_h rho(g,h,c)] / sum over g<h of |w_g w_h|.

This is a cohort-level structural property. It does not estimate program prevalence or activation in each specimen and does not prove functional cooperation. Report patient-bootstrap intervals and patient-omission sensitivity.

### Calibrated within-cohort null

Provisionally use 10,000 frozen matched gene-set draws, retaining the observed patient-expression matrix and matching program size, weight distribution, coverage and expression/variance characteristics. Empirical tail probabilities use the finite-simulation correction (b+1)/(B+1).

Assess excess over ordinary-cancer coexpression separately using appropriate independent reference/baseline information. Do not match on the candidate's observed resistant-cohort coordination statistic.

Calibrate behavior under independent genes, shared technical factors, ordinary coordinated programs and overlapping modules. These are model-dependent matched-set P values, not exact treatment-randomization tests. Unresolved calibration makes the corresponding statistical claim inconclusive.

### Cross-cohort recurrence

Estimate cohort evidence independently for the **same frozen common-gene hypothesis**. For the two required cohorts:

p_rep = max(p_NSCLC, p_melanoma).

This conjunction prevents a single strong cohort driving a pooled claim. It is interpretable only if both input P values are valid and calibrated for the specified hypothesis.

**Proposed correction:** Benjamini–Yekutieli q <= 0.05 across the complete primary family of 25 replication hypotheses. This accommodates dependence among program tests; it cannot repair an invalid null. Historical multiplicity rules remain unchanged. Unmeasurable programs are recorded as unassessed, not biological failures.

### Separate activity and temporal analyses

Structural recurrence does not require identical activity polarity. Shared activation/suppression needs a defined reference or paired contrast.

The paired subsets support separate activity-change and co-change analyses. Joint patient sign flips can test appropriate mean-change hypotheses under stated assumptions; they do not supply a residual co-change coordination null.

## 11. Statistical decisions: success, failure and inconclusive findings

All numerical defaults below remain proposals requiring scientific review and pre-analysis calibration.

### Success

- **Observed discrete recurrence:** reliably measured predefined feature in at least two independent patients per required context, with denominators and confidence intervals.
- **Supported structural recurrence:** measurement gates pass; positive coordination is supported independently in both cohorts; the calibrated conjunction passes the complete-family correction; uncertainty and technical/background/compartment annotations are reported.
- **Background-excess recurrence:** additional evidence exceeds a declared ordinary-cancer/molecular background. This is stronger than observed recurrence and separate from Level 2.

A working relevance target is C = 0.10. It is not an accepted biological cutoff. Distinguish positive coordination from evidence that the true effect exceeds this target: a point estimate above 0.10 with an interval crossing 0.10 does not establish a minimum effect above 0.10.

Known-program replication can succeed. A familiar cancer-compatible program is not automatically a novel or selected adaptation.

### Failure to support a specified candidate

With adequate measurement and precision, the feature does not replicate, has incompatible structure, has bounds excluding the declared meaningful target, or is attributable to a demonstrated technical artifact. State exactly which criterion failed. A precise small positive effect can support weak structural recurrence while failing a stronger minimum-effect target.

### Inconclusive

Ambiguous resistance/timing, unrecoverable definitions, failed coverage/transport, inadequate calibration, unresolved technical interpretation, wide intervals or a missing required cohort prevent adjudication. An interval spanning the relevance target is inconclusive for that target.

A nonsignificant result with inadequate precision is not evidence of absence. Failure of a restricted catalogue does not reject all possible MSIs. If a required cohort fails feasibility, do not substitute scheduled-treatment specimens retrospectively.

### Analysis gates

Freeze clinical eligibility; feature definitions and source versions; measurement/QC rules; null calibration; complete testing families; effect/precision targets; and interpretation rules before analysis. Design-specific reference/simulation assessment replaces arbitrary claims that a given N is automatically adequate.

## 12. NSCLC integration and claim boundaries

Preserve all 988 participants, original roles and legacy programs. They provide external fixed hypotheses, ordinary-cancer genomic/RNA context and a separate reproducibility workstream.

Potential NSCLC analyses include frozen program assessment, purity/composition sensitivity, assay-aware DNA–RNA relationships and later audited clinical associations. Cross-sectional TCGA does not establish therapy-induced change or acquired resistance.

Match claims to measurements:

- RNA recurrence: “recurrent transcriptomic program.”
- RNA regulon scores: “recurrent inferred regulator activity.”
- DNA context from unrelated cohorts: “cross-cohort genomic context.”
- Direct DNA conservation, retained regions, epigenetic maintenance or different genomic routes: require the corresponding measured data and specimen links.

Keep the investigator's Tiers III/II/I and computational statuses separate from recurrence/enrichment/contribution levels. No automatic tier assignment is proposed.

## 13. Deliverables and bounded hackathon plan

Proposed outputs:

1. Cohort/eligibility map with resistant-state and paired denominators.
2. Complete fixed-program definitions and measurement coverage.
3. Separate coordination, cross-cohort recurrence and background results.
4. Genomic recurrence tables only for verified DNA inputs.
5. Secondary paired-change displays.
6. An evidence ledger separating recurrence, enrichment and functional support.
7. A reproducibility/sensitivity report including failures and negative findings.

Network displays distinguish measured coexpression, curated interactions and inferred evolutionary edges. A picture is not a coordination test.

**Plan A remains the existing NSCLC prototype/reproducibility workstream**, not a forced new pan-cancer discovery study. A future runnable release needs one immutable source reference, required input/artifact manifest, explicit entry command, complete program definitions and numerical equivalence rules.

If reconstruction cannot be demonstrated, describe the deliverable as a documented prototype/source-audit package with incomplete reproducibility assessment. Do not retain a verified-reproducibility claim after a failed replay.

The prior 12–18 person-hour estimate was conditional and unbenchmarked; it is not a verified schedule. Confirm exact cutoff/template and artifact readiness before committing to delivery. Preserve a submission buffer. This documentation update prepares or sends no submission.

## 14. Full roadmap, feasibility and time estimates

Proposed stages after explicit implementation approval:

| Stage | Completion criterion | Indicative active effort |
|---|---|---|
| Artifact/release feasibility | Frozen program definitions and one reproducible or explicitly failed reconstruction | 1–3 working days, dependent on artifact availability |
| Clinical specimen audit | Frozen resistant-state manifest, subclasses, index-regimen selection and independent-patient counts | 2–4 working days per core cohort |
| Mapping/assay QC | Reproducible gene mapping and technical/coverage gates | 2–5 working days |
| Null calibration and protocol freeze | Declared statistics, families, numerical gates and precision assessment | 1–2 weeks |
| Fixed-program recurrence study | Cohort effects, conjunction results and complete negative/unassessed findings | 1–2 weeks |
| Third cohort and Level 2 feasibility | Independent clinical labels and appropriate comparator/source terms | Access-dependent |
| Genomic/regulatory extension | Matched measured inputs, callability and suitable backgrounds | Access-dependent; not promised from RNA |
| Functional follow-up/manuscript | Program-specific evidence and complete reproducible report | Subsequent research phase |

These are planning estimates, not measured runtimes or guarantees. A 12–20-week overall research programme remains contingent on validated inputs and independent data; controlled access or experiments can extend it.

No new de novo network discovery is assumed feasible solely because n=19 or n=29 resistant patients exist. New module learning requires demonstrated stability and a separate discovery/replication design.

## 15. Revised adversarial assessment, risks and alternatives

| Earlier objection | Revised disposition |
|---|---|
| Missing responders blocks discovery | Withdraw for Level 1; retain limitation for Level 2 |
| Baseline pairs are required for recurrence | Withdraw |
| Four same-site pairs determine the entire NSCLC N | Withdraw for resistant-state recurrence; retain temporal limitation |
| One study per context invalidates recurrence | Narrow: report tested-context recurrence; generalization/confounding remain limited |
| A known program cannot qualify | Withdraw; novelty is separate |
| Composition-associated programs must be discarded | Narrow: retain ecosystem features without an intrinsic claim |
| RNA can substitute for DNA/regulatory measurements | Retain objection |
| Training screens/software tests validate biology | Retain objection |
| Coordination, transport, backgrounds and replication need fixed rules | Retain objection; revised proposed procedures address it |
| Artifact recovery and clean reconstruction need verification | Retain objection |

See the [companion revised adversarial review](../reviews/PAN_CANCER_MSI_ADVERSARIAL_REVIEW_2026-10-31.md) for the updated criticisms and interpretation boundaries.

Remaining risks include small independent N, uncertain clinical subclassification, biopsy selection, site/composition differences, batch/artifact effects, cross-platform measurement and missing genomic access. Unknown states remain unknown. Scheduled endocrine/early EGFR/ovarian-recurrence cohorts stay separate unless documented resistance is independently verified.

## 16. Investigator decisions and approval checkpoint

**Confirmed direction**

- Recurrence among documented resistant tumors is the primary discovery question.
- Enrichment relative to non-resistant comparators and functional contribution are separate evidence levels.
- Missing responders do not invalidate Level 1.
- Preserve the MSI hypothesis, existing work, negative findings and measurement-specific claims.
- The current authorization is documentation revision.

**Proposals still requiring scientific review**

- Core specimen eligibility/subclasses and final clinical crosswalks.
- Primary 25-program family and benchmark families.
- Coverage, coordination effect, null calibration, conjunction and multiplicity defaults.
- Exact genomic/regulatory feasibility and any third cohort.
- Computational/biological evidence-status assignments.
- Runnable release, code/data terms and any later submission.

**Intended conclusion if supported**

> We identified predefined molecular features or coordinated programs recurring across independently collected tumors with documented treatment resistance. These findings nominate candidate conserved survival adaptations within the tested contexts. Compatibility with ordinary cancer biology, resistance-specific enrichment, selective origin and functional contribution were evaluated separately or remain unresolved.

**STOP: publishing this revised plan does not authorize dataset acquisition, analysis, code implementation, merging or submission. Those actions remain pending explicit approval.**
