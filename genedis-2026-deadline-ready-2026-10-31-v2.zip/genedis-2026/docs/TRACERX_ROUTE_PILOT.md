# Multi-region TRACERx route pilot

The investigator requested a next analysis using multi-region TRACERx data to investigate common evolutionary routes across patients. This pilot adds source phylogenetic ordering evidence that the project's earlier cross-sectional TCGA pilot did not contain. It does not reconstruct new phylogenies from raw sequencing or establish more reliable biological conclusions merely by using more detailed data.

## What changes scientifically

| Earlier TCGA pilot | Multi-region TRACERx pilot |
| --- | --- |
| One binary gene-event profile per participant | Published within-patient mutation-cluster trees and authors-annotated driver placements |
| CAPRI prevalence-based priority assumptions | Strict within-patient ancestry supported across every deposited alternative topology |
| No measured mutation CCF or branch ordering input | Multiple sampled primary regions and source cluster topology, with uncertainty retained |
| Reported protein-altering gene events | Authors-annotated driver events in the same fixed literature candidate-gene set |

These are distinct data sources and event definitions. The new analysis is not a matched longitudinal extension of TCGA, and numerical performance is not compared as if the cohorts and assays were interchangeable. Patient ancestry remains separate from recurring gene-event order: tumors from unrelated patients never acquire an invented common clonal ancestor.

## Sources and independent participants

The processed source is the academic non-commercial TRACERx release associated with Karasaki et al., *Evolutionary characterization of lung adenocarcinoma morphology in TRACERx*, Nature Medicine 2023, [DOI 10.1038/s41591-023-02230-w](https://doi.org/10.1038/s41591-023-02230-w), [Zenodo 7683605](https://zenodo.org/records/7683605). Source terms, software licenses and the project's eventual release license remain separate. Patient-level downloads, derived exports and generated display datasets stay local and Git-ignored. No controlled-access sequencing payload is requested.

The deposit contains 403 tumour reconstructions: 229 source-labeled LUAD, 129 LUSC and 45 Other, from 394 patients. The operational first slice uses LUAD, matching the prior pilot; the investigator was offered a choice of LUAD first or separate LUAD/LUSC analyses before this analysis. Histologies are not pooled.

To preserve independence without choosing among multiple primaries, exclude all patients with more than one deposited tumour across any histology. This removes 12 LUAD tumours belonging to eight such patients. The remaining 217 independent LUAD cases each have at least two distinct primary R regions. Lymph-node samples do not qualify a patient for the primary-region gate. Where present, the full source same-surgery tree, including lymph-node samples, is retained and labelled; it is not described as a primary-only reconstruction. Per-patient neoadjuvant status is not imputed from absent metadata.

## Fixed analysis

`configs/tracerx_routes_v0_1.json` was frozen before candidate-event frequencies, ordered-pair results or model fits. Its SHA256 is `59cb7426bee696e76df9d75bd4e61a7a322231f4eb589a2b08726ca20e696cc5`. A new deterministic patient-level SHA256 split reserves 152 participants for training and 65 for evaluation. Region counts, alternative trees and multiple mutations do not become additional independent observations.

The candidate universe is the same 18 literature-defined LUAD genes used in the earlier pilot. A TRACERx event requires an authors-annotated driver mutation; this is not an independent functional validation. Training eligibility requires at least ten carriers and ten noncarriers. Evaluation data, outcomes, stage and RNA programs do not select events or settings. No reported source driver is not verified wild type or adequate locus-level callability.

The source mutation identifier does not include the alternative allele. Variant-to-cluster joins therefore require the full tumour, chromosome, position, reference and alternative allele, plus corrected-cluster agreement. Gene presence remains distinct from confident placement: a gene can be present but have unresolved order. Several curated variants in one retained cluster can be a single gene event; gene hits in different clusters, failed joins and removed clusters cannot be assigned an arbitrary first occurrence.

Only 82 of the 403 deposited tumours have one topology alternative; most have several, with up to 39,497. The primary ordering rule is deliberately conservative: strict ancestor direction must agree across every valid deposited alternative with complete retained-node coverage. Two drivers on the same cluster have unresolved internal order. Drivers on separate branches are incomparable. Disagreement among alternatives, repeated hits and unavailable placements remain explicit categories. One patient's contribution is at most one directed vote for a gene pair, regardless of the number of regions or alternatives.

Agreement across the deposited candidate trees is not a calibrated probability of true ancestry. The candidate set, clustering, copy-number correction, mutation ascertainment and sampled regions can all miss the true history. Source-derived strict ancestry can also span intervening clusters; it does not establish adjacent clones or the next mutation acquired.

## Population model and assessment

The population engine is the unchanged official ASCETIC 1.2.0 `asceticPhylogenies` implementation, pinned to its upstream commit, with AIC, hill climbing, zero restarts and seed 20261018. The [official vignette](https://danro9685.github.io/ASCETIC/articles/ASCETIC.html) describes its phylogeny route. This pilot supplies one conservative ancestor-closure matrix per patient rather than pretending each uncertain mutation-cluster reconstruction is a uniquely resolved mutation tree. That partial-order adaptation and its assumptions must remain explicit. Genuine-runtime and structural input checks passed before fitting; no substitute is labelled ASCETIC.

The source-derived pair evidence is primary and can contain conflicting directions across patients. It is never forced into a DAG. A selected ASCETIC DAG is a separate model that imposes an agony-derived population ranking and regularized dependence assumptions; it cannot erase unresolved source categories or establish a universal event order.

The frozen assessments are 100 patient-bootstrap full fits, 100 ordering-null engine fits and 10,000 pair-statistic null permutations. Within each patient, null permutations exchange gene labels only among uniquely placed selected genes, preserving binary carrier data, occupied cluster placements and temporal-resolution structure; repeated/unmapped genes remain fixed and unordered. The directional statistic is forward strict-ancestry count minus reverse count. One-sided Monte Carlo p-values use a +1 correction, with BH over every ordered pair of eligible genes. These test the specified gene-label ordering null, not causality or complete adjustment for ascertainment and biology.

Every genuine selected edge remains available, including edges with weak or absent direct ordering evidence. Bootstrap selection frequency and the prespecified 80% display criterion are computational diagnostics, not probabilities of true evolution. All co-carrier denominators and unresolved counts remain visible. Held-out evaluation scores the frozen directions against independent evaluation patient trees and separately checks training-fitted joint event probabilities; it never refits or chooses the model using evaluation results.

## Application and interpretation

The existing TCGA and published-tree views remain available. The TRACERx companion presents the complete pair evidence, the separate population model and links to actual within-patient Auspice trees. A patient's native view uses the authors' deposited corrected topology and genuine SNV-count lengths. It is labelled as one source-selected topology; the population ordering evidence uses agreement across alternatives. Native population components have unitless layout positions and explicit event copies, not biological ancestors connecting patients.

Results and reproduction details are recorded in `TRACERX_ROUTE_SOURCE.md`, `TRACERX_ROUTE_METHODS.md` and `TRACERX_ROUTE_VIEW.md`. Source fidelity, resampling, held-out compatibility and functional/causal validation answer different questions. No survival analysis, clinical prediction, RNA-program refitting or biological tier assignment is part of this pilot.

## Observed results

Twelve of the 18 candidate genes met the training-only carrier gate, producing 66 unordered pairs and 132 directional tests. Every source category and co-carrier denominator remains available, including genes known to be present but not placeable in the source trees. In particular, all 27 RBM10 carriers have unavailable source cluster placements. Independent examination found their curated variants on chromosome X with missing corrected-cluster values and no embedded mapping under either X or numeric chromosome naming. No gene order was recovered by assuming an alternative chromosome spelling.

The genuine ASCETIC model selected three dependencies:

| Selected dependency | Bootstrap selection | Training strict ancestry / co-carriers | Evaluation strict ancestry / co-carriers | Ordering permutation BH q |
| --- | ---: | ---: | ---: | ---: |
| EGFR → KEAP1 | 19% | 1 / 1 | 0 / 0 | 1.0 |
| KEAP1 → STK11 | 85% | 2 / 12 | 0 / 5 | 1.0 |
| KEAP1 → SMARCA4 | 54% | 1 / 10 | 0 / 0 | 1.0 |

The 85% selection frequency does not mean an 85% probability of the evolutionary route. For KEAP1/STK11, nine training co-carriers place both drivers in the same source cluster, and one has unresolved mapping. All five evaluation co-carriers lack resolved order: four are same-cluster and one is unplaced. There is therefore no resolved held-out ancestry confirmation for this edge. The other two selected edges have no evaluation co-carriers at all.

All 100 patient bootstrap fits and 100 engine-null fits completed. The 10,000 label permutations produced no BH q below 0.05 among all 132 tested directions. The selected EGFR/KEAP1 dependency also has negative training co-occurrence association: KEAP1 is present in 1/20 EGFR carriers versus 22/132 noncarriers. It must not be described as positive cooperation merely because the model draws an arrow.

The frozen graph's held-out joint event log score was worse than the independent-event comparator by 0.06103 nats per evaluation patient. This is a co-occurrence prediction check, not a test of temporal truth. It does not support claiming a predictive improvement.

The achieved result is a functioning source-grounded test of candidate routes, with access to the underlying patient trees. Multi-region data supply richer ordering evidence and reveal how much remains unresolved. This particular pilot does not establish a robust shared evolutionary route, universal mutation sequence or improved biological reliability over the earlier pilot.
