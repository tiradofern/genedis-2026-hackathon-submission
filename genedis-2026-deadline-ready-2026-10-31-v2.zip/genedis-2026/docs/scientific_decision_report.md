# GeNeDis 2026: first scientific decision report

**Audit date:** October 14, 2026. **Status:** dataset audit complete; research lead selected the acquired-resistance primary focus. Technical readiness remains conditional. No differential expression, enrichment, module discovery, genomic association, or replication has been performed.

## Recommendation

Recommend **GSE248249 as the conditional primary discovery cohort** because it directly samples acquired resistance after PD-(L)1 therapy and contains 13 patient-matched pretreatment/resistance pairs. Recommend **GSE207422 bulk RNA sequencing as an independent biological comparison**, addressing pretreatment association with later major versus non-major pathologic response to combination chemoimmunotherapy. This comparison evaluates related biology across different endpoints; it cannot establish replication of acquired resistance.

GSE248249 is technically accessible, but **not yet confirmed ready for an inferential discovery analysis**. Array annotation must be fully retrieved and harmonized, and batch effects must be assessed with the public data. The final batch-corrected matrix described in the publication is available only upon request according to GEO. Explicit batch labels and histologic subtypes are absent from the downloaded GEO sample annotations. These uncertainties must remain visible.

If matched publicly accessible multi-omics is essential to the initial deliverable, **GSE126045 is a substantive alternative**, combining pretreatment RNA sequencing and methylation with 16 shared patient codes. Adopting it as primary would change the question to baseline programs associated with subsequent clinical benefit. It would not study programs acquired under treatment.

## What was verified

The workspace was empty of an existing repository or analysis project. A new project structure was created without installing an analysis stack. Public GEO metadata, the two GSE207422 clinical workbooks, and three processed expression matrices were downloaded. All expression columns were reconciled against their sample metadata. Large single-cell matrices, FASTQ/BAM files, CEL/IDAT archives, and controlled-access exomes were not downloaded.

| Dataset | Verified biological units and assays | What the labels mean | Defensible use and key restriction |
|---|---|---|---|
| GSE248249 | 42 Clariom D FFPE expression profiles, 29 patients; 13 pre and 29 acquired-resistance samples; 13 complete pairs | Prior partial/complete response followed by isolated or systemic progression; resistance biopsies collected after progression | Paired pretreatment versus acquired-resistance comparison in 13 patients. All patients in this expression cohort developed acquired resistance; no durable-responder control group |
| GSE207422 bulk | 24 profiles from 24 patients; 58,387 source gene identifiers; log2(TPM+1) | Later surgical MPR in 9 versus NMPR in 15; 5 of the 9 MPR are pCR | Baseline association with later pathologic response. **Every bulk sample is pretreatment**; there are no longitudinal bulk pairs |
| GSE207422 single cell | 15 samples from 15 patients; 3 pretreatment and 12 post-treatment resections | The post-treatment subset comprises 4 MPR including one pCR, and 8 NMPR | Optional patient-level cell-type/pseudobulk comparison; no longitudinal pairs within this assay. The pCR specimen cannot be presumed to contain viable malignant cells |
| GSE156054 | 6 profiles: HCC827/HCC827-GR, PC9/PC9-GR, H1975/H1975-OR | Gefitinib-selected resistance for HCC827 and PC9; osimertinib-selected resistance for H1975 | Descriptive within-model changes and prespecified module scores. One deposited expression profile per model/state; no replicate-based differential-expression inference |
| GSE126045: GSE126044 + GSE126043 | 16 pretreatment RNA profiles and 18 methylation profiles; 16 shared Dis codes with concordant response labels | Clinical benefit: PR or SD lasting >6 months; nonbenefit: PD or SD lasting ≤6 months, as defined in the original study | Potential matched RNA–methylation alternative. RNA has 5 responders and 11 nonresponders; all 5 FFPE RNA profiles are nonresponders. Full processed matrices and clinical crosswalk need further audit before analysis |

For the first three cohorts, see the original [Hu et al. study](https://pmc.ncbi.nlm.nih.gov/articles/PMC9985263/), [Memon et al. study](https://pmc.ncbi.nlm.nih.gov/articles/PMC11249385/), and [Wang et al. publication](https://pubmed.ncbi.nlm.nih.gov/33744274/). Counts and joins above were independently rebuilt from downloaded GEO files; source accession links and checksums are recorded in the manifests. The alternative's endpoint definition comes from [Cho et al., patient recruitment methods](https://www.nature.com/articles/s12276-020-00493-8).

## Consequential limitations

**Sampling site in GSE248249:** only 4 of 13 pairs have the same reported anatomic site. Paired design controls stable patient characteristics, but does not remove differences between, for example, a baseline lung biopsy and a resistance liver biopsy. Organ and cell-composition changes can mimic a treatment-associated program. A same-site sensitivity analysis would be descriptive and extremely small.

**Technical processing in GSE248249:** the public expression values are SST-RMA values. GEO describes two processing batches, followed in the publication by ComBat and LOESS processing. The deposited matrix must not be called the final corrected matrix. CEL filenames contain two preparation-number groups: 11 pairs remain in the same group and 2 cross groups. These are **unconfirmed technical proxies**, not author-supplied batch labels. Only 3 pairs match both site and filename group. A filename grouping is not sufficient evidence to perform definitive batch correction.

**Histology and treatment in GSE207422:** the bulk cohort includes 8 Adeno, 12 Squamous, 3 unspecified NSCLC, and 1 source-labeled Carcinosarcomatoid. Do not silently reclassify the last four as LUAD/LUSC. Histology and chemotherapy regimen are related; 24 patients cannot support a saturated model with many clinical covariates. Preserve the source spelling of antibody names, including “Cremlizumab,” pending adjudication. Non-MPR means >10% residual viable tumor, not necessarily primary radiographic progression or acquired resistance.

**Overlapping GSE207422 modalities:** P05, P07, and P08 occur in both assay cohorts. The union is 36 tumor patients, not 39 independent tumor patients. Bulk and single-cell cohorts cannot be treated as wholly independent validation sets. The original article describes 21 independent bulk patients; the deposited bulk matrix also contains these three overlapping patients, yielding 24 profiles.

**Expression units:** GSE207422 is already log2(TPM+1). GSE156054's filename contains “Raw_gene_counts,” but sample processing states TPM, and the matrix contains fractional values. Do not feed either matrix to a count-based DESeq2 model. GSE156054 also has an empty trailing column and 698 values with thousands separators; the audit parser handles these explicitly.

## Genomic and other omics evidence

The Memon publication reports WES for 34 tumors from 22 patients, including 12 longitudinal WES pairs and 28 lesions measured by both expression and WES. WES is deposited under [dbGaP phs002834.v1.p1](https://www.ncbi.nlm.nih.gov/projects/gap/cgi-bin/study.cgi?study_id=phs002834.v1.p1), which requires approved access. These are study-level matched modalities, **not an available open matched dataset for this project**. Public supplementary sample tables could not be retrieved through the attempted endpoints; their contents and expression–WES identifier mapping have not been verified.

[TCGA-LUAD](https://portal.gdc.cancer.gov/projects/TCGA-LUAD) and [TCGA-LUSC](https://portal.gdc.cancer.gov/projects/TCGA-LUSC) offer genomic context. cBioPortal identifies the corresponding PanCancer Atlas studies; exact RNA/mutation/CNA overlap must be audited by sample barcode. A matched multi-omics analysis can be conducted *within TCGA* after that audit, but its relationship to the resistance cohort is cross-cohort evidence. TCGA is not an acquired-resistance cohort, and its cases must not be joined to GEO patients.

The RNA–methylation alternative is publicly documented under [GSE126045](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE126045). The 16 title-stem matches and response agreement are recorded explicitly. The ~61 MB methylation matrix was not downloaded during this audit; probe filtering, annotations, specimen provenance, and the full matrix join remain to be checked.

A potential orthogonal proteomics resource is [PXD001825](https://proteomecentral.proteomexchange.org/cgi/GetDataset?ID=PXD001825), a kinase-enrichment resistance study including HCC827 models. It is an independent experiment, not matched proteomics for GSE156054 or the clinical cohorts. Its processed file usability and replicate inventory remain unverified; defer it from the minimum study. The publisher cites PXD001825, superseding a conflicting PXD001333 lead from an aggregator.

## Minimum viable analysis, after scientific review

1. **Resolve array preprocessing first.** Retrieve the complete GPL23126 annotation, exclude control/ambiguous features transparently, and freeze an outcome-independent gene-mapping rule. Examine sample distributions, principal components, pair structure, and technical grouping. Document any unresolved batch dependence. Do not claim reconstruction of the authors' corrected matrix without it.
2. **Begin with prespecified pathway scores in the 13 complete GSE248249 pairs.** Rank-based scores or an explicitly documented standardized-expression score can provide a simple baseline. Present every patient's change, a paired effect estimate, uncertainty, and multiplicity adjustment across the prespecified pathways. IFN-response pathways from the published study are positive-reference biology, not new FMSIs. Sensitivity analyses include leave-one-patient-out, same-site pairs, and same-filename-group pairs with clear limits.
3. **Compare fixed signatures in GSE207422 baseline bulk profiles.** The endpoint is NMPR versus MPR, with source pathology retained and a confirmed Adeno/Squamous sensitivity set. Fit a parsimonious model only if design rank, group sizes, and diagnostics permit. A signal here is baseline response-related concordance, not replication of longitudinal resistance.
4. **Only then attempt candidate module discovery.** Use transparent coexpression/functional networks, patient-level resampling, and explicit sensitivity to gene filtering and cell-composition effects. With 13 changes or 29 resistance patients, large de novo WGCNA modules may be unstable. Defer advanced ML. Absence of a stable new module is an acceptable result; a pathway score is not automatically a discovered FMSI.
5. **Add genomic context after module prioritization.** Use a separately audited TCGA modality intersection, then report mutation/CNA associations as cross-cohort context. Physical clustering needs a justified genomic null and assay-aware gene universe. Keep it secondary.

**Smallest meaningful result:** a reproducible, patient-level table and figure of prespecified transcriptional pathway changes at acquired resistance, with sampling-site and technical sensitivity, followed by a carefully labeled baseline-response comparison. This would establish whether a more ambitious FMSI discovery analysis is warranted; it does not establish a resistance mechanism.

**Computing/time feasibility:** the downloaded processed matrices total about 25 MB compressed and can be read without sequencing alignment. Integrity parsing completed locally. A CPU-only bulk/array workflow is plausible within the October 14–31 planning window; runtime and peak memory of statistical analysis have not been benchmarked. Single-cell analysis and access-dependent WES are outside the minimum deliverable.

## Scientific decisions needed

The recommended starting question is **“Which transcriptional programs change between pretreatment and acquired PD-(L)1 resistance, and do fixed signatures show related baseline response associations in an independent chemoimmunotherapy cohort?”** This replaces the handoff's proposed GSE207422 bulk discovery design because that assay is entirely pretreatment.

The research lead explicitly selected **acquired resistance with GSE248249** during this audit. GSE207422 remains the separate baseline-response comparison in the selected recommendation. The matched baseline RNA–methylation alternative is deferred. Matched resistance WES remains unavailable; genomic context would therefore be cross-cohort. The handling of unspecified NSCLC and Carcinosarcomatoid samples in the secondary cohort remains a scientific item for the next stage. Technical audit work is complete; inferential discovery still requires complete annotation and batch/site QC.

The [official hackathon page](https://2026.genedis.org/hackathon/) lists **October 31, 2026** for submission, November 10 for team selection, and November 21 for the hackathon. A cutoff time/timezone is not stated. Registration provides the brief and template; receipt of that template has not been confirmed. No registration, correspondence, or submission was performed.
