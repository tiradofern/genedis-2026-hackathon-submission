# Expanded TRACERx evidence view

This additive, read-only companion runs at <http://127.0.0.1:4003/>. **Histology
analysis** selects separately analysed adenocarcinoma (LUAD) or squamous cell
carcinoma (LUSC). **Driver analysis** selects the expanded source-curated
SNV/indel analysis or the corresponding frozen published-gene baseline. No
histologies are pooled. The original companion on port 4002, its baseline models
and all 342 original source patient-tree exports remain separate.

The expanded catalogue contains every gene with an authors' `DriverMut = TRUE`
SNV/indel in training patients. The frozen gate retains genes with at least ten
training carriers and ten non-carriers. Evaluation observations do not select
the catalogue or gate. A disclosure lists every candidate and its training-only
gate result; genes below the gate are not silently discarded from the audit.
Source curation is not independent functional confirmation of each variant.

The comparison table reports strict-order-resolved, same-cluster and unavailable
mapping observations over all co-carrier pair observations. A patient contributes
at most once to one pair but can contribute to several different pairs. These
totals are **not independent patient counts**. Baseline and expanded pair
universes have different denominators; adding observations or genes alone is not
evidence of improved reliability. The display validator independently rechecks
every source patient vote and rejects changed patient identities, locked roles
or histology.

Each selected pair preserves all seven original categories, both roles and all
co-carriers. Patient-trace filters change visible rows only. A strict source
ancestry relation must hold across every deposited alternative and may include
intervening clusters. Same-cluster events do not acquire a within-cluster order.
The evaluation cohort has already been inspected in previous pilots: subsequent
checks are exploratory sequential assessments, not independent external
validation or an untouched confirmatory holdout.

## Copy-number evidence

Copy-number measurements have a separate source-coverage and event-context
panel. They must not acquire temporal positions from regional presence,
clonality, allele-specific counts or mutation-cluster labels without a verified
comparable source ancestry relation. A shared chromosomal segment or arm is not
multiple independent evolution events merely because it overlaps several genes.
Reported absence, missing coverage and unavailable timing remain distinct.
Whole-genome duplication is separately labelled context. Copy-number context
does not create an ASCETIC arrow or a branch in the native source trees.

The complete source panel has 67 gene targets, plus WGD as a separate 68th
context event. **Copy-number event** selects an exact source event. **CNA patient
role** and **CNA source state** filter displayed patient rows without changing
the training/evaluation event denominators. The three states are reported, not
reported and assay unavailable. Original `is_clonal` labels, including multiple
source labels for one patient/event, remain visible. They are not order votes.

All 342 patients have SCNA records for all expected primary regions; this does
not establish complete gene-level measurement. The target table retains 675
LUAD and 413 LUSC patient-gene units with unavailable measurements and 64/63
units with partial primary-region measurements. AMER1, GPC3 and KDM6A have no
available target measurement in either histology. They are shown as unavailable,
rather than unreported normal copy states. Source WGD is reported in 157/217
LUAD and 104/125 LUSC patients, as presence context without an ordering claim.

The browser initially fetches only event/coverage summaries and a compact patient
chooser. Selecting one event fetches its patient states; clicking one patient
fetches that patient's exact calls and only the shared genomic units overlapping
the selected target. Allele-specific total/major/minor copies, ploidy, aberrant
cell fraction, source copy-state/MSAI labels and all overlapping panel genes
remain attached to the same coordinate unit. WGD instead exposes its separate
tumour/regional records. Full source segment inventories are never automatically
expanded into the browser. On-demand segment files must stay within the requested
cohort's source directory and match their stored size, SHA256 and tumour identity.

## Actual Nextstrain integration

Every expanded mutation-pair patient link reuses that patient's unchanged
published-tree export in genuine, unmodified Nextstrain Auspice on port 4000.
Those reconstructions already annotate all deposited curated drivers, including
genes outside the previous small candidate lists. Source SNV-count branch
lengths, corrected representative topology and all original alternative-topology
metadata stay intact. Copy numbers never become SNV-count branch lengths.

Separately named expanded model datasets use
`/tracerx/luad/expanded/population/edges` and
`/tracerx/lusc/expanded/population/edges`. The wrapper reuses the existing
loss-audited model projection while changing only new dataset titles, links and
explicit interpretation metadata. Each selected dependency is a unitless
two-event component; isolated retained genes remain singleton components. Full
selected parent sets and the exact authoritative model are embedded. These
components are model display copies, not patients, clones, chronological
transitions or reconstructed shared ancestry. Their exact companion DAG and
complete primary categorical evidence remain authoritative.

## Run and check

After source preparation and genuine inference, run from the repository root:

```powershell
python tracerx_expanded/visualization/native_models.py --cohort luad
python tracerx_expanded/visualization/native_models.py --cohort lusc
& 'tracerx_expanded/visualization/Start Expanded TRACERx.ps1'
python -m unittest discover -s tracerx_expanded/visualization/tests -v
node --check tracerx_expanded/visualization/app.js
```

The launcher binds only to `127.0.0.1`, runs its own background process hidden,
and verifies project, script, PID and start time before reusing or restarting it.
An unrelated listener is never stopped. The server accepts only the two
histologies and two configured analyses, whitelists its routes, preserves exact
source-download bytes and rejects invalid or unavailable results with HTTP 503.
No other analysis, example or synthetic scientific result replaces a missing
source. Patient-level source files, runtime state and generated datasets remain
local and ignored by Git.

## Design and verification record

This is a bounded extension of the existing light scientific workstation:
mineral-white surfaces, marine-teal controls, Segoe UI typography, amber evidence
qualifications, native labelled selectors, complete category tables and contained
scrolling. The existing visual identity and original port 4002 surface are
preserved. Controls and source resolution precede the detailed pair workflow.

Implementation checks, final desktop verification and independent finish-review
results are recorded below only after those checks have actually completed.

Eight display checks pass: independent category-resolution recounts, unchanged
baseline/expanded patient identities and roles, shared baseline event/pair counts,
all four exact source-download combinations, invalid/duplicate/foreign queries,
missing-source failure without fallback, three-state CNA and assay recounts,
source-call consequence preservation, rejection of invented ordered CNA events,
summary-first/on-demand HTTP boundaries, and both actual expanded native model
exports against the complete pinned official Augur v2 schema and projection
fidelity contract. The JavaScript syntax check passes. A single Impeccable
detector pass returned no findings. The initial restricted-host HTTP test could
not write Windows system temporary files; the completed checks pass with normal
host temporary-file and loopback access.

The final mutation-model SHA256 values are
`74738f243775d38cd0ad8d08c894391c024b961f66da86d30e46c2ab5ac7c7be`
(LUAD) and
`74f22b6a4f3bf5d47b1c6afb164e5e5c4a15b8afce0fc9c8900df3c85df6e411`
(LUSC). The exact CNA context SHA256 values are
`fad0523b3c4391f3ca6082cde3a065dc587ab21cfeb6e28f47ac26e8a173d573`
(LUAD) and
`e33490dcca53fdfd6abd7a7c33fba09dd05cbaaf5926c606bf605b6ad48516d8`
(LUSC). The initial view displays the selected mutation-model fingerprint; the
separate CNA audit disclosure displays its own exact fingerprint.

Root desktop verification passed at 1581 × 800. Both histologies round-tripped
between their exact baseline/expanded event counts (LUAD 12/18, LUSC 5/8).
The LUSC CDKN2A/KMT2D source category comparison retained its exact 1/5 training and
1/2 evaluation ancestry denominators. The LUAD EGFR amplification context showed
18 training and ten evaluation reports; the evaluation display filter showed ten
of 217 patient traces without changing those totals. Selecting one contributing
patient loaded its three expected/measured primary regions and a hash-verified
source segment containing both EGFR and IKZF1, with exact allele-specific copies,
ploidy and interpretation caveats. AMER1 remained assay unavailable for all 217
LUAD and all 125 LUSC patients. LUSC SOX2 amplification showed 48/26 reports in
training/evaluation; WGD showed 73/31. Both separately named native expanded
model views rendered their complete six/three dependencies and source warnings
with the correct final model fingerprints. No material desktop issue was found.

The available browser's earlier mobile viewport override did not take effect;
root did not repeat that unsupported action. Live mobile layout remains
**unverified**. Responsive CSS is implemented and is not substituted for browser
evidence. No new internal native branch-popup behavior was claimed.

The fresh independent Impeccable finish reviewer viewed all three final desktop
captures and inspected the direction contract, inherited visual system,
copy-number contract and native-model wrapper. Its disposition was **ship**.
All five contract promises, source distinctions and desktop visual fidelity
matched; no material fix or rebuild was required. The reviewer did not claim an
additional browser run or a second detector pass. Its complete review is saved
in [the finish-review record](../reviews/tracerx-expanded-ui-finish-review.md).

| Material finding | Verdict |
| --- | --- |
| No material desktop findings in the reviewed scope | Resolved; ship |
