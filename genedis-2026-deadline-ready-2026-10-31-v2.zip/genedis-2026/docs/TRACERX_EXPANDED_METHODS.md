# Expanded TRACERx event analysis: methods

The investigator requested a wider driver-gene search and copy-number changes, retaining separate adenocarcinoma and squamous analyses. This additive extension preserves the original 217 LUAD patients (152 training, 65 evaluation), 125 LUSC patients (88 training, 37 evaluation), source reconstructions, patient roles and earlier results. The original evaluation results were already inspected. Reusing those patients supports a comparable exploratory assessment; it does not create a fresh independent confirmatory evaluation.

## Candidate rule fixed before expanded frequencies

The mutation candidate universe is every exact gene symbol with at least one source-curated `DriverMut == TRUE` mutation in **training patients only**, without the original TCGA 18-gene LUAD or TCGA 10-gene LUSC restriction. Every candidate with at least 10 training carriers and 10 training noncarriers enters its histology's model. Evaluation-only gene names, counts, pair orders and model results cannot determine the candidate inventory or gate. Rare events remain in the candidate inventory with their exclusion reason; the gate is not relaxed to obtain more selected dependencies.

This is an externally specified annotation rule, not a claim that the candidate names form an independently validated panel. [Frankell et al., Nature 2023, Methods: Classification of driver alterations](https://www.nature.com/articles/s41586-023-05783-5) describes the original curation from COSMIC v75, pan-cancer and previous NSCLC studies, followed by variant-level driver criteria. Those author annotations are scientific inputs. They may reflect the publication's full cohort and computational predictions; they do not establish independent functional evidence for each mutation in this analysis. The [2024 Author Correction](https://doi.org/10.1038/s41586-024-07738-w) concerns Fig. 1 death/censoring symbols and does not replace the published mutation/CNA annotation methods.

## Histology, source orders and copy number

Each histology is configured, prepared, fitted and assessed separately. No LUAD/LUSC pooling or formal histology-difference test is performed. The existing source's exact curated mutation-to-cluster mappings are retained. A gene supplies an ordered vote only when **all** its curated mutations map unambiguously to the same retained source cluster and the cluster ancestry agrees across **every** deposited tree alternative. Several variants within that one cluster are allowed. Same-cluster order, incomparable branches, alternative-dependent relationships, repeated hits across clusters and missing/removed mappings remain explicit unresolved categories. An ancestor relation may span intervening clusters and is not an immediate next-mutation transition.

Copy-number source records are audited separately. A tumour or region identifier, `Tumour.cluster` multiple-primary label, cross-region presence, inferred clonality, adjusted copy number, or WGD-related molecular timing is not interchangeable with placement on the deposited mutation tree. A CNA without validated comparable branch ancestry supplies source context only. It does not enter the ordered engine as a zero-order node. No CNA/SNV or CNA/CNA direction is invented to increase the number of arrows. Gene amplification, homozygous deletion, whole-genome doubling and allelic loss are distinct event types; a regional broad segment can affect many genes together, so those genes cannot be interpreted as independent successive driver acquisitions. Consult the additive copy-number source guide for the audited fields, annotation limits and coverage denominators.

## Actual engine and assessment contract

The unchanged official ASCETIC 1.2.0 implementation, upstream commit `e6bc7f5214ce5eae015ca9ef9d13dbfdc756c5fa`, is reused through the already pinned R 4.5.1 runtime. The genuine call is `ASCETIC::asceticPhylogenies(dataset, models, regularization="aic", command="hc", restarts=0)`. Each patient's matrix contains strict all-alternative ancestor-closure relations; present mutation genes with unknown order remain named zero-relation nodes. This documented partial-order adaptation is not a uniquely resolved mutation tree or a validated new extension of ASCETIC. CNA context is outside these matrices.

For each histology, the prespecified analysis retains all selected dependencies, 100 patient-bootstrap fits, 100 within-patient label-null engine fits, and 10,000 directional label-null permutations. Labels shuffle only among uniquely mapped selected mutation genes within the same patient. Binary carrier data, co-occurrence, occupied placement structure and fixed unknown/repeated-hit identities remain unchanged. A patient supplies at most one categorical vote per event pair. Regions and tree alternatives do not increase the independent patient count.

Every ordered pair of frequency-eligible mutation genes belongs to the histology's BH adjustment family, including model-unselected directions. The one-sided statistic is forward minus reverse strict-ancestry patient counts. Monte Carlo P is `(1 + exceedances)/(1 + permutations)`. All unresolved denominators are reported; a directional-agreement Wilson interval is conditional on the resolved subset. The 80% bootstrap display criterion is not a biological validation threshold or an ancestry probability. Multiple exploratory versions share the same source patients and do not provide independent replications; separate within-histology BH families do not correct the entire research programme's sequential analyses.

The locked evaluation roles assess selected directions with all unresolved categories retained, and score train-only Beta(1,1) conditional-probability tables against independent-event marginals. The log score measures reported-event co-occurrence prediction, not temporal truth, clinical benefit or a universal cancer pathway. No evaluation refit, feature selection, threshold tuning or selected-edge pruning is allowed. A negative co-occurrence dependency must remain visible and must not be described as positive cooperation.

## Reproducibility and limits

`tracerx_expanded/inference/run.py` is additive and imports the existing pure source-evidence functions and unchanged R wrapper. It verifies the frozen configuration, baseline configuration/source/model hashes, exact patient identifiers and roles, preparation code and actual engine input hashes. Patient-level inputs, outputs, reproducibility snapshots and fitted R objects remain local and ignored. Small aggregate results contain no patient identifiers.

The main bottlenecks remain limited independent patients with both alterations and **resolved** relative order, early truncal events grouped in the same cluster, incomplete placement/callability, candidate-tree ambiguity, gene-level recurrence that merges biologically different variants, correlated broad CNAs, and multiple testing. Expanding the event list addresses missing mechanisms; it cannot manufacture within-cluster chronology or increase independent patient counts. More event types can increase coverage while reducing statistical precision.

## Completed frozen run

Both configurations were frozen before expanded frequencies, patient-pair results or fits. The actual genuine ASCETIC run retained the prespecified 100 bootstrap and 100 engine-null fits per histology, with every fit successful, plus 10,000 directional permutations. The first sandboxed R attempt could not see the existing pinned `BiocGenerics` library; the same unchanged wrapper and existing library ran successfully with normal host access. No package replacement or engine change was made.

| Measure | LUAD | LUSC |
|---|---:|---:|
| Fixed independent patients |217|125|
| Training/evaluation |152/65|88/37|
| Training-observed source-curated candidate genes |194|161|
| Genes passing the unchanged 10/10 gate |18|8|
| Earlier eligible genes |12|5|
| Unordered pairs / adjusted directions |153/306|28/56|
| Selected ASCETIC dependencies |6|3|
| Directions with BH q<0.05, entire family |0|0|
| Training resolved strict orders / all co-carrier patient-pair votes |85/463 (18.4%)|22/134 (16.4%)|
| Evaluation resolved strict orders / all co-carrier patient-pair votes |34/176|4/36|
| Joint minus independent evaluation log score, nats/patient |−0.0968100|−0.00388353|

Pair-vote totals reuse the same patients across gene pairs. They are not independent sample counts or confidence denominators for a cohort-wide ancestry probability. The fraction of resolved training votes barely increased compared with the earlier LUAD 50/277 (18.1%) and LUSC 12/75 (16.0%) models. The wider event universe supplied more observations and more hypotheses; it did not repair the chronology bottleneck.

New eligible LUAD genes are `ATM`, `ATRX`, `CREBBP`, `GRIN2A`, `KMT2C` and `KMT2D`; new eligible LUSC genes are `CUX1`, `FAT1` and `NF1`. LUAD `ATRX` and `RBM10` are present in the binary event layer but have zero uniquely mapped source placements. No ordered vote is imputed for them.

All selected dependencies remain visible, including weak, negatively associated and unresolved ones:

| Histology | Selected dependency | Bootstrap | Training forward/reverse/all co-carriers | Evaluation forward/reverse/all co-carriers | Ordering BH q |
|---|---|---:|---:|---:|---:|
|LUAD|EGFR→KEAP1|20%|1/0/1|0/0/0|1|
|LUAD|KEAP1→KMT2C|35%|1/0/4|0/0/1|1|
|LUAD|CREBBP→MGA|46%|1/0/3|0/0/1|1|
|LUAD|CREBBP→SMARCA4|50%|1/0/4|0/0/0|1|
|LUAD|KEAP1→SMARCA4|54%|1/0/10|0/0/0|1|
|LUAD|KEAP1→STK11|84%|2/0/12|0/0/5|1|
|LUSC|CDKN2A→KMT2D|45%|1/0/5|1/0/2|1|
|LUSC|CDKN2A→PIK3CA|64%|2/0/5|0/0/0|1|
|LUSC|NFE2L2→PIK3CA|51%|1/0/4|0/0/2|1|

These arrows are model-selected dependencies with sparse strict source evidence, not validated common routes. None of the selected LUAD dependencies has a resolved evaluation order. The one compatible evaluation order for LUSC `CDKN2A→KMT2D` is insufficient to establish a reliable route; the other co-carrier remains same-cluster unresolved. The joint co-occurrence models perform worse than their independent-event comparators on reused evaluation patients in both histologies. No higher-order clinical or temporal benefit is established.

Exact local model SHA256 hashes:

- LUAD: `74738f243775d38cd0ad8d08c894391c024b961f66da86d30e46c2ab5ac7c7be`.
- LUSC: `74f22b6a4f3bf5d47b1c6afb164e5e5c4a15b8afce0fc9c8900df3c85df6e411`.

`tracerx_expanded/inference/luad_results_summary.json` and `lusc_results_summary.json` preserve aggregate candidate gates, all pair-category denominators, selected dependencies, permutation tests, fit denominators, scores and provenance. Seven focused method tests passed: training-only candidate identity invariance, strict driver-annotation enforcement, unresolved-state preservation, exact baseline source/role/hash preservation, exhaustive training frequency selection, independent all-pair source-category reconstruction from strict/possible ancestry closures, and multiplicity/fit-denominator/holdout-score reproduction. Computational tests establish transformation fidelity and assessment behaviour, not the biological validity of inferred routes.

An additional read-only R check (`tracerx_expanded/inference/test_official_fit.R`) independently compared both saved official fitted objects with the frozen engine inputs. The two presence matrices and all 240 training patient-order matrices matched exactly; all 102 evaluation patients were excluded from the saved datasets and models; and the original numeric event indices mapped to exactly the nine reported dependencies. No CNA column entered either fit. The aggregate `official_fit_review.json` records these checks and exact object/input/model MD5s without patient identifiers.
