# Public NSCLC data readiness for the first app

October 17, 2026. **The TCGA PanCancer Atlas LUAD and LUSC distributions are suitable for the first research explorer**, with a measured intersection of 988 primary tumors carrying RNA, copy-number, and mutation-assay coverage. Use them as separate discovery cohorts with a shared exploration interface. The earlier GSE248249 audit remains a separate, conditional resistance extension; it is not discarded or combined with TCGA patients.

This recommendation supports building the app's data layer, cohort filters, program views, and source-backed specimen inspection. It does not establish a candidate island or make the data ready for unrestricted causal, survival, or evolutionary inference. The initial discovery rules are in [Candidate island criteria](CANDIDATE_ISLAND_CRITERIA.md).

## Verified cohort coverage

Counts below were rebuilt from complete downloaded matrices, clinical tables, mutation files, profile lists, and the GDC slide metadata response. DataHub is pinned to commit `7a4b4ec142f76ac04db22834232b23142d25bd2a`. Normal RNA comes from each study's `normals/` directory, with sample-type code 11 verified from column identifiers; it is not inferred from a filename containing the word normal.

| Measured property | LUAD | LUSC |
|---|---:|---:|
| Clinical participants in the distribution | 566 | 487 |
| Tumor RNA columns | 510 | 484 |
| Tumor CNA columns | 511 | 487 |
| Mutation-profiled sample keys | 566 | 484 |
| Primary-tumor RNA + CNA + mutation-profiled intersection | **507** | **481** |
| Unique participants in that intersection | **507** | **481** |
| Core tumors with RPPA protein measurements | 355 | 313 |
| Core tumors with ABSOLUTE purity estimates | 497 | 476 |
| Core participants with GDC slide links | 507 | 481 |
| Core tumor sample keys with GDC slide links | 507 | 481 |
| Core participants with a diagnostic-slide link | 464 | 457 |
| Available bulk normal RNA samples | 59 | 51 |
| Core tumor participants also having bulk normal RNA | 56 | 49 |
| Core tumors with reported grade in the inspected clinical table | 0 | 0 |
| Named IHC fields in the inspected clinical tables | 0 | 0 |

There are no duplicate core participants within or across these two cohorts. RNA, CNA, and RPPA matrix columns agree exactly with their corresponding published profile lists. The core is a proposed working sample universe, not a claim that every source participant has every modality. Its explicit rows are in `manifests/public_tcga_samples_2026-10-17.tsv`.

The underlying official study folders are [LUAD](https://github.com/cBioPortal/datahub/tree/7a4b4ec142f76ac04db22834232b23142d25bd2a/public/luad_tcga_pan_can_atlas_2018) and [LUSC](https://github.com/cBioPortal/datahub/tree/7a4b4ec142f76ac04db22834232b23142d25bd2a/public/lusc_tcga_pan_can_atlas_2018). Counts above describe this audited snapshot, not every version of TCGA or GDC.

## What the measurements mean

**RNA:** each tumor matrix contains 20,531 source rows of batch-normalized Illumina HiSeq RNASeqV2 RSEM expression. Complete numeric scans found nonnegative finite values and no missing expression cells. These are continuous measurements, not raw integer sequencing counts. There are six repeated RNA feature keys per tumor matrix, and hundreds of constant rows. Initial preparation must exclude all rows with a repeated stable gene identifier, retain an exclusion manifest, and apply the training-only variability rules. Do not silently select the first occurrence.

**DNA:** each GISTIC matrix contains 25,128 source rows with discrete values restricted to -2, -1, 0, 1, and 2. There are 39 repeated feature rows beyond the first occurrence per matrix. The same explicit gene-identity exclusion rule applies. Complete MAF scans found 225,653 LUAD and 185,067 LUSC reported records, all labeled GRCh37. Mutation records occur for 562 LUAD and 469 LUSC sample keys, while the profiled lists include 566 and 484, respectively. Preserve this distinction: an assayed sample with no reported event is not equivalent to a sample lacking assay coverage, and neither proves wild-type at every locus.

**Protein:** RPPA has 198 antibody-level rows, with 360 LUAD and 317 LUSC columns before the core intersection. Missing protein cells remain missing. Preserve antibody/epitope identifiers and multi-gene mappings rather than treating every row as a single unambiguous gene. RPPA supports protein-level corroboration; it is not IHC.

**Normal context:** the normal RNA matrices contain 59 LUAD-associated and 51 LUSC-associated solid-tissue normal samples. Use these as bulk tissue references, with purity, field effects, and mixture acknowledged. They are not germline DNA controls, a healthy epithelial atlas, or literal tumor ancestors.

## Linkage and pathology

The shared molecular key is the 15-character TCGA tumor sample identifier, such as `TCGA-AA-0001-01`. The mutation distribution also uses these shortened identifiers. Matching this key is stronger than matching a patient alone, but it does not identify a common vial, portion, analyte, or section. ABSOLUTE contributes a DNA aliquot identifier for its purity estimate, not a verified recovery of the original MAF or RNA aliquot. Preserve the linkage level in each record. The [official TCGA barcode hierarchy](https://docs.gdc.cancer.gov/Encyclopedia/pages/TCGA_Barcode/) distinguishes samples, vials, portions, and aliquots.

The complete GDC query returned 3,220 open slide-file records across these projects: 1,608 LUAD and 1,612 LUSC. The manifest retains file UUID, source sample barcode, patient, file size, checksum, and diagnostic-slide status. No whole-slide image was downloaded. Patient and sample-key matches do not establish the same block or tumor region as the molecular assay. Diagnostic-slide patient linkage is reported separately because not every core case has a diagnostic slide in this query.

The app can preserve source histology and expose linked slides. Fine architectural patterns, cytology, WHO grade, and IHC results must remain unavailable until actual annotations are supplied or reviewed. Their absence must not prevent the explorer from opening a cohort; the interface must distinguish unmeasured findings from negative findings. Presentation illustrations are unrelated to these analysis-coverage requirements.

## Clinical metadata and inference limits

Sex is populated for all core participants. Stage is reported for 505/507 LUAD and 478/481 LUSC participants; age for 488/507 and 470/481. OS time is present for 498/507 and 475/481, while endpoint status and other follow-up fields have different missingness. These are field-presence counts, not the final survival-analysis denominator. Event definitions, zero/invalid follow-up, censoring, sample eligibility, and model feasibility must be audited before a survival test.

The portal provides OS, DSS, DFS, and PFS fields. Preserve their source names and verify correspondence to the [TCGA clinical endpoint resource](https://gdc.cancer.gov/about-data/publications/PanCan-Clinical-2018) before using them inferentially. In particular, do not silently rename a portal PFS field as a uniformly adjudicated treatment-response endpoint.

Legacy treatment timelines and neoadjuvant/radiation fields are available, but this verification does not establish standardized regimen, line-of-therapy, response, or paired pretreatment/progression labels. TCGA cannot be presented as longitudinal acquired-resistance validation. Smoking, fine technical batch, immune/stromal composition, and other covariates require explicit coverage review; tissue source site is not a confirmed sequencing batch. Purity is available for 973 of the 988 core tumors from the [official PanCancer ABSOLUTE resource](https://gdc.cancer.gov/about-data/publications/pancanatlas).

## Complementary resources

| Resource | Useful extension | Current evidence boundary |
|---|---|---|
| CPTAC LUAD/LUSC | Independent proteomics and phosphoproteomics, genomic/RNA resources, and pathology images | Official resources and primary papers verified; the current open modality intersection and exact specimen/aliquot/slide crosswalk have not been independently audited here |
| Human Lung Cell Atlas healthy core | Normal epithelial and other lung cell-state context | Open atlas and labels verified; donor-aware signatures and platform-aware integration remain future preparation. Its corrected embedding does not mean its raw counts are batch corrected |
| TRACERx | Multi-region and evolutionary questions | Published paired DNA/RNA study is relevant, but the underlying accessions are controlled; it is not a no-approval dependency for the first build |

CPTAC has actual targeted IHC experiments, including subset immune-marker work in LSCC and targeted ALK/phospho-ALK work in LUAD. This does not establish a comprehensive linked IHC table or image set. Its broad mass-spectrometry measurements must remain distinct from those IHC experiments. See the [LUAD study](https://pmc.ncbi.nlm.nih.gov/articles/PMC7373300/), [LSCC study](https://pmc.ncbi.nlm.nih.gov/articles/PMC8475722/), [NCI CPTAC overview](https://gdc.cancer.gov/about-gdc/contributed-genomic-data-cancer-research/clinical-proteomic-tumor-analysis-consortium-cptac), and [TCIA pathology collections](https://www.cancerimagingarchive.net/collection/cptac-luad/). PDC has corrected sample/aliquot mappings in past releases; freeze its version before any join.

The [official HLCA overview](https://data.humancellatlas.org/hca-bio-networks/lung/atlases/lung-v1-0) supports a separate cell-state adapter, not direct concatenation with bulk RSEM data. The [TRACERx transcriptomic study](https://www.nature.com/articles/s41586-023-05706-4) specifies controlled EGA access. None of these source-level checks should be mistaken for an independently measured specimen intersection.

## Reproducibility and source terms

The audit verified 47 source files totaling 647,110,442 bytes, including complete processed molecular matrices and MAFs, clinical tables, normal RNA, purity, and slide metadata. Molecular LFS payloads were checked against the SHA256 and byte count declared by the pinned Git pointers. Some payloads were absent from GitHub's mirror; the script uses the endpoint declared in DataHub's pinned `.lfsconfig`, without saving temporary signed download links. No raw sequencing, controlled data, or whole-slide images were downloaded. Large processed files remain outside Git.

```powershell
python scripts/audit_public_tcga.py --download --include-mutations
python -m unittest discover -s tests -v
```

After the files have been acquired, omit `--download` to repeat the audit from the verified local cache. An offline rerun reproduced every readiness metric, excluding only the generation timestamp. Outputs are `results/reports/public_tcga_readiness_2026-10-17.json` and the three `manifests/public_tcga_*_2026-10-17.tsv` files. The initial tests cover corruption, duplicate identifiers, malformed tables, invalid numeric values, missingness, and barcode-linkage limits. All 18 repository tests passed; the full source audit completed. This is input-integrity evidence, not biological validation.

Source attribution and data terms remain attached to the download inventory. DataHub describes [ODbL database terms and TCGA GDAC conditions](https://github.com/cBioPortal/datahub#license); source visibility does not make the data CC0 or assign a license to this project's code. The GDC also distinguishes [open from controlled access](https://gdc.cancer.gov/access-data/data-access-processes-and-tools). Preserve source terms when sharing derived data or preparing submission materials.

The [current hackathon page](https://2026.genedis.org/hackathon/) permits reproducible open multi-omics workflows and asks for documented sources, processed tables, QC, and clear exploratory labels. It lists October 31 for submission; its November event-day statements conflict, so an exact event date should not be inferred from this audit. The registration-specific brief/template remains a submission-preparation item.

## First build contract

Build around the frozen cohort/sample crosswalk, assay availability, gene/antibody identities, source measurements, specimen-linked clinical metadata, and explicitly labeled slide links. Support both manual comparisons and guided program discovery through the same records. A candidate needs its membership, score definition, supporting participants, reproducibility status, biological tier, evidence, and limitations available for inspection.

The data layer and explorer can start now. Before fitting discovery modules, complete deterministic identifier exclusions, the frozen participant split, source/technical QC, and the versioned network parameters. Before promoting an association, complete the endpoint/model checks in the candidate criteria. Actual IHC, independent protein replication, lineage-specific normal references, and longitudinal evolution can be added as verified capabilities without inventing their availability in the first cohort.
