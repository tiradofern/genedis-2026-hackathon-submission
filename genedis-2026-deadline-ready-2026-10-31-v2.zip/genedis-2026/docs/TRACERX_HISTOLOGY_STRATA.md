# Separate TRACERx adenocarcinoma and squamous analyses

The investigator explicitly selected **adenocarcinoma and squamous separately** in response to the outstanding histology question. This extension adds a separately frozen squamous analysis to the completed adenocarcinoma pilot. It does not pool patients, gene selection, ordering tests or fitted graphs across histologies, and it does not establish a formal between-histology evolutionary difference.

## Independent source cohorts

Both analyses use the public processed TRACERx421 reconstruction and curated mutation deposit associated with Karasaki et al., *Evolutionary characterization of lung adenocarcinoma morphology in TRACERx*, [Nature Medicine 2023](https://doi.org/10.1038/s41591-023-02230-w), [Zenodo 7683605](https://zenodo.org/records/7683605). Despite the publication title, the deposited all-tumour trees and source metadata also contain explicitly labelled LUSC cases. This is not a new raw-sequencing reconstruction or a reclassification of the source histology.

Each participant must have exactly one deposited tumour across all histologies and at least two distinct primary R regions. Lymph-node samples do not qualify a participant for that gate, but the full same-surgery source tree is retained and labelled where applicable. All deposited alternative topologies must pass complete rooted-tree checks. No absent treatment metadata are imputed.

| Separate pilot | Deposited histology-labelled tumours | Excluded tumours from multi-tumour patients | Independent eligible patients | Training | Evaluation |
| --- | ---: | ---: | ---: | ---: | ---: |
| Adenocarcinoma (LUAD) | 229 | 12 | 217 | 152 | 65 |
| Squamous (LUSC) | 129 | 4 | 125 | 88 | 37 |

Patient-hash salts differ by histology. LUSC uses `tracerx-lusc-route-v0.1|`, with 70% training rounded to the nearest integer, exact half rounded up. The exact 88/37 allocation is fixed before event frequencies, order statistics or model results. The existing LUAD roles remain byte-exact. The source LUSC cohort has 21 single-topology and 104 multiple-topology reconstructions. Two source singleton encodings satisfy the same narrowly verified `1:1` codec rule; no generic self-loop removal is permitted.

## Squamous candidate events and fixed assessment

The LUSC configuration is [tracerx_routes_lusc_v0_1.json](../configs/tracerx_routes_lusc_v0_1.json), SHA256 `27a8f619cb39f8a807c569eee4f0a374c80af6bd061572cdda00bf7e530f30b8`. The pre-frequency freeze is recorded in `tracerx_routes/lusc_config_freeze_2026-10-18.json`, with exact source snapshots preserved before fitting.

The candidate universe comes from the explicit ten genome-wide MutSig genes in TCGA, *Comprehensive genomic characterization of squamous cell lung cancers*, [Nature 2012, printed page 520/Figure 1](https://compbio.hms.harvard.edu/publications/pdf/nature11404.pdf): TP53, CDKN2A, PTEN, PIK3CA, KEAP1, MLL2, HLA-A, NFE2L2, NOTCH1 and RB1. The abstract says eleven; the text and figure explicitly enumerate ten. This pilot uses that explicit list and does not invent an eleventh or combine it with the separately tested COSMIC-restricted list. The exact historical MLL2 symbol maps to KMT2D under the documented [human gene record](https://www.ncbi.nlm.nih.gov/gene/8085); literal source gene strings are preserved.

An event requires an authors-curated driver mutation. At least ten training carriers and ten training noncarriers are required; evaluation does not choose genes or relax gates. Five genes pass: TP53, CDKN2A, PIK3CA, KMT2D and NFE2L2. Their training carrier counts are 76, 15, 14, 16 and 12. The excluded candidates remain in the aggregate gate audit; absence of an author-reported driver is not verified wild type or adequate locus callability. This mutation-only analysis does not include copy-number-only, fusion-only or methylation-only alterations.

Every gene-pair co-carrier contributes one category. Strict ancestry must agree across every deposited alternative; same-cluster, incomparable, alternative-ambiguous, repeated-hit and unavailable-placement categories retain presence and their denominators. All curated variants must map to one retained cluster for a gene to be order-eligible. Ancestor closure may span intervening clusters; it is not an adjacent-clone or next-mutation transition.

The primary evidence is the complete patient-pair category table. The separate secondary engine is unchanged official ASCETIC 1.2.0 using the same explicitly documented conservative consensus partial-order adaptation as LUAD. Fixed AIC/hill-climbing, zero restarts, 100 patient-bootstrap fits, 100 ordering-null engine fits and 10,000 gene-label permutations are used. BH covers all 20 ordered pairs among the five training-eligible LUSC genes. This is one separately specified exploratory LUSC family, not an experiment-wide correction across both pilots. Evaluation never refits or chooses the graph.

## Actual squamous results

| Selected LUSC dependency | Bootstrap selection | Training strict forward / all co-carriers | Evaluation strict forward / all co-carriers | Ordering BH q |
| --- | ---: | ---: | ---: | ---: |
| CDKN2A → PIK3CA | 64 / 100 | 2 / 5 | 0 / 0 | 0.9516 |
| NFE2L2 → PIK3CA | 51 / 100 | 1 / 4 | 0 / 2 | 0.9516 |
| CDKN2A → KMT2D | 45 / 100 | 1 / 5 | 1 / 2 | 0.9516 |

All 100 patient-bootstrap and 100 engine-null fits completed. None of the 20 directions passes BH 0.05; no selected edge reaches the prespecified 80% model-selection stability criterion. That threshold is a computational diagnostic, not a probability of true ancestry.

For CDKN2A/PIK3CA, the other training co-carriers comprise one same-cluster and two mapping-unresolved patients; there are no evaluation co-carriers. For NFE2L2/PIK3CA, three training co-carriers are same-cluster, while both evaluation co-carriers have unavailable mapping. For CDKN2A/KMT2D, four training co-carriers are same-cluster; evaluation contains one strict ancestral relation and one same-cluster patient. No reverse strict order is observed for these selected dependencies. One resolved evaluation example is inspectable evidence, not a sufficiently replicated common route.

The frozen graph's evaluation joint event log score is −80.74448 versus −80.60079 for independent training-fitted marginals: −0.003884 nats per evaluation patient. This does not improve the event co-occurrence predictive check and does not test temporal truth. These results do not establish reliable common routes in LUSC. The completed LUAD findings remain unchanged and separately documented in [TRACERX_ROUTE_PILOT.md](TRACERX_ROUTE_PILOT.md).

## Application and reproduction

The live evidence explorer offers an explicit **Histology analysis** selector:

- [Adenocarcinoma evidence](http://127.0.0.1:4002/?cohort=luad)
- [Squamous evidence](http://127.0.0.1:4002/?cohort=lusc)
- [Separate squamous model components in actual Auspice](http://127.0.0.1:4000/tracerx/lusc/population/edges)

Each cohort's downloads, patient traces, event gate and native source trees stay associated with that histology. A missing or invalid requested cohort fails explicitly rather than silently substituting the other model. Patient-level source data, derived models, RDS fits, runtime dependencies and generated Nextstrain datasets remain local and Git-ignored. Academic non-commercial source restrictions and software/project licensing remain separate.

See [TRACERX_LUSC_SOURCE.md](TRACERX_LUSC_SOURCE.md), [TRACERX_LUSC_METHODS.md](TRACERX_LUSC_METHODS.md) and [TRACERX_LUSC_VIEW.md](TRACERX_LUSC_VIEW.md) for source hashes, commands and actual checks. `tracerx_routes/luad_preservation_2026-10-18.json` records the existing LUAD artifact bytes before the extension; preservation is verified after the new analysis. No survival tests, clinical prediction, RNA-program refits or biological tier assignments are added.

All 88 automated checks run for this extension pass: 28 existing Python, five existing Node, 12 source, 24 inference and 19 display tests. These include source fidelity and official schema validation for all 342 native patient exports and both model projections. An independent actual-source/RDS review matched the 88 training rows and temporal matrices, excluded all 37 evaluation patients from fitting, checked original numeric event indices and independently recomputed pair evidence and held-out scores. Final desktop checks verified both histology choices, each source model's fingerprint and denominators, patient-level filters and the native source/model links. Mobile layout and internal branch-popup interaction remain unverified. The original 15 recorded LUAD artifacts and all 217 LUAD native patient dataset bytes remain unchanged; no old source, gene gate, split or model was replaced.
