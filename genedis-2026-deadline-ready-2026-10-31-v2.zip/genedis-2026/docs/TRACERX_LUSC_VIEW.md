# Separate TRACERx histology views

The investigator selected **adenocarcinoma and squamous cell carcinoma separately**. The existing LUAD analysis remains the default at <http://127.0.0.1:4002/>. The same local companion now offers **Histology analysis** with two explicit options: adenocarcinoma (LUAD) and squamous cell carcinoma (LUSC). LUSC opens at <http://127.0.0.1:4002/?cohort=lusc>.

This control selects a separately frozen evidence file. It does not pool patients, apply a display-only histology filter to a combined fit, reuse the LUAD event gate, or reconstruct a shared clonal ancestor. A full page navigation resets the pair, patient and trace selections to the selected source. Role and relationship filters still change visible rows only; their aggregate denominators remain fixed.

| Source | LUAD | LUSC |
| --- | --- | --- |
| Independent eligible patients | 217 | 125 |
| Locked training / evaluation patients | 152 / 65 | 88 / 37 |
| Training-eligible driver-gene events | 12 | 5 |
| Complete unordered gene pairs | 66 | 10 |
| Model-selected dependencies | 3 | 3 |
| Source model | `tracerx_routes/inference/output/model.json` | `tracerx_routes/inference/output/lusc/model.json` |
| Patient export report | `tracerx_routes/visualization/output/patient_exports.json` | `tracerx_routes/visualization/output/lusc/patient_exports.json` |

The LUSC events are TP53, CDKN2A, PIK3CA, KMT2D and NFE2L2. KMT2D retains the frozen exact source MLL2 alias and original variant nomenclature in the source records. Reported-driver presence is retained when cluster mapping is unavailable; it is not a verified wild-type/callability assay.

## Genuine Nextstrain exports

The existing unmodified Auspice server on port 4000 serves the separately named abstract model lists:

- LUAD: <http://127.0.0.1:4000/tracerx/luad/population/edges>.
- LUSC: <http://127.0.0.1:4000/tracerx/lusc/population/edges>.

Every LUSC selected dependency appears exactly once as an independent edge component; isolated retained events remain visible. The complete selected parent set of PIK3CA contains CDKN2A and NFE2L2 and remains attached to each display copy. The native forest is unitless schematic layout, not patient ancestry, a mutation-count tree or a deterministic prerequisite rule. The exact companion DAG and embedded model remain authoritative.

All 125 LUSC patient trees also run as distinct native `/tracerx/patient/<safe-source-id>` datasets. Their explicit LUSC titles and source-histology metadata accompany the full embedded extract. They preserve the authors' corrected topology, real per-cluster SNV counts, truncal stems and exact curated-driver labels. Twenty-one have a single deposited topology and 104 have multiple alternatives; the native view shows one corrected representative and cannot resolve that uncertainty. Two narrowly normalized source singleton encodings remain single clusters with their genuine nonzero stems. Source genotype clusters are not sampled regions.

The LUSC source patients are disjoint from the existing 217 LUAD patients under the independence rule. New native patient exports check for identity/histology collisions before writing. Existing LUAD generated datasets were not regenerated or overwritten. The original published-tree proof and TCGA views are separate.

## Read the LUSC evidence cautiously

| Selected dependency | Bootstrap selection | Training ancestral / co-carriers | Evaluation ancestral / co-carriers | Ordering BH q |
| --- | ---: | ---: | ---: | ---: |
| CDKN2A → PIK3CA | 64 / 100 | 2 / 5 | 0 / 0 | 0.95162 |
| NFE2L2 → PIK3CA | 51 / 100 | 1 / 4 | 0 / 2 | 0.95162 |
| CDKN2A → KMT2D | 45 / 100 | 1 / 5 | 1 / 2 | 0.95162 |

The CDKN2A/PIK3CA training denominator includes one same-cluster and two mapping-unresolved patients. NFE2L2/PIK3CA training includes three same-cluster patients; both evaluation co-carriers are mapping unresolved. CDKN2A/KMT2D includes four same-cluster training patients and one same-cluster evaluation patient. None of the 20 ordered-pair tests passes BH q < .05. The held-out reported-event co-occurrence score is slightly worse than independence, by approximately 0.003884 nats per evaluation patient. One resolved evaluation observation cannot establish a reliable shared route. These are separate exploratory findings, not a powered comparison of histologies or a demonstration that their routes differ.

## Reproduce the display

Prepare the distinct frozen LUSC source and genuine model using the source/method instructions, then run from the repository root:

```powershell
python tracerx_routes/visualization/patient_trees.py --cohort lusc
python tracerx_routes/visualization/population_forest.py --cohort lusc
& 'tracerx_routes/visualization/Start TRACERx View.ps1' -Restart
python -m unittest discover -s tracerx_routes/visualization/tests -v
node --check tracerx_routes/visualization/app.js
```

The owned-server launcher verifies project, model path, PID and process start time before stopping its own recorded process. It binds only to loopback. The server whitelists the two model/report pairs, validates model histology before serving it and checks tree links against that cohort's patient IDs. Unsupported or duplicate cohort parameters return 400; a missing, invalid or incorrectly labelled source returns 503. No other histology or synthetic example substitutes for unavailable evidence. Exact source download bytes and fingerprint always belong to the selected histology.

Nineteen display checks passed, including the 13 prior checks and six additional checks for separate-cohort HTTP byte identity, wrong-histology/missing-source rejection, foreign tree-link rejection, unchanged LUAD model projection content, explicit squamous native metadata, cohort disjointness and all 125 LUSC source-tree fidelity/schema checks. All 342 actual patient exports passed the pinned official Augur v2 schema and source fidelity checks. The JavaScript syntax check passed. The one mechanical UI detector pass returned no findings. An initial restricted-host run could not write system temporary files; the complete checks passed with normal host temporary-file and loopback access.

Desktop browser verification passed on the final source model SHA256 `2cb08b9ac6a022cf5e3b0280c1e4c3f0b78d7a8b7150d6b14191c20ba886a1c2`. The selector round trip LUSC → LUAD → LUSC preserved the correct source fingerprints and cohort denominators. The CDKN2A/KMT2D evaluation-ancestry filter showed exactly one contributing patient while its aggregate remained 1/2; both locked roles and all source categories were then restored. Its native patient link opened the correct LUSC source representative with 155 deposited topologies and visible CDKN2A and KMT2D branch labels. The separate native LUSC model displayed all three dependencies, isolated TP53, the zero-resolved-evaluation warning and the exact final model fingerprint. The independent preservation check confirmed 15 LUAD artifact hashes and the aggregate fingerprint of all 217 existing native LUAD patient files remained unchanged.

The prior browser's mobile viewport override did not take effect, so live mobile layout remains unverified. Internal native branch-popup interaction also remains unverified; visible exact driver branch labels provide the tested reading path. The narrow selector extension preserves the existing palette, typography, category encodings, exact pair evidence and selected-model distinction.

The fresh, read-only Impeccable finish reviewer inspected all three final desktop screenshots, the direction contract, the existing design system and current source/export code. It independently checked the two model cohort counts, final LUSC fingerprint, bootstrap percentages and native model components. Its disposition was **SHIP**, with no material fix or rebuild required. Selector interactions and the passing checks remain independently root-verified evidence; the reviewer did not claim an additional browser run. A bounded design-documentation handoff records the new histology selector in the existing TRACERx design section without changing its visual identity or other application surfaces.

| Material finding | Verdict |
| --- | --- |
| No open material findings in the reviewed desktop scope | Resolved |
