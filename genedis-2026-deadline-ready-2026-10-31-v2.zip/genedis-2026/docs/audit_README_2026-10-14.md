# GeNeDis 2026 — Functional Molecular Survival Islands

**Current release: dataset feasibility audit, October 14, 2026.** This is not an implemented discovery pipeline or a final hackathon submission. Start with [the scientific decision report](docs/scientific_decision_report.md) and [the comparative feasibility assessment](docs/dataset_feasibility.md).

The initial audit changes the proposed design: GSE207422 bulk profiles are all pretreatment; GSE248249 contains 13 acquired-resistance pairs and is the recommended conditional primary. GSE207422 is a distinct baseline-response comparison. The research lead selected this acquired-resistance focus during the audit. Inferential analysis requires resolution of array preprocessing and annotation; secondary mixed-histology handling remains to be settled. An alternative matched RNA–methylation design is documented under GSE126045.

## Contents

- `manifests/dataset_manifest.tsv`: suitability, source access, licenses, labels, pairing, and limitations.
- `manifests/*samples.tsv`, `GSE248249_pairs.tsv`, `GSE126045_patient_matches.tsv`: reproducible sample/patient crosswalks.
- `manifests/file_inventory.tsv`: source URLs, bytes, and SHA-256 hashes of local evidence.
- `scripts/download_data.py`: bounded acquisition of public metadata and optional small processed matrices.
- `scripts/audit_metadata.py`: rebuilds manifests and verifies downloaded expression files, without hypothesis testing.
- `results/tables/matrix_integrity.tsv`, `results/reports/audit_summary.json`: actual audit outputs.
- `docs/`: scientific rationale, decision report, methods status, limitations, reproducibility, and learning log.

## Run the audit

Requires Python 3.11+ and internet access to NCBI FTP/HTTPS. **No third-party Python packages are required for this audit.** Python 3.13.15 and the bundled Python 3.12.14 were checked locally. No analysis environment was installed.

From the extracted project directory, preview the bounded retrieval plan:

```powershell
python scripts/download_data.py --small-matrices --comparison-matrix --additional-metadata --list
```

Reproduce the reviewed audit:

```powershell
python scripts/download_data.py --small-matrices --comparison-matrix --additional-metadata
python scripts/audit_metadata.py
python -m unittest discover -s tests -v
```

The first command downloads approximately 25 MB of processed expression plus small metadata files. Metadata-only acquisition is the default when flags are omitted. The single-cell matrix, raw sequencing, CEL/IDAT archives, and controlled-access datasets are not selected by any default command. Per-resource byte caps stop unexpectedly large responses. Existing source files are replaced only after complete validated retrieval; failure returns a nonzero exit code and is logged.

The optional `--paper-metadata` flag tries publication sample tables. Those endpoints returned non-XLSX responses in this audit; these tables are not prerequisites for the verified GEO audit. No author requests or approvals are assumed. If an independent reviewer lacks network access, the included metadata can be parsed, but complete expression-file checks require the downloaded matrices.

## Design and release gate

The research lead selected acquired resistance with GSE248249. Stage B should begin with full array annotation and batch/site QC; infer candidate modules only if those checks support the comparison. Resolve mixed/unspecified histology for the comparison cohort when defining its contrast. Genomics remains cross-cohort context unless legitimate matched access becomes available. See `configs/design_status.json`.

The source matrix filenames do not establish units: GSE156054's file is TPM despite “Raw_gene_counts” in its name; GSE207422 is log2(TPM+1); GSE248249 is SST-RMA intensity. Three different treatment states must not be pooled. Existing pathways are reference biology, not automatically new FMSIs.

## Submission planning

The [official hackathon page](https://2026.genedis.org/hackathon/) states October 31, 2026 as the deadline, with November 10 selection and November 21 presentation. The exact cutoff time/timezone and registration-specific template have not been confirmed. No correspondence, registration, upload, or submission was performed. The current compressed bundle is an audit handoff, not a final entry.

Large source datasets are excluded from version control and from the audit archive. Dataset terms remain separate from project code licensing; `LICENSE` records that a release license has not been selected. All present scientific outputs are metadata/integrity findings. There are no discovery or validation results to interpret yet.
