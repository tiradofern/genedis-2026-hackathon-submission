# Official Nextstrain Auspice runtime

This prototype runs the **unmodified official Nextstrain Auspice application**, locally on `http://127.0.0.1:4000`. It is not a substitute interface. The custom code converts published lung-cancer reconstructions into Auspice datasets and launches the official distribution; it does not infer a new evolutionary tree or connect different patients by ancestry.

## Pinned software

Verified October 18, 2026 against the official npm registry:

| Component | Version / provenance |
| --- | --- |
| Auspice | `3.1.0`, exact dependency in `nextstrain/package.json` |
| Package origin | `https://registry.npmjs.org/auspice/-/auspice-3.1.0.tgz` |
| Package integrity | `sha512-ixvpMmOsR+HOu2xytNcA20KeJfSCESyqnKcjrAUtT5K07aNwJsvqySGqQomPNyJ1tvzdnX/aYqIRODzyzkCFGQ==` |
| Dependency lock | `nextstrain/pnpm-lock.yaml` |
| Package manager | pnpm `11.25.0` |
| Node.js used | `24.19.0`; Auspice declares support for Node 24 or 26 |
| Auspice license | `AGPL-3.0-only`, retained in its package's `LICENSE.txt` |

The npm distribution includes the compiled server (`cli-build/`) and client (`dist/index.html`, hashed JavaScript bundles). They were installed without dependency lifecycle scripts; rebuilding upstream is unnecessary for this demonstration. No upstream source has been modified. Source-data terms and the project's pending release license remain separate from Auspice's license.

Official references: [Auspice installation](https://docs.nextstrain.org/projects/auspice/en/stable/introduction/install.html), [source repository](https://github.com/nextstrain/auspice), [server API](https://docs.nextstrain.org/projects/auspice/en/stable/server/api.html).

## Start or reopen

From the repository root in PowerShell:

```powershell
& '.\Start Nextstrain.ps1'
```

Open [the local app](http://127.0.0.1:4000). The launcher uses Node on `PATH`, then the existing Codex bundled runtime if available. A different installation can be supplied explicitly:

```powershell
& '.\Start Nextstrain.ps1' -NodePath 'C:\path\to\node.exe'
```

By default it starts a hidden background process, verifies `/charon/getAvailable`, and writes PID/state and logs under `nextstrain/.runtime/`. A repeated start recognizes its existing process. If another process occupies port 4000, select `-Port 4001`; the launcher does not stop unrelated processes. To keep the server attached to the current terminal and stop it with Ctrl+C, use `-Foreground`.

Stop a background instance with `& '.\Stop Nextstrain.ps1'` (or pass the matching `-Port`). This verifies the saved project, PID and process start time before stopping that process. `-WhatIf` performs the identity checks without stopping it.

The launcher fixes `HOST=127.0.0.1`. It passes the `nextstrain/datasets` and `nextstrain/narratives` directories to the official `auspice view` CLI. The application scans datasets live, so regenerated data do not require a server rebuild. Auspice exposes filenames with underscores as URL paths; for example, `lung_example.json` appears at `/lung/example`.

When executing inside Codex, local socket access and durable background processes may require its approved unsandboxed execution. A successful server log alone is insufficient verification: check the endpoint and the actual browser after the launch command returns.

## Reinstall locally

Use Node.js 24 or 26 and pnpm `11.25.0`, then run in `nextstrain/`:

```powershell
pnpm install --frozen-lockfile --ignore-scripts --store-dir .pnpm-store
```

On the machine used for this proof, the already bundled package manager can be called without a global install:

```powershell
$runtimeRoot = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node'
$nodeExecutable = Join-Path $runtimeRoot 'bin\node.exe'
$env:PATH = (Join-Path $runtimeRoot 'bin') + ';' + $env:PATH
& $nodeExecutable (Join-Path $runtimeRoot 'node_modules\pnpm\bin\pnpm.cjs') install --frozen-lockfile --ignore-scripts --store-dir .pnpm-store
```

`node_modules/`, the local package store, source downloads, generated datasets, PID state and logs stay outside Git. The lockfile pins package versions and integrity. Source reconstruction provenance and biological limitations are recorded separately in the dataset and prototype guide; a working runtime is not evidence that a published tree is accurate or that population-level NSCLC evolutionary ordering has been established.

## Runtime checks performed

- Installed Auspice `3.1.0` locally with lifecycle scripts disabled and confirmed its declared license/version and prebuilt client/server artifacts.
- Started the unmodified server with its official CLI and explicit loopback host.
- Confirmed HTTP 200 from `/`, `/charon/getAvailable`, and the official hashed main JavaScript bundle.
- Confirmed the listener was `127.0.0.1:4000`, and that the background process survived completion of the launch command.

The final dataset checks and actual interactive browser assessment are recorded with the prototype; these runtime checks alone do not verify scientific content.
