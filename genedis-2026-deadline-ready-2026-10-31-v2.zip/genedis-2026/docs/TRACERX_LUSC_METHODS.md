# Separate TRACERx squamous population-order analysis

The investigator explicitly selected **adenocarcinoma and squamous analyses separately**. This is the additional LUSC analysis. The completed LUAD configuration, source export, original analysis scripts, runtime lock, fitted model, aggregate result and native datasets remain unchanged. Neither cohort is pooled or used to tune the other's model. Different selected edges across these separately fitted, differently sized cohorts do not constitute a formal histology interaction test.

The LUSC analysis does **not establish a reliable common evolutionary route**. The unchanged genuine ASCETIC implementation selected three exploratory dependencies, but none reached the frozen 80% bootstrap display criterion or passed the adjusted source-ordering test. One selected direction has a single compatible evaluation-patient ancestry observation; this is not replicated route validation. Held-out reported-event prediction is slightly worse than independent-event marginals.

## Frozen candidate universe and cohort

[tracerx_routes_lusc_v0_1.json](../configs/tracerx_routes_lusc_v0_1.json), SHA256 `27a8f619cb39f8a807c569eee4f0a374c80af6bd061572cdda00bf7e530f30b8`, was frozen before LUSC candidate frequencies, pair results or model fits were inspected. Eligibility was determined from source histology, patient/tumour identity and region metadata beforehand. The source export and exact-byte source/configuration/auditor snapshots were separately locked before fitting.

The fixed external candidate universe is the **ten genome-wide MutSig FDR Q<0.1 genes explicitly listed in printed page 520 and Figure 1** of TCGA Research Network, *Comprehensive genomic characterization of squamous cell lung cancers*, Nature 489, 519–525 (2012), [doi:10.1038/nature11404](https://doi.org/10.1038/nature11404), [author-hosted published PDF](https://compbio.hms.harvard.edu/publications/pdf/nature11404.pdf). They are TP53, CDKN2A, PTEN, PIK3CA, KEAP1, MLL2, HLA-A, NFE2L2, NOTCH1 and RB1. The abstract says eleven whereas the explicit text and figure contain ten; we use that explicit ten-gene list and do not invent an eleventh candidate. The separate COSMIC-restricted secondary analysis is outside this frozen universe.

The only allowed candidate-symbol normalization is **MLL2 → KMT2D**. HGNC records KMT2D (HGNC:7133) with previous symbol MLL2 ([authoritative HGNC record](https://rest.genenames.org/fetch/hgnc_id/HGNC:7133)); [NCBI human Gene 8085](https://www.ncbi.nlm.nih.gov/gene/8085) independently identifies the locus. The source exporter preserves every literal `raw_source_gene` alongside the canonical analysis gene. No variant coordinate, allele or cluster mapping is changed by symbol normalization, and no broad alias merger is performed.

The same published TRACERx421 reconstruction deposit is used: Karasaki et al., *Evolutionary characterization of lung adenocarcinoma morphology in TRACERx*, Nature Medicine (2023), [doi:10.1038/s41591-023-02230-w](https://doi.org/10.1038/s41591-023-02230-w), [Zenodo 7683605](https://zenodo.org/records/7683605). Its deposited tumour trees include LUSC as well as LUAD. Academic/noncommercial source restrictions remain separate from software licenses. These are existing authors-inferred phylogenies and curated variants; this analysis does not reconstruct trees from raw sequencing reads.

Of 129 deposited source-labelled LUSC tumours, four belong to patients with multiple deposited tumours across any histology and are excluded. The resulting **125 independent single-tumour patients** each have at least two distinct primary R regions. Lymph nodes do not count toward that eligibility gate; the full same-surgery source tree, including recorded lymph nodes, is retained. Per-patient neoadjuvant status is unavailable and is not imputed.

All deposited alternatives pass the same source structural checks. Among the eligible LUSC patients, 21 have one deposited topology and 104 have multiple alternatives. Two use the exact source singleton self-sentinel encoding, normalized to one retained mutation cluster with no intercluster edge; no arbitrary self-loop removal or mutation chain is introduced. Alternatives and regions are not counted as independent patients.

The independent deterministic SHA256 patient ordering uses salt `tracerx-lusc-route-v0.1|`. Seventy percent training rounded to the nearest integer, with exact halves rounded up, gives **88 training and 37 evaluation patients**. This is consistent with the previous 217→152 LUAD allocation. No gene, outcome, source order or fitted result determines the split. The two eligible histology cohorts contain disjoint patients.

## Events, source order and genuine inference

Events use only source authors' `DriverMut == TRUE` mutation records. The exact tumour/chromosome/position/reference/alternate-allele join and retained-cluster mapping are identical in principle to the LUAD analysis. All curated hits in a gene must map unambiguously to one retained cluster before that gene can cast an ordered vote. Same-cluster, separate-branch, topology-ambiguous, repeated-gene and failed/removed-mapping observations remain unresolved categories. A zero means no reported curated driver mutation, not verified wild type, locus callability or functional absence. CNA, methylation and fusion-only alterations do not become mutation events.

The frozen training gate requires at least ten carriers and ten noncarriers, without relaxation after viewing counts. Every passing candidate is retained:

| Candidate | Training carriers / noncarriers | Included |
|---|---:|---|
| TP53 | 76 / 12 | Yes |
| CDKN2A | 15 / 73 | Yes |
| PTEN | 9 / 79 | No |
| PIK3CA | 14 / 74 | Yes |
| KEAP1 | 6 / 82 | No |
| KMT2D | 16 / 72 | Yes |
| HLA-A | 0 / 88 | No |
| NFE2L2 | 12 / 76 | Yes |
| NOTCH1 | 5 / 83 | No |
| RB1 | 5 / 83 | No |

Failure of this gate is not negative biological evidence. In particular, zero HLA-A curated events is not evidence of no HLA alteration or no immune-evasion mechanism.

Primary evidence is the complete **ten unordered gene-pair table**. Each co-carrier patient receives one mutually exclusive source category, and a strict ancestral direction requires agreement across every deposited alternative. This is ancestor closure, which can contain intervening clusters, not necessarily adjacent next-mutation transitions. The source evidence is not forced into an acyclic population graph.

The secondary model uses exactly the unchanged **ASCETIC 1.2.0** implementation, upstream commit `e6bc7f5214ce5eae015ca9ef9d13dbfdc756c5fa`, installed and locked for the prior LUAD analysis. No reinstallation, package patch, algorithm substitution or new compiler installation is needed. The original `prepare_inputs.py`, `evidence.py`, `run_ascetic.R` and `run.py` remain byte-exact. The additive [run_lusc.py](../tracerx_routes/inference/run_lusc.py) calls their pure preparation/evidence functions and the same original R entrypoint, with explicit LUSC identity, separate destinations, literal-gene alias checks and required source-freeze checks. Its own hash and all reused code/runtime hashes are included in the new model and exact-byte reproducibility snapshots.

The actual call remains `ASCETIC::asceticPhylogenies(dataset, models, regularization="aic", command="hc", restarts=0)`, with frozen seed 20261018. Each patient supplies one named strict-consensus ancestor-closure matrix; present genes with unresolved order remain named zero-relation nodes. This is the same documented conservative consensus partial-order adaptation, not a uniquely resolved mutation tree or a validated ASCETIC method extension. Full selected parent sets, all selected edges and engine output are retained.

All **100/100 whole-patient bootstrap fits** and **100/100 within-patient label-shuffle engine-null fits** completed. The primary ordering null uses 10,000 permutations and one-sided +1 Monte Carlo p values, with BH across **all twenty ordered eligible-gene directions**, including model-unselected directions. It preserves reported carrier sets and within-patient unique-placement resolution; repeated/unmapped gene identities remain fixed. Its label-exchangeability assumption and ascertainment limitations remain explicit. A bootstrap fraction describes model-selection stability, not the probability that a chronology is true.

## Actual results and limits

The complete aggregate evidence is [lusc_results_summary.json](../tracerx_routes/inference/lusc_results_summary.json). Final local model SHA256 is `2cb08b9ac6a022cf5e3b0280c1e4c3f0b78d7a8b7150d6b14191c20ba886a1c2`.

| Selected model dependency | Training strict forward / reverse / all co-carriers | Other training categories | Bootstrap | Engine-null selection | Ordering p / BH q | Evaluation evidence |
|---|---:|---|---:|---:|---:|---|
| CDKN2A → PIK3CA | 2 / 0 / 5 | One same-cluster, two mapping-ambiguous | 64/100 | 30/100 | 0.1122 / 0.9516 | No co-carriers |
| NFE2L2 → PIK3CA | 1 / 0 / 4 | Three same-cluster | 51/100 | 27/100 | 0.3312 / 0.9516 | Two co-carriers, both mapping-ambiguous; zero resolved |
| CDKN2A → KMT2D | 1 / 0 / 5 | Four same-cluster | 45/100 | 30/100 | 0.3322 / 0.9516 | Two co-carriers: one compatible strict ancestry, one same-cluster |

None of the twenty directional tests has BH q<0.05. No selected edge reaches 80% bootstrap selection. The one compatible evaluation ancestry observation for CDKN2A → KMT2D is a single patient, with one other evaluation co-carrier unresolved and sparse training order; it does not establish a replicated common route. The descriptive 95% Wilson interval for directional agreement conditional on its one resolved evaluation observation is approximately [0.207, 1.000], alongside the full two-co-carrier denominator.

Across all eligible pairs there are 75 training **patient-pair votes**: twelve strict directions, 56 same-cluster, one repeated-gene ambiguity and six mapping ambiguities. Evaluation has 26 patient-pair votes: three strict directions, nineteen same-cluster and four mapping ambiguities. Patients recur across different gene pairs; these totals are not independent-patient denominators. No eligible pair in this subset has an incomparable or topology-ambiguous observation, which does not establish that the underlying tumour topologies are unique.

Training-only Beta(1,1) joint-event CPTs score the 37 locked evaluation patients at **−80.744476**, versus **−80.600786** for independent training marginals: difference **−0.143690** overall, or **−0.003884 nats per evaluation patient**. There is no evaluation refit or model choice. PIK3CA retains both selected parents, CDKN2A and NFE2L2; a two-parent conditional distribution is not automatically an AND gate. This score checks reported-event cooccurrence prediction, not temporal truth, clinical prediction or survival.

Source-resolved order adds information beyond a prevalence-only model, but same-cluster resolution, variant mapping, sparse co-carriers, sampling and modelling assumptions limit this first slice. These findings do not validate causal cooperation, universal progression paths, resistance routes, survival signatures or functional/clinical tiers. The LUAD and LUSC fits remain exploratory and separate.

## Reproduce and verify

After reproducing the separately frozen source export described in the source guide, use the existing locked runtime:

```powershell
python tracerx_routes/inference/run_lusc.py
python -m unittest discover -s tracerx_routes/inference -p test_lusc_inference.py -v
```

Explicit `--config`, `--source`, `--output` and `--aggregate` arguments are available; the wrapper requires a LUSC configuration and refuses the immutable LUAD source, output and aggregate destinations. Each source/configuration/audit snapshot must match the pre-fit export lock. Runtime defaults reuse the local R4.5.1 installation and unchanged pinned libraries. Raw source data, patient-level outputs, RDS objects and runtime dependencies remain ignored; only aggregate evidence and code are versioned.

A provenance-only correction after the actual fit made the LUSC frozen-audit filename mandatory rather than silently omitting its hash. The complete engine-input and configuration bytes were verified unchanged against their actual R-output MD5s before reusing the genuine fit; the same fixed ordering assessment was regenerated, and snapshots now match finalized wrapper bytes. No events, patients, directions, parameters or fitted results changed.

**Nine new inference checks pass**: disjoint independent cohorts and frozen roles; the complete ten-candidate training gate; exact source-gene retention and aliasing; every patient vote rederived from separately exported strict/possible ancestor closures; all twenty directional nulls reproduced and BH checked; genuine engine input identity and all successful fits; full selected parent sets; training-only CPT immutability; exact frozen/source/code snapshots; and LUAD overwrite guards. An independent source review additionally compares the official fitted RDS's 88 training rows, all named patient order matrices, excluded evaluation IDs and original numeric event-index edges. These are reproducibility and source-fidelity checks, not biological validation.
