# First population-level NSCLC event-model pilot

This investigator-authorized next step uses the project's current audited public TCGA data, rather than the TRACERx demonstration. The first inference is within the source-labeled LUAD cohort. LUSC is audited separately; its patients are not pooled into the LUAD model.

The analytical object is a probabilistic graph of reported gene events across independent participants. It is not a clonal tree connecting different patients, a normal-to-tumor developmental history, a measured timeline, or a model of acquired treatment resistance.

## Data and method decision

The current source files provide mutation read counts and source-level somatic mutation profiles, but no mutation cancer-cell-fraction (CCF) annotations. Categorical GISTIC calls are not absolute locus-specific copy number. The public ABSOLUTE segment fields describe copy-number-state fractions, not point-mutation CCF. The annotated mutation CCF MAF is controlled access; no controlled payload was requested. The current mutation barcodes identify tumor sample keys, not the complete mutation aliquot. These inputs therefore do not pass the present gate for an ASCETIC CCF-based model. See `POPULATION_ROUTE_DATA_AUDIT.md`.

For the first runnable population model, use the genuine published **CAPRI** implementation in **TRONCO 2.40.0**, with the existing R 4.5.1 runtime and a separately pinned local package library. CAPRI is designed for cross-sectional event data. Its temporal-priority interpretation depends on event persistence, prevalence as a proxy for priority, detection assumptions, and cohort comparability. Selected edges describe assumption-based statistical selectivity/conditional dependencies. They do not establish causal mechanisms or prove that one event occurred earlier in an individual tumor.

The primary method paper is Ramazzotti et al., *CAPRI: efficient inference of cancer progression models from cross-sectional data*, Bioinformatics 31, 3016-3026 (2015), [DOI 10.1093/bioinformatics/btv296](https://doi.org/10.1093/bioinformatics/btv296). The candidate gene universe is the 18 significantly mutated genes in TCGA Research Network, *Comprehensive molecular profiling of lung adenocarcinoma*, Nature 511, 543-550 (2014), [DOI 10.1038/nature13385](https://doi.org/10.1038/nature13385).

## Frozen design and input correction

`configs/population_routes_v0_1_1.json` is the active configuration. The initial `v0_1` configuration is preserved as an audit record. Its per-row `Mutation_Status == Somatic` predicate could not apply: input schema QC found every source value was missing (`.`). Before any candidate gene frequencies or fitted edges were inspected, version 0.1.1 removed that impossible predicate and retained verified source-callset provenance. The VEP `SOMATIC` field was not substituted because it annotates existing database variants, not the call status of the current specimen. The before-fit correction and hashes are in `population_routes/config_freeze_2026-10-18.json`.

Events are source-reported PASS protein-altering variants, aggregated to a gene-event indicator. This does not mean every included variant is a functional driver. No qualifying reported event is not verified wild-type or proof of adequate locus-level callability. Mutation-assay coverage is required; unknown assay status is not encoded as zero. Four mutation-profiled LUAD samples have no mutation rows and remain represented with that status explicit.

The existing participant roles remain fixed: 507 source-labeled LUAD participants, 354 training and 153 evaluation. Gene eligibility is evaluated only in training: at least 20 carriers and 20 noncarriers. Eleven candidate events meet the frozen gate: TP53, KRAS, KEAP1, STK11, EGFR, NF1, BRAF, SETD2, RBM10, MGA and SMARCA4. The seven other candidate genes remain documented as outside this pilot's eligibility gate; their absence from the fitted graph is not a negative biological finding.

No outcomes, stage, RNA-program scores, or evaluation participants select the genes, graph or settings. The model uses BIC/hill-climbing and 100 internal CAPRI bootstrap replicates. It is assessed with 100 patient bootstrap fits, 100 column-permutation fits within training reported-protein-altering-mutation-count quartiles, and held-out prediction against an independent-event baseline. The burden measure is a reported mutation count, not mutations per megabase. Bootstrap stability, null comparisons and predictive performance have distinct meanings; none proves chronology. All selected edges remain exploratory.

## Newly identified pathology-quality flags

The official historical sample-quality resource has exact ABSOLUTE-aliquot annotations for 491 of the 507 source-labeled LUAD cases. It flags 52 for pathology exclusion: 38 `NSCLC, NOS - to be excluded` and 14 `NSCLC, favor LCNEC; to be excluded`. Another 439 are mapped without that flag, and 16 are unmapped/unknown. Neither a source LUAD label nor absence of a recorded exclusion is a new pathology adjudication.

The investigator explicitly selected preserving the original 507-case baseline and adding a separately specified sensitivity analysis excluding only the 52 known flags. Its remaining 455 participants retain their original roles: 316 training and 139 evaluation; the 16 quality-unknown cases stay explicitly unknown. The sensitivity retains the baseline training-selected event universe without gene reselection. It uses the same engine and assessment settings. Its design was recorded before the first model fit in `configs/population_routes_pathology_sensitivity_v0_1.json`.

The two results must be reported side by side. Evaluation performance is not used to choose a preferred model. Four training cases also have source neoadjuvant-therapy notifications and remain in both analyses; untreated natural history is not established. Any subsequent investigator change to the primary scientific cohort should be recorded explicitly, with the earlier runs retained as dated exploratory analyses.

## Application and scientific scope

`POPULATION_ROUTE_VIEW.md` describes the authoritative exact-DAG companion and the genuine Auspice edge-forest view. The native edge view preserves all selected relations but duplicates event variables as display copies; it is not a route tree or a patient phylogeny. Its unitless layout coordinates are not mutation counts or time. The published TRACERx demo retains its separate biological and distance semantics.

This step performs no survival testing, clinical prediction, new RNA-module discovery, island tier assignment, or functional validation. Gene aggregation, missing locus-level callability, source histology, tumor heterogeneity, detection differences, smoking/exposure, mutation burden and other unmeasured factors remain material limits on evolutionary interpretation. The quality sensitivity and burden-stratified null address specific concerns, not every possible confounder.

Reproduction instructions and results are recorded in `POPULATION_ROUTE_METHODS.md`. Raw patient-level artifacts and runtime dependencies remain local and Git-ignored. Source versions, hashes, configuration and software dependencies remain auditable.

## Baseline results and interpretation

The genuine engine selected TP53 → NF1, KRAS → STK11 and KEAP1 → SMARCA4. Across 100 successful patient bootstrap fits, these relations were selected 51%, 69% and 49% of the time. None reached the prespecified 80% display-stability threshold. Burden-stratified positive-association permutation BH q-values across all 110 ordered pairs were 0.7261, 0.5446 and 0.5446; none was below 0.05. The complete graph edge-count comparison against the specified null had p = 0.1089.

On 153 held-out cases, the frozen graph improved joint log probability over training-fitted independent events by 0.03031 nats per participant; the conditional descriptive 95% interval was −0.00712 to 0.06774. It includes zero and does not account for model-selection uncertainty. Every selected edge remains displayed despite these weak assessments. This is a working inference and visualization pipeline with exploratory relations, not evidence that stable evolutionary routes have been established. The pathology sensitivity is reported alongside it in the methods guide.

The 455-case pathology sensitivity selects only KRAS → STK11, with 74% bootstrap selection and burden-stratified permutation BH q = 0.7624. Its 139-case held-out mean gain is 0.02554 nats/participant, conditional descriptive 95% interval 0.00048 to 0.05059. This conditional predictive result does not establish chronology or overcome the stability/null limitations. Its graph edge-count null comparison is p = 0.7723. The baseline's other two relations are not selected in this sensitivity; no model is chosen using evaluation results.
