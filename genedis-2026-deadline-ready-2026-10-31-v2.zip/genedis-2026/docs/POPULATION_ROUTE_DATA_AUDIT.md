# NSCLC population-route input audit

October 18, 2026. This audit inspects the existing cohort's actual mutation files, frozen specimen roles, ABSOLUTE purity, public allele-specific segments, and source sample-quality annotations. It performs no evolutionary inference and changes no cohort membership, event definition, or training/evaluation assignment.

**The data support a technically feasible, explicitly assumption-based cross-sectional mutation-event progression pilot. They do not currently provide verified mutation CCF or directly observed event chronology.** A CAPRI result is a statistical selectivity model under stated assumptions. A successful visualization does not establish ancestry between unrelated patients.

## Fixed universe and actual mutation coverage

The input universe is exactly the original prepared explorer cohort, cross-checked against `manifests/public_tcga_samples_2026-10-17.tsv` and the original `data/processed/explorer_v0_1/bootstrap.json`. The prepared fingerprint is recorded in the machine-readable report. All participants remain independent; no additional TCGA cases are imported to improve counts.

| Audit quantity | LUAD | LUSC |
|---|---:|---:|
| Existing core participants/sample keys | 507 | 481 |
| Frozen training / evaluation | 354 / 153 | 336 / 145 |
| Participants with one or more original MAF rows | 503 | 466 |
| Mutation-profiled participants without MAF rows | 4 | 15 |
| MAF rows within the exact existing core | 203,720 | 183,483 |
| Source rows outside that core, excluded from this export | 21,933 | 1,584 |
| Core rows with valid tumor reference/alternate read counts | 203,720 | 183,483 |
| Core rows with positive alternate counts | 203,720 | 183,483 |
| Reported `t_depth` equals `t_ref_count + t_alt_count` | 139,961 | 123,596 |
| Reference + alternate depth at least 20 | 193,421 | 174,055 |
| Reference + alternate depth at least 50 | 142,679 | 129,869 |
| Alternate count at least 3 | 203,588 | 183,339 |
| Valid tumor read counts and available valid purity | 201,744 | 183,177 |
| Source `FILTER == PASS` rows, before classification/event filtering | 194,747 | 170,866 |
| Duplicate exact sample/build/locus/reference/alternate rows | 0 | 0 |
| Valid ABSOLUTE purity and ploidy at sample-key level | 497 | 476 |
| Standard 28-character ABSOLUTE aliquot barcodes | 491 | 465 |
| Source-provided mutation CCF rows in current MAF | 0 | 0 |

All 387,203 core MAF rows have GRCh37 coordinates, nonmissing reference/alternate alleles, and valid nonnegative integer tumor counts with positive total and alternate count. These checks do not establish sensitivity or locus-level callability. Profiled samples without rows remain in the fixed universe, annotated explicitly; absence of a qualifying reported event is not verified wild type. Unknown assay status must never be converted into an event-negative observation.

Both MAFs have 114 columns. Every core `Tumor_Sample_Barcode` is only a 15-character TCGA sample-type key. No CCF, mutant multiplicity, allele-specific absolute copy number, purity, ploidy, mutation UUID or full mutation-aliquot field is present. The ABSOLUTE table sometimes provides a study-specific tumour label rather than a standard aliquot barcode; these values are preserved without inventing missing barcode components. Its source call statuses also differ: LUAD has 489 `called`, seven `maf_call`, one `snp_call`, and ten missing; LUSC has 465 `called`, six `maf_call`, five `snp_call`, and five missing. These labels are retained rather than assumed to have identical timing quality.

The reported `t_depth` differs from reference + alternate read count in 63,759 LUAD and 59,887 LUSC rows. Both source fields are retained separately. This audit neither chooses one as the other's replacement nor interprets their difference as proof of poor calls. A future read-count likelihood must specify and validate its depth definition.

## Schema and event-quality findings before fitting

The MAFs contain `PASS` and several other source filters, including `oxog`, `common_in_exac`, `nonpreferredpair`, `wga`, `native_wga_mix`, and combinations. An event matrix must use the frozen source-filter rule explicitly rather than count every imported row.

**Every source `Mutation_Status` value is `.`**, including rows outside the core. A predicate requiring the literal value `Somatic` would therefore produce an artificial all-zero matrix. This was identified and reported before any gene-event frequency selection or model fitting. Raw exports preserve the missing value; they do not fill it with `Somatic`.

The separate `SOMATIC` field must not be substituted as a current-specimen call-origin flag. It is a VEP annotation of somatic status for existing variants and can contain comma-separated database annotations. Among core rows, 100,385 LUAD and 63,384 LUSC rows have an existing somatic annotation; 103,335 and 120,099 respectively lack it. [GDC VEP field definitions](https://docs.gdc.cancer.gov/Data/File_Formats/VCF_Format/).

The mutation profile's published source and cBioPortal file-level provenance must therefore be stated separately from the missing row annotation. The pinned `meta_mutations.txt` files describe the whole-exome mutation profiles. The pilot's source-reported mutation events are not a new independent somatic-call validation, and the missing field cannot justify selecting only database-known variants.

The historical root-owned `configs/population_routes_v0_1.json` froze the candidate genes, nine protein-altering classification categories, source filter, and absence semantics. Before the first fit, `configs/population_routes_v0_1_1.json` explicitly corrected the missing row-status predicate and recorded file-level somatic-callset provenance. It leaves the gene universe and other scientific rules unchanged and excludes neither database-unknown variants nor rows solely because their row status is missing. This audit exports raw rows and does not change those rules. The methods component prepares the binary matrix, burden counts, and frozen training-only selection from the amended configuration.

## Public allele-specific copy number: available but insufficient for mutation timing

The official [GDC PanCanAtlas publication page](https://gdc.cancer.gov/about-data/publications/pancanatlas) and its [open-access manifest](https://gdc.cancer.gov/system/files/public/file/PanCan-General_Open_GDC-Manifest_2.txt) identify the public processed `TCGA_mastercalls.abs_segtabs.fixed.txt`. The 253,061,161-byte download matched official MD5 `585c8793730f294d7bf0144566bb37fa`; its SHA256 is pinned in `population_routes/source/public_source_manifest.json`.

It includes `Modal_HSCN_1`, `Modal_HSCN_2`, `Modal_Total_CN`, subclonal allele copy-number states, and `Cancer_cell_frac_a1/a2` with confidence intervals. The latter describe **copy-number subclones**, not the MAF's point-mutation CCF. They cannot be copied into a mutation CCF matrix.

| Public segment feasibility quantity | LUAD | LUSC |
|---|---:|---:|
| Existing core samples with segment rows | 498 | 478 |
| Core segment rows | 74,486 | 80,841 |
| Modal diploid segment rows, 1 + 1 = 2 | 15,915 | 15,159 |
| Invalid segment coordinate rows | 2 | 0 |
| Adjacent source segment overlaps identified | 4 | 8 |
| Core MAF rows with numerical coordinate overlap | 186,802 | 170,738 |
| Core MAF rows numerically overlapping modal diploid segments | 45,990 | 46,477 |
| Core MAF rows without numerical coordinate overlap | 16,918 | 12,745 |

These overlap counts are a **feasibility calculation**, not a validated variant-to-absolute-copy-number mapping. The segmentation header does not state its reference assembly; common-coordinate compatibility has not been independently established here. It uses sample keys rather than full mutation aliquots, and limited source segment overlaps exist. No genotype/cross-platform concordance or timing-quality analysis was performed. Modal 1+1 copy number does not prove the absence of minor subclonal copy-number states or establish mutant multiplicity.

The existing explorer's GISTIC matrix is a separate discrete gene-level assay. Its source metadata define ordinal values -2 through 2; neither neutral 0 nor any other GISTIC category supplies absolute locus copy number. No VAF-to-CCF calculation or diploid assumption was applied.

The directly annotated mutation resource `TCGA_consolidated.abs_mafs_truncated.fixed.txt.gz` is listed in the official [controlled-access manifest](https://gdc.cancer.gov/system/files/public/file/PanCan-General_Controlled_GDC-Manifest.txt), UUID `4d34ef36-dd77-4d6d-9e65-c4f51ae09c23`. Its size is 1,204,979,698 bytes. Only the tiny public manifest was read; no controlled payload or credentials were requested. The Cell-of-Origin landing page's unlinked filename is not an open-access grant.

The public original MC3 MAF could potentially restore full mutation aliquot labels through a separately verified exact-variant/read-count join. That large additional retrieval was not needed for the present cross-sectional pilot and was not performed. It would still not by itself supply mutation CCF or validate a multiplicity model.

## Newly inspected historical pathology and quality annotations

The public 8,463,670-byte `merged_sample_quality_annotations.tsv` matched its official MD5 and the pinned SHA256. Exact ABSOLUTE-aliquot joins were possible for 491 LUAD and 465 LUSC core samples. No quality flags were guessed for unmatched records.

The matched historical annotations flag **52 existing LUAD-labelled core specimens** for pathology exclusion: 38 as `NSCLC, NOS - to be excluded`, and 14 as `NSCLC, favor LCNEC; to be excluded`. They limit any claim that all 507 existing LUAD-labelled samples have independently confirmed LUAD histology. This audit does not adjudicate those annotations or silently remove these participants.

| Cohort and frozen split | Mapped, not flagged | Flagged | Unknown mapping | Total |
|---|---:|---:|---:|---:|
| LUAD training | 305 | 38 | 11 | 354 |
| LUAD evaluation | 134 | 14 | 5 | 153 |
| LUSC training | 325 | 1 | 10 | 336 |
| LUSC evaluation | 139 | 0 | 6 | 145 |

Here `flagged` means a matched source pathology-exclusion flag or current `Do_not_use=True`. All 52 LUAD flags are pathology flags; no matched LUAD aliquot has current `Do_not_use=True`. The single LUSC flag is `Do_not_use=True`; no matched LUSC aliquot has an AWG pathology-exclusion flag. `Mapped, not flagged` is not a new pathological confirmation.

One LUAD and three LUSC aliquots also retain older DNU narrative annotations, but all four have an updated annotation stating the pipeline's level-3 data are acceptable and current `Do_not_use=False`. They are not counted as new current DNU flags. Other source patient notifications include prior or synchronous malignancies and four neoadjuvant-therapy notifications in each cohort. LUSC also contains one notification each for recurrence after submission, molecular analysis outside specification, and a case outside study protocol. These are not new clinical adjudications or automatic exclusion decisions. The raw notes and exact per-sample mappings stay in the ignored export. The versioned audit retains aggregate annotation categories, not those case narratives.

The investigator explicitly selected keeping the original baseline plus a separate sensitivity excluding the 52 known LUAD pathology flags. The baseline, frozen roles and unknown states remain explicit. The sensitivity retains 316 training and 139 evaluation cases, with the same baseline event universe and no reselection; see `POPULATION_ROUTE_METHODS.md`.

## Reproducible outputs and gates

`population_routes/audit_inputs.py` uses the Python standard library and reads the original source cache and prepared bootstrap without changing them. It verifies original mutation and purity hashes against the existing source manifest, checks the exact fixed sample universe and frozen roles, and verifies newly retrieved public input hashes. Raw variant exports are replaced atomically to avoid exposing a partially written file to the methods component.

```powershell
python population_routes/audit_inputs.py `
  --data-root 'C:\Users\tirad\CODEX HOME\Active Projects\A18- GeNeDis 2026\data\external\public_tcga_2026-10-17' `
  --prepared-root 'C:\Users\tirad\CODEX HOME\Active Projects\A18- GeNeDis 2026\data\processed\explorer_v0_1'
```

Add `--download-public` to retrieve only the pinned open ABSOLUTE segments, sample-quality table, and tiny open/controlled access-list metadata. The controlled mutation file is never an input to that downloader. Other users can supply corresponding verified source/prepared paths. Original expression normalization, genes, program scores, and cohort files are untouched.

Versioned outputs are `population_routes/source/input_readiness_audit.json` and `public_source_manifest.json`. Ignored outputs are `source/raw/LUAD_raw_variants.tsv`, `LUSC_raw_variants.tsv`, `cohort_mapping.tsv`, and downloaded public source files. The mapping carries frozen roles, read-count coverage, unaltered ABSOLUTE identifiers, explicit quality-mapping status, raw source flags/reasons, and raw narrative annotations. Source row indices and original fields permit variant tracing without making new timing claims.

The fixed-cohort/mutation-presence preparation gate is technically available under the explicit pre-fit missing-status correction and event configuration. The mutation-CCF and ASCETIC single-biopsy-timing gates remain **not passed**. Purity, read counts and modal absolute copy number are useful ingredients; they do not independently establish mutation multiplicity, uncertainty, exact aliquot linkage, or chronology. Stage, survival outcomes and RNA scores are not used as time.
