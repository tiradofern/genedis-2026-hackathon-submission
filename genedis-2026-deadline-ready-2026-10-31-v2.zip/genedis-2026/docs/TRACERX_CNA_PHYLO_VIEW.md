# CNA-aware patient reconstruction display

The additive local companion at `http://127.0.0.1:4004/` inspects new,
model-derived CNA-only sampled-primary-region reconstructions. LUAD and LUSC
remain distinct contexts. It preserves the previous companions on ports
4001–4003, every published mutation reconstruction and unmodified official
Auspice on port 4000.

## Patient evidence

The histology selector loads the frozen cohort, role denominators, regional
identities and current genuine-result statuses. Patient and prespecified
variant controls load one converted MEDICC2 record. Missing, pending, failed
or technically unavailable results produce an explicit status and no native
tree link. The view never substitutes a mutation tree, another patient or a
synthetic tree. Refresh results reads newly converted evidence without refits.

Successful records are bound to the frozen patient/role/input identities. Every
source input, mapping, genuine model output and converted-record fingerprint is
checked before a patient view or native export is served. The companion's exact
tree preserves every node, parent and minimum CNA-event branch length, including
zero distances. A keyboard-accessible branch table provides the same evidence
as selecting a plotted node. Each tip is a bulk sampled primary region or the
explicit artificial diploid anchor; internal nodes are conditional model
ancestors, never published mutation clusters or verified clones.

The selected patient's arm coverage, missing-base LOH bounds, positive/negative/
unknown carrier states, every acquisition/reversion branch and all placement
flags remain inspectable. An invalid compatible-history check does not prevent
inspection of the genuine region tree, but it leaves WGD carrier/order unknown.
The raw model WGD trace and history flags remain present; flagged native branch
labels explicitly mark placement flags. Changes on one branch remain unordered.
Measured-base counts are calculated from the selected variant's exact mapping,
so high-copy masking cannot inherit a primary-input coverage denominator.

Native projections use separately named ignored files
`nextstrain/datasets/cnaphylo_<histology>_<patient>[_<variant>].json`. They do not
change old `tracerx_*` files. The primary native route is
`/cnaphylo/<histology>/<patient>`; sensitivity variants append their separately
named route segment. Metadata embeds the exact converted record and fingerprint.
The projection checks exact topology, cumulative genuine lengths, regional tips,
the artificial anchor and complete model metadata. No dataset connects patients.
Official Auspice retains its generic horizontal-axis label, “Mutations.” A
visible companion note explains that this axis represents minimum CNA model
events here. Each native dataset title names **minimum CNA-event distance**;
its description explicitly excludes SNV counts and elapsed time. This is a
metadata qualification; official Auspice and all plotted distances stay unchanged.

Source artifacts load on demand. A disclosure exposes the selected record's
exact source/output paths and SHA-256 values, then offers exact-byte downloads.
Requests are confined to the new CNA analysis directories. The server binds
only `127.0.0.1`, uses a restrictive content-security policy and refuses mismatched
cohorts, identities, hashes, categories and output paths.

## Across-patient evidence

The population section reads the separate histology's frozen screen summary.
It reports incomplete screens explicitly, the training-only 10-carrier/
10-known-noncarrier gates, all 45 typed states, unknown counts, every primary
patient category and complete training/evaluation denominators. Same-chromosome
p/q arm pairs are excluded from the primary test family. Exact directional p,
histology-specific BH q and patient-bootstrap sign frequencies are displayed
without calling those frequencies truth probabilities.

The sensitivity table retains disagreement, failure and chromosome-resampling
unresolved states. Qualified order requires agreement across all four
reconstructions and at least 16/20 planned chromosome resamples; failed or unrun
replicates stay in the denominator. Sensitivities remain repeated analyses of
the same patients. The previously inspected evaluation cohort is exploratory,
not external validation. A summary showing adjusted directional asymmetry is
not a claim of reliable biological chronology or clinical utility.

Only the selected pair's hash-bound patient trace file loads on demand. Role
and primary-category filters change visible rows only; they leave aggregate
counts intact. Traces paginate 25 independent patients per page and link back
to the corresponding primary reconstruction. Missing screens never trigger a
relaxed gate, fabricated pair or substitute population model.

## Operation and verification

Launch `tracerx_cna_phylo/visualization/Start CNA TRACERx.ps1`; it starts a hidden
owned loopback process, reuses the same owned server, and refuses to replace
another process on port 4004. Local process metadata and logs stay ignored.
The source tree and scientific outputs remain outside Git.

The implementation extends the established mineral-white, marine-teal, Segoe UI
workstation with existing type, rules, controls and evidence-amber qualification.
It introduces no visual identity, palette or type system. Responsive rules stack
controls and retain contained tree/table scrolling; live mobile behavior requires
separate observation. No motion or decorative assets are required for this
scientific operating surface.

Ten focused display tests passed, covering genuine converted patient outputs
against pinned official Auspice schemas, exact topology/length fidelity,
flagged WGD unknownness, separate routes, no fallback on pending evidence,
identity/configuration rejection, exact per-pair trace hashes, full category
partitions and loopback HTTP behavior. Actual first/last patient-pair traces
from both histologies recount to their source aggregates. The focused
actual-data check subsequently passed on **all 1,368 genuine main-variant
projections** (342 patients times four prespecified variants). Bootstrap
replicates do not substitute for these reconstruction controls.

All 342 genuine primary native datasets were exported (217 LUAD, 125 LUSC).
Successful sensitivity datasets are also generated on demand. Pending records
produce no native tree. Only the new `cnaphylo_*` files were regenerated after
the reviewed unit clarification; no prior `tracerx_*` dataset was altered.
JavaScript syntax passes, and one Impeccable detector pass returned no findings.

The root's bounded desktop batch verified the frozen LUAD/LUSC contexts, a
history-flagged and valid primary patient, high-copy masking with reduced
measured coverage, the total-copy topology diagnostic, exact artifact/hash
disclosures, display filters that preserve aggregate role denominators,
cohort-preserving navigation and a genuine CNA reconstruction in unchanged
Auspice 3.1.0. A material status-wording correction distinguished completed
main reconstructions from pending chromosome uncertainty and was confirmed.
The fresh finish reviewer identified one native-axis unit ambiguity; the
bounded title/note correction was confirmed in the same reviewer's verdict
pass. Its final disposition is **ship**, with no remaining material finding;
see `reviews/cna-phylo-ui-finish-review.md`. The settled route capture retains
the separate LUSC 88/37 category denominators and explicit pending uncertainty.

Desktop proof images live in the local visualization workspace as
`cna-native-luad-clarified.png`, `cna-lusc-units-clarified.png` and
`cna-lusc-route-settled.png`. Live mobile behavior remains unverified. At the
finish review, all 1,368 main fits were complete but chromosome bootstrap
uncertainty was still running; the interface review does not establish
completed uncertainty, robust orders or reliable biological routes.

Final data confirmation after the full fleet and corrected patient-bootstrap screen completed: both histologies display completed reconstruction screens, including all 4,340 LUAD and 2,500 LUSC planned resamples. The one uninformative LUAD slot stays explicit. Full 152/65 and 88/37 category denominators remain visible. The final LUAD route capture is cna-luad-route-final.png in the local visualization workspace. This is a data-readiness confirmation, not another design-review loop or a biological-validation claim.
