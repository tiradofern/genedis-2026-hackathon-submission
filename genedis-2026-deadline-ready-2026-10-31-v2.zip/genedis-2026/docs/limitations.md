# Limitations

The key limitations are small independent sample sizes; mixed anatomic sites in longitudinal specimens; uncertain technical batches; absent histologic subtype annotations in the AR GEO cohort; combination therapy in the response cohort; tissue-composition confounding; unreplicated experimental profiles; unavailable final corrected array data; controlled-access matched exomes; and incomplete additional-cohort matrix/annotation audits.

GSE207422's two assay cohorts overlap in three patients. The bulk cohort contains unspecified NSCLC and a source-labeled Carcinosarcomatoid sample. The Cho RNA cohort has no responders among FFPE samples. No durable-responder comparison is available in the AR expression cohort, so temporal change cannot establish resistance specificity.

Dataset-specific reuse licenses are not established merely by public availability. Analysis-runtime and peak-memory requirements are unbenchmarked. The complete discovery and validation pipeline and final hackathon package are not implemented. None of these audit outputs establish clinical prediction, causation, PHI-handling capability, or treatment recommendations.
