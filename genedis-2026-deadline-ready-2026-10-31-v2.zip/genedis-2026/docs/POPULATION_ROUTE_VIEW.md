# Population event model: exact DAG and Nextstrain edge view

The authoritative visualization is the exact selected statistical event DAG at
`http://127.0.0.1:4001/`. It shows each event once and every selected incoming and
outgoing relation, including merged nodes. Selecting an event reveals its complete
selected-parent set, discovery/evaluation event counts and eligible denominators.
The complete selected-edge table and the method/validation audit remain available
as text alternatives to the graph. No edges are removed by an interactive support
threshold.

The Model selector keeps the baseline (354 discovery / 153 evaluation) and the
separate, investigator-approved pathology-exclusion sensitivity (316 / 139) apart.
Open the sensitivity directly at
`http://127.0.0.1:4001/?model=pathology_sensitivity`. The source model's complete
QC limitations are displayed for each model; this is not a new pathology
adjudication of TCGA specimens. The prominent assessment reports the source
stability criterion, burden-stratified BH q values and the conditional descriptive
evaluation interval. Neither current model has a selected edge meeting the 0.8
bootstrap criterion or BH q < 0.05; the evaluation gain intervals include zero.

This is a population event model under the inference method's assumptions. Nodes
are event variables, not patients, specimens, clones or observed ancestral tumours.
Columns represent dependency depth for display, not elapsed time. Multiple incoming
edges are the fitted joint conditioning set; the display does not turn them into
deterministic AND gates or necessary prerequisites. Reported-event absence retains
the source analysis's detection and missingness limitations.

## Genuine Nextstrain representation

The native application remains official, unmodified Auspice 3.1.0. Its linked view
at `http://127.0.0.1:4000/tcga/luad/population/edges` uses the officially supported
v2 `tree` array (a forest), as permitted by the
[official dataset schema](https://github.com/nextstrain/augur/blob/5b6ddcb26d5aaf1dc9c8991758f404c24e7b0d69/augur/data/schema-export-v2.json).
Each selected source edge is rendered exactly once as
an independent two-event component. Isolated events are represented as singleton
components. Repeated event labels are explicit display copies, never duplicate
patients. The component names are unique; the underlying event IDs remain visible.

This construction preserves all selected relations without choosing one parent,
inventing a shared ancestor or unfolding a multi-parent model into misleading
alternative paths. Each copy retains its complete selected-parent set and its
event-specific observation denominators. Each edge retains the source relation,
direction basis and reported bootstrap/permutation/held-out support fields.
The native popup exposes actual bootstrap selected/successful counts,
burden-null selected/successful counts and frequency, burden-stratified permutation
p and BH q, and training/evaluation probability-raising contrasts where supplied.
Source boolean flags are displayed as explicit “Yes”/“No” strings because the
stock Auspice popup leaves booleans blank; their raw boolean values remain
unchanged in the embedded source model. Descriptive held-out compatibility is not
a calibrated probability of event order.

The native view has a deliberate visual limitation: a merged event is shown in
several separate components; it cannot show the merged DAG or conditioning sets
as one connected graph. The exact DAG companion is authoritative for those
relationships. The complete source model is also embedded unchanged in
`meta.extensions.population_routes.authoritative_model` in the native dataset,
with a source SHA256 and an explicit copy-to-event mapping.

Positions `0 → 1` inside each native component are unitless display coordinates.
They are not mutation counts, substitutions per site, event timing or evidence
strength. Auspice creates an internal hidden forest root; this is software layout,
not a biological common ancestor. Stock interface words such as “genomes” and
“Divergence” do not have their pathogen meanings here. “No sequence changes
observed” means sequence-level mutation strings were not supplied to this event
model view. Neither patient dates nor sequence mutations are fabricated to alter
the interface vocabulary.

The published within-tumour TRACERx demonstration is a separate, unchanged dataset
with genuine published SNV-count lengths. Its semantics must not be transferred to
this population-model display.

## Run locally

From the project root, after the inference step has written its validated model:

```powershell
python population_routes/visualization/adapter.py --model population_routes/inference/output/model.json
python population_routes/visualization/adapter.py --model population_routes/inference/output/pathology_sensitivity/model.json --output nextstrain/datasets/tcga_luad_population_edges_pathology_sensitivity.json --report population_routes/visualization/output/pathology_sensitivity_projection_audit.json --companion-url 'http://127.0.0.1:4001/?model=pathology_sensitivity'
python nextstrain/tests/schema_validation.py nextstrain/datasets/tcga_luad_population_edges.json
python nextstrain/tests/schema_validation.py nextstrain/datasets/tcga_luad_population_edges_pathology_sensitivity.json
& '.\population_routes\visualization\Start Population View.ps1'
& '.\Start Nextstrain.ps1'
```

The companion launcher binds to `127.0.0.1`, starts a hidden process, records its
own process identity and model path under ignored `.runtime/`, and reuses only its
matching live server. It does not stop an unrelated process on an occupied port.
Use `-Foreground` for a terminal process that can be stopped with Ctrl+C.
Use `-Restart` after changing the server code; it stops only the matching recorded
process, verified by project, model path and process start time. The sensitivity
file is read separately; it never replaces the baseline source file or export.

The companion serves source model data read-only and shows a SHA256 fingerprint.
Download returns the exact source-file bytes, so its SHA256 matches the displayed
fingerprint. It has no data edits, model fitting,
patient uploads or external service calls. The source model's status, assumptions,
validation and limitations remain visible. An empty selected-edge result is shown
without fabricated relations. If no event nodes are supplied, the adapter writes
no invented native dataset; the companion shows the readiness result.

## Validation

```powershell
python -m unittest discover -s population_routes/visualization/tests -v
node --check population_routes/visualization/app.js
```

The tests use explicitly fictional fixtures with a two-parent merge, a multistep
dependency and an isolated event. They check every selected edge, all parent sets,
event-specific denominators, support metadata, the unchanged embedded source model,
the absence of invented dates/mutations, empty/readiness results, and rejection of
cycles or invalid counts. The exported dataset also validates against the same
hash-pinned official Augur v2 schemas used for the published reconstruction.

The actual-model integration test runs only once an inference model exists and
reports a skip otherwise. These checks establish faithful display and data-format
compatibility; they do not validate the model's biological or temporal claims.

October 18 implementation verification: all nine visualization tests pass,
including both frozen real models, complete projection audits, source-byte
download fidelity, same-server baseline/sensitivity separation, and rejection of
invalid model requests. Both native exports pass the official schema validator.
The HTTP round-trip test requires localhost access outside this session's
network-restricted sandbox. The root agent verified the actual desktop controls
and native popups. A requested live mobile viewport did not take effect; mobile
browser verification must not be claimed from that attempt.
