# TRACERx multi-region population-order pilot

This analysis uses published **within-patient inferred phylogenies**, rather than mutation prevalence as a surrogate for time. It adds usable ordering evidence, but the present results **do not establish a reliable recurrent evolutionary route**. The strongest selected dependency, KEAP1 → STK11, has 85% bootstrap selection but only two resolved training-patient ancestry votes and no resolved evaluation-patient vote. Its ordering permutation BH q is 1.0. The frozen model predicts held-out reported-driver cooccurrence slightly worse than independent-event marginals.

The scientific design is frozen in [tracerx_routes_v0_1.json](../configs/tracerx_routes_v0_1.json), SHA256 `59cb7426bee696e76df9d75bd4e61a7a322231f4eb589a2b08726ca20e696cc5`, before candidate frequencies, ordered pairs or models were inspected. This is a separate analysis from the earlier TCGA CAPRI pilot. No earlier TCGA results, original samples, RNA programs or source files are changed.

## Published method and genuine implementation

ASCETIC was published as *Evolutionary signatures of human cancers revealed via genomic analysis of over 35,000 patients*, Nature Communications (2023), [doi:10.1038/s41467-023-41670-3](https://doi.org/10.1038/s41467-023-41670-3). The paper itself analyzed the earlier TRACERx 100-patient multi-region cohort. That is evidence of method relevance; this pilot uses the distinct published TRACERx421 reconstruction deposit described below and is not a reproduction of the paper's 100-patient analysis or survival signatures.

We run the unchanged authors' **ASCETIC 1.2.0**, [official repository](https://github.com/danro9685/ASCETIC), commit `e6bc7f5214ce5eae015ca9ef9d13dbfdc756c5fa`, Apache-2.0. The [official vignette](https://danro9685.github.io/ASCETIC/articles/ASCETIC.html) describes a binary patient-by-event matrix and named per-patient phylogeny adjacency matrices. Its published entrypoint is:

```r
ASCETIC::asceticPhylogenies(
  dataset = patient_event_matrix,
  models = patient_order_matrices,
  regularization = "aic",
  command = "hc",
  restarts = 0
)
```

The primary fit and every outer bootstrap/null fit use this entrypoint, parameters and the fixed seed family based on 20261018. We do not reimplement the agony ranking or Bayesian-network learner, modify package internals, replace the result with a hand-selected edge set, or use held-out observations for model selection. The official implementation builds an agony ranking, applies its phylogeny-based probability-raising constraint, then performs AIC-regularized Bayesian-network learning. Its phylogeny-based constraint is not identical to requiring positive cross-sectional `P(B|A)-P(B|not A)`. Accordingly, a selected edge can encode negative reported cooccurrence; the descriptive cross-sectional difference is retained for each selected edge.

ASCETIC is compiled from the exact upstream C++ and R source using the official CRAN portable Rtools45 base toolchain (GCC 14.3.0, UCRT), without a system-wide compiler installation. A direct GCC invocation replaces make only; original source files, original Rcpp registration and the algorithm are unchanged. Standard `R CMD INSTALL --no-libs --no-test-load` installs the package's original R code/data/help, after which the compiled original DLL is placed in the standard `libs/x64` directory. Loading the genuine package and a fictional 100-patient ordering example passed; the example selected its planted A → B relation and added no A → C relation with no supplied order evidence.

[runtime_lock.json](../tracerx_routes/inference/runtime_lock.json) pins the exact source archive, source-file hashes, official compiler archive and seven additional official CRAN binaries. The already locked CAPRI library supplies 37 shared packages; its lock hash and actual versions are checked. Source hashes allow only Git's Windows CRLF versus archive LF equivalence. R 4.5.1, full package versions and the actual compiled DLL hash are retained locally in `output/sessionInfo.txt` and `.upstream/build_record.json`. No R user-library or system R installation was modified. The vignette's Bioconductor installation suggestion did not yield an ASCETIC entry in the inspected 3.21 binary index; the successful build uses the pinned authors' source instead.

## Cohort, event and structural input gates

Source: Karasaki et al., *Evolutionary characterization of lung adenocarcinoma morphology in TRACERx*, Nature Medicine (2023), [doi:10.1038/s41591-023-02230-w](https://doi.org/10.1038/s41591-023-02230-w), [Zenodo 7683605](https://zenodo.org/records/7683605). The deposit's academic/noncommercial-use terms apply separately from software licenses. Read [TRACERX_ROUTE_SOURCE.md](TRACERX_ROUTE_SOURCE.md) for source parsing, specimen context, exact mutation keys, exclusions and validation.

The frozen first slice contains **217 independent source-labeled LUAD patients**, each with exactly one deposited tumour across all histologies and at least two distinct primary `R` regions. All eight patients with multiple deposited tumours are excluded from this first analysis, rather than choosing a favourable tumour or treating several tumours as independent patients. The same-surgery source reconstruction can also include recorded lymph nodes; these are retained in the original full tree but do not satisfy the two-primary-region gate. Unavailable per-patient neoadjuvant metadata are not imputed from missing values or from adjuvant labels.

A deterministic SHA256 ordering of `tracerx-luad-route-v0.1|` plus source patient ID assigns **152 training and 65 evaluation patients**. The split is independent of genes, order evidence, outcomes and fitted results. LUSC and other histologies are not pooled. Stage, treatment outcomes, survival and RNA programs do not select events or edges.

Every deposited alternative was structurally checked for retained-node coverage, unique root and acyclicity. The source's explicit root self-sentinel was normalized only where applicable, with the source encoding retained in the audit. Directed reachability was calculated over every alternative; intersection/union of the resulting closures were cross-checked with deposited consensus data. The 217-patient cohort has **51 single-topology and 166 multiple-topology reconstructions**. Alternatives are possible deposited reconstructions, not posterior samples with calibrated probabilities. We do not weight a patient by their number of alternatives or count regions as patients.

Curated mutations require the source authors' `DriverMut == TRUE` flag. The full variant join includes tumour, chromosome, position, reference **and alternate allele**; the source's shorter mutation ID alone is insufficient. Exact joins must agree with corrected and embedded cluster assignments. Across all curated genes in the 217 patients, 1,214 driver records map to a retained cluster, 19 map to source-removed clusters and 191 lack an exact embedded-variant match. These are records, not patients. Unmapped/removed records remain reported gene presence; they cannot cast an ordered vote. All retained exact mappings have the source clean-cluster flag; no new clean-cluster filter is added. Source CCF, VAF, early/late annotations or cluster numbers are never substituted for an ancestor relation.

The fixed candidate set is the same 18 LUAD significantly mutated genes from TCGA Nature 2014 Figure 1, [doi:10.1038/nature13385](https://doi.org/10.1038/nature13385). Only authors-curated driver records in those genes count as events. Training-only gates require at least 10 carriers and 10 noncarriers; every passing gene is retained. The 12 passing events are TP53, KRAS, KEAP1, STK11, EGFR, NF1, RBM10, MGA, ARID1A, PIK3CA, SMARCA4 and CDKN2A. Counts for all 18 candidates and every exclusion remain in [results_summary.json](../tracerx_routes/inference/results_summary.json). Failure of a frequency gate is not negative biological evidence. A zero means no reported authors-annotated driver in that gene, not verified wild type, locus-level callability or functional absence.

## Primary estimand: source-resolved patient-pair evidence

A gene is order-eligible for a patient only if **every curated reported variant in that gene** maps unambiguously to one retained cluster. Several variants in that same cluster are allowed; hits in different clusters are unresolved. A partly mapped gene does not become ordered by selecting the convenient first variant.

For each of the 66 unordered eligible-gene pairs, every co-carrier patient contributes exactly one mutually exclusive category:

| Category | Meaning |
|---|---|
| A ancestral to B | Strict ancestor relation in every deposited valid alternative |
| B ancestral to A | Reverse strict relation in every alternative |
| Same cluster | Within-cluster order remains unresolved |
| Incomparable | Neither node is ancestor of the other in any alternative; separate branches |
| Topology ambiguous | Relation differs across deposited alternatives |
| Repeated gene ambiguous | At least one gene has curated hits across retained clusters |
| Mapping ambiguous | At least one gene has an unresolved/removed exact variant mapping |

Mapping ambiguity takes priority over an apparent repeated placement; neither category casts an order vote. Strict ancestry is transitive reachability: it can include intervening mutation clusters and is **not necessarily a direct next-mutation transition**. Separate branches are not temporal ties or evidence that either event occurred first. Same-cluster events are not expanded into an arbitrary driver chain.

The source-derived pair table is primary and remains complete whether ASCETIC selects an edge. It is not forced to be acyclic: different patients can support different routes. The patient traces and every unresolved denominator are inspectable in the companion view; source-selected corrected topologies in actual Auspice are representative individual reconstructions, not unanimous evidence across alternatives.

In this first slice, training contains 277 co-carrier **patient-pair votes**: 50 strict orders, 142 same-cluster, three incomparable, two repeated-gene and 80 mapping-ambiguous votes. Evaluation has 102 patient-pair votes: 16 strict orders, 62 same-cluster, one repeated-gene and 23 mapping-ambiguous votes. These totals reuse patients across gene pairs and are not independent patient denominators. No eligible pair in this particular subset has a topology-ambiguous vote; that does not imply the deposited tumour topologies are uniquely known.

## Documented partial-order adaptation for the secondary model

Each patient's matrix contains all their present selected genes as named nodes. A cell is one only for the strict all-alternative gene-ancestor closure. Same-cluster, incomparable, ambiguous and unmapped relations are zero, with their named gene presence retained in the model's co-carrier denominator. Thus unresolved order is not transformed into a negative mutation call.

This is a **conservative consensus-poset adaptation** of ASCETIC's phylogeny input, not a uniquely resolved mutational tree or a new validated version of ASCETIC. Software compatibility and source fidelity were checked; the statistical calibration and biological validity of this adaptation are not established. The package's global ranking and likelihood constraints still add modelling assumptions. A selected model edge is not a probability of temporal truth, direct ancestry between patients, causal cooperation, a necessary prerequisite or a universal route. Full selected parent sets are preserved; several incoming parents do not automatically form a deterministic AND gate.

## Frozen assessment

* **Patient bootstrap:** 100 outer resamples of whole training patients, replacing each patient's binary row and temporal matrix together. Duplicated bootstrap draws receive technical draw IDs and do not become new patients. Each fit uses the same official base entrypoint. Failures are retained with successful-fit denominators; events are never silently dropped or reselected. All 100 actual fits succeeded. The predefined 0.8 display threshold describes selection stability, not validation.
* **Primary ordering null:** 10,000 independent within-patient label permutations among uniquely mapped selected genes on their occupied cluster placements. Repeated/unmapped gene identities remain fixed and unordered. This preserves binary co-carrier data, participant count and each patient's temporal-resolution structure. The directional statistic is strict A-before-B count minus strict B-before-A count. One-sided Monte Carlo p is `(1 + null statistics >= observed)/(1 + 10000)`, followed by BH over **all 132 ordered pairs**, including model-unselected pairs. This tests gene-specific ordering conditional on label exchangeability, not a null of independent mutations or a universal causal model. Gene-specific ascertainment and driver timing can violate that exchangeability; the resulting exploratory p/q values are not proof of biological selection.
* **Engine null:** 100 genuine ASCETIC fits with the same unique-placement label shuffle and unchanged binary carrier matrix. Every fit succeeded; selected-edge counts/frequencies are reported. These 100 fits describe model sensitivity to ordering and are separate from the higher-resolution primary ordering tests.
* **Conditional directional interval:** a descriptive Wilson 95% interval uses only strict-order-resolved co-carriers. The full co-carrier denominator and resolved fraction remain alongside it. An interval is absent when no order is resolved; it is not a posterior chronology probability.
* **Locked evaluation:** selected training directions are compared with all categories of evaluation-patient evidence. No direction, event, parameter or display edge is selected using evaluation. A second check fits training-only Bayesian-network CPTs with Beta(1,1) smoothing, scores joint reported-event likelihood in evaluation, and compares with independent training marginals. Unseen parent configurations use p=0.5. This measures reported-driver cooccurrence prediction, not temporal truth or clinical prediction.

## Actual results

| Genuine selected model dependency | Training strict forward / reverse / all co-carriers | Other training evidence | Bootstrap | Ordering p / BH q | Evaluation evidence |
|---|---:|---|---:|---:|---|
| EGFR → KEAP1 | 1 / 0 / 1 | None | 19/100 | 0.5062 / 1.000 | No co-carriers |
| KEAP1 → STK11 | 2 / 0 / 12 | Nine same-cluster, one mapping-ambiguous | 85/100 | 0.2082 / 1.000 | Five co-carriers: four same-cluster, one mapping-ambiguous; zero resolved |
| KEAP1 → SMARCA4 | 1 / 0 / 10 | Four same-cluster, five mapping-ambiguous | 54/100 | 0.2547 / 1.000 | No co-carriers |

The engine-null selection frequencies are 16%, 35% and 16%, respectively. All model-selected edges are displayed even where bootstrap, null or evaluation evidence is weak. EGFR → KEAP1 has **negative** training reported cooccurrence difference, approximately −0.1167 (`P(KEAP1|EGFR)=1/20`, `P(KEAP1|no EGFR)=22/132`); it must not be described as positive cooperation or a well-supported progression route.

Held-out joint log score is **−308.4815**, versus **−304.5148** for independent marginals: a difference of **−3.9667** across 65 evaluation patients (−0.0610 per patient). The model does not improve this predictive check. More importantly for the scientific question, **none of the three selected directions has a resolved evaluation-patient order**, so this holdout cannot confirm their temporal recurrence.

KEAP1 → STK11 is therefore a candidate dependency with high resampling selection but sparse source-resolved ancestry, substantial unresolved same-cluster evidence, no adjusted ordering-test support and no evaluable held-out direction. Calling it a validated, replicated or more reliable evolutionary route would overstate these results. No survival, functional, causal, prospective or clinical validation is performed. Differences from the prior TCGA result cannot be interpreted as a controlled improvement in reliability: the cohort, event definition, sample size and inference model differ.

## Reproduce and verify

From the isolated project checkout, first reproduce the pinned source audit described in the source guide. On the existing Windows R4.5 installation:

```powershell
python population_routes/inference/install_runtime.py
python tracerx_routes/inference/install_runtime.py
python tracerx_routes/inference/run.py
python -m unittest discover -s tracerx_routes/inference -p test_inference.py -v
```

Use `--offline` for dependency installation when the locked archives are cached. Local Windows sandbox accounts can deny R package-metadata or archive-link access; the successful installation and analysis used normal host file permissions. No system-wide installation is required. Runtime downloads, per-patient data, fitted RDS files and generated models remain ignored; the aggregate result and all source/analysis code are versioned. No OpenAI API call or key is needed for this analysis.

`prepare_inputs.py` independently checks the frozen cohort, exact variant uniqueness, source gene summaries and complete consensus-pair coverage. `run_ascetic.R` checks the 44 pinned add-on package versions, prevents silent event deletion, and requires the official returned numeric indices to match input-column order before applying gene names. The R result stores actual input/config MD5s; the Python wrapper checks these plus SHA256 manifests before assessment. `run.py` writes the complete local model and an aggregate [results_summary.json](../tracerx_routes/inference/results_summary.json). The independent display validator recounts all patient votes.

**Fifteen inference tests passed**, including an actual-data comparison against separately exported strict/possible ancestor closures, all ambiguity categories, repeated same-gene hits, null exchangeability constraints, split independence, held-out CPT immutability, all-pair multiplicity and official-source archive equivalence. These computational checks establish reproducibility and faithful transformation, not biological validity.
