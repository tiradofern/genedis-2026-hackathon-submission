# Public multiregion TRACERx source and ordering audit

The new route pilot uses published **within-tumour phylogenetic reconstructions**, with each patient remaining independent. It translates the authors' processed source objects; it does not infer new patient trees from raw reads. Population inference is documented separately in `TRACERX_ROUTE_METHODS.md`.

## Publication, provenance and access

Karasaki T, Moore DA, Veeriah S, et al.; TRACERx Consortium. **Evolutionary characterization of lung adenocarcinoma morphology in TRACERx.** *Nature Medicine* 29, 833–845 (2023). [DOI 10.1038/s41591-023-02230-w](https://doi.org/10.1038/s41591-023-02230-w), PMID 37045996, PMCID PMC7614478. The public processed figure inputs are [Zenodo record 7683605, version 2](https://zenodo.org/records/7683605), DOI 10.5281/zenodo.7683605.

The source record restricts data use to academic non-commercial purposes and directs commercial users to the depositor. The software's license and this repository's release decision do not override those terms. This pilot downloads public processed data, runs locally and keeps raw and source-derived patient data outside Git. It does not retrieve the controlled EGA WES/RNA payloads, redistribute the dataset or publish an externally hosted patient-data application.

The preceding published-tree proof pinned ten source files in `nextstrain/source/source_manifest.json`; those same bytes are reused and checked. The population step adds the public mutation table, with a separate pinned manifest in `tracerx_routes/source/source_manifest.json`:

| Source file | Bytes | MD5 from the deposited release | SHA256 of inspected bytes |
|---|---:|---|---|
| `20221109_TRACERx421_phylogenetic_trees.rds` | 39,375,514 | `a2f107ad1b13222528470d03105f065e` | `7111c189edfc104eccff83c0b871d25ed3c0ecba9db64a04e1147cc963d9c02b` |
| `20221109_TRACERx421_mutation_table.fst` | 82,765,182 | `cb802b2038057b2e3a97d47a85cc6585` | `8bd22ad71613aaa65e12d875561d5669824499282e09c4e9fa8f77df882ae063` |

The downloaded mutation table contains 379,008 rows and 30 deposited columns. All constructed full variant keys are unique and have nonmissing key components. The source `mutation_id` is also unique here, but omits the alternate allele; it is insufficient as a general full-variant identity.

The companion cohort report, [Frankell et al., *Nature* 616, 525–533 (2023)](https://doi.org/10.1038/s41586-023-05783-5), describes early-stage treatment-naive NSCLC at enrolment. This establishes cohort context. The specific patient/tumour tables used here do not supply a per-patient neoadjuvant-status column, so the extractor leaves that field unknown. Their adjuvant-treatment labels are preserved separately and never used to infer pretreatment status. Every CCF specimen in these source trees has a surgery label; no relapse specimen is silently pooled into this pilot.

## Frozen independent LUAD cohort

The deposited phylogenetic list contains 403 tumour objects from 394 patients: 229 LUAD, 129 LUSC and 45 Other. Eight patients have more than one deposited tumour (seven have two, one has three). Across LUAD these account for 12 tumour objects.

The frozen first slice excludes all patients with more than one deposited tumour, across any histology. It requires at least two distinct primary `R` regions. Surgery lymph-node specimens stay in the full deposited reconstruction but do not count toward that eligibility gate. This yields **217 LUAD patients with one tumour each**. All 217 meet the primary-region requirement; primary-region counts are 94 with two, 48 with three, 37 with four, 21 with five, four with six, six with seven, and seven with eight. LUSC and Other are not pooled. No choice among multiple primaries is made based on their mutations or outcomes.

These rules and the participant split were frozen in `configs/tracerx_routes_v0_1.json`, SHA256 `59cb7426bee696e76df9d75bd4e61a7a322231f4eb589a2b08726ca20e696cc5`, before candidate-gene frequencies, ordered-pair findings or a fitted population model were inspected. `cohort_export_lock.json` records the exact source-derived population input hash: `33f80810a7fb7f025d3c93371760c245a9e9a797534af9235b51f0c2471c02c2`.

## Exact variant-to-cluster mapping

The RDS embeds per-tumour `ccf_table_pyclone_clean`, whose row names contain `tumour:chromosome:position:reference:alternate`, and the `PycloneCluster` column. The mutation table supplies `tumour_id`, `chr`, `start`, `ref`, `var`, `Hugo_Symbol`, logical `DriverMut`, logical `cleanCluster_SC`, and `PyCloneCluster_SC_TB_corrected`.

Only the authors' `DriverMut == TRUE` rows define reported curated mutation events. The parser constructs the exact full key from those five components, removing only the literal `chr` prefix from `chr`. It requires a unique match to the embedded mutation key, agreement of the embedded cluster and the table's corrected cluster, and retention of that cluster in the corrected source topology. A gene name, protein-change label, mutation count or clonal/subclonal label cannot substitute for the exact join.

Across the 217 eligible tumours, 1,424 source-curated driver variants are retained as reported-presence evidence:

| Placement status | Variants | Ordering use |
|---|---:|---|
| Exact key and corrected cluster agree; cluster retained | 1,214 | Eligible for source order, subject to same-gene and topology checks |
| Embedded source cluster removed by the authors' tree correction | 19 | Presence retained; order unresolved |
| Full variant absent from the embedded PyClone mutation map | 191 | Presence retained; order unresolved |

All 1,214 retained placements have `cleanCluster_SC == TRUE`. The 77 FALSE and 106 missing flags are among absent embedded mappings; another eight absent mappings have TRUE. The 19 source-removed mappings also have TRUE. Thus this pilot adds no new exclusion based on an assumed meaning of `cleanCluster_SC`. Its exact processing definition is not supplied as a data dictionary in these inspected files; the flag is copied verbatim rather than renamed as a validation result.

Every curated mutation remains in the ignored output, including failed joins and removed clusters. A gene is order-eligible within a patient only when all its curated variants map uniquely to the same retained cluster. Several variants in that one cluster are allowed. Repeated hits across clusters and any failed mapping leave that gene's order unresolved. Reported presence is preserved. The absence of a curated event means no source-reported curated driver mutation, rather than verified wild type, assay-wide callability or absence of other alteration mechanisms. Copy-number and structural events are not relabelled as point-mutation events.

An independent post-preparation check addressed RBM10, which is present in 27 eligible patients but has no uniquely mapped gene events. All 30 curated variants are recorded on `chrX`, with missing corrected-cluster and `cleanCluster_SC` fields. None has an embedded full-key match or a same-position/reference/alternate match under any chromosome label; those source trees contain no embedded X/23 or Y/24 variant rows. Thus a chromosome-label normalization cannot repair this missing source placement. `rbm10_join_qa.json` records the aggregate check. Its cause is not inferred, and these presences remain order-unresolved. The frozen population input bytes were unchanged.

## Topology uncertainty and source-fidelity checks

The primary source objects are `graph_pyclone.Corrected_tree`, `trunk`, `edgelength`, `alt_trees`, `consensus_branches`, and `consensus_relationships`. Direction comes from the deposited parent–child matrices, never cluster number, CCF, prevalence or branch length.

Every alternative must be a rooted, connected single-parent tree, with the same complete set of retained clusters and the deposited trunk. For each alternative, the parser computes all strict ancestor relationships. Their intersection must equal the deposited `consensus_relationships`, and their direct-edge intersection must equal `consensus_branches`. The corrected representative must occur among the alternatives. **All 403 source objects pass these checks**, including the documented singleton representation below. All 217 eligible LUAD cases pass without an exclusion or a fallback to the corrected representative.

In the eligible LUAD set, 51 tumours have one deposited alternative and 166 have multiple. A directed order is supported only when it agrees across every deposited alternative. A relationship that changes between ancestor and separate-branch placements, or reverses, is topology-ambiguous. Separate branches do not establish temporal equality. Two mutations in one cluster do not have a resolved internal order. The alternatives are neither additional patients nor calibrated posterior probability samples.

### Exact single-cluster sentinel

Three eligible LUAD source objects encode a single retained cluster using `Corrected_tree = 1:1`, `trunk = 1`, one named SNV count for cluster 1, every alternative equal to `1:1`, and both deposited consensus fields equal to `1:1`. The same exact encoding occurs in two LUSC source objects.

Only this complete signature is translated to a single node with zero intercluster edges. Literal source fields and the encoding flag remain in the display export. It introduces no ancestor and supplies no ordered vote between co-clustered drivers. Other self-loops fail structural validation. This is a source-representation interpretation, not a biological exclusion or a general repair of source graphs.

## Patient views and the population contract

`source/output/cohort_trees.json` contains one independent patient record with source identifiers, histology, all specimen labels, primary/LN counts, rooted corrected nodes, all curated driver mappings, per-gene placement states, all cluster-pair relationship categories, and strict/possible ancestor closures. It contains no fitted population edges. The inference layer applies the frozen training-only candidate-frequency gate and participant split.

`source/output/patient_trees/<tumour_id>.json` preserves the corrected representative, exact cluster IDs and source-assigned SNV counts for actual Auspice. `Fig.3bd.S4abcdefgh.R:531–535` explicitly extracts `graph_pyclone.edgelength` as `numSNVs`; its pinned script hash is recorded in each display export. A display-only zero anchor may expose the retained root stem; it is not a biological normal ancestor. Regional CCF estimates are copied in their deposited percentage units, including estimates outside 0–100. Region morphology is joined only by an exact documented punctuation substitution and remains specimen metadata, rather than a clone attribute.

Each native branch records whether its edge is in every source alternative, and how many alternatives contain it. These counts describe the deposited candidate list; they are not ancestry confidence probabilities. Curated-driver annotations are assigned only to exact retained clusters. A separately versioned `display_metadata_amendment.json` records the addition of the terms URL and branch-unit source reference to the 217 display files; the locked population input bytes stayed unchanged.

## Reproduction and checks

Run from the repository root. R 4.5.1 was used. The isolated official Windows binary reader is pinned to fst 0.9.8, fstcore 0.10.0 and Rcpp 1.1.2; fstcore reports that its binary was built with R 4.5.3, and the reader successfully translated the complete dataset under R 4.5.1. The previously pinned population runtime supplies jsonlite 2.0.0. No system R library is modified.

```powershell
python nextstrain/source/download_sources.py
python population_routes/inference/install_runtime.py
python tracerx_routes/source/retrieve_source.py
& 'C:/Program Files/R/R-4.5.1/bin/Rscript.exe' tracerx_routes/source/extract_sources.R
python tracerx_routes/audit_sources.py
python -m unittest discover -s tracerx_routes/source -p test_sources.py -v
```

On this desktop, native R package discovery under the restricted execution token failed; the same isolated libraries worked with normal process access. This was an execution-environment issue, rather than missing public source data. Source verification also runs separately with `python tracerx_routes/audit_sources.py --verify-only`. Extraction records current input and extractor-script MD5s, and the audit refuses stale native translations. Reproduction requires the exact frozen configuration and downloaded bytes; no automatic repinning is needed.

Eight source-contract tests passed: exact alternate-allele identity, source consensus disagreement, incomplete alternatives, same-cluster/separate-branch states, repeated and unmapped reported presence, exact singleton handling, and the real 217-patient export hash and independence. These checks establish translation fidelity and implementation behavior. They do not validate the authors' reconstructed ancestry, causal driver effects, or a population evolutionary route.
