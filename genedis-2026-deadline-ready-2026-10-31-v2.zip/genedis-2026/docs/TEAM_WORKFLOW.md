# Working together through Codex

## Current review: plan and results, October 31

Fernanda requests Justin's independent evaluation of the frozen plan/results, followed by recommendations and joint reassessment. Start with [the current review request](../reviews/JUSTIN_PLAN_RESULTS_REVIEW_REQUEST_2026-10-31.md) on `review/justin-plan-results-2026-10-31`. It pins the scientific release to `c0599df`, supplies an updated review template and describes the second pass with Fernanda. This supersedes the older initial-review prompt for the current task. Justin's review is not yet completed; existing AI reviews are not his sign-off. Keep the release/archive unchanged until explicit decisions authorize revisions. No direct message, access change or organizer delivery is performed by this documentation update.

The private GitHub repository is the shared source for this project. Fernanda and Justin each use a local copy in Codex; their conversations are separate, while committed project files, reviews, and decisions provide durable shared context. Conversation sync alone does not transfer a local folder to another computer.

## One time setup

Accept the repository invitation when it arrives. In Codex, ask it to clone `https://github.com/tiradofern/genedis-survival-islands.git` into a local research folder and open that folder as the project. Start a chat with: “Read AGENTS.md and docs/CURRENT_STATUS.md, synchronize the repository if the working copy is clean, and help me with my assigned GeNeDis task.”

Justin's first prompt can be: “Read AGENTS.md, docs/CURRENT_STATUS.md, and reviews/REVIEW_PROMPT.txt. Independently review the selected study and audit code. Write reviews/justin-initial-review.md on a review branch and prepare a pull request for Fernanda.”

Each person's Codex GitHub connection may need access to this newly created private repository. This is separate from accepting its GitHub invitation. Local Git access is sufficient for the local workflow; optional cloud/GitHub code review requires its own repository connection/settings. We have not enabled a new cloud review integration or assumed shared account access.

## Each session

1. Inspect the working tree and synchronize shared changes. Fast-forward a clean main branch; preserve uncommitted work and explain conflicts rather than resetting it away.
2. Read the current status, decisions, and task list. Choose one bounded task and a separate branch, such as `review/justin-initial` or `analysis/array-qc`.
3. Save the findings or changes in the repository. Record sources, assumptions, actual checks, and unresolved questions. Keep scientific proposals distinct from accepted decisions.
4. Push the branch and open a pull request for review. Link the review/findings from the task list or issue. The research lead adjudicates consequential biological choices and accepts merges unless the team explicitly delegates them.
5. At the next session, the other collaborator asks Codex to synchronize and read the new review or pull request. Package exchange is no longer needed for ordinary collaboration.

## Feedback and task discussion

Use a Markdown review in `reviews/` for substantive scientific feedback and GitHub issues for focused questions/tasks. A pull request is useful for reviewing a proposed document, code change, or analysis together. Branch ownership and work packages must be agreed; do not silently claim another person's task.

This setup does not create automatic cross-account agent messaging or background polling. Both collaborators can explicitly ask their Codex session to check the shared repository, issues, or pull requests. Automatic Codex reviews are an optional later integration, not a prerequisite.

## Data and historical evidence

Small curated GEO metadata and the dated audit outputs are versioned. Complete expression matrices and raw data are excluded; retrieve public processed inputs with `scripts/download_data.py` when needed. The initial code's `audit_metadata.py` writes manifests/reports, so use a working copy for a review rerun. Metadata-only runs cannot reconstruct complete matrix-integrity results. Preserve the dated October 14 snapshot.

The earlier package README and audit-era prose are historical evidence. For current coordination use `docs/CURRENT_STATUS.md` and `docs/DECISIONS.md`. The code release license is still pending, and third-party source data retain their own terms.

References: [OpenAI local projects](https://learn.chatgpt.com/docs/projects#use-local-projects-for-folders-and-codebases) and [optional GitHub code review setup](https://learn.chatgpt.com/docs/third-party/github).
