# Tonight's proposed study — recurring paired molecular-program changes

> Historical planning/review record preserved from commit `92408ee`. The subsequent investigator authorization permits the October31 bounded release work. Current execution protocol and QC decision: `pilot/PROTOCOL_2026-10-31.md` and `pilot/cohorts/FEASIBILITY_REPORT_2026-10-31.md`; both cohorts failed inference readiness and no paired effects were tested. See `submission/REVIEWER_README.md` for the current deliverable.

**Date:** October 31, 2026.
**Status:** investigator-recommended immediate endpoint; detailed procedure proposed for review. Publication of this document does not authorize acquisition, analysis, code implementation, merging or submission.

## Primary question

> **Do predefined molecular programs show recurring changes between pretreatment and acquired-resistance biopsies in two independently collected cancer cohorts?**

Convergent selection remains an overarching hypothesis. Tonight's measurement is recurring paired program-score change. A positive result nominates candidate adaptations; it does not establish selection, resistance specificity, causality, genomic conservation or a coordinated mechanism.

The broader [recurrence-first research roadmap](PAN_CANCER_MSI_RESEARCH_PLAN_2026-10-30.md) remains preserved. Its unpaired resistant-state endpoint, 25-program family and structural-coordination statistics are not tonight's primary protocol.

## Two proposed cohorts and independent units

| Cohort | Upper source inventory for paired work | Readiness limits |
|---|---|---|
| GSE65185 melanoma / MAPK inhibition | 18 patients with genuine pretreatment baselines and resistant specimens | Final index-regimen, acquired-resistance and sampling eligibility need reconciliation; multiple lesions/lines must not become independent patients |
| GSE248249 NSCLC / PD-(L)1 treatment | 13 complete pretreatment/post-resistance pairs | Strict acquired-resistance crosswalk, biopsy site and processing remain unresolved; only four pairs share reported site |

These are maximum source counts, not final eligible n. The broader up-to-19 melanoma/up-to-29 NSCLC resistant-state inventories are not the paired endpoint's denominators.

Use one eligible pair per independent patient. Require a genuine baseline before the index regimen, independently documented acquired resistance following initial clinical benefit under an explicit source-compatible definition, and resistance sampling before a subsequent systemic therapy.

The NSCLC source reports CR/PR in 22/29 molecular patients and includes SD-associated progression. That publication-level figure does not identify the final strict-AR paired subset. Preserve source definitions, clinical response, lesion response and ambiguous subclasses. Do not silently label every pair strict acquired resistance or relabel SD as primary resistance.

Exclude already resistant surrogate baselines, incompatible treatment lines and unresolved patient/specimen links. Freeze selection of a first eligible resistance biopsy and any tie-breaking rules before score inspection. Scheduled early EGFR and endocrine biopsies answer separate exposure/response questions and cannot replace an acquired-resistance cohort retrospectively.

Sources: [GSE65185](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE65185), [Hugo et al.](https://pubmed.ncbi.nlm.nih.gov/26359985/); [GSE248249](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE248249), [Memon et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC11249385/).

## Limited published program family — proposed before results

Use these six MSigDB Hallmarks as the complete primary program family:

1. HALLMARK_INTERFERON_ALPHA_RESPONSE
2. HALLMARK_INTERFERON_GAMMA_RESPONSE
3. HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION
4. HALLMARK_HYPOXIA
5. HALLMARK_OXIDATIVE_PHOSPHORYLATION
6. HALLMARK_G2M_CHECKPOINT

These are literature-based hypotheses, not programs selected from the new results. Pin the exact human gene lists, release, source terms and hashes before any scoring. All six remain in the declared family even if some are unassessable.

IFN-alpha and IFN-gamma overlap and do not represent independent biological replications. The EMT gene-set label in melanoma is an expression annotation, not proof of a literal epithelial transition. Proliferation, immune or stromal changes remain eligible observations without being automatically called survival adaptations.

The existing 25 provisional NSCLC modules remain preserved. Recovering or validating those local artifacts is not a prerequisite for testing the six published hypotheses; they are a separate reproducibility/future-transfer workstream.

Reference: [Liberzon et al., MSigDB Hallmarks](https://pubmed.ncbi.nlm.nih.gov/26771021/).

## Prespecified measurement

Use one explicitly defined rank-based score for both cohorts, rather than apply TCGA RSEM PC1 centering to arrays or FPKM.

- Harmonize unique gene identifiers with a pinned mapping; remove controls and ambiguous identities.
- Collapse multiple valid measurements of one gene by a prespecified within-sample median. Retain mapping losses.
- Define U as the fixed common, technically eligible gene universe measured across both cohorts and both timepoints, before inspecting paired effects.
- For sample s, use average ranks for ties and r_s(g)=(rank_s(g)-1)/(|U|-1).
- For the measured portion of positive-direction Hallmark P, define S(P,s)=mean of r_s(g) over g in P, minus 0.5.
- Use the same covered program genes and universe for the corresponding comparison in both cohorts.
- Proposed coverage gate: at least 80% of the original genes and at least 20 measured genes. Do not impute unmeasured genes as zero.
- Do not log-transform already processed array/log-expression values again, fit count models to FPKM/intensities, or normalize the cohorts together.

This transparent rank-score proposal is informed by single-sample scoring methods; it is not asserted to be numerically identical to a particular singscore implementation or the legacy PC1 score. Rank changes are relative-expression measurements, not direct pathway flux or absolute activation.

Reference context: [single-sample scoring](https://doi.org/10.1186/s12859-018-2435-4).

## Paired effects, uncertainty and complete testing family

For patient i and program P:

Delta(i,P)=S(P,resistance)-S(P,pretreatment).

The primary cohort statistic is mean paired score change. Report every patient, final eligible n, mean change, median as descriptive context and a prespecified patient-bootstrap 95% interval (proposed 10,000 resamples). State that small-n bootstrap uncertainty is approximate. Any standardized effect is secondary; do not substitute it for the directly interpretable score difference.

Prespecify **12 directional hypotheses: six programs x increase/decrease**.

For each direction d:

1. Compute a one-sided paired mean-change sign-flip P value within each cohort, under explicit symmetry/exchangeability assumptions for the paired differences.
2. Use exhaustive 2^n sign patterns for final eligible n where feasible. Exact enumeration needs no Monte Carlo +1 correction. Use common patient sign patterns across all six programs to preserve cross-program dependence.
3. For that same direction, calculate p_rep(P,d)=max(p_NSCLC(P,d),p_melanoma(P,d)).
4. Apply Benjamini–Yekutieli correction across all 12 prespecified directional replication hypotheses, with proposed q<=0.05.
5. Opposite-direction changes are discordance, not common-direction replication. Do not choose one-sided tails after inspection.

The conjunction requires valid per-cohort P values for the same frozen score/eligible gene hypothesis. Multiplicity correction cannot repair invalid pairing, processing or exchangeability. This observational test is not treatment randomization and cannot establish a treatment-caused effect.

The broader roadmap's structural statistic C and C=0.10 relevance proposal do not apply to Delta scores. No clinical-importance cutoff or mechanism claim is inferred merely from a significant paired result.

## Binding data-readiness gate

**Current status: unpassed.** Fresh input reconstruction and usable paired data have not been demonstrated in this workspace.

Before any inferential claim, verify:

- patient identity, genuine pairing, index regimen, baseline timing and clinically documented acquired resistance;
- sampling before a subsequent systemic regimen;
- sufficient program/gene measurement;
- interpretable within-study processing, batch assignments or independently justified processing equivalence;
- whether biopsy site/composition changes can plausibly explain the observed paired comparison;
- an estimable technical design and defensible paired-test assumptions.

The absence of the authors' final corrected matrix alone is not an automatic veto if the public processing and verified technical structure support a defensible analysis. Conversely, missing metadata, time–batch aliasing or unresolved major site shifts cannot be fixed by adding unsupported covariates.

Use a written go/descriptive/stop decision before inferential score comparisons. Same-site displays with four patients cannot validate a 13-pair result.

**Feasibility limit:** if only the four same-site NSCLC pairs are defensible, the smallest exhaustive one-sided sign-flip P is 1/16=0.0625, before multiplicity. Under this proposed protocol, that set cannot establish inferential two-cohort recurrence. The result must be descriptive or a feasibility assessment; do not change the test to rescue significance.

## Success, negative results and inconclusive results

**Supported recurring paired change:** both cohorts pass the binding gate; the same-direction conjunction passes the complete-family rule; effect sizes, uncertainty, patient influence and relevant site/processing sensitivity are fully reported.

Permitted conclusion:

> These programs show recurring changes between pretreatment and acquired resistance across two cancer–treatment contexts.

This does not demonstrate selection, resistance specificity, causality, genomic conservation or within-program cooperation.

**No supported recurrence:** eligible informative data do not support the predefined shared-direction hypothesis. Report all six programs, both directions and effects. Without adequate precision, a negative test does not establish absence of meaningful changes.

**Descriptive/inconclusive:** a cohort fails pairing/site/processing/measurement assumptions, or uncertainty is insufficient. Do not count a scheduled-treatment cohort as a replacement or use a pooled effect to conceal a failed required cohort.

## Bounded work and fallback

After explicit analytical approval:

1. Confirm the actual submission cutoff/timezone and reviewer-access requirements.
2. Make the input/pairing/site/processing readiness decision first. Proposed initial budget: at most two hours to assess readiness, not permission to repair an entire missing pipeline.
3. If the gate passes, freeze the six program definitions, score recipe, exclusions and complete testing family before molecular results.
4. Compute the bounded paired effects, uncertainty and replication tests, followed by the prespecified sensitivities and reproducibility checks.
5. Protect documentation/submission time; do not add new cohorts, de novo modules, phylogenies, genomic-retention analyses or a classifier.

If the gate fails, return to the existing NSCLC reproducibility/prototype assessment rather than expanding the new analysis. Report any failed reconstruction explicitly; do not call a failed replay verified reproducibility.

At the read-only clock check on October 31, 2026, it was approximately 1:51 a.m. America/New_York, about 22 hours before local midnight. **Local midnight is a planning reference, not a verified organizer cutoff.** No promised schedule follows from that arithmetic; readiness and actual cutoff determine feasibility.

## Approval boundary

This records the investigator's recommended immediate scientific focus. The six-set panel, scoring, test and time-box defaults remain proposed until reviewed. New data acquisition, analyses, code implementation, merges and submission still require explicit approval.
