# Published lung cancer reconstruction used in the Nextstrain proof

This proof displays an existing, authors' inferred **within-patient lung adenocarcinoma clonal tree**. It does not infer a tree from TCGA, join unrelated patients into an ancestry tree, or estimate common evolutionary routes across patients. The deposited topology and branch counts are preserved. The intended immediate milestone is to demonstrate that the actual Nextstrain Auspice application can explore a real published cancer reconstruction.

## Publication, access, and terms

Karasaki T, Moore DA, Veeriah S, et al.; TRACERx Consortium. **Evolutionary characterization of lung adenocarcinoma morphology in TRACERx.** *Nature Medicine* **29**, 833-845 (2023). Published April 12, 2023. [DOI: 10.1038/s41591-023-02230-w](https://doi.org/10.1038/s41591-023-02230-w); [PMID 37045996](https://pubmed.ncbi.nlm.nih.gov/37045996/); [PMCID PMC7614478](https://pmc.ncbi.nlm.nih.gov/articles/PMC7614478/).

The publication describes integrated multiregion whole-exome, RNA-sequencing, and histopathological analysis of LUAD. Its figure scripts and processed inputs are deposited at [Zenodo record 7683605, version 2](https://zenodo.org/records/7683605), DOI [10.5281/zenodo.7683605](https://doi.org/10.5281/zenodo.7683605).

The Zenodo notes explicitly restrict the dataset to **academic non-commercial use** and instruct commercial entities to request access from the depositor. This local research proof retains that restriction. An open download is not permission to redistribute or publish a hosted application containing the data. The article, the data, and the Auspice software have separate terms. The repository's unresolved project release license does not supersede any of them. No public hosting or source-data redistribution was performed.

Only public processed files were downloaded. The underlying WES and RNA-seq referenced by the publication remain controlled-access EGA datasets (EGAS00001006494 and EGAS00001006517); they were neither retrieved nor analyzed here.

The published study labels are pseudonyms, not identifying patient information. Nevertheless, the downloaded files and the selected source-derived reconstruction stay local and Git-ignored. Versioned code, checksums, and instructions permit an authorized user to recreate the proof without committing patient-level data.

## Exact source objects and meaning

The source is `20221109_TRACERx421_phylogenetic_trees.rds` (39,375,514 bytes), a named R list of 403 deposited tumour reconstruction objects. Its official Zenodo MD5 is `a2f107ad1b13222528470d03105f065e`. The SHA256 and complete source URLs are in `nextstrain/source/source_manifest.json`.

The selected example is the **first deposited tumour**, independently confirmed as LUAD using the tumour metadata. Selection was for a readable interface demonstration with multiple regions and a single deposited topology; it was not based on outcome, a survival-program result, or a finding of convergence. The generated local JSON records its exact study labels. The proof contains 15 retained mutation-cluster nodes and 14 parent-child relationships, including four terminal clusters. These four terminals are **not** the four sampled tissue regions.

| Deposited R object | Use and interpretation |
|---|---|
| `graph_pyclone.Corrected_tree` | Exact corrected parent-child topology, without reattaching clusters removed by the authors' reconstruction |
| `graph_pyclone.trunk` | Published truncal mutation-cluster identifier; independently matches the unique root of the source graph |
| `graph_pyclone.edgelength` | Named count of SNVs for each mutation cluster; retained branch length is the count for the child cluster |
| `graph_pyclone.consensus_branches` | Independent deposited parent:child representation; every selected edge must agree exactly |
| `graph_pyclone.alt_trees` | Selected example has one deposited alternative topology, which must match the corrected source edges exactly |
| `nested_pyclone.ccf_cluster_table` | Source cancer-cell-fraction estimates by mutation cluster and specimen, in percent |
| `clonality_out.clonality_table_corrected` | Authors' per-cluster, per-specimen clonal/subclonal/absent labels; not recalculated here |

The authors' script `Fig.3bd.S4abcdefgh.R`, lines 103 and 531-535, loads this RDS, selects clusters in `Corrected_tree`, and reads the named `edgelength` vector into `ClusterName` and `numSNVs`. This provides direct numerical branch-unit evidence. The neighbouring lines 541-542 read `nested_pyclone.ccf_cluster_table`; lines 549-552 use its values on a percentage scale. The source files are downloadable through the pinned manifest; their checksums matched the Zenodo listing on October 18, 2026.

The RDS supplies the selected `Corrected_tree` as a flattened, column-major edge vector. The extractor reshapes it into paired parent and child columns and then validates all resulting edges against both `consensus_branches` and the sole deposited alternative topology. Parent direction is not guessed from cluster ID, CCF, or branch count. A changed or ambiguous topology fails extraction rather than being silently redrawn.

### Truncal stem and horizontal axis

The published root cluster has **259 SNVs**, so setting its length to zero would lose the source truncal burden. The local source JSON preserves `branch_length=259` for that root and separately records `root_stem.length=259`. The retained source clusters total 1,321 SNVs.

The adapter may prepend one explicitly labelled **display-only origin anchor** at cumulative distance zero so that the root's 259-SNV stem is visible. This anchor is not a sampled normal cell, an inferred clone in the deposited source, or evidence about a specific normal ancestor. All 15 source nodes, 14 source edges, and their numerical counts remain distinguishable from this one display device.

Horizontal distance is the cumulative count of source-assigned SNVs along an inferred lineage. It is neither calendar time, a sequence substitution rate, nor a normalized number of mutations per genomic site. No dates, root age, clock fit, or individual mutation identities are fabricated.

### Regional CCF and pathology linkage

The source CCF matrix contains four actual specimen labels. The regional metadata file has the same labels with a hyphen before the regional suffix where the CCF matrix uses a period. The extractor requires both an exact tumour match and exact full-label agreement after only this documented punctuation substitution. Missing or duplicate joins fail.

Each retained clone has numeric attributes `region_r1_ccf_percent` through `region_r4_ccf_percent`, plus the corresponding source clonality labels. These values are copied without imputation, rounding, rescaling, or clamping. The deposited root estimate in one region is 101%; this is retained as an estimate exceeding 100, not silently changed into a biological assertion of more than all cancer cells.

Regional growth patterns are held separately: two sampled regions are acinar, one is cribriform, and one is lepidic. A specimen is a mixture of clones. The proof does **not** assign its regional morphology to a single cluster or assert that clone ancestry proves a transition between those histological patterns. It does not add outcome or treatment metadata.

## Reproduction

Paths below are relative to the repository root. The scripts resolve source-file locations relative to their own directory, so the downloader and extractor can be invoked from another working directory. Python 3.13 was used. Parsing the complete nested RDS takes several minutes; R is not required.

```powershell
python -m venv nextstrain/source/.venv
& nextstrain/source/.venv/Scripts/python.exe -m pip install -r nextstrain/source/requirements-source.txt
& nextstrain/source/.venv/Scripts/python.exe nextstrain/source/download_sources.py
& nextstrain/source/.venv/Scripts/python.exe nextstrain/source/extract_published_tree.py
```

An optional ignored `nextstrain/source/_deps/` install directory is also recognized; it was used for this local proof. It should not be combined with a different environment unless the same pinned package versions are intended.

The downloader checks exact size, SHA256 and MD5 for all pinned files before accepting them. Existing mismatches fail, and new files are downloaded to `.partial` names and verified before replacement. It does not regenerate or overwrite the versioned manifest. `--verify-only` performs an offline integrity check. The SHA256 values pin the inspected bytes; MD5 values for all ten files were also compared against the depositor's Zenodo listing.

The extractor rechecks all pinned inputs, selects the specified reconstruction, verifies LUAD, topology, branch counts, truncal root and specimen joins, and writes ignored `nextstrain/source/selected_published_tree.json`. That compact JSON is the converter's input. It includes the source citation and hashes, exact cluster IDs, per-node attributes, root-stem information, specimen annotations, source-equivalence checks, and limitations. It does not fit a new phylogeny.

Ten source files are pinned. Three provide the selected tree and its two metadata joins; one source R script defines the branch units. The additional patient metadata, LUAD overview, tumour-diversity CSV, figure scripts, and driver-summary TSV are retained as provenance/context from the inspected public release. The tumour-diversity CSV is a table of summary statistics, not a Newick tree and not a topology source. The driver-summary TSV is not used to fabricate branch-specific mutation identities.

## Interpretation limits and the next scientific boundary

This proves software interoperability for an existing published cancer reconstruction. It does not validate the authors' phylogeny anew, demonstrate new tumour ancestry, establish a shared pathway across independent patients, or connect these TRACERx clones to the project's frozen TCGA RNA programs. One deposited candidate topology and agreement with its consensus-edge representation do not constitute calibrated confidence probabilities.

Common evolutionary routes across patients remain the investigator's broader target. That later step requires an appropriate cancer-progression inference design, adequate molecular ordering information, and separate validation. It cannot be inferred merely because this published tree renders successfully in Auspice.
