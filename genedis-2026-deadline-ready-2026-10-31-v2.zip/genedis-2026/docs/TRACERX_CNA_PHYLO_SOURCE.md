# CNA-aware patient reconstruction: source and input contract

This new analysis preserves the original 217 LUAD patients (152 training, 65 evaluation) and 125 LUSC patients (88/37), separately. Its tips are the exact frozen primary R regions: 707 LUAD and 455 LUSC samples. Lymph nodes, extra samples and alternate mutation topologies do not become independent patients. Original mutation models and patient trees are unchanged. The new reconstruction uses genome-wide autosomal copy-number profiles rather than the prior 67-gene context panel.

## Actual public inputs

The pinned [Karasaki/TRACERx Zenodo deposit](https://zenodo.org/records/7683605) supplies the full `20221109_TRACERx421_scna_table.fst` (419,828 rows, SHA256 `1ba04b3c53bf10d8ba1add69efb54319102608a733714cb6acf233706c2d1827`) and original `20221108_sequenza_seg_df_cruk.fst` (1,451,925 rows, SHA256 `08bde1bea886a7dc23af5592e96ae536b92fa7e5d0a1b5543537099e44db55d0`). Their published checksums and byte counts are verified before translation with the existing pinned R reader packages. Academic non-commercial source restrictions remain separate from MEDICC2 GPLv3 and project licensing.

The multisample SCNA table contains patient, tumour and sample identifiers, chromosome, start/end, heterozygous SNP count, source integer total/major/minor copies, ploidy, aberrant cell fraction, continuous raw allelic estimates, source event label, mirrored subclonal allelic imbalance (MSAI), and the reference sample used in phasing. It has no sex-chromosome calls. The original Sequenza table includes chromosome X and many missing allele-specific states; it is audited for source comparison, not mixed into the primary multisample profile. No absent X/Y data are imputed.

Within the 342 frozen patients, the SCNA table has 330,058 rows from 1,189 regions. Restricting exactly to primary R regions gives 181,063 LUAD rows and 139,461 LUSC rows. Source integer states are nonmissing, nonnegative, integral, consistently ordered major >= minor, and total equals their sum; no selected regional intervals overlap. No source raw estimate is rounded, no source event threshold is retuned, and low-purity samples are not silently substituted or removed after fitting.

## Coordinate and phasing audit

The authors-linked original [Refphase legacy code](https://bitbucket.org/schwarzlab/refphase-legacy), pinned at `ba84892f854031227aa60d674da07a75922b95f3`, constructs GRanges using `starts.in.df.are.0based=FALSE` and exports GRanges start/end as `startpos/endpos`. We follow that one-based closed convention and explicitly convert to MEDICC2 BED coordinates as `start = startpos - 1`, `end = endpos`. Both original source coordinates and converted coordinates remain in each canonical regional record. Endpoint matching to the separate original Sequenza segmentation is descriptive; the two sources have different breakpoints and endpoint agreement alone would not establish the convention.

The legacy final-output code explicitly writes `nAraw` as the maximum and `nBraw` as the minimum of the continuous estimates, and writes sorted `nMajor/nMinor` source integers. Distinct `ph_int_cpnA/ph_int_cpnB` fields hold shared haplotype orientation in that code. Those phased columns are absent from the deposited SCNA table. Every deposited frozen-patient row has nAraw >= nBraw, including MSAI-positive rows. Neither the raw estimates nor MSAI plus reference-sample labels recover verified shared A/B orientation. Inputs therefore remain explicitly **unphased major/minor**, with `cn_a = nMajor`, `cn_b = nMinor`. They are not labelled haplotype-resolved.

The [official MEDICC2 documentation](https://github.com/schwarzlab-ccb/medicc2) warns against its internal evolutionary phasing for multisample data. We do not invoke it. The separate total-copy-number topology diagnostic tests sensitivity to this limitation; it cannot restore true parental haplotypes or provide LOH states.

## Common segmentation, missing bases and continuity

Each patient's required primary-region source intervals are split at their union of exact BED breakpoints. An atom is retained only where every required primary region has a valid source integer call. Source row indexes, identifiers, SNP counts, literal MSAI states and phasing reference are preserved alongside each regional state. Missing coverage is not diploid. No patient is excluded using alteration frequencies or inferred routes.

| Canonical input | LUAD | LUSC |
| --- | ---: | ---: |
| Patients | 217 | 125 |
| Primary regions | 707 | 455 |
| Common-covered atoms | 48,454 | 33,876 |
| Common-covered bases summed across patients | 574,153,013,343 | 329,080,331,248 |
| Unmeasured bases within observed chromosome envelopes, summed across patients | 29,903,361,732 | 18,876,413,792 |

These base totals reuse genomic positions across patients and are not independent sample sizes. Terminal bases outside an observed chromosome envelope are also unknown; full-arm coverage is always calculated against the entire fixed reference arm, not only an observed envelope.

Source intervals have numerous gaps, including large centromeric/poorly covered intervals. MEDICC2 ordinarily treats successive segments as adjacent, which can incorrectly join events across large unmeasured spans. The frozen primary policy terminates continuity blocks at gaps **greater than 1 Mb**. Within a block, omitted shorter gaps remain an explicit event-continuity assumption, not measured sequence. The 100-kb variant assesses that assumption. Every engine row still covers exactly one measured common atom, so `end - start = observed_bp`; omitted gaps never contribute arm coverage or LOH bases.

Continuity blocks use unique **numeric pseudochromosomes**, e.g. `chr10001` for the first block of reference chromosome 1. This avoids the official MEDICC2 parser collapsing textual suffixes such as `chr1_block2`. Each atom's original chromosome, numeric pseudochromosome, block and original BED coordinates are stored in a matching map. Local gain/loss events stop at block boundaries; WGD remains global. Bootstrap draws must resample original autosomes, retaining their blocks together, rather than treating blocks as independent chromosomes.

## Copy-number range and fixed references

Source copies exceed the official engine's per-allele maximum of eight: selected primary rows include 2,084 LUAD major-allele and 11 minor-allele values above eight, and 2,020/8 LUSC values. The complete uncapped values remain canonical source data. Only the primary and 100-kb **engine inputs** apply the explicitly frozen per-allele cap of eight. Capped intervals and regional base counts are recorded; a default hidden engine transformation is not presented as exact source fidelity.

The `highcopy_mask` sensitivity instead removes the entire shared atom if any required region's source allele exceeds eight. It does not select a different patient cohort or replace a missing value. It excludes 911 LUAD and 827 LUSC common atoms, respectively 1,894,160,640 and 2,211,407,491 summed patient bases. The resulting gaps retain the same 1-Mb continuity policy. High-copy masking can remove biologically important focal amplifications; this is a sensitivity to the computational bound, not a preferred interpretation of those events.

The reference ontology uses all 44 autosomal p/q arms from the official [UCSC hg19 cytoband table](https://hgdownload.soe.ucsc.edu/goldenPath/hg19/database/cytoBand.txt.gz), excluding `acen` centromeric bands. `hg19_arms.json` preserves exact BED intervals. The UCSC assembly-gap table is a separate descriptive reference. Neither reference is learned from training/evaluation event frequencies. Arm LOH and WGD rules are fixed in the root configurations and implemented in the separate methods layer; broad events and gene overlaps are not converted to independent evolutionary steps.

## Reproduction and checks

`audit_segments.R` translates the complete verified frozen-patient source rows and retains original one-based row indexes. `audit_quality.py` independently audits coverage, gaps, overlaps, source states and endpoint comparisons. `build_inputs.py canonical` creates local per-patient uncapped common atoms and a hash manifest. Canonical/reference/arm artifacts were locked before any actual patient fit or LOH event-frequency calculation.

`build_inputs.py engine --freeze tracerx_cna_phylo/config_freeze_2026-10-18.json` verifies final root configuration bytes, source/canonical/reference/arm locks and exact implemented gap/cap policies before producing `primary`, `gap100k` and `highcopy_mask` TSVs. The root's pre-fit amendment changes only the total-copy-number diagnostic's unsupported x2 setting to the official +2 topology diagnostic followed by a full primary x2 refit; no actual patient fit preceded the amendment. Runtime constructs that diagnostic separately.

The flat local `source/output/input_manifest.json` lists each histology, original patient/role/regions, variant, input/mapping/canonical paths and SHA256s, source status, number of segments/blocks and capped source intervals/bases. Every original patient remains in the denominator. A patient with fewer than two usable non-diploid regions is explicitly not run. Source and canonical files, input TSVs, per-patient maps and results remain ignored. Only code, aggregate audits, pinned reference metadata and this documentation are versioned.

All **10 independent source checks passed** on the real 342-patient, 1,026-input export. `test_source.py` checks real pinned source/reference bytes, original patient roles recovered independently from both frozen mutation-model artifacts, primary-region scope, code-backed coordinate/phasing semantics, every canonical atom against its exact original source row, reference arm geometry, every engine TSV state and common segmentation, complete high-copy masking, continuity block thresholds, freeze locks, and absence of patient identifiers in versioned aggregate JSON. The pinned reference retriever also verified every downloaded reference file. These computational checks establish translation fidelity; they do not validate inferred evolutionary histories or common routes.
