# Initial candidate Molecular Survival Island criteria

Version 0.1, October 17, 2026. These working criteria define what the first research engine may call a candidate Molecular Survival Island. They implement the investigator's functional-convergence hypothesis without presuming a survival mechanism. Numerical gates are initial project defaults, not established biological diagnostic standards. They are recorded before discovery in `configs/candidate_island_v0_1.json`; changes require a new version and a complete rerun.

A candidate island is a **reproducible coordinated molecular program**, initially detected as a set of coexpressed RNA features with a reproducible activity score. It is a feature program, not a cluster of patients. Each tumor may show activity in several programs. DNA configurations, pathology, normal-reference context, and clinical outcomes describe or test a program; none is required to be identical across tumors.

## Entry and reproducibility

Discover within LUAD and LUSC separately, using primary tumors and one prespecified specimen per participant. A pooled NSCLC overview can display both cohorts, but a module separating their lineages is not automatically a shared survival program. Split participants into 70% discovery and 30% untouched evaluation sets with seed 20261017, before filtering or fitting. Require at least 100 discovery and 50 evaluation participants for the initial reproducibility workflow. Smaller cohorts remain useful for descriptive or fixed-program comparisons.

Here, held-out or untouched means excluded from this project's learned feature selection, module detection, score fitting, and outcome-based decisions. Published upstream batch normalization is fixed and may have used the full source cohort; independence from that preprocessing has not been established. This is internal evaluation of the app's fitted model, not a claim that every preprocessing step was independently estimated in discovery participants.

Use the pinned, batch-normalized RSEM RNA profile and an explicitly verified log2(x+1) transformation. These are continuous expression measurements; count-based models such as DESeq2 are not appropriate inputs for this release. Fit feature selection, missing-value handling, scaling, module membership, score weights, and sign in discovery participants only. Exclude ambiguous identifiers, more than 5% missing measurements, features expressed above zero in fewer than 20% of discovery samples, and features with effectively zero variability. Use up to the 5,000 most variable eligible genes by discovery-set median absolute deviation for the initial computationally bounded analysis. This restricted search space must be visible in every result; absence of a module outside it is not a negative biological finding.

Use versioned Entrez identifiers as the initial gene key and retain source symbols. Exclude every occurrence of a repeated or missing stable gene identifier, recording assay-specific losses, rather than choosing the first row or silently averaging discordant measurements. The audit found repeated keys in both RNA and CNA. RPPA retains its antibody/epitope identity and may map to multiple genes; it must not be forced into the same one-feature-per-gene assumption.

| Check | Initial working gate | Interpretation |
|---|---|---|
| Coordination | Signed coexpression module, normally 20–500 genes; first principal component explains at least 25% of standardized module variance and at least 70% of genes correlate positively with its oriented score at r ≥0.5 | A screen for coordination, not cooperation. Retain larger modules as broad programs requiring review |
| Resampling | Refit in 100 seeded 80% discovery-participant subsamples; match each original module to the best gene-set Jaccard overlap; Jaccard ≥0.5 in at least 80% of runs | Detects sensitivity to participant sampling; show the distribution and module-matching rule |
| Untouched evaluation | Freeze genes and projected activity score; assess density/connectivity preservation, using WGCNA Zsummary >10 as the initial strong-preservation guideline with 200 permutations | Report module size and medianRank because Zsummary depends on size. Do not refit a score in the evaluation set |
| Confounding assessment | Inspect source/technical factors, purity, composition, and relevant clinical variables; show original tissue programs alongside sensitivity analyses | An immune/stromal program can be biologically relevant. Label it; do not silently delete it or call it tumor-intrinsic |

The implementation and all network parameters must be frozen before fitting. Failure to meet a gate yields a **provisional module**, with the failed checks visible. Passing the internal checks yields an **internally reproducible candidate**; reproduction in distinct participants from an independent study yields an **externally reproduced candidate**. An alternative distribution of the same TCGA participants is not external replication. These statuses are separate from the biological evidence tiers.

The method draws on [weighted coexpression modules and eigengenes](https://pmc.ncbi.nlm.nih.gov/articles/PMC2631488/) and [density/connectivity preservation](https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1001057). The filtering, size, coordination, and resampling gates above are project choices rather than thresholds established by those papers. Bulk-tissue composition is a material source of molecular association, as shown in the [primary TCGA purity analysis](https://pmc.ncbi.nlm.nih.gov/articles/PMC4671203/).

## Biological evidence tiers

| Tier | Required evidence | What the app must not imply |
|---|---|---|
| III — Molecular Island of Uncertain Significance | Reproducible coordination, with its internal/external scope visible; survival-related function may be unknown | No demonstrated survival function, cooperation, or actionability |
| II — Survival-Associated Molecular Island | Tier III coordination plus a prespecified association with a relevant endpoint, adequate sample/event counts, confounder assessment, consistent effect direction, and FDR ≤0.05 in both discovery and the declared held-out validation testing families, with effect and confidence interval reported | A same-sign but inconclusive validation estimate remains Tier III with an exploratory annotation. Internal validation must be labeled; patient survival does not establish a cellular survival mechanism |
| I — Functionally Supported Survival Island | Reviewed functional evidence for the specific coordinated program in a relevant context, such as perturbation, rescue, dependency, or convincing causal evidence | A known oncogene, pathway enrichment, or a study of one component does not validate the entire island; no automatic Tier I assignment |

A Tier III candidate does **not** require pathway enrichment, a particular DNA event, a tumor-normal difference, an outcome association, or a new program absent from normal biology. Known normal programs may be repurposed. Curated pathway baselines remain labeled as known programs; scoring them does not constitute discovery of a new island.

Tier evidence records must name the cohort/model, specimens or experiments, program components covered, intervention where applicable, endpoint, effect and uncertainty, limitations, citation, reviewer, and review date. Contradictory and negative evidence remains visible. These research tiers are distinct from clinical somatic-variant classification.

## DNA and phenotype associations

Map mutations and CNA to frozen continuous program scores using the audited sample key. Preserve assay availability separately from alteration status: an unprofiled sample is unknown, and a missing MAF row is not proof of wild-type at every locus. Store the cBio sample key, original DNA barcode where available, and any unresolved vial or aliquot correspondence.

For exploratory alteration–program models, require at least 10 assayed carriers and 10 assayed noncarriers. Report smaller groups descriptively. Prespecify relevant covariates and correct the complete tested alteration–program family with Benjamini–Hochberg FDR at 0.05. Different alteration groups associated with a shared program can support **shared molecular state**; they do not establish causal routes or evolutionary convergence.

For outcome models, require explicit event/censoring definitions, positive valid follow-up, at least 20 events and at least 10 events per fitted parameter as initial feasibility gates. Fit parsimonious, prespecified continuous-score models and check their assumptions; retain the reason when a model is not estimable. Correct the complete module–endpoint family at FDR 0.05. Do not optimize survival cutpoints. A training upper quartile may support descriptive filtering, separate from inference. Prefer the [TCGA curated clinical endpoint resource](https://gdc.cancer.gov/about-data/publications/PanCan-Clinical-2018); the portal's PFS/DFS labels require explicit mapping to the original resource before inferential use.

Historical histology, grade, architecture, cytology, IHC, and molecular subtype remain separate. Missing architecture or IHC is unavailable, not negative. RPPA is protein measurement, not immunohistochemistry. GDC slide links expose their patient/sample/section relationship; a linked slide is not an algorithmically verified histologic pattern.

## Normal references and evolutionary claims

Use adjacent bulk lung only as tissue context, with its cellular admixture, field effects, and processing limitations. Use a healthy, lineage-labeled cell atlas for a separate normal cellular-state reference, with donor-aware signatures and platform-aware comparison. Do not concatenate its raw counts with TCGA bulk RSEM values. Neither reference is a literal tumor ancestor or proof of a cell of origin.

The first between-patient display represents molecular similarity and program activity. It must not show inferred chronology, common clonal ancestry, or branch lengths with evolutionary meaning. Selection, acquisition, plasticity, composition change, and cooperation need additional evidence; TCGA cross-sectional similarity does not distinguish them.

## Acceptance checks for the discovery implementation

- Preserve participant independence and the precise join level. Missing assays never become wild-type calls; missing outcomes never become nonevents.
- Changing evaluation samples cannot alter discovery features, fitted membership, weights, sign, thresholds, or endpoint selection.
- Recover planted coordinated programs and lose coordination after independently permuting gene profiles across participants; simply permuting whole rows is not a valid negative control.
- Detect and label planted technical/composition signals. Rank-deficient models, inadequate groups/events, and unresolved confounding return a specific limitation instead of a significance claim.
- Reproduce scores and resampling under fixed inputs/configuration. Run null checks through the complete selection/testing procedure, not just the last statistical test.
- Keep exploratory guided findings and investigator-defined comparisons on the same specimen/program records. Ad hoc filtering must not silently turn exploratory p-values into prespecified validation.

These are future engine acceptance checks. The current work verifies inputs and defines criteria; it has not fitted modules, tested associations, or assigned any island tier.
