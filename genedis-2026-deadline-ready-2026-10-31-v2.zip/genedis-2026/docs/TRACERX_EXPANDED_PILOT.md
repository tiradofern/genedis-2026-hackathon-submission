# Broader TRACERx drivers and copy-number evidence

The investigator requested an explanation of what limits reliable common routes and authorized expansion to broader driver genes and copy-number alterations, keeping adenocarcinoma and squamous separate. This is a separately frozen extension, not a replacement of the baseline analyses. Both baseline source cohorts, patient roles, model bytes and native patient datasets remain preserved.

## What limits the baseline

The dominant measured bottleneck is **ordering resolution**. A published mutation cluster can contain several drivers without resolving their internal order. Additional regions and a more detailed tree do not automatically separate those events. An event can also be reported as present while lacking a reliable variant-to-cluster placement.

| Baseline training evidence | LUAD | LUSC |
| --- | ---: | ---: |
| Independent patients | 152 | 88 |
| Eligible driver genes | 12 | 5 |
| Co-carrier patient-pair observations | 277 | 75 |
| Strict order resolved | 50 (18.1%) | 12 (16.0%) |
| Same mutation cluster, internal order unresolved | 142 | 56 |
| Variant/cluster mapping unresolved | 80 | 6 |
| Other unresolved categories | 5 | 1 |

These pair observations reuse patients across gene pairs and are not independent patient sample counts. Evaluation resolution is lower: 16/102 LUAD observations and 3/26 LUSC observations. No eligible baseline pair casts a topology-disagreement vote in this subset. Most unresolved observations therefore cannot be recovered by selecting one convenient topology or weakening the all-alternative rule.

Rare co-carriers leave few independent observations per direction. The earlier named candidate panels also omitted many source-curated drivers, and both pilots excluded copy-number-only alterations. Broader candidate coverage addresses that omission, but it also increases the number of tests and does not create more patients or recover missing order. Source ascertainment, sampling, unobserved clones, variant equivalence and the model's conservative partial-order adaptation remain limitations. Bootstrap frequency measures selection under resampling, not the probability that a route is biologically true.

## Frozen expansion

The original 217 LUAD patients (152 training/65 evaluation) and 125 LUSC patients (88/37) remain unchanged. The new candidate rule includes **all source DriverMut TRUE genes observed in training**, then retains every gene passing the same ten-carrier/ten-noncarrier training gate. No evaluation-only gene name or frequency chooses this catalogue. Authors' annotations remain source inputs, not independent functional validation or an independently ascertained external panel. The broader rule is consistent with the driver annotation framework described by [Frankell et al., Nature 2023](https://doi.org/10.1038/s41586-023-05783-5).

Separate configurations were frozen before expanded gene inventories, frequencies or fits: `configs/tracerx_expanded_luad_v0_1.json` and `configs/tracerx_expanded_lusc_v0_1.json`. Their hashes and exact snapshots are recorded in `tracerx_expanded/config_freeze_2026-10-18.json`. Existing source placement and all-alternative ancestry rules, genuine ASCETIC, patient resampling, ordering nulls and multiplicity are preserved. No significance or evaluation result chooses genes or prunes selected edges.

The original evaluation patients have already been inspected in earlier pilots. They remain fixed for comparability, but this sequential extension is **exploratory**, not untouched or independent external validation. Baseline and expanded total log scores target different event universes and must not be directly compared as evidence of improved reliability. Each model is checked against its own independent-event comparator.

## What copy-number data can contribute

The public [Karasaki TRACERx source deposit](https://zenodo.org/records/7683605) provides regional allele-specific segments, total/major/minor copy numbers, ploidy and aberrant cell fraction, a 67-gene CNA panel, and source-reported amplification, homozygous-deletion and genome-doubling events. Exact source files, hashes, versions and academic non-commercial terms are recorded separately.

The audited tables do not provide a verified comparable CNA-to-mutation-tree branch placement. Their `Tumour.cluster` is a multiple-primary tumour grouping, not a mutation cluster. The core [Frankell figure-code deposit](https://zenodo.org/records/7822002) contains doubled-mutation-cluster groupings and a CCF similarity heuristic, but these are not a deposited verified joint branch map. That heuristic was inspected and not run as if its inferred matches were source truth. Clonal status and regional sharing alone do not establish which CNA or mutation occurred first.

Copy-number alterations are therefore included as **source presence/coverage context**. The rule accepts authors' driver `Amp` calls for OG panel genes and `Homdel` calls for TSG panel genes; `GD` remains separate WGD context. Exact source rows, raw clonal labels, regional coverage and shared segment identities are preserved. Reported, not_reported and assay_unavailable states remain distinct. Not reported is not verified copy-neutral or wild type, and segment availability does not guarantee complete gene-level callability. Genes on one broad gain/loss or one WGD do not become independent evolutionary steps.

No de novo CNA or LOH driver calls, CNA chronology tests, ordered CNA nodes, mutation-length branches or SNV/CNA ancestral arrows are invented. Reliable joint CNA/mutation routes would require a defensible patient-specific mapping or a separately validated joint reconstruction accounting for allelic state, losses, recurrence and WGD. The new source layer exposes those missing requirements instead of masking them.

## Delivery and verification

The actual expanded mutation runs retain 18 LUAD genes from 194 training-observed curated candidates and eight LUSC genes from 161 candidates. No baseline eligible gene is lost. Added LUAD genes are ATM, ATRX, CREBBP, GRIN2A, KMT2C and KMT2D; added LUSC genes are CUX1, FAT1 and NF1.

| Separate mutation analysis | Baseline genes → expanded genes | Training strict order / all pair votes | Selected dependencies | Directions passing BH 0.05 |
| --- | ---: | ---: | ---: | ---: |
| LUAD | 12 → 18 | 85 / 463 (18.4%) | 6 | 0 / 306 |
| LUSC | 5 → 8 | 22 / 134 (16.4%) | 3 | 0 / 56 |

All 100 patient-bootstrap and 100 engine-null fits completed per histology, alongside 10,000 primary ordering permutations. The broader catalogue adds observations but barely changes the proportion with resolved order. LUAD KEAP1 → STK11 still has only two strict training observations among 12 co-carriers and no resolved order among five evaluation co-carriers, despite 84% model selection under resampling. Every selected LUAD dependency lacks resolved evaluation order. LUSC CDKN2A → KMT2D retains one compatible evaluation observation among two co-carriers. No reliable shared route is established in either expanded analysis.

Expanded joint-event prediction is below its own independent-event comparator by 0.096810 nats per evaluation patient for LUAD and 0.003884 for LUSC. These are exploratory reused-evaluation checks, not temporal validation or directly comparable baseline-versus-expanded likelihood targets. Every selected edge, weak support, unresolved category and negative association remains visible; source evidence is not pruned to make a preferred graph.

The CNA layer adds all 67 typed source driver-gene events plus separate WGD context. There are 358 reported LUAD and 435 reported LUSC gene–patient units; these are **not independent evolutionary steps**. All 342 patients have SCNA rows for every frozen primary region, but gene-specific measurements remain incomplete: 675 LUAD and 413 LUSC gene–patient units are assay-unavailable. AMER1, GPC3 and KDM6A lack source gene coordinates/measurements for all included patients; they are unknown, not negative. An additional 64 LUAD and 63 LUSC gene–patient assay units have some measurements without complete primary-region coverage. No reported CNA call lacks a source gene-mean measurement.

For example, source-reported WGD occurs in 157/217 LUAD and 104/125 LUSC patients; source SOX2 amplification is reported in 74/125 LUSC patients. These context counts do not establish when the alteration occurred relative to a specific mutation. The 2,884 LUAD and 1,487 LUSC coordinate units overlapping multiple panel genes remain shared genomic context; genes at those loci do not become separate ordered votes.

The expanded companion runs separately on loopback port 4003 and distinguishes baseline/expanded analyses and LUAD/LUSC. The baseline 4002 application and all existing Nextstrain patient reconstructions remain preserved. Expanded mutation evidence links to the same genuine patient trees, which already display all exact source-curated driver annotations. CNA context stays separate from mutation-order arrows.

All 59 automated checks pass: 28 existing Python, five existing Node, 11 expanded source, seven inference and eight display checks. JavaScript syntax and both new native model schemas pass. A separate source review independently rederived all pair categories, candidate gates, 362 directional tests/corrections and evaluation scores without importing the inference implementation. Official-engine RDS review matched all 240 training matrices and all nine selected edge indices, with 102 evaluation patients excluded from fitting. The preservation record verifies 51 original artifacts and all 342 original native patient dataset bytes unchanged.

One bounded live desktop check covered all four histology/analysis combinations, exact pair categories, CNA role filters, explicit assay-unavailable states, a selected patient's on-demand shared-segment trace, and both expanded model views in genuine Auspice. Screenshots confirm the overview, CNA context and native projection. Mobile rendering remains unverified. Computational/source fidelity does not establish biological reliability.

Implementation `c677e0aef32716cc13e091767d034d46ee9b25fc` is in [draft PR #7](https://github.com/tiradofern/genedis-survival-islands/pull/7), based on `analysis/tracerx-histology-strata`. The independent desktop finish review found no material issue; design documentation records this bounded extension. No merge has been performed.

See `TRACERX_EXPANDED_SOURCE.md`, `TRACERX_EXPANDED_METHODS.md` and `TRACERX_EXPANDED_VIEW.md` for provenance, actual results, reproduction and verification. Source and patient-level outputs stay local and ignored; aggregate evidence and code are versioned. No survival analysis, clinical prediction, RNA-program refit or biological tier assignment is added.
