# Local explorer v0.1

The first working app uses the verified October 17 public TCGA inputs. It supports a linked molecular landscape, specimen and program inspection, gene-level RNA/CNA/reported MAF events, GDC slide-record links, frozen group comparisons, and export/restore of exploration state. It runs on `127.0.0.1` and serves local read-only data. There is no hosted deployment or account system.

## Start on this Windows checkout

The isolated `.venv` and prepared data already exist on the investigator's machine. From the project directory:

```powershell
& '.\Start Explorer.ps1'
```

Open **http://127.0.0.1:8766** and leave that process running. Ctrl+C stops it. The launcher prepares data only when the prepared manifest is absent. If configuration or fitting code changes, stop the server and run preparation again; startup rejects a stale recipe or changed artifact.

## Set up another checkout

Python 3.11+ is required. Preparation uses pinned NumPy/SciPy; the HTTP server uses Python's standard library. The browser interface has no package installation or build step.

```powershell
python -m venv .venv
& '.\.venv\Scripts\python.exe' -m pip install -r requirements-app.txt
& '.\.venv\Scripts\python.exe' scripts/audit_public_tcga.py --download --include-mutations
& '.\.venv\Scripts\python.exe' scripts/prepare_explorer.py
& '.\Start Explorer.ps1'
```

The audited sources occupy approximately 647 MB. Raw inputs, generated matrices, SQLite, and the local environment are ignored by Git. `scripts/run_explorer.py --port 8767` can select a different local port. Unix users can run the equivalent commands with `.venv/bin/python` and launch `scripts/run_explorer.py` directly.

## Use the linked workspace

1. Choose LUAD or LUSC. Each landscape is fitted separately. Filter stage, sex, purity, a gene's reported DNA events, or a provisional program's activity. Mobile users can expand **Filter specimens**.
   In **Color by → Pathologic stage**, stages I–IV use blue, orange, green and purple; unknown is gray. Matching swatches appear beside the stage filters. **Program activity** and purity use cyan for lower values, blue at the scale midpoint and purple for higher values. The labeled keys and specimen table provide the corresponding meanings. Color changes preserve molecular coordinates and scores.
2. Load a source gene symbol or Entrez ID. The table shows log2(batch-normalized RSEM + 1), GISTIC CNA, and presence of any reported MAF event. **No reported event** is not a verified wild-type call. Variant classes include synonymous and other source classifications; no clinical prioritization is applied.
3. Select a point or specimen identifier. Inspect source diagnosis, available measurements, model role, and GDC slide records. Slide images are not downloaded; sample-key and patient-only links remain distinct. IHC and grade remain unavailable. RPPA availability is shown, but the v0.1 interface does not yet expose protein-level values.
4. Inspect a provisional RNA program and color the landscape by its score. **Upper training quartile** uses the frozen training threshold, not a diagnostic cutoff. Normal tissue triangles are bulk RNA context projected through the tumor training transform. They are not ancestors, germline DNA, or a cell-of-origin atlas. PCA coordinates represent between-patient similarity, not a phylogeny, chronology, or trajectory.
5. Save the current population as group A or B. Membership stays fixed as filters change. The comparison removes shared tumors from both groups and reports descriptive mean differences only. A difference in the score used to define a group is expected. Covariates have not been controlled and no inference or tier promotion follows from this view.
6. Export selection CSV or exploration JSON. **Data & criteria → Restore exploration** accepts the same dataset/recipe fingerprint. Reloading the page clears unsaved selections; nothing is stored in browser local storage. Export is the persistence mechanism.

## What was fitted

The prespecified implementation is `configs/explorer_build_v0_1.json`, within `configs/candidate_island_v0_1.json`. This first exploration restricts discovery to the top **2,000** eligible training-MAD genes, below the scientific specification's 5,000-gene maximum. It uses signed weighted correlation (power 6), average linkage, and distance cut 0.92. No tuning used outcomes or evaluation participants. The feature universe and fixed cut materially affect module membership; this is one provisional implementation, not an optimized or exhaustive island catalogue.

| Cohort | Training | Evaluation | Provisional programs | Training coordination screen passed |
|---|---:|---:|---:|---:|
| LUAD | 354 | 153 | 14 | 14 |
| LUSC | 336 | 145 | 11 | 11 |

All 25 modules exceed the 20-gene minimum and satisfy the initial training coordination screen; none exceeds 500 genes. These are computed exploratory outputs, **not validated islands**. The 100 resampling runs, holdout preservation, enrichment, purity/composition sensitivity, controlled clinical association, and external/functional evidence review have not run. No biological tier has been assigned, including Tier III. Published upstream normalization may have used the entire source cohort; the local split does not undo that preprocessing.

Feature filtering, imputation, centering/scaling, PCA, module memberships/loadings/signs, and activity thresholds are learned on training participants. Evaluation and normal samples receive frozen projections. Every repeated/missing stable Entrez ID is excluded, rather than retaining an arbitrary row. Per cohort this removes 50 tumor-RNA rows, 319 CNA rows, and 9 normal-RNA rows; these include missing/nonpositive identifiers as well as repeated IDs. The full loss log remains in `data/processed/explorer_v0_1/feature_exclusions.json`.

Prepared artifacts contain source clinical metadata, gene catalogs, RNA/CNA matrices, frozen transformations/loadings, score records, slide metadata, and a read-only MAF SQLite index. Startup checks configuration, recipe and artifact hashes. The fingerprint includes fitting/preparation code, configuration, sample/slide manifests, and all 47 source hashes. The source commit is `7a4b4ec142f76ac04db22834232b23142d25bd2a`. `results/reports/explorer_preparation_2026-10-17.json` records this build's small audit summary. Complete program gene sets and full-precision weights are in the local bootstrap and available from `/api/bootstrap`.

## Verification and current limits

```powershell
& '.\.venv\Scripts\python.exe' -m unittest discover -s tests -v
node --test tests/frontend.test.mjs
node --check web/app.js
& '.\.venv\Scripts\python.exe' -m compileall -q scripts src tests
```

The 28 Python tests include synthetic planted coordination, holdout leakage checks, participant independence, explicit identifier exclusions, missing measurements, overlap removal, stale-artifact rejection, and HTTP error handling. Five Node tests exercise independent filters, missingness, training thresholds, snapshot validation, and CSV quoting. Synthetic fixtures are tests only; the app contains actual audited public data. These checks do not establish biological validity.

The optional `tests/browser_smoke.cjs` requires Playwright and a running server. With an installed Chrome, set `EXPLORER_BROWSER_CHANNEL=chrome`; make Playwright available through the normal Node resolution path or `NODE_PATH`. It checks real cohort counts, gene/MAF filters, GDC links, area selection, group overlap, export/restore, empty results, and desktop/mobile behavior. Screenshots and output go to ignored `work/qa/`. No browser download or global package installation is required on this machine. Local browser checks passed at 1440×1000 and 390×844 with no JavaScript exceptions or page-level mobile overflow; this is not an exhaustive accessibility or cross-browser audit.

The next scientific milestone is the reproducibility/preservation workflow and composition sensitivity before any Tier III assignment. Next app extensions can expose RPPA values and complete program membership in the interface, add curated evidence review, and support additional independently verified cohorts. The presentation cases remain outside app prerequisites.
