# Shared tasks

## Current execution handoff — October 31

Completed: Quek clinical/source identity audit and frozen cell identification; both MCC raw-matrix reconstructions; NSCLC patient crosswalk and uniform numeric QC; complete 50-program descriptive/conditional RNA run; strict cell-mask sensitivity; exact independent replay; full tables, figures and adversarial reviews. Read `pilot/cellular_2026-10-31/RESULTS_2026-10-31.md`.

Scientific HOLD: robust MSI nomination is inconclusive because melanoma coordination sensitivity is unassessable. NSCLC primary validation is not reached; no protein-program effects were run. Next investigator-directed study needs stronger independently supported malignant-cell coverage/additional patients and a compatible NSCLC functional assay. Do not tune the frozen method to rescue OXPHOS. Preserve the previous submission archive; organizer delivery, merge and permission changes remain outside this execution.

## Latest: enforce separate primary and exploratory eligibility

- Primary: verify two non-NSCLC cancers with treatment-specific acquired-resistance evidence plus the approved independent NSCLC endpoint before candidate discovery.
- Exploratory only: Yang 509 has documented benefit→progression but unresolved treatment status and uncertain acquired resistance. It does not count toward primary feasibility. Preserve this category separately and assess inclusion sensitivity only with a qualifying primary analysis.
- Continue technical metadata checks without calculating program effects; retain reader failures and clinical unknowns. Protein measurement approval remains in force within reliable component coverage.

## Latest: complete the approved orthogonal-validation route

- Accepted: protein measurements may support NSCLC validation for reliably measured program components, with restricted orthogonal claims.
- Continue: complete MCC annotation/timepoint reconciliation, verify the melanoma clinical/annotation link and test faithful processed-object metadata extraction. Preserve the full pan-cancer design.
- Before effects: freeze the RNA-to-protein component mapping and endpoint-specific analysis/adequacy rules. The modality approval alone does not open the full clinical/measurement gate.

## Latest: execute the retained pan-cancer plan, subject to the complete data gate

- PI decision: keep the full pan-cancer requirement and continue feasibility before molecular analysis; do not run the offered NSCLC-only replacement.
- Complete: parallel clinical/access follow-up, correction of unapproved gate restrictions, and bounded numerical preparation with 14 new synthetic tests. The full 42-test Python suite and five frontend tests pass.
- Current evidence and implementation entry point: `pilot/cellular_2026-10-31/README.md`. No expression matrix was retrieved for this follow-up, and no real-data scores or molecular candidates were generated.
- Pending: verify a complete clinically eligible, measurable discovery/validation combination, including the conditional restricted orthogonal NSCLC protein route; then freeze endpoint-specific measurement, coordination, inference, multiplicity and adequacy rules before effects. These remain uncompleted prerequisites, not a positive gate.
- Preserve the existing release/archive and negative results. Metadata feasibility is not automatically the hackathon's replacement scientific deliverable. Further scope changes and final organizer delivery require explicit PI decisions.

## Latest: end-to-end feasibility before molecular discovery

- Complete: record four PI resolutions following Justin's PR #13 and conduct a bounded public clinical/sample metadata audit.
- Gate outcome: no complete qualifying combination verified; hold molecular scoring and candidate selection. Source-level counts are not final eligible/powered denominators.
- Revised immediate scope: preserve the existing NSCLC reconstruction/feasibility submission and document the new study's data obstacles. The full pan-cancer single-cell goal remains conditional future work.
- Next targeted evidence: clinical supplements/crosswalks for Quek/Bi/Yost and targeted-therapy leads; actual public NSCLC scRNA access and acquired subset; then endpoint-specific measurement/precision planning if a chain becomes credible.
- Any reduced discovery breadth, changed treatment matching or protein-only validation needs a recorded scientific scope decision before molecular candidates. No silent substitutions or new biological analyses are authorized here.


## Latest task: review the consolidated PI decisions

- Completed: consolidate the interview into `reviews/PI_DECISIONS_FOR_JUSTIN_2026-10-31.md`, with 16 preferences, explicit supersessions and unresolved operational choices.
- Awaiting Justin: one evidence-linked support/amend/disagree/needs-evidence response, including the smallest defensible next study. His first findings draft in PR #12 is available; these later decisions still need assessment.
- Subsequent joint work: Fernanda, Justin and Codex reassess the response, record accepted/deferred changes and only then define any authorized implementation. No further broad PI interview is needed now.
- Preserve: frozen scientific release/archive and old closed cohort gates. New dataset feasibility is unverified; no new biological analysis or organizer delivery occurs under this coordination task.


## Current review requested by the PI

1. Justin independently evaluates the frozen plan/results at `c0599df`, challenges the cohort gates and existing AI reviews, and returns evidence-linked recommendations. Request prepared; his acceptance/report is pending.
2. Fernanda, Justin and Codex reassess the recommendations using a response/decision matrix. Fernanda adjudicates scientific decisions; recommended changes are not automatically authorized.
3. If revisions are authorized, preserve the original release, implement only the agreed scope, and give Justin an opportunity to verify resolution of material findings. Final organizer delivery still needs separate explicit PI approval.

Current request and templates: `reviews/JUSTIN_PLAN_RESULTS_REVIEW_REQUEST_2026-10-31.md`. This review sequence takes precedence over the earlier proposed human-review row below. The coordination update is documentation only; no new analyses are assigned or run.

## October 31 release work — accepted execution scope

The PI authorized local implementation and package preparation; external organizer delivery remains approval-gated. AI stream ownership is bounded by path, and all human assignments below remain proposals until accepted.

| Stream | Current outcome | Owner/interface |
|---|---|---|
| Existing-release recovery | Complete: 47 exact inputs, 25 provisional definitions, two fresh fits and 28+5 tests/browser pass | Recovery stream; `release_recovery/` |
| Longitudinal gate | Complete: no inferential go for either candidate; no paired effects tested | Cohort stream; `pilot/cohorts/` |
| Published panel | Complete: six MSigDB 2024.1.Hs sets pinned with hashes/terms | Program stream; `pilot/programs/` |
| Requirements | Confirmed organizer brief; archive/link accepted; no Springer template | `submission/requirements_audit.md` |
| Independent review | Core export, scientific scope, preflight and pinned replay reviewed; final ZIP receives a separate content/hash receipt | `independent_review/` |
| Integration/replay/package | Complete review candidate: pinned replay passes; first failed attempt preserved; clean-commit archive built and checked at delivery | Root; `submission/` |
| Human review | Proposed PI/Justin tasks prepared, not sent or externally assigned | `submission/PI_JUSTIN_HANDOFF.md` |
| Organizer submission | Not performed; explicit final PI approval required | PI |

Normal-reference-first B10: the separate GTEx/Healthy-HLCA normal-only baselines and linked view are implemented and assessed on `analysis/normal-reference-first`, based on completed CNA commit `7c11329`. GTEx has limited fine-tissue discrimination and weak rejection controls; HLCA's locked rejection-consistency gate failed despite high represented-class recall, and study transfer is uneven. Preserve these negative findings and frozen models. No LUAD/LUSC tumor projection is made; comparable RNA processing and reference/rejection adequacy remain unresolved. Protein/DNA overlays remain later work.

Task ownership and methods remain proposals until the collaborators agree. Use GitHub issues for focused discussion when useful, and link the resulting branch or pull request here. Avoid duplicate parallel edits to the same sample manifest.

October 17 update: the investigator explicitly requested public-data verification and initial candidate-island criteria. These are complete for the TCGA first-build recommendation; see the readiness report and version 0.1 criteria. The prior GSE248249 audit remains a separate resistance extension. Earlier work packages remain available but no longer define the only technical sequence. Presentation cases and missing presentation text do not block the app.

October 18 Nextstrain review: B04 is implemented and verified in [draft PR #3](https://github.com/tiradofern/genedis-survival-islands/pull/3), stacked on `ui/brighter-landscape-colors`. The working local application and source/reproduction guides are in the isolated prototype checkout. The subsequently authorized B05 pilot is in [draft PR #4](https://github.com/tiradofern/genedis-survival-islands/pull/4) on `analysis/nsclc-population-routes`, stacked on `app/nextstrain-tumor-proof`; implementation commit `7d9f2f4483a991c9c64fe7a42de33cbac509fb81`. See the population-route guides. No merge has been performed.

October 18 multi-region review: B06 is implemented and verified in [draft PR #5](https://github.com/tiradofern/genedis-survival-islands/pull/5) on `analysis/tracerx-multiregion-routes`, stacked on `analysis/nsclc-population-routes`; implementation commit `356df756e11f0f972860d800d74e9dbca74285a5`. The live source evidence and native patient-tree views are documented in the TRACERx guides. All 99 local checks pass; the exploratory analysis does not establish a validated common route.

Subsequent histology clarification: Fernanda chose separate adenocarcinoma and squamous analyses. B07 is implemented in [draft PR #6](https://github.com/tiradofern/genedis-survival-islands/pull/6) on `analysis/tracerx-histology-strata`, stacked on B06's branch; implementation commit `1f76cd9d42df2a919175213bc0496a5466cdf614`. B06's frozen LUAD artifacts remain unchanged. The LUSC configuration fixes 125 independent participants and 88/37 training/evaluation roles before event frequencies or ordering/model results. No merge has been performed.

Expanded-event authorization: B08 is implemented in [draft PR #7](https://github.com/tiradofern/genedis-survival-islands/pull/7), on `analysis/tracerx-expanded-events`, stacked on B07's branch. Implementation commit `c677e0aef32716cc13e091767d034d46ee9b25fc` adds the complete training-only authors-curated mutation-driver universe and source CNA/WGD presence/coverage context, with separate histologies and all baseline artifacts preserved. Source audits did not establish comparable CNA branch placement; no ordered CNA model nodes or arrows are invented. All 59 checks and the independent source/engine/desktop reviews pass. No reliable shared route is established; no merge has been performed.

| ID | Work | Status | Owner | Completion criterion |
|---|---|---|---|---|
| S01 | Continue investigator interview and cumulative scientific record | In progress; prior functional-convergence question answered by Update #2 | Fernanda as investigator; Codex facilitates | Preserve the decision that identical alterations are not required; clarify program boundaries, reproducibility, tier evidence, normal references, and pathology/IHC linkage one question at a time |
| S02 | Define research-data demonstration evidence | Complete for initial recommendation | Codex, as requested by Fernanda | Verified full TCGA RNA/CNA/MAF, clinical, normal RNA, purity and slide metadata; frozen source and sample manifests; remaining modality limitations explicit |
| S03 | Define initial candidate-island criteria | Complete as working version 0.1 | Codex, as requested by Fernanda | Versioned coordination, internal reproducibility, tier evidence, missingness, confounding and acceptance rules; no discovery findings implied |
| B02 | Build the app data layer and linked exploration workflow | First local slice implemented; app branch under review | Codex under explicit investigator authorization | Linked RNA/CNA/MAF, specimen/GDC records, program scores, frozen descriptive comparisons and export/restore work; RPPA values and richer morphology/evidence integration remain extensions |
| B03 | Improve landscape color visibility | Complete locally, October 18 | Codex, at investigator request | Brighter stage and continuous colors, larger opaque dots, matching stage swatches and legend keys; plotted membership/coordinates and selection behavior preserved |
| B04 | Run a published lung-cancer reconstruction in actual Nextstrain Auspice | Complete locally, October 18; isolated `app/nextstrain-tumor-proof` branch | Codex with explicitly authorized parallel agents | Official Auspice 3.1.0, pinned source extraction and format adapter, exact published topology/SNV lengths, source-based regional coloring, schema/fidelity tests and live browser controls verified; no new evolutionary inference |
| B05 | Run the first across-patient NSCLC event-model pilot | Implemented locally, October 18; exploratory results under review | Codex under investigator authorization, with parallel source/method/view checks | Genuine CAPRI, fixed LUAD roles and event criteria, baseline plus investigator-selected pathology sensitivity, 100 bootstrap/100 burden-null fits per run, frozen held-out scoring, exact DAG and actual Auspice edge view with uncertainty; no claim of validated routes |
| B06 | Test population routes with multi-region TRACERx phylogenies | Complete locally, October 18; exploratory results under review | Codex under investigator authorization, with source/method/view agents | 217 independent LUAD patients, exact curated-driver placements, all-alternative ancestry consensus with unresolved states, frozen 152/65 roles, genuine ASCETIC, patient bootstrap/order nulls, held-out assessment, live evidence explorer and 217 inspectable native patient trees; 99 checks pass, no tested direction passes BH 0.05 and no selected dependency has resolved evaluation ancestry; no claim of validated routes |
| B07 | Analyze TRACERx squamous separately and support histology selection | Complete locally, October 18; exploratory results under review | Codex with source/method/view agents | Separate 125-patient LUSC cohort with 88/37 roles, five eligible genes, genuine ASCETIC, 100 bootstrap/100 engine-null fits and 10,000 ordering permutations, locked evaluation, 125 additional native patient trees and live histology selector; 88 checks pass, prior LUAD bytes preserved, no direction passes adjusted testing and no shared route is validated |
| B08 | Expand mutation drivers and include source copy-number evidence | Complete locally, October 18; draft PR #7 | Codex with explicitly authorized source/method/view agents | Separate 18-gene LUAD and eight-gene LUSC fits; 67-gene CNA panel plus WGD presence/coverage context; 59 passing checks and independent source/engine reviews; desktop app and native views verified; 51 baseline artifacts and 342 native patient files unchanged. No adjusted ordering signal, fabricated CNA chronology or independent-validation claim |
| B09 | Reconstruct patient-specific CNA trees and screen recurring CNA routes | Complete locally; investigator-approved private draft PR #8 | Codex with explicitly authorized source/runtime/method agents | All 1,368 main fits and 6,840 planned chromosome slots terminal; one uninformative draw retained, no engine failure/retry. Separate LUAD/LUSC screens, independent source/draw/state/statistical audits, 77 passing checks and verified desktop/native views. Primary/qualified denominators preserved; no adjusted common-route signal or joint SNV/CNA clone claim |
| B10 | Build a normal-reference-first RNA similarity analysis | Normal-only baselines implemented and assessed; HLCA gate failed, tumor projection blocked | Codex with authorized source/model/independent-review agents | Both exact source audits, donor-blocked fits, locked development/calibration, held-out donor intervals, rejection controls, 100 donor resamples per reference plus 100 HLCA full-pipeline resamples and ten genuine study-held-out refits; linked separate view and all prior analyses preserved. Actual limitations remain explicit; a similarity hierarchy is not ancestry |
| D02 | Implement and validate candidate-program discovery | Provisional fit complete; reproducibility validation pending | Codex implemented first fit; later scientific work unassigned | Explicit feature losses, fixed participant split and model, planted-signal/leakage tests complete; 100 resampling runs, holdout preservation, composition sensitivity and independent validation still required before tier assignment |
| P01 | Prepare illustrative presentation cases | Presentation only; outside build prerequisites | Unassigned | Illustrate potential real-life use through the preferred pathology narrative, with accurate source labeling; no required linkage to the analysis cohort |
| A01 | Dataset discovery and feasibility audit | Complete | Initial audit | Manifest, patient crosswalks, sources, integrity report, and rerunnable audit code |
| R01 | Independent scientific and technical review | Ready for Justin | Justin proposed; acceptance pending | `reviews/justin-initial-review.md` with evidence, prioritized issues, minimum study, and proposed contribution; return by review PR |
| B01 | Complete GPL23126 annotation and batch/site QC | Conditional resistance extension; not a TCGA app prerequisite | Unassigned | Versioned mapping and losses, distributions/PCA/pair diagnostics, and explicit go/narrow/stop recommendation |
| C01 | Freeze pathway baseline and paired statistical plan | Depends on review and QC | Unassigned | Prespecified scores, gene universe, effect/uncertainty, multiplicity, and sensitivity criteria |
| C02 | Define baseline-response comparison | Depends on review and fixed signatures | Unassigned | Endpoint, histology handling, eligible patients, parsimonious model, and limited interpretation |
| D01 | Assess whether stable novel modules can be supported | Deferred until baseline/QC | Unassigned | Transparent definition, patient-level resampling, and comparison with established pathway baselines |
| E01 | Audit TCGA modality intersection and genomic context | Depends on prioritized candidates | Unassigned | Exact within-TCGA sample matching and clear cross-cohort relation to GEO |
| F01 | Independent analysis rerun and submission preparation | Later | Unassigned | Clean reproducible run, exportable figures/tables, limitations, source terms, and final template check |
