# Methods status

**Implemented:** bounded HTTPS acquisition; GEO matrix-header parsing; read-only XLSX metadata extraction; sample and patient reconciliation; paired-site and technical-filename inventory; column/identifier/numeric integrity checks; explicit provenance and hashes. These are feasibility methods, not a complete analysis pipeline.

**Proposed, not implemented:** complete Clariom D annotation and QC; patient-paired pathway scores and differential expression; multiplicity control; biological comparison of fixed signatures; resampling-based module robustness; separately audited TCGA genomic context. The analysis plan, software packages, transformations, gene universe, random seeds, and source pathway versions will be frozen after cohort/scientific review.

No gene filtering, expression normalization, ComBat correction, statistical inference, coexpression discovery, machine learning, or inferential figure was performed during this audit. A source matrix's hash and zero missing cells establish file integrity, not adequate biological or sequencing QC.
