# Scientific and collaboration decisions

## October 31 execution record: retain primary limits despite a technical signal

Under renewed build authorization, execute the original two-cancer fixed-program measurements with the frozen protocols/gates in `pilot/cellular_2026-10-31/`, preserving the full primary design. Pre-effect independent review permits descriptive/conditional measurements but holds robust MSI nomination because the melanoma primary/strict masks retain six/five cells and the latter cannot assess coordination. The primary scientific objective remains inconclusive; this is not a newly approved substitute study or a completed end-to-end validation.

The completed run reports all 50 Hallmarks, 46 activity-assessable and 31 primary coordination-assessable. The OXPHOS technical BY q=0.044992 does not override the hold. No candidate was nominated and no real NSCLC protein follow-up was run. NSCLC source readiness is separately verified. Frozen pre-effect commits are `74cf912` and `85b3694`; all scientific fields and CSVs match exact replay. Preserve every exclusion, source conflict, unassessable endpoint and negative result. No threshold/mask/covariate alteration to rescue the observed signal. A changed future study remains investigator-directed. See the executed results, reviews and reconstruction record.

## October 31, 2026: strict primary discovery, separate uncertain-case exploration

The PI accepted both categories with distinct roles: primary discovery requires acquired resistance supported by treatment-specific clinical criteria; a separately labelled exploratory analysis may include uncertain benefit→progression cases and assess whether they change findings. Uncertain cases do not satisfy the qualifying discovery-cohort gate.

Yang 509 is classified as documented initial benefit followed by progression, treatment status at progression unresolved, acquired resistance uncertain. The four-day biopsy interval does not establish whether progression occurred during treatment. Treatment discontinuation alone neither automatically establishes nor excludes resistance; the relevant last-dose interval, reason for stopping and intervening treatment require assessment. See the [clinical eligibility decision](../pilot/cellular_2026-10-31/CLINICAL_ELIGIBILITY.md). Protein validation remains approved within its restricted measurement scope.

## October 31, 2026: restricted NSCLC protein validation approved

The PI explicitly accepted protein measurements for independent NSCLC validation, limited to the program components reliably covered by the assay. Retain RNA discovery across at least two non-NSCLC cancers, patient independence and the comparable-treatment-family requirement. Report the NSCLC step as orthogonal evidence for its measured component; do not claim complete RNA-program replication, genomic conservation or causal resistance.

This approval resolves the modality preference. It does not verify clinical eligibility, malignant-cell annotation, processed-object extraction, biologically sufficient component coverage, coordination or statistical adequacy. Those gates and prospective mapping remain necessary before candidate selection. Necessary public processed-object retrieval for metadata and structural QC can proceed under the existing build authorization without computing molecular program effects.

## October 31, 2026: renewed execution and retained pan-cancer gate

The investigator requested maximum-effort execution, including parallel work and adversarial review. When offered a smaller NSCLC-only acquired-resistance pilot conditional on data verification, she explicitly retained the full pan-cancer requirement and directed feasibility work before molecular analysis. Do not substitute the old NSCLC explorer or a metadata report for the requested molecular-discovery deliverable automatically.

The [gate review](../pilot/cellular_2026-10-31/GATE_REVIEW.md) corrects assistant-added restrictions without changing the approved objective. At least two cancer types is a breadth requirement, not an approved minimum of two patients per type. Similar therapy families need prospective biological justification rather than identical regimens; additional agents require strata and limit attribution. Neither whole-transcriptome coverage nor login-free processed access is universal. Adequate targeted RNA or a justified orthogonal protein component may support a properly specified endpoint, while protein support is not full RNA-program replication. No numeric cell minimum, majority-cell threshold, mandatory pretreatment increase or mandatory responder cohort is introduced.

The complete qualifying combination remains unverified. New arithmetic/aggregation code and synthetic tests are computational preparation only; no dataset-dependent program collection, coverage threshold, inference family or candidate list is frozen, and no real molecular analysis has run. Preserve prior work and negative results. Final scientific scope decisions remain with the PI; author contacts, access applications, access changes, merges and organizer submission are not authorized.

## October 18, 2026: normal-reference-first implementation

Implement the supplied `docs/normal_reference_handoff_2026-10-18.txt` separately, preserving completed CNA and earlier models. Build and assess normal profiles before fixed tumor queries. Keep body-wide GTEx bulk and healthy-lung pseudobulk models/units distinct; a similarity hierarchy and RNA resemblance do not establish origin, ancestry or chronology. Exact primary source exclusions remove cultured/transformed GTEx contexts and all tumor-adjacent HLCA donors while retaining records/reasons. This implements the handoff's normal/adjacent distinction; it does not certify every GTEx donor as healthy or invent a RIN cutoff.

Block donors across tissues/cell types before learning features. Training, development, calibration and normal test remain separate; development choices lock before test inspection. Report unsupported populations, rejection, donor uncertainty, study-transfer limits and the exact bootstrap scope. A failed gate limits claims and cannot be tuned away using tumors. RSEM tumor projection awaits comparability. HPA protein and SMaHT DNA remain later layers; no map assigns a biological tier or cellular fraction.

The first actual assessment is retained without test-driven tuning: GTEx macro-recall is 67.57% across 49 observed of 52 trained tissue classes, with weak rejection controls despite passing its descriptive development-consistency checks. Healthy-HLCA represented-class macro-recall is 98.15%, but its rejection-consistency gate failed (45.80% versus locked 60.03% lower bound), all three unsupported Mesothelium test profiles were accepted as fibroblasts, and study-held-out recall ranges from 42.26% to 100% with unequal populations. High internal classification accuracy does not override these failures. The delivered baseline is inspectable and assessed; reliable off-reference tumor mapping is not established. A future improvement requires a separately versioned, prespecified analysis rather than reopening this test set to retune the frozen baseline.

The completed source audits bind every actual input/producer. HLCA's raw-only transport amendment retains the immutable source version and exact raw groups, with a separately hashed derived file and technical range ledger; no whole-original-H5AD checksum is claimed. Added restoration/display helpers preserve all frozen scientific bytes and never rebless changed model results. GTEx conditional neighbor stability averages 99 complete draws, while branch support uses all 100; HLCA's full training-pipeline stability retains all 100 draws with missing-class zero credit. Cross-platform exact frozen-model restoration remains unverified.

## October 18, 2026: new patient-specific CNA reconstruction

Final computational assessment completed all 1,368 main variants and 6,840 chromosome-bootstrap slots: 6,839 successful resamples and one retained uninformative draw, with no engine failure, timeout or retry. Separate final LUAD/LUSC screens establish no direction passing BH 0.05. Four-variant and chromosome-qualified training orders number 1,719 and 1,522 patient-pair observations, not independent patients or validated routes. Final independent review corrected a seed-selection implementation error to the already frozen patient-bootstrap seed; ordering counts and exact/BH results stayed unchanged. No outcome, eligibility threshold, source input, model fit or chromosome draw was changed to improve the result. See the complete final audit and limitations in `docs/TRACERX_CNA_PHYLO_PILOT.md`.

The investigator explicitly requested CNA-aware reconstruction within each patient and then recurring-route analysis, with LUAD and LUSC separate. This authorizes new inferred CNA trees and explicit model-derived event placements; the prior context-only limitation remains accurate for the earlier implementation and source annotations. No source table becomes a verified joint CNA/SNV tree. The new branch is `analysis/tracerx-cna-phylogenies`, preserving prior commit `9f3b60e`, all source data and baseline analyses.

Retain all 217 LUAD and 125 LUSC patients with their original training/evaluation roles. Use each frozen patient's primary R regions as the CNA sampled-region leaves; do not use lymph nodes to replace unavailable primary regions. Technical failures remain explicit within the original availability denominator. Bulk region tips are not individual clones or independent patients. Source major/minor counts lack shared haplotype orientation; raw continuous values must not be rounded into invented phase. Source generation code establishes 1-based closed coordinates, converted to BED0 half-open only in engine inputs.

Before fitting, freeze genuine pinned MEDICC2 parameters, explicit high-copy handling, common measured segmentation, genomic-gap assumptions, the CNA event ontology and sensitivity/testing rules. Preserve all original copy counts and report any engine cap. A small omitted genomic gap is an adjacency assumption, not an observed diploid interval. Minimum event histories and ancestral states remain model-dependent; order within a single branch is unresolved, and repeated changes, reversions, unknown coverage, zero-length separation and sensitivity disagreement remain visible. Broad shared events and gene aliases do not create independent support. The primary event vocabulary will emphasize autosomal-arm LOH and WGD, with exact definitions frozen before fits; source driver Amp/Homdel calls remain separate annotations unless an actual defensible placement is established. Evaluation has already been inspected and remains exploratory.

## October 18, 2026: broader mutation drivers and copy-number context

Fernanda requested an explanation of the limits on reliable evolutionary routes and authorized broader driver genes and copy-number changes, with adenocarcinoma and squamous remaining separate. The extension is isolated on `analysis/tracerx-expanded-events`, based on `04f35d1` after a successful remote fetch. A preservation manifest records 51 baseline artifacts plus the aggregate bytes of all 342 native patient datasets. Original source cohorts, patient roles and fitted results remain unchanged.

The baseline bottleneck is source-order resolution: LUAD training has 50 strict-order observations among 277 patient-pair co-carrier votes (18.1%), with 142 same-cluster and 80 mapping-unresolved votes. LUSC has 12/75 strict-order votes (16.0%), with 56 same-cluster and six mapping-unresolved votes. Patients recur across pairs, so these are not independent patient denominators. No eligible baseline pair has a topology-disagreement vote; relaxing all-alternative agreement would not recover the large within-cluster or unavailable-placement component. Rare co-carriers, variant ascertainment, model assumptions and lack of independent replication also limit reliability. Bootstrap selection is not chronology probability.

Before expanded training gene inventories, frequencies, ordered-pair results or fits, freeze all source DriverMut TRUE genes observed in training as the candidate rule, followed by the unchanged ten-training-carrier/ten-noncarrier gate. No evaluation-only gene identity or frequency selects the catalogue. This broadens the earlier named LUAD/LUSC panels without selecting a list to favor observed edges. Authors' labels are accepted source annotations, not independent functional validation; they may reflect the publication cohort. The configurations are `configs/tracerx_expanded_luad_v0_1.json` (SHA256 `43c279e084ac9e8d9a3056c2409bfa4e293ec891c6cc7db2b9b979632b6a22c5`) and `configs/tracerx_expanded_lusc_v0_1.json` (SHA256 `21f89d6476066bfaec853ddf94c6436004b36c68a705f852ae787a6ca3b955c9`). Original eligibility and split objects are preserved exactly. Patient bootstrap, null fits, ordered-pair permutation assessments and within-histology multiplicity remain fixed.

The public source contains regional allele-specific copy-number segments, a curated 67-gene CNA panel, authors-reported Amp/Homdel calls and WGD context. The source `Tumour.cluster` field denotes multiple-primary tumour grouping, not a mutation-clone branch. Core-paper figure code provides doubled-cluster groupings and a regional-CCF best-match heuristic; these do not supply a deposited verified joint CNA/mutation branch map. Do not execute that heuristic as if it were source truth or infer temporal order from coarse clonality or regional sharing. Include only pinned authors-reported driver Amp for OG genes or Homdel for TSG genes matching the panel; GD is separate WGD context. Preserve exact source rows, clonality, coverage, region and segment identifiers, distinguishing reported, not_reported and assay_unavailable. A missing report is not verified diploid or wild type. Broad-segment genes and WGD do not become independently counted steps. No de novo CNA/LOH driver calls, CNA chronology tests or ordered CNA model nodes are authorized by these data semantics.

The existing evaluation patients have already been inspected in prior pilots. Their fixed roles support transparent comparisons but do not constitute untouched or external validation of this adaptive extension. Baseline and expanded models have different event universes, so their total likelihoods are not directly comparable as a common-target improvement; each is checked against its own independent-event comparator. Both histologies and all exploratory testing families remain separate. A source-grounded expanded analysis may still fail to establish reliable routes; no survival analysis, RNA refit, clinical prediction or biological tier assignment is added.

The actual expanded runs retain 18 LUAD genes from 194 training-observed curated genes and eight LUSC genes from 161. All baseline eligible genes remain. Six LUAD and three LUSC dependencies are selected; none of all 306/56 ordered tests passes BH 0.05. All bootstrap/null fits complete, but training strict resolution remains only 85/463 and 22/134 patient-pair votes. Evaluation likelihood remains below each model's independent comparator; no reliable common route is established. The completed source context adds 67 CNA gene events and separate WGD with 358/435 reported gene–patient units, without counting correlated broad-segment genes as independent steps. All source primary-region sets have SCNA rows; missing gene-specific measurement and partial coverage remain explicit. AMER1, GPC3 and KDM6A are unavailable, not negative. ATRX joins RBM10 as mutation presence without source cluster placement; no sex-chromosome naming repair supplies a missing mapping.

## October 18, 2026: separate adenocarcinoma and squamous analyses

Fernanda answered the outstanding TRACERx histology question: **adenocarcinoma and squamous separately**. This expands the earlier operational LUAD-first slice; it does not change the completed LUAD inputs, split, model or results. The extension is isolated on `analysis/tracerx-histology-strata`, based on `f63e90b` after a successful remote fetch.

Cohort-only inspection identifies 129 deposited LUSC tumours. Four belong to patients with multiple deposited tumours of any histology and are excluded under the existing independence rule. All 125 remaining patients have at least two primary R regions and pass source structural checks. A 70% training allocation rounded to the nearest integer with exact half rounded up gives 88 training/37 evaluation patients, with the new fixed `tracerx-lusc-route-v0.1|` patient-hash salt. This allocation rule is consistent with 217 LUAD patients giving 152 training. The exact frozen counts and salt, not later results, control role assignment.

The LUSC candidate universe is the explicit ten genome-wide MutSig genes in TCGA, *Comprehensive genomic characterization of squamous cell lung cancers*, Nature 2012, DOI `10.1038/nature11404`, printed page 520/Figure 1. The abstract says eleven, while the text and figure explicitly enumerate ten; use the ten listed genes rather than invent an eleventh or mix in the separately tested COSMIC-restricted list. The historical MLL2 symbol maps explicitly to KMT2D, with literal source gene symbols preserved. The same authors-curated mutation definition and ten-training-carrier/ten-noncarrier gate apply, including to near-invariant genes. Copy-number-only, fusion-only and methylation-only events are not supplied by this mutation-only analysis.

The new `configs/tracerx_routes_lusc_v0_1.json` SHA256 is `27a8f619cb39f8a807c569eee4f0a374c80af6bd061572cdda00bf7e530f30b8`, frozen before LUSC gene frequencies, ordering results or fits. Source topology uncertainty, exact variant mapping, patient independence, genuine ASCETIC, resampling/nulls and locked evaluation follow the LUAD framework. BH correction is a separately prespecified LUSC family; it is not an experiment-wide correction over both exploratory pilots. Histologies have independent sources of uncertainty and separately selected event sets; differences between their fitted graphs are not a formal test of histology-specific evolutionary routes.

The completed LUSC run retains TP53, CDKN2A, PIK3CA, KMT2D and NFE2L2. Genuine selected dependencies are CDKN2A → PIK3CA (64% bootstrap; 2/5 training strict, no evaluation co-carriers), NFE2L2 → PIK3CA (51%; 1/4 training strict, both evaluation co-carriers unplaced), and CDKN2A → KMT2D (45%; 1/5 training strict, 1/2 evaluation strict and one same-cluster). Every selected ordering q is 0.951619; none of all 20 directions passes BH 0.05. The model's held-out event log score is worse than independent events by 0.003884 nats/participant. A single compatible evaluation ancestry example does not establish reliable replication or a common route. All 100 bootstrap and 100 engine-null fits completed; 10,000 primary ordering permutations and independent actual-source/RDS review passed. Original LUAD source/model/configuration and native patient datasets remain byte-exact.

## October 18, 2026: multi-region TRACERx ordering evidence

Fernanda explicitly requested trying multi-region TRACERx data to reconstruct more reliable common evolutionary routes. The new analysis is isolated on `analysis/tracerx-multiregion-routes`, based on `ae88da6` after a successful remote fetch. This is a new exploratory analysis; the earlier TCGA cohorts, programs, models and native displays are preserved.

The first operational slice is LUAD, matching the prior pilot. A histology-preference question was offered before analysis, and work proceeded with the stated LUAD-first assumption while it remained unanswered. LUSC and Other are not pooled. Of 229 deposited LUAD tumours, 12 belong to eight patients with multiple deposited tumours of any histology. Exclude all such patients rather than selecting among primaries or treating tumours as independent patients. The remaining 217 independent LUAD patients all have at least two distinct primary R regions. Same-surgery lymph-node samples stay in the full source trees but do not qualify the primary-region gate. No absent per-patient neoadjuvant information is imputed. These are operational research choices under the authorized pilot, not a revised definition of the earlier TCGA cohort.

The configuration was frozen before gene-event frequencies or model results: `configs/tracerx_routes_v0_1.json`, SHA256 `59cb7426bee696e76df9d75bd4e61a7a322231f4eb589a2b08726ca20e696cc5`. A deterministic patient-level split fixes 152 training and 65 evaluation cases. The 18 literature candidate genes are retained as the starting universe; an authors-curated driver event and at least ten training carriers and ten noncarriers define eligibility. Twelve genes pass. Variant joins include the alternative allele and corrected-cluster agreement. Unmapped, removed or repeated-hit drivers remain present with unknown order, rather than becoming absent or receiving an arbitrary first occurrence.

Use strict ancestor agreement across all valid deposited topology alternatives as the primary ordering evidence, with at most one vote per patient per gene pair. Same-cluster order is unresolved; separate branches are incomparable. Three eligible source trees encode a single cluster as the exact self-pair 1:1 consistently across corrected/alternative/consensus/root/length fields. Normalize only that complete source sentinel to one node and zero intercluster edges, preserving literal source fields; never remove generic self-loops or invent within-cluster order. Frozen source byte snapshots and hashes are retained before fitting.

Genuine ASCETIC 1.2.0 was compiled from pinned unchanged authors' source using an isolated official portable toolchain. It runs on conservative named consensus-order matrices, a documented partial-order adaptation of its phylogeny interface. The frozen analysis uses AIC/hill climbing, zero restarts, 100 full patient bootstrap fits, 100 engine-null fits and 10,000 within-patient uniquely placed gene-label permutations. BH covers all 132 ordered eligible pairs. Evaluation neither fits the graph nor selects genes, edges or settings. Every actual selected edge remains displayed separately from the complete source-pair evidence.

The model selects EGFR → KEAP1, KEAP1 → STK11 and KEAP1 → SMARCA4, with bootstrap frequencies 19%, 85% and 54%. Their strict source training support is only 1/1, 2/12 and 1/10 co-carriers; none has resolved evaluation order. All selected ordering BH q-values are 1.0. The EGFR/KEAP1 edge has negative reported co-occurrence association, so an arrow must not be labelled positive cooperation. The held-out joint event score is worse than independent marginals by 0.06103 nats per participant. The result adds auditable ordering information but does not establish reliable common routes or improved biological validity. See the TRACERx pilot/source/method/view guides. No survival testing, clinical prediction, RNA-program refit or biological tier assignment was performed.

## October 18, 2026: first across-patient event-model pilot

Fernanda explicitly requested the next step using the project's current NSCLC data to investigate common evolutionary routes across patients. The implementation is isolated on `analysis/nsclc-population-routes`, based on `32140fb` from the published-tree prototype. Shared updates were fetched before work. The existing explorer cohorts, frozen training/evaluation roles and provisional RNA programs remain preserved.

The authorized first slice is source-labeled LUAD: 507 independent participants, 354 training and 153 evaluation. LUSC is audited separately and not pooled. A published cross-sectional event method, genuine TRONCO CAPRI 2.40.0, is used with frozen gene-event criteria, BIC/hill-climbing, 100 patient bootstrap fits, 100 burden-stratified null fits, and training-only fitted probabilities scored on held-out participants. These are exploratory statistical dependencies under persistence, prevalence and detection assumptions. They do not establish actual order in a tumour, direct ancestry, causal cooperation or validated population routes. No outcomes or RNA-program scores select genes or edges.

Schema QC identified all missing per-row Mutation_Status values. Before candidate gene frequencies or a model were inspected, the impossible initial Somatic predicate was corrected in version 0.1.1, preserving the original configuration and hashes. Source somatic-callset provenance is retained; VEP SOMATIC database annotation is not a specimen-call filter. Source PASS protein-altering calls are aggregated by gene; neither functional-driver identity nor verified wild-type absence is established. The current inputs do not pass the mutation-CCF gate for ASCETIC. Public copy-number-state fractions and VAF are not substituted for mutation CCF.

The newly inspected official historical quality resource flags 52 source-labeled LUAD cases for pathology exclusion: 38 NSCLC, NOS and 14 favour LCNEC. Fernanda explicitly chose **keep the original cohort and add an analysis excluding flagged cases**. The separately specified sensitivity retains 455 participants (316 training, 139 evaluation), the baseline 11-gene event universe and identical settings. Sixteen quality-unknown participants remain labelled unknown. Four training participants have neoadjuvant-therapy notifications; the model is not presented as untreated natural history. These source annotations are not new pathology adjudications. Evaluation performance does not select a preferred cohort or model.

The authoritative display preserves the complete selected DAG and conditioning sets. The unmodified Nextstrain application receives one independent component per selected relation and singleton components for isolated events, with explicit display copies and unitless positions. No common clonal root or patient tips are invented. Results, negative stability/null assessments and limitations must remain visible together. See `POPULATION_ROUTE_PILOT.md` and the source, method and view guides for reproducibility and final results. This pilot performs no survival testing, biological tier assignment or functional validation.

## October 18, 2026: published lung-cancer reconstruction in Nextstrain

Fernanda explicitly requested a working prototype in the actual Nextstrain application, starting with a published lung-cancer evolutionary reconstruction, and authorized parallel subagents. The longer-term scientific objective clarified in this discussion is recurrent evolutionary routes across patients. The immediate implementation is a source-faithful display of a published within-tumor reconstruction; it does not infer new routes across the TCGA cohort.

Implementation is isolated on `app/nextstrain-tumor-proof`, based on local commit `143a4d91240a4cf3423e74218850102da9079402`. The shared remote was fetched successfully before work began. The existing explorer, its frozen programs, and historical audit remain outside this prototype's changes. Use official local Auspice with a converter for published processed tree data. Preserve topology, branch-length semantics, source identifiers, attribution, and source access terms; do not create a common clonal ancestor for unrelated patients or insert unobserved dates, geographic coordinates, mutations, or support values.

Proposals to evaluate ASCETIC or CAPRI for future population-level inference remain proposals. Displaying a published reconstruction establishes software integration only. It does not validate the existing provisional programs, establish a survival mechanism, or demonstrate population-level evolutionary convergence.

October 18, 2026 interface preference: the investigator reported that the plot colors were hard to see and requested brighter dots and stage colors. Implemented distinct blue/orange/green/purple stages with gray unknowns, a stronger ordered cyan/blue/purple continuous scale, larger opaque dots and matching labeled keys. This presentation choice does not change any scientific criterion, fitted model, source observation or candidate tier.

| Date | Decision | Status | Basis and consequence |
|---|---|---|---|
| October 14, 2026 | Use acquired PD-(L)1 resistance in GSE248249 as the primary biological focus | Accepted by Fernanda | Thirteen complete patient pairs; inferential readiness remains conditional on annotation and batch/site QC |
| October 14, 2026 | Use GSE207422 bulk for a separate baseline-response biological comparison | Selected recommendation | All 24 profiles are pretreatment; no claim of direct acquired-resistance replication |
| October 14, 2026 | Defer the GSE126045 matched baseline RNA-methylation alternative | Deferred | Different clinical question and preservation confounding; 16 matched published patient codes |
| October 15, 2026 | Establish a private GitHub repository for collaboration through each person's Codex session | Authorized by Fernanda | Share durable project context, code, decisions, and reviews instead of exchanging packages |
| October 17, 2026 | Resume scientific definition through a physician-scientist interview, one focused question at a time | Confirmed by investigator handoff | Maintain a cumulative record; begin no new implementation or analysis without an explicit request |
| October 17, 2026 | Broaden the overarching aim beyond acquired treatment resistance | Confirmed by investigator handoff | Investigate candidate Molecular Survival Islands and their relationships to NSCLC behavior, pathology, IHC, and possible vulnerabilities; resistance remains one relevant setting |
| October 17, 2026 | Preserve the previous audit and resistance-cohort selection while reconsidering their role in the expanded aim | Reconciliation of prior decision and new direction; future study role unresolved | No replacement dataset, island definition, analysis method, or minimum demonstration has been selected |
| October 17, 2026, Update #2 | Do not define islands exclusively by identical genomic alterations; retain genotype-driven and function-driven discovery | Confirmed investigator direction; biological convergence remains a hypothesis | Different genomic routes may yield functionally related programs; shared states do not establish evolutionary convergence |
| October 17, 2026, Update #2 | Adopt provisional research evidence Tiers I, II, and III | Confirmed investigator framework; operational criteria pending | Classify functional support, survival association, or uncertain significance, respectively; retain Tier III candidates and evidence provenance; no implied clinical actionability |
| October 17, 2026, Update #2 | Include repurposing and reconfiguration of normal programs in the scientific framework | Investigator-endorsed biological possibility | Normal-reference comparisons should not equate differential expression with a newly created mechanism |
| October 17, 2026, Update #2 | Prefer Gross -> Scope -> Genomics -> Population-Level Discovery | Confirmed presentation preference | Begin with two illustrative lung adenocarcinomas; actual source images, outcomes, and linkage remain to be established |
| October 17, 2026, Update #2 | Retain GLP-1 receptor agonism as a future direction outside the central hackathon objective | Confirmed scope decision; mechanism speculative | Do not claim demonstrated island disruption or a general treatment benefit |
| October 17, 2026, subsequent clarification | Introductory cases are solely presentation illustrations of potential clinical use | Explicit investigator decision | No required linkage to the research cohort; cases, presentation images, and case-to-omics linkage are not tool-build prerequisites |
| October 17, 2026, public-data readiness | Verify public data and define initial candidate-island criteria to prepare the app build | Explicit investigator authorization | New input-integrity audit and versioned working criteria; not authorization to invent biological findings |
| October 17, 2026, public-data readiness | Recommend TCGA PanCancer LUAD/LUSC as the first explorer backbone | Evidence-based first-build recommendation; not a claim that Fernanda selected a new biological endpoint | 507/481 independent primary tumor sample keys with verified RNA/CNA/MAF coverage, clinical and slide links; preserve GSE248249 as a distinct resistance extension |
| October 17, 2026, initial criteria | Operationalize a candidate initially as a reproducible coordinated RNA program and separate computational status from biological tier | Working version 0.1 defined under the requested scope | Outcome-blind discovery, patient independence, frozen evaluation, DNA/phenotype annotation and explicit Tier III/II/I evidence requirements; numerical gates remain research defaults |

## Open scientific items

- Can the primary comparison support a credible exploratory estimand given organ changes, time, tissue composition, and uncertain batches?
- Which gene mapping, preprocessing, score definition, and sensitivity analyses are defensible with the public array data?
- How should unspecified NSCLC and source-labeled Carcinosarcomatoid samples be handled in the comparison cohort?
- What cross-cohort genomic claim is scientifically useful and appropriate for the intended submission?
- Which module definition and robustness criteria, if any, are justified by the independent sample size?

For each future decision, record the date, scientific question, evidence, alternatives, decision, rationale, decision-maker, and downstream files affected. Preserve unresolved disagreements. Do not convert a proposed task owner or method into an accepted decision without agreement.

## October 17, 2026: scientific direction refinement

Historical first-handoff record: the pending functional-convergence question below is answered by Update #2, recorded later in this document. Preserve the original entry as a dated account, not the current unanswered question.

Source: the investigator-supplied handoff, preserved verbatim in `scientific_handoff_2026-10-17.txt`. These entries record the investigator's direction and hypotheses, not independent verification of its literature, dataset leads, or proposed mechanisms. The decision-maker for confirmed requirements is Fernanda; the reconciliation below does not select a new study.

### Confirmed requirements

- Current scope is NSCLC; the longer-term interest in other cancers does not expand this submission automatically.
- Preserve the term **Molecular Survival Islands** as a provisional investigator-defined concept. Physical genomic clustering and foreign/viral material are not required. A molecular hotspot refers to a candidate island, not necessarily a recurrent nucleotide mutation.
- Investigate differing tumor behavior beyond targeted-therapy resistance. Histologic, immunophenotypic, and clinical associations and potential vulnerabilities are research questions, not promised findings.
- Include appropriate normal cellular references in the scientific framework while separating genetic and cellular-state references. Do not assume either is a literal tumor ancestor.
- Develop an intuitive, interactive research workspace with linked guided discovery and free exploration. Both molecular-to-pathology and pathology-to-molecular investigation are required.
- IHC must support filtering and comparisons, with scoring and provenance where available. RNA, protein abundance, and actual IHC findings remain non-equivalent evidence.
- Preserve separate histologic type/subtype, architecture, cytology, grade, IHC, molecular classification, and specimen-site fields, including original source labels. The handoff specifies WHO Thoracic Tumours fifth edition (2021) as the initial terminology reference; reference and dataset suitability have not been rechecked in this update.
- Treatment, site, timing, response, and outcomes should be explorable with specimen provenance, missingness, confounders, uncertainty, and reproducible comparisons visible.
- Nextstrain is a preferred interaction reference. No installation, analytical engine, screen layout, or phylogeny method is approved. Unrelated patients must not be given an invented common clonal tree.

### Working hypotheses, not established findings

- Recurring combinations of alterations or regulatory states may cooperate in tumor survival and behavior.
- Different genomic routes may converge on a shared functional survival program.
- Candidate programs may correspond to recognizable histologic or IHC patterns and may suggest vulnerabilities.
- Normal-state comparisons may provide useful biological context, without establishing an observed transformation timeline.

### Meaningful differences from the prior project framing

1. The October 14 decision and earlier rationale focused on treatment-related phenotypes and acquired PD-(L)1 resistance. The updated overarching aim is broader. Preserve that prior selection as historical work; its role in a future minimum demonstration remains open rather than automatically canceled or reaffirmed as sufficient.
2. The earlier rationale's functional-program wording was more definite than the current unresolved island definition. Do not assume the investigator has chosen functional equivalence over genomic configuration or a composite state.
3. The audited expression studies do not establish feasibility for the full requested DNA-RNA-pathology-IHC experience. Prior access, matching, site, batch, and sample-size limitations remain valid. The new literature and atlas leads are not adopted datasets.
4. Existing scripts, source data, audit reports, and prior scientific decisions remain preserved. This update changes the scientific framing and immediate work phase; it produces no discovery results.

### Open questions and scientific limits

- **Immediate question:** If two tumors have different genomic alterations but activate essentially the same coordinated survival mechanism, would the investigator consider them to share the same Molecular Survival Island?
- The detection/classification unit remains open: genomic configuration, functional program, composite state, or several classes. The immediate question is pending; no investigator answer has been inferred.
- Appropriate normal lineages, island evidence thresholds, IHC markers/scoring, specimen-linked data availability, validation, and the minimum hackathon demonstration remain unresolved.
- Co-occurrence, reproducible association, clinical correlation, evidence consistent with selection, and demonstrated functional cooperation are distinct evidence levels.
- Pre-existing clone selection, new alterations, regulatory adaptation, changes in cellular proportions, and true cooperation must not be collapsed into acquisition of mutations.
- Molecular-pathology specimen matching, tumor-normal pairing, and longitudinal tumor pairing are distinct. None implies the others.
- Shared states across patients do not establish ancestry or convergent evolution by themselves. A similarity graph is not automatically a phylogeny.
- Confounders include purity, cellular composition, stage, drivers, treatment/history, sampling site/time, batch, platform, and heterogeneity. Clinical associations do not establish causality.
- Organizer instructions and deadline details remain to be verified when submission planning resumes; no current verification was performed for this scientific-record update.

### Record maintenance and provenance

After each investigator answer, append the question, the answer faithfully summarized, its status (confirmed requirement, hypothesis, or unresolved proposal), rationale, limitations, and implications. Do not infer acceptance from assistant suggestions or an unanswered question. Continue one scientific question at a time; technical translation follows clarification and explicit implementation authorization.

This update affects `AGENTS.md`, `docs/CURRENT_STATUS.md`, `docs/TASKS.md`, `docs/scientific_rationale.md`, and this cumulative log. The new dated handoff is preserved separately from `original_handoff.txt`. Local baseline: `2c78aaf891cb443df65588b10127e72c0d2a4939`. Remote fetch failed with `getaddrinfo() thread failed to start`, so current collaborator changes could not be checked. Existing untracked `Articles/` material was not modified or staged.

## October 17, 2026: handoff Update #2

Source: `scientific_handoff_2026-10-17_update2.txt`, preserved from the investigator's attachment. This supplements the first handoff. It records investigator decisions and hypotheses, not newly verified literature, observed cases, or analysis results. The supplied file is 10,929 bytes and ends in Act III with the instruction to use actual outcomes only if documented and authorized for public presentation. Its title mentions public-data strategy, but no detailed strategy or later presentation acts were received; those contents must not be reconstructed from the title.

### Prior interview question and answer

**Question:** Can tumors with different genomic alterations share a Molecular Survival Island by activating essentially the same coordinated survival mechanism?

**Answer conveyed by the handoff:** Yes, this possibility is central to the investigator's hypothesis. Identical mutations, copy-number changes, structural changes, or regulatory configurations are not necessary for a functionally related candidate state. Discovery should accommodate both genomic configurations and functional programs, with programs subsequently mapped back to genomic routes.

**Status and implication:** Confirmed scientific direction; functional and evolutionary convergence are not established project findings. The earlier pending question is resolved at this conceptual level. Quantitative similarity, program boundaries, reproducibility thresholds, and evidence sufficient to infer evolutionary convergence remain unresolved. This answer does not select an algorithm, dataset, or implementation.

### Confirmed provisional evidence framework

| Tier | Investigator label | Evidence meaning | Key limit |
|---|---|---|---|
| I | Functionally Supported Survival Island | Convincing functional evidence that a coordinated program contributes to fitness, persistence, resistance, or a relevant survival mechanism; examples include perturbation, rescue, dependency, or strong causal evidence of cooperation | Coexpression/enrichment alone is insufficient; biological support does not imply clinical actionability |
| II | Survival-Associated Molecular Island | Reproducible coordination and association with a relevant phenotype, such as persistence, resistance, progression, metastasis, or survival | Causality remains unproven; address confounding, composition, and technical artifacts |
| III | Molecular Island of Uncertain Significance | Reproducible coordination with unknown survival-related function | Retain for investigation without representing it as a proven survival mechanism |

These are investigator-defined research tiers, not the AMP/ASCO/CAP clinical somatic-variant system. Classification may change as evidence accumulates. Lack of evidence does not establish absence of effect, and molecular coordination does not establish functional cooperation. Every assignment must retain evidence provenance. The handoff anticipates that new hackathon candidates may be Tier III or, with suitable evidence, Tier II; this is an expectation, not a finding. Published functional studies may inform Tier I support, but no actual candidate assignment has been made.

**Proposed safeguard for investigator discussion, not an accepted new rule:** evidence supporting a single component or a different experimental context should not automatically validate the entire proposed island. Exact component coverage, biological context, and the transferability of external evidence need explicit review before a Tier I assignment.

### Additional hypotheses and scope decisions

- Normal programs may be persistently activated, suppressed, deregulated, or recombined in malignant states. Where suitable references exist, compare normal expression, abnormal activity, reconfigured combinations, and states poorly represented by those references. Absence from a reference does not establish biological novelty.
- inv(16)/CBFB::MYH11 AML and cooperating alterations are conceptual background supplied by the investigator. NSCLC remains the hackathon scope.
- The idea that GLP-1 receptor agonists might disrupt coordinated survival programs or tumor-microenvironment relationships remains speculative. The investigator explicitly excluded it as a central computational objective of this hackathon. Preserve possible tumor-intrinsic, systemic metabolic, immune, tolerance, and confounding explanations without inferring treatment benefit.

### Presentation direction and unresolved provenance

Confirmed narrative: **Gross -> Scope -> Genomics -> Population-Level Discovery**. The investigator would like to present personally if selected. This is a scientific narrative, not approval of a slide layout or an implemented interface.

- Act I: introduce two illustrative lung adenocarcinomas with representative gross images and specimen context.
- Act II: use H&E to illustrate similar diagnoses, architecture, or cytology, with comparable IHC where available.
- Act III: raise the question of differing response, recurrence, dissemination, progression, or survival. Actual case outcomes require documentation and authorization for public presentation.
- The cases, images, IHC findings, outcomes, authorizations, and exact case-to-omics relationships have not been supplied or verified. Do not imply they are linked to any selected molecular cohort. Representative images cannot be substituted for actual case images without clear labeling and provenance.
- The supplied text stops at Act III. Genomics and population-level presentation details, a detailed public-data strategy, and the minimum multi-omics demonstration remain unspecified. Preserve all prior specimen-linkage and data-access limitations.

### Immediate work and record provenance

Integrate the received decisions and continue focused scientific clarification, beginning with whether a continuation of Update #2 exists. The immediate scientific priority is a credible, reproducible NSCLC multi-omics demonstration, with the interactive atlas retained as the long-term vision. No code, dataset, statistical method, actual findings, or case-level content is authorized or created by this record update.

Inspected the existing analysis scaffold, dated `configs/design_status.json`, submission status, and current project documents before updating documentation. The audit configuration remains historical and unchanged; README now points readers to the current direction. Local baseline: `f48bbcaba74a22d0f97b70b220241ba6e3d8a12e`. Remote fetch again failed with `getaddrinfo() thread failed to start`; shared updates remain unverified. Existing untracked `Articles/` material and previous source handoffs were preserved.

## October 17, 2026: presentation cases are not build prerequisites

**Investigator clarification:** "No, forget about the cases. The cases are only for the presentation and illustration of how this tool can be used in clinical practice real life scenarios".

**Status:** Confirmed requirement clarification. The introductory cases demonstrate potential clinical use; they are not required analysis inputs and need not match the molecular cohort. Case selection, gross/H&E/IHC presentation images, and case-to-omics linkage must not block the tool build or determine cohort eligibility.

**Consequence:** Remove these items from the research-data demonstration prerequisites and track presentation preparation separately. The missing presentation continuation is not a build dependency. Existing requirements for genuine specimen-level matching within research datasets, accurate evidence labels, and no fabricated findings remain in force. This correction does not by itself select a cohort, endorse clinical deployment, or request implementation.

Updated guidance, current status, tasks, and rationale accordingly. Documentation-only update based on local commit `5d1b498c0b7b8587bc30100b55d2e221995fdafc`; remote synchronization remains unavailable from the preceding fetch attempt.

## October 17, 2026: public data verified and initial criteria defined

**Request:** "Go ahead and verify the public data and define the initial candidate-island criteria so we can start building the app."

**Verified evidence:** pinned DataHub source commit `7a4b4ec142f76ac04db22834232b23142d25bd2a`; 47 source files and 647,110,442 bytes; complete RNA/CNA/RPPA/MAF and normal RNA scans; profile-list and patient joins; official ABSOLUTE purity; complete GDC slide metadata. Molecular LFS payloads matched source hashes and sizes. The core intersections are 507 LUAD and 481 LUSC primary tumors, one per participant, with no core patient overlap across cohorts. RPPA covers 355/313, purity 497/476, and normal RNA is available for 56/49 core participants. All core cases have patient and sample-key slide links; aliquot/section correspondence is unresolved.

**Recommendation and rationale:** start the broader multi-omics explorer with these auditable TCGA cohorts, analyzed separately by histology. They support DNA-to-program and program-to-phenotype exploration better than making an expression-only resistance cohort the whole initial app. The earlier resistance selection and audit remain intact as a separate extension. TCGA is not longitudinal resistance validation. CPTAC and HLCA are useful source-verified complements; their integration and specimen overlap have not been independently measured here. This recommendation does not change a biological endpoint by assumption.

**Initial criteria:** `configs/candidate_island_v0_1.json` and `docs/CANDIDATE_ISLAND_CRITERIA.md` define a coordinated RNA program as the initial computational unit, with outcome-blind within-histology discovery, participant-level split, fixed scores, resampling and untouched-set preservation. These criteria implement the investigator's direction; their numerical thresholds are versioned working defaults, not established biological standards or separately accepted diagnostic criteria. Tier III does not require a DNA hit, enrichment, tumor-normal difference, or outcome association. Tier II requires reproducible, adequately controlled phenotype association; Tier I requires specific functional support. Shared state does not establish evolutionary convergence.

**Material data limits:** no named IHC fields or grade in the inspected clinical tables; RPPA is not IHC; normal RNA is a bulk tissue reference, not germline DNA or a lineage atlas. MAF barcodes are truncated to the sample key, and inferred absence of a variant must not become verified wild-type. Repeated gene identifiers need explicit exclusion before modeling. Clinical field availability is not a completed endpoint/censoring audit. The between-patient atlas must show similarity rather than invented ancestry.

**Outputs and validation:** `docs/PUBLIC_DATA_READINESS.md`; candidate criteria document/config; `scripts/audit_public_tcga.py`; three versioned `manifests/public_tcga_*_2026-10-17.tsv` files; `results/reports/public_tcga_readiness_2026-10-17.json`; integrity tests. All 18 repository tests pass. The first sandbox test run failed on temporary-directory permissions; the approved execution passed. No module discovery, association tests, island assignments, or app implementation was performed.

**Source and collaboration state:** remote fetch succeeded after approved network access; `origin/main` remains at the shared baseline `2c78aaf`. The new research branch starts at local `d7a98bc`. Existing `Articles/`, October 14 evidence, source handoffs, and prior collaborator work remain preserved. The official hackathon page was rechecked: reproducible open multi-omics is suitable; October 31 submission is listed, while November event dates conflict. The submission-specific template remains a later preparation item, not a data-layer build prerequisite.

## October 17, 2026: private draft PR and first local app authorized

**Request:** "Yes, push it to the private GeNeDis repository and create the draft PR. Then start building the app using the verified public data and candidate-island criteria."

**Completed publication of the foundation:** pushed `research/public-data-island-criteria-2026-10-17` and created draft PR #1, https://github.com/tiradofern/genedis-survival-islands/pull/1. No merge or public release was requested. The app uses a separate stacked branch, `app/explorer-v0-1`.

**App delivery:** first implementation commit `34c97e3` was pushed to the same confirmed-private repository in draft PR #2, https://github.com/tiradofern/genedis-survival-islands/pull/2, targeting the research branch to keep the implementation diff separate. The independent interface finish review returned **ship**, with both selection-state and plot-boundary accessibility findings resolved. The built design system is recorded separately from scientific criteria. Neither PR has been merged.

**Routine implementation choices within this authorization:** local-only Python HTTP service and buildless browser interface; isolated pinned NumPy/SciPy environment; prepared read-only matrices/SQLite; Nextstrain-inspired linked scientific workstation. This first slice supports both gene/DNA-led filtering and program/activity-led selection, with specimen/source-pathology inspection and GDC slide-record links. It records RPPA availability without claiming RNA is protein or IHC. Presentation cases remain irrelevant to cohort eligibility.

**Frozen provisional fitting:** the implementation configuration was written before the first fit: 2,000 eligible training-MAD genes (within the 5,000 maximum), signed weighted correlation power 6, average linkage cut at distance 0.92, separate histologies, outcome-blind deterministic participant split. LUAD has 354 training/153 evaluation participants; LUSC 336/145. All learned feature filtering, imputation, center/scale, PCA and module weights/signs/cutoffs use training participants. Evaluation and bulk normal RNA receive frozen projection. Published upstream normalization remains a limitation. Full-precision module weights and frozen transformations are retained locally. Source, recipe and artifact hashes are checked; export/import requires the same fingerprint.

**Observed exploratory output:** 14 LUAD and 11 LUSC RNA modules pass the initial training coordination screen; none exceeds 500 genes. They remain provisional and untiered. Resampling, holdout preservation, enrichment, composition sensitivity, controlled survival/phenotype analysis and functional evidence have not run. These counts are implementation outputs under one restricted feature universe, not validated survival-island findings or proof of a novel program. Missing/invalid/repeated identifiers are excluded explicitly (per cohort: 50 tumor RNA, 319 CNA, 9 normal RNA rows), with complete loss logs.

**Manual comparisons:** frozen membership, participant-independent cohort, shared tumors excluded from both groups, descriptive mean/median statistics only. No p-values, automated tiers, clinical actionability or causal interpretation. Score-defined group differences are expected. Normal overlays and the plot explicitly describe molecular similarity/context, not ancestry or trajectories. IHC/grade remain unknown. Slide links do not prove identical aliquot or section.

**Verification:** all 28 Python tests and five Node tests pass. Synthetic tests check planted coordination, holdout leakage, split invariance, duplicated IDs, missingness, stale artifacts and overlap handling; fixtures are not app data. Real-data headless Chrome checks validate cohort counts, filtering, GDC links, selection, comparison, exports/restore, empty results and responsive layouts with no JavaScript exceptions. Windows sandbox temp/network restrictions required approved execution outside the container; no global dependencies or browser downloads were added. The guide states these are implementation checks, not biological validation. Historical October 14 audit/configuration and user-owned Articles remain preserved.


## October 31 execution and submission decisions

- The PI explicitly authorized local implementation, necessary public retrieval, analysis, tests and final-material preparation on an isolated branch. No merges, access changes, external messages or organizer upload are authorized; final delivery requires explicit PI approval.
- The primary pilot measurement is recurring paired program changes. Recurrence, comparator enrichment, treatment-associated selection and functional contribution are separate evidence levels. Missing responders does not invalidate recurrence; expression does not establish genomic conservation.
- The additive release starts from cumulative `a4edb2b`; prior work, splits and negative results are preserved. All 47 core inputs recover exactly; 25 programs remain provisional despite computational reconstruction.
- Six predefined human Hallmarks are frozen as MSigDB 2024.1.Hs before effects. The fixed 12-direction family, score and replication/single-cohort fallback are recorded in `pilot/PROTOCOL_2026-10-31.md`.
- Both candidate cohorts fail clinical/technical inference readiness. Stop before scores/effects; report feasibility as inconclusive, not molecular negative. No new cohort, gene set or statistical tail is added to rescue the result.
- The minimum submission is the runnable NSCLC explorer, complete program definitions, fresh reproducibility evidence, preserved negative findings and longitudinal feasibility.
- The PI supplied the October 14 organizer email: archive/link accepted, NSCLC scope confirmed, no Springer template. Use 18:00 EDT / 22:00 UTC operational deadline; the official cutoff time is not independently confirmed.
- Root project LICENSE remains pending; prepare a private review archive without a new general license grant. Do not bundle large sources, prepared patient matrices, publications, installed runtimes, credentials or personal correspondence.
- The first archive-replay attempt incorrectly followed the virtual-environment executable symlink and is retained as unaccepted. The corrected helper preserves that invocation path and checks pinned versions before reconstruction. The pinned repeat passes. No primary biological analyses occurred.

## October 31: Justin review and joint reassessment requested

- Fernanda requests that Justin independently evaluate the plan and results, provide recommendations, and then reassess the work with her. Justin's acceptance, assessment and sign-off remain unreceived; existing AI reviews do not substitute for his input.
- Prepare a review guide, unfilled independent-review template and joint response/decision template on a separate coordination branch. Pin the material under review to scientific release `c0599df` and the original archive checksum; preserve both unchanged.
- Invite evidence-based challenges to all AI conclusions, including no-go decisions. Distinguish confirmed ineligibility from unresolved metadata, missing batch labels from demonstrated confounding, recurrence from resistance specificity, and computational reconstruction from biological validation.
- After the review arrives, synthesize the recommendations for PI/Justin adjudication, record accepted/rejected/deferred issues and dissent, and define any bounded authorized revisions. Justin should be able to recheck whether those revisions resolve his material concerns.
- This request authorizes review coordination/documentation, not new biological analysis, direct messages, access changes, merges or organizer delivery. Final submission approval follows the requested review sequence and applies to an exact final package.


## October 31: consolidated interview preferences for Justin's assessment

The PI requests that all decisions from the subsequent interview be run by Justin. The complete decision inventory D01–D16 is in `reviews/PI_DECISIONS_FOR_JUSTIN_2026-10-31.md`; it is a curated scientific record, not a personal conversation transcript. Justin's response and joint operational-method approval remain pending. PR #12 contains an earlier AI-assisted findings draft whose personal sign-off is marked pending.

Current preferences are malignant-cell-first, function-first discovery in at least two non-NSCLC cancer types with documented acquired resistance to similar therapies, followed by independent NSCLC testing in the same treatment family. Published groups are primary, the existing NSCLC-derived programs are separate, and new data-driven modules are exploratory. Both paired and resistance-only designs are included, with their estimands distinguished. The first therapy group depends on verified public-data feasibility, and well-supported RNA-based malignancy classification is acceptable. Matched responding tumors are optional secondary comparators.

The majority-cell candidate-eligibility requirement was explicitly withdrawn. Report cell-level prevalence and uncertainty where measurable; '>50%' defines 'most' and '≥two-thirds' is sensitivity only. Smaller malignant populations remain eligible. Program-level versus program-plus-core-genes NSCLC replication remains unanswered. No minimum sample size, new hypothesis family, activity threshold, coordination null or new dataset has been operationally approved. The old 12-direction pilot is not transferred automatically to this design.

This is review coordination on an isolated documentation branch. It does not reopen the two old cohort gates, change the frozen scientific release/archive, authorize new biological analysis, delegate PI authority, merge branches, change access, send messages or authorize organizer delivery.


## October 31: post-Justin resolutions and end-to-end feasibility gate

The PI explicitly chose: (1) program-level NSCLC replication first, gene matching as the subsequent investigation; (2) pre-existing recurrent programs may qualify, with pretreatment changes as additional temporal evidence rather than mandatory admission; (3) durable stable disease counts alongside CR/PR under treatment-specific duration rules and separate response strata; (4) verify a complete discovery-and-validation combination before molecular discovery, and revise scope before candidate selection if it cannot be verified. See `reviews/PI_RESOLUTIONS_AFTER_JUSTIN_2026-10-31.md`.

The authorized metadata-only audit is documented in `docs/DISCOVERY_VALIDATION_GATE_2026-10-31.md`. No complete chain of at least two different non-NSCLC discovery cancers plus independent NSCLC same-family malignant-cell RNA validation is verified. This is inconclusive feasibility, not proof of absence. Cases, models, scheduled biopsies, private access, unmatched regimens and different molecular modalities are distinguished from missing clinical metadata.

Operational consequence: hold new molecular discovery and candidate selection. Revise the immediate scope to metadata feasibility plus the preserved NSCLC reconstruction; the full pan-cancer hypothesis remains conditional future work. No proposed numeric minimum, program panel, score threshold, old 12-test rule, changed treatment-family definition or narrower biological study is adopted automatically. Published studies' molecular results are prior art, not selected project candidates.

The existing source code, datasets, original gate files, split, programs, negative results, frozen release c0599df and archive remain unchanged. No new expression matrices/raw molecular datasets, molecular analyses, contacts, merges, access changes or external submission occurred. Any substantive reduced-scope scientific study needs a specific PI decision before candidate selection; final organizer delivery remains approval-gated.
