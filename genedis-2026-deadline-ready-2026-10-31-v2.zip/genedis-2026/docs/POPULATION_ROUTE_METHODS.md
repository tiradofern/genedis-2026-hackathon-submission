# Population route pilot: methods and observed limits

This pilot fitted the genuine published **CAPRI** algorithm in **TRONCO 2.40.0** to the project's existing source-labeled LUAD cohort. It inferred an exploratory directed acyclic graph of reported gene-event selectivity. It did not reconstruct a common ancestor between patients or establish mutation chronology.

The aggregate numerical evidence is versioned in `population_routes/inference/results_summary.json`. Patient-level event matrices, official-engine RDS files, raw downloads and generated display datasets remain local and ignored by Git.

Git attributes preserve the exact bytes of the frozen pilot JSON configurations, runtime lock, source manifests and aggregate evidence. Their staged repository blobs were checked against the working-file bytes so automatic line-ending conversion cannot invalidate the recorded hashes on checkout.

## Why CAPRI was run and ASCETIC was gated

[ASCETIC's official vignette](https://danro9685.github.io/ASCETIC/articles/ASCETIC.html) requires cancer-cell-fraction information for its single-biopsy ordering route, or reconstructed within-patient phylogenies for its phylogeny route. Its recommended single-biopsy resampling additionally uses VAF information. The audited current cBioPortal mutation tables have read counts but no mutation CCF, mutant multiplicity or full mutation aliquot identifier. Public ABSOLUTE segment CCF describes copy-number clones and is not mutation CCF. VAF, purity alone, ordinal GISTIC calls, stage and RNA scores were not substituted for timing information. ASCETIC was not run on these data.

[CAPRI](https://doi.org/10.1093/bioinformatics/btv296) was developed for cross-sectional binary genomic events. The actual [Bioconductor TRONCO distribution](https://bioconductor.org/packages/3.21/bioc/html/TRONCO.html) provides its implementation. `run_capri.R` invokes `TRONCO::import.genotypes`, `TRONCO::tronco.capri`, `TRONCO::as.adj.matrix` and `TRONCO::as.confidence`. No substitute inference algorithm was labeled CAPRI or ASCETIC, and no upstream engine code was edited.

CAPRI uses prevalence-based priority and positive probability raising to constrain candidate relationships, then a regularized likelihood search. Its assumptions include event persistence, observable relevant events, nondegenerate/distinguishable event patterns and adequate detection. These assumptions are not established merely by fitting a graph. In particular, this small gene panel omits fusions, copy-number and many other relevant alterations, so the closed-world assumption is not satisfied as a demonstrated biological fact. Apparent relations may reflect omitted variables or confounding.

The displayed graph's parents jointly condition a Bayesian event probability. This run supplied no AND/OR/XOR formula hypotheses. Multiple incoming arrows would not establish a deterministic AND requirement, and the held-out check explicitly uses the complete joint parent state rather than choosing one parent or imposing an AND gate.

## Frozen population and events

The active configuration is `configs/population_routes_v0_1_1.json`, SHA256 `8cec7f268f665609a4542db37efe077a4c766149372e071ced2fed1addba8a46`, written before gene-event frequencies or edges were fitted. Historical `v0_1` is preserved: its attempted row-level `Mutation_Status == Somatic` predicate was corrected before fitting because every source row contains a dot in that field. The source `SOMATIC` field is a VEP annotation of existing database records and was not used as a per-specimen call-state filter. Inclusion relies on documented somatic-callset provenance, not independent verification of every call.

- Baseline: all **507** existing mutation-profiled, independent source-labeled LUAD participants; original **354 training / 153 evaluation** roles unchanged. Four profiled samples without MAF records remain as no qualifying reported event. Missing mutation assays would fail readiness, rather than becoming zero events.
- Candidates: all 18 significantly mutated genes in the prespecified [TCGA Nature 2014 Figure 1 set](https://doi.org/10.1038/nature13385), without outcome, RNA-program, stage or edge-based optimization.
- Event: at least one source `PASS` protein-altering call in the fixed nine classifications. Gene aggregation does not establish every variant as a functional driver or distinguish gain/loss of function and repeated hits.
- Eligibility: at least 20 carriers and 20 noncarriers among training participants, retaining every candidate that passes. Evaluation prevalence does not affect inclusion. Eleven events passed: TP53, KRAS, KEAP1, STK11, EGFR, NF1, BRAF, SETD2, RBM10, MGA and SMARCA4.
- Zero means no qualifying **reported** event in a profiled sample. It does not establish verified wild type or locus-level callability.

The baseline includes **52 historical AWG pathology flags** (38 NSCLC, NOS and 14 favor LCNEC), with 38 in training and 14 in evaluation; **16** participants have unknown source-quality linkage. These source flags are not a new pathology adjudication, and an unflagged record is not confirmed LUAD. The investigator explicitly selected keeping the original cohort and a separate sensitivity analysis.

The prespecified sensitivity in `configs/population_routes_pathology_sensitivity_v0_1.json` removes only those 52 known flags, leaving **316 training / 139 evaluation** participants and the same 11 events without reselection. All 16 unknown-quality participants remain (11 training, 5 evaluation). Both runs retain four historical neoadjuvant-treatment notifications, all in training. Neither is established untreated natural history.

## Published engine and uncertainty

The existing R **4.5.1** installation was used without alteration. Thirty-seven official Windows package archives were installed into the isolated `population_routes/inference/.rlibrary`. Exact versions, archive URLs, sizes and SHA256s are recorded in `runtime_lock.json`; cached archives stay in ignored `.downloads`. The locked engine is TRONCO 2.40.0 with bnlearn 5.2.1. Its original source package license is GPL-3.

Settings were BIC, hill-climbing, internal bootstrap 100, internal p threshold 0.05 and seed 20261018. Other published defaults were explicitly retained: minimum boot scores 3, exhaustive/minimum-statistic sampling enabled, restart 100, and false-positive/false-negative parameters zero. Zero error parameters do not demonstrate perfect assays. Each outer fit invokes the same actual published engine and settings, with deterministic seed offsets.

For each cohort definition:

1. Fit only its fixed training rows and retain the complete engine-selected graph. No edge is removed or added using uncertainty or evaluation results.
2. Draw **100 participant bootstrap** training samples with replacement, rerunning the full engine, including its internal 100 bootstrap samples. Edge stability is selection frequency among successful full fits. Both actual runs completed all 100 without failures. The fixed display threshold is 0.8; it is not a biological validity threshold.
3. Run **100 burden-stratified null** fits. Total reported protein-altering burden counts all PASS calls in the same nine classes across all genes. Training-only burden quartiles define strata; each event column is independently permuted within each stratum, preserving its event prevalence exactly within strata. Sensitivity quartiles use its remaining training rows. Both runs completed all 100 null fits without failures.
4. Report the edge's null selection frequency separately from a permutation association test. The test statistic is `P(target | source) - P(target | no source)`. The one-sided empirical p-value is `(1 + null statistics at least observed) / (1 + 100)`. Apply BH adjustment over **all 110 ordered pairs**, including pairs not selected by CAPRI. This tests the specified positive association against the specified burden null, not chronology. One hundred permutations limit resolution and power; this is exploratory.
5. Retain CAPRI's own internal temporal-priority/probability-raising/hypergeometric diagnostics separately. Its internal bootstrap Wilcoxon p-values are not interchangeable with patient-level permutation probabilities or posterior confidence in evolution.

The whole-graph null comparison uses selected edge count, with the same +1 correction. It is a descriptive model-complexity comparison, not a separate temporal test. Burden quartiles cannot control every smoking, sampling, histology, technical or other biological confounder.

## Frozen held-out predictive check

Each event's complete parent-state conditional table is estimated on training participants with Beta(1,1) smoothing. Previously unseen training parent configurations receive probability 0.5. The independence baseline uses training-only Beta(1,1) marginal probabilities. The frozen graph and both probability sets score held-out observations without refitting, feature selection or edge selection.

The score is joint log probability in natural-log nats per participant. Positive graph-minus-independence values indicate improved descriptive joint prediction under this check, not clinical prediction, temporal validity or survival benefit. The reported interval is a normal approximation using paired evaluation-participant score differences, conditional on the selected graph and training-fitted probabilities; it excludes model-selection uncertainty. The sensitivity overlaps the baseline and is not independent validation or a basis for choosing a winner.

## Actual results

| Baseline selected relation | Patient bootstrap | Burden null selection frequency | Burden permutation p | BH q, all 110 pairs |
| --- | ---: | ---: | ---: | ---: |
| TP53 -> NF1 | 0.51 | 0.07 | 0.0792 | 0.7261 |
| KRAS -> STK11 | 0.69 | 0.08 | 0.0198 | 0.5446 |
| KEAP1 -> SMARCA4 | 0.49 | 0.02 | 0.0297 | 0.5446 |

The sensitivity selects only KRAS -> STK11: bootstrap 0.74, null selection frequency 0.19, permutation p 0.0396 and BH q 0.7624. No selected edge in either run meets 0.8 bootstrap stability or burden-permutation BH q below 0.05. Every selected edge is retained and labeled exploratory in both views.

| Frozen held-out check | Original cohort | Known pathology flags excluded |
| --- | ---: | ---: |
| Evaluation participants | 153 | 139 |
| Graph-minus-independence nats / participant | 0.03031 | 0.02554 |
| Conditional descriptive 95% interval | -0.00712 to 0.06774 | 0.000483 to 0.05059 |
| Whole-graph edge-count null comparison p | 0.1089 | 0.7723 |

These findings establish an operational exploratory population model and expose uncertainty. They do **not** establish a robust shared evolutionary route. The small positive predictive difference in the overlapping sensitivity does not establish chronology, and it does not overcome the edge-stability and multiplicity results.

## Reproduce and verify

First reproduce the audited source exports using `docs/POPULATION_ROUTE_DATA_AUDIT.md`. Keep the configuration and source hashes fixed. The inference scripts run from any working directory using paths relative to themselves; commands below are shown from the repository root.

```powershell
python population_routes/inference/install_runtime.py
python population_routes/inference/prepare_inputs.py
python population_routes/inference/run.py
python population_routes/inference/prepare_sensitivity.py
python population_routes/inference/run.py --config population_routes/inference/output/pathology_sensitivity/configuration_resolved.json --output population_routes/inference/output/pathology_sensitivity
python population_routes/inference/finalize_evidence.py
python -m unittest discover -s population_routes/inference -p test_inference.py -v
```

Use `--rscript PATH` for an existing R4.5 executable outside the default location. The binary installer does not install R or change system/user libraries. `--offline` uses already cached hash-verified archives. If an old archive is unavailable from its original repository URL, recover those exact bytes from the retained local cache; do not silently substitute a newer package. Source and model checks fail on changed hashes, duplicate participants, altered roles, missing assay readiness, identical retained training event columns, or nonvarying events after restriction.

The actual baseline fit/resampling took 77.73 seconds and sensitivity 63.31 seconds on this machine. Eleven focused tests passed, including frozen held-out CPTs, joint multiple-parent conditioning without AND, training-only event eligibility, all-pair BH, schema/source gates, changed-hash rejection, exact real engine edges, full resampling denominators and fixed sensitivity membership/roles/events. An independent source agent also matched both saved official-engine RDS genotype matrices and adjacency graphs to the inputs/outputs. No repeat inference was required for descriptive metadata updates.

An audit-provenance limitation is retained explicitly: the source audit JSON was supplemented with aggregate ABSOLUTE statuses and generalized notification categories after initial preparation. The original prefit audit hash remains recorded, but its preceding complete bytes were not retained. Variant export, cohort mapping, configuration and matrix bytes were unchanged. A final audit snapshot and its hash are retained locally; this ancillary metadata refresh changed no fit or threshold.

The authoritative representation is the exact inferred DAG. Any Auspice edge-forest is a labeled event-model projection, with unitless drawing positions and duplicate event occurrences declared; it does not turn these relations into a common patient ancestry tree. No survival testing, clinical actionability, island tier assignment or RNA-program discovery was performed.
