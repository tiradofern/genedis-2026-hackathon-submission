# Published lung-cancer tree in Nextstrain

This local demonstration uses the unmodified official Nextstrain Auspice application, pinned to version 3.1.0. It translates an existing published lung-tumor reconstruction into Auspice's data format. It does not reconstruct a new evolutionary history or fit a population-level progression model.

## Open the demonstration

Run `Start Nextstrain.ps1` in this checkout, then open:

**http://127.0.0.1:4000/lungcancer/tracerx/published**

`Stop Nextstrain.ps1` stops only the process recorded for this checkout, with its process start time checked. Use `-Port 4001` on both scripts if port 4000 is already occupied. The existing TCGA explorer has its own launcher and data.

## What the tree represents

The selected example is one published LUAD reconstruction, CRUK0005, from Karasaki, Moore, Veeriah and colleagues, *Evolutionary characterization of lung adenocarcinoma morphology in TRACERx*, Nature Medicine 29, 833-845 (2023), DOI [10.1038/s41591-023-02230-w](https://doi.org/10.1038/s41591-023-02230-w). The authors' processed data and figure code are in [Zenodo record 7683605](https://zenodo.org/records/7683605), under its stated academic, non-commercial use terms.

The source graph contains 15 inferred mutation clusters and 14 directed edges. It also records four sampled regions. Mutation clusters are not tissue samples. Branch lengths are the authors' cluster SNV counts, confirmed against the published figure script. They are not elapsed time, substitutions per genomic site, clone prevalence, or a measure of confidence.

The published root cluster carries a 259-SNV truncal stem. A separately labeled display-only origin is needed to draw this stem in Auspice. This anchor is not a sampled normal specimen, an inferred clone, or a reconstructed normal-cell ancestor. Fidelity checks distinguish published nodes/edges from this drawing anchor.

Source metadata, selection rationale, raw-file checksums, regional measurements and extraction details are in `NEXTSTRAIN_SOURCE.md` and the local source extract. No mutation sequences, calibrated dates, geographic coordinates, branch support or new clone assignments have been invented. Existing uncertainty in the published reconstruction remains.

## Explore

- Use **Color by** to inspect source node labels, source node types and available source measurements.
- Click a branch to focus on its descendant clusters; use **Zoom to root** to restore the tree.
- Click a terminal node to inspect its retained source identifiers and attributes. A terminal cluster is not automatically an independently sampled specimen.
- Open the dataset description for the paper, source record, branch-length units and limitations.

Auspice retains some upstream pathogen terminology, including the word "genomes" in its byline. In this demonstration the counted tips are terminal nodes of the published tumor reconstruction. The original 15 clusters include internal clusters as well as terminal clusters.

The default coloring is the source R3 cancer-cell-fraction estimate, in percent. The four regional CCF profiles are retained without clipping or imputation; source estimates can exceed 100% (one value is 101%). Regional morphology is specimen metadata and is not assigned to individual clones. Source branch labels are initially hidden to prevent short branches from producing overlapping text; they remain available in the native controls.

The native popup may say "No sequence changes observed" because individual sequence-level mutation strings were not provided to Auspice. This is not evidence of zero somatic mutations. Each node includes an explicit sequence-data status note; use the published SNV counts for branch burden.

## Reproduce and verify

Follow `NEXTSTRAIN_SOURCE.md` for pinned source download/extraction and `NEXTSTRAIN_RUNTIME.md` for the pinned official application installation. Run `python nextstrain/convert_published_tree.py` to produce the local Auspice dataset and fidelity report. The conversion preserves source labels, every published directed edge and SNV branch counts, including the truncal stem.

Downloaded patient-level source artifacts and generated dataset JSON files remain local and ignored by Git. Versioned scripts, pinned dependencies, schema references and provenance make the preparation reproducible. Source terms apply separately from Auspice's AGPL software license.

The user's longer-term question is recurrent evolutionary routes across patients and their relationship to candidate Molecular Survival Islands. This within-tumor example establishes the application and data-adapter foundation for that work. The frozen TCGA programs remain provisional; this demonstration performs no survival testing, new module discovery, tier assignment or cross-patient evolutionary inference.

## Verification on October 18, 2026

- Ten public source files matched the pinned byte counts, SHA256 and depositor MD5 checksums. A fresh direct RDS extraction reproduced the selected source JSON byte-for-byte; corrupt source files are rejected.
- All 15 source mutation clusters, 14 directed edges, node attributes and SNV edge lengths were preserved, along with the 259-SNV root stem. An independent review confirmed the single additional node is the documented display anchor.
- Ten adapter tests and validation against pinned official Augur/Auspice v2 schemas passed. The existing 28 Python tests and five Node tests passed. The first sandboxed Python run was prevented from creating temporary fixtures; the full normal-access rerun passed.
- The actual Chrome application loaded the published dataset. Source-based recoloring, terminal-cluster details, descendant-branch zoom and full-tree restoration worked. The official application and bundle returned HTTP 200 on the loopback-only server; repeated launch reused the existing process.

These are software integration and source-fidelity checks, not independent validation of the original biological reconstruction.
