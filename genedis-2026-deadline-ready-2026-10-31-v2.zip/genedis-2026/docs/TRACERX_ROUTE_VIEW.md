# TRACERx source-order view

The local view at <http://127.0.0.1:4002/> compares the published within-patient ancestry evidence across 217 independent LUAD patients: 152 training and 65 frozen evaluation patients, 12 retained driver-gene events and all 66 unordered event pairs. The complete categorical evidence is primary. The separate ASCETIC result selects three dependencies and does not establish a validated shared evolutionary route.

## Open and reproduce

Keep the genuine, unmodified Auspice 3.1.0 server on port 4000 running using `nextstrain/Start Nextstrain.ps1`. Source preparation and genuine inference are documented in [source](TRACERX_ROUTE_SOURCE.md) and [methods](TRACERX_ROUTE_METHODS.md); no new fit is performed by a renderer.

From the repository root:

```powershell
python tracerx_routes/visualization/patient_trees.py
python tracerx_routes/visualization/population_forest.py
& 'tracerx_routes/visualization/Start TRACERx View.ps1'
```

The source-pair view is <http://127.0.0.1:4002/>. Choose a gene pair, inspect its contributing patients, then open an individual published tree using that patient's Nextstrain link. All 217 source reconstructions are separate datasets under `nextstrain/datasets/tracerx_patient_*.json`; a source tumour ID is safely mapped into the `/tracerx/patient/<source-tumour-id>` route. The chooser uses the export report, so source IDs containing underscores do not accidentally change native route segments.

The separate native model list is <http://127.0.0.1:4000/tracerx/luad/population/edges>. The earlier TCGA view on port 4001 and original single-tree published proof remain separate and unchanged. The new launcher verifies PID, process start time, project and model before reusing or restarting its own server. It binds only to 127.0.0.1 and never stops an unrelated listener.

## Read the primary evidence

Every co-carrier patient contributes exactly one category to a pair, regardless of regions or alternative trees. The view preserves both locked roles and every category:

| Category | Interpretation |
| --- | --- |
| A ancestral to B | A's retained cluster is strictly ancestral to B's across every valid deposited alternative. |
| B ancestral to A | The reverse strict relation agrees across all alternatives. |
| Same mutation cluster | The source does not resolve within-cluster ordering. |
| Incomparable branches | The genes lie on separate branches in every alternative. |
| Topology ambiguous | The relationship differs across deposited alternatives. |
| Repeated placement | Driver variants in a gene span multiple retained clusters; no single gene position is selected. |
| Mapping unresolved | A required variant-to-retained-cluster placement is unavailable or ambiguous. |

Strict ancestry is an ancestor-closure relation and may include intervening clusters. It does not mean an adjacent clone or the next mutation. Multiple variants of one gene within the same uniquely mapped cluster can remain one placed event; hits spanning clusters are not collapsed to a preferred occurrence. Source-consensus ancestry does not turn a published reconstruction into independently verified biological truth.

Both ancestral directions alone form the strict-order-resolved denominator. Same-cluster, incomparable and all ambiguous states remain in the co-carrier denominator. Every retained pair remains in the overview, including pairs without resolved orders. The aggregate evidence is not forced into a DAG and can retain heterogeneous or conflicting patient histories.

The patient trace can be filtered by role and relationship. Filters change displayed rows only; they do not change aggregate counts. Patient IDs select the published-tree inspector. The inspector shows the exact gene placements and original variant/mapping metadata, and links to the genuine native tree. Source IDs and patient-level traces remain local ignored data.

RBM10 is visibly marked **presence only; no resolved cluster placement**: 19 training carriers and 8 evaluation carriers, with zero uniquely placed in both roles. Its unresolved comparisons are retained. It is neither absent nor recoded as wild type. The event table displays carrier and unique-placement denominators for all 12 events.

## Interpret individual Nextstrain trees

Each native patient dataset displays the authors' corrected source tree as **one representative**. The source deposited 51 single-topology and 166 multiple-topology reconstructions in this cohort. The representative display does not resolve alternative-topology uncertainty; the population analysis uses strict agreement across all deposited alternatives, rather than that representative as a tiebreaker.

Source cluster IDs, directed topology, positive truncal stem, per-cluster SNV counts, exact driver annotations and alternative-edge metadata are preserved. Horizontal distance is cumulative published SNV count. Terminal clusters are inferred mutation clusters, not sampled regions. The source includes the full same-surgery tree, including lymph-node context where present; eligibility requires at least two primary R regions. No dates, molecular clock, additional sequence calls or support probabilities are invented.

An explicit **display-only origin** draws a nonzero source trunk and is not an inferred biological clone or a sampled normal. Three narrowly documented source singleton `1:1` encodings are already normalized by the source parser to one cluster and zero source ancestry edges; the exact literal encodings remain embedded. Their true truncal SNV counts remain visible. The renderer accepts normalized singleton and chain trees and rejects arbitrary self-parent edges. The original proof converter remains unchanged.

The native **drivers** branch-label option is enabled by default: each positive label is the exact deposited `curated_driver_genes` string attached to that cluster. Source `none assigned` values are preserved as metadata but not drawn as positive driver labels. This makes internal drivers visible even when the stock color legend shows terminal clusters only. Raw CCF percentage estimates, including estimates over 100, are preserved rather than clamped or treated as clocks.

Auspice's stock word “genomes” counts displayed terminal clusters in this context. Its sequence popup may say “No sequence changes observed” because sequence mutation strings were not supplied; this does not mean zero somatic mutations. Source SNV-count metadata remains the quantitative evidence. Internal-branch popup interaction was not successfully verified in the browser; visible internal driver branch labels provide an independently tested reading path.

## Keep the separate model distinct

The exact ASCETIC selected DAG uses one node per retained event, including isolated and presence-only events. Layout is schematic and has no mutation-length or time axis. Arrow labels show training and evaluation ancestral / co-carrier counts. The table places those denominators, unresolved categories, bootstrap selection and ordering-null p/BH q beside one another. Reported-event delta P describes association, including negative association, rather than positive cooperation.

| Selected dependency | Bootstrap selection | Training ancestral / co-carriers | Evaluation ancestral / co-carriers | Ordering BH q |
| --- | ---: | ---: | ---: | ---: |
| EGFR → KEAP1 | 19 / 100 | 1 / 1 | 0 / 0 | 1.0 |
| KEAP1 → STK11 | 85 / 100 | 2 / 12 | 0 / 5 | 1.0 |
| KEAP1 → SMARCA4 | 54 / 100 | 1 / 10 | 0 / 0 | 1.0 |

For KEAP1/STK11, the remaining training patients are nine same-cluster and one mapping-unresolved; evaluation contains four same-cluster and one mapping-unresolved. The 85% selection frequency cannot supply missing resolved evaluation ancestry. All 132 ordering directions have no BH q below .05. The frozen evaluation reported-driver co-occurrence score is worse than independence by approximately 0.06103 nats per patient; that score is not a temporal validation or clinical prediction metric.

The native model dataset renders every selected edge once as an independent two-event component, plus singleton components for isolated events. Repeated event labels are explicit display copies, never patients or clones. Full selected parent sets are preserved on every copy; no parent is discarded or interpreted as a deterministic AND gate or mandatory prerequisite. Auspice's hidden software forest root has no biological meaning.

Native model positions 0→1 are **unitless layout positions**, not mutation counts, time, support or source biological branch length. The stock Divergence, genomes and sequence-popup wording must be read under this convention. The projection cannot draw merges or show a joint conditioning set visually, so the exact companion DAG and embedded original model remain authoritative. A model with no edges is displayed honestly with its retained isolated events; no edges are invented to make a figure.

## Provenance and verification

`/source-model.json` downloads the exact input bytes. `/model.json` serves the validated model, its SHA256, display audit and native-tree links. Other than the explicit UI assets, server paths are whitelisted; invalid or unavailable evidence returns 503. No synthetic example substitutes for missing source results. The full source extract and SHA256 are embedded in each native patient export, and the complete model and copy mapping in the native population export. Original source terms and project release licensing remain separate.

```powershell
python -m unittest discover -s tracerx_routes/visualization/tests -v
node --check tracerx_routes/visualization/app.js
```

Thirteen display tests pass, including independent recounts of every patient-pair vote, category partitions, reverse orientation, missing/duplicate vote rejection, permitted conflicting aggregate directions, exact source singleton/chain lengths, internal driver-label fidelity, all 217 actual patient exports against the pinned official Augur v2 schema, exact selected model source counts, merged parent sets and zero-edge honesty, deliberate mutation rejection, and read-only HTTP byte identity / path whitelist / invalid-source failures. Fixture data are explicitly fictional and test-only.

Desktop browser verification passed pair selection and trace filtering, unchanged aggregate denominators, evaluation zero-resolved versus same-cluster/unmapped counts, actual patient-tree navigation, source lineage topology/SNV counts, the 353-SNV singleton display, and final visible internal KEAP1/STK11 labels using the native default `drivers` branch labels. The separate native model view also rendered all three dependencies and isolated events with its warning. Internal branch-popup behavior was not established. The requested mobile viewport override did not apply in the available browser surface; live mobile layout is **unverified**. Responsive CSS and contained table scrolling are implemented but are not substituted for that browser evidence.

The fresh independent Impeccable finish review inspected both desktop screenshots and the current source contract and returned **SHIP**. It reported no open material desktop findings. The complete category table continues below the first viewport, without obstructing inspection. No additional live interaction or mobile verification was claimed by the reviewer.

| Material finding | Verdict |
| --- | --- |
| No open material findings in the reviewed desktop scope | Resolved |
