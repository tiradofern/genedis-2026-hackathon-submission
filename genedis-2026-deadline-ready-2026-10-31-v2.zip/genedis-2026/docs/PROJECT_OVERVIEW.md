# GeNeDis 2026 molecular survival islands project

**Collaboration brief for Justin | Prepared October 15, 2026 | Audit snapshot October 14, 2026**

## Research question

Which coordinated transcriptional programs change between pretreatment and acquired resistance to PD-(L)1 therapy in non-small cell lung cancer, and do fixed signatures show related baseline response associations in a separate cohort?

Fernanda Tirado, DO, is the research lead. The project provisionally calls coordinated treatment-associated programs **Functional Molecular Survival Islands (FMSIs)**. This is a proposed operational concept. It does not imply physical genomic islands, tumor-intrinsic resistance, or a demonstrated causal mechanism. Genomic proximity is a secondary exploratory question.

## Selected design

| Evidence source | Verified structure | Intended contribution |
|---|---|---|
| GSE248249 | Clariom D expression arrays from 42 FFPE tumors in 29 patients; 13 complete pretreatment/acquired-resistance pairs | Selected primary focus: within-patient transcriptional change at acquired resistance |
| GSE207422 bulk | 24 pretreatment RNA profiles; 9 later MPR, including 5 pCR, and 15 NMPR | Independent biological comparison of baseline signatures with later pathologic response to chemoimmunotherapy |
| GSE156054 | Three parental/resistant EGFR-mutant model pairs; one deposited expression profile per model/state | Optional descriptive experimental comparison |
| TCGA LUAD and LUSC | Candidate expression, mutation, and copy-number resources; modality overlap not yet audited | Cross-cohort genomic context after exact sample and assay checks |

In the primary study, acquired resistance means an initial partial or complete response followed by progression. Everyone in its expression cohort developed acquired resistance; there is no durable-responder control group. GSE207422's baseline NMPR/MPR endpoint is different and cannot establish replication of acquired resistance. Its bulk assay has no longitudinal pairs.

## Main concerns for review

Only **4 of the 13 primary pairs** share the same reported anatomic site. A lung-to-liver sampling change can alter expression through tissue composition. Pairing controls stable patient characteristics, but does not remove this concern.

GEO supplies **SST-RMA expression values**, while the publication describes later ComBat and LOESS processing. The final corrected matrix is described as available on request. Explicit batch labels and histologic subtypes are absent from the inspected GEO characteristics. CEL filename groups are unconfirmed technical proxies. Complete GPL23126 gene annotation and batch/site QC are the next technical tasks.

The primary publication reports matched exomes, but these are in controlled-access dbGaP and are not available to this public-only workflow. Using TCGA would be cross-cohort integration. The GSE207422 comparison also contains unspecified NSCLC and a source-labeled Carcinosarcomatoid sample whose handling remains to be decided.

## Smallest useful study

Start with a small, prespecified collection of pathway scores across the 13 pairs, displaying each patient's change, effect estimates, uncertainty, and multiplicity control. Test sensitivity to patient omission, sampling site, and technical grouping. Known interferon pathways are reference biology from the original study, not automatically new discoveries.

Then evaluate fixed signatures against baseline MPR/NMPR in GSE207422. Attempt new coexpression modules only if QC and resampling support stability. Add separately audited genomic context after prioritizing candidates. A finding that modules are unstable, or that the cohorts disagree, is a valid outcome.

An alternative matched baseline RNA-methylation design exists under GSE126045, with 16 shared patient codes. It was not selected. It changes the question to later clinical benefit and has a preservation confounder: all five FFPE RNA samples are nonresponders.

## Review request and collaboration

Justin and his Codex assistant are asked to assess whether the selected design can support a credible exploratory result, identify the smallest analysis worth doing, propose concrete solutions to the annotation/batch/site issues, and suggest useful contributions. Please distinguish blockers from improvements and cite the exact source file, sample, or publication passage behind each finding. Proposed roles and work packages are suggestions until the team agrees.

The package includes the completed metadata audit, source references, code, and a feedback template. No discovery analysis has run. Seven parser tests and the source-integrity audit passed on Python 3.13.15 and 3.12.14. The complete expression files can be retrieved using the included downloader.

## Source references

- Primary cohort: [GSE248249](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE248249); [Memon et al.](https://doi.org/10.1016/j.ccell.2023.12.013).
- Baseline comparison: [GSE207422](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE207422); [Hu et al.](https://doi.org/10.1186/s13073-023-01164-9).
- Experimental models: [GSE156054](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE156054); [Wang et al.](https://doi.org/10.1016/j.bbamcr.2021.119016).
- Genomic context: [GDC TCGA LUAD](https://portal.gdc.cancer.gov/projects/TCGA-LUAD) and [TCGA LUSC](https://portal.gdc.cancer.gov/projects/TCGA-LUSC).
- Alternative: [GSE126045](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE126045); [Cho et al.](https://doi.org/10.1038/s12276-020-00493-8).
- Submission planning: the [official hackathon page](https://2026.genedis.org/hackathon/), checked October 14, listed October 31, 2026. Cutoff time/timezone and registration template remain to be confirmed.
