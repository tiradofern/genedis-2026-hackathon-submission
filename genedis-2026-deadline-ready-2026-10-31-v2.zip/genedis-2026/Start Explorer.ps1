$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$projectPython = Join-Path $projectRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $projectPython)) {
    throw 'Create the project environment first: python -m venv .venv; then .venv\Scripts\python.exe -m pip install -r requirements-app.txt'
}
Push-Location -LiteralPath $projectRoot
try {
    if (-not (Test-Path -LiteralPath (Join-Path $projectRoot 'data\processed\explorer_v0_1\prepared_manifest.json'))) {
        & $projectPython 'scripts\prepare_explorer.py'
        if ($LASTEXITCODE -ne 0) { throw 'Data preparation failed; see the message above.' }
    }
    Write-Host 'Open http://127.0.0.1:8766 in your browser. Keep this process running while using the explorer.'
    & $projectPython 'scripts\run_explorer.py'
} finally {
    Pop-Location
}
