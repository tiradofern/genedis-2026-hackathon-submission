import {stageColors,continuousColor,escapeHTML as esc,fmt,cnaLabel,matchesSample,csvText,validateSnapshot} from './helpers.js';

const $=id=>document.getElementById(id);
const defaults=()=>({stages:Object.keys(stageColors),sex:'',purity:0,includeUnknown:true,alteration:'all',activity:'all',search:''});
const state={data:null,study:'LUAD',view:'landscape',filters:defaults(),program:null,gene:null,geneQuery:'EGFR',color:'stage',selected:null,selection:null,page:0,zoom:1,brush:false,normal:false,inspector:'program',groups:{LUAD:{a:null,b:null},LUSC:{a:null,b:null}},geneToken:0,specimenToken:0};
let plotTransform=null,drag=null;
const cohort=()=>state.data.cohorts[state.study];
const program=()=>cohort().programs.find(p=>p.id===state.program)??null;
const scores=()=>cohort().scores[state.program]??[];
const groups=()=>state.groups[state.study];

function message(text){$('message').hidden=!text;$('message').innerHTML=text?`${esc(text)}<button id="dismiss-message" aria-label="Dismiss message">×</button>`:'';$('dismiss-message')?.addEventListener('click',()=>message(''));}
async function api(path,options){const response=await fetch(path,options);const result=await response.json();if(!response.ok)throw new Error(result.error??'The local data service did not respond.');return result;}
function selectedSamples(useBrush=true){const p=program(),values=scores();return cohort().samples.filter((sample,i)=>matchesSample(sample,i,state.filters,state.gene,values[i],p?.high_threshold??Infinity)&&(!useBrush||!state.selection||state.selection.has(sample.id)));}
function sampleIndex(id){return cohort().samples.findIndex(s=>s.id===id);}
function currentFiltersDescription(){const f=state.filters;return [f.stages.length===5?'All stages':f.stages.map(s=>s==='Unknown'?s:`Stage ${s}`).join(', '),f.sex||'All sexes',f.purity?`Purity ≥${f.purity}%${f.includeUnknown?' or unknown':''}`:'All purities',f.alteration==='all'?'':`${state.gene?.symbol??state.geneQuery}: ${f.alteration}`,f.activity==='all'?'':`${state.program}: ${f.activity}`,state.selection?'Area selection':''].filter(Boolean).join(' · ');}

function syncControls(){
  document.querySelectorAll('[data-study]').forEach(b=>{const active=b.dataset.study===state.study;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});
  $('stage-filters').innerHTML=Object.entries(stageColors).map(([name,color])=>`<div class="stage-option"><label class="check-label"><input type="checkbox" data-stage="${name}" ${state.filters.stages.includes(name)?'checked':''}><span class="stage-swatch" style="background:${color}" aria-hidden="true"></span><span>${name==='Unknown'?'Unknown':`Stage ${name}`}</span></label><span>${cohort().samples.filter(s=>s.stage_group===name).length}</span></div>`).join('');
  $('sex-filter').value=state.filters.sex;$('purity-filter').value=state.filters.purity;$('purity-output').textContent=`${state.filters.purity}%`;$('include-unknown').checked=state.filters.includeUnknown;
  $('alteration-filter').value=state.filters.alteration;$('activity-filter').value=state.filters.activity;$('sample-search').value=state.filters.search;$('color-by').value=state.color;$('gene-input').value=state.geneQuery;$('show-normal').checked=state.normal;
  $('activity-filter').disabled=!program();
}

function refresh(){
  if(!state.data)return;
  const selected=selectedSamples();
  $('landscape-title').textContent=`${state.study} molecular landscape`;
  $('cohort-summary').textContent=`${selected.length.toLocaleString()} of ${cohort().samples.length} tumors in view · ${cohort().name}`;
  $('specimen-count').textContent=`${selected.length.toLocaleString()} matched`;
  $('clear-selection').hidden=!state.selection;
  const g=groups();$('group-indicator').textContent=g.a||g.b?`${Number(Boolean(g.a))+Number(Boolean(g.b))}`:'';
  $('save-a').textContent=g.a?`Replace group A (${g.a.ids.length})`:'Save as group A';$('save-b').textContent=g.b?`Replace group B (${g.b.ids.length})`:'Save as group B';
  $('save-a').disabled=!selected.length;$('save-b').disabled=!selected.length;
  if(selected.length&&!selected.some(s=>s.id===state.selected)){state.selected=selected[0].id;loadSpecimen(state.selected);}
  if(!selected.length){state.selected=null;state.specimenToken++;$('specimen-inspector').innerHTML='<div class="inspector-empty"><h2>No tumors match</h2><p>Relax a filter or clear the area selection to inspect a specimen.</p></div>';}
  renderPlot();renderTable();
  if(state.view==='compare')renderCompare();
}

function domain(values){let low=Math.min(...values),high=Math.max(...values);const pad=(high-low||1)*.1;low-=pad;high+=pad;const center=(low+high)/2,half=(high-low)/2/state.zoom;return [center-half,center+half];}
const mix=continuousColor;
function pointColor(sample,index){if(state.color==='program'){const value=scores()[index]??0;return mix((value+2.5)/5);}if(state.color==='purity')return sample.purity===null?'#64748b':mix(sample.purity);if(state.color==='variant')return state.gene?.reported_variant_samples.includes(sample.id)?'#d97706':'#0072ce';return stageColors[sample.stage_group];}

function renderPlot(){
  const c=cohort(),visible=selectedSamples(false),base=state.normal?[...c.samples,...c.normal_references]:c.samples;
  const width=800,height=440,m={left:53,right:22,top:22,bottom:40},xd=domain(base.map(s=>s.x)),yd=domain(base.map(s=>s.y));
  const x=value=>m.left+(value-xd[0])/(xd[1]-xd[0])*(width-m.left-m.right),y=value=>height-m.bottom-(value-yd[0])/(yd[1]-yd[0])*(height-m.top-m.bottom);
  plotTransform={x,y,xd,yd,width,height};
  const grid=Array.from({length:5},(_,i)=>{const t=i/4,xv=xd[0]+(xd[1]-xd[0])*t,yv=yd[0]+(yd[1]-yd[0])*t;return `<line class="plot-grid" x1="${x(xv)}" x2="${x(xv)}" y1="${m.top}" y2="${height-m.bottom}"/><line class="plot-grid" x1="${m.left}" x2="${width-m.right}" y1="${y(yv)}" y2="${y(yv)}"/><text class="plot-axis" x="${x(xv)}" y="${height-20}" text-anchor="middle">${fmt(xv,0)}</text><text class="plot-axis" x="${m.left-10}" y="${y(yv)+4}" text-anchor="end">${fmt(yv,0)}</text>`;}).join('');
  const points=visible.map(sample=>{const index=sampleIndex(sample.id),opacity=(state.selection&&!state.selection.has(sample.id))?0.15:1;return `<circle class="tumor-point" data-id="${esc(sample.id)}" cx="${x(sample.x)}" cy="${y(sample.y)}" r="4.5" fill="${pointColor(sample,index)}" opacity="${opacity}"/>`;}).join('');
  const normals=state.normal?c.normal_references.map(sample=>`<path class="normal-point" d="M${x(sample.x)} ${y(sample.y)-4.5}l4.2 7.5h-8.4z"><title>${esc(sample.id)} · solid-tissue normal reference</title></path>`).join(''):'';
  const active=visible.find(s=>s.id===state.selected);
  $('landscape').innerHTML=`<title id="plot-title">${state.study} molecular similarity, ${visible.length} visible tumors</title><desc id="plot-description">Within-cohort PCA fitted on training participants. Points indicate similarity, not common ancestry. The table provides keyboard access.</desc><defs><clipPath id="plot-clip"><rect x="${m.left}" y="${m.top}" width="${width-m.left-m.right}" height="${height-m.top-m.bottom}"/></clipPath></defs>${grid}<g clip-path="url(#plot-clip)">${normals}${points}${active?`<circle class="selected-ring" cx="${x(active.x)}" cy="${y(active.y)}" r="7"/>`:''}<rect id="brush-rect" class="brush-rect" hidden/></g><text class="plot-axis-title" x="${width/2}" y="${height-2}" text-anchor="middle">PC1 · ${fmt(c.explained_variance[0]*100)}% training variance</text><text class="plot-axis-title" transform="translate(13 ${height/2}) rotate(-90)" text-anchor="middle">PC2 · ${fmt(c.explained_variance[1]*100)}%</text>${!visible.length?'<text x="410" y="205" text-anchor="middle" class="loading-label">No tumors match the current filters</text>':''}`;
  let legend=[];
  if(state.color==='stage')legend=Object.entries(stageColors).map(([name,color])=>[name==='Unknown'?name:`Stage ${name}`,color]);
  if(state.color==='program')legend=[['Lower activity',mix(0)],['Mid activity',mix(.5)],['Higher activity',mix(1)]];
  if(state.color==='purity')legend=[['Lower purity',mix(0)],['Mid purity',mix(.5)],['Higher purity',mix(1)],['Unknown','#64748b']];
  if(state.color==='variant')legend=[[`${state.gene?.symbol??'Gene'} reported event`,'#d97706'],['No reported event','#0072ce']];
  $('legend').innerHTML=legend.map(([label,color])=>`<span class="legend-item"><span class="legend-dot" style="background:${color}"></span>${esc(label)}</span>`).join('');
  $('brush-button').setAttribute('aria-pressed',String(state.brush));
}

function renderTable(){
  const visible=selectedSamples(),size=12,pages=Math.max(1,Math.ceil(visible.length/size));state.page=Math.min(state.page,pages-1);
  const start=state.page*size,rows=visible.slice(start,start+size);
  $('expression-header').textContent=`${state.gene?.symbol??'Gene'} RNA`;
  $('specimen-rows').innerHTML=rows.length?rows.map(sample=>{const i=sampleIndex(sample.id),variant=state.gene?.reported_variant_samples.includes(sample.id);return `<tr class="${sample.id===state.selected?'selected':''}"><td><button class="sample-link" data-specimen="${esc(sample.id)}">${esc(sample.id)}</button></td><td>${sample.stage_group==='Unknown'?'Unknown':esc(sample.stage_group)}</td><td>${sample.purity===null?'Unknown':`${fmt(sample.purity*100,0)}%`}</td><td>${state.gene?fmt(state.gene.expression[i],2):'Loading…'}</td><td>${state.gene?esc(cnaLabel(state.gene.cna[i])):'—'}</td><td>${state.gene?`<span class="tag ${variant?'pending':''}">${variant?'Reported':'No event'}</span>`:'—'}</td></tr>`;}).join(''):'<tr><td colspan="6">No matching specimens. Reset filters or clear the area selection.</td></tr>';
  $('table-range').textContent=visible.length?`${start+1}–${Math.min(start+size,visible.length)} of ${visible.length} · RNA: log2(RSEM + 1)`:'0 specimens';
  $('previous-page').disabled=state.page===0;$('next-page').disabled=state.page>=pages-1;
}

function renderPrograms(){
  const c=cohort(),p=program();
  if(!p){$('program-inspector').innerHTML='<div class="inspector-empty"><h2>No provisional programs</h2><p>The configured training-only screen did not produce a module meeting the minimum size. Gene and specimen exploration remain available.</p></div>';return;}
  $('program-inspector').innerHTML=`<section class="inspector-section"><div class="inspector-heading-line"><h2>Provisional RNA programs</h2><span class="tag">${c.programs.length}</span></div><p>Data-derived coordination; survival significance is unassigned.</p><div class="program-list">${c.programs.slice(0,5).map(item=>`<button class="program-row ${item.id===p.id?'active':''}" data-program="${item.id}" aria-pressed="${item.id===p.id}"><span><strong>${esc(item.name)}</strong><span class="tag pending">Untiered</span></span><small>${item.gene_count} genes · ${esc(item.genes.slice(0,3).map(g=>g.symbol).join(' / '))}</small></button>`).join('')}</div>${c.programs.length>5?`<label for="program-select" class="sub-label">All provisional programs</label><select class="program-select" id="program-select">${c.programs.map(item=>`<option value="${item.id}" ${item.id===p.id?'selected':''}>${esc(item.name)} · ${item.gene_count} genes</option>`).join('')}</select>`:''}</section><section class="inspector-section"><h3>${esc(p.name)}</h3><span class="tag pending">Validation pending</span>${p.broad?'<p class="subtle-note">Broad program exceeds the default 500-gene size and requires review.</p>':''}<p>Leading genes by absolute frozen score weight</p><div class="gene-chips">${p.genes.slice(0,8).map(g=>`<button class="gene-chip" data-gene="${esc(g.id)}" title="Load ${esc(g.symbol)} measurements">${esc(g.symbol)}</button>`).join('')}</div><dl class="measurements"><dt>Training PC1 variance</dt><dd>${fmt(p.pc1_variance*100)}% / 25% gate</dd><dt>Coordinated genes</dt><dd>${fmt(p.coordinated_fraction*100,0)}% / 70% gate</dd><dt>Coordination screen</dt><dd>${p.coordination_pass?'Passed':'Below gate'}</dd><dt>Resampling</dt><dd>Not run · 100 required</dd><dt>Holdout preservation</dt><dd>Not run</dd><dt>Biological evidence tier</dt><dd>Not assigned</dd></dl><p class="subtle-note">A reproducible program can enter Tier III without a survival association. This module has not yet passed that reproducibility workflow.</p><button class="button secondary" id="color-program" style="margin-top:13px">Color landscape by activity</button><details><summary>Frozen score and discovery method</summary><p>${esc(state.data.build.module_method)}. ${c.discovery_features.toLocaleString()} training-selected genes; ${c.training_n} training / ${c.evaluation_n} evaluation participants. Score: training-scaled first component projected without refitting. Published upstream normalization is fixed.</p></details></section>`;
  $('program-select')?.addEventListener('change',event=>selectProgram(event.target.value));
  $('color-program')?.addEventListener('click',()=>{state.color='program';$('color-by').value='program';refresh();});
}

function setInspector(which){state.inspector=which;document.querySelectorAll('[data-inspector]').forEach(b=>{const active=b.dataset.inspector===which;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});$('program-inspector').hidden=which!=='program';$('specimen-inspector').hidden=which!=='specimen';}
function selectProgram(id){state.program=id;state.selection=null;state.page=0;renderPrograms();refresh();if(state.selected)loadSpecimen(state.selected);}

async function loadSpecimen(id){
  if(!id)return;const token=++state.specimenToken,study=state.study;
  try{const value=await api(`/api/specimen?${new URLSearchParams({study,id})}`);if(token!==state.specimenToken||study!==state.study)return;
    const s=value.sample,index=sampleIndex(s.id),p=program();
    $('specimen-inspector').innerHTML=`<section class="inspector-section"><div class="inspector-heading-line"><h2>${esc(s.id)}</h2><span class="tag">${esc(s.study)}</span></div><p>${esc(s.histology)}</p><dl class="measurements"><dt>Source stage</dt><dd>${esc(s.stage||'Unknown')}</dd><dt>Age / sex</dt><dd>${s.age===null?'Unknown':fmt(s.age,0)} / ${esc(s.sex)}</dd><dt>ABSOLUTE purity</dt><dd>${s.purity===null?'Unknown':`${fmt(s.purity*100,0)}%`}</dd><dt>Model role</dt><dd>${s.role==='training'?'Training':'Evaluation'}</dd><dt>RPPA protein</dt><dd>${s.rppa?'Available':'Unavailable'}</dd><dt>IHC / grade</dt><dd>Not supplied</dd>${state.gene?`<dt>${esc(state.gene.symbol)} RNA</dt><dd>${fmt(state.gene.expression[index],2)}</dd><dt>${esc(state.gene.symbol)} CNA</dt><dd>${esc(cnaLabel(state.gene.cna[index]))}</dd>`:''}${p?`<dt>${esc(p.name)} score</dt><dd>${fmt(scores()[index],2)}</dd>`:''}</dl><p class="subtle-note">RNA is log2(batch-normalized RSEM + 1). Source tumor sample key; identical aliquot and tissue section are not established.</p></section><section class="inspector-section"><h3>Linked histology files</h3><p>${value.slides.length} source links · ${s.diagnostic_slide_count} diagnostic</p>${value.slides.slice(0,4).map(slide=>`<a class="slide-link" href="https://portal.gdc.cancer.gov/files/${encodeURIComponent(slide.file_id)}" target="_blank" rel="noopener noreferrer">${esc(slide.file_name.split('.')[0])}<small>${slide.diagnostic_slide==='True'?'Diagnostic':'Tissue'} slide · ${esc(slide.linkage)} link</small></a>`).join('')}<p class="subtle-note">Opens the GDC file record. Images have not been downloaded or assigned a histologic pattern.</p></section><section class="inspector-section"><h3>Reported DNA events</h3><p>${value.variant_record_count.toLocaleString()} MAF records · ${esc(value.genome_build)}</p><ul class="compact-list">${value.variants.slice(0,8).map(v=>`<li><strong>${esc(v.symbol)}</strong>${v.protein?' · '+esc(v.protein):''}<span>${esc(v.classification.replaceAll('_',' '))} · chr${esc(v.chromosome)}:${esc(v.position)}</span></li>`).join('')||'<li>No reported event in this profiled sample.</li>'}</ul><p class="subtle-note">First ${Math.min(8,value.variants.length)} records alphabetically; no clinical prioritization or actionability classification.</p><details><summary>Source clinical fields</summary><dl class="measurements">${Object.entries(s.clinical).filter(([key,val])=>val&&val!=='NA').map(([key,val])=>`<dt>${esc(key)}</dt><dd>${esc(val)}</dd>`).join('')}</dl></details></section>`;
  }catch(error){if(token===state.specimenToken)message(error.message);}
}

async function loadGene(query){
  const token=++state.geneToken,study=state.study;state.geneQuery=query;$('gene-input').value=query;$('gene-help').textContent='Loading verified measurements…';
  try{const value=await api(`/api/gene?${new URLSearchParams({study,gene:query})}`);if(token!==state.geneToken||study!==state.study)return;
    state.gene=value;state.geneQuery=value.symbol;$('gene-input').value=value.symbol;$('gene-help').textContent=`${value.symbol} · Entrez ${value.id} · all reported MAF classes`;
    state.page=0;refresh();if(state.selected)loadSpecimen(state.selected);
  }catch(error){if(token!==state.geneToken)return;state.geneQuery=state.gene?.symbol??query;$('gene-input').value=state.geneQuery;$('gene-help').textContent=state.gene?`Gene unavailable; still displaying ${state.gene.symbol}.`:'Gene unavailable. Try a source symbol or Entrez ID.';message(error.message);}
}

function changeStudy(study){
  state.study=study;state.filters=defaults();state.gene=null;state.selection=null;state.selected=null;state.page=0;state.zoom=1;state.program=cohort().programs[0]?.id??null;
  syncControls();renderPrograms();refresh();loadGene(state.geneQuery);
  if(state.view==='evidence')renderEvidence();
}

function changeView(view){state.view=view;for(const name of ['landscape','compare','evidence'])$(`${name}-view`).hidden=name!==view;document.querySelectorAll('[data-view]').forEach(b=>{const active=b.dataset.view===view;b.classList.toggle('active',active);b.setAttribute('aria-current',active?'page':'false');});if(view==='compare')renderCompare();if(view==='evidence')renderEvidence();}
function saveGroup(which){const ids=selectedSamples().map(s=>s.id);if(!ids.length)return;groups()[which]={ids,description:currentFiltersDescription(),filters:structuredClone(state.filters),program:state.program,gene:state.gene?.id??null};refresh();message(`Group ${which.toUpperCase()} saved with ${ids.length} ${state.study} tumors. Its specimen list stays fixed as you change filters.`);}

async function renderCompare(){
  const g=groups();
  $('comparison-content').innerHTML=`<div class="comparison-groups">${['a','b'].map(key=>`<section class="comparison-group"><h2>Group ${key.toUpperCase()} <span class="tag">${state.study}</span></h2><strong class="count">${g[key]?.ids.length??0} tumors</strong><p>${esc(g[key]?.description??'Use the landscape filters or area selection, then save the current population.')}</p><button class="button secondary" data-capture="${key}">Use current selection</button>${g[key]?`<button class="text-button" data-clear-group="${key}">Clear group</button>`:''}</section>`).join('')}</div><div id="comparison-results">${!g.a||!g.b?'<div class="empty-state" style="margin-top:23px"><h2>Define two populations</h2><p>Return to the landscape to select a population for each group. The comparison uses frozen specimen lists and excludes overlap explicitly.</p><button class="button secondary" id="return-landscape" style="margin-top:15px">Return to landscape</button></div>':'<p class="comparison-note">Calculating descriptive program differences…</p>'}</div>`;
  $('return-landscape')?.addEventListener('click',()=>changeView('landscape'));
  if(!g.a||!g.b)return;
  const capturedA=g.a,capturedB=g.b,study=state.study;
  try{const result=await api('/api/compare',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({study,a:g.a.ids,b:g.b.ids})});if(study!==state.study||capturedA!==groups().a||capturedB!==groups().b||state.view!=='compare')return;
    $('comparison-results').innerHTML=`${result.overlap_count?`<div class="wide-note">${result.overlap_count} shared tumors were excluded from both groups. Effective sizes: A ${result.a_count}, B ${result.b_count}.</div>`:''}<section class="comparison-results"><h2>Program activity</h2><p>Frozen training-scaled scores. Difference is group A mean minus group B mean; no p-values or evidence-tier promotion.</p><div class="table-scroll"><table><thead><tr><th>Provisional program</th><th>A mean / n</th><th>B mean / n</th><th>Difference</th></tr></thead><tbody>${result.programs.map(row=>`<tr><td>${esc(cohort().programs.find(p=>p.id===row.id)?.name??row.id)}</td><td>${fmt(row.a.mean,2)} / ${row.a.n}</td><td>${fmt(row.b.mean,2)} / ${row.b.n}</td><td>${row.difference!==null&&row.difference>0?'+':''}${fmt(row.difference,2)}</td></tr>`).join('')}</tbody></table></div></section><p class="comparison-note">If groups were defined by a program score, a difference in that same score is expected and remains descriptive. Stage, purity and other covariates have not been controlled by this comparison.</p>`;
  }catch(error){message(error.message);}
}

async function renderEvidence(){
  const c=cohort();
  $('evidence-content').innerHTML=`<section class="evidence-intro"><h2>What is measured in this release</h2><p>The backbone is a verified intersection of public TCGA PanCancer Atlas molecular profiles. A source sample key is not proof of identical vial, aliquot or histology section.</p><div class="table-scroll"><table class="coverage-table"><thead><tr><th>Coverage</th><th>LUAD</th><th>LUSC</th></tr></thead><tbody><tr><td>Primary tumors: RNA + CNA + mutation assay</td><td>507</td><td>481</td></tr><tr><td>RPPA protein measurements</td><td>355</td><td>313</td></tr><tr><td>ABSOLUTE purity</td><td>497</td><td>476</td></tr><tr><td>Bulk normal RNA samples</td><td>59</td><td>51</td></tr><tr><td>Named IHC fields / reported grade</td><td>Not supplied</td><td>Not supplied</td></tr></tbody></table></div></section><section class="evidence-section"><h2>Candidate-island rules</h2><p>Computational reproducibility is separate from biological evidence. The app currently displays provisional modules without a biological tier.</p><details open><summary>Tier III · Molecular Island of Uncertain Significance</summary><p>Requires reproducible coordination. Survival significance may be unknown. A DNA hit, pathway enrichment, tumor-normal difference or clinical association is not required.</p></details><details><summary>Tier II · Survival-Associated Molecular Island</summary><p>Requires reproducible coordination and a prespecified, confounder-assessed phenotype association with consistent direction and FDR ≤0.05 in discovery and declared held-out validation families. A discovery p-value alone is insufficient.</p></details><details><summary>Tier I · Functionally Supported Survival Island</summary><p>Requires convincing functional evidence for the specific coordinated program in a relevant context. A known component or pathway label does not validate the full program. No clinical actionability is implied.</p></details><details><summary>Current preparation and validation scope</summary><p>${c.training_n} training and ${c.evaluation_n} evaluation participants in ${state.study}; ${c.discovery_features.toLocaleString()} training-selected features. Upstream published normalization is fixed. PCA and program scores are fitted on training participants. Resampling, holdout preservation and clinical association tests have not been run. Repeated or ambiguous gene identifiers were excluded explicitly.</p></details><details><summary>Full versioned criteria</summary><pre class="criteria-pre">${esc(JSON.stringify(state.data.criteria,null,2))}</pre></details></section><section class="evidence-section"><h2>Source provenance</h2><p>Public inputs remain local. No raw sequencing or whole-slide images were downloaded. Dataset fingerprint: <code>${esc(state.data.fingerprint.slice(0,20))}</code></p><div id="source-inventory">Loading the source inventory…</div></section>`;
  try{const evidence=await api('/api/provenance');if(state.view!=='evidence')return;
    $('source-inventory').innerHTML=`<p class="comparison-note">${evidence.inventory.length} checked source files · ${evidence.exclusions.length} ambiguous/repeated feature rows excluded across tumor RNA, CNA and normal RNA.</p><div class="table-scroll"><table class="source-table"><thead><tr><th>Study / resource</th><th>Stored bytes</th><th>SHA256</th><th>Source</th></tr></thead><tbody>${evidence.inventory.map(row=>`<tr><td>${esc(row.study)}<br>${esc(row.resource)}</td><td>${Number(row.bytes).toLocaleString()}</td><td><code title="${esc(row.sha256)}">${esc(row.sha256.slice(0,16))}…</code></td><td><a href="${esc(row.lfs_pointer_url||row.url)}" target="_blank" rel="noopener noreferrer">View source</a></td></tr>`).join('')}</tbody></table></div>`;
  }catch(error){message(error.message);}
}

function download(name,content,type){const url=URL.createObjectURL(new Blob([content],{type})),anchor=document.createElement('a');anchor.href=url;anchor.download=name;anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function snapshot(){return {schema_version:1,app_version:state.data.version,dataset_fingerprint:state.data.fingerprint,source_commit:state.data.source_commit,criteria_version:state.data.criteria.specification_version,study:state.study,program:state.program,gene:state.gene?.id??state.geneQuery,color:state.color,filters:structuredClone(state.filters),selected_ids:selectedSamples().map(s=>s.id),area_selection:state.selection?[...state.selection]:null,groups:groups(),created_utc:new Date().toISOString(),interpretation:'Exploratory selection; provisional programs have no biological tier'};}
function exportJSON(){if(state.data)download(`survival-island-exploration-${state.study}.json`,JSON.stringify(snapshot(),null,2),'application/json');}
function exportCSV(){const rows=selectedSamples().map(sample=>{const i=sampleIndex(sample.id);return [sample.id,sample.patient_id,state.study,sample.histology,sample.stage,sample.purity,state.gene?.symbol,state.gene?.expression[i],state.gene?.cna[i],state.gene?state.gene.reported_variant_samples.includes(sample.id):'',state.program,scores()[i],sample.role,state.data.fingerprint];});download(`TCGA-${state.study}-selection.csv`,csvText(['sample_id','patient_id','cohort','source_histology','source_stage','absolute_purity','gene','log2_RSEM_plus_1','GISTIC_CNA','reported_MAF_event','provisional_program','program_score','model_role','dataset_fingerprint'],rows),'text/csv;charset=utf-8');}

function svgPosition(event){return new DOMPoint(event.clientX,event.clientY).matrixTransform($('landscape').getScreenCTM().inverse());}
function bindEvents(){
  const narrow=window.matchMedia('(max-width:680px)');
  $('filter-drawer').open=!narrow.matches;
  narrow.addEventListener('change',event=>{$('filter-drawer').open=!event.matches;});
  document.querySelectorAll('[data-study]').forEach(b=>b.addEventListener('click',()=>changeStudy(b.dataset.study)));
  document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>changeView(b.dataset.view)));
  document.querySelectorAll('[data-inspector]').forEach(b=>b.addEventListener('click',()=>setInspector(b.dataset.inspector)));
  $('stage-filters').addEventListener('change',()=>{state.filters.stages=[...document.querySelectorAll('[data-stage]:checked')].map(el=>el.dataset.stage);state.page=0;refresh();});
  const update=()=>{state.filters.sex=$('sex-filter').value;state.filters.purity=Number($('purity-filter').value);state.filters.includeUnknown=$('include-unknown').checked;state.filters.alteration=$('alteration-filter').value;state.filters.activity=$('activity-filter').value;state.filters.search=$('sample-search').value.trim();$('purity-output').textContent=`${state.filters.purity}%`;state.page=0;refresh();};
  ['sex-filter','purity-filter','include-unknown','alteration-filter','activity-filter','sample-search'].forEach(id=>$(id).addEventListener(id==='sample-search'||id==='purity-filter'?'input':'change',update));
  $('reset-filters').addEventListener('click',()=>{state.filters=defaults();state.selection=null;state.page=0;syncControls();refresh();message('');});
  $('gene-form').addEventListener('submit',event=>{event.preventDefault();loadGene($('gene-input').value.trim());});
  $('gene-input').addEventListener('input',()=>{const query=$('gene-input').value.toUpperCase();const matches=state.data.genes.filter(g=>g.symbol.toUpperCase().startsWith(query)||g.id===query).slice(0,30);$('gene-options').innerHTML=matches.map(g=>`<option value="${esc(g.symbol)}">Entrez ${esc(g.id)}</option>`).join('');});
  $('color-by').addEventListener('change',()=>{state.color=$('color-by').value;renderPlot();});
  $('show-normal').addEventListener('change',()=>{state.normal=$('show-normal').checked;renderPlot();});
  $('brush-button').addEventListener('click',()=>{state.brush=!state.brush;renderPlot();});
  $('zoom-in').addEventListener('click',()=>{state.zoom=Math.min(5,state.zoom*1.35);renderPlot();});$('zoom-out').addEventListener('click',()=>{state.zoom=Math.max(.6,state.zoom/1.35);renderPlot();});
  $('reset-view').addEventListener('click',()=>{state.zoom=1;state.selection=null;refresh();});$('clear-selection').addEventListener('click',()=>{state.selection=null;state.page=0;refresh();});
  $('previous-page').addEventListener('click',()=>{state.page=Math.max(0,state.page-1);renderTable();});$('next-page').addEventListener('click',()=>{state.page++;renderTable();});
  $('save-a').addEventListener('click',()=>saveGroup('a'));$('save-b').addEventListener('click',()=>saveGroup('b'));
  $('export-json').addEventListener('click',exportJSON);$('export-csv').addEventListener('click',exportCSV);
  document.addEventListener('click',event=>{const specimen=event.target.closest('[data-specimen]'),p=event.target.closest('[data-program]'),gene=event.target.closest('[data-gene]'),capture=event.target.closest('[data-capture]'),clear=event.target.closest('[data-clear-group]');if(specimen){state.selected=specimen.dataset.specimen;setInspector('specimen');loadSpecimen(state.selected);renderPlot();renderTable();}if(p)selectProgram(p.dataset.program);if(gene)loadGene(gene.dataset.gene);if(capture)saveGroup(capture.dataset.capture);if(clear){groups()[clear.dataset.clearGroup]=null;refresh();}});
  $('landscape').addEventListener('click',event=>{if(state.brush)return;const point=event.target.closest('[data-id]');if(point){state.selected=point.dataset.id;setInspector('specimen');loadSpecimen(state.selected);renderPlot();renderTable();}});
  $('landscape').addEventListener('pointermove',event=>{if(drag){const point=svgPosition(event),rect=$('brush-rect');rect.removeAttribute('hidden');rect.setAttribute('x',Math.min(drag.x,point.x));rect.setAttribute('y',Math.min(drag.y,point.y));rect.setAttribute('width',Math.abs(point.x-drag.x));rect.setAttribute('height',Math.abs(point.y-drag.y));return;}const point=event.target.closest('[data-id]');if(!point){$('plot-tooltip').hidden=true;return;}const sample=cohort().samples.find(s=>s.id===point.dataset.id),rect=$('plot-wrap').getBoundingClientRect();$('plot-tooltip').innerHTML=`<strong>${esc(sample.id)}</strong>${esc(sample.stage||'Stage unknown')} · ${sample.purity===null?'Purity unknown':`${fmt(sample.purity*100,0)}% purity`}`;$('plot-tooltip').style.left=`${Math.min(event.clientX-rect.left+12,rect.width-220)}px`;$('plot-tooltip').style.top=`${Math.max(0,event.clientY-rect.top-60)}px`;$('plot-tooltip').hidden=false;});
  $('landscape').addEventListener('pointerleave',()=>{$('plot-tooltip').hidden=true;});
  $('landscape').addEventListener('pointerdown',event=>{if(!state.brush)return;drag=svgPosition(event);$('landscape').setPointerCapture(event.pointerId);$('plot-tooltip').hidden=true;});
  $('landscape').addEventListener('pointercancel',()=>{drag=null;renderPlot();});
  $('landscape').addEventListener('pointerup',event=>{if(!drag)return;const end=svgPosition(event),left=Math.min(drag.x,end.x),right=Math.max(drag.x,end.x),top=Math.min(drag.y,end.y),bottom=Math.max(drag.y,end.y);state.selection=new Set(selectedSamples(false).filter(s=>plotTransform.x(s.x)>=left&&plotTransform.x(s.x)<=right&&plotTransform.y(s.y)>=top&&plotTransform.y(s.y)<=bottom).map(s=>s.id));drag=null;state.page=0;refresh();});
  $('import-button').addEventListener('click',()=>$('import-file').click());
  $('import-file').addEventListener('change',async event=>{try{const file=event.target.files[0];if(!file)return;if(file.size>1000000)throw new Error('The exploration file is too large.');const saved=validateSnapshot(JSON.parse(await file.text()),state.data);state.study=saved.study;state.filters=saved.filters;state.program=saved.program;state.selection=saved.area_selection?new Set(saved.area_selection):null;state.groups[state.study]=saved.groups??{a:null,b:null};state.color=['stage','program','purity','variant'].includes(saved.color)?saved.color:'stage';state.page=0;state.zoom=1;state.gene=null;syncControls();renderPrograms();changeView('landscape');refresh();await loadGene(String(saved.gene??'EGFR'));message('Exploration restored against the same verified dataset and criteria.');}catch(error){message(error.message);}finally{event.target.value='';}});
}

async function initialize(){
  try{state.data=await api('/api/bootstrap');state.program=cohort().programs[0]?.id??null;$('fingerprint-label').textContent=`Dataset ${state.data.fingerprint.slice(0,10)}`;bindEvents();syncControls();renderPrograms();refresh();loadGene('EGFR');}
  catch(error){$('cohort-summary').textContent='The local prepared dataset could not be loaded.';$('plot-wrap').innerHTML='<div class="empty-state"><h2>Connect the verified data</h2><p>Check that the local server is running and the prepared-data manifest matches the criteria. Restart the explorer after running the preparation script.</p><button class="button secondary" id="retry-load" style="margin-top:15px">Retry connection</button></div>';$('retry-load').addEventListener('click',()=>location.reload());message(error.message);}
}
initialize();
