export const stageColors = {I:'#0072ce',II:'#d97706',III:'#009e73',IV:'#a23fc0',Unknown:'#64748b'};
export const activityColors = ['#40c4f4','#1684e8','#4a16ad'];
export function continuousColor(value){
  const position=Math.max(0,Math.min(1,value))*(activityColors.length-1);
  const index=Math.min(activityColors.length-2,Math.floor(position)),fraction=position-index;
  const channels=color=>color.match(/[a-f\d]{2}/gi).map(channel=>parseInt(channel,16));
  const a=channels(activityColors[index]),b=channels(activityColors[index+1]);
  return `rgb(${a.map((channel,i)=>Math.round(channel+(b[i]-channel)*fraction)).join(',')})`;
}
export const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const fmt = (value, digits=1) => value === null || value === undefined || !Number.isFinite(Number(value)) ? '—' : Number(value).toLocaleString('en-US',{maximumFractionDigits:digits,minimumFractionDigits:digits});
export const cnaLabel = value => value === null || value === undefined ? 'Unmeasured' : ({'-2':'Deletion','-1':'Loss','0':'Neutral','1':'Gain','2':'Amplification'}[value] ?? 'Unknown');

export function matchesSample(sample,index,filters,gene,score,threshold){
  if(!filters.stages.includes(sample.stage_group)) return false;
  if(filters.sex && sample.sex!==filters.sex) return false;
  if(sample.purity===null ? !filters.includeUnknown : sample.purity*100<filters.purity) return false;
  if(filters.search && !sample.id.toLowerCase().includes(filters.search.toLowerCase())) return false;
  if(filters.activity==='high' && !(score>=threshold)) return false;
  if(filters.activity==='other' && !(score<threshold)) return false;
  if(filters.alteration!=='all'){
    if(!gene) return false;
    const variant=gene.reported_variant_samples.includes(sample.id),cna=gene.cna[index];
    if(filters.alteration==='variant'&&!variant) return false;
    if(filters.alteration==='no-variant'&&variant) return false;
    if(filters.alteration==='amp'&&cna!==2) return false;
    if(filters.alteration==='del'&&cna!==-2) return false;
    if(filters.alteration==='cna-unknown'&&cna!==null) return false;
  }
  return true;
}

export function csvText(headers,rows){
  const quote=value=>'"'+String(value??'').replaceAll('"','""')+'"';
  return [headers,...rows].map(row=>row.map(quote).join(',')).join('\r\n');
}

export function validateSnapshot(value,bootstrap){
  if(value.schema_version!==1||value.dataset_fingerprint!==bootstrap.fingerprint) throw new Error('This exploration belongs to a different dataset or criteria version.');
  const cohort=bootstrap.cohorts[value.study];
  if(!cohort) throw new Error('The saved cohort is unavailable.');
  const known=new Set(cohort.samples.map(s=>s.id));
  const lists=[value.selected_ids??[],value.area_selection??[],value.groups?.a?.ids??[],value.groups?.b?.ids??[]];
  if(lists.some(list=>!Array.isArray(list)||list.some(id=>!known.has(id)))) throw new Error('The exploration contains specimens outside the verified cohort.');
  if(!value.filters||!Array.isArray(value.filters.stages)||value.filters.stages.some(stage=>!Object.hasOwn(stageColors,stage))) throw new Error('The saved stage filter is invalid.');
  if(!Number.isFinite(value.filters.purity)||value.filters.purity<0||value.filters.purity>100) throw new Error('The saved purity filter is invalid.');
  if(!['all','high','other'].includes(value.filters.activity)||!['all','variant','no-variant','amp','del','cna-unknown'].includes(value.filters.alteration)) throw new Error('The saved molecular filter is invalid.');
  if(typeof value.filters.search!=='string'||typeof value.filters.sex!=='string'||typeof value.filters.includeUnknown!=='boolean') throw new Error('The saved filter values are invalid.');
  if(value.program&&!cohort.programs.some(p=>p.id===value.program)) throw new Error('The saved program is unavailable.');
  if(typeof value.gene!=='string'||!['stage','program','purity','variant'].includes(value.color)) throw new Error('The saved display settings are invalid.');
  return value;
}
