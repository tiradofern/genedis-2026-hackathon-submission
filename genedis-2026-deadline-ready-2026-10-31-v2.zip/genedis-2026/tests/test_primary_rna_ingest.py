"""Fault-injection checks for count parsing, exact IDs and common RNA QC."""
import csv
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

from scipy import sparse

SCRIPT = Path(__file__).resolve().parents[1] / 'pilot/cellular_2026-10-31/prepare_primary_rna.py'
SPEC = importlib.util.spec_from_file_location('prepare_primary_rna', SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class PrimaryRNAIngestTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='primary-rna-parser-test-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / 'counts.csv'
        self.metadata = self.root / 'metadata.csv'
        self.metadata.write_text('cell_id\na\nb\n')
        self.selected = [{'cell_id': 'a', 'patient_id': 'synthetic:p1'},
                         {'cell_id': 'b', 'patient_id': 'synthetic:p1'}]
        self.valid = [',a,b', 'MT-CO1,3,0'] + [f'G{k},3,0' for k in range(199)]

    def prepare(self, lines):
        self.source.write_text('\n'.join(lines) + '\n')
        return MODULE.ingest(self.source, self.selected, self.root / 'out',
                             'synthetic', self.metadata)

    def test_sparse_orientation_source_order_counts_and_qc_exclusions(self):
        receipt = self.prepare(self.valid)
        matrix = sparse.load_npz(self.root / 'out/synthetic_counts.npz')
        self.assertEqual(matrix.shape, (1, 200))
        self.assertEqual(int(matrix.sum()), 600)
        self.assertEqual(matrix[0, 0], 3)
        self.assertEqual(receipt['eligible_annotated_cells'], 2)
        self.assertEqual(receipt['technical_QC_pass_cells'], 1)
        genes = json.loads((self.root / 'out/synthetic_genes.json').read_text())
        self.assertEqual(genes, ['MT-CO1'] + [f'G{k}' for k in range(199)])
        with (self.root / 'out/synthetic_eligible_cell_qc.csv').open() as handle:
            cells = list(csv.DictReader(handle))
        self.assertEqual([row['cell_id'] for row in cells], ['a', 'b'])
        self.assertEqual(cells[0]['UMI'], '600')
        self.assertEqual(cells[0]['detected_genes'], '200')
        self.assertEqual(cells[0]['MT_UMI'], '3')
        self.assertAlmostEqual(float(cells[0]['MT_percent']), 0.5)
        self.assertEqual(cells[1]['technical_QC_pass'], 'False')

    def test_corrupt_numeric_fields_are_rejected_in_unselected_columns(self):
        # Validation must include unselected source columns, not only cells kept.
        self.selected = self.selected[:1]
        for bad in ['-1', '0.5', 'nan', 'inf', '2junk', '4294967296']:
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                self.prepare([',a,b', f'G,3,{bad}'])

    def test_duplicate_genes_cells_and_width_mismatch_are_rejected(self):
        malformed = [self.valid + [self.valid[1]], [',a,a'] + self.valid[1:],
                     [',a,b', 'G,1'], [',a,b', 'G,1,2,3']]
        for lines in malformed:
            with self.subTest(lines=lines[:2]), self.assertRaises(ValueError):
                self.prepare(lines)

    def test_metadata_ids_missing_from_source_are_rejected(self):
        self.selected[0]['cell_id'] = 'missing'
        with self.assertRaisesRegex(ValueError, 'metadata IDs missing'):
            self.prepare(self.valid)

    def test_no_quality_passing_cells_fails_without_lowering_thresholds(self):
        with self.assertRaisesRegex(ValueError, 'No cells pass common technical QC'):
            self.prepare([',a,b', 'G,1,1'])

    def test_quoted_gene_names_use_csv_and_are_preserved(self):
        lines = self.valid.copy()
        lines[1] = '"GENE,WITH,COMMA",3,0'
        self.prepare(lines)
        genes = json.loads((self.root / 'out/synthetic_genes.json').read_text())
        self.assertEqual(genes[0], 'GENE,WITH,COMMA')


if __name__ == '__main__':
    unittest.main()
