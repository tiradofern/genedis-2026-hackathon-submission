"""Pure synthetic package checks; no source-assay access or molecular analysis."""
import csv
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

SCRIPT = Path(__file__).resolve().parents[1]/'submission/verify_deadline_package.py'
SPEC = importlib.util.spec_from_file_location('deadline_package_verifier',SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class DeadlinePackageVerifierTests(unittest.TestCase):
    def archive(self,name,mode=0o100644):
        buffer=io.BytesIO()
        with zipfile.ZipFile(buffer,'w') as archive:
            item=zipfile.ZipInfo(name);item.external_attr=mode<<16
            archive.writestr(item,b'synthetic fixture')
        buffer.seek(0)
        return zipfile.ZipFile(buffer)

    def test_safe_inventory_rejects_traversal_links_and_assay_blobs(self):
        for name,mode in [('genedis-2026/../../escape.txt',0o100644),
                ('/absolute.txt',0o100644),('genedis-2026/README.md',0o120777),
                ('genedis-2026/data/external/raw.csv',0o100644),
                ('genedis-2026/pilot/raw.rds',0o100644),
                ('genedis-2026/./README.md',0o100644)]:
            with self.subTest(name=name),self.archive(name,mode) as archive:
                with self.assertRaises(ValueError):MODULE.safe_inventory(archive)
        with self.archive('genedis-2026/README.md') as archive:
            self.assertEqual(len(MODULE.safe_inventory(archive)),1)

    def test_frozen_hash_mismatch_or_missing_file_fails(self):
        MODULE.check_hash({'a':b'valid'},'a',hashlib.sha256(b'valid').hexdigest())
        for payload in ({'a':b'changed'},{}):
            with self.assertRaises(ValueError):MODULE.check_hash(payload,'a',hashlib.sha256(b'valid').hexdigest())

    def test_gmt_requires_complete_fifty_program_family_and_exact_members(self):
        groups={f'P{k}':['G1','G2'] for k in range(50)}
        gmt='\n'.join('\t'.join([name,'synthetic']+genes) for name,genes in groups.items()).encode()
        specification={'gmt_path':'panel.gmt','gmt_sha256':MODULE.digest(gmt),'family_size':50,
            'members_sha256':MODULE.digest(json.dumps(groups,sort_keys=True,separators=(',',':')).encode())}
        self.assertEqual(len(MODULE.program_members({'panel.gmt':gmt},specification)),50)
        specification['members_sha256']='0'*64
        with self.assertRaises(ValueError):MODULE.program_members({'panel.gmt':gmt},specification)

    def test_csv_requires_exact_patient_program_cartesian_product(self):
        programs=[f'P{k}' for k in range(50)];patients=['p1','p2','p3']
        patient=io.StringIO();writer=csv.writer(patient);writer.writerow(['program','patient_id'])
        for p in programs:
            for person in patients:writer.writerow([p,person])
        family=io.StringIO();writer=csv.writer(family);writer.writerow(['program'])
        for p in programs:writer.writerow([p])
        payload={MODULE.CELL+'results/primary_all_programs_by_patient.csv':patient.getvalue().encode(),
                 MODULE.CELL+'results/primary_conditional_by_family.csv':family.getvalue().encode()}
        self.assertEqual(MODULE.check_csv_family(payload,'primary',programs,patients)['patient_rows'],150)
        lines=patient.getvalue().splitlines();lines[-1]=lines[1]
        payload[MODULE.CELL+'results/primary_all_programs_by_patient.csv']='\n'.join(lines).encode()
        with self.assertRaises(ValueError):MODULE.check_csv_family(payload,'primary',programs,patients)

    def test_public_source_hashes_are_bound_to_frozen_inputs(self):
        cohorts=[{'inputs':[{'path':'data/counts.csv','sha256':'a'*64,'bytes':123}]}]
        manifest={'artifacts':[{'path':'counts.csv','sha256':'a'*64,'bytes':123}]}
        self.assertEqual(MODULE.source_bindings(cohorts,manifest,{}),1)
        manifest['artifacts'][0]['sha256']='b'*64
        with self.assertRaises(ValueError):MODULE.source_bindings(cohorts,manifest,{})

    def test_frontend_reporter_is_explicit_tap_and_summary_is_checked(self):
        self.assertIn('--test-reporter=tap',MODULE.FRONTEND_COMMAND)
        self.assertEqual(MODULE.frontend_pass_count('TAP version 13\n# pass 5\n# fail 0\n'),5)
        for invalid in ['# pass 5\n# fail 1\n','# pass 4\n# fail 0\n','ℹ pass 5\nℹ fail 0\n']:
            with self.subTest(invalid=invalid),self.assertRaises(ValueError):
                MODULE.frontend_pass_count(invalid)

    def test_verification_report_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);report=root/'report.json';report.write_text('preserve')
            with self.assertRaises(ValueError):
                MODULE.verify_package(root/'unused.zip',root/'unused-ref.zip','unused-python',report,root)
            self.assertEqual(report.read_text(),'preserve')
