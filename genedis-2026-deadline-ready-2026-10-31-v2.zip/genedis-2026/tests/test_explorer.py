"""Scientific safeguards and HTTP behavior using explicitly synthetic fixtures."""
import hashlib
import json
import sqlite3
import sys
import tempfile
import threading
import unittest
from contextlib import closing
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from survival_islands.explorer_model import descriptive_comparison, fit_components, fit_features, participant_split, project, provisional_modules
from survival_islands.explorer_server import ExplorerStore, handler_for
from scripts.prepare_explorer import read_matrix

CRITERIA = json.loads((ROOT / "configs/candidate_island_v0_1.json").read_text())["discovery"]
BUILD = json.loads((ROOT / "configs/explorer_build_v0_1.json").read_text())


class ModelTests(unittest.TestCase):
    def test_split_is_order_independent_and_rejects_repeated_participants(self):
        ids = [f"synthetic-{i}" for i in range(200)]
        train, holdout = participant_split(ids, 20261017)
        reverse = ids[::-1]
        reverse_train, _ = participant_split(reverse, 20261017)
        self.assertEqual({ids[i] for i in train}, {reverse[i] for i in reverse_train})
        self.assertEqual((len(train), len(holdout)), (140, 60))
        self.assertFalse(set(train) & set(holdout))
        with self.assertRaises(ValueError):
            participant_split(["same", "same"], 1)

    def test_holdout_cannot_change_features_or_transform(self):
        rng = np.random.default_rng(13)
        values = np.exp(rng.normal(2, .8, (160, 40)))
        train = np.arange(110)
        values[3, 4] = np.nan
        first = fit_features(values, train, list(map(str, range(40))), CRITERIA, 25)
        changed = values.copy()
        changed[110:] = 1e12
        second = fit_features(changed, train, list(map(str, range(40))), CRITERIA, 25)
        for key in ("selected", "impute", "center", "scale"):
            np.testing.assert_array_equal(first[key], second[key])
        np.testing.assert_allclose(project(values, first), first["normalized"])
        components, variance = fit_components(first["normalized"][train], 2)
        np.testing.assert_allclose(components.T @ components, np.eye(2), atol=1e-10)
        self.assertTrue(np.all((variance > 0) & (variance < 1)))

    def test_negative_rsem_rejected(self):
        with self.assertRaises(ValueError):
            fit_features(np.full((150, 25), -1.), np.arange(100), list(map(str, range(25))), CRITERIA, 25)

    def test_planted_coordination_and_frozen_scores_without_tiering(self):
        rng = np.random.default_rng(29)
        values = np.exp(2 + rng.normal(size=(220, 1)) + rng.normal(scale=.05, size=(220, 30)))
        train = np.arange(150)
        transform = fit_features(values, train, list(map(str, range(30))), CRITERIA, 30)
        modules = provisional_modules(transform["normalized"], train, BUILD, CRITERIA)
        self.assertEqual(len(modules), 1)
        module = modules[0]
        self.assertTrue(module["coordination_pass"])
        self.assertEqual(len(module["indices"]), 30)
        expected = transform["normalized"][:, module["indices"]] @ module["weights"] / module["score_scale"]
        np.testing.assert_allclose(module["scores"], expected)
        self.assertAlmostEqual(module["scores"][train].std(ddof=1), 1)
        changed = transform["normalized"].copy()
        changed[150:] = 1e9
        refit = provisional_modules(changed, train, BUILD, CRITERIA)[0]
        np.testing.assert_allclose(module["weights"], refit["weights"])
        self.assertNotIn("evidence_tier", module)

    def test_comparison_deduplicates_and_excludes_overlap_from_both(self):
        samples = [{"id": sid} for sid in ["a", "b", "c"]]
        result = descriptive_comparison(samples, {"p": [1., 100., 4.]}, ["a", "a", "b"], ["b", "c"])
        self.assertEqual((result["a_count"], result["b_count"], result["overlap_count"]), (1, 1, 1))
        self.assertEqual(result["programs"][0]["difference"], -3)
        self.assertIn("no hypothesis test", result["interpretation"])
        empty = descriptive_comparison(samples, {"p": [1., 2., 3.]}, ["a"], ["a"])
        self.assertIsNone(empty["programs"][0]["difference"])
        with self.assertRaises(ValueError):
            descriptive_comparison(samples, {}, ["outsider"], [])


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.data = self.root / "prepared"
        self.data.mkdir()
        (self.root / "configs").mkdir()
        for name in ("candidate_island_v0_1.json", "explorer_build_v0_1.json"):
            (self.root / "configs" / name).write_text("{}")
        self.write("bootstrap.json", {"fingerprint": "synthetic", "version": "test", "cohorts": {"LUAD": {"samples": [{"id": "fixture", "patient_id": "participant"}], "scores": {"p": [1.]}}}})
        self.write("LUAD_genes.json", {"rna_ids": ["1", "2"], "rna_symbols": ["G1", "G2"], "cna_ids": ["1"], "cna_symbols": ["G1"]})
        self.write("LUAD_slides.json", [{"patient_id": "participant", "sample_key": "fixture", "diagnostic_slide": "False", "file_name": "tissue"}, {"patient_id": "participant", "sample_key": "normal", "diagnostic_slide": "True", "file_name": "diagnostic"}])
        np.savez(self.data / "LUAD_matrices.npz", rna=np.array([[np.nan, 2.]]), cna=np.array([[np.nan]]))
        with closing(sqlite3.connect(self.data / "measurements.sqlite")) as database:
            database.execute("CREATE TABLE variants(study,sample,gene,symbol,classification,protein,chromosome,position,reference,alternate)")
            database.execute("INSERT INTO variants VALUES ('LUAD','fixture','1','G1','Silent','','1','9','A','C')")
            database.commit()
        self.manifest = {"fingerprint": "synthetic", "criteria_sha256": hashlib.sha256(b"{}").hexdigest(), "build_sha256": hashlib.sha256(b"{}").hexdigest(), "files": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in self.data.iterdir()}}
        self.write("prepared_manifest.json", self.manifest)
        self.store = ExplorerStore(self.data, self.root)

    def write(self, name, value):
        (self.data / name).write_text(json.dumps(value))

    def test_unmeasured_measurements_are_json_null_not_zero(self):
        gene = self.store.gene("LUAD", "g1")
        self.assertEqual(gene["expression"], [None])
        self.assertEqual(gene["cna"], [None])
        self.assertEqual(gene["reported_variant_samples"], ["fixture"])
        self.assertEqual(self.store.gene("LUAD", "2")["cna"], [None])
        json.dumps(gene, allow_nan=False)

    def test_source_variant_classes_and_slide_linkages_stay_distinct(self):
        specimen = self.store.specimen("LUAD", "fixture")
        self.assertEqual(specimen["variants"][0]["classification"], "Silent")
        self.assertEqual([s["linkage"] for s in specimen["slides"]], ["sample-key", "patient-only"])
        with self.assertRaises(KeyError):
            self.store.specimen("LUAD", "outsider")
        with self.assertRaises(ValueError):
            self.store.cohort("OTHER")
        with self.assertRaises(ValueError):
            self.store.compare("LUAD", [[]], [])

    def test_changed_artifact_or_configuration_prevents_startup(self):
        (self.data / "LUAD_slides.json").write_text("[]")
        with self.assertRaisesRegex(ValueError, "checksum"):
            ExplorerStore(self.data, self.root)
        (self.root / "configs/explorer_build_v0_1.json").write_text('{"changed":true}')
        with self.assertRaisesRegex(ValueError, "current criteria"):
            ExplorerStore(self.data, self.root)

    def test_duplicate_stable_feature_identifiers_all_excluded(self):
        path = self.root / "source.tsv"
        path.write_text("Hugo_Symbol\tEntrez_Gene_Id\tTCGA-AA-0001-01\nA\t1\t3\nB\t1\t4\nC\t2\tNA\nD\t\t9\n")
        parsed = read_matrix(path)
        self.assertEqual(parsed["ids"], ["2"])
        self.assertEqual(len(parsed["excluded"]), 3)
        self.assertTrue(np.isnan(parsed["values"][0, 0]))

    def test_http_errors_and_read_only_service(self):
        server = ThreadingHTTPServer(("127.0.0.1", 0), handler_for(self.store, ROOT / "web"))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(thread.join, 2)
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        base = f"http://127.0.0.1:{server.server_port}"
        with urlopen(base + "/api/health") as response:
            self.assertEqual(json.load(response)["status"], "ready")
            self.assertIn("frame-ancestors 'none'", response.headers["Content-Security-Policy"])
        for path in ("/api/gene?gene=absent", "/api/specimen?id=outsider"):
            with self.assertRaises(HTTPError) as error:
                urlopen(base + path)
            self.assertEqual(error.exception.code, 400)
        with self.assertRaises(HTTPError) as error:
            urlopen(Request(base + "/api/compare", data=b"[]", headers={"Content-Type": "application/json"}))
        self.assertEqual(error.exception.code, 400)
