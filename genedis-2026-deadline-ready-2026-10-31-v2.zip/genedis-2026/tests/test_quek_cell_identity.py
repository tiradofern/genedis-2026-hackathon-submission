"""Synthetic controls for the frozen cell-identity rule, without program data."""
import copy
import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MODULE = ROOT / "pilot/cellular_2026-10-31/identify_quek_cells.py"
spec = importlib.util.spec_from_file_location("quek_cell_identity", MODULE)
identity = importlib.util.module_from_spec(spec)
spec.loader.exec_module(identity)
PROTOCOL = json.loads((MODULE.parent / "QUEK_CELL_ID_PROTOCOL.json").read_text())


def row(name, library="lib", **changes):
    genes = set(PROTOCOL["primary_lineage_genes"] + ["PTPRC"])
    for name_group in ("T", "B", "myeloid"):
        genes.update(PROTOCOL["confident_immune"][name_group])
    for name_group in ("stromal", "endothelial"):
        genes.update(PROTOCOL["confident_stromal_or_endothelial"][name_group])
    result = dict(cell_id=name, **{"orig.ident":library},count_sum="1000",detected_genes="250",exported_MT_percent="5")
    result.update({g:"0" for g in genes})
    result.update({k:str(v) for k,v in changes.items()})
    return result


def references(n=50, **changes):
    return [row(f"ref{i}",PTPRC=2,CD3D=1,CD3E=1,**changes) for i in range(n)]


class FrozenIdentityTests(unittest.TestCase):
    def test_primary_sensitivity_and_reference_lineage_exclusions(self):
        cells = references()+[
            row("primary",MLANA=2,PMEL=2),
            row("strict",MLANA=2,PMEL=2,DCT=2),
            row("immune",MLANA=2,PMEL=2,PTPRC=2,CD3D=1,CD3E=1),
            row("stroma",MLANA=2,PMEL=2,COL1A1=2,COL1A2=2),
            row("cross_module",MLANA=2,PMEL=2,COL1A1=2,PECAM1=2)]
        masks,_,_=identity.classify_marker_rows(cells,PROTOCOL)
        self.assertEqual([x["quek_primary_putative_malignant"] for x in masks[-5:]],
                         [True,True,False,False,True])
        self.assertFalse(masks[-5]["quek_three_gene_sensitivity"])
        self.assertTrue(masks[-4]["quek_three_gene_sensitivity"])

    def test_ambient_threshold_is_strictly_exceeded(self):
        cells=references(50,MLANA=2,PMEL=2)+[row("equal",MLANA=2,PMEL=2),row("above",MLANA=2,PMEL=3)]
        masks,refs,_=identity.classify_marker_rows(cells,PROTOCOL)
        self.assertAlmostEqual(refs["lib"]["threshold"],.004)
        self.assertFalse(masks[-2]["quek_primary_putative_malignant"])
        self.assertTrue(masks[-1]["quek_primary_putative_malignant"])

    def test_insufficient_reference_is_unassessable_not_negative(self):
        masks,refs,_=identity.classify_marker_rows(references(49)+[row("target",MLANA=4,PMEL=4)],PROTOCOL)
        self.assertEqual(refs["lib"]["reference_cells"],49)
        self.assertIsNone(masks[-1]["quek_primary_putative_malignant"])
        self.assertEqual(masks[-1]["quek_identity_status"],"unassessable_ambient_reference")

    def test_technical_boundaries_and_forbidden_features(self):
        cells=references()+[row("boundary",MLANA=2,PMEL=2,count_sum=500,detected_genes=200,exported_MT_percent=20),
                            row("low",MLANA=2,PMEL=2,count_sum=499)]
        before=copy.deepcopy(cells)
        a,_,_=identity.classify_marker_rows(cells,PROTOCOL)
        self.assertTrue(a[-2]["quek_primary_putative_malignant"])
        self.assertFalse(a[-1]["quek_primary_putative_malignant"])
        changed=copy.deepcopy(cells)
        for r in changed:
            r.update(XIST="ignored",RPS4Y1="ignored",RNA_mia_ID="different",RNA_timepoint="different",RECIST="different",CD274="ignored")
        b,_,genes=identity.classify_marker_rows(changed,PROTOCOL)
        self.assertEqual(a,b)
        self.assertNotIn("XIST",genes)
        self.assertNotIn("CD274",genes)
        self.assertEqual(cells,before)

    def test_invalid_data_and_unfrozen_protocol_fail(self):
        with self.assertRaises(ValueError):
            identity.classify_marker_rows([row("duplicate"),row("duplicate")],PROTOCOL)
        with self.assertRaises(ValueError):
            identity.classify_marker_rows([row("bad",MLANA="nan")],PROTOCOL)
        with self.assertRaises(ValueError):
            identity.classify_marker_rows([row("bad",MLANA=800,PMEL=800)],PROTOCOL)
        changed=copy.deepcopy(PROTOCOL);changed["status"]="draft"
        with self.assertRaises(ValueError):
            identity.classify_marker_rows([row("one")],changed)


if __name__ == "__main__":
    unittest.main()
