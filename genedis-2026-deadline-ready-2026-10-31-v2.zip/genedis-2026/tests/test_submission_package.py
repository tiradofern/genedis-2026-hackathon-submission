"""Hermetic v2 archive guards using a disposable Git repository and fake results."""
import copy
import csv
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "submission"))
import build_archive as builder
import verify_archive as verifier


class SubmissionPackageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="genedis-package-fixture-")
        self.base = Path(self.temp.name)
        self.repo = self.base / "repo"
        self.repo.mkdir()
        self.rules = json.loads((ROOT / "submission/package_allowlist.json").read_text())
        content = {name:b"synthetic reviewer artifact\n" for name in builder.V2_REQUIRED}
        # Public gene definitions are fixtures; no study expression/results are read.
        for name in ("h.all.v2024.1.Hs.symbols.gmt", "h.all.v2024.1.Hs.json"):
            path="pilot/programs/sources/"+name
            content[path]=(ROOT/path).read_bytes()
        input_path=builder.CELLULAR+"FROZEN_PRIMARY_RNA_INPUT_MANIFEST.json"
        content[input_path]=b"{}\n"
        protocol={"programs":{"family_size":50,"gmt_sha256":hashlib.sha256(content["pilot/programs/sources/h.all.v2024.1.Hs.symbols.gmt"]).hexdigest()},
                  "input_manifest":{"path":input_path,"sha256":hashlib.sha256(content[input_path]).hexdigest()}}
        protocol_path=builder.CELLULAR+"RNA_MEASUREMENT_PROTOCOL.json"
        content[protocol_path]=json.dumps(protocol).encode()
        gate={"protocol_sha256":hashlib.sha256(content[protocol_path]).hexdigest(),"primary_nomination_enabled":False,
              "complete_primary_discovery_validation_claim_gate":"HOLD_INCONCLUSIVE"}
        content[builder.CELLULAR+"RNA_EXECUTION_GATE.json"]=json.dumps(gate).encode()
        content[builder.CELLULAR+"NSCLC_COMPONENT_EXECUTION_GATE.json"]=json.dumps({"decision":"HOLD","stage":"NOT_REACHED"}).encode()
        content["submission/package_allowlist.json"]=json.dumps(self.rules).encode()
        for name,data in content.items():
            path=self.repo/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
        subprocess.run(["git","init","-q",str(self.repo)],check=True)
        self.commit()

    def tearDown(self):
        self.temp.cleanup()

    def commit(self):
        subprocess.run(["git","add","-A"],cwd=self.repo,check=True)
        subprocess.run(["git","-c","user.name=Fixture","-c","user.email=fixture@example.invalid",
                        "-c","commit.gpgsign=false","commit","-qm","synthetic fixture"],cwd=self.repo,check=True)

    def build(self,path):
        with patch.object(builder,"ROOT",self.repo):
            return builder.build(path)

    def test_clean_committed_archive_is_deterministic_and_has_bound_evidence(self):
        a=self.base/"a.zip";b=self.base/"b.zip"
        result=self.build(a);self.build(b)
        self.assertEqual(a.read_bytes(),b.read_bytes())
        self.assertFalse(result["source_tree_dirty"])
        self.assertEqual(verifier.verify(a)["status"],"passed")
        with zipfile.ZipFile(a) as archive:
            self.assertTrue(all(x.create_system==3 for x in archive.infolist()))
            manifest=json.loads(archive.read(builder.PREFIX+"/PACKAGE_MANIFEST.json"))
        self.assertEqual(manifest["package_version"],builder.VERSION)
        self.assertEqual(set(manifest["required_artifact_sha256"]),builder.V2_REQUIRED)

    def test_dirty_tracked_and_untracked_sources_cannot_be_packaged(self):
        target=self.base/"blocked.zip"
        (self.repo/"README.md").write_text("uncommitted change")
        with self.assertRaisesRegex(ValueError,"clean committed"):
            self.build(target)
        subprocess.run(["git","restore","README.md"],cwd=self.repo,check=True)
        (self.repo/"untracked-private-note.txt").write_text("private fixture")
        with self.assertRaisesRegex(ValueError,"clean committed"):
            self.build(target)
        self.assertFalse(target.exists())

    def test_missing_committed_current_evidence_blocks_build(self):
        (self.repo/(builder.CELLULAR+"results/quek_three_gene_full_result.json")).unlink()
        self.commit()
        with self.assertRaisesRegex(ValueError,"Missing required reviewer evidence"):
            self.build(self.base/"missing.zip")

    def test_existing_archive_is_never_overwritten(self):
        target=self.base/"existing.zip";target.write_bytes(b"previous archive")
        with self.assertRaisesRegex(ValueError,"Preserve existing"):
            self.build(target)
        self.assertEqual(target.read_bytes(),b"previous archive")

    def test_private_paths_remain_disallowed_under_relaxed_declared_rules(self):
        rules=copy.deepcopy(self.rules);rules["roots"] += ["data",".venv-other"]
        for name in ("data/external/source.csv","submission/GMAIL_DRAFT_RECEIPT.json",
                     "docs/.env.example","src/.ssh/id_rsa","docs/new\nline.md",".venv-other/metadata.json"):
            with self.subTest(name=name):
                self.assertFalse(builder.eligible(name,rules))

    def test_self_consistent_archive_cannot_omit_mandatory_current_results(self):
        archive=self.base/"valid.zip";self.build(archive)
        with zipfile.ZipFile(archive) as z:
            payload={name[len(builder.PREFIX)+1:]:z.read(name) for name in z.namelist()}
        missing=builder.CELLULAR+"results/primary_full_result.json"
        del payload[missing]
        rules=json.loads(payload["submission/package_allowlist.json"])
        rules["required_files"].remove(missing)
        payload["submission/package_allowlist.json"]=json.dumps(rules).encode()
        manifest=json.loads(payload["PACKAGE_MANIFEST.json"])
        names=sorted(set(payload)-{"PACKAGE_MANIFEST.json","SHA256SUMS.tsv"})
        manifest["files"]=[{"path":n,"bytes":len(payload[n]),"sha256":hashlib.sha256(payload[n]).hexdigest()} for n in names]
        manifest["file_count"]=len(names)
        manifest["required_artifact_sha256"].pop(missing)
        payload["PACKAGE_MANIFEST.json"]=json.dumps(manifest).encode()
        payload["SHA256SUMS.tsv"]=("path\tsha256\n"+"".join(n+"\t"+hashlib.sha256(payload[n]).hexdigest()+"\n" for n in sorted(set(payload)-{"SHA256SUMS.tsv"}))).encode()
        bad=self.base/"missing-self-consistent.zip"
        with zipfile.ZipFile(bad,"w") as z:
            for name,data in payload.items():
                info=zipfile.ZipInfo(builder.PREFIX+"/"+name);info.create_system=3;info.external_attr=0o100644<<16
                z.writestr(info,data)
        with self.assertRaisesRegex(ValueError,"Missing required reviewer"):
            verifier.verify(bad)


if __name__ == "__main__":
    unittest.main()
