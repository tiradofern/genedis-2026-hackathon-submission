"""Synthetic mathematical tests; no biological files or expression results."""
import sys
import unittest
import json
from pathlib import Path

import numpy as np
from scipy import sparse

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "pilot" / "cellular_2026-10-31"))
from rna_coordination import (
    RNACase, by_adjust, deterministic_cells, matched_gene_strata,
    mean_offdiagonal_correlation, run_rna_coordination,
    shared_gene_permutation, standardized_rank_residuals,
)


def fixture(patient="p1", cancer="c1", seed=17):
    rng = np.random.default_rng(seed)
    counts = rng.integers(10, 41, size=(70, 61)).astype(float)
    factor = rng.integers(10, 41, size=70)
    counts[:, :10] = factor[:, None]
    counts[:, -1] = 10000 - counts[:, :-1].sum(axis=1)
    return RNACase(patient, cancer, counts, [f"g{i}" for i in range(61)],
                   [f"cell{i}" for i in range(70)])


def run(cases, programs=None, **kw):
    if programs is None:
        programs = {"planted": [f"g{i}" for i in range(10)]}
    options = dict(permutations=99, expected_family_size=len(programs),
                   minimum_activity_fraction=.8, minimum_activity_genes=5,
                   minimum_coordination_genes=5, maximum_cells=60,
                   excluded_identity_genes=["g60"])
    options.update(kw)
    return run_rna_coordination(cases, programs, **options)


class CoordinationMathTests(unittest.TestCase):
    def test_fast_identity_matches_explicit_correlation(self):
        rng = np.random.default_rng(13)
        z, variable, rank, df = standardized_rank_residuals(rng.normal(size=(35, 9)), rng.normal(size=(35, 2)))
        self.assertTrue(variable.all())
        corr = z @ z.T
        expected = (corr.sum() - np.trace(corr)) / (9 * 8)
        self.assertAlmostEqual(mean_offdiagonal_correlation(z), expected, places=13)
        self.assertEqual(rank, 3)
        self.assertEqual(df, 32)

    def test_zero_variance_and_unidentifiable_design_do_not_pass(self):
        z, variable, _, _ = standardized_rank_residuals(np.ones((10, 8)), np.ones((10, 2)))
        self.assertFalse(variable.any())
        z, variable, _, df = standardized_rank_residuals(np.ones((2, 8)), np.arange(2)[:, None])
        self.assertIsNone(z)
        self.assertLess(df, 2)

    def test_shared_bijection_preserves_program_sizes_overlap_and_strata(self):
        a = np.array([[.1, .2, .3, .4, .6, .8], [.1, .2, .3, .4, .6, .8]])
        groups, _ = matched_gene_strata(a, a, bins=2)
        permutation = shared_gene_permutation(groups, 6, np.random.default_rng(6))
        self.assertEqual(sorted(permutation.tolist()), list(range(6)))
        left, right = np.array([0, 1, 4]), np.array([1, 3, 4])
        self.assertEqual(len(set(permutation[left]) & set(permutation[right])), 2)
        for g in groups:
            self.assertEqual(set(permutation[g]), set(g))

    def test_hash_selection_is_order_invariant(self):
        ids = [f"c{i}" for i in range(20)]
        chosen = {ids[i] for i in deterministic_cells(ids, "p", 8)}
        reverse = ids[::-1]
        self.assertEqual(chosen, {reverse[i] for i in deterministic_cells(reverse, "p", 8)})

    def test_by_includes_unassessable_hypotheses(self):
        np.testing.assert_allclose(by_adjust([.01, .2, 1.]), [.055, .55, 1.])


class CompleteEngineTests(unittest.TestCase):
    def test_planted_statistic_exceeds_fixed_independent_gene_control(self):
        programs = {"planted": [f"g{i}" for i in range(10)],
                    "control": [f"g{i}" for i in range(10, 30)]}
        result = run([fixture()], programs, permutations=39)
        planted, control = result["programs"]
        self.assertGreater(planted["patients"][0]["coordination"],
                           control["patients"][0]["coordination"] + .5)

    def test_default_testing_family_cannot_be_silently_reduced(self):
        with self.assertRaisesRegex(ValueError, "testing family"):
            run_rna_coordination([fixture()], {"one": [f"g{i}" for i in range(20)]})

    def test_planted_coordination_and_independent_patients(self):
        result = run([fixture(), fixture("p2", "c2", 18)])
        row = result["programs"][0]
        self.assertEqual(result["patient_count"], 2)
        self.assertEqual(result["cancer_types"], ["c1", "c2"])
        self.assertEqual(result["permutations_completed"], 99)
        for p in row["patients"]:
            self.assertAlmostEqual(p["coordination"], 1., places=12)
            self.assertGreater(p["null_excess"], .4)
            self.assertLessEqual(p["conditional_p"], .03)
        self.assertEqual(row["conditional_pmax"], max(x["conditional_p"] for x in row["patients"]))

    def test_sparse_dense_and_batch_sizes_agree(self):
        case = fixture()
        dense = run([case], return_null=True, permutations=23, batch_size=1)
        case.counts = sparse.csr_matrix(case.counts)
        other = run([case], return_null=True, permutations=23, batch_size=8)
        np.testing.assert_allclose(dense["null_statistics"], other["null_statistics"], atol=1e-12)
        self.assertAlmostEqual(dense["programs"][0]["patients"][0]["activity"],
                               other["programs"][0]["patients"][0]["activity"])

    def test_missing_genes_remain_unassessable_and_corrected(self):
        programs = {"planted": [f"g{i}" for i in range(10)], "missing": ["absent"] * 1}
        result = run([fixture()], programs)
        row = result["programs"][1]
        self.assertFalse(row["coordination_assessable"])
        self.assertEqual(row["conditional_pmax"], 1.)
        self.assertEqual(row["conditional_by_q"], 1.)
        self.assertIsNone(row["patients"][0]["activity"])
        self.assertIsNone(row["patients"][0]["coordination"])

    def test_repeated_patient_duplicate_cells_and_nan_are_rejected(self):
        with self.assertRaises(ValueError):
            run([fixture(), fixture()])
        case = fixture()
        case.cell_ids[1] = case.cell_ids[0]
        with self.assertRaises(ValueError):
            run([case])
        case = fixture()
        case.counts[0, 0] = np.nan
        with self.assertRaises(ValueError):
            run([case])

    def test_common_variable_membership_and_all_constant_case(self):
        case = fixture("p2", "c2")
        case.counts[:, 0] = 20
        case.counts[:, -1] = 10000 - case.counts[:, :-1].sum(axis=1)
        result = run([fixture(), case])
        self.assertNotIn("g0", result["coordination_universe"])
        self.assertNotIn("g0", result["programs"][0]["coordination_members"])
        case.counts[:] = 1
        result = run([case])
        self.assertFalse(result["programs"][0]["coordination_assessable"])
        self.assertEqual(result["programs"][0]["conditional_pmax"], 1.)
        self.assertEqual(result["permutations_completed"], 0)

    def test_global_full_universe_set_is_a_tied_null_not_a_discovery(self):
        programs = {"all": [f"g{i}" for i in range(60)]}
        result = run([fixture()], programs, permutations=39)
        self.assertEqual(result["programs"][0]["conditional_pmax"], 1.)
        self.assertEqual(result["programs"][0]["conditional_by_q"], 1.)

    def test_partial_genes_do_not_become_zero_expression(self):
        programs = {"partial": ["g0", "g1", "absent"]}
        result = run([fixture()], programs, minimum_activity_genes=1,
                     minimum_coordination_genes=2, minimum_activity_fraction=.9)
        row = result["programs"][0]
        self.assertEqual(row["activity_coverage"], 2 / 3)
        self.assertIsNone(row["patients"][0]["activity"])
        self.assertEqual(row["conditional_pmax"], 1.)

    def test_results_are_json_serializable_and_full_permutation_is_reproducible(self):
        first = run([fixture()], permutations=19, batch_size=3)
        second = run([fixture()], permutations=19, batch_size=7)
        json.dumps(first, allow_nan=False)
        self.assertEqual(first["programs"], second["programs"])
        self.assertEqual(first["matching_strata_gene_ids"], second["matching_strata_gene_ids"])

    def test_negative_duplicate_sparse_entries_cannot_cancel_to_pass(self):
        case = fixture()
        row, col = np.nonzero(case.counts)
        data = case.counts[row, col]
        case.counts = sparse.coo_matrix((np.r_[data, -1.], (np.r_[row, 0], np.r_[col, 0])), shape=case.counts.shape)
        with self.assertRaisesRegex(ValueError, "Stored sparse"):
            run([case])


if __name__ == "__main__":
    unittest.main()
