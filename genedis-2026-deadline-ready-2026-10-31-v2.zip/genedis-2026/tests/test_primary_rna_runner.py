"""Synthetic fail-closed tests; never load or execute real cohort effects."""
import csv
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from scipy import sparse

SCRIPT = Path(__file__).resolve().parents[1] / 'pilot/cellular_2026-10-31/run_primary_rna.py'
SPEC = importlib.util.spec_from_file_location('run_primary_rna', SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class PrimaryRNARunnerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='synthetic-primary-runner-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.protocol_path, self.gate_path = self.root/'protocol.json', self.root/'gate.json'
        genes = ['MT-CO1'] + [f'G{i}' for i in range(219)]
        receipts = []
        for cohort, cancer in [('toyA','MCC'),('toyB','melanoma')]:
            matrix_path = self.root/f'{cohort}_counts.npz'
            gene_path, cell_path = self.root/f'{cohort}_genes.json', self.root/f'{cohort}_cells.csv'
            sparse.save_npz(matrix_path, sparse.csr_matrix(np.full((8,220),3,dtype=np.uint32)))
            gene_path.write_text(json.dumps(genes))
            rows = [{'cell_id':f'{cohort}:c{k}','patient_id':cohort+':p','cancer':cancer,
                     'UMI':660,'detected_genes':220,'MT_UMI':3,'MT_percent':100*3/660,
                     'technical_QC_pass':'True'} for k in range(8)]
            with cell_path.open('w',newline='') as handle:
                writer=csv.DictWriter(handle,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
            receipts.append({'cohort':cohort,'status':'STRUCTURAL_INGEST_ONLY_NO_PROGRAM_SCORES',
                'all_source_values_validated':True,'patients':[cohort+':p'],
                'inputs':[{'path':str(gene_path),'bytes':gene_path.stat().st_size,'sha256':MODULE.sha256(gene_path)}],
                'output_shape_cells_by_genes':[8,220],'output_nnz':8*220,'technical_QC_pass_cells':8,
                'outputs':[{'path':str(p),'bytes':p.stat().st_size,'sha256':MODULE.sha256(p)}
                           for p in (matrix_path,gene_path,cell_path)]})
        self.manifest_path=self.root/'manifest.json'
        self.manifest_path.write_text(json.dumps({'status':'STRUCTURAL_INPUTS_NO_PROGRAM_SCORES','cohorts':receipts}))
        self.gmt_path=self.root/'programs.gmt'
        self.gmt_path.write_text('\n'.join('\t'.join([f'P{k}','synthetic']+genes[1:21]) for k in range(50))+'\n')
        programs=MODULE.parse_gmt(self.gmt_path.read_text())
        parameters={name:value.default for name,value in inspect.signature(MODULE.run_rna_coordination).parameters.items()
                    if name not in {'datasets','programs','excluded_identity_genes','return_null'}}
        parameters.update(permutations=3,maximum_cells=8)
        self.protocol={'analysis_id':MODULE.ANALYSIS_ID,'status':'FROZEN_BEFORE_REAL_PROGRAM_EFFECTS',
            'input_manifest':{'path':str(self.manifest_path),'sha256':MODULE.sha256(self.manifest_path)},
            'cohort_ids':['toyA','toyB'],'cohort_cancer_types':{'toyA':'MCC','toyB':'melanoma'},
            'programs':{'gmt_path':str(self.gmt_path),'gmt_sha256':MODULE.sha256(self.gmt_path),
                        'members_sha256':MODULE.members_hash(programs),'family_size':50},
            'engine_parameters':parameters,'excluded_identity_genes':[],
            'primary_nomination_enabled':False,'limitations':['Synthetic fixture; no biological inference.']}
        artifacts = [SCRIPT, SCRIPT.parent/'rna_coordination.py', SCRIPT.parent/'program_scores.py']
        for name in ('MEASUREMENT_PROTOCOL.md','INDEPENDENT_EXECUTION_REVIEW.md'):
            path=self.root/name;path.write_text('Synthetic frozen scientific review.\n');artifacts.append(path)
        self.protocol['execution_artifacts']={str(path):MODULE.sha256(path) for path in artifacts}
        self.freeze()

    def freeze(self):
        self.protocol_path.write_text(json.dumps(self.protocol,sort_keys=True))
        self.gate_path.write_text(json.dumps({'analysis_id':MODULE.ANALYSIS_ID,
            'decision':'GO_DESCRIPTIVE_CONDITIONAL','protocol_sha256':MODULE.sha256(self.protocol_path)}))

    def test_full_family_outputs_and_explicit_no_nomination(self):
        files=MODULE.run(self.protocol_path,self.gate_path,self.root/'out')
        result=json.loads(files[0].read_text())
        self.assertEqual(len(result['programs']),50)
        self.assertFalse(result['primary_nomination_enabled'])
        with (self.root/'out/primary_all_programs_by_patient.csv').open() as handle:
            self.assertEqual(len(list(csv.DictReader(handle))),100)
        with (self.root/'out/primary_conditional_by_family.csv').open() as handle:
            self.assertEqual(len(list(csv.DictReader(handle))),50)
        self.assertTrue(all(p['conditional_by_q']==1 for p in result['programs']))

    def test_missing_or_changed_gate_prevents_any_engine_call(self):
        for gate in [{'decision':'HOLD'}, {'decision':'GO_DESCRIPTIVE_CONDITIONAL',
                'analysis_id':MODULE.ANALYSIS_ID,'protocol_sha256':'0'*64}]:
            self.gate_path.write_text(json.dumps(gate))
            with patch.object(MODULE,'run_rna_coordination') as engine:
                with self.assertRaises(ValueError):
                    MODULE.run(self.protocol_path,self.gate_path,self.root/'out')
                engine.assert_not_called()

    def test_existing_nonempty_output_is_rejected_before_effects(self):
        output=self.root/'out';output.mkdir();(output/'prior.txt').write_text('preserve me')
        real=MODULE.run_rna_coordination
        with patch.object(MODULE,'run_rna_coordination',autospec=real) as engine:
            with self.assertRaisesRegex(ValueError,'existing nonempty output'):
                MODULE.run(self.protocol_path,self.gate_path,output)
            engine.assert_not_called()
        self.assertEqual((output/'prior.txt').read_text(),'preserve me')

    def test_code_artifact_change_blocks_assay_loading(self):
        key=next(path for path in self.protocol['execution_artifacts'] if Path(path).name=='MEASUREMENT_PROTOCOL.md')
        Path(key).write_text('Changed scientific protocol.')
        with patch.object(MODULE,'prepare_inputs') as prepare:
            with self.assertRaisesRegex(ValueError,'SHA256 mismatch'):
                MODULE.run(self.protocol_path,self.gate_path,self.root/'out')
            prepare.assert_not_called()

    def test_tampered_hashed_matrix_is_rejected(self):
        matrix=self.root/'toyA_counts.npz'
        matrix.write_bytes(matrix.read_bytes()+b'changed')
        with self.assertRaisesRegex(ValueError,'SHA256 mismatch'):
            MODULE.run(self.protocol_path,self.gate_path,self.root/'out')

    def test_cell_qc_is_recomputed_even_if_tampered_metadata_is_rehashed(self):
        cell=self.root/'toyA_cells.csv'
        text=cell.read_text().replace(',660,',',661,',1);cell.write_text(text)
        manifest=json.loads(self.manifest_path.read_text())
        target=next(x for x in manifest['cohorts'][0]['outputs'] if x['path']==str(cell))
        target.update(bytes=cell.stat().st_size,sha256=MODULE.sha256(cell))
        self.manifest_path.write_text(json.dumps(manifest))
        self.protocol['input_manifest']['sha256']=MODULE.sha256(self.manifest_path);self.freeze()
        with self.assertRaisesRegex(ValueError,'Actual full-library'):
            MODULE.run(self.protocol_path,self.gate_path,self.root/'out')

    def test_nomination_and_program_membership_changes_fail_closed(self):
        self.protocol['primary_nomination_enabled']=True;self.freeze()
        with self.assertRaisesRegex(ValueError,'nomination must remain disabled'):
            MODULE.run(self.protocol_path,self.gate_path,self.root/'out')
        self.protocol['primary_nomination_enabled']=False
        self.protocol['programs']['members_sha256']='0'*64;self.freeze()
        with self.assertRaisesRegex(ValueError,'Program membership'):
            MODULE.run(self.protocol_path,self.gate_path,self.root/'out')

    def test_invalid_sensitivity_rejected_before_primary_effects(self):
        self.protocol['sensitivity']={'name':'strict','cell_mask_path':str(self.root/'missing.csv'),
            'cell_mask_sha256':'0'*64,'column':'strict','cohort_id':'toyB'}
        self.freeze()
        # Patching engine also changes introspection; preserve its exact signature.
        real=MODULE.run_rna_coordination
        with patch.object(MODULE,'run_rna_coordination',autospec=real) as engine:
            with self.assertRaisesRegex(ValueError,'Missing file'):
                MODULE.run(self.protocol_path,self.gate_path,self.root/'out')
            engine.assert_not_called()

    def test_fixed_sensitivity_remains_a_subset_and_retains_all_programs(self):
        mask=self.root/'mask.csv'
        mask.write_text('cell_id,strict\n'+'\n'.join(f'toyB:c{k},{k<5}' for k in range(8))+'\n')
        self.protocol['sensitivity']={'name':'strict','cell_mask_path':str(mask),
            'cell_mask_sha256':MODULE.sha256(mask),'column':'strict','cohort_id':'toyB'}
        self.freeze()
        files=MODULE.run(self.protocol_path,self.gate_path,self.root/'out')
        self.assertEqual(len(files),2)
        result=json.loads(files[1].read_text())
        self.assertEqual([p['all_cells'] for p in result['patients']],[8,5])
        self.assertEqual(len(result['programs']),50)


if __name__=='__main__':
    unittest.main()
