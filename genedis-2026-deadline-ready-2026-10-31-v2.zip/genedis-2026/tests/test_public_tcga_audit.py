"""Integrity and missing-data safeguards for the new public-data audit."""
import tempfile
import unittest
from pathlib import Path

from scripts.audit_public_tcga import (
    case_ids, is_missing, matrix_audit, mutation_audit, parse_pointer,
    read_table, retrieve, sample_key, unique_rows,
)


class PublicTCGAAuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)

    def fixture(self, text):
        path = self.folder / "fixture.tsv"
        path.write_text(text, encoding="utf-8")
        return path

    def test_lfs_pointer_validated_not_mistaken_for_actual_matrix(self):
        digest, size = parse_pointer(("version https://git-lfs.github.com/spec/v1\n"
                                     "oid sha256:" + "a" * 64 + "\nsize 123\n").encode())
        self.assertEqual((digest, size), ("a" * 64, 123))
        with self.assertRaises(ValueError):
            parse_pointer(b"Hugo_Symbol\tTCGA-AA-0001-01\n")

    def test_missing_outcome_is_distinct_from_zero(self):
        self.assertTrue(is_missing("[Not Available]"))
        self.assertTrue(is_missing("NaN"))
        self.assertFalse(is_missing("0"))
        self.assertFalse(is_missing("0:LIVING"))

    def test_sample_key_explicitly_collapses_different_vials(self):
        first = sample_key("TCGA-AA-0001-01A-11D-0000-01")
        second = sample_key("TCGA-AA-0001-01B-11R-0000-01")
        self.assertEqual(first, second)
        self.assertNotEqual(first, sample_key("TCGA-AA-0001-11A"))
        with self.assertRaises(ValueError):
            sample_key("patient-1")

    def test_clinical_comments_and_duplicate_identifiers(self):
        columns, rows = read_table(self.fixture("# labels\nPATIENT_ID\tOS_MONTHS\nP1\tNA\nP1\t0\n"))
        self.assertEqual(columns, ["PATIENT_ID", "OS_MONTHS"])
        with self.assertRaises(ValueError):
            unique_rows(rows, "PATIENT_ID")

    def test_ragged_clinical_table_fails(self):
        with self.assertRaises(ValueError):
            read_table(self.fixture("PATIENT_ID\tSTAGE\nP1\n"))

    def test_matrix_missing_is_not_zero_and_negative_rsem_fails(self):
        result = matrix_audit(self.fixture(
            "Hugo_Symbol\tEntrez_Gene_Id\tTCGA-AA-0001-01\tTCGA-AA-0002-01\n"
            "A\t1\t0\tNA\nB\t2\t-1\t2\n"), "rna")
        self.assertEqual(result["cells"]["missing"], 1)
        self.assertEqual(result["cells"]["zero"], 1)
        self.assertFalse(result["structural_numeric_checks_passed"])

    def test_duplicate_sample_or_invalid_cna_cannot_pass(self):
        with self.assertRaises(ValueError):
            matrix_audit(self.fixture(
                "Hugo_Symbol\tTCGA-AA-0001-01\tTCGA-AA-0001-01\nA\t1\t2\n"), "rna")
        result = matrix_audit(self.fixture(
            "Hugo_Symbol\tTCGA-AA-0001-01\nA\t3\n"), "cna")
        self.assertFalse(result["structural_numeric_checks_passed"])

    def test_nonfinite_and_ragged_matrices_cannot_pass(self):
        result = matrix_audit(self.fixture(
            "Hugo_Symbol\tTCGA-AA-0001-01\nA\tinf\nB\t1\t2\n"), "rna")
        self.assertEqual(result["cells"]["nonfinite"], 1)
        self.assertEqual(result["malformed_rows"], 1)
        self.assertFalse(result["structural_numeric_checks_passed"])

    def test_mutation_table_keeps_full_barcode_and_event_counts(self):
        result = mutation_audit(self.fixture(
            "Hugo_Symbol\tTumor_Sample_Barcode\tVariant_Classification\tNCBI_Build\n"
            "G1\tTCGA-AA-0001-01A\tMissense_Mutation\tGRCh37\n"
            "G2\tTCGA-AA-0001-01A\tNonsense_Mutation\tGRCh37\n"))
        self.assertEqual(result["records_by_sample"], {"TCGA-AA-0001-01": 2})
        self.assertEqual(result["full_barcodes"], ["TCGA-AA-0001-01A"])
        self.assertNotIn("TCGA-AA-0002-01", result["records_by_sample"])

    def test_duplicate_profile_list_fails(self):
        with self.assertRaises(ValueError):
            case_ids(self.fixture("case_list_ids: TCGA-AA-0001-01\tTCGA-AA-0001-01\n"))

    def test_cached_source_corruption_cannot_pass(self):
        path = self.fixture("corrupted source")
        with self.assertRaises(ValueError):
            retrieve("https://example.invalid/never-requested", path, 1000, False,
                     expected_hash="0" * 64)
        with self.assertRaises(ValueError):
            retrieve("https://example.invalid/never-requested", path, 1000, False,
                     expected_size=1)


if __name__ == "__main__":
    unittest.main()
