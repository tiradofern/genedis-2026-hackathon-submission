"""Fictional parser fixtures only; never used for scientific outputs."""
import gzip
import importlib.util
import tempfile
import unittest
from pathlib import Path

spec = importlib.util.spec_from_file_location("audit", Path(__file__).parents[1] / "scripts/audit_metadata.py")
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


class IntegrityTests(unittest.TestCase):
    def matrix(self, text, **kwargs):
        scratch = Path(__file__).parents[1] / "work" / "test-scratch"
        scratch.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=scratch) as tmp:
            if not Path(tmp).resolve().is_relative_to(scratch.resolve()):
                raise ValueError("Test temporary directory escaped scratch root")
            path = Path(tmp) / "fictional.txt.gz"
            with gzip.open(path, "wt") as f:
                f.write(text)
            return audit.matrix_integrity(path, **kwargs)

    def test_thousands_and_trailing_empty_column(self):
        r = self.matrix("Gene\tModelA\tModelB\t\ng1\t1,234.56\t0\t\n", thousands=True)
        self.assertEqual(r["samples"], 2)
        self.assertEqual(r["thousands_separator_cells"], 1)
        self.assertEqual(r["maximum"], 1234.56)

    def test_invalid_grouping_is_rejected(self):
        with self.assertRaises(ValueError):
            self.matrix("Gene\tA\ng1\t1,23.4\n", thousands=True)

    def test_column_width_is_rejected(self):
        with self.assertRaises(ValueError):
            self.matrix("Gene\tA\tB\ng1\t4\n")

    def test_duplicate_columns_are_rejected(self):
        with self.assertRaises(ValueError):
            self.matrix("Gene\tA\tA\ng1\t4\t5\n")

    def test_late_added_geo_sample_is_preserved(self):
        metadata = {"!Sample_geo_accession": [["GSM_FAKE1", "GSM_FAKE2"]],
                    "!Sample_title": [["first", "late added"]],
                    "!Sample_characteristics_ch1": [["timepoint: Pre", "timepoint: Post"]]}
        r = audit.geo_samples(metadata)
        self.assertEqual(r[1]["gsm"], "GSM_FAKE2")
        self.assertEqual(r[1]["timepoint"], "Post")

    def test_mismatched_metadata_width_is_rejected(self):
        metadata = {"!Sample_geo_accession": [["GSM_FAKE1", "GSM_FAKE2"]],
                    "!Sample_title": [["first", "second"]],
                    "!Sample_characteristics_ch1": [["timepoint: Pre"]]}
        with self.assertRaises(ValueError):
            audit.geo_samples(metadata)

    def test_matrix_markers(self):
        r = self.matrix('!Series_title\t"fixture"\n!series_matrix_table_begin\n"ID_REF"\t"GSM_FAKE1"\n"g1"\t4.5\n!series_matrix_table_end\n', series_matrix=True)
        self.assertEqual(r["features"], 1)
        self.assertEqual(r["sample_ids"], ["GSM_FAKE1"])


if __name__ == "__main__":
    unittest.main()
