"""Analytical, synthetic-only tests for bounded cellular numerical utilities."""
import sys
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "pilot" / "cellular_2026-10-31"))
from program_scores import (
    aggregate_cells_by_specimen, aggregate_specimens_by_patient,
    cell_cpm, mean_cell_cpm, parse_gmt, rank_program_scores,
)


class ProgramDefinitionTests(unittest.TestCase):
    def test_gmt_preserves_exact_ids_and_allows_overlap_between_programs(self):
        programs = parse_gmt("P1\turl1\tA\tB\nP2\turl2\tB\tC\n")
        self.assertEqual(programs, {"P1": ("A", "B"), "P2": ("B", "C")})

    def test_gmt_rejects_duplicate_or_ambiguous_identifiers(self):
        for text in (
            "P\tu\tA\tA", "P\tu\tA\nP\tu\tB", "P\tu\tA\t",
            "P\tu\t A", "P\tu\tA B", "\tu\tA", "P\tu", "\n",
        ):
            with self.subTest(text=text), self.assertRaises(ValueError):
                parse_gmt(text)


class RankScoreTests(unittest.TestCase):
    def score(self, values, genes, programs, universe, *, fraction=1., count=1):
        return rank_program_scores(
            values, genes, programs, universe,
            minimum_coverage_fraction=fraction, minimum_measured_genes=count,
        )

    def test_hand_calculated_ranks_and_average_ties(self):
        result = self.score(
            [[0., 2., 2., 9.], [5., 5., 5., 5.]],
            ["A", "B", "C", "D"], {"low": ["A", "B"], "high": ["C", "D"]},
            ["A", "B", "C", "D"],
        )
        # Ranks 1,2.5,2.5,4 give normalized scores -.5,0,0,.5.
        np.testing.assert_allclose(result.scores["low"], [-.25, 0.])
        np.testing.assert_allclose(result.scores["high"], [.25, 0.])

    def test_gene_column_universe_and_program_order_do_not_change_scores(self):
        original = self.score([[2., 7., 0.]], ["A", "B", "C"],
                              {"P": ["A", "B"]}, ["A", "B", "C"])
        permuted = self.score([[0., 2., 7.]], ["C", "A", "B"],
                              {"P": ["B", "A"]}, ["C", "B", "A"])
        np.testing.assert_array_equal(original.scores["P"], permuted.scores["P"])

    def test_missing_program_genes_are_not_imputed_as_zero(self):
        result = self.score([[1., 9.]], ["A", "B"],
                            {"partial": ["B", "absent"], "none": ["absent"]},
                            ["A", "B"], fraction=.5)
        np.testing.assert_array_equal(result.scores["partial"], [.5])
        self.assertEqual(result.coverage["partial"].measured_genes, ("B",))
        self.assertEqual(result.coverage["partial"].fraction, .5)
        self.assertFalse(result.coverage["none"].eligible)
        self.assertTrue(np.isnan(result.scores["none"]).all())
        strict = self.score([[1., 9.]], ["A", "B"], {"partial": ["B", "absent"]},
                            ["A", "B"], fraction=.75)
        self.assertTrue(np.isnan(strict.scores["partial"]).all())

    def test_explicit_universe_excludes_other_expression_columns(self):
        result = self.score([[1., 2., 1000.]], ["A", "B", "outside"],
                            {"P": ["B"]}, ["A", "B"])
        np.testing.assert_array_equal(result.scores["P"], [.5])

    def test_invalid_mapping_universe_values_and_policy_are_rejected(self):
        examples = [
            ([[1., 2.]], ["A", "A"], {"P": ["A"]}, ["A", "B"], 1., 1),
            ([[1., 2.]], ["A", "B"], {"P": ["A", "A"]}, ["A", "B"], 1., 1),
            ([[1., 2.]], "AB", {"P": ["A"]}, ["A", "B"], 1., 1),
            ([[1., 2.]], ["A", "B"], {"P": "AB"}, ["A", "B"], 1., 1),
            ([[1., 2.]], ["A", "B"], {"P": ["A"]}, ["A", "A"], 1., 1),
            ([[1., 2.]], ["A", "B"], {"P": ["A"]}, ["A", "missing"], 1., 1),
            ([[1., 2.]], ["A", "B"], {"P": []}, ["A", "B"], 1., 1),
            ([[1., np.nan]], ["A", "B"], {"P": ["A"]}, ["A", "B"], 1., 1),
            ([[1., np.inf]], ["A", "B"], {"P": ["A"]}, ["A", "B"], 1., 1),
            ([[1., 2.]], ["A", "B"], {"P": ["A"]}, ["A"], 1., 1),
            ([[1., 2.]], ["A", "B"], {"P": ["A"]}, ["A", "B"], 1.1, 1),
            ([[1., 2.]], ["A", "B"], {"P": ["A"]}, ["A", "B"], 1., 0),
        ]
        for values, genes, programs, universe, fraction, count in examples:
            with self.subTest(example=(values, genes, programs, universe, fraction, count)):
                with self.assertRaises(ValueError):
                    self.score(values, genes, programs, universe, fraction=fraction, count=count)


class LibraryNormalizationTests(unittest.TestCase):
    def test_equal_cell_cpm_differs_from_summed_library_weighting(self):
        counts = [[1., 0.], [0., 9.]]
        np.testing.assert_array_equal(cell_cpm(counts), [[1_000_000., 0.], [0., 1_000_000.]])
        np.testing.assert_array_equal(mean_cell_cpm(counts), [500_000., 500_000.])
        self.assertFalse(np.allclose(mean_cell_cpm(counts), [100_000., 900_000.]))

    def test_library_scaling_does_not_change_equal_cell_profile(self):
        np.testing.assert_allclose(mean_cell_cpm([[1., 2.], [4., 1.]]),
                                   mean_cell_cpm([[10., 20.], [4., 1.]]))

    def test_zero_missing_nonfinite_negative_and_overflow_counts_are_rejected(self):
        for counts in ([[0., 0.]], [[1., -1.]], [[1., np.nan]], [[1., np.inf]],
                       [[1e308, 1e308]], [], [1., 2.]):
            with self.subTest(counts=counts), self.assertRaises(ValueError):
                cell_cpm(counts)


class PatientAggregationTests(unittest.TestCase):
    def test_finite_extreme_values_cannot_overflow_aggregation_silently(self):
        common = dict(values=[[1e308], [1e308]], cell_ids=["c1", "c2"],
                      states=["resistance", "resistance"])
        with self.assertRaisesRegex(ValueError, "nonfinite"):
            aggregate_cells_by_specimen(
                **common, patient_ids=["p1", "p1"], specimen_ids=["s1", "s1"])
        repeated = aggregate_cells_by_specimen(
            **common, patient_ids=["p1", "p1"], specimen_ids=["s1", "s2"])
        with self.assertRaisesRegex(ValueError, "nonfinite"):
            aggregate_specimens_by_patient(
                repeated, state="resistance", repeated_specimens="equal_specimen_mean")
        separate = aggregate_cells_by_specimen(
            **common, patient_ids=["p1", "p2"], specimen_ids=["s1", "s2"])
        patients = aggregate_specimens_by_patient(
            separate, state="resistance", repeated_specimens="error")
        with self.assertRaisesRegex(ValueError, "nonfinite"):
            _ = patients.cohort_mean

    def fixture(self):
        return aggregate_cells_by_specimen(
            [[0.], [0.], [0.], [2.], [8.], [100.]],
            cell_ids=["c1", "c2", "c3", "c4", "c5", "c6"],
            patient_ids=["p1", "p1", "p1", "p1", "p2", "p2"],
            specimen_ids=["s1", "s1", "s1", "s2", "s3", "baseline"],
            states=["resistance"] * 5 + ["pretreatment"],
        )

    def test_specimens_and_patients_are_not_counted_as_cells(self):
        specimens = self.fixture()
        self.assertEqual(specimens.independent_patient_count, 2)
        self.assertEqual(specimens.specimen_ids, ("s1", "s2", "baseline", "s3"))
        self.assertEqual(specimens.cell_counts, (3, 1, 1, 1))
        patients = aggregate_specimens_by_patient(
            specimens, state="resistance", repeated_specimens="equal_specimen_mean")
        self.assertEqual(patients.patient_ids, ("p1", "p2"))
        self.assertEqual(patients.specimen_counts, (2, 1))
        np.testing.assert_array_equal(patients.values, [[1.], [8.]])
        np.testing.assert_array_equal(patients.cohort_mean, [4.5])
        # Neither the six-cell mean nor the three-resistance-specimen mean.
        self.assertNotAlmostEqual(float(patients.cohort_mean[0]), 110 / 6)
        self.assertNotAlmostEqual(float(patients.cohort_mean[0]), 10 / 3)

    def test_repeated_specimens_require_explicit_policy_and_states_never_pool(self):
        specimens = self.fixture()
        with self.assertRaises(ValueError):
            aggregate_specimens_by_patient(specimens, state="resistance", repeated_specimens="error")
        with self.assertRaises(ValueError):
            aggregate_specimens_by_patient(specimens, state="resistance", repeated_specimens="pool")
        with self.assertRaises(ValueError):
            aggregate_specimens_by_patient(specimens, state="unknown", repeated_specimens="error")
        baseline = aggregate_specimens_by_patient(
            specimens, state="pretreatment", repeated_specimens="error")
        self.assertEqual(baseline.patient_ids, ("p2",))
        np.testing.assert_array_equal(baseline.values, [[100.]])

    def test_duplicate_cells_conflicting_specimen_mapping_and_missing_labels_fail(self):
        for cells, patients, specimens, states in (
            (["c1", "c1"], ["p1", "p1"], ["s1", "s1"], ["AR", "AR"]),
            (["c1", "c2"], ["p1", "p2"], ["s1", "s1"], ["AR", "AR"]),
            (["c1", "c2"], ["p1", "p1"], ["s1", "s1"], ["AR", "pre"]),
            (["c1", "c2"], ["p1", ""], ["s1", "s2"], ["AR", "AR"]),
            (["c1", "c2"], ["p1", "p2"], ["s1", "s2"], ["AR"]),
        ):
            with self.subTest(labels=(cells, patients, specimens, states)):
                with self.assertRaises(ValueError):
                    aggregate_cells_by_specimen([[1.], [2.]], cell_ids=cells,
                        patient_ids=patients, specimen_ids=specimens, states=states)


if __name__ == "__main__":
    unittest.main()
