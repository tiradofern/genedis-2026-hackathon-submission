"""Synthetic checks only; never open real NSCLC assay measurements."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

SOURCE = Path(__file__).parents[1] / "pilot/cellular_2026-10-31/analyze_nsclc_component.py"
SPEC = importlib.util.spec_from_file_location("nsclc_component_runner", SOURCE)
runner = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(runner)


class ConditionalComponentTests(unittest.TestCase):
    def test_midrank_ties(self):
        np.testing.assert_array_equal(runner.midranks([3, 1, 1, 5]), [3, 1.5, 1.5, 4])

    def test_perfect_reverse_relationship_and_partial(self):
        rng = np.random.default_rng(20261031)
        a = np.arange(40, dtype=float)
        result = runner.pair_correlations(a, -a, rng.uniform(10, 500, 40), rng.normal(size=40))
        self.assertAlmostEqual(result["spearman"], -1)
        self.assertAlmostEqual(result["partial_rank_correlation"], -1)
        self.assertEqual(result["residual_df"], 36)

    def test_independent_synthetic_channels(self):
        rng = np.random.default_rng(903)
        n = 2000
        result = runner.pair_correlations(rng.normal(size=n), rng.normal(size=n),
                                          rng.uniform(10, 500, n), rng.normal(size=n))
        self.assertLess(abs(result["spearman"]), .08)
        self.assertLess(abs(result["partial_rank_correlation"]), .08)

    def test_low_cell_and_constant_channels_are_missing(self):
        for n in [0, 2, 5]:
            result = runner.pair_correlations(np.arange(n), np.arange(n), np.arange(n), np.arange(n))
            self.assertIsNone(result["spearman"])
            self.assertIsNone(result["partial_rank_correlation"])
            self.assertEqual(result["status"], "unassessable")
        result = runner.pair_correlations(np.ones(40), np.arange(40), np.arange(40), np.sin(np.arange(40)))
        self.assertIsNone(result["spearman"])
        self.assertEqual(result["reason"], "constant_channel")

    def test_perfectly_technical_rank_relationship_has_no_partial(self):
        a = np.arange(40, dtype=float)
        result = runner.pair_correlations(a, -a, np.expm1(a / 10), np.sin(a))
        self.assertAlmostEqual(result["spearman"], -1)
        self.assertIsNone(result["partial_rank_correlation"])
        self.assertEqual(result["reason"], "constant_or_numerically_zero_residual")

    def test_sensitivity_never_rescues_an_uncalibratable_ROI(self):
        protocol = runner.proposed_protocol()
        labels = np.array(["Myeloid"] * 19 + ["Tumour"])
        keep, calibration = runner.sensitivity_mask(labels, np.ones(20), np.ones(20), protocol)
        self.assertIsNone(keep)
        self.assertEqual(calibration["status"], "unavailable")
        labels = np.array(["Myeloid"] * 20 + ["Tumour", "Tumour", "Tumour"])
        cd45 = np.r_[np.arange(20), 0, 14.25, 0]
        panck = np.r_[np.arange(20), 20, 20, 14.25]
        keep, calibration = runner.sensitivity_mask(labels, cd45, panck, protocol)
        self.assertTrue(keep[-3])
        self.assertFalse(keep[-2])  # Exactly CD45 q75 is excluded.
        self.assertFalse(keep[-1])  # Exactly panCK q75 is excluded.

    def test_equal_ROI_weight_and_missing_patient_retention(self):
        rng = np.random.default_rng(93)
        n1, n2 = 16, 64
        n = n1+n2
        metadata = {"PatientID": np.array(["2"] * n), "TherapyStatus": np.array(["post"] * n),
                    "SampleID": np.array(["synthetic"] * n), "ROI": np.array(["1"]*n1+["2"]*n2),
                    "Cluster_levels": np.array(["Tumour"] * n), "Area": rng.uniform(10, 100, n)}
        a = np.r_[np.arange(n1), np.arange(n2)].astype(float)
        b = np.r_[np.arange(n1), -np.arange(n2)].astype(float)
        channels = {"CD38": a, "IDO": b, "PD-L1": rng.normal(size=n),
                    "HLA-ABC": np.ones(n), "HLA-DR": np.ones(n), "CD45": np.zeros(n),
                    "pan Cytokeratin": np.ones(n), "Histone H3": rng.normal(size=n)}
        rois, patients = runner.analyze_arrays(metadata, channels, runner.proposed_protocol())
        p1 = next(p for p in patients if p["publication_patient_id"] == "P1" and p["variant"] == "source_Tumour")
        result = p1["pairs"]["CD38__IDO1"]["spearman"]
        self.assertEqual(result["assessable_ROIs"], 2)
        self.assertAlmostEqual(result["equal_ROI_mean"], 0)
        self.assertEqual(len(patients), 14)
        self.assertTrue(all(r["status"] == "unavailable" for r in rois if r["variant"] == "source_Tumour_marker_restriction"))
        json.dumps({"rois": rois, "patients": patients}, allow_nan=False)
        descriptions = runner.across_patient_descriptives(patients)
        description = next(v for v in descriptions if v["variant"] == "source_Tumour" and
                           v["pair"] == "CD38__IDO1" and v["statistic"] == "spearman")
        self.assertEqual(description["assessable_patients"], 1)
        self.assertAlmostEqual(description["equal_patient_mean"], 0)
        # JSON key sorting must not change the three prespecified pair identities.
        sorted_protocol = json.loads(json.dumps(runner.proposed_protocol(), sort_keys=True))
        _, sorted_patients = runner.analyze_arrays(metadata, channels, sorted_protocol)
        self.assertEqual(runner.across_patient_descriptives(sorted_patients), descriptions)

    def test_gate_rejects_before_real_file_access(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            protocol = tmp/"protocol.json"
            gate = tmp/"gate.json"
            protocol.write_text(json.dumps(runner.proposed_protocol()))
            gate.write_text(json.dumps({"decision": "HOLD"}))
            with patch.object(runner, "load_sce", side_effect=AssertionError("Real assay reader called")) as reader:
                with self.assertRaises(ValueError):
                    runner.run(gate, protocol, tmp/"REAL_FILE_MUST_NOT_OPEN.rds", tmp/"out")
                reader.assert_not_called()
            self.assertFalse((tmp/"out").exists())

    def test_exact_frozen_protocol_hash_is_required(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            p = runner.proposed_protocol()
            p["status"] = "FROZEN"
            protocol = tmp/"protocol.json"
            gate = tmp/"gate.json"
            protocol.write_text(json.dumps(p))
            gate.write_text(json.dumps({"decision": "GO", "analysis_id": runner.ANALYSIS_ID,
                                        "protocol_sha256": hashlib.sha256(protocol.read_bytes()).hexdigest()}))
            runner.validate_gate(gate, protocol)
            protocol.write_bytes(protocol.read_bytes()+b"\n")
            with self.assertRaises(ValueError):
                runner.validate_gate(gate, protocol)


if __name__ == "__main__":
    unittest.main()
