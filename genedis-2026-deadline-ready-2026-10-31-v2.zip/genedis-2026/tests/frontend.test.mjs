import test from 'node:test';
import assert from 'node:assert/strict';
import {matchesSample,csvText,validateSnapshot,cnaLabel} from '../web/helpers.js';
const filter=()=>({stages:['I','II','III','IV','Unknown'],sex:'',purity:0,includeUnknown:true,activity:'all',alteration:'all',search:''});
const sample={id:'synthetic-a',stage_group:'I',sex:'Female',purity:null};
const gene={reported_variant_samples:[],cna:[null]};
test('unknown purity stays separate; independent stage filters combine',()=>{
  const f=filter();f.purity=50;
  assert.equal(matchesSample(sample,0,f,gene,1,1),true);
  f.includeUnknown=false;
  assert.equal(matchesSample(sample,0,f,gene,1,1),false);
  assert.equal(matchesSample({...sample,purity:.6},0,f,gene,1,1),true);
  f.stages=['III'];
  assert.equal(matchesSample({...sample,purity:.6},0,f,gene,1,1),false);
});
test('missing CNA is neither neutral nor deletion; MAF event preserved',()=>{
  const f=filter();f.alteration='del';
  assert.equal(matchesSample(sample,0,f,gene,1,1),false);
  f.alteration='cna-unknown';
  assert.equal(matchesSample(sample,0,f,gene,1,1),true);
  assert.equal(cnaLabel(null),'Unmeasured');assert.equal(cnaLabel(0),'Neutral');
  f.alteration='variant';
  assert.equal(matchesSample(sample,0,f,{...gene,reported_variant_samples:[sample.id]},1,1),true);
});
test('training-defined upper quartile includes boundary without a gene filter',()=>{
  const f=filter();f.activity='high';
  assert.equal(matchesSample(sample,0,f,null,1,1),true);
  assert.equal(matchesSample(sample,0,f,null,.99,1),false);
  f.activity='other';assert.equal(matchesSample(sample,0,f,null,1,1),false);
});
test('exploration rejects stale fingerprint, invalid specimen or filter',()=>{
  const bootstrap={fingerprint:'verified',cohorts:{LUAD:{samples:[sample],programs:[{id:'p'}]}}};
  const valid={schema_version:1,dataset_fingerprint:'verified',study:'LUAD',program:'p',gene:'1',color:'stage',selected_ids:[sample.id],filters:filter()};
  assert.equal(validateSnapshot(valid,bootstrap),valid);
  assert.throws(()=>validateSnapshot({...valid,dataset_fingerprint:'old'},bootstrap),/different dataset/);
  assert.throws(()=>validateSnapshot({...valid,area_selection:['other']},bootstrap),/outside/);
  assert.throws(()=>validateSnapshot({...valid,groups:{a:{ids:['other']}}},bootstrap),/outside/);
  assert.throws(()=>validateSnapshot({...valid,filters:{...filter(),purity:101}},bootstrap),/purity/);
});
test('CSV preserves commas, quotes and unknown values',()=>{
  assert.equal(csvText(['id','value'],[['a,b','"quoted"'],['c',null]]),'"id","value"\r\n"a,b","""quoted"""\r\n"c",""');
});
