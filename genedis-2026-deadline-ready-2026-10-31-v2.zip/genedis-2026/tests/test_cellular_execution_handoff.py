"""Hermetic transport-integrity checks; no clinical or biological effect data."""
import hashlib
from http.client import IncompleteRead
import importlib.util
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch


SOURCE = Path(__file__).resolve().parents[1] / 'pilot/cellular_2026-10-31/retrieve_execution_sources.py'
SPEC = importlib.util.spec_from_file_location('execution_source_transport', SOURCE)
TRANSPORT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(TRANSPORT)


class Response(io.BytesIO):
    def __init__(self, data, status=200, headers=None):
        super().__init__(data)
        self.status = status
        self.headers = headers or {}


class SourceIntegrityTests(unittest.TestCase):
    payload = b'published-processed-input\n'

    def item(self):
        return {'url': 'https://example.org/data', 'bytes': len(self.payload),
                'sha256': hashlib.sha256(self.payload).hexdigest()}

    def test_complete_response_is_hash_checked_before_publication(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / 'source.csv'
            with patch.object(TRANSPORT.urllib.request, 'urlopen', return_value=Response(self.payload)):
                TRANSPORT.fetch(self.item(), target, 0)
            self.assertEqual(target.read_bytes(), self.payload)
            self.assertEqual(list(target.parent.glob('*.part')), [])

    def test_exact_ranges_reconstruct_complete_source(self):
        def response(request, **kwargs):
            start, end = map(int, request.get_header('Range').removeprefix('bytes=').split('-'))
            return Response(self.payload[start:end+1], 206,
                            {'Content-Range': f'bytes {start}-{end}/{len(self.payload)}'})
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / 'source.csv'
            with patch.object(TRANSPORT.urllib.request, 'urlopen', side_effect=response):
                TRANSPORT.fetch(self.item(), target, 5)
            self.assertEqual(target.read_bytes(), self.payload)

    def test_wrong_content_range_preserves_absent_target(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / 'source.csv'
            bad = Response(self.payload[:5], 206, {'Content-Range': 'bytes 1-5/999'})
            with patch.object(TRANSPORT.urllib.request, 'urlopen', return_value=bad):
                with self.assertRaisesRegex(ValueError, 'Incorrect range'):
                    TRANSPORT.fetch(self.item(), target, 5)
            self.assertFalse(target.exists())
            self.assertEqual(list(target.parent.glob('*.part')), [])

    def test_same_length_corruption_cannot_become_source(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / 'source.csv'
            damaged = b'X' + self.payload[1:]
            with patch.object(TRANSPORT.urllib.request, 'urlopen', return_value=Response(damaged)):
                with self.assertRaisesRegex(ValueError, 'SHA256 mismatch'):
                    TRANSPORT.fetch(self.item(), target, 0)
            self.assertFalse(target.exists())
            self.assertEqual(list(target.parent.glob('*.part')), [])

    def test_failed_large_ranges_halve_without_appending_partial_bytes(self):
        requested = []
        def response(request, **kwargs):
            start,end = map(int,request.get_header('Range').removeprefix('bytes=').split('-'))
            requested.append((start,end))
            if end-start+1 > 4:
                # Correct metadata, then an actual partial body and premature EOF.
                # Its bytes must be discarded before retrying the same offset.
                return Response(self.payload[start:start+2],206,
                                {'Content-Range':f'bytes {start}-{end}/{len(self.payload)}'})
            return Response(self.payload[start:end+1],206,
                            {'Content-Range':f'bytes {start}-{end}/{len(self.payload)}'})
        with tempfile.TemporaryDirectory() as directory:
            target=Path(directory)/'source.csv'
            with patch.object(TRANSPORT.urllib.request,'urlopen',side_effect=response):
                TRANSPORT.fetch(self.item(),target,16,minimum_chunk_bytes=4)
            self.assertEqual(requested[:3],[(0,15),(0,7),(0,3)])
            self.assertEqual(target.read_bytes(),self.payload)
            self.assertEqual(list(target.parent.glob('*.part')),[])

    def test_adaptive_transport_cannot_accept_corrupted_range_bytes(self):
        def response(request, **kwargs):
            start,end=map(int,request.get_header('Range').removeprefix('bytes=').split('-'))
            if end-start+1>4:
                raise IncompleteRead(b'',end-start+1)
            data=self.payload[start:end+1]
            if start==0:
                data=b'X'+data[1:]
            return Response(data,206,{'Content-Range':f'bytes {start}-{end}/{len(self.payload)}'})
        with tempfile.TemporaryDirectory() as directory:
            target=Path(directory)/'source.csv'
            with patch.object(TRANSPORT.urllib.request,'urlopen',side_effect=response):
                with self.assertRaisesRegex(ValueError,'SHA256 mismatch'):
                    TRANSPORT.fetch(self.item(),target,16,minimum_chunk_bytes=4)
            self.assertFalse(target.exists())
            self.assertEqual(list(target.parent.glob('*.part')),[])

    def test_persistent_transport_failure_has_a_bounded_retry_count(self):
        with tempfile.TemporaryDirectory() as directory:
            target=Path(directory)/'source.csv'
            with patch.object(TRANSPORT.urllib.request,'urlopen',side_effect=IncompleteRead(b'',4)) as mocked:
                with self.assertRaises(IncompleteRead):
                    TRANSPORT.fetch(self.item(),target,16,minimum_chunk_bytes=4,maximum_range_attempts=4)
            self.assertEqual(mocked.call_count,4)
            self.assertFalse(target.exists())
            self.assertEqual(list(target.parent.glob('*.part')),[])

    def test_existing_target_is_preserved_after_verified_transfer(self):
        with tempfile.TemporaryDirectory() as directory:
            target=Path(directory)/'source.csv';target.write_bytes(b'existing-different-source')
            with patch.object(TRANSPORT.urllib.request,'urlopen',return_value=Response(self.payload)):
                with self.assertRaises(FileExistsError):
                    TRANSPORT.fetch(self.item(),target,0)
            self.assertEqual(target.read_bytes(),b'existing-different-source')
            self.assertEqual(list(target.parent.glob('*.part')),[])


if __name__ == '__main__':
    unittest.main()
