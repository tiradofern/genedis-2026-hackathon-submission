# MSigDB panel attribution and terms

**Source:** Molecular Signatures Database (MSigDB), human Hallmark collection, release **2024.1.Hs**. Authoritative source URLs and byte hashes are recorded in `panel_manifest.json`.

**Copyright:** MSigDB contents are protected by copyright (c) 2004–2025 Broad Institute, Inc., Massachusetts Institute of Technology, and Regents of the University of California, as stated on the retrieved license page. The website footer separately displays 2004–2026; both are preserved in the source HTML.

**License:** [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/). The [official MSigDB license terms](https://www.gsea-msigdb.org/gsea/msigdb_license_terms.jsp), retrieved October 31, 2026, explicitly apply these terms to releases v6.0–v7.5.1 and v2022.1 and above, subject to additional terms for some named gene-set sources. The page names KEGG MEDICUS, other KEGG, BioCarta, and historical AAAS/STKE restrictions. This package includes only six **H** collection Hallmark sets, not those named restricted C2/M2 subcollections. No additional restriction for these H sets is specified by the inspected page.

CC BY 4.0 permits reuse and sharing with attribution, a license link, and an indication of changes. **Changes made here:** selected six intact Hallmark gene sets from the full H release; generated a long-form membership table, metadata subset, and gene-set overlap table. No source member was added, removed, renamed, or reweighted. Mapping and coverage decisions made by later analysis are separate derived artifacts and must be reported there.

These dataset terms are separate from the GeNeDis project's still-pending software release license. Bundling licensed gene definitions does not grant a license to the project's other code or third-party datasets.

**Primary publication:** Liberzon A, Birger C, Thorvaldsdóttir H, Ghandi M, Mesirov JP, Tamayo P. *The Molecular Signatures Database (MSigDB) hallmark gene set collection.* Cell Systems. 2015;1(6):417–425. [doi:10.1016/j.cels.2015.12.004](https://doi.org/10.1016/j.cels.2015.12.004). [PMID:26771021](https://pubmed.ncbi.nlm.nih.gov/26771021/).

Retain this attribution, the license link, source links, version, and change statement when sharing the subset. The saved HTML in `sources/` is evidence of the public terms inspected; the authoritative current terms remain at the URL above.
