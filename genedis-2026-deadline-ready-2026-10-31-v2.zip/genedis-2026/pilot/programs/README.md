# Fixed published program panel

The six program **definitions** were fixed at **2026-10-31 06:43:09 UTC**, before patient-level program scoring. They are intact human Hallmark sets from the authoritative Broad Institute **MSigDB 2024.1.Hs** release. This archived release was selected for a stable, auditable public source; no outcome-based release or membership selection was performed. The panel follows the six program names already proposed in the tonight protocol.

| Fixed program | MSigDB ID | Original genes |
|---|---|---:|
| Interferon alpha response | M5911 | 97 |
| Interferon gamma response | M5913 | 200 |
| Epithelial mesenchymal transition | M5930 | 200 |
| Hypoxia | M5891 | 200 |
| Oxidative phosphorylation | M5936 | 200 |
| G2M checkpoint | M5901 | 200 |

The exact source GMT and independent release JSON are included under `sources/`; the preparation script requires their gene lists and source URLs to agree. `hallmark_panel_v2024.1.Hs.gmt`, its JSON counterpart, and `membership.tsv` contain **all original members**, without alias conversion or feature filtering. `panel_manifest.json` provides source and artifact SHA256 hashes, program sizes, release IDs, license, and the prospective freeze record. Common-gene coverage, expression identifier mapping, and the eventual eligible cohort manifest are separate analysis gates; freezing the gene definitions does not imply those gates have passed.

Run from the repository root:

```bash
python pilot/programs/freeze_panel.py --verify-only
```

This uses only cached public definitions, changes no files, and reads no patient information. To replay preparation into a **new** directory, including pinned public-source retrieval:

```bash
python pilot/programs/freeze_panel.py --destination /tmp/genedis-hallmark-panel-replay
```

Existing different bytes are never overwritten. The saved license pages record terms at retrieval; a future change to a live terms page may prevent a fully byte-identical network replay, while the bundled frozen source remains independently verifiable.

`program_overlap.tsv` reports all 36 ordered pairs of set overlaps, including diagonals, with gene counts, intersection, union, Jaccard index, and the fraction of the smaller set shared. The interferon alpha and gamma programs substantially overlap. They must not be presented as two independent adaptations. These published program scores also do not test whether their genes are coordinated in the current cohorts. A melanoma EMT score does not establish a literal epithelial-to-mesenchymal transition. Expression shifts are not genomic conservation, selection, resistance specificity, or functional contribution.

See [TERMS_AND_CITATION.md](TERMS_AND_CITATION.md) for attribution and redistribution terms.
