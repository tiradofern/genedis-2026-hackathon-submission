#!/usr/bin/env python3
"""Retrieve/check the prospectively selected public six-Hallmark panel.

Only public gene definitions are read. No patient expression or outcomes are read.
The original GMT and independent release JSON must agree exactly per gene set.
Existing files are never replaced with different bytes.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import urllib.request


RELEASE = "2024.1.Hs"
FROZEN_AT_UTC = "2026-10-31T06:43:09Z"
PROGRAMS = (
    "HALLMARK_INTERFERON_ALPHA_RESPONSE",
    "HALLMARK_INTERFERON_GAMMA_RESPONSE",
    "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION",
    "HALLMARK_HYPOXIA",
    "HALLMARK_OXIDATIVE_PHOSPHORYLATION",
    "HALLMARK_G2M_CHECKPOINT",
)
SOURCE_ROOT = "https://data.broadinstitute.org/gsea-msigdb/msigdb/release/2024.1.Hs/"
SOURCES = {
    "h.all.v2024.1.Hs.symbols.gmt": {
        "url": SOURCE_ROOT + "h.all.v2024.1.Hs.symbols.gmt",
        "sha256": "ee2463540042078bfa3f67828e1e223bb354446d9fbb4d22845866835ba5c772",
        "bytes": 48690,
    },
    "h.all.v2024.1.Hs.json": {
        "url": SOURCE_ROOT + "h.all.v2024.1.Hs.json",
        "sha256": "921b18c0f3f238b10432eb4b16ba5ed0471ef26dd9f2e4d99323d8b9e7ec6f21",
        "bytes": 73086,
    },
    "msigdb_license_terms_2026-10-31.html": {
        "url": "https://www.gsea-msigdb.org/gsea/msigdb_license_terms.jsp",
        "sha256": "d7f60159f93efdf76e729e8d81fdc14cb4d6a6cef8866706217627bf18dfe6a9",
        "bytes": 6264,
    },
    "license_terms_list_2026-10-31.html": {
        "url": "https://www.gsea-msigdb.org/gsea/license_terms_list.jsp",
        "sha256": "9940e1243d60dd526533b9a6b33ae9e52a6d4772b50805dec095bbb784430a00",
        "bytes": 3800,
    },
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_once(path: Path, data: bytes, verify_only: bool) -> None:
    if path.exists():
        if path.read_bytes() != data:
            raise ValueError(f"Refusing to overwrite different existing bytes: {path}")
    elif verify_only:
        raise FileNotFoundError(path)
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)


def tsv_bytes(rows: list[list[object]]) -> bytes:
    out = io.StringIO(newline="")
    writer = csv.writer(out, delimiter="\t", lineterminator="\n")
    writer.writerows(rows)
    return out.getvalue().encode("utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--verify-only", action="store_true", help="Read cached sources only; change no files.")
    args = parser.parse_args()
    root = args.destination
    cached: dict[str, bytes] = {}
    for name, spec in SOURCES.items():
        path = root / "sources" / name
        if path.exists():
            data = path.read_bytes()
        elif args.verify_only:
            raise FileNotFoundError(path)
        else:
            with urllib.request.urlopen(spec["url"], timeout=60) as response:
                data = response.read()
        if len(data) != spec["bytes"] or digest(data) != spec["sha256"]:
            raise ValueError(f"Source content does not match frozen source: {name}")
        write_once(path, data, args.verify_only)
        cached[name] = data

    release_json = json.loads(cached["h.all.v2024.1.Hs.json"])
    gmt_rows: dict[str, list[str]] = {}
    for line in cached["h.all.v2024.1.Hs.symbols.gmt"].decode("utf-8").splitlines():
        fields = line.split("\t")
        if len(fields) < 3 or fields[0] in gmt_rows:
            raise ValueError("Malformed/duplicate source GMT entry")
        gmt_rows[fields[0]] = fields
    if len(gmt_rows) != 50 or set(gmt_rows) != set(release_json):
        raise ValueError("Expected the complete matching 50-set human H collection")

    membership = [["program", "gene_symbol", "release", "source_url"]]
    selected_json = {}
    selected_lines = []
    sets = {}
    for program in PROGRAMS:
        fields = gmt_rows[program]
        meta = release_json[program]
        genes = fields[2:]
        if not genes or len(set(genes)) != len(genes):
            raise ValueError(f"Empty/duplicate gene symbols: {program}")
        if genes != meta["geneSymbols"] or meta["collection"] != "H":
            raise ValueError(f"Official JSON/GMT disagreement: {program}")
        if fields[1] != meta["msigdbURL"]:
            raise ValueError(f"Official source-link disagreement: {program}")
        sets[program] = set(genes)
        selected_lines.append("\t".join(fields))
        selected_json[program] = meta
        membership.extend([[program, gene, RELEASE, fields[1]] for gene in genes])

    artifacts = {
        "hallmark_panel_v2024.1.Hs.gmt": ("\n".join(selected_lines) + "\n").encode(),
        "membership.tsv": tsv_bytes(membership),
        "hallmark_panel_v2024.1.Hs.json": (json.dumps(selected_json, indent=2, ensure_ascii=False) + "\n").encode(),
    }
    overlaps = [["program_a", "program_b", "n_a", "n_b", "intersection", "union", "jaccard", "overlap_smaller_fraction"]]
    for a in PROGRAMS:
        for b in PROGRAMS:
            intersection = len(sets[a] & sets[b])
            union = len(sets[a] | sets[b])
            overlaps.append([a, b, len(sets[a]), len(sets[b]), intersection, union,
                             f"{intersection / union:.12g}",
                             f"{intersection / min(len(sets[a]), len(sets[b])):.12g}"])
    artifacts["program_overlap.tsv"] = tsv_bytes(overlaps)
    manifest = {
        "status": "fixed_before_patient_program_scores",
        "frozen_at_utc": FROZEN_AT_UTC,
        "release": RELEASE,
        "organism": "Homo sapiens",
        "identifier_type": "MSigDB release gene symbols (no alias conversion applied)",
        "source_collection": "MSigDB H: hallmark gene sets",
        "selection": "Six published programs named in the pre-existing tonight protocol, fixed without expression/outcome inspection.",
        "selection_scope": "Gene definitions only; cohort eligibility and common-universe mapping are separate gates.",
        "license": "CC-BY-4.0",
        "license_url": "https://www.gsea-msigdb.org/gsea/msigdb_license_terms.jsp",
        "attribution": "MSigDB; Broad Institute, Inc., Massachusetts Institute of Technology, and Regents of the University of California. Liberzon et al., Cell Systems 2015, doi:10.1016/j.cels.2015.12.004, PMID:26771021.",
        "changes": "Subsetted six intact H gene sets; source gene order and all members retained. No genes added, removed, reweighted, or remapped.",
        "sources": SOURCES,
        "programs": [{"name": p, "n_genes": len(sets[p]), "systematic_name": selected_json[p]["systematicName"],
                      "msigdb_url": selected_json[p]["msigdbURL"],
                      "gene_list_sha256": digest(("\n".join(gmt_rows[p][2:]) + "\n").encode())} for p in PROGRAMS],
        "union_n_genes": len(set.union(*sets.values())),
        "artifacts": {name: {"sha256": digest(data), "bytes": len(data)} for name, data in artifacts.items()},
        "cautions": [
            "Published Hallmark membership does not establish coordination in these cohorts.",
            "The two interferon programs substantially overlap and are not independent adaptations.",
            "EMT signature recurrence in melanoma is not proof of literal epithelial-to-mesenchymal transition.",
            "Gene symbols reflect the frozen release; cross-platform aliases require a separate auditable mapping.",
            "No patient expression, clinical outcomes, program effects, or resistance enrichment were read by this script."
        ],
    }
    artifacts["panel_manifest.json"] = (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode()
    for name, data in artifacts.items():
        write_once(root / name, data, args.verify_only)
    for program in PROGRAMS:
        print(f"{program}\t{len(sets[program])}")
    print(f"Verified {len(PROGRAMS)} programs, {manifest['union_n_genes']} unique symbols; frozen {FROZEN_AT_UTC}")
    print(f"panel_manifest.json sha256={digest(artifacts['panel_manifest.json'])}")


if __name__ == "__main__":
    main()
