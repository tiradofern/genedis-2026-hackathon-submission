# Pre-effect review of measurement scope

Review date: October 31, 2026. This is an AI-assisted adversarial technical review, not Justin's approval. Reviewed `MEASUREMENT_PROTOCOL.md`, `RNA_MEASUREMENT_PROTOCOL.json`, `RNA_EXECUTION_GATE.json`, `INDEPENDENT_EXECUTION_REVIEW.md`, `QUEK_CELL_ID_PROTOCOL.json`, and the recorded PI resolutions. No real program effects were inspected for this review.

## Decision

**Scientific disposition: GO_DESCRIPTIVE_CONDITIONAL for the narrowly specified measurements; HOLD for robust MSI nomination and the full primary discovery–NSCLC validation claim.** There is no newly identified mathematical blocker to calculating the frozen descriptive summaries and conditional matched-gene-set diagnostics. This is not a finding that the original end-to-end feasibility gate passed.

The original PI requirement was a feasible two-non-NSCLC-cancer discovery and independent NSCLC validation combination before molecular discovery. Relabelling scoring as measurement does not by itself waive that instruction. The execution gate expressly attributes its limited permission to the PI's renewed build authorization; the responsible parent workflow must retain that authorization and this distinction in the audit trail. Neither an AI review nor a favorable technical result supplies a new PI scope decision. The authorized interpretation must remain: limited measurements of the original design were executed, while its primary scientific objective is inconclusive. Do not describe this as a successfully validated pan-cancer MSI study or a newly approved substitute study.

## Reasons for the scientific limit

- The acquired-resistant specimens span two cancer types but only three independent patients: two MCC and one melanoma. They cannot establish population recurrence or independent within-melanoma replication. Multiple cells, genes, sequencing lanes, and null draws do not add patients.
- The fixed melanoma identification procedure retains six lineage-positive putative malignant resistance-stage cells and five under the stricter rule. With the fixed technical design, the residual dimensions are two and one, respectively. Two is a mathematical estimability threshold, not evidence of biological stability. The stricter sensitivity cannot evaluate coordination. This prevents robust nomination before any effect is seen; do not lower covariate rank, alter the mask, or relax the residual-dimension rule to rescue it.
- Unmodified RNA donor labels have independent supporting evidence, but conflicting ADT/demultiplex metadata persist. These are putative malignant melanocytic cells, not DNA-confirmed cancer cells or a complete malignant population. The mask may exclude dedifferentiated states. It does not justify prevalence estimates for all cancer cells or pre/post selection claims.
- PD-(L)1-containing regimens constitute the declared broad treatment family. The MCC cellular/local treatments and melanoma combination checkpoint regimen remain explicit strata and confounders. Cross-context recurrence would not isolate an effect of checkpoint blockade.

## Exact identity exclusions checked

The frozen RNA protocol contains **35 unique excluded genes**: 31 melanoma identification/lineage/reference/identity genes plus four MCC identity genes. The split is:

- Melanoma/reference/identity (31): `CD3D, CD3E, CD79A, CD79B, COL1A1, COL1A2, DCN, DCT, DDX3Y, EIF1AY, EMCN, FCER1G, KDM5D, KDR, LST1, LUM, MITF, MLANA, MS4A1, PECAM1, PMEL, PTPRC, RPS4Y1, SOX10, TRAC, TYR, TYROBP, TYRP1, UTY, VWF, XIST`.
- MCC identity (4): `CHGA, ENO2, KRT20, NCAM1`.

This list covers the frozen four primary melanocytic markers, immune/stromal/endothelial reference markers, additional lineage markers and donor-identity anchors. Exclude these from the common scoring and coordination universes before effects, while retaining them in full-library normalization totals. Preserve exact original Hallmark membership and report losses against that original membership. Freezing these exclusions reduces direct feature reuse; it does not remove all selection bias or make RNA-based cell identification independent of RNA measurement.

## Statistical interpretation

The fixed 50-set family, shared bijective stratified gene permutations, retained unassessable rows and BY correction avoid selecting favorable pathways after inspection. Patient-level maximum P values are conjunction diagnostics for these fixed specimens under an approximate conditional gene-exchangeability null. They are not estimates or tests of clinical-population recurrence. BY controls the stated family only to the extent its input null P values are calibrated; multiplicity correction does not repair poor exchangeability or missing biological replication.

Expression/detection matching and overlap-preserving permutations do not fully account for tissue lineage, generic cancer biology, regulatory architecture, environmental induction, cell-selection effects or technical artifacts. Report these limits beside the results. A small conditional P value may identify unusual within-specimen gene-set organization relative to this technical background; it cannot establish resistance specificity, convergent selection, conserved genomic regions or causality. A non-small P value means no evidence against this exact null, not proof of absent biology. If any binary technical-significance label is used, its numerical BY threshold must also be frozen before effects; reporting continuous P and adjusted values requires no new threshold.

No responder cohort is required merely to describe recurrence in resistant specimens. Its absence does prevent an enrichment or resistance-specificity claim. Existing activity and conditional coordination summaries do not establish common contributing genes, pathway flux, physical interactions, or a newly discovered distributed network.

## NSCLC and reporting checks

With robust nomination prospectively disabled, **do not run actual NSCLC program follow-up to manufacture completion**. Mark primary validation `NOT_REACHED_NO_ROBUST_DISCOVERY_NOMINATION`. Source readiness, patient mapping, technical assay QC, prepared code and synthetic tests remain valid independent deliverables. The three direct protein channels cannot be presented as replication of an entire RNA Hallmark, even if a future separately authorized component test is performed. Marker restriction within source-labelled Tumour cells is not independent malignant-cell identification.

The final report must distinguish completed descriptive measurements, exploratory conditional tests, unassessable robustness, and validation not reached. Preserve all 50 programs and both fixed masks, exact denominators, negative results, source conflicts and earlier work. The scientific conclusion permitted before effects is that the current primary design is inconclusive; results may describe the measured specimens but cannot reverse that gate.
