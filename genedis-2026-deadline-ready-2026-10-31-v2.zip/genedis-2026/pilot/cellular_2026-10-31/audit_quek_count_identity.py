"""Stream Quek RNA counts for integrity and prespecified identity-marker QC.

No program scores, differential expression, functional effects or malignant-cell
calls are calculated. Only the explicit identity-marker allowlist is exported,
to ignored local data. Sex-chromosome RNA patterns do not prove donor identity.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import sys
import time
import warnings
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "data/external/cellular_2026_10_31"
MARKERS = (
    "XIST", "RPS4Y1", "DDX3Y", "UTY", "KDM5D", "EIF1AY",
    "MLANA", "PMEL", "DCT", "MITF", "SOX10", "TYR", "TYRP1",
    "PTPRC", "CD3D", "CD3E", "TRAC", "CD79A", "CD79B", "MS4A1",
    "LST1", "TYROBP", "FCER1G", "COL1A1", "COL1A2", "DCN", "LUM",
    "PECAM1", "VWF", "KDR", "EMCN",
)
Y_MARKERS = ("RPS4Y1", "DDX3Y", "UTY", "KDM5D", "EIF1AY")


def file_sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def distribution(values):
    return dict(zip(("minimum", "q25", "median", "q75", "maximum"),
                    map(float, np.quantile(values, [0, .25, .5, .75, 1]))))


def immune_identity_summary(index, quality, markers, totals, detected=None):
    """Prespecified lineage identity QC; not a functional program measurement."""
    lineages = dict(T=("CD3D", "CD3E", "TRAC"),
                    B=("CD79A", "CD79B", "MS4A1"),
                    myeloid=("LST1", "TYROBP", "FCER1G"))
    needed = set(Y_MARKERS) | {"XIST", "PTPRC"} | set(sum(lineages.values(), ()))
    if not needed.issubset(markers):
        return dict(status="UNASSESSABLE_MISSING_IDENTITY_MARKERS", missing=sorted(needed-set(markers)))
    index = np.asarray(index, dtype=int)
    quality_index = index[quality[index]]
    lineage_positive = {name: np.sum([markers[g][quality_index] > 0 for g in genes], axis=0) >= 2
                        for name, genes in lineages.items()}
    immune = (markers["PTPRC"][quality_index] >= 2) & np.logical_or.reduce(list(lineage_positive.values()))
    selected = quality_index[immune]
    n = len(selected)
    result = dict(status="DESCRIPTIVE_IDENTITY_QC_ONLY",input_cells=len(index),
        quality_passing_cells=len(quality_index),confident_immune_cells=n,
        library_count_distribution=distribution(totals[selected]) if n else None,
        detected_gene_distribution=distribution(detected[selected]) if n and detected is not None else None,
        lineage_support_among_confident_immune={name:int(mask[immune].sum()) for name,mask in lineage_positive.items()},
        fraction_resolution=1/n if n else None,
        small_group_notice="Fewer than 20 cells: fragile descriptive fractions; this is not an eligibility rule" if n<20 else None)
    if not n:
        result.update(at_least_two_Y_genes_fraction=None,XIST_detected_fraction=None,
                      both_fraction=None,Y_sum_cpm_distribution=None)
        return result
    y_values = np.stack([markers[g][selected] for g in Y_MARKERS])
    y_supported = np.sum(y_values > 0, axis=0) >= 2
    x_supported = markers["XIST"][selected] > 0
    result.update(at_least_two_Y_genes_cells=int(y_supported.sum()),
        at_least_two_Y_genes_fraction=float(y_supported.mean()),
        XIST_detected_cells=int(x_supported.sum()),XIST_detected_fraction=float(x_supported.mean()),
        both_cells=int(np.sum(y_supported & x_supported)),both_fraction=float(np.mean(y_supported & x_supported)),
        neither_cells=int(np.sum(~y_supported & ~x_supported)),
        Y_sum_cpm_distribution=distribution(y_values.sum(axis=0)/totals[selected]*1_000_000))
    return result


def sex_identity_anchor(index, markers, totals):
    """Same prespecified sex panel in a reference subset, without a donor call."""
    genes = ("XIST",) + Y_MARKERS
    if not set(genes).issubset(markers):
        return dict(status="UNASSESSABLE_MISSING_SEX_MARKERS")
    index = np.asarray(index, dtype=int)
    if not len(index):
        return dict(status="UNASSESSABLE_NO_REFERENCE_CELLS",cells=0)
    y_values = np.stack([markers[g][index] for g in Y_MARKERS])
    y_supported = np.sum(y_values>0,axis=0)>=2
    x_supported = markers["XIST"][index]>0
    return dict(status="DESCRIPTIVE_REFERENCE_SEX_PATTERN_NOT_GENOTYPE",cells=len(index),
        at_least_two_Y_genes_cells=int(y_supported.sum()),
        at_least_two_Y_genes_fraction=float(y_supported.mean()),
        XIST_detected_cells=int(x_supported.sum()),XIST_detected_fraction=float(x_supported.mean()),
        both_cells=int(np.sum(y_supported&x_supported)),
        Y_sum_cpm_distribution=distribution(y_values.sum(axis=0)/totals[index]*1_000_000),
        individual_genes={gene:dict(detected_cells=int(np.sum(markers[gene][index]>0)),
            fraction_detected=float(np.mean(markers[gene][index]>0)),
            raw_count_distribution=distribution(markers[gene][index]),
            cpm_distribution=distribution(markers[gene][index]/totals[index]*1_000_000)) for gene in genes})


def audit(counts, metadata, concordant_pre, marker_output):
    start = time.monotonic()
    with metadata.open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream)
        required = {"", "orig.ident", "nCount_RNA", "nFeature_RNA", "mia_ID", "timepoint"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError("Required RNA metadata columns are absent")
        records = list(reader)
    metadata_ids = [row[""] for row in records]
    if len(metadata_ids) != len(set(metadata_ids)):
        raise ValueError("Duplicate metadata cell IDs")
    lookup = {row[""]: row for row in records}
    pre_ids = concordant_pre.read_text().splitlines()
    if not pre_ids or len(pre_ids) != len(set(pre_ids)):
        raise ValueError("Concordant PRE cell IDs are empty or duplicated")
    pre_set = set(pre_ids)
    digest = hashlib.sha256()
    markers, genes, mitochondrial_genes = {}, set(), []
    row_count = nonzero_entries = 0
    maximum_count = 0.
    width_errors, duplicate_genes = [], []
    with counts.open("rb") as stream:
        header_bytes = stream.readline()
        digest.update(header_bytes)
        header = next(csv.reader([header_bytes.decode("utf-8-sig")], strict=True))
        cell_ids = header[1:]
        if not cell_ids or any(not cell for cell in cell_ids) or len(cell_ids) != len(set(cell_ids)):
            raise ValueError("Missing or duplicate count-matrix cell IDs")
        if set(cell_ids) != set(metadata_ids):
            raise ValueError("Count-matrix and RNA-metadata cell ID sets differ")
        totals = np.zeros(len(cell_ids), dtype=np.float64)
        detected = np.zeros(len(cell_ids), dtype=np.int64)
        mitochondrial_totals = np.zeros(len(cell_ids), dtype=np.float64)
        for line_number, raw_line in enumerate(stream, 2):
            digest.update(raw_line)
            if not raw_line.strip():
                raise ValueError(f"Empty matrix row at line {line_number}")
            gene_bytes, separator, numeric = raw_line.rstrip(b"\r\n").partition(b",")
            if not separator:
                raise ValueError(f"Missing delimiter at line {line_number}")
            gene_fields = next(csv.reader([gene_bytes.decode()], strict=True))
            if len(gene_fields) != 1 or not gene_fields[0] or gene_fields[0] != gene_fields[0].strip():
                raise ValueError(f"Ambiguous feature identifier at line {line_number}")
            gene = gene_fields[0]
            if gene in genes:
                duplicate_genes.append(gene)
            genes.add(gene)
            if b'"' in numeric:
                # Permit standard quoted numeric fields without dropping CSV checks.
                values = np.asarray(next(csv.reader([numeric.decode()], strict=True)), dtype=float)
            else:
                with warnings.catch_warnings():
                    warnings.simplefilter("error")
                    values = np.fromstring(numeric, dtype=np.float64, sep=",")
            if len(values) != len(cell_ids):
                width_errors.append(line_number)
                raise ValueError(f"Unexpected matrix width at line {line_number}")
            if not np.all(np.isfinite(values)) or np.any(values < 0):
                raise ValueError(f"Nonfinite or negative count at line {line_number}")
            if np.any(values > 2**53 - 1) or np.any(values != np.floor(values)):
                raise ValueError(f"Noninteger or unrepresentable count at line {line_number}")
            totals += values
            detected += values > 0
            nonzero_entries += int(np.count_nonzero(values))
            maximum_count = max(maximum_count, float(values.max()))
            if gene in MARKERS:
                if gene in markers:
                    raise ValueError(f"Ambiguous duplicated allowlisted marker: {gene}")
                markers[gene] = values.astype(np.int64)
            if gene.startswith("MT-"):
                mitochondrial_genes.append(gene)
                mitochondrial_totals += values
            row_count += 1
    if duplicate_genes:
        raise ValueError(f"Duplicate feature identifiers: {duplicate_genes[:10]}")
    if not row_count or np.any(~np.isfinite(totals)) or np.any(totals > 2**53 - 1):
        raise ValueError("Empty matrix or nonexact/overflowing library totals")
    expected_counts = np.array([float(lookup[cell]["nCount_RNA"]) for cell in cell_ids])
    expected_features = np.array([float(lookup[cell]["nFeature_RNA"]) for cell in cell_ids])
    if not np.all(np.isfinite(expected_counts)) or not np.all(np.isfinite(expected_features)):
        raise ValueError("Metadata technical totals contain nonfinite values")
    counts_equal = totals == expected_counts
    features_equal = detected == expected_features
    missing_pre = sorted(pre_set - set(cell_ids))
    if missing_pre:
        raise ValueError("Concordant PRE IDs are absent from count matrix")
    groups = {"triple_concordant_MIA1_PRE": [i for i, cell in enumerate(cell_ids) if cell in pre_set]}
    for donor, state in sorted({(lookup[cell]["mia_ID"], lookup[cell]["timepoint"])
                               for cell in cell_ids if lookup[cell]["orig.ident"] == "MELCAP02"}):
        groups[f"MELCAP02_RNA_label_{donor}_{state}"] = [
            i for i, cell in enumerate(cell_ids)
            if lookup[cell]["orig.ident"] == "MELCAP02"
            and lookup[cell]["mia_ID"] == donor and lookup[cell]["timepoint"] == state
        ]
    sex_summary = {}
    for group, indices in groups.items():
        index = np.asarray(indices, dtype=int)
        entry = {"cells": len(indices), "zero_library_cells": int(np.sum(totals[index] == 0)),
                 "library_count_distribution": distribution(totals[index]), "genes": {}}
        for gene in ("XIST",) + Y_MARKERS:
            if gene not in markers:
                entry["genes"][gene] = {"status": "not_represented_in_matrix"}
                continue
            observed = markers[gene][index]
            positive = totals[index] > 0
            cpm = observed[positive] / totals[index][positive] * 1_000_000
            entry["genes"][gene] = dict(detected_cells=int(np.sum(observed > 0)),
                fraction_detected=float(np.mean(observed > 0)), raw_count_distribution=distribution(observed),
                cpm_distribution=distribution(cpm) if len(cpm) else None)
        if all(gene in markers for gene in Y_MARKERS) and "XIST" in markers:
            y_sum = np.sum([markers[gene][index] for gene in Y_MARKERS], axis=0)
            x_positive = markers["XIST"][index] > 0
            y_positive = y_sum > 0
            valid = totals[index] > 0
            entry["Y_panel"] = dict(genes=list(Y_MARKERS),
                any_detected_cells=int(y_positive.sum()), fraction_any_detected=float(y_positive.mean()),
                sum_raw_count_distribution=distribution(y_sum),
                sum_cpm_distribution=distribution(y_sum[valid] / totals[index][valid] * 1_000_000) if valid.any() else None,
                XIST_only_cells=int(np.sum(x_positive & ~y_positive)),
                Y_only_cells=int(np.sum(y_positive & ~x_positive)),
                both_detected_cells=int(np.sum(x_positive & y_positive)),
                neither_detected_cells=int(np.sum(~x_positive & ~y_positive)))
        sex_summary[group] = entry
    comparisons = {}
    pre = sex_summary["triple_concordant_MIA1_PRE"]
    if "Y_panel" in pre and "XIST" in pre["genes"]:
        for group, observed in sex_summary.items():
            if group == "triple_concordant_MIA1_PRE" or "Y_panel" not in observed:
                continue
            comparisons[group] = dict(
                XIST_detection_fraction_difference_from_PRE=observed["genes"]["XIST"]["fraction_detected"]-pre["genes"]["XIST"]["fraction_detected"],
                Y_panel_detection_fraction_difference_from_PRE=observed["Y_panel"]["fraction_any_detected"]-pre["Y_panel"]["fraction_any_detected"],
                interpretation="Descriptive marker-pattern comparison, not a donor assignment or genotype match")
    mito_percent = np.divide(mitochondrial_totals*100,totals,
                             out=np.full_like(totals,np.nan),where=totals>0)
    quality = (detected>=200) & (mito_percent<=20)
    refined_identity = {
        "definition_frozen_before_refined_readout": {
            "RNA_quality":"Actual exported detected genes >=200 AND actual MT-prefixed exported counts / full exported library counts *100 <=20",
            "confident_immune":"PTPRC >=2 UMI AND (>=2 detected T genes OR >=2 detected B genes OR >=2 detected myeloid genes)",
            "lineage_panels":{"T":["CD3D","CD3E","TRAC"],"B":["CD79A","CD79B","MS4A1"],"myeloid":["LST1","TYROBP","FCER1G"]},
            "marker_detected":"At least one observed UMI",
            "Y_support":"At least two distinct genes detected among RPS4Y1, DDX3Y, UTY, KDM5D, EIF1AY",
            "XIST_support":"At least one observed XIST UMI",
            "small_group_notice_threshold":20,"small_group_notice_is_eligibility_rule":False,
        },
        "actual_mitochondrial_genes":mitochondrial_genes,
        "metadata_percent_mito_used":False,
        "quality_fraction_denominator":"Exported assayed gene universe, not assumed identical to earlier metadata nCount_RNA universe",
        "groups":{group:immune_identity_summary(indices,quality,markers,totals,detected) for group,indices in groups.items()}
                 if mitochondrial_genes else {"status":"UNASSESSABLE_NO_MT_PREFIX_FEATURES"},
        "interpretation":"Independent lineage-restricted sex-chromosome RNA patterns can support an identity investigation; no genotype proof or automatic donor relabelling."
    }
    pre_index=np.asarray(groups["triple_concordant_MIA1_PRE"],dtype=int)
    pre_anchors=dict(
        rule="Same declared >=2-of-5-Y and XIST detection rules; no immune filter imposed on these separately labelled reference anchors",
        all_concordant_PRE=sex_identity_anchor(pre_index,markers,totals),
        quality_passing_concordant_PRE=sex_identity_anchor(pre_index[quality[pre_index]],markers,totals),
        limitation="These reference subsets need not be immune cells. Positive multi-Y RNA can support an identity investigation but is not a donor genotype match or automatic cohort GO.")
    marker_output.parent.mkdir(parents=True, exist_ok=True)
    with marker_output.open("x", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["cell_id", "orig.ident", "RNA_mia_ID", "RNA_timepoint", "count_sum", "detected_genes", "triple_concordant_PRE", "exported_MT_count_sum", "exported_MT_percent"]+list(MARKERS))
        for i, cell in enumerate(cell_ids):
            row = lookup[cell]
            writer.writerow([cell, row["orig.ident"], row["mia_ID"], row["timepoint"], int(totals[i]),
                             int(detected[i]), cell in pre_set,int(mitochondrial_totals[i]),float(mito_percent[i])]+[
                                 int(markers[gene][i]) if gene in markers else "NA" for gene in MARKERS])
    return dict(audit="Technical count identity and prespecified independent marker audit",
        created_utc=datetime.now(timezone.utc).isoformat(),
        software=dict(python=sys.version.split()[0],numpy=np.__version__,
                      script_sha256=file_sha256(Path(__file__))),
        status="STRUCTURE_PASS_METADATA_TECHNICAL_TOTALS_MATCH" if counts_equal.all() and features_equal.all()
               else "STRUCTURE_PASS_METADATA_TOTALS_MISMATCH",
        sources={"counts":dict(path=str(counts),bytes=counts.stat().st_size,sha256=digest.hexdigest()),
                 "RNA_metadata":dict(path=str(metadata),bytes=metadata.stat().st_size,sha256=file_sha256(metadata)),
                 "concordant_PRE_ids":dict(path=str(concordant_pre),sha256=file_sha256(concordant_pre),cells=len(pre_ids))},
        matrix=dict(genes=row_count,cells=len(cell_ids),unique_genes=len(genes),unique_cells=len(set(cell_ids)),
                    widths_valid=True,finite_nonnegative_integer_counts=True,nonzero_entries=nonzero_entries,
                    maximum_entry=maximum_count,zero_library_cells=int(np.sum(totals==0))),
        technical_metadata_comparison=dict(cell_sets_identical=True,cell_order_identical=cell_ids==metadata_ids,
            exact_nCount_RNA_matches=int(counts_equal.sum()),nCount_RNA_mismatches=int((~counts_equal).sum()),
            maximum_absolute_nCount_difference=float(np.max(np.abs(totals-expected_counts))),
            count_sum_minus_metadata=dict(less=int(np.sum(totals<expected_counts)),
                equal=int(counts_equal.sum()),greater=int(np.sum(totals>expected_counts)),
                distribution=distribution(totals-expected_counts)),
            exact_nFeature_RNA_matches=int(features_equal.sum()),nFeature_RNA_mismatches=int((~features_equal).sum()),
            maximum_absolute_nFeature_difference=float(np.max(np.abs(detected-expected_features))),
            detected_genes_minus_metadata=dict(less=int(np.sum(detected<expected_features)),
                equal=int(features_equal.sum()),greater=int(np.sum(detected>expected_features)),
                distribution=distribution(detected-expected_features)),
            mismatch_explanation="Unresolved; earlier feature filtering is a possible explanation, not verified."),
        identity_marker_allowlist=list(MARKERS),represented_markers=[g for g in MARKERS if g in markers],
        absent_markers=[g for g in MARKERS if g not in markers],sex_chromosome_marker_groups=sex_summary,
        quality_and_confident_immune_identity=refined_identity,
        PRE_identity_anchors=pre_anchors,
        limited_feature_presence_audit={g:g in genes for g in ("TRAC","TRBC1","TRBC2","IGKC","IGHM","IGLC1","IGLC2")},
        descriptive_group_comparisons=comparisons,
        ignored_local_marker_export=dict(path=str(marker_output),bytes=marker_output.stat().st_size,sha256=file_sha256(marker_output)),
        scientific_limits=["Counts/metadata technical agreement does not validate clinical donor labels.",
            "Sex-chromosome RNA is affected by dropout, composition, chromosome alterations and expression state; it is not genotype proof.",
            "No donor is automatically relabelled from these markers.",
            "Triple-concordant POST remains zero; this audit does not nominate a primary melanoma acquired-resistance cohort.",
            "Other lineage markers are exported for identity QC only and not summarized as functional programs.",
            "No IFN program, molecular survival program, differential expression or resistance effect was computed."],
        program_scores_computed=False,molecular_candidates_selected=False,elapsed_seconds=time.monotonic()-start)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--counts", type=Path, default=LOCAL / "quek_RNA_count.csv")
    parser.add_argument("--metadata", type=Path, default=LOCAL / "quek_metadata/Melanoma_RNA_metadata.csv")
    parser.add_argument("--concordant-pre", type=Path, default=Path("/tmp/quek-triple-concordant-MIA1-Pre.txt"))
    parser.add_argument("--marker-output", type=Path, default=LOCAL / "quek_identity_marker_counts.csv")
    parser.add_argument("--report", type=Path, default=Path(__file__).with_name("QUEK_COUNT_STRUCTURE_QC.json"))
    args = parser.parse_args()
    if args.report.exists() or args.marker_output.exists():
        parser.error("Preserve previous outputs; supply fresh paths")
    if not args.marker_output.resolve().is_relative_to(LOCAL.resolve()):
        parser.error("Per-cell identity-marker counts must remain in ignored local data")
    report = audit(args.counts,args.metadata,args.concordant_pre,args.marker_output)
    args.report.write_text(json.dumps(report,indent=2,allow_nan=False)+"\n")
    print(json.dumps({"status":report["status"],"matrix":report["matrix"],
                      "technical_metadata_comparison":report["technical_metadata_comparison"],
                      "marker_export":str(args.marker_output),"report":str(args.report)},indent=2))


if __name__ == "__main__":
    main()
