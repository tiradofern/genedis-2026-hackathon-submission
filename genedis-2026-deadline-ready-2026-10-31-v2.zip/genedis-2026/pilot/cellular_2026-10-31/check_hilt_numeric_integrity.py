"""Technical IMC integrity checks only; no patient/group/program effects.

Inspect all channels uniformly, never report marker means or program scores.
"""
import argparse
import json
from pathlib import Path
import resource
import signal
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--rds", required=True, type=Path)
p.add_argument("--receipt", required=True, type=Path)
a = p.parse_args()
resource.setrlimit(resource.RLIMIT_AS, (4 * 1024**3, 4 * 1024**3))
signal.alarm(180)
started = time.perf_counter()
import numpy as np
from rds2py.PyRdsReader import PyRdsParser

x = PyRdsParser(str(a.rds))
r = x.root_object
ld = r.load_attribute_by_name("assays").load_attribute_by_name("data").load_attribute_by_name("listData")
names = list(ld.load_attribute_by_name("names").get_string_arr())
arrays = {}
qc = {}
features = None
cells = None
for i, name in enumerate(names):
    m = ld.load_vec_element(i)
    dims = tuple(int(v) for v in m.load_attribute_by_name("dim").get_numeric_data())
    dn = m.load_attribute_by_name("dimnames")
    fn = list(dn.load_vec_element(0).get_string_arr())
    cn = list(dn.load_vec_element(1).get_string_arr())
    if features is None:
        features, cells = fn, cn
    if fn != features or cn != cells:
        raise RuntimeError("Assay names/order differ")
    values = m.get_numeric_data().reshape(dims, order="F")
    finite = np.isfinite(values)
    arrays[name] = values
    qc[name] = {
        "dimensions": list(dims), "dtype": str(values.dtype),
        "total_values": int(values.size), "nonfinite_values": int((~finite).sum()),
        "NaN_values": int(np.isnan(values).sum()), "positive_infinity": int(np.isposinf(values).sum()),
        "negative_infinity": int(np.isneginf(values).sum()),
        "nonfinite_by_channel": {f: int(n) for f, n in zip(features, (~finite).sum(axis=1))},
    }
    if name == "counts":
        qc[name]["negative_finite_values"] = int((values[finite] < 0).sum())

transforms = {}
if "counts" in arrays and "exprs" in arrays:
    expected = np.arcsinh(arrays["counts"])
    observed = arrays["exprs"]
    common = np.isfinite(expected) & np.isfinite(observed)
    transforms["exprs_equals_asinh_counts_cofactor_1"] = {
        "evaluated_values": int(common.sum()), "rtol": 1e-7, "atol": 1e-9,
        "allclose": bool(np.allclose(expected[common], observed[common], rtol=1e-7, atol=1e-9)),
        "missingness_identical": bool(np.array_equal(np.isfinite(expected), np.isfinite(observed))),
    }
if "exprs" in arrays and "zscaled" in arrays:
    expression = arrays["exprs"]
    expected = (expression - expression.mean(axis=1, keepdims=True)) / expression.std(axis=1, ddof=1, keepdims=True)
    observed = arrays["zscaled"]
    common = np.isfinite(expected) & np.isfinite(observed)
    transforms["zscaled_equals_R_row_scale_of_exprs_ddof_1"] = {
        "evaluated_values": int(common.sum()), "rtol": 1e-7, "atol": 1e-9,
        "allclose": bool(np.allclose(expected[common], observed[common], rtol=1e-7, atol=1e-9)),
        "missingness_identical": bool(np.array_equal(np.isfinite(expected), np.isfinite(observed))),
    }
q = {
    "audit": "Authorized Hiltbrunner uniform technical numeric/transform integrity only",
    "date": "2026-10-31", "input_file": a.rds.name,
    "verdict": "TECHNICAL_CHECKS_RECORDED_SCIENTIFIC_GO_NOT_ASSIGNED",
    "limits": {"address_space_GiB": 4, "alarm_seconds": 180},
    "features": features, "unique_cell_ids": len(set(cells)), "cells": len(cells),
    "assays": qc, "transformation_checks": transforms,
    "logcounts_transformation": "Not verified: no formula assumed from assay name",
    "not_checked": ["Antibody specificity/background or positivity thresholds", "Segmentation correctness",
                    "Cancer-cell purity of source labels", "Saturation against instrument calibration",
                    "Any program score, clinical-group contrast, candidate direction or resistance specificity"],
    "molecular_effects_or_program_scores_computed": False,
    "assay_values_written_or_printed": False,
    "elapsed_seconds": round(time.perf_counter() - started, 3),
    "peak_rss_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
}
a.receipt.write_text(json.dumps(q, indent=2) + "\n")
print(json.dumps({"assay_nonfinite": {k: v["nonfinite_values"] for k, v in qc.items()},
                  "transformation_checks": transforms, "receipt": str(a.receipt),
                  "elapsed_seconds": q["elapsed_seconds"], "peak_rss_KiB": q["peak_rss_KiB"]}))
