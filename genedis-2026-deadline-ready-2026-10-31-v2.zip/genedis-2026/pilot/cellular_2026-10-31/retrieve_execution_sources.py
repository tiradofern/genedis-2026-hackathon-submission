#!/usr/bin/env python3
"""Retrieve/verify exact public processed inputs; never overwrite conflicting data."""
from __future__ import annotations
import argparse
import hashlib
from http.client import IncompleteRead
import json
import os
from pathlib import Path
import tempfile
import urllib.request
import urllib.error

HERE = Path(__file__).resolve().parent
LOCAL = HERE.parents[1] / 'data/external/cellular_2026_10_31'


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def verify(path, item):
    if path.stat().st_size != item['bytes'] or sha256(path) != item['sha256']:
        raise ValueError(f'Exact source bytes/SHA256 mismatch; preserve and investigate: {path}')


class TruncatedRange(OSError):
    """A correctly labelled range whose transfer ended prematurely."""


def read_range(item, start, end):
    """Buffer one bounded, exact public HTTP206 range before committing bytes."""
    if start < 0 or end < start or end >= item['bytes'] or end-start+1 > 8*1024*1024:
        raise ValueError('Invalid or oversized byte range')
    request = urllib.request.Request(item['url'], headers={
        'User-Agent': 'GeNeDis-reproducibility/1.0', 'Accept-Encoding': 'identity',
        'Range': f'bytes={start}-{end}'})
    with urllib.request.urlopen(request, timeout=60) as response:
        expected = f'bytes {start}-{end}/{item["bytes"]}'
        if response.status != 206 or response.headers.get('Content-Range') != expected:
            raise ValueError('Incorrect range response; status/Content-Range must match exactly')
        remaining = end - start + 1
        blocks = []
        while remaining:
            block = response.read(min(8 * 1024 * 1024, remaining))
            if not block:
                raise TruncatedRange('Truncated source range')
            if len(block) > remaining:
                raise ValueError('Source range exceeded expected byte length')
            blocks.append(block)
            remaining -= len(block)
        if response.read(1):
            raise ValueError('Source range exceeded expected byte length')
    return b''.join(blocks)


def fetch(item, target, chunk_bytes, minimum_chunk_bytes=65536, maximum_range_attempts=8):
    """Fetch exact bytes; bounded range retries halve only transport failures.

    Incorrect range metadata/status and final SHA mismatches are hard failures.
    Failed partial ranges are never appended. Every successful range begins at
    the next actual byte; no missing byte is guessed or synthesized.
    """
    if chunk_bytes < 0 or minimum_chunk_bytes < 1 or maximum_range_attempts < 1:
        raise ValueError('Invalid bounded range settings')
    if chunk_bytes > 8 * 1024 * 1024:
        raise ValueError('Range buffering is bounded to 8 MiB per request')
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=target.name + '.', suffix='.part', dir=target.parent)
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, 'wb') as out:
            start = 0
            while start < item['bytes']:
                if chunk_bytes:
                    size = min(chunk_bytes, item['bytes'] - start)
                    floor = min(minimum_chunk_bytes, size)
                    for attempt in range(maximum_range_attempts):
                        end = start + size - 1
                        try:
                            block = read_range(item, start, end)
                            break
                        except urllib.error.HTTPError:
                            # An HTTP refusal/status error is not permission to try another route.
                            raise
                        except (IncompleteRead, urllib.error.URLError, OSError):
                            if attempt + 1 == maximum_range_attempts:
                                raise
                            size = max(floor, size // 2)
                    out.write(block)
                    start += len(block)
                    continue
                end = item['bytes'] - 1
                headers = {'User-Agent': 'GeNeDis-reproducibility/1.0', 'Accept-Encoding': 'identity'}
                request = urllib.request.Request(item['url'], headers=headers)
                with urllib.request.urlopen(request, timeout=60) as response:
                    if response.status != 200:
                        raise ValueError(f'Expected complete HTTP200 response for {target.name}')
                    remaining = end - start + 1
                    while remaining:
                        block = response.read(min(8 * 1024 * 1024, remaining))
                        if not block:
                            raise ValueError(f'Truncated source response: {target.name}')
                        out.write(block)
                        remaining -= len(block)
                    if response.read(1):
                        raise ValueError(f'Source response exceeded expected byte length: {target.name}')
                start = end + 1
        verify(temp, item)
        # Exclusive publication preserves a concurrent/previous output.
        os.link(temp, target)
    finally:
        temp.unlink(missing_ok=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest', type=Path, default=HERE / 'EXECUTION_SOURCE_MANIFEST.json')
    p.add_argument('--base', type=Path, default=LOCAL)
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument('--verify-only', action='store_true')
    mode.add_argument('--download', action='store_true')
    p.add_argument('--artifact', action='append', help='Exact relative artifact path; repeat to select a subset')
    p.add_argument('--chunk-bytes', type=int, default=0,
                   help='Initial exact HTTP206 range size, at most 8 MiB; failed transfers halve adaptively')
    p.add_argument('--minimum-chunk-bytes', type=int, default=65536,
                   help='Adaptive range floor; default 65536 bytes (64 KiB)')
    a = p.parse_args()
    if a.chunk_bytes < 0 or a.chunk_bytes > 8 * 1024 * 1024 or a.minimum_chunk_bytes < 1:
        p.error('Use 0..8 MiB initial chunks and a positive minimum chunk size')
    if not a.base.resolve().is_relative_to(LOCAL.resolve()):
        p.error('Keep source data under ignored local data')
    items = json.loads(a.manifest.read_text())['artifacts']
    if len({i['path'] for i in items}) != len(items):
        p.error('Duplicate artifact paths in source manifest')
    if a.artifact:
        if set(a.artifact) - {i['path'] for i in items}:
            p.error('Unknown requested artifact')
        items = [i for i in items if i['path'] in set(a.artifact)]
    for item in items:
        target = a.base / item['path']
        if not target.resolve().is_relative_to(a.base.resolve()):
            raise ValueError('Unsafe manifest path')
        if target.exists():
            verify(target, item)
        elif a.download:
            fetch(item, target, a.chunk_bytes, a.minimum_chunk_bytes)
        else:
            raise FileNotFoundError(target)
        print(json.dumps({'path': str(target), 'bytes': item['bytes'], 'sha256': item['sha256'], 'verified': True}), flush=True)


if __name__ == '__main__':
    main()
