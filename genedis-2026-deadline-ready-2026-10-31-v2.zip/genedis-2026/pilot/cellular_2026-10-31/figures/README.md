# RNA measurement figures and visual QC

These figures summarize completed, frozen-protocol RNA measurements. They do
not select or validate Molecular Survival Islands (MSIs). All 50 predefined
programs and all three independent patient identities remain visible in
alphabetical program order; no result-dependent ranking or highlighting was
used.

| Figure | Measurement | Interpretation |
| --- | --- | --- |
| `01_rna_program_activity.svg` / `.png` | Mean normalized gene rank after equal-cell mean full-library CPM | Continuous case-level relative expression, without an active/inactive cutoff |
| `02_rna_coordination_T.svg` / `.png` | Mean off-diagonal partial rank correlation across sampled cells | Conditional technical coordination diagnostic |
| `03_rna_coordination_excess.svg` / `.png` | Coordination minus matched-gene null mean | Conditional technical diagnostic adjusted for the frozen gene-matching background |

Gray `NA` means the frozen measurement criteria were not met; it does not mean
zero expression or absence of coordination. Coverage is assayed/original
membership for expression and common-variable/assayed membership for
coordination. Different cancer and platform contexts remain separate.

The primary definition includes 5,147 and 4,864 cells in the two MCC cases and
six cells in the melanoma case. Coordination uses at most 512 deterministically
sampled cells per case. The strict melanoma definition retains five cells and
has one residual degree of freedom, making the shared coordination endpoint
unassessable. All 50 rows remain visible in that sensitivity analysis. These
figures therefore support **no robust cross-cancer MSI nomination**. Individual
cells are not independent clinical patients; the conditional gene-matching
diagnostics do not establish patient-population significance, resistance
specificity, or a causal mechanism.

## Visual QC

All three final PNGs were visually inspected after rendering. Patient labels,
cancer labels, cell counts, residual degrees of freedom, all 50 program labels,
coverage, legends, explicit missing values, and the six-cell/five-cell
limitation are legible without clipping. The primary expression panel has 46
assessable programs, the primary coordination panel has 31, and the strict
shared coordination panel has zero; the complete family is retained throughout.
The SVG files preserve text and provide the same complete panels for export.

`figure_manifest.json` records input-result, generator, protocol, and engine
SHA-256 hashes; the two pre-effect freeze commits; image hashes; software
versions; program/patient order; color scales; claim limits; and visual-QC
checks. The visual-QC and frozen-context sections record this post-render
inspection and provenance attachment; they are separate from the numerical
analysis.

## Reproduction

Plotting uses a separate environment with CPython 3.12.14, NumPy 2.3.5, and
Matplotlib 3.10.8. Its pinned direct dependencies are in
`../requirements-figures.txt`; the frozen core environment was not changed.
From the repository root, supply the completed primary and strict result JSONs:

```bash
python pilot/cellular_2026-10-31/plot_program_measurements.py \
  --results PATH/primary_full_result.json \
  --sensitivity PATH/quek_three_gene_full_result.json \
  --output-directory NEW_FIGURE_DIRECTORY
```

Use a new output directory. The generator checks the complete testing family,
patient identities, explicit missing values, numeric ranges, and the fixed
melanoma-denominator caption. It never reads a study expression matrix or
selects candidates. Regeneration creates the figures and numerical provenance
manifest; repeat visual inspection before attaching a new visual-QC record.
