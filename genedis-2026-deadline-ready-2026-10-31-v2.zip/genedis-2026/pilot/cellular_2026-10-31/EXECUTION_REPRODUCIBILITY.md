# Reproducing the bounded cellular measurements

Run from the repository root on the reviewed `analysis/cellular-discovery-readiness-2026-10-31` revision. Use the final recorded commit when supplied; the branch name alone is mutable. This handoff preserves the earlier release, source files, clinical adjudication, frozen cell classifier and complete 50-program family. It neither reopens primary MSI nomination nor authorizes a protein-validation result.

## What is reproducible and what the result means

The current bounded execution measures fixed RNA programs in two acquired-resistant MCC specimens and the six lineage-positive putative melanoma cells retained by the frozen classifier. The stricter melanoma mask retains five cells. Its coordination sensitivity is unassessable under the existing model. Consequently, the primary robust MSI nomination remains inconclusive and the downstream independent NSCLC protein-validation stage is **not reached**. See [INDEPENDENT_EXECUTION_REVIEW.md](INDEPENDENT_EXECUTION_REVIEW.md) and [MEASUREMENT_PROTOCOL.md](MEASUREMENT_PROTOCOL.md). Numerical or transport reproducibility does not resolve this biological limitation.

The commands below describe a **fresh checkout/reconstruction**. In an existing workspace, use verification commands first and preserve previous outputs. The anchor/audit/classifier helpers refuse to overwrite prior outputs; choose fresh receipt paths rather than deleting historical artifacts. Do not regenerate or edit frozen protocols/gates to force a pass.

## Runtime and public inputs

The RNA execution environment is Python **3.12.14**, NumPy **2.3.3**, SciPy **1.16.2**. The two Python scientific dependencies are pinned in `requirements-app.txt`. On a fresh checkout with Python 3.12 available:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-app.txt
```

The separate RDS reader environment is needed only for the optional NSCLC structural/numeric check below. Its pinned dependencies and limitations are documented in [READER_REPRODUCIBILITY.md](READER_REPRODUCIBILITY.md). No R runtime, raw FASTQ/BAM, controlled-access approval or genome alignment is needed for the current RNA replay.

[EXECUTION_SOURCE_MANIFEST.json](EXECUTION_SOURCE_MANIFEST.json) contains canonical public URLs, exact lengths and SHA256 values for 12 processed inputs: two GEO MCC matrices; their TISCH cell annotations; Quek Mendeley v1 RNA counts, RNA/ADT metadata and four demultiplexing tables; and the Hiltbrunner Zenodo processed SCE. The full source RNA matrices are processed public inputs, not newly generated raw-sequence data. The Quek RNA source filename is `Melanoma_RNA_counts.csv`; its preserved local name is `quek_RNA_count.csv`. The first MCC source is `GSE117988_raw.expMatrix_Tumor.csv.gz`.

Retain the studies' original terms and citations; Quek Mendeley v1 is CC BY 4.0. This helper grants no additional rights. Large source files and cell-level derived inputs remain under ignored `data/` paths and must not be committed. Complete inputs total approximately 1.3 GB; allow additional space for derived arrays and temporary transfers. Network transfer time varies.

The first MCC source required exact HTTP206 ranges in this environment. Its successful historical transfer used actual bytes 0–65,535 and 1–524,287 with a verified 65,535-byte overlap, followed by validated larger ranges; three failed 512 KiB ranges were subdivided. No byte was inferred. The helper now starts at the requested range size and, on a truncated/network transfer, halves the same uncommitted range to a configurable 64 KiB floor, with at most eight attempts per starting offset. It buffers each complete range before appending, so failed partial transfers cannot duplicate or skip bytes. Incorrect HTTP status/Content-Range and final SHA256 mismatches are hard failures, not reasons to accept alternate bytes. Retrieve this file separately, then the remaining sources. Existing files must pass both exact length and SHA256; conflicting files remain unchanged and failed temporary files are removed.

```bash
.venv/bin/python pilot/cellular_2026-10-31/retrieve_execution_sources.py --download --artifact GSE117988_raw.expMatrix_Tumor.csv.gz --chunk-bytes 524288 --minimum-chunk-bytes 65536
.venv/bin/python pilot/cellular_2026-10-31/retrieve_execution_sources.py --download
.venv/bin/python pilot/cellular_2026-10-31/retrieve_execution_sources.py --verify-only
```

All 12 local inputs passed the verification command after this helper update. Eight hermetic tests cover complete/range transport, adaptive subdivision after failed large ranges, bounded persistent failures, incorrect ranges, corrupted bytes and no-overwrite behavior. Two small real public-range reads were checked against the already verified canonical file; the updated helper was not used to repeat the entire 13 MB download or any biological analysis. This does not guarantee future third-party uptime or that every server permits byte ranges; a changed source must be investigated rather than accepted under a new hash.

## Reconstructing the pretreatment identity anchor and cell mask

The historical audit used `/tmp/quek-triple-concordant-MIA1-Pre.txt`. That ephemeral file is **not required**. [regenerate_quek_pre_anchor.py](regenerate_quek_pre_anchor.py) rebuilds it from the hash-verified public tables by exact library-qualified cell IDs, requiring both RNA and ADT metadata to agree on `orig.ident`, `mia_ID`, `timepoint` and `RECIST`, and the provided demultiplexing table to name the same sample. RNA row order is preserved. No expression program or response-dependent cell threshold is used.

The regenerated anchor contains exactly **398 MIA1 pretreatment IDs**, 10,348 bytes, SHA256 `61b94721d2d408fdf584694afbb1dc4448853a0a9f17787d8981faa73f76abe3`, identical to the historical file. There are **zero** corresponding triple-concordant resistance IDs. These are checks against a particular fixed public release, not general clinical eligibility minima. The anchor supports the separately documented RNA sample-identity adjudication; consensus across reduced files is not independent proof of their correctness.

```bash
mkdir -p data/external/cellular_2026_10_31/replay_qc
.venv/bin/python pilot/cellular_2026-10-31/regenerate_quek_pre_anchor.py --output data/external/cellular_2026_10_31/quek_triple_concordant_MIA1_PRE.txt --report data/external/cellular_2026_10_31/replay_qc/PRE_ANCHOR.json
.venv/bin/python pilot/cellular_2026-10-31/audit_quek_count_identity.py --counts data/external/cellular_2026_10_31/quek_RNA_count.csv --metadata data/external/cellular_2026_10_31/quek_metadata/Melanoma_RNA_metadata.csv --concordant-pre data/external/cellular_2026_10_31/quek_triple_concordant_MIA1_PRE.txt --marker-output data/external/cellular_2026_10_31/quek_identity_marker_counts_anchored.csv --report data/external/cellular_2026_10_31/replay_qc/QUEK_COUNT_STRUCTURE_QC.json
.venv/bin/python pilot/cellular_2026-10-31/identify_quek_cells.py --input data/external/cellular_2026_10_31/quek_identity_marker_counts_anchored.csv --protocol pilot/cellular_2026-10-31/QUEK_CELL_ID_PROTOCOL.json --output data/external/cellular_2026_10_31/quek_cell_identity_mask.csv --report data/external/cellular_2026_10_31/replay_qc/QUEK_CELL_ID_QC.json
```

The full count audit streams the roughly 1.075 GB CSV. Its report records source dimensions, count validity, technical discrepancies and fixed sex-marker identity checks. The classifier uses independent lineage and exclusion markers rather than candidate functional genes. It should reproduce the six-cell primary and five-cell stricter MIA1 resistance masks and 99-cell primary pretreatment mask. Preserve any failure; do not retune to obtain larger cell counts.

## Reconstructing analysis inputs and replaying the frozen RNA calculation

```bash
.venv/bin/python pilot/cellular_2026-10-31/prepare_primary_rna.py --cohort all --quek-cell-mask data/external/cellular_2026_10_31/quek_cell_identity_mask.csv
.venv/bin/python pilot/cellular_2026-10-31/run_primary_rna.py --protocol pilot/cellular_2026-10-31/RNA_MEASUREMENT_PROTOCOL.json --gate pilot/cellular_2026-10-31/RNA_EXECUTION_GATE.json --output-dir data/processed/cellular_2026_10_31/replay_results
```

The preparation step validates all numeric source values, exact sample/barcode joins and frozen technical QC, then writes canonical cells-by-genes CSR arrays, gene identifiers, cell tables and receipts under `data/processed/cellular_2026_10_31/`. **The preparation command itself can overwrite existing derived files. Run these canonical-path commands only in a fresh checkout with no previous derived outputs; in an existing workspace, preserve those outputs and use a new `--output-dir` for reconstruction checks.** The analysis runner separately refuses a nonempty result directory. The canonical paths are intentional because the frozen manifest binds them.

`RNA_MEASUREMENT_PROTOCOL.json` points to the versioned **`FROZEN_PRIMARY_RNA_INPUT_MANIFEST.json`**, not the newly generated ignored manifest. Rebuilt receipts have new timestamps, so the ignored manifest's SHA256 will differ. The frozen historical snapshot retains the original scientific/input binding while the runner verifies that the reconstructed array, gene and cell files match its exact lengths/hashes. Do not copy a fresh manifest over that snapshot. A synthetic check in the pinned environment confirmed deterministic SciPy NPZ bytes with fixed ZIP timestamps. Any actual reconstructed-file mismatch is a stop for investigation, not permission to refresh the frozen hash.

The runner also verifies protocol/gate identity, exact protocol bytes, engine/wrapper hashes, full GMT membership, the complete 50-set family, the source cell mask and independent patient/cancer identifiers. It requires `GO_DESCRIPTIVE_CONDITIONAL` and `primary_nomination_enabled=false`. Its output directory must be fresh. The saved primary and stricter-mask outputs include complete JSON and per-patient/per-family CSV tables, coverage, conditional null statistics and provenance. Execution timestamps and timings may differ; the numerical measurements and fixed inputs should agree. Preserve unassessable endpoints and all negative results.

The Hallmark source GMT is already versioned under `pilot/programs/sources/`; use the exact GMT path and hashes in the frozen protocol. Do not substitute a newer gene-set release, score only a favourable subset, or treat a conditional gene-label P value as patient-population recurrence.

## NSCLC readiness and validation boundary

The source SCE is included in the source manifest for independent review of readiness. Optional numeric integrity recheck, which computes no program effects:

```bash
python3.12 -m venv /tmp/genedis-rds-reader-fixture-env
/tmp/genedis-rds-reader-fixture-env/bin/python -m pip install -r pilot/cellular_2026-10-31/requirements-reader-python.txt
/tmp/genedis-rds-reader-fixture-env/bin/python pilot/cellular_2026-10-31/check_hilt_numeric_integrity.py --rds data/external/cellular_2026_10_31/sce-clustering-allsamples-original_final.RDS --receipt data/external/cellular_2026_10_31/replay_qc/NSCLC_NUMERIC_QC.json
```

The published-patient mapping and original bounded MCD-footer provenance remain in `NSCLC_ID_CROSSWALK_QC.json`; [recover_hilt_crosswalk.py](recover_hilt_crosswalk.py) documents that separate procedure. Review its original receipts and clinical adjudication rather than infer patient IDs from molecular effects. The protein program-stage runner must **not** be invoked in this replay: `NSCLC_COMPONENT_PROTOCOL_PROPOSED.json` remains proposed and `NSCLC_COMPONENT_EXECUTION_GATE.json` is HOLD/not reached because no robust discovery program was nominated. Assay accessibility is not validation success. No protein effects are claimed by this handoff.

## Checks performed for this handoff

```bash
.venv/bin/python -m unittest discover -s tests -p test_cellular_execution_handoff.py -v
```

All eight transport-integrity checks passed, including adaptive failed-large-range recovery and fail-closed corruption/no-overwrite controls. The real public metadata regeneration reproduced the historical anchor byte for byte, and all 12 full source files passed length/SHA verification. This handoff update did not execute biological program analyses or inspect their results. Broader analysis-engine tests and actual execution receipts belong to their separately recorded runs.

No source data, prior output, frozen decision or submission archive was altered by the handoff. External submission, repository access changes, merge and author/organizer contact are separate investigator actions.

## Actual fresh reconstruction and analysis replay

[FRESH_RECONSTRUCTION_QC.json](FRESH_RECONSTRUCTION_QC.json) records a separate fresh-directory execution of anchor reconstruction, count/identity auditing, frozen cell classification and all three RNA preparations. All 15 checked payloads (anchor, marker export, full mask and 12 prepared files) matched their original SHA256 values. Sources were the already retrieved hash-verified public files; a second complete network retrieval was not performed. Receipt timestamps and output paths intentionally differ and are not scientific payload differences.

[RNA_EXECUTION_QC.json](RNA_EXECUTION_QC.json) separately records exact replay of the frozen analysis: all scientific JSON fields and all four CSV files agree, excluding only elapsed timings and the provenance creation timestamp. The final complete Python suite passed 95 tests, including eight transport-integrity tests; the frontend suite passed five. Numerical reconstruction and replay do not establish robust MSI discovery or complete the NSCLC validation stage.
