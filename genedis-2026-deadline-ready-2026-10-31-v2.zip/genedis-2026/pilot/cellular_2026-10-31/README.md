# Pan-cancer cellular program measurements — October 31, 2026

**Executed: fixed-program RNA measurements in two acquired-resistant cancers. Primary scientific outcome: inconclusive for robust Molecular Survival Island discovery. No MSI nominated; NSCLC validation not reached.**

Read the [results and interpretation](RESULTS_2026-10-31.md) first. Two independent MCC patients contributed 5,147 and 4,864 QC-passing cancer-labelled cells; one melanoma patient contributed six lineage-positive putative malignant cells. The stricter melanoma mask retained five and could not assess coordination. This limitation was established before effects and was not relaxed.

All 50 published Hallmark programs were retained: 46 supported descriptive activity and 31 supported the primary conditional coordination calculation. Oxidative phosphorylation crossed the prespecified **technical** BY threshold (q=0.044992), but it cannot qualify as an MSI because coordination robustness is unavailable and ordinary cancer/mitochondrial biology remains a plausible explanation. Cells do not add independent clinical patients. This run establishes neither population recurrence nor resistance specificity, selection, genomic conservation or causality.

## Review the evidence

- [Complete results](RESULTS_2026-10-31.md), [all-program patient table](results/primary_all_programs_by_patient.csv), [all-family conditional table](results/primary_conditional_by_family.csv), [full primary output](results/primary_full_result.json) and [stricter sensitivity](results/quek_three_gene_full_result.json).
- [Three complete-family figures](figures/README.md), with visible unavailable results and actual cell/patient denominators.
- [Frozen methods](MEASUREMENT_PROTOCOL.md), [machine-readable protocol](RNA_MEASUREMENT_PROTOCOL.json), [bounded execution gate](RNA_EXECUTION_GATE.json), [frozen input manifest](FROZEN_PRIMARY_RNA_INPUT_MANIFEST.json) and [exact replay/QC](RNA_EXECUTION_QC.json).
- [Independent pre-effect adequacy review](INDEPENDENT_EXECUTION_REVIEW.md), [scope review](MEASUREMENT_SCOPE_REVIEW.md), independent [RNA](CODE_REVIEW_RNA.md)/[protein](CODE_REVIEW_NSCLC.md) code reviews and [post-effect adversarial review](RESULTS_ADVERSARIAL_REVIEW.md). These are AI-assisted reviews, not Justin's personal sign-off.

## Reconstruct and rerun

Follow [EXECUTION_REPRODUCIBILITY.md](EXECUTION_REPRODUCIBILITY.md). It supplies exact public source URLs/hashes, deterministic identity-anchor reconstruction, the frozen cell classifier, technical preparation and complete-family calculation. Core RNA uses Python 3.12.14, NumPy 2.3.3 and SciPy 1.16.2. Source matrices and cell-level intermediates remain ignored; complete derived result tables and small representative artifacts are included. Exact independent replay matched all scientific fields and CSV bytes. Test/QC evidence distinguishes numerical reproducibility from biological validation.

[Fresh end-to-end reconstruction](FRESH_RECONSTRUCTION_QC.json) independently reproduced the identity anchor, marker export, full cell mask and all 12 prepared matrix/gene/cell/QC payloads exactly from the previously retrieved public inputs. The final Python suite passed 95 tests, with five frontend tests also passing. This does not repair the biological sampling limitation.

The frozen pre-effect commits are `74cf912` and `85b3694`. Do not edit a frozen protocol, input identity or threshold to rescue a favorable result. A future changed analysis requires a separate prospectively specified version.

## NSCLC and source limitations

The [NSCLC clinical crosswalk and numeric readiness](NSCLC_READINESS_EXECUTION.md) are now verified, but protein tumor-cell coverage is highly unequal and the panel has limited functional coverage. The [proposed component protocol](NSCLC_COMPONENT_PROTOCOL_PROPOSED.json) and [HOLD/not-reached gate](NSCLC_COMPONENT_EXECUTION_GATE.json) do not report protein effects. Three IFN-related proteins cannot validate a 200-gene RNA program; the oxidative-phosphorylation Hallmark has zero direct nominal gene-product overlap in this panel. No robust discovery candidate was available for the primary validation stage.

Source audits remain explicit: [MCC](MCC_METADATA_GATE.md), [Quek melanoma](QUEK_EXECUTION_GATE.md), [count/identity QC](QUEK_COUNT_STRUCTURE_QC.json), [frozen melanoma cell identification](QUEK_CELL_ID_PROTOCOL.json) and [observed cell coverage](QUEK_CELL_ID_QC.json). Conflicting Quek RNA/ADT/demultiplex labels and the baseline-site discrepancy remain preserved. Independent identity evidence supports the unmodified RNA mapping; it does not establish DNA-confirmed malignancy or complete malignant-cell recovery.

[Yang melanoma](YANG_MELANOMA_GATE.md) remains clinically uncertain and exploratory only; [origin-uncertain HNSCC](HNSCC_GATE.md) remains outside primary discovery. Neither was substituted to fill the cancer-type requirement. [Machine-readable readiness](readiness.json) separates source eligibility, completed measurements, inconclusive robustness and validation not reached.

## Preserved work and next step

The [earlier preparation record](PRE_EXECUTION_PREPARATION_RECORD.md), old negative gates, original LUAD/LUSC analyses, provisional programs, scientific release and frozen submission archive remain preserved. The existing NSCLC programs were not used for candidate discovery or circular validation. No repository access change, merge, author contact or organizer delivery was performed.

Next, obtain independently supported malignant-cell coverage and additional eligible patients before a new robust coordination/replication analysis. NSCLC follow-up needs an assay that measures the nominated function adequately. Comparator enrichment and experimental contribution are subsequent evidence levels, not conclusions of this run. This repository update is for investigator and Justin review; it does not automatically replace or submit the earlier hackathon package.
