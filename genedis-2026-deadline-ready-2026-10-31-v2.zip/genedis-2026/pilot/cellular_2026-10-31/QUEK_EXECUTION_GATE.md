# Quek melanoma: public access and clinical/sample gate execution

October 31, 2026. **Clinical acquired-resistance evidence recovered; public molecular access recovered; sample-identity reconciliation and malignant-cell identification still require adjudication. No automatic molecular GO.** This document records metadata/source work before program values or candidate selection. Source counts are not final eligible malignant-cell denominators.

## Verified clinical source

Quek et al., *Cell Reports* 2024, [DOI 10.1016/j.celrep.2024.114392](https://doi.org/10.1016/j.celrep.2024.114392), [original clinical Figure 1](https://ars.els-cdn.com/content/image/1-s2.0-S2211124724007204-gr1_lrg.jpg), and [Table S1](https://ars.els-cdn.com/content/image/1-s2.0-S2211124724007204-mmc2.xlsx) were verified. Table S1 is a valid 10,570-byte clinical XLSX (SHA256 `4225a281ee51bf7d76edeae313a6c6559e614111947d30166a96369589d23a9f`). The figure is a valid 351,784-byte JPEG (SHA256 `5dc393b00ad02d94e1ea3203222e334ea508485455726c567c96d8806723923c`). Ordinary public publisher requests with normal headers succeeded; no authentication, challenge solving or restricted-data access was used.

| Source clinical sample | Patient | Clinical annotation | Measurement/timing |
|---|---|---|---|
| Table S1 sample `P5` | MIA1, stage IV, BRAF V600E | Acquired resistance, RECIST PR, ipilimumab+nivolumab | Pretreatment; Table S1 says lymph node; CODEX/scRNA/CITE-seq |
| Table S1 sample `P4` | Same patient MIA1 | Acquired resistance, RECIST PR, ipilimumab+nivolumab | Post-treatment lymph node; scRNA/CITE-seq |

The clinical figure shows ipilimumab+nivolumab, partial response, progression and the post-treatment lymph-node biopsy labelled acquired resistance, followed by later progression and dabrafenib/trametinib. It supports a response-to-acquired-resistance sequence with the sampled resistance biopsy before the later targeted-regimen switch. Exact dose dates or duration must not be inferred from diagram spacing. This is stronger source-defined acquired-resistance evidence than a bare post-treatment or PFS label.

**Baseline-site discrepancy:** Figure 1 depicts the pretreatment MIA1 biopsy as subcutaneous; Table S1 calls it lymph node. Post-treatment lymph node agrees. Retain both records. Prefer resistant-state recurrence initially; do not assert a same-site longitudinal pair or attribute a paired change to therapy without resolving the baseline.

## Distinct sample-ID namespaces

The [GitHub sample map](https://github.com/cameliaquek/singlecell_spatial_multiomics/blob/main/samples/sampleid) has a **CODEX ID** column. Its CODEX `P4` is MIA8 pretreatment, with no scRNA; that must not override Table S1's scRNA/CITE sample `P4` for MIA1 post-treatment. Namespaces must remain explicit.

The unambiguous RNA mapping in that map is `MIA1_PRE → MIA1a`, and `MIA1_PROG → MIA1b` with no CODEX ID. Public RNA metadata report MIA1a/Pre/MELCAP01, 687 cells, and MIA1b/Post/MELCAP02, 1,768 cells. **Those source RNA labels are not automatically trusted because the cross-file metadata joins below reveal a substantial discrepancy.** Cross-file agreement does not establish independent derivation.

## Public-access route recovered

The [CC BY 4.0 public dataset](https://data.mendeley.com/datasets/w55dvbb82f/1), DOI `10.17632/w55dvbb82f.1`, is accessible with ordinary public requests. Inspecting the site's public client bundle identified its actual file-list endpoint:

```text
https://data.mendeley.com/public-api/datasets/w55dvbb82f/files?folder_id=root&version=1&$start=0&$limit=1000
```

Use `Accept: application/vnd.mendeley-public-dataset.1+json`, a normal User-Agent and the public dataset-page Referer. The manifest returned HTTP 200 and eight completed files. The `/versions/1/files` path attempted earlier is not this client's route. Public version metadata confirms version 1 is available. No OAuth token was supplied or required for this public route.

| Public asset | Bytes | Role |
|---|---:|---|
| `Melanoma_RNA_counts.csv` | 1,075,482,773 | Public RNA values; not downloaded or inspected by this audit |
| `Melanoma_RNA_metadata.csv` | 1,137,371 | 15,913 unique cell IDs, library, source patient/timepoint/RECIST and QC fields |
| `Melanoma_ADT_counts.csv` | 6,320,627 | Public protein counts; no values inspected by this audit |
| `Melanoma_ADT_metadata.csv` | 1,354,824 | 19,516 cell IDs and clinical/library/QC fields |
| Four `Melanoma_sample-barcode_0*.tsv` files | 181,306–472,315 each | Source sample-demultiplex assignments; exact algorithm/final clinical mapping provenance remains unresolved |

All six small metadata/assignment files were retrieved into ignored `data/external/cellular_2026_10_31/quek_metadata/` and exactly match the manifest SHA256 values. The manifest, all stable public URLs, lengths/hashes and detailed joins are in [QUEK_METADATA_RECEIPTS.json](QUEK_METADATA_RECEIPTS.json). The RNA file's expected SHA256 is `bdbd958782d6ea82e628d48adac67a1cc1372663e051198c2edbce8e6c82a662`. Raw EGA sequencing remains a separate controlled resource; it was not accessed.

## Critical sample-label discordance

The public RNA metadata and ADT metadata share **9,041 exact cell identifiers**, but only **748** have the same source patient label. These are not raw expression differences. They are metadata disagreements within the same library/barcode namespaces.

For MELCAP02:

- Source RNA-labelled MIA1b/Post contains 1,768 cells. Their supplied demultiplex assignments are 1,281 `MIA11Pre`, 126 `MIA1Post` and 361 mixed `0/1` or `1/0`.
- Source RNA-labelled MIA11a/Pre contains 3,643 cells, of which 2,579 are assigned `MIA1Post` in the supplied demultiplex table.
- ADT-labelled MIA1b/Post agrees with `MIA1Post` for 2,632/2,694 cells; ADT-labelled MIA11a/Pre agrees with `MIA11Pre` for 1,629/1,654 cells.
- Among shared RNA/ADT IDs, 973 RNA-labelled MIA1b cells are ADT-labelled MIA11a, while 1,353 RNA-labelled MIA11a cells are ADT-labelled MIA1b.

Other libraries also show strong RNA/ADT patient-label discrepancies. Do not use RNA `mia_ID` alone to select resistant cells, silently swap labels, or treat molecular clustering as proof of sample identity. Preserve the source RNA label, source ADT label and source demultiplex assignment separately.

A possible **prospective technical identity reconstruction**, requiring independent adjudication, is the intersection of: RNA library MELCAP02, supplied demultiplex assignment `MIA1Post`, and the same cell ID labelled MIA1b/Post in the ADT metadata. This intersection contains **1,335 RNA cell IDs**. It is a proposed sample-identity set, **not a validated identity or malignant-cell set**. ADT labels and the TSV assignments may share one upstream derivation; RNA labels could reflect a later corrected mapping. Agreement is not a majority-vote ground truth. Ambiguous/mixed assignments and disagreement must remain excluded or separately reported. Count-matrix header identity, QC-field correspondence and independent mapping provenance must be verified before adopting it. No reconstruction is adopted automatically in this record.

The source notebook schema contains HTO and SoupCell/SNP assignment fields, which are absent from the released reduced metadata. The only explicit source HTO-to-clinical map recovered here is `MIA11_PROG → MELCAP04_HTO5`; no MIA1 progression tag was verified. The small public ADT count file was subsequently retrieved with permission for **identity-assay feature inventory only**: it contains 131 CITE antibody rows and 19,516 cell columns, but **no hashtag/HTO count rows**. No functional protein values were inspected. Table S1 contains no sex field. Sex-marker or other genotype-independent checks require an adequately anchored clinical/reference identity; expression levels of BRAF or NRAS cannot establish their mutation genotypes.

**Unrelabelled three-source consensus:** requiring RNA `MIA1b/Post/MELCAP02`, ADT `MIA1b/Post` and supplied assignment `MIA1Post` simultaneously yields **zero post-treatment cells**. Requiring the corresponding pretreatment MIA1a/Pre/MELCAP01 identity yields 398 cells. Therefore there is no already-agreeing resistant subset that can be used without resolving the label conflict. The 398 pretreatment cells may provide a technical identity reference, but cannot themselves supply an acquired-resistance specimen. No subset size or agreement rule is relaxed to force a molecular result.

## Malignant-cell identification remains distinct

The retrieved metadata do **not** contain cell-type, tumour/malignancy or published cluster labels. The [final Table S2A marker inventory](https://ars.els-cdn.com/content/image/1-s2.0-S2211124724007204-mmc3.xlsx) (11,196 bytes; SHA256 `cfc2c676ee78e69d029004f231aacf848de7b355d3e2d1d3bec491a7fcf04fa2`) describes tumour melanocyte subtypes and markers, not barcode assignments. Its canonical lineage markers include MITF, MLANA, PMEL and DCT, with SOX10 imaging correspondence. Some listed state markers overlap IFN pathways and must not be used to select cells when testing those same functions.

The public [STEP0 script](https://github.com/cameliaquek/singlecell_spatial_multiomics/blob/main/scripts/STEP0-CITEseqv2.Rmd) uses joint RNA/ADT clustering and SingleR/BlueprintEncode annotation, and exports an annotated metadata file to a local path. That export is not among the eight released assets. The posted script contains an apparent syntax issue and starts from an unprovided integrated RDS; it cannot be run blindly as a complete reconstruction recipe.

A reliable existing barcode annotation or a prospectively frozen, source-compatible, independently checked malignant-cell identification method is still necessary. It must not classify cells using the candidate program's activity, invent DNA-confirmed malignancy or count every clinical biopsy cell as cancer. A generic spatial H5AD for MIA11 is not a substitute for MIA1 acquired-resistance cell labels.

## Additional public provenance checks

The official [Mendeley version history](https://data.mendeley.com/public-api/datasets/w55dvbb82f/versions) lists only available version 1, published May 13, 2024. No later published correction resolving the patient-label conflict was found. The metadata/upload dates are not evidence that one conflicting mapping is correct.

The [public Git LFS spatial H5AD](https://media.githubusercontent.com/media/cameliaquek/singlecell_spatial_multiomics/main/inputs/P1_Transferred_092022_1.h5ad) was inspected through seven bounded HTTP 206 range requests totaling 419,162 bytes of a 1,985,307,994-byte file. No expression array was accessed and the full-file checksum was not verified. Its `obs` fields are only `TransferredLabels`, `__categories`, `_index`, `leiden`, `size`, `x`, `y` and `z`; it has no HTO, SoupCell, SNP or original RNA donor metadata. This is the spatial target, not a recovered source-RNA reference or a substitute acquired-resistance specimen.

The documented anonymous [EGA public sample-metadata endpoint](https://metadata.ega-archive.org/studies/EGAS50000000339/samples?limit=1000) lists four pooled RNA sequencing libraries, EGAN50000055519–EGAN50000055522. Each has `biological_sex: unknown`; these records provide no patient-specific sex anchor. Only open metadata was accessed; controlled sequencing files were not accessed.

## Gate status

Clinical source-defined MIA1 acquired resistance and public processed access are now genuinely supported. The remaining technical requirements are RNA-count identity/QC verification, resolution of the metadata discordance, and defensible malignant-cell identification. These are concrete technical gates, not a reason to conflate source RNA-labelled MIA1b with an unquestioned resistant-cell set.

The complete pan-cancer combination is not opened by this document. No expression/protein values, program scores, candidate nominations or cross-cancer biological conclusions were generated here. Retain primary/exploratory separation, independent patients and all adverse source findings.

### Subsequent structural preparation

After independent technical identity review, the build lead directed retention of the **unmodified author RNA mapping**, rather than majority-vote correction from ADT/TSV labels. The prospectively frozen [cell-identity protocol](QUEK_CELL_ID_PROTOCOL.json) and its [classification QC](QUEK_CELL_ID_QC.json) identify **six** MIA1b/Post lineage-positive putative malignant cells (five under the three-gene sensitivity). The sparse structural ingest preserves these six cells, all source genes and actual count-derived QC without functional program scoring. This is a deliberately small, incompletely sampled lineage-positive population; it does not establish complete malignant-cell recovery or adequate precision for coordination inference. The adverse metadata findings above remain part of the audit trail. Read any later full-gate adjudication separately from this initial access/discordance record.
