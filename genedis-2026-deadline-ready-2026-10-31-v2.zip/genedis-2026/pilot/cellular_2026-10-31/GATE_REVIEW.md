# Gate review and additional public-source checks

October 31, 2026. This records an independent AI-assisted adversarial review and source-metadata checks. It is not Justin's personal sign-off, a molecular analysis or a completed systematic literature review.

## Investigator's latest decision

The investigator requested maximum-effort execution, then explicitly chose: **keep the full pan-cancer requirement and continue feasibility work before molecular analysis**, rather than substitute an NSCLC-only pilot. The objective remains malignant-cell program discovery in at least two non-NSCLC cancers with documented acquired resistance, followed by independent NSCLC testing under a prospectively justified comparable treatment family. No molecular candidates have been selected.

## Corrections to overly restrictive gate interpretations

| Question | Governing interpretation |
|---|---|
| How many patients per cancer? | No universal number is approved. The [D04 decision](../../reviews/PI_DECISIONS_FOR_JUSTIN_2026-10-31.md) specifies breadth across at least two cancer types, not a two-patient rule. A single case in a cancer can contribute descriptive cross-cancer occurrence; it cannot establish within-cancer reproducibility. Eligible, measurable and adequately informative for a proposed claim are different statuses. |
| Must therapies be identical? | No. Define a mechanistically defensible family prospectively. Combination status, sequence and additional therapies require explicit strata and limit attribution; they do not automatically disqualify a cohort. For example, a KRASG12C-inhibitor-containing family may include dual KRAS/EGFR treatment, if justified before effects. Pooling every targeted agent is insufficiently specific. |
| Must every assay be whole-transcriptome RNA? | No. Targeted cell-resolved RNA can qualify if program coverage and measurement compatibility are adequate. Cell-resolved protein might support an explicitly specified orthogonal program endpoint, but is not automatically RNA-program replication. A single marker cannot stand in for a distributed coordinated program without a justified measurement model. |
| Must processed files be public without login? | No. Ordinary sign-in is distinct from controlled-access approval. Legitimately accessible raw data can qualify if reconstruction is actually feasible within resources and time. Missing a processed-file route is a practical readiness issue, not proof of biological unsuitability. No new controlled-access applications or unauthorized access are permitted. |
| Must a program increase or occupy most cancer cells? | No. Pre-existing programs and small malignant populations remain eligible. No universal cell-count threshold or majority-cell rule is adopted. Measurement uncertainty and technical adequacy must be reported. |
| Must responders or baseline samples exist? | No for resistant-state recurrence. They enable separate enrichment or temporal questions. Clinical histories still must establish initial benefit followed by progression. Convincing source-supported chronology can suffice without exact calendar dates or mandatory formal RECIST labels. |

These corrections remove unapproved restrictions. **They do not themselves verify the missing complete dataset combination or authorize candidate selection.** Broad RNA validation, cross-modal biological validation and clinically demonstrated resistance mechanisms remain distinct conclusions.

## Additional source checks

### NSCLC targeted-therapy lead: Maynard 2020

The [primary article](https://pmc.ncbi.nlm.nih.gov/articles/PMC7484178/) links the [author analysis repository](https://github.com/czbiohub-sf/scell_lung_adenocarcinoma), which links a genuinely public [Drive input folder](https://drive.google.com/drive/folders/1sDzO0WOD4rnGC7QfTKwdcQTx3L36PFwX). Its listing contains a count CSV, cell-level clinical metadata and processed objects. **The count matrices and expression objects were not downloaded.** The small clinical metadata and [inferCNV cell annotations](https://github.com/czbiohub-sf/scell_lung_adenocarcinoma/blob/master/data_out/NI03/results/inferCNV_annotation.csv) were inspected as metadata.

The source clinical CSV includes patient/specimen IDs, treatment, response, sampling-state and timing fields. These fields must be anchored to the correct treatment episode: some PD biopsies precede the listed next treatment's start. Therefore PD plus a response or PFS field is not an automatic acquired-resistance rule.

Three candidate EGFR progression records have prior PR fields. Their measurement/histology audit substantially limits a possible pilot: one has no tumor-labelled cells in the inspected annotation; one has 17 and a small-cell-transformation note; the longitudinal same-site osimertinib case has 13 at progression and squamous transformation described in the paper. These are **source-annotation counts, not a chosen cell-number cutoff or fully eligible analysis denominators**. Intervening therapy and post-progression sampling gaps also remain unresolved. They do not provide two non-NSCLC discovery cancers. The investigator declined an NSCLC-only replacement.

Clinical CSV receipt: 11,084,633 bytes, SHA256 `b4f3f169516001e89bc8b3d8052e207331ff662ca6d236e1c2cf68eccffdf2a6`. It was retrieved from the author's publicly linked Drive file `12g84ooMTsWV58JWbp2ql8TMfgS4ct8as`; the local metadata cache is excluded from this review. The deposited source inventory and paper's filtered cohort are not assumed identical without reconstruction.

### Three-cancer CJRB-101 trial: wrong biological material

The [2026 trial article](https://pmc.ncbi.nlm.nih.gov/articles/PMC13182499/), DOI `10.1136/jitc-2025-014702`, includes NSCLC, HNSCC and melanoma participants. However, the genuinely public [Figshare manifest](https://api.figshare.com/v2/articles/30969202) lists `YHIM2004_scRNAseq.rds`, **1,917,130,143 bytes**, MD5 `a3cdd7a07aae1b60c2c605df6b087b23`, CC BY 4.0. The study methods identify this as a humanized NSCLC patient-derived xenograft experiment, not single-cell biopsies from the three clinical cancer cohorts. Clinical refractory eligibility also does not require initial benefit. The file was not downloaded; public availability does not cure the material/phenotype mismatch.

### Other accession safeguards

- [GSE173647 HNSCC](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE173647), [primary paper](https://pmc.ncbi.nlm.nih.gov/articles/PMC8547513/): two patients are multiplexed into each pre/post library; a public patient-barcode crosswalk and prior-benefit history were not verified. Libraries cannot be counted as two independent pairs.
- [ATC BRAF/MEK study](https://pmc.ncbi.nlm.nih.gov/articles/PMC13293951/): one convincing acquired-resistance case is a legitimate cross-cancer lead, not automatic ineligibility. Actual accessible processed RNA and suitable NSCLC validation remain unverified; generated data are EGA-listed.
- [DESTINY-Gastric06](https://pmc.ncbi.nlm.nih.gov/articles/PMC12856360/): a credible acquired-resistance HER2-ADC lead; public processed access, clinical crosswalk and the other required cancer/NSCLC contexts are unresolved.
- [GSE150949](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE150949) is a cell-line/persister experiment; [GSE171145](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE171145) is treatment-naive; [GSE148466](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE148466) lacks verified acquired-resistance histories; [GSE253718](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE253718) has three resistant-labelled clinical specimens but no verified initial-benefit chronology in inspected records. None is promoted to clinically acquired-resistant solely by an accession title.

## Current outcome

The complete qualifying combination is **not yet verified**, including after correcting the overrestrictions above. This is an unresolved feasibility result, not a negative molecular finding or proof that suitable data do not exist. Preserve the [detailed follow-up](FEASIBILITY_FOLLOWUP.md), all earlier negative findings and the frozen NSCLC release. The metadata audit is not automatically substituted for the requested molecular-discovery deliverable.

## Strongest combination under assessment after the follow-up

**Superseding PI adjudication:** Yang 509 is exploratory only and does not count toward primary feasibility. Protein measurement is approved as an option, but not a completed endpoint validation. The table below describes technical leads, not a qualifying primary combination. See [clinical eligibility](CLINICAL_ELIGIBILITY.md), [actual metadata-reader results](READER_REPRODUCIBILITY.md) and the additional [HNSCC gate](HNSCC_GATE.md). The HNSCC origin-dependent case is also not currently counted toward the strict primary gate.

| Role | Public source and evidence | Still unresolved before a molecular GO |
|---|---|---|
| Melanoma discovery | [Yang GSE269936](YANG_MELANOMA_GATE.md): RECIST-linked responder under pembrolizumab, observed PFS event at day 1,126, POST specimen at day 1,130; public processed counts and authors' tumor annotations in a large public R object | Strongly supported **source-inferred/probable acquired resistance**, rather than an explicit source AR label. Exact on/off-treatment/intervention-to-biopsy state is unresolved. The specimen-specific malignant barcode crosswalk has not been extracted from the 3 GB object or technically verified. |
| MCC discovery | [Two independent acquired-resistance cases](MCC_METADATA_GATE.md); public count headers and TISCH malignant labels recovered. The second patient's entire annotation-to-header join is verified; source tissue restricts it to 4,969 labelled malignant tumor cells | First-patient TISCH timing is mislabeled: proposed correction to day +615 is supported by original GEO and unique source sample sizes, but the full cell-ID join/adjudication remains pending. Retain original fields and correction provenance. Source-defined and curated malignant subsets differ. |
| Independent NSCLC test | [Hiltbrunner seven-patient cell-resolved protein resource](ORTHOGONAL_NSCLC_GATE.md), with public SCE object, tumor-label code and 39 independently measured metal channels | Faithful S4 extraction, usable tumor cells, independent tumor-label sensitivity and a prospectively justified restricted program-to-protein mapping remain unverified. This is a proposed **orthogonal component test**, not full RNA-program replication. |

A PD-(L)1-inhibitor-containing family could be prospectively justified, with monotherapy, dual-checkpoint and adoptive-cell combinations explicitly separated. This table does not adopt that family, select a panel or turn unknown treatment histories into verified facts. The NSCLC measurement question is a consequential endpoint decision for investigator review.

An additional [Sequential NCI-CLARITY source, GSE229772](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE229772), linked to [Revsine et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC10897542/), supplies public cell-subtype metadata and longitudinal HCC/iCCA profiles. Eleven patients and 31 biopsies are source inventories; late HCC biopsies do not by themselves prove acquired resistance. Individual initial-benefit/progression histories remain unverified. It is retained as a clinical-metadata lead, not an alternative accepted cohort.

The TISCH2 follow-up found no qualifying NSCLC checkpoint acquired-resistance RNA source among its immunotherapy-labelled entries: GSE146100 concerns one patient's induction-treated nodules; GSE151537 and GSE176021 concern T cells/pretreatment or neoadjuvant settings. This bounded resource check is not proof of global data absence.
