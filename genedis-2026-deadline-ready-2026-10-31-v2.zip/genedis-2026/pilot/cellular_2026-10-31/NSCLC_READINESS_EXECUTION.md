# Executed NSCLC readiness checks — October 31, 2026

## Outcome

**The clinical-to-processed identifier crosswalk is now verified for all seven Hiltbrunner cases, and uniform numeric/transform integrity checks pass.** These resolve concrete access/QC obstacles. They do not select candidates, freeze a protein panel or assign scientific GO. No program score, clinical-group contrast, candidate direction, resistance enrichment or functional effect was calculated.

The PI authorized NSCLC protein measurements for validation of program components they can reliably measure. The full design remains at least two non-NSCLC discovery cancers followed by independent NSCLC testing in a prospectively justified treatment family. This document concerns the NSCLC arm only; it neither substitutes an exploratory cohort into primary discovery nor changes clinical acquired-resistance criteria.

## Verified identifier crosswalk from independent source metadata

The deposited SCE uses internal patient IDs 2/4/5/9/11/12/14; the publication uses P1–P7. The mapping below was **not inferred from ordinal position, cell phenotypes or molecular results**.

For each of the 14 publicly named `P#_response.mcd` / `P#_resistance.mcd` files in [Zenodo 8041882](https://zenodo.org/records/8041882), a bounded HTTP 206 request retrieved only the last 1 MiB. The MCD XML schema's `Slide.Filename` exposes the original specimen block filename. Those block IDs were matched exactly to `SampleID` in the already extracted SCE column metadata. No image or intensity payload was decoded and no full MCD was downloaded. Local XML excerpts remain in ignored data storage; the versioned [NSCLC_ID_CROSSWALK_QC.json](NSCLC_ID_CROSSWALK_QC.json) records source URLs, ranges, byte/hash receipts and matches. [recover_hilt_crosswalk.py](recover_hilt_crosswalk.py) reproduces the procedure.

| Publication case | Internal SCE ID | Pre source-Tumour cells | Resistance source-Tumour cells | Checkpoint history | Supplementary Table 1 time to resistance |
|---|---|---:|---:|---|---:|
| P1 | 2 | 71 | 5,497 | Nivolumab | 10 months |
| P2 | 4 | 9 | 79 | Nivolumab/ipilimumab, then nivolumab after ipilimumab toxicity | 6 months |
| P3 | 5 | 16 | 2 | Nivolumab; prior BRAF/MEK therapy and radiation | 7 months |
| P4 | 9 | 222 | **0** | Nivolumab; prior chemotherapy/radiation | 9 months |
| P5 | 11 | 172 | 5 | Pembrolizumab with brain-radiation history | 8 months |
| P6 | 12 | 15 | 1,483 | Nivolumab; prior chemotherapy/radiation | 8 months |
| P7 | 14 | 4,453 | 3,355 | Nivolumab; prior chemotherapy | 15 months |

**One source-header exception is retained:** 13 of 14 MCD public state labels agree with the matched SCE specimen state. The P6 response MCD's `Slide.Filename` still names `NB17-597-1`, the resistance block; its resistance file names `NB17-597-1_real`. Both identify processed patient 12. P6's case identity is therefore independently supported by the resistance file, but the public response-file header does not independently verify its earlier specimen `NB13-417-1`. Earlier-specimen linkage currently relies on the SCE's same-patient identity and pre label. Do not call all 14 file-state headers consistent or silently repair the source header. A strict paired analysis should resolve or separately exclude this unresolved earlier-specimen provenance before using its paired change.

Counts in this table are **source annotation counts**, not inferred program prevalence, proof of malignancy or independent sample sizes. Zero cancer cells is missing program measurement, not absence of a survival strategy. The object supports seven patient pairs structurally, at most six resistance profiles with any source-Tumour cells, and fewer may support a reliable coordinated-protein endpoint. No universal tumor-cell threshold or final usable n is imposed here; those depend on the frozen endpoint, precision and technical sensitivities before effects.

## Clinical source and remaining chronology limits

The [primary publication](https://pmc.ncbi.nlm.nih.gov/articles/PMC10449840/) states that all seven patients initially responded and subsequently developed resistance, with response assessment using **iRECIST**. This supplies cohort-level acquired-resistance evidence; these are not merely scheduled on-treatment or primary-nonresponse samples. The identifier crosswalk now permits individual treatment histories to be attached to the processed patients without guessing.

The official supplement was recovered from [BioStudies S-EPMC10449840](https://www.ebi.ac.uk/biostudies/files/S-EPMC10449840/41467_2023_40745_MOESM1_ESM.pdf): 3,688,683 bytes; SHA256 `f9df949ccb84308b0e25144ecbb4f216d860d6330d099b89adb5a9f5e426a5e4`. Only the clinical Table 1 on page 11 was inspected for this readiness step. It lists the durations above and treatment-line categories.

Do not force consistency where sources differ: the main text reports seven months for P5 versus eight in the supplementary table; P3/P4/P6 are described by cycle counts in the narrative that do not directly reproduce the supplementary month values without additional timing information. P3's diagnosis stage also differs between narrative and table. Record these as chronology/source uncertainties rather than inventing dates or converting cycle counts using an assumed schedule. Precise individual response categories, calendar progression/biopsy dates and local/intervening therapy timing are not all established by this table. The study-wide initial-benefit/progression statement remains meaningful; exact therapy-specific duration exclusions require adjudication of these uncertainties.

The source calls the earlier tissue “Response,” but Methods clarifies that it was obtained **before ICI began**; several initial specimens preceded other treatments. Thus these labels are not biopsies collected while responding to ICI. Pretreatment-to-resistance changes can span chemotherapy, radiation and site changes. Resistance-only recurrence and an index-therapy paired temporal effect are distinct endpoints. Treatment strata remain five nivolumab, one pembrolizumab/radiation-history case and one sequential nivolumab/ipilimumab→nivolumab case; additional agents are not silently removed from their histories.

## Executed technical numeric checks

[NSCLC_NUMERIC_QC.json](NSCLC_NUMERIC_QC.json), generated by [check_hilt_numeric_integrity.py](check_hilt_numeric_integrity.py), records a single bounded 4 GiB / 180-second process. It completed in approximately **2.4 seconds** with approximately **721 MiB peak RSS**. Every channel was checked uniformly; no hypothesis-selected feature or clinical group was summarized.

- All four assays have identical feature/cell order and shape **41 × 99,659**.
- **16,344,076 total assay values checked** across `counts`, `exprs`, `logcounts`, `zscaled`: no NaN, positive/negative infinity or other nonfinite values.
- For all **4,086,019** entries, `exprs` agrees with `asinh(counts)` at cofactor 1 within rtol 1e-7 / atol 1e-9, including matching finite masks.
- For all **4,086,019** entries, `zscaled` agrees with R-style per-channel centering/scaling of `exprs` using sample SD (ddof 1), at the same tolerances. The centering/scaling constants were used only to verify a deposited transformation, not reported as biological summaries.
- `logcounts` is finite; its transformation was **not** assumed or verified from its name.
- No raw assay values, marker means, group summaries, score distributions or effect sizes were printed or written.

The matrix contains 39 independent antibody channels plus two DNA stains (Iridium/Iridium2). The reagent list has 41 antibody rows because two keratin reagents share one channel and CD31/vWF share another. These distinct counts must not be conflated. Numeric integrity does not establish analytical specificity, positivity above background, segmentation accuracy or pathway activity.

## Component-measurement readiness and limits

The existing all-program coverage audit is an instrument-coverage assessment, not a result-based candidate screen. A possible IFN-associated component has direct gene/protein correspondences for **CD38, IDO1 and CD274**, with HLA-ABC and HLA-DR as aggregate/complex measurements requiring explicit mapping. HLA-ABC is one measured channel, not three independent gene observations; HLA-DR is not a separate measurement of every class-II gene. STING abundance is not STING activation. Sparse coverage cannot validate an entire Hallmark program or a new distributed MSI by itself.

The supported protein component, its sign structure, biological sufficiency, background model, scoring/coordination tests, tumor-cell rules, missingness/precision criteria and complete multiplicity family remain to be frozen before candidate effects. A small numeric-finite panel is not automatically a reliably measured coordinated program. No final protein panel or statistical protocol was chosen by these QC steps.

The source methods explicitly select **CD3-high and CD3-low ROIs using pan-cytokeratin/CD3 fluorescence**. They are sampled immune-context regions, not an unbiased census of each tumor. The paper reports daily instrument calibration and a measured metal-tag spillover slide. This audit did not independently recover/validate the actual calibration/spillover controls, establish detection thresholds or inspect segmentation masks against images. Within-tumor prevalence therefore cannot be generalized to “most cancer cells” from these selected fields. Source Tumour clusters were learned using the marker panel; program tests sharing those markers need a sensitivity to phenotype-selection artifacts and immune-cell spillover, using independently justified epithelial/pathology rules where feasible.

## Readiness decision for the next molecular step

Identity and numeric integrity now pass; individual regimen/source histories can be attached using a verified mapping. Remaining limits are specific: P6 earlier-file provenance, uneven malignant-cell coverage, clinical timing disagreements, targeted component coverage and the unfrozen endpoint/statistical rules. These need not all bar descriptive resistance-stage recurrence, but they constrain which patients/components and claims are supportable. They cannot be resolved by examining favorable candidate effects.

A scientifically permitted next step requires the discovery-side clinical gate and the prospective operational endpoint to pass together. The NSCLC arm may then provide limited orthogonal evidence for the measured protein component. It must not be relabeled whole-transcriptome replication, genomic conservation, resistance specificity, causal resistance, or proof of coordinated selection. This executed readiness report contains no molecular-discovery result.
