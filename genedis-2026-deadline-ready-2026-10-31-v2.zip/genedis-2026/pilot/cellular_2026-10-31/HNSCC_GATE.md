# GSE213047 HNSCC: clinical and technical readiness gate

October 31, 2026. **Clinically promising source-defined acquired resistance;
technical gate unresolved. No molecular-analysis GO.** One patient is not by
itself an exclusion for a descriptive case-level cross-cancer comparison.
Three lesions are not three independent patients.

**Strict-primary adjudication:** the published acquired-resistance interpretation is meaningful, but depends on inferred metastatic origin of a lesion initially considered a separate primary. Under the PI's uncertain-case policy, this source is not currently counted toward the qualifying primary discovery cancers. It remains a clinical/technical lead and potential exploratory source. This is not a universal requirement for independent DNA testing; it preserves the unresolved origin-dependent resistance classification in this particular case. Technical malignant-cell mapping is also unresolved.

## Verified clinical episode

The [primary Lin et al. paper](https://pmc.ncbi.nlm.nih.gov/articles/PMC9548500/)
([DOI 10.1038/s41698-022-00314-3](https://doi.org/10.1038/s41698-022-00314-3))
describes a patient with a nasopharyngeal SCC and neck/lung metastases treated
with **nivolumab**. The lung metastasis achieved complete response; the
nasopharyngeal primary and neck metastases achieved partial responses that
remained stable. A new laryngeal SCC then developed **while receiving CPI**.
All three sampled lesions were collected simultaneously at total laryngectomy
and bilateral cervical lymphadenectomy.

This supplies an initial-benefit-to-on-treatment-progression sequence. The
authors explicitly interpret the case as acquired resistance in the abstract,
results and discussion; it is not merely a post-treatment nonresponse label.
The clinical distinction is nevertheless material: clinicians initially
considered the laryngeal lesion a new primary, whereas the authors inferred a
metastasis from the nasopharyngeal cancer using similar RNA-inferred CNA
profiles. Common origin is **inferred**, not independently DNA-confirmed. An
accepted manifest must retain this uncertainty rather than assert proven clonal
identity. If the clinical interpretation remains a new unrelated primary, that
lesion cannot establish acquired resistance of the responding index malignancy.

Figure 1 places immunotherapy and the laryngeal lesion in 2019 but supplies no
month-level interval. Duration must not be read from arrow spacing. An arbitrary
universal six-month requirement has not been adopted by the PI. Any applicable
treatment-specific definition and its clinical justification must be fixed
prospectively. The on-treatment status here is explicitly stated, unlike cases
with unresolved on/off-treatment progression. Exact last-dose, progression and
biopsy dates are not available in the inspected records.

The original clinical timeline was retrieved from the public publisher image:
[Figure 1](https://media.springernature.com/full/springer-static/image/art%3A10.1038%2Fs41698-022-00314-3/MediaObjects/41698_2022_314_Fig1_HTML.png).
It is cached locally at `/tmp/genedis-hnscc-clinical-timeline.png` for inspection.

## Specimens, measurements and independence

Official [GEO study](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE213047)
and sample records identify:

| Specimen | Published profile | Clinical role |
|---|---|---|
| `GSM6569751`, `HN19-1` | Nasopharyngeal SCC, 3,818 post-QC cells | Responding lesion, PR |
| `GSM6569752`, `HN19-2` | Nasopharyngeal neck-node metastasis, 2,870 post-QC cells | Responding lesion, PR |
| `GSM6569753`, `HN19-3` | Laryngeal SCC, 4,782 post-QC cells | New progressing lesion during nivolumab |

There are **11,470 total post-QC cells**, not 11,470 verified malignant cells.
This is one independent patient with no pretreatment tumor scRNA specimen. The
other two lesions are within-patient, contemporaneous biological comparisons;
they are neither independent durable responders nor longitudinal baselines.
Site/lineage differences between lesions remain confounders.

The source uses 10x Genomics VDJ NextGEM v1.1, Cell Ranger 6.0.0 and hg19.
The authors identify epithelial clusters and confirm malignant status with
**inferCNV**, using T and B cells as normal references. RNA-based malignancy
assignment is source-supported; no new classifier or expression analysis was
run in this audit. Source QC and inferred-CNA methodology must be audited before
adopting an exact malignant-cell subset.

## Actual public file inventory

The official GEO supplementary directory lists only the
[post-QC count matrix](https://ftp.ncbi.nlm.nih.gov/geo/series/GSE213nnn/GSE213047/suppl/GSE213047_HNSCC_scRNAseq_post_QC_count_matrix.txt.gz).
A HEAD request returned **HTTP 200**, `application/x-gzip`, **13,726,792 bytes**.
No matrix body or expression rows were downloaded in this audit. A dedicated
cell-barcode-to-malignancy annotation file is not listed in that directory.

The article-specific BioStudies API
[`S-EPMC9548500`](https://www.ebi.ac.uk/biostudies/api/v1/studies/S-EPMC9548500)
lists exactly two supplementary files: `41698_2022_314_MOESM1_ESM.pdf`
(reporting summary, 1,219,761 bytes) and `41698_2022_314_MOESM2_ESM.docx`
(supplemental material, 4,408,123 bytes). No separate cell-metadata table is
listed. These are article-specific filenames, not generic supplementary names
assumed to belong to this publication. Public source-supplement inspection did
not recover an exact malignant-cell barcode list.

## Additional annotation route: downloaded archive contains a different study

[CanCellVar's primary resource paper](https://pmc.ncbi.nlm.nih.gov/articles/PMC11267512/)
explicitly includes GSE213047 and describes downloadable cell annotations.
Its [download page](https://bio-bigdata.hrbmu.edu.cn/CanCellVar/download.jsp)
lists an HNSC cell-annotation archive, with this exact public endpoint:

<https://bio-bigdata.hrbmu.edu.cn/CanCellVar/downloadCopy.jsp?loc=cell_type&name=HNSC.cell_type.zip>

The web service reached an `application/x-download` response but could not render
that binary type. Initial execution-environment retrieval returned HTTP 403;
an ordinary anonymous request with browser headers then retrieved the valid
150,855-byte archive, SHA256
`b77a3a3b8805b2c23cb5a42032bb8ccb0fe9fa3f72bad8c96949a811d8ac9d57`.
It contains **only `HNSC/HNSC_GSE181919.cell_type.txt`**, 1,297,121 bytes,
whose cell IDs start with `GSM5514352_...`. This is a different study, not
GSE213047. The archive must not be used for this case merely because its cancer
label matches. It is cached locally at `/tmp/genedis-HNSC.cell_type.zip` for
source-inventory verification. No expression data were in this annotation
archive, and no source labels were silently transferred between studies.

Thus the public resource paper's inclusion of GSE213047 does **not** establish
that its current HNSC download supplies the required annotation. A usable
GSE213047-specific annotation, provenance, cell identifiers, coverage and barcode
joins remain **unverified**. No access control was bypassed.

Ordinary study-specific metadata requests within the same public download
service returned HTTP 500, which is not proof of global unavailability. The
separate NPC annotation archive was also checked because the index malignancy
is nasopharyngeal: it contains `NPC/NPC_GSE162025.cell_type.txt`, again a different
study. No unrelated annotations were substituted. Bounded searches did not
locate a Broad Single Cell Portal, CELLxGENE or 3CA copy of this case's metadata.

The inspected TISCH gallery did not list GSE213047, and the candidate
`HNSC_GSE213047_CellMetainfo_table.tsv` endpoint returned 404. Absence from that
catalogue does not establish global absence of suitable annotations.

## Decision and next condition

The clinical episode is potentially admissible under a prospectively justified
source-defined acquired-resistance rule, with inferred metastatic origin kept
explicit. It is not rejected for n=1 or an unadopted universal duration cutoff.
However, usable malignant-cell barcode annotations and specimen linkage have
not yet been verified. **Do not declare the two-cancer discovery gate passed or
score programs on this basis.** Recover and audit the exact annotation, or
prospectively approve and validate a source-compatible malignancy-identification
method before candidate inspection. Full matrix integrity, gene coverage,
harmonization and the complete NSCLC validation gate remain separate conditions.

No molecular effects, program recurrence, candidate MSI, genomic conservation
or causal resistance finding was generated by this metadata audit.
