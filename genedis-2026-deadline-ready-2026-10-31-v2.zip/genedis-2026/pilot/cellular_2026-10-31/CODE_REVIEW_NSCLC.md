# Independent restricted NSCLC runner review

October 31, 2026. Reviewed `analyze_nsclc_component.py`, its synthetic tests and the existing identifier/transform readiness records. This is an independent AI-assisted code review, not Justin's sign-off, a clinical GO or a review of real program effects. No study object, intensities or molecular outputs were opened.

**Verdict: no material numerical blocker identified for the documented descriptive endpoint. Two interpretation/integration conditions must remain explicit before real execution.**

1. **The marker sensitivity is not an independent tumor classifier.** At the reviewed selection block, `independent_marker_sensitivity` is `source_Tumour AND marker_keep`, so it retains the source panel-based clustering selection. Independent CD45/pan-cytokeratin criteria can test sensitivity to an additional restriction; they do not remove source-label circularity or recover tumor cells excluded by the original clusters. Rename it to a source-Tumour marker restriction, or explicitly retain this qualification in outputs and interpretation. Its immune-reference quartiles are proposed operational heuristics, not validated malignancy/purity thresholds. Communicated to the owning agent; runner not edited by this review.

2. **The leaf GO artifact is not the complete pan-cancer gate.** `validate_gate` checks endpoint identity, a FROZEN protocol and its exact byte hash before source hashing/loading; this is correct fail-closed ordering. It does not itself verify the two non-NSCLC discovery cohorts or bind their accepted gate artifacts. Root must issue the endpoint GO only after the complete investigator-required gate passes and record the full-gate reference/hash plus the frozen runner bytes before effects. A standalone NSCLC readiness decision must not be supplied as that authorization. Post-run runner provenance records the implementation hash but does not alone prove its pre-effect freeze.

## Verified implementation behavior

- R's feature-by-cell numeric payload is reshaped with `order="F"`; assay cell names must exactly match metadata order. Required channels are uniquely named. The fixed source hash and prior uniform QC record constrain this to the audited object. Reader orientation was reviewed against those records; this review did not independently decode the real RDS.
- Uses the source `exprs` assay directly. The readiness record verifies `exprs = asinh(counts)` with cofactor 1. No additional asinh, RNA CPM or transcriptome-rank transform is applied to protein values.
- Three direct measurements map CD38→CD38, IDO1→IDO and CD274→PD-L1. HLA-ABC/HLA-DR remain aggregate/complex context, rather than multiple independent genes or full-pathway replication.
- Post-treatment cells remain grouped by patient, sample and ROI. ROI statistics receive equal weight within patients; patient summaries receive equal weight across patients. All seven source patients remain represented, with unavailable measurements retained. Cells/ROIs do not inflate clinical n.
- Rank ties, constant channels, low residual degrees of freedom and near-zero technical residuals are handled explicitly. Partial statistics are defined as marker midranks residualized against intercept, raw log1p(area) and source-transformed Histone H3; this is not an undocumented all-variable rank transformation.
- The runner computes no inferential P values or clinical-population confidence intervals. Output directories cannot overwrite existing results, and outputs retain source/protocol/gate/runner hashes and limitations.

## Verification performed

```bash
.venv/bin/python -m unittest discover -s tests -p test_nsclc_component_runner.py -v
```

**Nine synthetic tests pass**, covering ties, known correlations, independent channels, missing/constant measurements, technical residual degeneracy, ROI weighting, retained missing patients and gate/hash rejection. No real-data analysis accompanied the review. Source-label selection, ROI sampling bias, spillover/segmentation uncertainty and sparse component coverage remain scientific limitations; the descriptive runner does not resolve them.
