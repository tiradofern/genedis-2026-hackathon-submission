**Historical preparation record, preserved from before the October 31 molecular measurement run. Its no-results statements describe that earlier state. Read RESULTS_2026-10-31.md for the executed results.**

# Cellular discovery preparation — October 31, 2026

**Subsequent PI decision:** restricted protein measurements are approved for the NSCLC validation step. Specific component mapping and the complete clinical/technical gate remain pending; no molecular effects have been calculated.

**Latest clinical boundary:** [uncertain cases are exploratory only](CLINICAL_ELIGIBILITY.md). Yang 509 does not count toward the two qualifying primary discovery cancers. Metadata recovery or an approved assay modality cannot change that clinical status.

**No molecular discovery results have been generated.** The investigator retained the full pan-cancer requirement and declined the proposed NSCLC-only pilot. The complete discovery/validation dataset combination remains unverified. This directory contains metadata feasibility evidence and tested numerical building blocks; it is not a completed analysis pipeline or a substitute hackathon submission.

Read the [clinical/access follow-up](FEASIBILITY_FOLLOWUP.md), [gate interpretation and additional sources](GATE_REVIEW.md), and [current project status](../../docs/CURRENT_STATUS.md). All earlier analyses, closed gates, provisional programs and the frozen release/archive remain preserved.

Current sources are [MCC](MCC_METADATA_GATE.md), [Yang melanoma](YANG_MELANOMA_GATE.md), the [HNSCC clinical/technical lead](HNSCC_GATE.md) and the [restricted orthogonal NSCLC protein endpoint](ORTHOGONAL_NSCLC_GATE.md). **Melanoma and the origin-uncertain HNSCC case are not currently counted toward primary discovery.** The complete primary combination remains unverified. See [machine-readable readiness](readiness.json); no candidate program is selected by this source assessment.

## Actual technical work completed

- Reconciled MCC metadata against both original count-file headers, retaining a documented source-derived correction to a misleading timing label.
- Retrieved and hash-verified public processed objects, retained outside Git. [NSCLC structural QC](HILT_STRUCTURE_QC.json) verifies four 41-by-99,659 assays and cell-metadata identity/order. The 41 features are 39 antibody channels plus two DNA stains. Tumor-cell coverage is uneven, and the clinical-to-internal patient-ID crosswalk remains unresolved; seven source patients is not a final program-eligible denominator.
- Recovered author metadata for **85,443 tumor-labelled melanoma cells** using a tested, bounded base-R reader. The initial Python format failure remains preserved separately. No RNA assay or intensity values were extracted or summarized. Clinical uncertainty remains despite successful technical extraction.
- Audited the measured panel against all 50 published Hallmarks in [ASSAY_COVERAGE.md](ASSAY_COVERAGE.md), without choosing candidates or thresholds. Sparse direct overlap cannot validate entire pathways; a justified restricted component requires its own prospective mapping.
- Preserved all source objects, factor/NA semantics, source identifiers and retrieval hashes. [Reader reproduction instructions](READER_REPRODUCIBILITY.md) describe isolated runtimes, scripts, fixtures and actual success/failure receipts. The original analysis environment remains unchanged.

## Numerical utilities

`program_scores.py` performs no file access, retrieval, clinical classification or automatic analysis. Its caller must supply clinically adjudicated data, audited malignant-cell labels, exact identifiers, appropriate input units, a measurable gene universe and an explicit coverage policy. **Neither a program collection nor analysis thresholds are frozen by this implementation.**

- GMT parsing preserves exact gene identifiers and rejects duplicate definitions. It performs no alias conversion.
- Relative-expression scores average within-sample gene ranks, with average ties and the documented normalization `(rank - 1) / (G - 1) - 0.5`. Missing program genes are excluded with reported coverage; missing universe genes are an error. This is an explicitly defined descriptive score, not a claim of numerical equivalence to an external scoring package.
- Cell CPM requires finite, nonnegative count-like input and a positive complete supplied library total. Equal-cell mean CPM differs from a library-size-weighted summed pseudobulk; neither is selected as the study's primary representation here.
- Cells aggregate within explicit specimens. A caller must select a sampling state and an explicit policy before repeated specimens aggregate within patients. Cross-source patient/specimen identifiers require audited namespacing. Equal-patient summaries do not turn cells, specimens or sequencing lanes into independent patients.
- Nonfinite values, duplicate/conflicting identifiers and numerical overflow fail explicitly. Programs failing coverage retain an unmeasurable status rather than an invented zero score; a future caller must handle those statuses before aggregation.

These scores do not establish an active/inactive state, coordination, pathway flux, resistance specificity, selection, causality or a Molecular Survival Island. The module includes no clinical gate runner, inference, candidate ranking, plots, molecular results or cohort-specific code.

## Verification

From the repository root, using the existing pinned environment:

```bash
.venv/bin/python -m unittest discover -s tests -p test_cellular_program_scores.py -v
.venv/bin/python -m unittest discover -s tests -v
node --test tests/frontend.test.mjs
```

The new 14 tests use hand-calculated and synthetic examples only. The complete Python suite passes 42 tests; the existing frontend suite passes five. Tests check arithmetic, ties, ordering, missingness, invalid inputs, overflow and patient/specimen weighting. They do not validate biological findings or establish data readiness. Subsequent metadata-reader work used separate pinned Python and base-R runtimes; the original project environment was not modified. Reader fixtures verify exact metadata preservation, evidence-overwrite refusal and nonzero failure exits; see [the launcher checks](READER_LAUNCHER_CHECK.json).

## Remaining prerequisites

Before real-data scores or candidate selection, verify the complete clinically eligible, technically measurable pan-cancer combination and its independent NSCLC validation source; define the treatment family and regimen strata; then freeze the dataset-dependent program collection, measurement/calibration choices, coordination test if supportable, multiplicity family, success/failure/inconclusive rules and adequacy assessment. Observed recurrence, temporal change, comparator enrichment and functional contribution remain separate evidence levels.

No organizer submission, repository access change, author contact or access application accompanies this preparation.
