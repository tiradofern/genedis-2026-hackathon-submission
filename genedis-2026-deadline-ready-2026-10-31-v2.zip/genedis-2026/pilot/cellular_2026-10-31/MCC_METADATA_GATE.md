# Merkel cell carcinoma: clinical and cell-metadata gate

Metadata audit, October 31, 2026. **Cell-barcode joins reconciled; conditional
study readiness, not an analysis GO.**
These are two independent acquired-resistance patients in one cancer type.
No expression rows, molecular program scores or candidate-selection results
were inspected. Only public clinical/source text, cell annotations and the first
CSV header of each processed count file were read. Header checks do not establish
complete matrix integrity or measurement quality.

## Clinical episodes and specimen independence

The [original Paulson et al. paper](https://pmc.ncbi.nlm.nih.gov/articles/PMC6155241/)
and official GEO records identify:

| Namespaced patient | Relevant specimens | Clinical evidence and treatment interpretation |
|---|---|---|
| `GSE117988:2586-4` | `GSM3330559`: pretreatment tumor; `GSM3330560`: acquired-resistance tumor, day +615 | Long response followed by relapse. Initial adoptive MCPyV-specific T-cell therapy was followed by progression; pembrolizumab and subsequently ipilimumab were added before the durable response. This is acquired resistance after a combination/sequential immunotherapy course, not acquired resistance to T cells alone or checkpoint monotherapy. Local radiation was also used. |
| `GSE118056:9245-3` | `GSM3317835`/`GSM3317836`: lanes 001/002 of one tumor specimen, relapse day +565 | Complete radiographic/pathologic regression followed by relapse after an 18-month response. Avelumab plus virus-specific T-cell infusions; initial interventions also included local interferon-beta and radiation. One resistance-stage tumor, not two independent observations. No pretreatment tumor scRNA profile is available for this patient. |

The detailed last-dose/progression-to-biopsy intervals and absence of an
intervening systemic regimen are not fully reconstructed here. The primary
article explicitly identifies these specimens as late/acquired resistance.
The later day +832 biopsy from the first patient was used for separate assays;
it must not be substituted for the day +615 scRNA specimen.

## Original molecular files: access and header evidence

| GEO processed file | HEAD response and size | First decompressed CSV header |
|---|---|---|
| [GSE117988 tumor matrix](https://ftp.ncbi.nlm.nih.gov/geo/series/GSE117nnn/GSE117988/suppl/GSE117988_raw.expMatrix_Tumor.csv.gz) | HTTP 200; 13,531,097 bytes | 141,190 bytes; 7,431 cell columns: 2,243 suffix `-1`, 5,188 suffix `-2`. SHA256 `97ba907c09f62d0e848a1db1b031c24ca2da6217042beca327e001a074946d5f`. |
| [GSE118056 combined matrix](https://ftp.ncbi.nlm.nih.gov/geo/series/GSE118nnn/GSE118056/suppl/GSE118056_raw.expMatrix.csv.gz) | HTTP 200; 30,940,247 bytes | 210,350 bytes; 11,071 cell columns: 5,748 suffix `-1`, 5,323 suffix `-2`. SHA256 `910c086a0dffc7b91984f5396fae25ee712672b8e907cefac966135b50ca3a32`. |

The GSE118056 sample record explicitly maps `-1` to PBMC and `-2` to tumor
digest. Its lanes must not be added as separate matrices or patients. GSE117988
uses 3-prime v2 chemistry; GSE118056 uses 5-prime chemistry. Raw expression
values must not be pooled across these preparations.

Some repeated streamed requests returned an empty response, despite a successful
earlier header read. The first header was recovered through the ordinary public
[GEO file-download endpoint](https://www.ncbi.nlm.nih.gov/geo/download/?acc=GSE117988&format=file&file=GSE117988_raw.expMatrix_Tumor.csv.gz),
which redirected to the FTP HTTPS file, using a bounded HTTP byte-range GET.
Only the compressed prefix was transferred, and decompression output was capped
at the exact 141,190-byte header length. No expression row was decoded. The
header was cached locally as `/tmp/genedis-mcc117988-counts-header.csv` for the
join, avoiding further partial-stream requests. No access control was bypassed.
The hashes above identify header bytes, not full count files.

## Malignant-cell identification and public annotation

The primary study identifies MCC cells using established marker expression
(`NCAM1`, `ENO2`, `CHGA`, `KRT20`) alongside immune markers. This is RNA-based
classification, not independent DNA-confirmed malignancy. The first patient's
reported 7,431 digest cells include 1,984 malignant cells before treatment and
5,131 at resistance. Total digest cells must not be called malignant cells.

Public TISCH annotations provide a separate reproducible cell-label source:

| Cell metadata | Receipt | Tissue-restricted malignant annotations |
|---|---|---|
| [MCC_GSE117988_aPD1aCTLA4](http://tisch.comp-genomics.org/static/data/MCC_GSE117988_aPD1aCTLA4/MCC_GSE117988_aPD1aCTLA4_CellMetainfo_table.tsv) | 1,591,187 bytes; 10,148 rows; SHA256 `5dd5a79d63b8a6287ba7e77d8ccbc8a48e6e60cd961f640be37c32b46fea1b46` | `Tumor_Pre`: 2,205 cells, 2,025 labelled malignant. `Tumor_EarlyD27`: 5,187 cells, 5,149 labelled malignant. |
| [MCC_GSE118056_aPDL1](http://tisch.comp-genomics.org/static/data/MCC_GSE118056_aPDL1/MCC_GSE118056_aPDL1_CellMetainfo_table.tsv) | 1,186,040 bytes; 11,024 rows; SHA256 `8413bce6b319f4909ce85955583ce7d733ba5b44e6352bca8c684c9665d49c00` | Tumor source: 5,323 cells, 4,969 labelled malignant. PBMC: 5,701 cells, including 12 labelled malignant. |

**Restrict both source tissue and malignant label.** The first metadata file
also labels one PBMC cell malignant; its overall 7,175 malignant labels are not
the tissue-restricted analysis denominator. Likewise, the second file's overall
4,981 labels include 12 PBMC cells. These labels require provenance and
uncertainty assessment; they are not automatically the original authors' exact
cell set. Their differing denominators are preserved.

## Timing discrepancy: retain the original and a clinical correction separately

The TISCH label `Tumor_EarlyD27` conflicts with the original first-patient tumor
specimens: GEO contains pretreatment tumor and acquired-resistance day +615,
whereas day +27 belongs to the PBMC series. The erroneous label must not be used
to classify these tumor cells as scheduled early treatment sampling.

In TISCH, all `Tumor_Pre` barcodes have prefix `Tumor@` and suffix `-1`; all
`Tumor_EarlyD27` barcodes have prefix `Tumor@` and suffix `-2`. The original
matrix header has 2,243 `-1` cells and 5,188 `-2` cells, matching the primary
article's before/after sample sizes exactly. This supplies structural support
for the clinical correction, independently of any program expression values.
The original Cell Ranger aggregation input sheet has not been recovered.

The first-patient barcode join is now exact and one-to-one after removing only
the TISCH tissue prefix `Tumor@`: all **7,392 distinct tumor-metadata cell IDs**
match the **7,431 distinct original header IDs**, with **zero unmatched metadata
IDs**. There are 39 original cells without a TISCH annotation: 38 in suffix
`-1` and one in suffix `-2`. These cells remain unannotated/excluded unless a
separate defensible classification is supplied; no missing label is imputed.

| Retained original TISCH sample | Exact original-header join | Source-derived clinical classification |
|---|---|---|
| `Tumor_Pre`, all suffix `-1` | 2,205/2,205 metadata IDs match; 2,243 original cells in this library | Pretreatment, `GSM3330559`, `clinical_day=NA` (before treatment; no invented numeric day) |
| `Tumor_EarlyD27`, all suffix `-2` | 5,187/5,187 metadata IDs match; 5,188 original cells in this library | Acquired resistance, `GSM3330560`, `clinical_day=615` |

This correction is a **source-derived clinical adjudication**, not an original
TISCH annotation or a new molecular result. It combines exact barcode joins,
the original study's explicitly reported before/after cell counts, the only two
GEO tumor specimens, and their clinical time labels. It does not infer timing
from pathway expression, clustering or any selected molecular effect.

Any accepted corrected manifest must retain `source_sample` and
`source_timepoint` unchanged, add `clinical_state` and `clinical_day`, and record
the GEO/paper/header evidence and adjudicator. It must never silently replace
the TISCH source fields. The barcode reconciliation is complete; final study
eligibility still requires the documented clinical adjudication to be accepted
in the prospective study manifest before molecular scoring.

For GSE118056, all 11,024 TISCH cell identifiers match the original matrix header
exactly; 47 original PBMC barcodes are absent from TISCH, while all 5,323 tumor
barcodes are represented. The source tissue suffix and single day +565 tumor
episode are therefore structurally linked. Both annotation files use the local
patient label `patient1`; studies must be namespaced to preserve independence.

## Remaining gate

Accept the documented source-derived timing-label correction, audit annotation
uncertainty and full matrix/QC integrity, and fix
the clinical regimen strata before molecular use. This MCC audit alone does not
establish a second discovery cancer, comparable independent NSCLC validation,
adequate precision, coordination, resistance specificity or a causal mechanism.

Aggregate HLA-ABC protein staining is not interchangeable with locus-specific
HLA transcripts; an orthogonal protein readout must be named and interpreted as
such rather than whole-RNA-program replication.
