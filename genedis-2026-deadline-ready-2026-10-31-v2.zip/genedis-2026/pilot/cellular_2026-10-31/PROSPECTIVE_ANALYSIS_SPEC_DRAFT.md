# Prospective molecular analysis specification — draft, October 31, 2026

**DRAFT FOR REVIEW; NOT A FROZEN PROTOCOL OR MOLECULAR RESULT.** This proposal does not open the clinical gate, select programs, inspect molecular effects, or replace the full pan-cancer design. It is a bounded analysis option if the complete discovery–validation combination qualifies. The current possibility of two MCC patients plus one melanoma patient is a planning scenario, not a verified final eligible denominator.

## Scope and scientific evidence

Require clinically supported acquired resistance in two distinct non-NSCLC discovery cancers and an independent NSCLC orthogonal endpoint. Uncertain clinical cases remain a separate exploratory sensitivity and cannot supply the missing primary cancer type. Define the PD-(L)1-containing treatment family prospectively, retaining adjunct therapies and radiation. Preserve earlier results, rejected sources and negative findings.

With two discovery patients in one cancer and one in the other, an actual molecular analysis is feasible, but **population-level recurrence or independent within-cancer replication cannot be established for the one-patient cancer**. Thousands of cells do not change that. The useful distinction is:

1. Descriptive recurrence of measured features across the observed independent cases and cancer types.
2. Conditional evidence that predefined sets are more coordinated than technically matched gene sets in those specimens.
3. Population recurrence, resistance enrichment, selection and functional contribution: separate questions requiring additional patients, comparators or experiments.

Any resulting nomination is an **exploratory candidate recurring coordinated feature**, with the actual patient counts attached. A conditional gene-set P value cannot establish level 3. Pre-existing programs remain eligible; a pretreatment increase is not required. Generic cancer biology remains a plausible explanation.

## Prospective freeze and measurement

Before effects, record the source/patient/specimen/cell crosswalk, clinical exclusions, treatment family, malignant-cell rule, full source hashes, software versions, assay units, gene mapping, sampling seed and every method parameter. The fixed benchmark proposal is **all 50 MSigDB Hallmark 2024.1.Hs sets**, using the complete cached definitions and terms. This is a new proposal, not inheritance of the old six-program bulk protocol. No new learned module or classifier is needed tonight.

Freeze an explicit uniquely mapped RNA gene universe shared by the discovery assays. Do not silently resolve duplicate symbols, treat missing features as zero, learn from NSCLC values, or select genes by association with resistance. Preserve measurable zeros. Keep assays in their native valid representation; count-like RNA can use the existing equal-cell CPM helper when the full measured library is supplied. Log-normalized inputs must not be mistaken for counts. No expression matrix is pooled or batch-corrected across cancers.

Proposed full-set fidelity policy for review: at least 80% of original members must be uniquely represented in the common assay universe for a whole-set activity summary. This is an operational representation rule, not an established biological cutoff, and must be reviewed against source feature availability before effects. Coordination has an additional variable-gene coverage report; two variable members are merely the mathematical minimum and do not establish adequate whole-program representation. Freeze the coordination coverage policy before its statistic is calculated; otherwise report the partial statistic as descriptive only. Retain all 50 rows, including unassessable sets. Protein components have their own biological sufficiency assessment rather than this RNA coverage rule.

One prespecified resistance specimen per patient is primary; sequencing lanes are technical replicates. Selection uses clinical timing/site rules, never program values. Earlier paired specimens, additional resistance specimens and uncertain cases remain separately labelled. Cells, ROIs and repeated biopsies cannot increase clinical n.

## RNA activity: descriptive measurement

For each malignant cell, rank genes over the fixed measurable RNA universe with average ties, transform to `(rank-1)/(G-1)-0.5`, then average uniformly over represented program genes. Aggregate within specimen, then give patients equal weight. Report continuous patient scores, covered genes and distributions; do not invent an active/inactive threshold or require positive scores for nomination. These scores are relative-expression summaries, not pathway flux or absolute activation. Direction-labelled sets such as KRAS_SIGNALING_DN need interpretation according to their published definition.

Use the mean of per-cell full-library-normalized profiles followed by the same fixed-universe rank summary as a prespecified measurement sensitivity. This changes the estimand, so report it separately rather than choosing the more favorable answer. A rare malignant population is not excluded by a majority-cell rule; limited cell sampling can miss such populations and must be acknowledged.

For genuine within-patient baseline/resistance pairs, report both scores and their difference. Historical baseline comparisons spanning other therapies/sites are descriptive temporal context. With one pair per cancer, no patient-level significance claim is possible. Paired changes add evidence but are not admission criteria.

## RNA coordination: a separate conditional test

Activity is not coordination. The proposed statistic is the mean off-diagonal correlation among a set's eligible genes across malignant cells within each patient. Use across-cell ranks for each gene, then remove only prespecified available technical covariates, such as source-recorded library/detection metrics and ROI/batch indicators. Record residual degrees of freedom and nonconstant members. Do not regress out the biological programs being tested. Missing technical covariates are limitations, not invented values. The resulting statistic is partial rank correlation, not a gene interaction network or proof of cooperative survival.

For standardized residual gene vectors `z_g` with squared norm `n-1`, the statistic can be computed without constructing a gene-by-gene matrix:

`T = (||sum_g z_g||^2 - m*(n-1)) / (m*(m-1)*(n-1))`.

Check this identity against an explicit correlation matrix on synthetic fixtures. Exclude numerical zero-variance genes by a frozen tolerance; record the original and remaining membership. Unidentifiable residualization or insufficient degrees of freedom makes the coordination endpoint unassessable. It is not zero coordination.

Use a separate **common coordination universe** containing only genes with identifiable, nonconstant technical residuals in every primary discovery patient. Fix each represented set as its intersection with that universe before its statistic or null is evaluated. This makes member counts identical across patients and prevents zero-variance filtering after a permutation from changing null set sizes/overlaps. The activity universe remains separate and retains measurable zeros. Report losses relative to both the original set and the assayed universe; source/gene-variance QC is not evidence of a biological effect.

### Matched background and multiplicity

Construct technical gene-matching strata before program effects, using patient-balanced expression/detection summaries across the discovery sources. A concrete proposal is within-patient percentile summaries of mean expression and detection fraction, averaged equally across patients, then a fixed 5-by-5 quantile stratification. Document ties, deterministic merging of undersized strata and per-patient matching diagnostics. This is an approximate technical background; it does not control every gene's network degree, lineage relevance or ordinary cancer biology.

For each null replicate, apply **one bijective gene-label permutation within these strata**, shared across all 50 sets and discovery patients. It preserves represented set sizes, their pairwise overlaps and the observed expression matrix; it does not destroy the measured background gene correlations. Do not independently generate overlapping sets and then call them independent evidence. Preserve target-set identity and report overlap groups, especially highly overlapping Hallmarks.

Use **4,999 prespecified null replicates**, seed recorded, with one-sided upper-tail Monte Carlo `p=(1+number(T_null>=T_observed))/5000`. Each patient's P value refers to a conditional matched-gene-set model. Within each cancer take the maximum eligible-patient P value, then take the maximum across the two discovery cancers: an intersection–union criterion for conditional evidence in all observed primary cases. This is not a pooled cross-cancer test or a population replication P value. Require a positive observed correlation and positive excess over the matched-null center for the corresponding directional coordination interpretation.

Apply Benjamini–Yekutieli correction over the complete 50-set family at q<=0.05; retain unassessable sets with P=1 and an explicit unassessable label. The shared permutations preserve overlap; BY also accommodates arbitrary dependence provided the underlying conditional P values are valid under the stated null model. Exchangeability within technical strata is a modeling assumption, not a guarantee supplied by multiplicity correction. Report sensitivity to matching quality and residual technical confounding.

Resolution matters: 4,999 permutations give minimum P=0.0002. For 50 BY tests, the worst first-ranked adjusted value is approximately `50*4.499*0.0002=0.045`. At 999 replicates it is approximately 0.225, so that smaller budget cannot support a lone discovery at q<=0.05. Do not stop early because a favorable P value appears. An incomplete null run is incomplete, not a positive or tested-negative result.

A patient-level two-sided sign test has minimum P=`2^(1-n)` before correction. With n=2 or n=1 this is 0.5 or 1; cells cannot repair the lack of clinical replication. Report this inferential limit even if conditional gene-set coordination is convincing.

## NSCLC: restricted protein-component follow-up

Use [ASSAY_COVERAGE.md](ASSAY_COVERAGE.md) and its complete 50-set inventory to adjudicate components **before NSCLC effects**. A measured gene overlap is not sufficient by itself. Specify the biological component, all independently measured channels, expected relationships, known alternative regulation and what part of the RNA program remains untested. Pooled HLA channels count once each; CD45 isoforms do not become additional genes; cleaved caspase-3 is a state measurement. A single marker can support a feature observation but cannot establish coordinated multi-protein behavior.

Do not apply transcriptome-rank scoring or RNA CPM normalization to the 39-channel selected IMC panel. Use the verified source transformation without double transformation. Predefine tumor labels and sensitivities that avoid selecting cancer cells using the functional markers under test where possible; retain segmentation/spillover and classification limitations.

Seven clinical patients do not imply seven usable tumor-cell endpoints. Source-labelled post-treatment tumor counts are **5,497; 79; 2; 0; 5; 1,483; 3,355** for internal IDs **2; 4; 5; 9; 11; 12; 14**. Zero is missing measurement. Two/five cells cannot provide reliable within-tumor covariance merely because the object decoded successfully. Technical usefulness depends on marker detection, ROI structure and endpoint precision, not a retrospectively chosen universal cell threshold.

The minimal defensible orthogonal output is per-patient component-marker summaries and within-patient multi-marker correlation/co-occurrence estimates, retaining ROIs and uncertainty. **Propose descriptive protein coordination for tonight** unless a defensible spatial/technical null is prospectively implemented. Independently shuffling individual cells within an ROI generally destroys spatial dependence and can yield anticonservative significance. A selected 39-antibody panel is not an exchangeable whole-proteome background. Do not transfer the RNA matched-gene null to these proteins.

Patient-level concordance can be reported with all denominators, but the small usable patient count and 50-program family sharply limit clinical inference. A positive finding supports a measured protein component recurring in the observed independent acquired-resistant NSCLC specimens, not complete RNA-program replication or a causal mechanism.

## Effect sizes, uncertainty and secondary genes

Report every patient's activity score, coordination correlation, matched-null excess and coverage. For paired specimens report individual changes. Avoid a pooled cancer mean as the primary effect. With one/two patients per discovery cancer, a reliable population confidence interval is not supported; mark it not estimable rather than displaying a narrow cell-derived interval as clinical precision.

ROI/block resampling, when adequate blocks exist, can describe conditional specimen measurement uncertainty. Dissociated-cell resampling omits clone/spatial dependence and is a technical sensitivity, not patient-population confidence. Report its exact interpretation. With only one ROI, an across-ROI interval is unavailable. Leave-one-patient-out analyses are sensitivity checks, not independent validation.

Only after functional results, describe gene-to-rest-of-program correlations, omitting the gene itself from its reference score to avoid mathematical self-inclusion. Report all represented genes and consistency across patients; do not treat identical published set membership as newly discovered gene conservation. Gene-core comparisons are descriptive unless a separate complete gene-testing family is frozen. Functional similarity can remain informative without identical contributing genes.

## Outcomes fixed before effects

- **Conditional molecular success:** adequate coverage/technical quality and same positive coordination evidence under the complete 50-set rule in both discovery cancers; any nomination remains case-level and exploratory. NSCLC is separately labelled supported for a justified measured component, unsupported, or unassessable. Baseline presence remains eligible.
- **Tested negative:** completed valid tests do not support the specified coordination hypotheses. Report all effects/P/Q values. This does not show that survival adaptations are absent or that the programs are resistance-specific negatives.
- **Inconclusive:** clinical gate fails, whole-program/component representation is inadequate, coordination is technically unidentifiable, reliable NSCLC tumor measurement is missing, or the null computation cannot finish. Unassessable is distinct from tested negative.
- **No causal conclusion:** neither case recurrence nor conditional coordination demonstrates selection, enrichment over non-resistant tumors, functional contribution, genomic conservation or clinical prediction. Known pathway recurrence is not discovery of a novel learned network.

## Bounded implementation and stop rules

The approximately 60-minute implementation estimate assumes a passed gate and accessible processed matrices, complete barcode mapping and the small verified readers; it excludes raw sequencing reconstruction. Before effects, benchmark the statistic/null implementation on synthetic matrices. If needed for a predictable budget, prospectively cap coordination cells at 512 per specimen using a reproducible identifier-hash selection, explicitly a computational cap rather than a clinical eligibility minimum. Preserve all-cell descriptive profiles and report rare-state sampling limits. Do not change the cap or select cells based on a program result.

Suggested sequence after GO: 0–10 minutes final input/identifier/QC checks and freeze; 10–35 RNA scores and vectorized, batched null calculations; 35–45 restricted protein summaries and essential sensitivities; 45–60 all-family tables, scientific review, figures and exact rerun. Batch sparse membership operations and avoid full genome-wide correlation matrices. Reserve packaging/verification time before the 18:00 Eastern submission deadline. A failed runtime/quality checkpoint yields an explicit partial or inconclusive analysis, not a relaxed clinical definition or a retrospectively easier test.

No calculation under this proposal is authorized by the document itself. Record the actual complete gate, accepted method version/hash and execution start before biological scores or candidate selection.
