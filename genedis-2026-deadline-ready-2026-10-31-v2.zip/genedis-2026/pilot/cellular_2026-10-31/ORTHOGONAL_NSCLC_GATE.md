# Conditional NSCLC orthogonal-protein gate — October 31, 2026

## Verdict and scope

**CONDITIONAL; NOT GO.** Hiltbrunner et al. provide a credible public, cell-resolved protein resource from seven clinically acquired-resistant NSCLC patients. It may support orthogonal testing of a biologically sufficient protein component of a frozen molecular program. It does not automatically replicate a whole RNA program, establish resistance specificity, or complete the required two non-NSCLC discovery cancers followed by independent NSCLC validation.

This corrects the overly strong implication that only whole-transcriptome malignant-cell RNA, an identical platform, or an identical regimen could satisfy any NSCLC validation endpoint. The PI prioritized cancer-cell identification and program-level validation; a different modality requires explicit measurement mapping and appropriately restricted claims. The full pan-cancer design remains required. PD-(L)1-containing regimens may be evaluated under a prospectively justified treatment-family definition, with additional agents, radiation, treatment sequence and regimen strata retained. Sharing one treatment component does not establish biological equivalence or identify that component as the cause of a shared phenotype.

This began as a source/clinical/assay audit before molecular inspection. A subsequent authorized structural-QC step decoded the deposited SCE and extracted cell/feature metadata; its findings are recorded below. The native parser necessarily processes the complete serialized file, but no molecular assay array was converted to NumPy, summarized, scored or used for candidate selection. Public marker metadata and source code were read; source analysis code was not executed. Earlier gates, the frozen submission and negative findings are preserved.

## Sources and public file inventory

- Primary publication: Hiltbrunner et al., *Nature Communications* 14, 5154 (2023), DOI [10.1038/s41467-023-40745-5](https://doi.org/10.1038/s41467-023-40745-5); [PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC10449840/); [Europe PMC official full-text XML](https://www.ebi.ac.uk/europepmc/webservices/rest/PMC10449840/fullTextXML).
- Public IMC deposition: [Zenodo 8041882](https://zenodo.org/records/8041882), DOI 10.5281/zenodo.8041882; [record API](https://zenodo.org/api/records/8041882). The API reports **CC BY 4.0**. Article, sequencing-access restrictions and dataset terms remain distinct.
- Sequencing-method code: [Lab-Curioni/Acquired_Resistance_ICI_NSCLC](https://github.com/Lab-Curioni/Acquired_Resistance_ICI_NSCLC). Sequencing data are not the cell-resolved protein endpoint evaluated here.

The public record lists **56 files**: 14 raw MCD files, 38 segmentation-mask TIFF files, one processed SCE RDS, one antibody-panel CSV and two R notebooks. The following are listing/metadata receipts; listing is not proof that the processed object has been decoded or its contents verified.

| Public file | Bytes | Deposited MD5 | Role |
|---|---:|---|---|
| `sce-clustering-allsamples-original_final.RDS` | 159,811,140 | `17dc8c356c86f479a34213714a07abb8` | Processed SingleCellExperiment object; subsequently retrieved by root and structurally decoded as documented below |
| `AK_List.csv` | 3,417 | `e85a68a3fbaaf5ea749e02984397d5bc` | Antibody identity, metal, clone, lot, vendor and concentration; read as assay metadata |
| `Analysis IMC.Rmd` | 38,151 | `68fad629579e364ec573989f12734878` | Source annotation/analysis code; read, not run |
| `Read IMC RAW data.Rmd` | 4,690 | `61a0667fd30a45ab3174c615a8badf23` | Source object construction/metadata code; read, not run |

Direct public metadata links: [panel](https://zenodo.org/records/8041882/files/AK_List.csv?download=1), [analysis code](https://zenodo.org/records/8041882/files/Analysis%20IMC.Rmd?download=1), [object-construction code](https://zenodo.org/records/8041882/files/Read%20IMC%20RAW%20data.Rmd?download=1).

**No native cell-intensity CSV is listed.** The construction notebook references local `cell.csv`, `Image.csv`, `Object relationships.csv` and `LC-Curioni Project_1.1.csv`, which are not independently listed in this deposition. `AK_List.csv` is a reagent manifest, not a cell-by-marker table. The available shortcut is the processed RDS, not reconstruction from approximately 11 GB of raw imaging material. A usable S4/Bioconductor-object reader and verified extraction are a real technical gate: the script expects R/SingleCellExperiment; a Python reader must demonstrate preservation of assays, row/column identities and metadata before use. Do not assume `pyreadr` can decode an arbitrary S4 SingleCellExperiment.

## Clinical population and independent units

The publication describes seven independent NSCLC patients who initially benefited from checkpoint inhibition and subsequently developed resistance, with two tumor specimens per patient. Its aggregate table reports five nivolumab, one pembrolizumab and one nivolumab/ipilimumab case; six had previous chemotherapy and one did not. The prose sentence suggesting all had previous chemotherapy conflicts with that table and the P5 narrative. Retain the individual histories instead of imposing that aggregate sentence on P5.

| Source patient | Checkpoint exposure and clinical resistance evidence | Sampling/history limits |
|---|---|---|
| P1 | Nivolumab; paper reports resistance ten months after immunotherapy began, with 30 cycles administered | Initial diagnostic tissue preceded cisplatin/docetaxel and thoracic/lymph-node radiation; resistance sample from primary tumor |
| P2 | Nivolumab/ipilimumab, then nivolumab after ipilimumab toxicity; explicit initial response followed by progression | Earlier cisplatin/pemetrexed, pemetrexed maintenance and radiation; resistance primary-tumor biopsy; retain sequential-combination stratum |
| P3 | Nivolumab; resistance after 43 cycles; included in authors' initial-response/acquired-resistance cohort | Earlier surgery, cisplatin/gemcitabine, BRAF/MEK therapy and brain radiation; resistance pleural lesion; individual RECIST category/duration not recovered here |
| P4 | Nivolumab; explicit initial response followed by progression after 30 cycles | Several earlier chemotherapy/radiation regimens; resistance pleural lesion. Narrative says adenosquamous, aggregate histology table says one squamous case; both are NSCLC, but retain the source wording |
| P5 | Pembrolizumab; progression after seven months; included in authors' acquired-resistance cohort | Brain radiation; narrative describes initial primary-tumor biopsy and resistance lymph-node biopsy. Exact individual initial-response category/duration not recovered here |
| P6 | Nivolumab; progression after 21 cycles; included in authors' acquired-resistance cohort | Prior whole-brain/primary-tumor radiation and chemotherapy; baseline specimen collected at surgery after five chemotherapy cycles, then additional chemotherapy before nivolumab |
| P7 | Nivolumab; explicit partial response for 15 months, then progression and biopsy | Prior platinum/pemetrexed; exact specimen-site/date crosswalk still needs confirmation |

Potential inventory: **7 resistance-stage patients and 7 source-paired earlier specimens**, not 14 independent patients. Regimen strata are P1/P3/P4/P6/P7 nivolumab, P5 pembrolizumab with radiation history, and P2 nivolumab/ipilimumab followed by nivolumab. Do not exclude combinations merely because they differ from monotherapy; assess their relevance to the prospectively stated family and report them separately. No universal per-cancer minimum is introduced by this audit.

The cohort-level acquired-resistance statement supplies meaningful clinical evidence. It is not a substitute for recording missing individual dates, response categories and durations. Supplementary Table 1 and the swimmer plot should complete exact treatment/biopsy chronology where obtainable. Ordinary supplement requests returned a browser challenge or inaccessible attachment; neither was bypassed. Some narrative tissue descriptions elsewhere in the paper are inconsistent, so precise site metadata must be adjudicated before site-adjusted comparisons.

**The earlier samples are not uniformly immediate pretreatment specimens for the index ICI.** Changes between initial diagnostic tissue and resistance may span chemotherapy, radiation, anatomical-site changes and disease evolution. Such pairs can provide descriptive temporal context; a paired change cannot automatically be attributed to ICI or acquired resistance. This does not automatically invalidate measuring recurrence in the resistance-stage specimens themselves.

Final patient denominators for any protein endpoint remain unknown until clinical crosswalk, technical usability, tumor-cell identification and component coverage pass. A patient missing adequate usable tumor cells remains missing, not a zero score. Repeated ROIs, tissue sections and cells do not increase the independent patient count.

## Cell labels, pairing fields and object expectations

The publication describes segmentation using nuclear/membrane staining, Ilastik and CellProfiler, with per-cell mean marker intensities and arcsinh transformation (cofactor 1). Tumor cells are described as pan-cytokeratin positive; other major classes include CD3 T cells, CD11b myeloid cells, CD31/vWF vessels and SMA stroma.

The public construction script explicitly creates the following expected column metadata: `PatientID`, `TherapyStatus`, `Block`, `ImageNumber`, `BatchID`, `SampleID`, `ROI`, `CellNumber`, `Center_X`, `Center_Y`, `Area`, `MajorAxisLength`, `MinorAxisLength`. It builds cell IDs from sample, ROI and cell number and stores the assay, panel and metadata in a SingleCellExperiment. The analysis script maps `pre` to `Response` and `post` to `Resitance` [source spelling]; these are source labels, **not proof the earlier tissue was collected while clinically responding to ICI**.

The script assigns `Cluster_levels = Tumour` to clusters **6, 7, 13, 18, 19, 20, 24**; separate labels are Stroma, Vessel, T cell, Myeloid and Undefined. These source-code statements support annotation availability but do not verify that all fields survive in the deposited RDS. Confirm them after authorized extraction, check one-to-one patient/timepoint/ROI relationships and retain all unknowns.

Pan-cytokeratin plus pathology-selected tumor regions is a plausible cancer-cell classification, not genomic proof. Normal epithelial inclusion, loss of epithelial markers in malignant subpopulations, segmentation spillover and immune-cell adjacency require consideration. Because source clustering used the protein panel, testing a program that also affected cluster assignment can induce selection artifacts. A prospectively specified sensitivity based on epithelial morphology/pan-cytokeratin and exclusion of clearly immune cells should be independent of the tested functional proteins where feasible.

## Assay coverage: 41 antibody rows, 39 independent channels

The actual `AK_List.csv` contains these targets:

| Measurement class | Listed targets |
|---|---|
| Structural/segmentation or lineage | pan Cytokeratin AE1; Keratin Epithelial AE3; Histone H3; SMA; CD31; vWF |
| Proteins potentially relevant to a restricted cancer-cell functional component | HLA-ABC; HLA-DR; CD274/PD-L1; IDO; TMEM173/STING; CD73; Carbonic Anhydrase IX; cleaved Caspase3; CD38 |
| Additional immune/phenotyping targets | CD204; VISTA; CD11b; CD14; CD134; CD8a; CD68; TCF1/TCF7; CD206; CD15; FOXP3; GITR/TNFRSF18; CD163; CD279/PD-1; CD3; CD4; LAG-3; Granzyme B; CD27; Siglec-1/CD169; CD45RO; CD45; CCL21; CD278/ICOS; CD45RA; CD303 |

AE1 and AE3 share metal **Pr141**; CD31 and vWF share **Yb172**. These are two mixed measurements, not four independently resolved observations. HLA-ABC is one pan-reactive antibody/channel, not separate measurements of HLA-A, HLA-B and HLA-C. CD45RA and CD45RO are isoform-related measurements, not independent genes. Cleaved caspase-3 measures a protein cleavage state, not total CASP3 transcript abundance. The panel contains **no Ki67**, STAT1, IRF1, B2M or TAP proteins.

The table describes what can be measured; it does not nominate a candidate or report activity. Protein abundance is not interchangeable with transcript abundance, flux, phosphorylation or pathway activation.

## Conditional orthogonal endpoint and measurement limits

Several independent channels could potentially represent a restricted, prospectively justified **IFN-associated antigen-presentation/immunoregulation protein component**, for example through HLA-ABC, HLA-DR, CD274 and IDO1. That example is an assay-coverage possibility, not a selected program, effect direction or positive result. The mapping from a discovery program to its measured protein component must be documented and frozen before NSCLC values are inspected. If too little of the biological component is covered, label it unassessable.

This panel cannot automatically validate a whole Hallmark IFN program: important signaling/processing proteins are absent, pan-HLA measurements aggregate genes, and multiple regulatory inputs affect the covered proteins. STING abundance does not establish STING activation. CAIX alone does not validate a hypoxia program; cleaved caspase-3 alone does not validate a coordinated apoptosis program. Proliferation, oxidative phosphorylation, broad EMT and DNA-repair programs lack sufficient direct coverage here. A generic score averaging the available functional markers would not become an MSI merely because several markers were measured.

If a component is biologically sufficient, test **coordination separately from score abundance**: predefined relationships across its independently measured proteins within source-defined tumor cells must recur across patients and survive ROI/segmentation/composition sensitivities. Cell-level co-occurrence alone is not independent-patient replication. Patient-level summaries and uncertainty must remain primary; correlation among thousands of cells must not be used as thousands of independent clinical observations. Nulls should preserve relevant marker distributions, ROI/technical structure and missingness; a hand-picked immune-rich panel is not an unbiased whole-proteome background.

A supported result could state: “A prespecified protein component of the RNA-derived program recurs within source-identified cancer cells in this independent acquired-resistant NSCLC cohort.” It cannot state complete transcriptomic replication, genomic conservation, resistance-specific enrichment, selection or causality without the additional measurements/comparators/experiments those claims require.

## Verified reader feasibility on fixtures only

An isolated Python 3.12 environment at `/tmp/genedis-rds-reader-fixture-env` was created without changing the project's original `.venv`. It contains `rds2py==0.10.6`, `singlecellexperiment==0.7.0`, `summarizedexperiment==0.8.0`, `biocframe==0.8.1`, `biocutils==0.5.0`, `compressed-lists==0.4.5`, `genomicranges==0.9.0`, `iranges==0.7.3` and `numpy==2.5.4`. `rdata==1.1.0` was also installed but is not required for the demonstrated route. No R runtime is needed for these fixture tests.

**Verified:** `rds2py.read_rds(path)` read a synthetic 3-marker/4-cell SingleCellExperiment with three distinct assays (`counts`, `exprs`, `zscaled`). All three numeric arrays, marker/cell names, row annotations and PatientID/TherapyStatus/ROI/tumor-class fields matched the synthetic originals. A second, independently R-generated package fixture containing only random numbers also passed: [BiocPy `sumexpt.rds`](https://github.com/BiocPy/rds2py/blob/master/tests/data/sumexpt.rds), 8,966 bytes, SHA256 `5216e979076804b803dd18eceb445d102d8aa3047b20d00a5f01a64878b059c5`, shape 200 by 6, column names A–F and alternating ChIP/Input labels. Its [generation script](https://github.com/BiocPy/rds2py/blob/master/tests/data/generate_files.R) uses synthetic random matrices. No study expression or protein data were used.

**Important conversion limitation found by the fixture:** the high-level SingleCellExperiment constructor lost object-level `metadata`, although assays and row/column metadata survived. Low-level slot extraction preserved the fixture's metadata. BiocPy string/numeric wrappers also require deliberate conversion; some synthetic numeric columns returned lists of length-one vectors. Do not stringify wrappers, flatten arbitrary list-valued columns or silently drop metadata. A subsequent study extraction must verify exact dimensions/order, factor levels/missing values, column identities and marker channels against source metadata, and preserve any unsupported slots separately.

The tested low-level method, pinned to the versions above, is:

```python
from rds2py.PyRdsReader import PyRdsParser
from rds2py.generics import _dispatcher

parser = PyRdsParser(path)
root = parser.root_object
raw_column_metadata = parser._process_object(root.load_attribute_by_name("colData"))
column_metadata = _dispatcher(raw_column_metadata)
raw_object_metadata = parser._process_object(root.load_attribute_by_name("metadata"))
object_metadata = _dispatcher(raw_object_metadata)
```

`_process_object` and `_dispatcher` are private/version-specific interfaces, so their behavior must stay fixture-tested and pinned. The high-level route can supply `assays`, `row_names`, `column_names`, `row_data` and `column_data`; low-level reads can recover omitted object metadata. Retain the immutable input and checksum. Preserve the deposited assay values and transformation provenance; do not apply arcsinh again to an already transformed assay.

Sources for the reader: [official documentation](https://www.biocpy.org/rds2py/), [SCE parser](https://github.com/BiocPy/rds2py/blob/master/src/rds2py/read_sce.py), [low-level reader](https://github.com/BiocPy/rds2py/blob/master/src/rds2py/PyRdsReader.py), [native parser wrapper](https://github.com/BiocPy/rds2py/blob/master/lib/src/rdswrapper.cpp). The native wrapper calls `rds2cpp::parse_rds` in its constructor: **it eagerly parses the whole file before slots are accessed**. Neither `read_rds` nor `parse_rds` exposes a documented skip-assay/streaming metadata option. Slot-selective Python conversion avoids additional realization/copies of unwanted assays, but is not an on-disk metadata-only parser. For a Seurat object, `meta.data` is the anticipated slot; its presence must be checked through `root.get_attribute_names()` instead of assumed. This audit did not test a real Seurat object.

Practical estimates are provisional: the 159.8 MB Hiltbrunner object is a reasonable first technical extraction attempt; allow roughly 10–30 minutes for retrieval, decoding, schema checks and metadata export, and reserve several GB of RAM until actual dimensions are known. The small fixture's peak RSS was approximately 73 MB and does **not** benchmark the study object. A 3 GB compressed Seurat file may expand past available memory, especially with complete Python conversion; its size does not establish a safe bound on a 17 GB machine. A separate process with a documented memory/time limit and no full assay conversion is preferable if such a technical attempt is authorized. Failure under that bound is a resource/format limitation, not evidence of biological absence. Do not install a full R/Bioconductor stack or download the study object based on this fixture result alone; coordinate the technical retrieval/QC step with the overall gate.

The fixtures establish a plausible reader, **not faithful decoding of the actual Hiltbrunner object or scientific GO**. No real IMC RDS, Seurat RDS, expression matrix, intensity or molecular effect was downloaded/read in this reader test.

## Actual processed-object structural QC — authorized follow-up

The root agent retrieved the exact listed object and verified its deposited MD5. SHA256: `2d81b58ac70c355f78bbc97216af2d1d2f8d472993736bcd263681d76d868acf`. A separate process with a 4 GiB address-space limit and 180-second alarm completed structural/annotation extraction in approximately **4.0 seconds**, peaking at approximately **566 MiB RSS**. The versioned aggregate receipt is [HILT_STRUCTURE_QC.json](HILT_STRUCTURE_QC.json); full cell/feature metadata exports remain local under ignored `data/external/cellular_2026_10_31/` with their hashes in that receipt.

Verified structure:

- **99,659 cells**, unique cell IDs and 22 column-metadata fields. All four assay cell-name vectors exactly match cell-metadata order.
- Four assays: **counts, exprs, logcounts, zscaled**, each **41 by 99,659**, with identical feature-name order. No assay values were extracted or summarized. Assay names do not themselves prove transformations; the numeric relation among these assays remains untested.
- **39 antibody measurement channels plus Iridium and Iridium2 DNA stains**, explaining 41 assay rows despite 39 independent antibody channels. The combined `CD31 / vWF` measurement and single pan-cytokeratin measurement are explicit in the actual feature names.
- `elementMetadata` has **41 rows and zero columns**; marker identity comes from the matching assay dimnames, not a populated antibody row table. The separately deposited reagent manifest remains necessary.
- `PatientID`, `TherapyStatus`, `SampleID`, `ROI`, `BatchID`, `Cluster_levels` and source clustering columns are present. There are seven internal patient IDs, each with one pre and one post specimen. Each pair has the same recorded acquisition-date batch label; this does not establish every aspect of processing comparability.
- Object-level metadata contains `graph`. It was not converted; no transformation-provenance values or graph contents were inspected.

**A clinical identifier crosswalk is unresolved:** the SCE uses IDs **2, 4, 5, 9, 11, 12, 14**, whereas the publication describes P1–P7. The source script orders these seven internal IDs, but does not explicitly state their correspondence to P1–P7. Do not infer a clinical crosswalk solely from ordinal position, phenotype or apparent similarity of results. Exact individual regimen/site histories therefore cannot yet be attached to the processed records.

Source-defined tumor-label counts reveal a second important limitation:

| Internal SCE ID | Pre cells labelled Tumour | Post cells labelled Tumour |
|---|---:|---:|
| 2 | 71 | 5,497 |
| 4 | 9 | 79 |
| 5 | 16 | 2 |
| 9 | 222 | **0** |
| 11 | 172 | 5 |
| 12 | 15 | 1,483 |
| 14 | 4,453 | 3,355 |

The object contains **15,379 source-labelled tumor cells overall**, but these are very unevenly distributed. Seven paired specimens do not provide seven usable tumor-cell resistance profiles: one post specimen has no source-labelled tumor cells, and two have only two/five. No universal cell minimum is imposed here. Precision, reliable joint protein measurement, segmentation quality and the chosen program determine usability before candidate tests. Zero tumor cells is missing measurement, not zero program activity. Source classification may require independent pathology/segmentation sensitivity review; it must not be changed merely to obtain a desired molecular result.

**Actual-object outcome: structural access passes; clinical crosswalk and program-specific technical suitability remain conditional.** There is no automatic scientific GO, resistance-specific inference or positive program finding.

## Conditions before molecular go

1. Verify both non-NSCLC discovery cancer sources and patient independence under the full design; this NSCLC audit alone does not do so.
2. Prospectively specify PD-(L)1-containing-family comparability and regimen/history strata, with explicit additional-agent and radiation limitations.
3. Complete the seven-patient specimen/timepoint/clinical crosswalk and distinguish post-only recurrence from the more confounded paired historical comparison.
4. Verify legitimate processed-object access and faithful assay/metadata extraction without relying on unlisted native CSVs; inspect technical structure before program effects.
5. Map each frozen program to independent protein measurands; justify sufficient biological coverage and specify unassessable components before viewing NSCLC values.
6. Freeze tumor-cell rules, score/coordination statistics, patient-level nulls, uncertainty, multiplicity and negative/inconclusive outcomes before candidate tests.

Until these conditions pass, the verdict remains **CONDITIONAL; no candidate selection or automatic GO**. A genuine orthogonal-protein validation path is preserved without silently upgrading it to RNA replication or discarding the PI's full pan-cancer objective.
