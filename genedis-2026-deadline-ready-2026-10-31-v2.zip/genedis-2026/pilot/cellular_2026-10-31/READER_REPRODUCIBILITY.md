# Isolated RDS metadata readers

These readers support technical access/QC. They select no molecular candidates and compute no program scores. Native RDS readers eagerly deserialize the file; logically extracting metadata is not a promise to avoid parsing assay bytes. Original input files and the project's original `.venv` stay unchanged.

## Python reader and retained failure

The fixture-tested Python 3.12 environment is pinned in [requirements-reader-python.txt](requirements-reader-python.txt). Recreate it separately:

```bash
python -m venv /tmp/genedis-rds-reader-fixture-env
/tmp/genedis-rds-reader-fixture-env/bin/python -m pip install -r pilot/cellular_2026-10-31/requirements-reader-python.txt
```

[extract_yang_structure.py](extract_yang_structure.py) bounds a single `rds2py` native parse and requests only `meta.data`. The actual Yang attempt failed on an unsupported serialized closure (SEXP type 3) in command history after 36.566 seconds, peaking at approximately 8.1 GiB RSS under a 12 GiB address-space cap. [YANG_STRUCTURE_QC.json](YANG_STRUCTURE_QC.json) preserves the failure. No metadata CSV or RNA assay was extracted. A synthetic S4 object with closure-valued command history reproduced this format failure; it is not evidence that clinical metadata or biological signals are absent.

The actual Hiltbrunner SCE was structurally readable with this environment; [HILT_STRUCTURE_QC.json](HILT_STRUCTURE_QC.json) records precise limits. High-level `rds2py` SCE conversion lost object-level metadata in a synthetic fixture, so use its separately tested low-level slot access where necessary. Do not silently drop unsupported slots or assume Python wrapper representations preserve factor/NA semantics without checks.

## Isolated base-R fallback

The tested runtime is **Debian 13 x86_64**, R **4.5.0**, Debian package **4.5.0-3**. The package was downloaded from the official Debian mirror, not installed system-wide:

- URL: https://deb.debian.org/debian/pool/main/r/r-base/r-base-core_4.5.0-3_amd64.deb
- Bytes: 28,626,144.
- SHA256: `6c529a906d2a26cf78e6c24eaa96e0bbd061b032e6c824f9a61e5f313353b155`.
- Local extraction: `/tmp/genedis-base-r-4.5.0/root` using `dpkg-deb -x`.
- The host already supplied every native `libR.so` dependency according to `ldd`. Another host may need a proper R installation or matching dependencies; this is not a cross-platform runtime claim.
- Only extracted `/usr/lib/R/etc` symlinks pointing at `/etc/R/*` were redirected to their equivalents under the extracted root. `Renviron.ucf` was copied to the isolated `etc/R/Renviron`. No `/etc`, apt state, system library or original project environment was changed.

Run the actual binary at `root/usr/lib/R/bin/exec/R`, with `R_HOME=root/usr/lib/R`, `LD_LIBRARY_PATH=root/usr/lib/R/lib`, and `R_SHARE_DIR=root/usr/share/R/share`. [run_base_r_metadata.py](run_base_r_metadata.py) supplies these command-local variables, a separate child process, address-space cap and alarm. [extract_seurat_metadata_base.R](extract_seurat_metadata_base.R) calls only `readRDS` and `attr(x,"meta.data",exact=TRUE)`; it does not invoke Seurat methods or access assay slots.

The extractor exports a metadata-only RDS, CSV and schema TSV. **The metadata RDS is authoritative for exact R factor levels, ordered factors, missing values and types**. CSV uses a collision-checked `__R_NA__` token, preserving ordinary empty strings separately; schema TSV records column classes, missing counts and factor levels. Preserve all three together. Serialization can still encounter missing namespace requirements on a real object even when a generic fixture passes.

Use fresh output/receipt paths for each attempt: the launcher refuses to overwrite existing evidence. A failed or timed-out child, or a missing required export, returns a nonzero launcher exit status and retains the failure receipt. A technical failure cannot be treated as a successful extraction merely because a JSON receipt was written.

## Reproduce the synthetic check

Use [reader_metadata_fixture.R](reader_metadata_fixture.R) in separate R sessions: first `create /tmp/reader-fixture`, then run the base-R extractor on that fixture, then `verify /tmp/reader-fixture`. The fixture is a synthetic S4 object containing factor/ordered-factor/NA metadata, a closure in command history and an assay that the metadata extractor never accesses.

```bash
python pilot/cellular_2026-10-31/run_base_r_metadata.py \
  --runtime-root /tmp/genedis-base-r-4.5.0/root \
  --input /tmp/reader-fixture/synthetic_seurat_closure.rds \
  --output-prefix /tmp/reader-fixture/base_metadata_fixture \
  --receipt /tmp/reader-fixture/base_metadata_fixture.json \
  --memory-gib 2 --timeout-seconds 30
```

The tested base-R extraction returned a metadata-only RDS exactly identical to the original `meta.data` in a fresh session without defining its S4 class or installing Seurat. The Python closure-failure fixture and this base-R success are complementary format tests. They do not establish any actual cohort's acquired-resistance eligibility, statistical precision or primary-discovery status. Yang remains exploratory under the PI's stricter primary-case criteria.

The committed fixture and both readers were exercised together; [READER_FIXTURE_QC.json](READER_FIXTURE_QC.json) records the base-R exact-metadata pass and expected Python closure failure. Python source syntax and whitespace checks also passed.

## Actual Yang base-R metadata outcome

After the fixture check, the authorized actual-object fallback succeeded under the same **12 GiB / 180-second** bound: **85,443 metadata rows and 31 source fields**, 46.797 seconds, approximately **8.0 GiB peak child RSS**. [YANG_BASE_R_QC.json](YANG_BASE_R_QC.json) records the successful fallback separately from the preserved Python failure. The full metadata-only RDS, CSV and schema TSV remain ignored under `data/external/cellular_2026_10_31/yang_base_cellmetadata*`; their hashes are recorded in the receipt. No RNA assay was accessed, converted or summarized.

All metadata rows carry source `cell_type=Tumor`. The object spans 23 source patient IDs and 31 source specimens. Actual source metadata establish that `509_1` and `509_2` are **both POST** specimens, with 11,564 and 298 cells respectively, not a pretreatment/resistance pair. `620_2` has 900 cells and is POST under `ICI_combo`; `620_1` has 201 cells, PRE under `ICI_PD1`, and different response/PFS labels. The latter is not automatically a baseline for the later combination-treatment line. Grouped treatment labels, day and PFS fields require clinical interpretation against the publication and cannot alone establish progression-linked biopsy purpose or precise drug exposure.

The metadata include authors' `S.Score`, `G2M.Score`, `Phase`, `metaprogram` and `cell_subtype` fields. They were preserved, but their molecular score values were not summarized or adopted as this study's results. Technical metadata access does not change Yang's current exploratory status or open the primary molecular-discovery gate.
