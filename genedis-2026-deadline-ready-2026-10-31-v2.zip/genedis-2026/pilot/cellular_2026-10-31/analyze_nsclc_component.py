"""Fail-closed, conditional restricted-protein component runner.

Implementing this runner does not freeze its proposed endpoint. Real SCE access
requires a GO gate tied to the exact bytes of a FROZEN protocol. No P values,
clinical confidence intervals, whole-pathway scores or resistance claims.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path
import platform
import sys

import numpy as np

ANALYSIS_ID = "NSCLC_ORTHOGONAL_IFNG_COMPONENT"
DIRECT = {"CD38": "CD38", "IDO1": "IDO", "CD274": "PD-L1"}
CONTEXT = {"HLA_ABC_aggregate": "HLA-ABC", "HLA_DR_complex": "HLA-DR"}
PATIENT_MAP = {"P1": "2", "P2": "4", "P3": "5", "P4": "9", "P5": "11", "P6": "12", "P7": "14"}
SOURCE_SHA = "2d81b58ac70c355f78bbc97216af2d1d2f8d472993736bcd263681d76d868acf"
LIMITATIONS = [
    "Only three direct proteins represent a restricted component; no whole-RNA-program validation or pathway flux.",
    "HLA channels are separate aggregate/complex context, never expanded into independent genes.",
    "Source Tumour clustering used the same panel and can induce selection/circularity.",
    "The marker-restriction sensitivity intersects source Tumour labels; it is not independent tumor identification and does not remove clustering circularity.",
    "ROIs were selected for CD3-high/low and pan-cytokeratin context; they are not an unbiased tumor census.",
    "Cells/ROIs are not independent clinical patients; no patient-population CI or inferential P value is supplied.",
    "Low/zero-cell and constant-channel results are unassessable, not absence or negative molecular findings.",
]


def proposed_protocol():
    """Return a PROPOSAL for explicit root/PI freezing, never an executable GO."""
    return {
        "analysis_id": ANALYSIS_ID, "status": "PROPOSED", "assay": "exprs",
        "source_sce_sha256": SOURCE_SHA, "direct_features": DIRECT,
        "context_features": CONTEXT, "source_patient_map": PATIENT_MAP,
        "partial_covariates": ["intercept", "log1p_Area", "Histone H3_exprs"],
        "covariates_rank_transformed": False, "minimum_residual_df": 10,
        "minimum_immune_reference_cells": 20, "immune_reference_percentile": 75,
        "quantile_method": "linear", "immune_labels": ["Myeloid", "T cell"],
        "sensitivity_rules": ["CD45 < immune_ROI_q75", "pan Cytokeratin > immune_ROI_q75"],
        "primary_tumour_label": "Tumour", "post_state": "post",
        "clinical_cases": {
            p: {"regimen": r, "resistance_months_supplement": m,
                "source": "Hiltbrunner2023 main patient history and Supplementary Table1",
                "limits": "Earlier tissue may precede other therapies; exact chronology discrepancies retained"}
            for p, r, m in [
                ("P1", "nivolumab", 10), ("P2", "nivolumab/ipilimumab then nivolumab", 6),
                ("P3", "nivolumab after BRAF/MEK and other therapy", 7), ("P4", "nivolumab", 9),
                ("P5", "pembrolizumab; brain radiation history", 8), ("P6", "nivolumab", 8),
                ("P7", "nivolumab", 15)]
        },
        "protocol_limits": LIMITATIONS,
    }


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_gate(gate_path, protocol_path):
    """Must run before importing an RDS reader or opening the study object."""
    gate_bytes = Path(gate_path).read_bytes()
    protocol_bytes = Path(protocol_path).read_bytes()
    gate = json.loads(gate_bytes)
    protocol = json.loads(protocol_bytes)
    json.dumps(protocol, allow_nan=False)
    digest = hashlib.sha256(protocol_bytes).hexdigest()
    if gate.get("decision") != "GO" or protocol.get("status") != "FROZEN":
        raise ValueError("No GO gate and FROZEN protocol: real assay access is blocked")
    if gate.get("protocol_sha256") != digest:
        raise ValueError("GO gate does not match exact protocol bytes")
    if gate.get("analysis_id") != ANALYSIS_ID or protocol.get("analysis_id") != ANALYSIS_ID:
        raise ValueError("Analysis identity mismatch")
    expected = proposed_protocol()
    for key in expected:
        if key in ["status", "clinical_cases", "protocol_limits"]:
            continue
        if protocol.get(key) != expected[key]:
            raise ValueError(f"Runner/protocol mismatch for {key}; amend explicitly before effects")
    if set(protocol.get("clinical_cases", {})) != set(PATIENT_MAP):
        raise ValueError("Frozen clinical annotations must retain all seven source patients")
    return protocol, digest, hashlib.sha256(gate_bytes).hexdigest()


def midranks(values):
    values = np.asarray(values, dtype=float)
    order = np.argsort(values, kind="mergesort")
    result = np.empty(len(values), dtype=float)
    start = 0
    while start < len(values):
        end = start + 1
        while end < len(values) and values[order[end]] == values[order[start]]:
            end += 1
        result[order[start:end]] = (start + end - 1) / 2 + 1
        start = end
    return result


def pearson(values_a, values_b):
    a = values_a - values_a.mean()
    b = values_b - values_b.mean()
    denominator = float(np.linalg.norm(a) * np.linalg.norm(b))
    if denominator <= np.finfo(float).eps * max(1.0, np.linalg.norm(values_a) * np.linalg.norm(values_b)):
        return None
    return float(np.clip(np.dot(a, b) / denominator, -1, 1))


def pair_correlations(a, b, area, histone, minimum_df=10):
    a, b, area, histone = [np.asarray(v, dtype=float) for v in [a, b, area, histone]]
    good = np.isfinite(a) & np.isfinite(b) & np.isfinite(area) & np.isfinite(histone) & (area >= 0)
    a, b, area, histone = [v[good] for v in [a, b, area, histone]]
    n = len(a)
    result = {"n_complete_cells": n, "spearman": None, "partial_rank_correlation": None,
              "status": "unassessable", "reason": None, "design_rank": None, "residual_df": None}
    if n == 0:
        result["reason"] = "no_complete_cells"
        return result
    design = np.column_stack([np.ones(n), np.log1p(area), histone])
    rank = int(np.linalg.matrix_rank(design))
    result.update(design_rank=rank, residual_df=n-rank-1)
    if n-rank-1 < minimum_df:
        result["reason"] = "residual_df_below_frozen_minimum"
        return result
    ra, rb = midranks(a), midranks(b)
    raw = pearson(ra, rb)
    if raw is None:
        result["reason"] = "constant_channel"
        return result
    result["spearman"] = raw
    if rank != 3:
        result.update(status="raw_only", reason="technical_covariate_design_rank_deficient")
        return result
    residual_a = ra - design @ np.linalg.lstsq(design, ra, rcond=None)[0]
    residual_b = rb - design @ np.linalg.lstsq(design, rb, rcond=None)[0]
    # Numerical OLS noise is not evidence of residual variation.
    if (np.linalg.norm(residual_a) <= 1e-10 * max(1, np.linalg.norm(ra)) or
            np.linalg.norm(residual_b) <= 1e-10 * max(1, np.linalg.norm(rb))):
        result.update(status="raw_only", reason="constant_or_numerically_zero_residual")
        return result
    partial = pearson(residual_a, residual_b)
    result.update(partial_rank_correlation=partial, status="assessable" if partial is not None else "raw_only",
                  reason=None if partial is not None else "constant_residual")
    return result


def sensitivity_mask(labels, cd45, panck, protocol):
    immune = np.isin(labels, protocol["immune_labels"]) & np.isfinite(cd45) & np.isfinite(panck)
    n = int(immune.sum())
    if n < protocol["minimum_immune_reference_cells"]:
        return None, {"status": "unavailable", "reason": "insufficient_ROI_immune_reference", "immune_cells": n}
    q = protocol["immune_reference_percentile"] / 100
    cd45_cut = float(np.quantile(cd45[immune], q, method="linear"))
    panck_cut = float(np.quantile(panck[immune], q, method="linear"))
    keep = np.isfinite(cd45) & np.isfinite(panck) & (cd45 < cd45_cut) & (panck > panck_cut)
    return keep, {"status": "calibrated", "immune_cells": n, "CD45_q75": cd45_cut, "panCK_q75": panck_cut}


def summaries(values):
    finite = np.asarray(values, dtype=float)
    finite = finite[np.isfinite(finite)]
    if not len(finite):
        return {"n_finite": 0, "median": None, "q25": None, "q75": None, "IQR": None}
    q25, median, q75 = np.quantile(finite, [.25, .5, .75], method="linear")
    return {"n_finite": len(finite), "median": float(median), "q25": float(q25),
            "q75": float(q75), "IQR": float(q75-q25)}


def analyze_arrays(metadata, channels, protocol):
    """Pure-array runner used by synthetic tests; no file or gate bypass CLI."""
    n = len(metadata["PatientID"])
    if any(len(v) != n for v in metadata.values()) or any(len(v) != n for v in channels.values()):
        raise ValueError("Cell metadata/channel length mismatch")
    reverse = {v: k for k, v in protocol["source_patient_map"].items()}
    post = np.asarray(metadata["TherapyStatus"]) == protocol["post_state"]
    groups = {}
    for i in np.flatnonzero(post):
        pid = str(metadata["PatientID"][i])
        if pid not in reverse:
            raise ValueError("Unmapped post-treatment patient")
        key = (pid, str(metadata["SampleID"][i]), str(metadata["ROI"][i]))
        groups.setdefault(key, []).append(i)
    roi_results = []
    for (pid, sample, roi), indices in sorted(groups.items()):
        ix = np.asarray(indices)
        labels = np.asarray(metadata["Cluster_levels"])[ix]
        tumour = labels == protocol["primary_tumour_label"]
        keep, calibration = sensitivity_mask(labels, channels["CD45"][ix], channels["pan Cytokeratin"][ix], protocol)
        for variant in ["source_Tumour", "source_Tumour_marker_restriction"]:
            available = variant == "source_Tumour" or keep is not None
            selected = tumour if variant == "source_Tumour" else (tumour & keep if keep is not None else np.zeros(len(ix), dtype=bool))
            selected_ix = ix[selected]
            row = {"publication_patient_id": reverse[pid], "source_patient_id": pid, "sample": sample, "ROI": roi,
                   "variant": variant, "status": "available" if available else "unavailable",
                   "source_tumour_cells": int(tumour.sum()), "selected_cells": int(selected.sum()) if available else None,
                   "clinical": protocol["clinical_cases"][reverse[pid]], "calibration": calibration,
                   "direct_channels": {}, "HLA_context_only": {}, "pairs": {}}
            if available:
                for gene, feature in protocol["direct_features"].items():
                    row["direct_channels"][gene] = summaries(channels[feature][selected_ix])
                for label, feature in protocol["context_features"].items():
                    row["HLA_context_only"][label] = summaries(channels[feature][selected_ix])
                for ga, gb in itertools.combinations(DIRECT, 2):
                    fa, fb = protocol["direct_features"][ga], protocol["direct_features"][gb]
                    row["pairs"][ga+"__"+gb] = pair_correlations(
                        channels[fa][selected_ix], channels[fb][selected_ix], np.asarray(metadata["Area"], dtype=float)[selected_ix],
                        channels["Histone H3"][selected_ix], protocol["minimum_residual_df"])
            roi_results.append(row)
    patients = []
    for case, pid in protocol["source_patient_map"].items():
        for variant in ["source_Tumour", "source_Tumour_marker_restriction"]:
            rr = [r for r in roi_results if r["source_patient_id"] == pid and r["variant"] == variant]
            result = {"publication_patient_id": case, "source_patient_id": pid, "variant": variant,
                      "ROI_count": len(rr), "available_ROIs": sum(r["status"] == "available" for r in rr),
                      "pairs": {}, "mean_of_ROI_channel_medians": {}}
            for ga, gb in itertools.combinations(DIRECT, 2):
                key = ga+"__"+gb
                result["pairs"][key] = {}
                for stat in ["spearman", "partial_rank_correlation"]:
                    vals = [r["pairs"][key][stat] for r in rr if key in r["pairs"] and r["pairs"][key][stat] is not None]
                    result["pairs"][key][stat] = {"assessable_ROIs": len(vals), "equal_ROI_mean": float(np.mean(vals)) if vals else None}
            for gene in protocol["direct_features"]:
                vals = [r["direct_channels"][gene]["median"] for r in rr if gene in r["direct_channels"] and r["direct_channels"][gene]["median"] is not None]
                result["mean_of_ROI_channel_medians"][gene] = {"measured_ROIs": len(vals), "equal_ROI_mean": float(np.mean(vals)) if vals else None}
            patients.append(result)
    return roi_results, patients


def across_patient_descriptives(patients):
    """Equal-patient descriptions of already equal-ROI results; no inference."""
    output = []
    pair_names = [a+"__"+b for a, b in itertools.combinations(DIRECT, 2)]
    for variant in ["source_Tumour", "source_Tumour_marker_restriction"]:
        subset = [p for p in patients if p["variant"] == variant]
        for pair in pair_names:
            for statistic in ["spearman", "partial_rank_correlation"]:
                values = [p["pairs"][pair][statistic]["equal_ROI_mean"] for p in subset
                          if pair in p["pairs"] and p["pairs"][pair][statistic]["equal_ROI_mean"] is not None]
                output.append({"variant": variant, "pair": pair, "statistic": statistic,
                               "source_patients_retained": len(subset), "assessable_patients": len(values),
                               "equal_patient_mean": float(np.mean(values)) if values else None,
                               "median_patient_value": float(np.median(values)) if values else None,
                               "minimum_patient_value": float(np.min(values)) if values else None,
                               "maximum_patient_value": float(np.max(values)) if values else None,
                               "interpretation": "descriptive only; no clinical population interval or P value"})
    return output


def load_sce(path, protocol):
    # Imported only after gate validation and actual source-byte verification.
    from rds2py.PyRdsReader import PyRdsParser
    from rds2py.generics import _dispatcher
    parser = PyRdsParser(str(path))
    root = parser.root_object
    frame = _dispatcher(parser._process_object(root.load_attribute_by_name("colData")))
    required = ["PatientID", "TherapyStatus", "SampleID", "ROI", "Cluster_levels", "Area"]
    metadata = {k: np.asarray(list(frame[k]), dtype=float if k == "Area" else str) for k in required}
    ids = list(frame.row_names)
    if len(set(ids)) != len(ids):
        raise ValueError("Duplicated source cell IDs")
    ld = root.load_attribute_by_name("assays").load_attribute_by_name("data").load_attribute_by_name("listData")
    names = list(ld.load_attribute_by_name("names").get_string_arr())
    assay = ld.load_vec_element(names.index(protocol["assay"]))
    dims = tuple(int(v) for v in assay.load_attribute_by_name("dim").get_numeric_data())
    dn = assay.load_attribute_by_name("dimnames")
    features = list(dn.load_vec_element(0).get_string_arr())
    if list(dn.load_vec_element(1).get_string_arr()) != ids:
        raise ValueError("Assay/metadata cell-name order mismatch")
    needed = list(DIRECT.values()) + list(CONTEXT.values()) + ["CD45", "pan Cytokeratin", "Histone H3"]
    if len(set(features)) != len(features) or not set(needed).issubset(features):
        raise ValueError("Required channel absent or nonunique")
    matrix = assay.get_numeric_data().reshape(dims, order="F")
    return metadata, {feature: matrix[features.index(feature)].copy() for feature in needed}


def run(gate_path, protocol_path, sce_path, output_directory):
    protocol, protocol_hash, gate_hash = validate_gate(gate_path, protocol_path)
    # No study-file open can occur above this line.
    source_hash = sha256_file(sce_path)
    if source_hash != protocol["source_sce_sha256"]:
        raise ValueError("Source SCE checksum mismatch")
    metadata, channels = load_sce(sce_path, protocol)
    rois, patients = analyze_arrays(metadata, channels, protocol)
    out = Path(output_directory)
    out.mkdir(parents=True, exist_ok=False)
    (out / "roi_component.json").write_text(json.dumps(rois, indent=2, allow_nan=False)+"\n")
    (out / "patient_component.json").write_text(json.dumps(patients, indent=2, allow_nan=False)+"\n")
    (out / "across_patient_descriptives.json").write_text(json.dumps(across_patient_descriptives(patients), indent=2, allow_nan=False)+"\n")
    provenance = {"analysis_id": ANALYSIS_ID, "protocol_sha256": protocol_hash, "gate_sha256": gate_hash,
                  "source_sce_sha256": source_hash, "software": {"python": platform.python_version(), "numpy": np.__version__},
                  "runner_sha256": sha256_file(__file__), "frozen_protocol": protocol,
                  "assay": "exprs: canonical asinh(mean IMC intensity), cofactor 1",
                  "aggregation": "arithmetic mean of assessable ROI correlations within each patient; no cell weighting",
                  "partial_rank_definition": "midrank marker values, OLS residuals against intercept+raw log1p(Area)+exprs Histone H3",
                  "P_values_or_clinical_CIs_computed": False, "limitations": LIMITATIONS}
    (out / "provenance.json").write_text(json.dumps(provenance, indent=2)+"\n")
    return out


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    for name in ["gate", "protocol", "sce", "output-directory"]:
        p.add_argument("--"+name, required=True, type=Path)
    args = p.parse_args(argv)
    try:
        out = run(args.gate, args.protocol, args.sce, args.output_directory)
    except (ValueError, OSError, KeyError) as exc:
        p.exit(2, f"Blocked: {exc}\n")
    print(f"Restricted descriptive component outputs: {out}")


if __name__ == "__main__":
    main()
