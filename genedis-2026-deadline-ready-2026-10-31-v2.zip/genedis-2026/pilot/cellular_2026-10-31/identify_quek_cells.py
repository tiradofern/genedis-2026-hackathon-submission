"""Apply the frozen RNA cell-identity rule; no functional program analysis."""
import argparse
import csv
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "data/external/cellular_2026_10_31"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def classify_marker_rows(rows, protocol):
    """All specimens use identical rules; unavailable references yield NA."""
    if protocol["status"] != "FROZEN_BEFORE_LINEAGE_CLASSIFICATION_AND_PROGRAM_EFFECTS":
        raise ValueError("Frozen identity protocol required")
    if not rows or len({r["cell_id"] for r in rows}) != len(rows):
        raise ValueError("Empty input or duplicate cell identifiers")
    libraries = [r["orig.ident"] for r in rows]
    if any(not x or x != x.strip() for x in libraries):
        raise ValueError("Explicit library identifiers required")
    lineage = protocol["primary_lineage_genes"]
    ir = protocol["confident_immune"]
    im = [ir[k] for k in ("T", "B", "myeloid")]
    sr = protocol["confident_stromal_or_endothelial"]
    sm = [sr[k] for k in ("stromal", "endothelial")]
    genes = sorted(set(lineage + ["PTPRC"] + sum(im, []) + sum(sm, [])))
    numeric = {}
    for key in genes + ["count_sum", "detected_genes", "exported_MT_percent"]:
        v = np.array([float(r[key]) for r in rows])
        if np.any(~np.isfinite(v)) or np.any(v < 0):
            raise ValueError(f"Invalid identity measurements: {key}")
        if key != "exported_MT_percent" and np.any(v != np.floor(v)):
            raise ValueError(f"Noninteger counts: {key}")
        numeric[key] = v
    if np.any(numeric["exported_MT_percent"] > 100):
        raise ValueError("Mitochondrial percent above 100")
    total = numeric["count_sum"]
    if any(np.any(numeric[g] > total) for g in genes):
        raise ValueError("Marker exceeds complete library count")
    qr = protocol["technical_quality"]
    quality = ((total >= qr["minimum_released_RNA_UMI"])
               & (numeric["detected_genes"] >= qr["minimum_detected_genes"])
               & (numeric["exported_MT_percent"] <= qr["maximum_recomputed_MT_percent"]))
    immune = ((numeric["PTPRC"] >= ir["minimum_PTPRC_counts"])
              & np.logical_or.reduce([np.sum([numeric[g] > 0 for g in module], axis=0)
                  >= ir["minimum_detected_genes_in_one_module"] for module in im]))
    stromal = np.logical_or.reduce([np.sum([numeric[g] >= sr["minimum_counts_per_gene"]
                  for g in module], axis=0) >= sr["minimum_genes_in_one_module"] for module in sm])
    n_lineage = np.sum([numeric[g] >= protocol["lineage_minimum_counts_per_gene"] for g in lineage], axis=0)
    lineage_sum = np.sum([numeric[g] for g in lineage], axis=0)
    fraction = np.divide(lineage_sum, total, out=np.zeros_like(total), where=total > 0)
    if np.any(fraction > 1):
        raise ValueError("Lineage sum exceeds complete library count")
    references = {}
    ar = protocol["ambient_lineage_check"]
    for library in sorted(set(libraries)):
        ref = np.array([x == library for x in libraries]) & quality & immune
        n = int(ref.sum())
        threshold = (float(np.quantile(fraction[ref], ar["lineage_fraction_must_exceed_reference_quantile"], method="linear"))
                     if n >= ar["minimum_reference_cells"] else None)
        references[library] = dict(reference_cells=n,threshold=threshold,quantile=0.99,
            quantile_method="linear",comparison="strictly_greater_than",
            status="ASSESSABLE" if threshold is not None else "UNASSESSABLE_INSUFFICIENT_REFERENCE")
    output = []
    for i, library in enumerate(libraries):
        ref = references[library]
        known = ref["threshold"] is not None
        primary = bool(quality[i] and n_lineage[i] >= protocol["lineage_minimum_genes"]
                       and fraction[i] > ref["threshold"] and not immune[i] and not stromal[i]) if known else None
        strict = bool(primary and n_lineage[i] >= 3) if known else None
        status = ("unassessable_ambient_reference" if not known else
                  "lineage_positive_putative_malignant" if primary else
                  "failed_technical_quality" if not quality[i] else
                  "reference_lineage_or_mixed" if immune[i] or stromal[i] else "unclassified_or_mixed")
        output.append(dict(quek_quality=bool(quality[i]),quek_confident_immune=bool(immune[i]),
            quek_confident_stromal_endothelial=bool(stromal[i]),quek_lineage_genes_ge2=int(n_lineage[i]),
            quek_lineage_fraction=float(fraction[i]),quek_ambient_reference_n=ref["reference_cells"],
            quek_ambient_q99=ref["threshold"],quek_primary_putative_malignant=primary,
            quek_three_gene_sensitivity=strict,quek_identity_status=status))
    return output,references,genes


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input",type=Path,default=LOCAL/"quek_identity_marker_counts_anchored.csv")
    p.add_argument("--protocol",type=Path,default=Path(__file__).with_name("QUEK_CELL_ID_PROTOCOL.json"))
    p.add_argument("--output",type=Path,default=LOCAL/"quek_cell_identity_mask.csv")
    p.add_argument("--report",type=Path,default=Path(__file__).with_name("QUEK_CELL_ID_QC.json"))
    a = p.parse_args()
    if a.output.exists() or a.report.exists():
        p.error("Preserve prior outputs; choose fresh paths")
    if not a.output.resolve().is_relative_to(LOCAL.resolve()):
        p.error("Per-cell masks must remain in ignored local data")
    protocol_hash = sha256(a.protocol)
    protocol = json.loads(a.protocol.read_text())
    with a.input.open(newline="") as stream:
        r = csv.DictReader(stream)
        fields = r.fieldnames
        rows = list(r)
    masks,refs,genes = classify_marker_rows(rows,protocol)
    if set(fields) & set(masks[0]):
        raise ValueError("Classifier fields already present in input")
    a.output.parent.mkdir(parents=True,exist_ok=True)
    with a.output.open("x",newline="") as stream:
        w = csv.DictWriter(stream,fieldnames=fields+list(masks[0]))
        w.writeheader()
        for row,mask in zip(rows,masks):
            w.writerow(row|{k:("NA" if v is None else v) for k,v in mask.items()})
    groups = []
    for library,donor in sorted({(r["orig.ident"],r["RNA_mia_ID"]) for r in rows}):
        selected = [x for r,x in zip(rows,masks) if r["orig.ident"]==library and r["RNA_mia_ID"]==donor]
        groups.append(dict(library=library,unmodified_RNA_mia_ID=donor,input_cells=len(selected),
            quality_passing_cells=sum(x["quek_quality"] for x in selected),
            primary_putative_malignant_cells=sum(x["quek_primary_putative_malignant"] is True for x in selected),
            three_gene_sensitivity_cells=sum(x["quek_three_gene_sensitivity"] is True for x in selected),
            unassessable_cells=sum(x["quek_primary_putative_malignant"] is None for x in selected),
            identity_status_counts=dict(Counter(x["quek_identity_status"] for x in selected))))
    report = dict(audit="Frozen RNA cell identity; no functional programs",created_utc=datetime.now(timezone.utc).isoformat(),
        protocol=dict(path=str(a.protocol),sha256=protocol_hash,status=protocol["status"],hash_recorded_before_lineage_read=True),
        source=dict(path=str(a.input),bytes=a.input.stat().st_size,sha256=sha256(a.input)),
        software=dict(numpy=np.__version__,script_sha256=sha256(Path(__file__))),
        classification_gene_inputs=genes,same_algorithm_applied_to_all_cells=True,
        sex_markers_used_for_classification=False,clinical_response_used_for_classification=False,
        source_patient_labels_modified=False,program_scores_computed=False,molecular_candidates_selected=False,
        library_ambient_references=refs,aggregate_groups=groups,
        ignored_local_cell_mask=dict(path=str(a.output),bytes=a.output.stat().st_size,sha256=sha256(a.output),
                                    cells=len(rows),all_original_fields_preserved=True),
        limitations=[protocol["interpretation"],"No thresholds were lowered after classification.",
                     "Unassessable ambient references remain NA, not negative cells.",
                     "Cell-mask availability is not automatic clinical-cohort or complete-gate approval."])
    a.report.write_text(json.dumps(report,indent=2,allow_nan=False)+"\n")
    print(json.dumps(dict(groups=groups,library_references=refs,report=str(a.report)),indent=2))


if __name__ == "__main__":
    main()
