# NSCLC IMC assay coverage audit — October 31, 2026

**Status: metadata inventory only; no program selected and no molecular validation GO.** The actual deposited object contains 39 antibody channels and two DNA stains. This audit compares nominal reagent targets with all 50 published human Hallmark 2024.1.Hs definitions. It reads marker/reagent metadata and gene-set membership only; no intensity, expression, score, effect or molecular candidate was inspected. The complete machine-readable inventory is [ASSAY_COVERAGE.json](ASSAY_COVERAGE.json).

## Sources and counting rules

- Actual channel names: [HILT_STRUCTURE_QC.json](HILT_STRUCTURE_QC.json), derived from the deposited SCE without numerical assay conversion in the structural audit.
- Reagent identities: [Zenodo AK_List.csv](https://zenodo.org/records/8041882/files/AK_List.csv?download=1), 3,417 bytes; MD5 `e85a68a3fbaaf5ea749e02984397d5bc`; SHA256 `c43f2c9ec81b03228a2196bc1a686980ba0a3367c645d2b9c2a963048919e95c`. Its 41 antibody rows map to 39 metal channels because AE1/AE3 and CD31/vWF each share a channel.
- Benchmark definitions: complete cached [Hallmark GMT](../programs/sources/h.all.v2024.1.Hs.symbols.gmt) and [JSON](../programs/sources/h.all.v2024.1.Hs.json), release 2024.1.Hs. This is a complete coverage inventory, **not a new frozen analysis panel**. Their hashes are recorded in the JSON report.

There are **29 nominal direct gene-product channels mapping to 29 distinct gene symbols**. Two additional CD45 isoform channels map to PTPRC, and cleaved caspase-3 is a separate cleavage-state measurement. Seven further antibody channels represent a family, complex, mixed target or glycan without credited unique-gene coverage. These are target-identity categories, not seven failed reagents. Channel independence here means separately acquired measurements; it does not establish statistical independence.

HLA-ABC remains one aggregate channel; HLA-DR remains one complex-antigen channel. Neither is expanded into multiple measured genes. CD31/vWF and pan-cytokeratin mixtures are not deconvolved. CD15/HI98 recognizes Lewis-X carbohydrate, not a directly measured FUT4 protein. Histone H3 and generic CD3 are conservatively left without a unique-gene assignment in this inventory. Cleaved caspase-3 does not measure total CASP3 or its RNA.

The IDO mapping to **IDO1** is supported by the deposited SP260/Abcam ab245737 identity and the manufacturer's [product record](https://www.abcam.com/en-us/products/primary-antibodies/indoleamine-2-3-dioxygenase-antibody-sp260-bsa-and-azide-free-ab245737) and [2024 multiplex reference list](https://docs.abcam.com/pdf/general/reference-list-of-abcam-antibody-for-multiplex-ihc-jul-2024.pdf). This supports nominal target naming; it does not demonstrate specificity or detection reliability in these IMC specimens. For CD15/HI98 glycan identity, see the manufacturer's [HI98 data sheet](https://www.bdbiosciences.com/content/bdb/paths/generate-tds-document.us.555402.pdf). For the HLA-ABC clone, see the [EMR8-5 data sheet](https://www.bdbiosciences.com/content/bdb/paths/generate-tds-document.cn.565292.pdf). Manufacturer documents from another formulation establish epitope context, not validation of the study lot.

## All 50 Hallmark sets: nominal direct overlap

The numerator is the number of distinct gene products with direct nominal antibody targets, not transcript coverage, the number of active proteins, or a validation percentage. The complete original gene count is the denominator. Additional isoform/cleavage channels are listed separately and do not increase this numerator. **No numeric eligibility threshold or program nomination is imposed.**

| Hallmark program | Direct nominal overlap / full genes | Direct nominal gene products | Additional state-specific channels |
|---|---:|---|---|
| ADIPOGENESIS | 0/200 | — | — |
| ALLOGRAFT_REJECTION | 4/200 | CD4, CD8A, GZMB, PTPRC | CD45RO, CD45RA |
| ANDROGEN_RESPONSE | 0/101 | — | — |
| ANGIOGENESIS | 0/36 | — | — |
| APICAL_JUNCTION | 2/200 | CD274, PTPRC | CD45RO, CD45RA |
| APICAL_SURFACE | 0/44 | — | — |
| APOPTOSIS | 2/161 | CD14, CD38 | Cleaved Caspase3 |
| BILE_ACID_METABOLISM | 0/112 | — | — |
| CHOLESTEROL_HOMEOSTASIS | 0/74 | — | — |
| COAGULATION | 0/138 | — | — |
| COMPLEMENT | 2/200 | GZMB, ITGAM | Cleaved Caspase3 |
| DNA_REPAIR | 0/150 | — | — |
| E2F_TARGETS | 0/200 | — | — |
| EPITHELIAL_MESENCHYMAL_TRANSITION | 2/200 | ACTA2, NT5E | — |
| ESTROGEN_RESPONSE_EARLY | 0/200 | — | — |
| ESTROGEN_RESPONSE_LATE | 0/200 | — | — |
| FATTY_ACID_METABOLISM | 0/158 | — | — |
| G2M_CHECKPOINT | 0/200 | — | — |
| GLYCOLYSIS | 1/200 | NT5E | — |
| HEDGEHOG_SIGNALING | 0/36 | — | — |
| HEME_METABOLISM | 0/200 | — | — |
| HYPOXIA | 0/200 | — | — |
| IL2_STAT5_SIGNALING | 4/199 | ICOS, NT5E, TNFRSF18, TNFRSF4 | Cleaved Caspase3 |
| IL6_JAK_STAT3_SIGNALING | 2/87 | CD14, CD38 | — |
| INFLAMMATORY_RESPONSE | 2/200 | CD14, MSR1 | — |
| INTERFERON_ALPHA_RESPONSE | 0/97 | — | — |
| INTERFERON_GAMMA_RESPONSE | 3/200 | CD274, CD38, IDO1 | Cleaved Caspase3 |
| KRAS_SIGNALING_DN | 1/200 | PDCD1 | — |
| KRAS_SIGNALING_UP | 0/200 | — | — |
| MITOTIC_SPINDLE | 0/199 | — | — |
| MTORC1_SIGNALING | 0/200 | — | — |
| MYC_TARGETS_V1 | 0/200 | — | — |
| MYC_TARGETS_V2 | 0/58 | — | — |
| MYOGENESIS | 0/200 | — | — |
| NOTCH_SIGNALING | 0/32 | — | — |
| OXIDATIVE_PHOSPHORYLATION | 0/200 | — | — |
| P53_PATHWAY | 0/200 | — | — |
| PANCREAS_BETA_CELLS | 0/40 | — | — |
| PEROXISOME | 0/104 | — | — |
| PI3K_AKT_MTOR_SIGNALING | 0/105 | — | — |
| PROTEIN_SECRETION | 0/96 | — | — |
| REACTIVE_OXYGEN_SPECIES_PATHWAY | 0/49 | — | — |
| SPERMATOGENESIS | 0/135 | — | — |
| TGF_BETA_SIGNALING | 0/54 | — | — |
| TNFA_SIGNALING_VIA_NFKB | 0/200 | — | — |
| UNFOLDED_PROTEIN_RESPONSE | 0/113 | — | — |
| UV_RESPONSE_DN | 0/144 | — | — |
| UV_RESPONSE_UP | 0/158 | — | Cleaved Caspase3 |
| WNT_BETA_CATENIN_SIGNALING | 1/42 | TCF7 | — |
| XENOBIOTIC_METABOLISM | 0/200 | — | — |

For exact membership, CA9 is absent from all 50 sets, including HALLMARK_HYPOXIA; TMEM173 and its STING1 name are also absent. This is a property of this benchmark, not evidence that CAIX lacks a relationship to hypoxia or STING lacks an immune-signaling role. Broader biological-component mappings require separate justification and prospective specification.

## Complete channel inventory

| Actual channel | Nominal gene, if uniquely assigned | Measurement category |
|---|---|---|
| Histone H3 | Unassigned | protein family |
| SMA | ACTA2 | direct gene product |
| pan Cytokeratin | Unassigned | antibody mixture |
| CD38 | CD38 | direct gene product |
| HLA-DR | Unassigned | complex antigen |
| ICOS | ICOS | direct gene product |
| CD27 | CD27 | direct gene product |
| CD68 | CD68 | direct gene product |
| CD163 | CD163 | direct gene product |
| Siglec-1 / CD169 | SIGLEC1 | direct gene product |
| CD11b | ITGAM | direct gene product |
| CD204 | MSR1 | direct gene product |
| IDO | IDO1 | direct gene product |
| CD3 | Unassigned | complex antigen |
| LAG-3 | LAG3 | direct gene product |
| CD45RO | PTPRC | isoform specific |
| PD-1 | PDCD1 | direct gene product |
| CD73 | NT5E | direct gene product |
| CD134 | TNFRSF4 | direct gene product |
| Granzyme B | GZMB | direct gene product |
| PD-L1 | CD274 | direct gene product |
| TCF1 / TCF7 | TCF7 | direct gene product |
| CD45 | PTPRC | direct gene product |
| FOXP3 | FOXP3 | direct gene product |
| CD45RA | PTPRC | isoform specific |
| CD8a | CD8A | direct gene product |
| Carbonic Anhydrase IX | CA9 | direct gene product |
| GITR | TNFRSF18 | direct gene product |
| CD303 | CLEC4C | direct gene product |
| VISTA | VSIR | direct gene product |
| TMEM173 | TMEM173 | direct gene product |
| CD4 | CD4 | direct gene product |
| CD31 / vWF | Unassigned | antibody mixture |
| CD14 | CD14 | direct gene product |
| CCL21 | CCL21 | direct gene product |
| CD206 (MMR) | MRC1 | direct gene product |
| Cleaved Caspase3 | CASP3 | cleavage specific |
| Iridium | Unassigned | DNA stain |
| Iridium2 | Unassigned | DNA stain |
| CD15 | Unassigned | glycan epitope |
| HLA-ABC | Unassigned | aggregate antigen |

The JSON retains the exact source reagent rows, clones, vendors, catalogue numbers, metal tags and mapping caveats. Source metadata are preserved without silently correcting vendor/host spellings or discrepancies; for example, the cleaved-caspase entry requires reagent-level host/clone reconciliation before assay validation.

## Consequences for a later orthogonal test

A sparse, predominantly immune/phenotyping panel cannot validate a whole transcriptomic program solely by sharing its label or averaging whichever markers happen to be available. Conversely, a limited but biologically sufficient protein component could be tested after its definition, independent measurands, expected relationships and technical reliability are justified and frozen before NSCLC values are inspected. Completeness of a whole Hallmark set is not a universal requirement for such a restricted component.

A 39-channel within-cell rank is relative to a deliberately selected antibody panel, not a whole-proteome background. Do not apply the generic transcriptome-rank helper to these channels and interpret the result as calibrated program activity. Protein abundance does not establish activation, enzymatic flux, coordinated function or transcript abundance; STING activation and antigen-processing capacity need measurements beyond the corresponding target labels.

A later test must still resolve the clinical identifier crosswalk, tumor-cell ascertainment, assay transformations, reliable marker detection, segmentation/ROI effects and uneven cancer-cell sampling. Program coordination must be tested separately from abundance, using patient-level recurrence and appropriate technical nulls. Zero source-labelled tumor cells is missing measurement. Repeated cells and ROIs do not increase the independent-patient denominator. This audit does not open the full discovery-and-validation gate.
