"""Standalone descriptive RNA figures from completed result JSON only.

This script never reads study matrices or selects programs. Run on real result
files only after the parent clinical/protocol gate and analysis have completed.
Use the separately installed plotting environment; core dependencies are unchanged.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import tempfile

os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "genedis-plot-matplotlib"))
os.environ.setdefault("XDG_CACHE_HOME", str(Path(tempfile.gettempdir()) / "genedis-plot-cache"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
import numpy as np


FIXED_LIMIT = (
    "Melanoma: primary 6 cells; strict sensitivity 5 cells with residual df=1. "
    "Robust cross-cancer nomination is inconclusive. Cells are not independent clinical patients."
)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_result(result):
    """Require a complete family and explicit patient denominators; preserve NA."""
    rows = result.get("programs", [])
    names = [r.get("program") for r in rows]
    if len(names) != 50 or len(set(names)) != 50 or any(not isinstance(n, str) for n in names):
        raise ValueError("Figures require all 50 uniquely named programs; no top-only filtering")
    patients = result.get("patients", [])
    ids = [p.get("patient_id") for p in patients]
    if not ids or len(ids) != len(set(ids)) or any(not isinstance(p, str) for p in ids):
        raise ValueError("Explicit unique patient metadata required")
    for p in patients:
        for key in ["cancer_type", "all_cells", "coordination_cells", "residual_degrees_of_freedom"]:
            if key not in p:
                raise ValueError(f"Missing patient denominator: {key}")
    for row in rows:
        rid = [x.get("patient_id") for x in row.get("patients", [])]
        if len(rid) != len(set(rid)) or set(rid) != set(ids):
            raise ValueError("Each program must retain every patient, with explicit missing values")
        for key in ["original_members", "assayed_members", "coordination_members"]:
            if key not in row or not isinstance(row[key], list):
                raise ValueError(f"Missing complete membership/coverage field: {key}")
    return {r["program"]: r for r in rows}, {p["patient_id"]: p for p in patients}


def measurement_matrix(rows, programs, patient_ids, field):
    matrix = np.full((len(programs), len(patient_ids)), np.nan)
    for i, name in enumerate(programs):
        records = {x["patient_id"]: x for x in rows[name]["patients"]}
        for j, patient in enumerate(patient_ids):
            value = records[patient].get(field)
            if value is None:
                continue
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not np.isfinite(value):
                raise ValueError(f"Invalid numeric measurement: {name}/{patient}/{field}")
            matrix[i, j] = value
    return matrix


def patient_labels(metadata, ids, *, coordination=False):
    labels = []
    for pid in ids:
        p = metadata[pid]
        count = p["coordination_cells"] if coordination else p["all_cells"]
        suffix = f"cells={count}"
        if coordination:
            suffix += f"\ndf={p['residual_degrees_of_freedom']}"
        labels.append(f"{pid}\n{p['cancer_type']}\n{suffix}")
    return labels


def draw_heatmap(ax, matrix, labels, programs, title, *, cmap, norm, show_programs):
    color_map = plt.get_cmap(cmap).copy()
    color_map.set_bad("#e3e6e8")
    artist = ax.imshow(np.ma.masked_invalid(matrix), aspect="auto", interpolation="none",
                       cmap=color_map, norm=norm)
    ax.set_title(title, loc="left", fontsize=11, fontweight="bold", pad=12)
    ax.set_xticks(range(len(labels)), labels, fontsize=7.4)
    ax.xaxis.tick_top()
    ax.tick_params(axis="x", length=0, pad=6)
    ax.set_yticks(range(len(programs)))
    ax.set_yticklabels([x.removeprefix("HALLMARK_") for x in programs] if show_programs else [], fontsize=7.1)
    ax.tick_params(axis="y", length=0)
    ax.set_yticks(np.arange(-.5, len(programs), 1), minor=True)
    ax.grid(which="minor", axis="y", color="white", linewidth=.35)
    ax.tick_params(which="minor", length=0)
    for i, j in np.argwhere(~np.isfinite(matrix)):
        ax.text(j, i, "NA", ha="center", va="center", fontsize=6.1, color="#626a70")
    for spine in ax.spines.values():
        spine.set_visible(False)
    return artist


def coverage_axis(ax, programs, primary, strict, *, coordination=False):
    ax.set_xlim(0, 1)
    ax.set_ylim(len(programs) - .5, -.5)
    ax.axis("off")
    ax.set_title("Measured members\nprimary | strict", loc="left", fontsize=8.4, pad=12)
    for i, name in enumerate(programs):
        texts = []
        for rows in [primary, strict]:
            row = rows[name]
            numerator = len(row["coordination_members"] if coordination else row["assayed_members"])
            denominator = len(row["assayed_members"] if coordination else row["original_members"])
            texts.append(f"{numerator}/{denominator}")
        ax.text(.03, i, " | ".join(texts), fontsize=6.9, va="center", color="#424b51")


def annotate(fig, title, subtitle, footer, synthetic):
    fig.suptitle(title, x=.02, y=.995, ha="left", fontsize=16, fontweight="bold")
    fig.text(.02, .973, subtitle, fontsize=9.2, color="#424b51")
    fig.text(.02, .075, footer, fontsize=8.3, va="top", linespacing=1.55)
    fig.text(.02, .018, FIXED_LIMIT, fontsize=8.2, color="#343b40")
    if synthetic:
        fig.text(.99, .995, "SYNTHETIC INPUT — LAYOUT CHECK", ha="right", va="top",
                 fontsize=10, color="#934a3e", fontweight="bold")


def save_pair(fig, directory, stem):
    output = []
    for ext in ["svg", "png"]:
        path = directory / f"{stem}.{ext}"
        metadata = {"Date": None} if ext == "svg" else {"Software": f"Matplotlib {matplotlib.__version__}"}
        fig.savefig(path, dpi=200, metadata=metadata, facecolor="white")
        output.append({"file": path.name, "sha256": digest(path), "bytes": path.stat().st_size})
    plt.close(fig)
    return output


def render_measurements(primary, sensitivity, output_directory, *, synthetic=False):
    primary_rows, primary_meta = validate_result(primary)
    strict_rows, strict_meta = validate_result(sensitivity)
    programs = sorted(primary_rows)
    if set(programs) != set(strict_rows) or set(primary_meta) != set(strict_meta):
        raise ValueError("Primary and strict sensitivity must retain the same complete program/patient identities")
    ids = list(primary_meta)
    # Freeze-related facts are displayed directly, not inferred from favorable effects.
    melanoma = [p for p in ids if "mel" in primary_meta[p]["cancer_type"].lower()
                or primary_meta[p]["cancer_type"].upper() == "SKCM"]
    if len(melanoma) != 1:
        raise ValueError("This figure specification requires the single melanoma case to be explicit")
    mel = melanoma[0]
    if (primary_meta[mel]["all_cells"], strict_meta[mel]["all_cells"],
            strict_meta[mel]["residual_degrees_of_freedom"]) != (6, 5, 1):
        raise ValueError("Fixed caption/metadata disagreement; amend the figure specification explicitly")
    directory = Path(output_directory)
    directory.mkdir(parents=True, exist_ok=False)
    plt.rcParams.update({"font.family": "DejaVu Sans", "svg.fonttype": "none", "axes.unicode_minus": True})
    artifacts = []
    activity = [measurement_matrix(r, programs, ids, "activity") for r in [primary_rows, strict_rows]]
    if any(np.any(np.abs(a[np.isfinite(a)]) > .5 + 1e-10) for a in activity):
        raise ValueError("Relative-expression score outside the specified rank range")
    fig = plt.figure(figsize=(15, 14.7))
    grid = fig.add_gridspec(1, 4, width_ratios=[len(ids), len(ids), 1.45, .16],
                            left=.29, right=.92, top=.875, bottom=.13, wspace=.22)
    norm = Normalize(-.5, .5)
    for k, (values, meta, title) in enumerate(zip(activity, [primary_meta, strict_meta],
                                                  ["Primary cell definition", "Strict cell-definition sensitivity"])):
        ax = fig.add_subplot(grid[0, k])
        artist = draw_heatmap(ax, values, patient_labels(meta, ids), programs, title,
                              cmap="RdBu_r", norm=norm, show_programs=k == 0)
    coverage_axis(fig.add_subplot(grid[0, 2]), programs, primary_rows, strict_rows)
    colorbar = fig.colorbar(artist, cax=fig.add_subplot(grid[0, 3]))
    colorbar.set_label("Mean normalized gene rank", fontsize=9)
    colorbar.ax.tick_params(labelsize=8)
    annotate(fig, "Predefined RNA-program measurements",
             "All 50 programs retained. Continuous case-level relative expression; no active/inactive threshold.",
             "Color summarizes the equal-cell mean full-library CPM profile ranked over the fixed assayed universe.\n"
             "Coverage = assayed/original members. Gray NA = unmeasurable under the frozen criteria; zero is a midrank reference.\n"
             "Different cancer/platform contexts remain separate; these are not resistance-specific or population-prevalence estimates.", synthetic)
    artifacts += save_pair(fig, directory, "01_rna_program_activity")

    matrices = [measurement_matrix(r, programs, ids, field)
                for field in ["coordination", "null_excess"] for r in [primary_rows, strict_rows]]
    norms = []
    for group in [matrices[:2], matrices[2:]]:
        values = np.concatenate([a[np.isfinite(a)] for a in group])
        bound = max(.05, float(np.max(np.abs(values))) * 1.05) if len(values) else .05
        norms.append(Normalize(-bound, bound))
    for group_index, (title, label, stem) in enumerate([
            ("RNA coordination: conditional technical diagnostics", "Mean partial rank correlation T", "02_rna_coordination_T"),
            ("RNA coordination: excess over the matched-gene background", "T minus matched-null mean", "03_rna_coordination_excess")]):
        group = matrices[group_index * 2:group_index * 2 + 2]
        fig = plt.figure(figsize=(15, 14.7))
        grid = fig.add_gridspec(1, 4, width_ratios=[len(ids), len(ids), 1.45, .16],
                                left=.29, right=.92, top=.865, bottom=.13, wspace=.22)
        for k, (values, meta, panel_title) in enumerate(zip(group, [primary_meta, strict_meta],
                                                          ["Primary cell definition", "Strict cell-definition sensitivity"])):
            ax = fig.add_subplot(grid[0, k])
            artist = draw_heatmap(ax, values, patient_labels(meta, ids, coordination=True), programs, panel_title,
                                  cmap="PuOr", norm=norms[group_index], show_programs=k == 0)
        coverage_axis(fig.add_subplot(grid[0, 2]), programs, primary_rows, strict_rows, coordination=True)
        bar_axis = fig.add_subplot(grid[0, 3])
        if any(np.isfinite(a).any() for a in group):
            bar = fig.colorbar(artist, cax=bar_axis)
            bar.set_label(label, fontsize=8.4)
            bar.ax.tick_params(labelsize=8)
        else:
            bar_axis.axis("off")
            bar_axis.text(.5, .5, "No assessable values", rotation=90, ha="center", va="center", fontsize=8)
        annotate(fig, title,
                 "All 50 programs and all cases shown. These panels do not select or validate Molecular Survival Islands.",
                 "T = mean off-diagonal correlation of technically residualized across-cell gene ranks. Excess uses the frozen matched-gene null.\n"
                 "Coverage = common variable/assayed members. NA includes insufficient residual df or representation; it is not zero coordination.\n"
                 "Strict sensitivity can make the shared endpoint unassessable for all cases. Conditional diagnostics are not population P values.", synthetic)
        artifacts += save_pair(fig, directory, stem)
    manifest = {"synthetic_illustration": synthetic, "program_count": len(programs),
                "program_order": programs, "patient_order": ids,
                "caption_limit": FIXED_LIMIT, "figures": artifacts,
                "activity_color_range": [-.5, .5],
                "coordination_color_ranges": [[n.vmin, n.vmax] for n in norms],
                "software": {"python": platform.python_version(), "numpy": np.__version__,
                             "matplotlib": matplotlib.__version__},
                "generator_sha256": digest(__file__),
                "claims": "Descriptive complete-family measurements; no activation, conservation, resistance specificity or MSI-selection claim"}
    return directory, manifest


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--sensitivity", type=Path, required=True)
    parser.add_argument("--output-directory", type=Path, required=True)
    parser.add_argument("--synthetic-illustration", action="store_true")
    args = parser.parse_args(argv)
    primary = json.loads(args.results.read_text())
    strict = json.loads(args.sensitivity.read_text())
    directory, manifest = render_measurements(primary, strict, args.output_directory,
                                               synthetic=args.synthetic_illustration)
    manifest["inputs"] = [{"role": role, "file": path.name, "sha256": digest(path)}
                           for role, path in [("primary", args.results), ("strict_sensitivity", args.sensitivity)]]
    (directory / "figure_manifest.json").write_text(json.dumps(manifest, indent=2, allow_nan=False) + "\n")
    print(f"Wrote complete-family descriptive figures to {directory}")


if __name__ == "__main__":
    main()
