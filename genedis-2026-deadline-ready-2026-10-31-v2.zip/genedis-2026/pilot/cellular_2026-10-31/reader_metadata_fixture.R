# Synthetic only: no study data. Run create and verify in separate R sessions.
args <- commandArgs(trailingOnly=TRUE)
if (length(args) < 2L) stop("Expected create/verify and fixture directory")
dir.create(args[[2]], recursive=TRUE, showWarnings=FALSE)
input <- file.path(args[[2]], "synthetic_seurat_closure.rds")
if (args[[1]] == "create") {
  setClass("FixtureSeurat", slots=c(meta.data="data.frame", commands="list", assays="list"))
  md <- data.frame(patient=c("A","A","B"), sample=factor(c("sample_a","sample_b","sample_c")),
                   status=ordered(c("pre","post",NA),levels=c("pre","post")),
                   row.names=c("cell1","cell2","cell3"))
  x <- new("FixtureSeurat",meta.data=md,
           commands=list(function(){stop("NEVER_EXECUTE")}),
           assays=list(forbidden=matrix(1:6,2,3)))
  saveRDS(x,input)
  cat("SYNTHETIC_CLOSURE_FIXTURE_CREATED\n")
} else if (args[[1]] == "verify") {
  original <- attr(readRDS(input),"meta.data",exact=TRUE)
  extracted <- readRDS(file.path(args[[2]],"base_metadata_fixture.rds"))
  stopifnot(identical(original,extracted),is.ordered(extracted$status),is.na(extracted$status[3]))
  cat("EXACT_METADATA_FACTOR_NA_FIXTURE_PASS\n")
} else stop("Unknown mode")
