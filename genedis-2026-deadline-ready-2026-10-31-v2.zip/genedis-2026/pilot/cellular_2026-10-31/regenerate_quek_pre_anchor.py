#!/usr/bin/env python3
"""Reconstruct the source-concordant MIA1 PRE identity anchor; no RNA effects.

The output is a cell-identifier file in ignored local data. Original RNA row
order is retained so the historical /tmp anchor is reproducible byte for byte.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
LOCAL = ROOT / 'data/external/cellular_2026_10_31'
EXPECTED_COUNT = 398
EXPECTED_SHA256 = '61b94721d2d408fdf584694afbb1dc4448853a0a9f17787d8981faa73f76abe3'


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read_metadata(path):
    with path.open(newline='') as stream:
        reader = csv.DictReader(stream)
        required = {'', 'orig.ident', 'mia_ID', 'timepoint', 'RECIST'}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError(f'Missing required metadata columns: {path}')
        rows = list(reader)
    seen = set()
    for row in rows:
        cell = row['']
        if not cell or cell in seen or not cell.startswith(row['orig.ident'] + '_'):
            raise ValueError(f'Duplicate, empty or library-inconsistent cell ID: {path}')
        seen.add(cell)
    return rows


def regenerate(metadata_dir, manifest_path):
    manifest = json.loads(manifest_path.read_text())
    records = {r['filename']: r for r in manifest['public_file_manifest']['files']}
    filenames = ['Melanoma_RNA_metadata.csv', 'Melanoma_ADT_metadata.csv']
    filenames += [f'Melanoma_sample-barcode_{i:02d}.tsv' for i in range(1, 5)]
    sources = []
    for name in filenames:
        path, expected = metadata_dir / name, records[name]
        if path.stat().st_size != expected['bytes'] or digest(path) != expected['source_sha256']:
            raise ValueError(f'Public-source bytes/SHA256 mismatch: {path}')
        sources.append({'filename': name, 'path': str(path), 'bytes': path.stat().st_size,
                        'sha256': digest(path), 'url': expected['public_download_url']})
    rna = read_metadata(metadata_dir / filenames[0])
    adt = {r['']: r for r in read_metadata(metadata_dir / filenames[1])}
    demux = {}
    for i in range(1, 5):
        library = f'MELCAP{i:02d}'
        path = metadata_dir / f'Melanoma_sample-barcode_{i:02d}.tsv'
        with path.open(newline='') as stream:
            reader = csv.DictReader(stream, delimiter='\t')
            if reader.fieldnames != ['barcode', 'assignment']:
                raise ValueError(f'Unexpected demultiplexing schema: {path}')
            for row in reader:
                barcode = row['barcode']
                if not barcode.endswith('-1') or not barcode[:-2]:
                    raise ValueError(f'Unexpected source barcode suffix: {path}')
                cell = library + '_' + barcode[:-2]
                if cell in demux:
                    raise ValueError(f'Duplicate full library-qualified barcode: {cell}')
                demux[cell] = row['assignment']
    rules = {'PRE': ('MELCAP01', 'MIA1a', 'Pre', 'PR', 'MIA1Pre'),
             'POST': ('MELCAP02', 'MIA1b', 'Post', 'PR', 'MIA1Post')}
    groups = {stage: [] for stage in rules}
    for row in rna:
        other = adt.get(row[''])
        if other is None:
            continue
        for stage, (library, donor, timing, response, assignment) in rules.items():
            expected = (library, donor, timing, response)
            fields = ('orig.ident', 'mia_ID', 'timepoint', 'RECIST')
            if (tuple(row[f] for f in fields) == expected
                    and tuple(other[f] for f in fields) == expected
                    and demux.get(row['']) == assignment):
                groups[stage].append(row[''])
    payload = ('\n'.join(groups['PRE']) + '\n').encode()
    if len(groups['PRE']) != EXPECTED_COUNT or hashlib.sha256(payload).hexdigest() != EXPECTED_SHA256:
        raise ValueError('Historical source-concordant PRE reconstruction changed; investigate rather than overwrite')
    if groups['POST']:
        raise ValueError('Historical zero triple-concordant POST changed; investigate source provenance')
    return payload, {'purpose': 'Source-concordant pretreatment identity anchor only; no molecular program analysis',
                     'source_receipt': {'path': str(manifest_path), 'sha256': digest(manifest_path)},
                     'sources': sources, 'join': 'Exact full library-qualified cell IDs; retain RNA source row order',
                     'clinical_fields_matched_in_both_metadata_tables': list(fields),
                     'source_rules': {k: list(v) for k, v in rules.items()},
                     'PRE_cells': len(groups['PRE']), 'POST_cells': len(groups['POST']),
                     'interpretation': 'Concordance is not independent proof that all reduced metadata labels are correct',
                     'program_effects_computed': False}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--metadata-dir', type=Path, default=LOCAL / 'quek_metadata')
    p.add_argument('--source-receipt', type=Path, default=HERE / 'QUEK_METADATA_RECEIPTS.json')
    p.add_argument('--output', type=Path, default=LOCAL / 'quek_triple_concordant_MIA1_PRE.txt')
    p.add_argument('--report', type=Path, default=HERE / 'QUEK_PRE_ANCHOR_REGENERATION.json')
    a = p.parse_args()
    if a.output.exists() or a.report.exists():
        p.error('Preserve prior outputs; supply fresh paths')
    if not a.output.resolve().is_relative_to(LOCAL.resolve()):
        p.error('Cell identifiers must remain inside ignored local data')
    payload, report = regenerate(a.metadata_dir, a.source_receipt)
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_bytes(payload)
    report.update(script_sha256=digest(Path(__file__)), output={
        'path': str(a.output), 'bytes': len(payload), 'sha256': digest(a.output)})
    a.report.parent.mkdir(parents=True, exist_ok=True)
    with a.report.open('x') as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'PRE_cells': report['PRE_cells'], 'POST_cells': report['POST_cells'],
                      'output': report['output'], 'report': str(a.report)}, indent=2))


if __name__ == '__main__':
    main()
