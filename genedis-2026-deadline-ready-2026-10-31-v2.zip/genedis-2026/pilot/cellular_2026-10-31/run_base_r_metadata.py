"""Bound an isolated base-R metadata extraction; never invoke assay methods."""
import argparse
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--runtime-root", required=True, type=Path)
p.add_argument("--input", required=True, type=Path)
p.add_argument("--output-prefix", required=True, type=Path)
p.add_argument("--receipt", required=True, type=Path)
p.add_argument("--memory-gib", type=int, default=12)
p.add_argument("--timeout-seconds", type=int, default=180)
a = p.parse_args()
if a.memory_gib < 1 or a.timeout_seconds < 1:
    p.error("Memory and time limits must be positive")
home = a.runtime_root.resolve() / "usr/lib/R"
env = dict(os.environ, R_HOME=str(home), LD_LIBRARY_PATH=str(home / "lib"),
           R_SHARE_DIR=str(a.runtime_root.resolve() / "usr/share/R/share"),
           OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")
prefix = a.output_prefix.resolve()
prefix.parent.mkdir(parents=True, exist_ok=True)
outputs = [str(prefix) + suffix for suffix in [".csv", ".rds", "_schema.tsv"]]
if any(Path(v).exists() for v in [*outputs, a.receipt]):
    p.error("Use fresh output and receipt paths; existing evidence is never overwritten")
a.receipt.parent.mkdir(parents=True, exist_ok=True)
script = Path(__file__).with_name("extract_seurat_metadata_base.R").resolve()
cmd = [str(home / "bin/exec/R"), "--vanilla", "--slave", "-f", str(script),
       "--args", str(a.input.resolve()), *outputs]

def limits():
    cap = a.memory_gib * 1024**3
    resource.setrlimit(resource.RLIMIT_AS, (cap, cap))
    signal.alarm(a.timeout_seconds)

started = time.perf_counter()
q = {"audit": "Isolated base-R logical metadata extraction", "input_file": a.input.name,
     "verdict": "TECHNICAL_ATTEMPT_STARTED", "memory_cap_GiB": a.memory_gib,
     "alarm_seconds": a.timeout_seconds, "RNA_assay_access": False}
a.receipt.write_text(json.dumps(q, indent=2) + "\n")
try:
    result = subprocess.run(cmd, env=env, preexec_fn=limits, capture_output=True,
                            text=True, timeout=a.timeout_seconds + 5)
    succeeded = result.returncode == 0 and all(Path(v).is_file() for v in outputs)
    q.update(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr,
             verdict="METADATA_EXTRACTION_PASS" if succeeded else "TECHNICAL_EXTRACTION_FAILED",
             output_files=[v for v in outputs if Path(v).exists()])
except subprocess.TimeoutExpired:
    q.update(verdict="TECHNICAL_TIMEOUT")
finally:
    q["elapsed_seconds"] = round(time.perf_counter() - started, 3)
    q["peak_child_rss_KiB"] = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    a.receipt.write_text(json.dumps(q, indent=2) + "\n")
print(json.dumps(q))
raise SystemExit(0 if q["verdict"] == "METADATA_EXTRACTION_PASS" else 1)
