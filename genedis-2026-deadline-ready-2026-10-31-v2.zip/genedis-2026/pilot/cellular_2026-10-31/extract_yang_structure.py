"""Read only Seurat metadata/structure; never convert an RNA assay.

Run with the separately pinned rds2py fixture environment. Native RDS parsing is
eager; an address-space limit and alarm bound this technical attempt.
"""

import argparse
import collections
import csv
import hashlib
import importlib.metadata
import json
import resource
import signal
import time
from pathlib import Path


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--rds", required=True, type=Path)
    ap.add_argument("--metadata-csv", required=True, type=Path)
    ap.add_argument("--receipt", required=True, type=Path)
    ap.add_argument("--memory-gib", type=int, default=12)
    ap.add_argument("--timeout-seconds", type=int, default=180)
    args = ap.parse_args()
    started = time.perf_counter()
    cap = args.memory_gib * 1024**3
    resource.setrlimit(resource.RLIMIT_AS, (cap, cap))
    signal.alarm(args.timeout_seconds)
    receipt = {
        "audit": "Yang processed Seurat structural/metadata QC only",
        "date": "2026-10-31",
        "verdict": "TECHNICAL_ATTEMPT_STARTED",
        "source_file": args.rds.name,
        "source_bytes": args.rds.stat().st_size,
        "limits": {"address_space_GiB": args.memory_gib, "alarm_seconds": args.timeout_seconds},
        "RNA_assays_converted": False,
        "molecular_scores_or_effects_computed": False,
    }
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    args.receipt.write_text(json.dumps(receipt, indent=2) + "\n")
    try:
        from rds2py.PyRdsReader import PyRdsParser
        from rds2py.generics import _dispatcher

        receipt["reader_versions"] = {
            k: importlib.metadata.version(k) for k in ["rds2py", "biocframe", "numpy"]
        }
        print("Starting bounded native parse; no assay conversion", flush=True)
        parser = PyRdsParser(str(args.rds))
        root = parser.root_object
        receipt["root_type"] = root.get_rtype()
        receipt["root_class"] = root.get_class_name()
        receipt["root_attributes"] = root.get_attribute_names()
        if "meta.data" not in receipt["root_attributes"]:
            raise RuntimeError("Seurat meta.data slot not found")
        frame = _dispatcher(parser._process_object(root.load_attribute_by_name("meta.data")))
        if hasattr(frame, "column_names"):
            columns = [str(v) for v in frame.column_names]
            row_ids = [str(v) for v in frame.row_names]
        else:
            columns = [str(v) for v in frame.columns]
            row_ids = [str(v) for v in frame.index]
        n = len(row_ids)
        data = {c: list(frame[c]) for c in columns}
        if not all(len(v) == n for v in data.values()):
            raise RuntimeError("Metadata column lengths differ from row IDs")

        def scalar(value):
            if value is None:
                return None
            return value.item() if hasattr(value, "item") else value

        args.metadata_csv.parent.mkdir(parents=True, exist_ok=True)
        with args.metadata_csv.open("w", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(["source_cell_id"] + columns)
            for i, cell_id in enumerate(row_ids):
                writer.writerow([cell_id] + [scalar(data[c][i]) for c in columns])
        metadata_keys = [
            c for c in columns
            if any(term in c.lower() for term in [
                "patient", "sample", "celltype", "cell_type", "cell.type", "status",
                "response", "treatment", "therapy", "biopsy", "timepoint", "orig.ident",
            ])
        ]
        categorical_counts = {}
        for c in metadata_keys:
            counts = collections.Counter(str(scalar(v)) for v in data[c])
            if len(counts) <= 100:
                categorical_counts[c] = dict(counts)
        requested = {"509_1", "509_2", "620_2"}
        target_counts = {}
        for c in columns:
            counts = collections.Counter(str(scalar(v)) for v in data[c])
            found = {target: counts[target] for target in sorted(requested) if counts[target]}
            if found:
                target_counts[c] = found
        receipt.update({
            "verdict": "METADATA_STRUCTURE_PASS_CLINICAL_GATE_REMAINS_CONDITIONAL",
            "metadata_python_class": type(frame).__name__,
            "metadata_cells": n,
            "unique_cell_ids": len(set(row_ids)),
            "duplicate_cell_ids": n - len(set(row_ids)),
            "metadata_columns": columns,
            "metadata_column_types": {c: type(frame[c]).__name__ for c in columns},
            "categorical_metadata_counts": categorical_counts,
            "requested_specimen_label_counts": target_counts,
            "metadata_export": {
                "file": str(args.metadata_csv),
                "bytes": args.metadata_csv.stat().st_size,
                "sha256": hashlib.sha256(args.metadata_csv.read_bytes()).hexdigest(),
                "missing_value_encoding": "Empty CSV field for None; source values otherwise preserved",
            },
            "reader_versions": {k: importlib.metadata.version(k) for k in ["rds2py", "biocframe", "numpy"]},
            "limits_of_claim": [
                "Metadata-only logical extraction still requires eager native file parsing",
                "No RNA assay was converted or summarized",
                "Source cell labels are annotations, not new malignancy inference",
                "Clinical eligibility is not established by specimen names alone",
                "Actual factor-level/NA fidelity requires review of metadata representation",
            ],
        })
    except Exception as exc:
        receipt.update({"verdict": "TECHNICAL_EXTRACTION_FAILED", "error_class": type(exc).__name__, "error": str(exc)})
        raise
    finally:
        receipt["elapsed_seconds"] = round(time.perf_counter() - started, 3)
        receipt["peak_rss_KiB"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        args.receipt.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({k: receipt.get(k) for k in ["verdict", "metadata_cells", "metadata_columns", "requested_specimen_label_counts", "elapsed_seconds", "peak_rss_KiB"]}), flush=True)


if __name__ == "__main__":
    main()
