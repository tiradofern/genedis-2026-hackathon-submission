#!/usr/bin/env python3
"""Validate and sparsely ingest frozen primary RNA inputs; never score programs.

Matrices are source genes by cells CSV (optionally gzip), written as CSR cells by
all source genes after the common technical QC. Source cell and gene strings are
preserved. Metadata labels, not expression values, define eligible specimens.
"""
from __future__ import annotations
import argparse
import csv
import gzip
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
from scipy import sparse

BASE = Path('data/external/cellular_2026_10_31')
OUT = Path('data/processed/cellular_2026_10_31')
LIMITS = {'minimum_UMI': 500, 'minimum_detected_genes': 200, 'maximum_MT_percent': 20}


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def read_table(path, delimiter=','):
    with Path(path).open(newline='') as handle:
        return list(csv.DictReader(handle, delimiter=delimiter))


def truth(value):
    if str(value).strip().lower() in {'true', '1', 'yes'}:
        return True
    if str(value).strip().lower() in {'false', '0', 'no', ''}:
        return False
    raise ValueError(f'Invalid explicit Boolean: {value!r}')


def unique(values, what):
    if len(values) != len(set(values)):
        raise ValueError(f'Duplicate {what}; no silent collapse is permitted')


def mcc_selection(base, accession):
    if accession == 'GSE117988':
        filename, patient = 'MCC_GSE117988_aPD1aCTLA4_CellMetainfo_table.tsv', '2586-4'
    else:
        filename, patient = 'MCC_GSE118056_aPDL1_CellMetainfo_table.tsv', '9245-3'
    metadata = base / filename
    rows = read_table(metadata, '\t')
    unique([row['Cell'] for row in rows], 'annotation cell IDs')
    selected = []
    for row in rows:
        raw_id = row['Cell'].removeprefix('Tumor@')
        if (row['Source'] == 'Tumor' and
                row['Celltype (malignancy)'] == 'Malignant cells' and raw_id.endswith('-2')):
            selected.append({'cell_id': raw_id, 'annotation_cell_id': row['Cell'],
                'patient_id': f'{accession}:{patient}', 'cancer': 'MCC',
                'specimen_stage': 'acquired_resistance',
                'source_timepoint': row.get('TimePoint', ''),
                'source_sample': row.get('Sample', ''),
                'corrected_timepoint': 'day615' if accession == 'GSE117988' else 'acquired_resistance',
                'timing_note': 'Source-derived correction: raw EarlyD27 retained; index tumor is day615.'
                    if accession == 'GSE117988' else 'Post-treatment -2 tumor specimen; clinical eligibility adjudicated separately.',
                'source_malignancy': row['Celltype (malignancy)'],
                'source_treatment': row.get('Treatment', '')})
    if not selected:
        raise ValueError(f'No frozen eligible malignant post-treatment cells in {metadata}')
    unique([row['cell_id'] for row in selected], 'normalized selected annotation cell IDs')
    return metadata, selected, f'{accession}_{patient}_post'


def quek_selection(base, mask_path):
    if mask_path is None:
        raise ValueError('--quek-cell-mask is required; no invented cell mask')
    rows = read_table(mask_path)
    mask_field = next((key for key in ('primary_lineage', 'quek_primary_putative_malignant') if rows and key in rows[0]), None)
    if mask_field is None:
        raise ValueError('Quek mask requires an explicit primary_lineage or quek_primary_putative_malignant column')
    id_col = next((key for key in ('cell_id', 'source_cell_id', 'Cell', '') if key in rows[0]), None)
    if id_col is None:
        raise ValueError('Quek mask has no supported source cell identifier field')
    unique([row[id_col] for row in rows], 'Quek mask cell IDs')
    meta_path = base / 'quek_metadata/Melanoma_RNA_metadata.csv'
    source = read_table(meta_path)
    unique([row[''] for row in source], 'Quek source RNA metadata cell IDs')
    lookup = {row['']: row for row in source}
    selected = []
    for row in rows:
        cell_id = row[id_col]
        if cell_id not in lookup:
            raise ValueError(f'Quek mask ID absent from source RNA metadata: {cell_id}')
        meta = lookup[cell_id]
        mask_value = str(row[mask_field]).strip()
        # Unassessable lineage identities are preserved in the source mask and excluded.
        is_primary = False if mask_value.upper() in {'NA', 'NAN', 'UNASSESSABLE'} else truth(mask_value)
        if (is_primary and meta['mia_ID'] == 'MIA1b' and
                meta['timepoint'] == 'Post' and meta['orig.ident'] == 'MELCAP02'):
            selected.append({'cell_id': cell_id, 'annotation_cell_id': cell_id,
                'patient_id': 'Quek2024:MIA1', 'cancer': 'melanoma',
                'specimen_stage': 'acquired_resistance', 'source_timepoint': 'Post',
                'source_sample': meta['mia_ID'], 'corrected_timepoint': 'Post',
                'timing_note': 'Unmodified source RNA mapping; conflicting ADT/TSV labels preserved separately.',
                'source_malignancy': 'independent lineage-positive putative malignant',
                'source_treatment': 'ipi+nivo'})
    if not selected:
        raise ValueError('No primary lineage-positive source-RNA MIA1b/Post cells; do not relax mask')
    return meta_path, selected, 'Quek2024_MIA1_post'


def ingest(matrix_path, selected_rows, output_dir, stem, metadata_path, mask_path=None):
    """Read/validate EVERY source value; retain nonzeros only in selected columns."""
    matrix_path, output_dir = Path(matrix_path), Path(output_dir)
    if not matrix_path.is_file():
        raise FileNotFoundError(matrix_path)
    selected_by_id = {row['cell_id']: row for row in selected_rows}
    unique([row['cell_id'] for row in selected_rows], 'selected cell IDs')
    genes, seen_genes = [], set()
    rr, cc, dd = [], [], []
    opener = gzip.open if matrix_path.suffix == '.gz' else open
    with opener(matrix_path, 'rt', newline='') as handle:
        first = next(csv.reader([handle.readline()]))
        cells = first[1:]
        if not cells or any(not item for item in cells):
            raise ValueError('Missing/empty source cell IDs')
        unique(cells, 'source matrix cell IDs')
        positions = {name: k for k, name in enumerate(cells)}
        missing = set(selected_by_id) - set(positions)
        if missing:
            raise ValueError(f'{len(missing)} selected metadata IDs missing from matrix: {sorted(missing)[:3]}')
        # Preserve matrix column order exactly; all later files follow this order.
        kept_source_index = np.array([k for k, cell in enumerate(cells) if cell in selected_by_id], dtype=np.int64)
        selected_ids = [cells[k] for k in kept_source_index]
        n_selected = len(selected_ids)
        total = np.zeros(n_selected, dtype=np.uint64)
        detected = np.zeros(n_selected, dtype=np.uint32)
        mt_total = np.zeros(n_selected, dtype=np.uint64)
        for line_no, line in enumerate(handle, 2):
            if not line.strip():
                raise ValueError(f'Blank source matrix row at {line_no}')
            token, numeric = line.rstrip('\r\n').split(',', 1)
            # A comma inside a quoted gene or quoted numeric values requires CSV.
            if token.count('"') % 2 or '"' in numeric:
                fields = next(csv.reader([line]))
                gene = fields[0]
                values = np.asarray(fields[1:], dtype=np.float64)
            else:
                gene = next(csv.reader([token]))[0]
                parsed = np.fromstring(numeric + ',nan', sep=',', dtype=np.float64)
                if parsed.size != len(cells) + 1 or not np.isnan(parsed[-1]):
                    raise ValueError(f'Malformed numeric CSV at row {line_no}')
                values = parsed[:-1]
            if not gene or gene in seen_genes:
                raise ValueError(f'Empty/duplicate source gene at row {line_no}: {gene!r}')
            seen_genes.add(gene)
            if values.size != len(cells):
                raise ValueError(f'Wrong numeric width at row {line_no}: {values.size} != {len(cells)}')
            if (not np.isfinite(values).all() or (values < 0).any() or
                    (values != np.floor(values)).any() or (values > np.iinfo(np.uint32).max).any()):
                raise ValueError(f'Non-finite, negative, fractional or overflowing count at row {line_no}')
            gene_index = len(genes)
            genes.append(gene)
            chosen = values[kept_source_index].astype(np.uint32)
            nonzero = np.flatnonzero(chosen)
            if nonzero.size:
                rr.append(nonzero.astype(np.int32))
                cc.append(np.full(nonzero.size, gene_index, dtype=np.int32))
                dd.append(chosen[nonzero])
            total += chosen
            detected += chosen > 0
            if gene.upper().startswith('MT-'):
                mt_total += chosen
            if len(genes) % 5000 == 0:
                print(f'{stem}: validated {len(genes)} genes, {n_selected} eligible columns', flush=True)
    if not genes:
        raise ValueError('No source genes')
    mt_percent = np.divide(mt_total * 100., total, out=np.zeros(n_selected, dtype=float), where=total > 0)
    quality = (total >= LIMITS['minimum_UMI']) & (detected >= LIMITS['minimum_detected_genes']) & (mt_percent <= LIMITS['maximum_MT_percent'])
    if not quality.any():
        raise ValueError('No cells pass common technical QC; preserve failure and do not lower thresholds')
    arrays = [np.concatenate(items) if items else np.empty(0, dtype=dtype)
              for items, dtype in ((dd, np.uint32), (rr, np.int32), (cc, np.int32))]
    matrix = sparse.coo_matrix((arrays[0], (arrays[1], arrays[2])), shape=(n_selected, len(genes)), dtype=np.uint32).tocsr()
    if not np.array_equal(np.asarray(matrix.sum(axis=1)).ravel(), total):
        raise ValueError('Sparse matrix count sums differ from source values')
    final = matrix[quality].tocsr()
    output_dir.mkdir(parents=True, exist_ok=True)
    matrix_out = output_dir / f'{stem}_counts.npz'
    genes_out = output_dir / f'{stem}_genes.json'
    cells_out = output_dir / f'{stem}_cells.csv'
    all_qc_out = output_dir / f'{stem}_eligible_cell_qc.csv'
    sparse.save_npz(matrix_out, final)
    genes_out.write_text(json.dumps(genes) + '\n')
    qc_rows = []
    for k, cell_id in enumerate(selected_ids):
        qc_rows.append({**selected_by_id[cell_id], 'source_matrix_column': int(kept_source_index[k]),
            'UMI': int(total[k]), 'detected_genes': int(detected[k]),
            'MT_UMI': int(mt_total[k]), 'MT_percent': float(mt_percent[k]),
            'technical_QC_pass': bool(quality[k])})
    for path, output_rows in ((all_qc_out, qc_rows), (cells_out, [r for r in qc_rows if r['technical_QC_pass']])):
        with path.open('w', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(qc_rows[0]))
            writer.writeheader(); writer.writerows(output_rows)
    inputs = [matrix_path, Path(metadata_path)] + ([Path(mask_path)] if mask_path else [])
    receipt = {'status': 'STRUCTURAL_INGEST_ONLY_NO_PROGRAM_SCORES',
        'created_UTC': datetime.now(timezone.utc).isoformat(), 'cohort': stem,
        'patients': sorted({row['patient_id'] for row in selected_rows}),
        'source_shape_genes_by_cells': [len(genes), len(cells)],
        'eligible_annotated_cells': n_selected, 'technical_QC_pass_cells': int(quality.sum()),
        'technical_QC_excluded_cells': int((~quality).sum()), 'limits': LIMITS,
        'output_shape_cells_by_genes': list(final.shape), 'output_nnz': int(final.nnz),
        'source_genes_or_cells_silently_collapsed': False, 'all_source_values_validated': True,
        'primary_matrix_contains_only_QC_passing_cells': True,
        'inputs': [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha256(p)} for p in inputs],
        'outputs': [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha256(p)}
                    for p in (matrix_out, genes_out, cells_out, all_qc_out)],
        'numpy_version': np.__version__, 'scipy_version': __import__('scipy').__version__,
        'preparation_script_sha256': sha256(Path(__file__))}
    receipt_out = output_dir / f'{stem}.receipt.json'
    receipt_out.write_text(json.dumps(receipt, indent=2) + '\n')
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, default=BASE)
    parser.add_argument('--output-dir', type=Path, default=OUT)
    parser.add_argument('--cohort', nargs='+', choices=['mcc117988', 'mcc118056', 'quek', 'all'], default=['all'])
    parser.add_argument('--quek-cell-mask', type=Path)
    args = parser.parse_args()
    cohorts = ['mcc117988', 'mcc118056', 'quek'] if 'all' in args.cohort else args.cohort
    receipts = []
    for cohort in cohorts:
        if cohort.startswith('mcc'):
            accession = 'GSE' + cohort[3:]
            metadata, selected, stem = mcc_selection(args.base, accession)
            source_name = f'{accession}_raw.expMatrix_Tumor.csv.gz' if accession == 'GSE117988' else f'{accession}_raw.expMatrix.csv.gz'
            source = args.base / source_name
            receipt = ingest(source, selected, args.output_dir, stem, metadata)
        else:
            metadata, selected, stem = quek_selection(args.base, args.quek_cell_mask)
            receipt = ingest(args.base / 'quek_RNA_count.csv', selected, args.output_dir, stem, metadata, args.quek_cell_mask)
        receipts.append(receipt)
        print(json.dumps({'cohort': stem, 'cells': receipt['technical_QC_pass_cells'], 'genes': receipt['source_shape_genes_by_cells'][0]}), flush=True)
    all_receipts = [json.loads(path.read_text()) for path in sorted(args.output_dir.glob('*.receipt.json'))]
    manifest = {'status': 'STRUCTURAL_INPUTS_NO_PROGRAM_SCORES', 'cohorts': all_receipts,
                'independent_patients': sorted({p for item in all_receipts for p in item['patients']})}
    (args.output_dir / 'primary_rna_input_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')


if __name__ == '__main__':
    main()
