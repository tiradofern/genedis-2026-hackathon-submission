"""Conditional RNA program statistics; no source I/O or clinical gate decisions.

All numerical choices are proposed until the investigator's protocol is frozen.
Gene-matched P values condition on the supplied specimens, cells and strata;
they are not population-recurrence, resistance-enrichment or causal P values.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import time
from typing import Mapping, Sequence

import numpy as np
from scipy import sparse
from scipy.stats import rankdata


@dataclass
class RNACase:
    patient_id: str
    cancer_type: str
    counts: object
    gene_ids: Sequence[str]
    cell_ids: Sequence[str]
    mitochondrial_fraction: object | None = None


def _ids(values, name):
    if isinstance(values, (str, bytes)):
        raise ValueError(f"{name} must be an explicit sequence")
    values = tuple(values)
    if any(not isinstance(x, str) or not x or x != x.strip() for x in values):
        raise ValueError(f"Invalid {name}")
    if len(set(values)) != len(values):
        raise ValueError(f"Duplicate {name}")
    return values


def _case(case):
    if isinstance(case, Mapping):
        case = RNACase(**case)
    if not isinstance(case, RNACase):
        raise ValueError("Each dataset must be an RNACase or its field mapping")
    _ids([case.patient_id], "patient identifier")
    _ids([case.cancer_type], "cancer type")
    genes, cells = _ids(case.gene_ids, "gene identifiers"), _ids(case.cell_ids, "cell identifiers")
    if sparse.issparse(case.counts):
        stored = np.asarray(case.counts.tocoo(copy=False).data, dtype=float)
        if np.any(~np.isfinite(stored)) or np.any(stored < 0):
            raise ValueError("Stored sparse count entries must be finite and nonnegative")
        counts = sparse.csr_matrix(case.counts, dtype=float, copy=True)
        if np.any(~np.isfinite(counts.data)) or np.any(counts.data < 0):
            raise ValueError("Stored sparse count entries must be finite and nonnegative")
        counts.sum_duplicates()
        counts.eliminate_zeros()
        data = counts.data
        detected = np.diff(counts.indptr).astype(float)
    else:
        counts = np.asarray(case.counts, dtype=float)
        if counts.ndim != 2:
            raise ValueError("Counts must be cells by genes")
        data = counts
        detected = np.count_nonzero(counts, axis=1).astype(float)
    if counts.shape != (len(cells), len(genes)) or not len(cells) or not len(genes):
        raise ValueError("Count dimensions and explicit cell/gene identifiers differ")
    if np.any(~np.isfinite(data)) or np.any(data < 0):
        raise ValueError("Counts must be finite and nonnegative")
    with np.errstate(over="ignore"):
        totals = np.asarray(counts.sum(axis=1)).ravel()
    if np.any(~np.isfinite(totals)) or np.any(totals <= 0):
        raise ValueError("Every cell requires a finite positive full-library total")
    mt = None
    if case.mitochondrial_fraction is not None:
        mt = np.asarray(case.mitochondrial_fraction, dtype=float)
        if mt.shape != (len(cells),) or np.any(~np.isfinite(mt)) or np.any((mt < 0) | (mt > 1)):
            raise ValueError("Mitochondrial fractions must be finite, cell-aligned and in [0,1]")
    return case, counts, genes, cells, totals, detected, mt


def deterministic_cells(cell_ids, patient_id, maximum=512, seed=20261031):
    """Hash selection is independent of expression, program membership and order."""
    cell_ids = _ids(cell_ids, "cell identifiers")
    if not isinstance(maximum, (int, np.integer)) or isinstance(maximum, bool) or maximum < 1:
        raise ValueError("maximum must be a positive integer")
    keys = [hashlib.sha256(f"{seed}\0{patient_id}\0{c}".encode()).digest() for c in cell_ids]
    return np.asarray(sorted(range(len(cell_ids)), key=lambda i: (keys[i], cell_ids[i]))[:maximum])


def standardized_rank_residuals(expression, covariates, tolerance=1e-10):
    """Across-cell average ranks, technical residuals, and unit-norm gene vectors.

    Input rows are cells and columns are genes. The intercept is always added;
    supplied nonconstant covariates are centered/scaled before SVD. Dependent
    columns are handled by the SVD rank, not an assumed number of covariates.
    Unit squared norm is algebraically equivalent to the n-1 norm convention.
    """
    expression = np.asarray(expression, dtype=float)
    covariates = np.asarray(covariates, dtype=float)
    if expression.ndim != 2 or covariates.ndim != 2 or expression.shape[0] != covariates.shape[0]:
        raise ValueError("Expression and technical covariates must have matching cells")
    if not np.all(np.isfinite(expression)) or not np.all(np.isfinite(covariates)):
        raise ValueError("Nonfinite residualization input")
    n = expression.shape[0]
    if n < 2:
        return None, np.zeros(expression.shape[1], dtype=bool), 0, n
    centered = covariates - covariates.mean(axis=0)
    norms = np.linalg.norm(centered, axis=0)
    usable = norms > tolerance
    design = np.column_stack((np.ones(n) / np.sqrt(n), centered[:, usable] / norms[usable]))
    q, singular, _ = np.linalg.svd(design, full_matrices=False)
    design_rank = int(np.count_nonzero(singular > tolerance))
    df = n - design_rank
    if df < 2:
        return None, np.zeros(expression.shape[1], dtype=bool), design_rank, df
    q = q[:, :design_rank]
    ranked = rankdata(expression, axis=0, method="average")
    residual = ranked - q @ (q.T @ ranked)
    norms = np.linalg.norm(residual, axis=0)
    variable = norms > tolerance
    z = np.zeros_like(residual)
    z[:, variable] = residual[:, variable] / norms[variable]
    return z.T, variable, design_rank, df


def mean_offdiagonal_correlation(unit_gene_vectors):
    """Mean off-diagonal Gram correlation; no full gene-correlation matrix."""
    z = np.asarray(unit_gene_vectors, dtype=float)
    if z.ndim != 2 or z.shape[0] < 2 or not np.all(np.isfinite(z)):
        raise ValueError("Need at least two finite standardized gene vectors")
    norms = np.einsum("ij,ij->i", z, z)
    if not np.allclose(norms, 1., atol=1e-8, rtol=1e-8):
        raise ValueError("Each gene vector must have unit squared norm")
    m = z.shape[0]
    total = z.sum(axis=0)
    return float((total @ total - norms.sum()) / (m * (m - 1)))


def matched_gene_strata(expression_percentiles, detection_percentiles, bins=5):
    """Patient-balanced mean percentiles, fixed grid, deterministic singleton merge.

    Arrays are patients by common variable genes. Ties get average percentiles.
    Any singleton grid stratum merges with the closest nonempty grid stratum by
    Manhattan distance, breaking ties lexicographically. No program effect is
    used. A stratum containing all genes is allowed; matching remains approximate.
    """
    a, b = np.asarray(expression_percentiles), np.asarray(detection_percentiles)
    if a.ndim != 2 or b.shape != a.shape or not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)):
        raise ValueError("Matching summaries must be finite patients-by-genes arrays")
    if not isinstance(bins, int) or bins < 1:
        raise ValueError("bins must be a positive integer")
    pooled_a, pooled_b = a.mean(axis=0), b.mean(axis=0)
    coordinates = np.minimum((np.column_stack((pooled_a, pooled_b)) * bins).astype(int), bins - 1)
    groups = {}
    for i, xy in enumerate(coordinates):
        groups.setdefault(tuple(xy), []).append(i)
    merges = []
    while len(groups) > 1:
        singles = sorted(k for k, v in groups.items() if len(v) < 2)
        if not singles:
            break
        key = singles[0]
        target = min((k for k in groups if k != key),
                     key=lambda k: (abs(k[0] - key[0]) + abs(k[1] - key[1]), k))
        groups[target].extend(groups.pop(key))
        merges.append((key, target))
    return [np.asarray(sorted(groups[k]), dtype=int) for k in sorted(groups)], merges


def shared_gene_permutation(strata, gene_count, rng):
    """One global bijection preserves every program's size and pairwise overlap."""
    permutation = np.arange(gene_count)
    for group in strata:
        permutation[group] = rng.permutation(group)
    return permutation


def by_adjust(pvalues):
    p = np.asarray(pvalues, dtype=float)
    if p.ndim != 1 or not len(p) or np.any(~np.isfinite(p)) or np.any((p < 0) | (p > 1)):
        raise ValueError("P values must be finite and in [0,1]")
    m = len(p)
    order = np.argsort(p, kind="stable")
    adjusted = p[order] * m * np.sum(1 / np.arange(1, m + 1)) / np.arange(1, m + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    result = np.empty(m)
    result[order] = np.minimum(adjusted, 1.)
    return result


def run_rna_coordination(
    datasets, programs, *, excluded_identity_genes=(), permutations=4999,
    seed=20261031, maximum_cells=512, minimum_activity_fraction=.8,
    minimum_activity_genes=20, minimum_coordination_genes=20,
    minimum_variable_fraction=.5, matching_bins=5, batch_size=16,
    expected_family_size=50, variance_tolerance=1e-10,
    comparison_tolerance=1e-12, return_null=False,
):
    """Calculate complete-family descriptive activity and conditional coordination.

    One resistance specimen per unique patient must already be adjudicated by
    the caller. This function never decides clinical acquired resistance or cell
    malignancy. Inputs are full-library count-like abundances, never log counts.
    No early stopping based on P values is performed. Synthetic fixtures may
    explicitly override proposed family size/thresholds/permutation count.
    """
    started = time.perf_counter()
    if not isinstance(permutations, int) or permutations < 1 or not isinstance(batch_size, int) or batch_size < 1:
        raise ValueError("Permutation and batch counts must be positive integers")
    if not (0 <= minimum_activity_fraction <= 1 and 0 <= minimum_variable_fraction <= 1):
        raise ValueError("Coverage fractions must be in [0,1]")
    if minimum_activity_genes < 1 or minimum_coordination_genes < 2:
        raise ValueError("Invalid minimum gene counts")
    if not np.isfinite(variance_tolerance) or variance_tolerance <= 0:
        raise ValueError("Variance tolerance must be finite and positive")
    if not np.isfinite(comparison_tolerance) or comparison_tolerance < 0:
        raise ValueError("Comparison tolerance must be finite and nonnegative")
    names = _ids(tuple(programs), "program identifiers")
    if len(names) != expected_family_size:
        raise ValueError("All programs in the explicitly specified testing family are required")
    definitions = {p: _ids(programs[p], f"{p} members") for p in names}
    if any(not genes for genes in definitions.values()):
        raise ValueError("Empty program definition")
    cases = [_case(d) for d in datasets]
    if not cases:
        raise ValueError("At least one explicitly identified patient is required")
    _ids([c[0].patient_id for c in cases], "independent patient identifiers")
    excluded = set(_ids(excluded_identity_genes, "excluded identity genes"))
    universe = sorted(set.intersection(*(set(c[2]) for c in cases)) - excluded)
    if len(universe) < 2:
        raise ValueError("The common assayed universe has fewer than two genes")
    assayed_set = set(universe)
    assayed_members = {p: [g for g in definitions[p] if g in assayed_set] for p in names}
    original_activity_ok = {p: len(assayed_members[p]) >= minimum_activity_genes
                            and len(assayed_members[p]) / len(definitions[p]) >= minimum_activity_fraction
                            for p in names}
    vectors, variable_masks, mean_percentiles, detect_percentiles = [], [], [], []
    activity, patient_info = {}, []
    for case, counts, genes, cells, totals, detected, mt in cases:
        lookup = {g: i for i, g in enumerate(genes)}
        columns = np.asarray([lookup[g] for g in universe])
        if sparse.issparse(counts):
            means = np.asarray(counts[:, columns].T @ (1_000_000. / totals)).ravel() / len(cells)
            detection = np.asarray((counts[:, columns] > 0).sum(axis=0)).ravel() / len(cells)
        else:
            means = np.mean(counts[:, columns] / totals[:, None] * 1_000_000., axis=0)
            detection = np.mean(counts[:, columns] > 0, axis=0)
        mean_percentiles.append((rankdata(means, method="average") - .5) / len(universe))
        detect_percentiles.append((rankdata(detection, method="average") - .5) / len(universe))
        ranks = (rankdata(means, method="average") - 1) / (len(universe) - 1) - .5
        positions = {g: i for i, g in enumerate(universe)}
        activity[case.patient_id] = {p: float(np.mean([ranks[positions[g]] for g in assayed_members[p]]))
                                     if original_activity_ok[p] else None for p in names}
        selected = deterministic_cells(cells, case.patient_id, maximum_cells, seed)
        block = counts[selected][:, columns]
        block = block.toarray() if sparse.issparse(block) else np.asarray(block)
        cpm = block / totals[selected, None] * 1_000_000.
        covs = [np.log1p(totals[selected]), detected[selected]]
        cov_names = ["log1p_full_library_total", "detected_full_library_genes"]
        if mt is not None:
            covs.append(mt[selected])
            cov_names.append("mitochondrial_fraction")
        z, variable, design_rank, df = standardized_rank_residuals(cpm, np.column_stack(covs), variance_tolerance)
        vectors.append(z)
        variable_masks.append(variable)
        patient_info.append({"patient_id": case.patient_id, "cancer_type": case.cancer_type,
                             "all_cells": len(cells), "coordination_cells": len(selected),
                             "selected_cell_ids": [cells[i] for i in selected],
                             "technical_covariates": cov_names, "technical_design_rank": design_rank,
                             "residual_degrees_of_freedom": df,
                             "variable_assayed_genes": int(variable.sum())})
    common_variable = np.logical_and.reduce(variable_masks)
    variable_universe = [g for g, keep in zip(universe, common_variable) if keep]
    variable_positions = {g: i for i, g in enumerate(variable_universe)}
    members = {p: [g for g in assayed_members[p] if g in variable_positions] for p in names}
    ok = {p: original_activity_ok[p] and len(members[p]) >= minimum_coordination_genes
          and len(members[p]) >= minimum_variable_fraction * len(assayed_members[p])
          and all(x["residual_degrees_of_freedom"] >= 2 for x in patient_info) for p in names}
    active_names = [p for p in names if ok[p]]
    observed = np.full((len(cases), len(active_names)), np.nan)
    null = np.empty((permutations, len(cases), len(active_names)))
    strata, merges = [], []
    preparation_done = time.perf_counter()
    if active_names:
        z_cases = [z[common_variable] for z in vectors]
        widths = [z.shape[1] for z in z_cases]
        offsets = np.cumsum([0] + widths)
        joined = np.ascontiguousarray(np.concatenate(z_cases, axis=1))
        member_indices = [np.asarray([variable_positions[g] for g in members[p]]) for p in active_names]
        sizes = np.asarray([len(x) for x in member_indices])
        flattened = np.concatenate(member_indices)
        for ci, z in enumerate(z_cases):
            for pi, idx in enumerate(member_indices):
                observed[ci, pi] = mean_offdiagonal_correlation(z[idx])
        strata, merges = matched_gene_strata(np.asarray(mean_percentiles)[:, common_variable],
                                            np.asarray(detect_percentiles)[:, common_variable], matching_bins)
        rng = np.random.default_rng(seed)
        for begin in range(0, permutations, batch_size):
            b = min(batch_size, permutations - begin)
            # Each draw's bijection is reused for every set and every patient.
            indices = np.concatenate([shared_gene_permutation(strata, len(variable_universe), rng)[flattened]
                                      for _ in range(b)])
            lengths = np.tile(sizes, b)
            indptr = np.concatenate(([0], np.cumsum(lengths)))
            membership = sparse.csr_matrix((np.ones(len(indices)), indices, indptr),
                                           shape=(b * len(active_names), len(variable_universe)))
            sums = np.asarray(membership @ joined).reshape(b, len(active_names), joined.shape[1])
            for ci in range(len(cases)):
                block = sums[:, :, offsets[ci]:offsets[ci + 1]]
                squares = np.einsum("bpc,bpc->bp", block, block)
                null[begin:begin + b, ci, :] = (squares - sizes) / (sizes * (sizes - 1))
        if np.any(~np.isfinite(observed)) or np.any(~np.isfinite(null)):
            raise ValueError("Nonfinite coordination statistic cannot pass")
    rows, family_p = [], []
    active_lookup = {p: i for i, p in enumerate(active_names)}
    for p in names:
        case_rows = []
        for ci, info in enumerate(patient_info):
            record = {"patient_id": info["patient_id"], "cancer_type": info["cancer_type"],
                      "activity": activity[info["patient_id"]][p], "coordination": None,
                      "null_mean": None, "null_excess": None, "conditional_p": 1.}
            if ok[p]:
                j = active_lookup[p]
                t = float(observed[ci, j])
                center = float(null[:, ci, j].mean())
                record.update(coordination=t, null_mean=center, null_excess=t - center,
                              # A conservative numeric tie guard avoids treating
                              # roundoff-equivalent permutations as smaller.
                              conditional_p=float((1 + np.count_nonzero(null[:, ci, j] >= t - comparison_tolerance)) / (permutations + 1)))
            case_rows.append(record)
        pmax = max(x["conditional_p"] for x in case_rows)
        cancer_pmax = {c: max(x["conditional_p"] for x in case_rows if x["cancer_type"] == c)
                       for c in sorted({x["cancer_type"] for x in case_rows})}
        family_p.append(pmax)
        rows.append({"program": p, "original_members": list(definitions[p]),
                     "assayed_members": assayed_members[p], "coordination_members": members[p],
                     "activity_coverage": len(assayed_members[p]) / len(definitions[p]),
                     "variable_fraction_of_assayed": len(members[p]) / len(assayed_members[p]) if assayed_members[p] else 0.,
                     "coordination_assessable": ok[p], "patients": case_rows,
                     "conditional_p_by_cancer": cancer_pmax,
                     "conditional_pmax": pmax,
                     "all_positive_coordination_and_excess": bool(ok[p] and all(x["coordination"] > 0 and x["null_excess"] > 0 for x in case_rows))})
    for row, q in zip(rows, by_adjust(family_p)):
        row["conditional_by_q"] = float(q)
    result = {"evidence_scope": "conditional matched-gene-set model; not population recurrence or resistance specificity",
              "patient_count": len(cases), "cancer_types": sorted({x[0].cancer_type for x in cases}),
              "patients": patient_info, "activity_universe": universe,
              "coordination_universe": variable_universe, "excluded_identity_genes": sorted(excluded),
              "programs": rows, "parameters": {"permutations": permutations, "seed": seed,
              "maximum_cells": maximum_cells, "minimum_activity_fraction": minimum_activity_fraction,
              "minimum_activity_genes": minimum_activity_genes, "minimum_coordination_genes": minimum_coordination_genes,
              "minimum_variable_fraction": minimum_variable_fraction, "matching_bins": matching_bins,
              "batch_size": batch_size, "family_size": expected_family_size,
              "variance_tolerance": variance_tolerance, "comparison_tolerance": comparison_tolerance},
              "matching_stratum_sizes": [len(s) for s in strata],
              "matching_strata_gene_ids": [[variable_universe[i] for i in s] for s in strata],
              "matching_singleton_merges": [[[int(v) for v in a], [int(v) for v in b]] for a, b in merges],
              "permutations_completed": permutations if active_names else 0,
              "null_status": "complete" if active_names else "not_applicable_no_assessable_programs",
              "timing_seconds": {"preparation": preparation_done - started,
                                  "total": time.perf_counter() - started}}
    if return_null:
        result["null_statistics"] = null
        result["null_program_order"] = active_names
    return result
