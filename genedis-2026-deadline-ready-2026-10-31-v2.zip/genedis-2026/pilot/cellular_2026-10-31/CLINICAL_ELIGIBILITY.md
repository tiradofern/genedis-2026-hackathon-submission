# Primary and exploratory clinical eligibility

PI decision, October 31, 2026. This supplements the approved restricted NSCLC protein endpoint and retains the full pan-cancer data gate.

## Primary discovery

Require acquired resistance supported by treatment-specific clinical criteria. Record the evidence for initial benefit, the subsequent progression event, relevant treatment episode and sampled specimen. Source-defined CR/PR and appropriately durable SD can establish benefit. Exact calendar dates and one universal duration threshold are not imposed on every treatment family.

Progression after treatment discontinuation neither automatically establishes nor automatically excludes acquired resistance. Where relevant, resolve the last dose, interval to progression, reason for stopping, intervening treatment and rechallenge history under the applicable clinical framework. A short progression-to-biopsy interval does not establish treatment status at progression.

## Separate exploratory analysis

Cases with documented initial benefit followed by progression but unresolved resistance classification may enter a clearly labelled exploratory analysis. Keep their uncertainty visible and assess how their inclusion changes findings once a qualifying primary analysis exists. They do **not** count toward the required qualifying discovery cancer cohorts. This permission does not open the primary gate or authorize using uncertain cases to nominate primary candidates.

## Current melanoma case

For [Yang patient 509](YANG_MELANOMA_GATE.md), the accepted classification is **documented initial benefit followed by progression; treatment status at progression unresolved; acquired resistance uncertain**. The response, progression event and biopsy four days afterward establish a useful sequence. They do not establish whether progression occurred during treatment.

The case is eligible for the separately labelled exploratory category, subject to technical QC. It remains excluded from primary discovery and from counting the two qualifying non-NSCLC cancers until clinical eligibility is resolved. Technical annotation recovery cannot resolve missing clinical exposure history.

## Measurement and claims

Protein measurements are approved for the independent NSCLC step only for components reliably measured and prospectively mapped. Approval of that modality does not establish cohort readiness, complete RNA-program replication, resistance specificity, selection or causality. Preserve all primary/exploratory denominators, unknowns, exclusions and negative findings.
