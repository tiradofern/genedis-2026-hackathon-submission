# Adversarial review of the frozen molecular measurements

Reviewed October 31, 2026, after execution. This is an AI-assisted scientific review, not Justin's approval. Sources were the completed `primary_full_result.json` and `quek_three_gene_full_result.json` in `data/processed/cellular_2026_10_31/measurement_run_20261031_frozen/`, the frozen measurement specification, and the independent pre-effect review. No new biological analysis, parameter adjustment or additional permutation run was performed for this review.

## Verdict

The pipeline produced a real, complete-family molecular measurement result. It did **not** establish a robust pan-cancer MSI, resistance-specific program, conserved genomic feature or causal resistance mechanism. The original discovery–independent NSCLC validation objective remains **inconclusive**, with robust nomination disabled before effects and NSCLC validation **not reached**. The observed OXPHOS row must not reopen that prospective decision.

## What was measured

The frozen primary run retained all 50 Hallmark programs across three independent acquired-resistant patients in two cancers. After technical QC, the MCC cases contributed 5,147 and 4,864 cells for descriptive activity; 512 cells per case were used for coordination. The melanoma case contributed six lineage-positive putative malignant cells. Its technical design had rank four and residual dimension two, compared with 508 residual dimensions in each MCC coordination sample. These are three patients, not thousands of clinical replicates.

Activity coverage permitted 46 of 50 program summaries. The four activity-unassessable sets were coagulation, KRAS signaling down, pancreas beta cells and spermatogenesis. Coordination was assessable for 31 sets; 19 were unassessable under the frozen membership/variability rules. The primary null calculation completed all 4,999 draws. Unassessable P/Q values stored as one are bookkeeping for the complete family, not valid negative biological tests.

## OXPHOS: a conditional observation with substantial alternative explanations

`HALLMARK_OXIDATIVE_PHOSPHORYLATION` had 184 of its 200 original genes in the shared assayed universe and 172 in the coordination universe. Its observed mean residual gene correlations were approximately **0.00831**, **0.01216** and **0.06084** for the two MCC cases and melanoma, respectively. The corresponding null excesses were positive. Each patient's conditional Monte Carlo P value was **0.0002**; the maximum was therefore 0.0002 and the 50-set BY-adjusted value was **0.044992**.

These values support only this statement: in these measured specimens, this predefined set showed greater within-specimen residual co-expression than the stated matched-gene-set null. The numeric adjusted value is below 0.05, but no robust MSI nomination follows. The correlations differ substantially in magnitude; neither common direction nor similar rank-summary activity proves matching effect size, a shared patient-population program or a common resistance process. The small MCC average correlations should be reported rather than replaced by the P value.

The result has several credible explanations that the current design cannot distinguish:

- Respiratory and mitochondrial genes participate in familiar, coordinated cellular machinery in many viable cancer and non-cancer cells. Known pathway architecture and generic essential metabolism can produce exceptional co-expression without a resistance-specific adaptation.
- Cell size, metabolic state, cell cycle, viability, stress, RNA quality, mitochondrial abundance and processing can influence these genes. Residualizing released-library size, gene detection and mitochondrial-read fraction reduces selected technical dependencies but does not eliminate them, particularly with six cells and two residual dimensions. Nuclear-encoded mitochondrial transcripts also need not be controlled by the MT-prefixed read fraction.
- Approximate matching on expression and detection preserves some technical background but does not match complete regulatory structure, lineage, organelle biology, genomic position or all cell-selection effects. BY adjustment addresses the declared multiplicity family; it cannot make this background model a test against ordinary cancer biology.
- The melanoma lineage mask is highly selective and does not enumerate all malignant states. Donor-label conflicts and possible ambient/mixed-cell errors remain limitations despite independent supporting identity evidence. Selection of these six cells could alter the observed co-expression geometry.
- Treatment regimens, tissue contexts and sample processing differ. PD-(L)1-containing combinations do not isolate one shared selective pressure, and there are no appropriate non-resistant comparators in this analysis.

Every OXPHOS P value is at the attainable Monte Carlo floor, **1/(4,999+1)**: no sampled null draw exceeded the observed statistic under the specified tie convention. This is finite simulation resolution, not P=0, an exact underlying tail probability, or independent replication. The adjusted value is near a conventional 0.05 boundary and depends on this finite-resolution estimate. Do not rerun with more draws or tune the null after seeing the result to obtain a preferred decision. A future independent study can prospectively specify more precise estimation.

## The frozen robustness failure remains decisive

The stricter melanoma lineage rule retained five cells. Its technical design still had rank four, leaving one residual dimension. Consequently the stricter result had **no assessable coordination programs**, no common coordination universe and zero null draws, explicitly labelled `not_applicable_no_assessable_programs`.

This is not a failed replication that demonstrated an opposite biological effect. It is an unavailable robustness measurement. Similar OXPHOS activity summaries in the two masks cannot substitute for an unmeasurable coordination sensitivity. No post-effect removal of covariates, alternate malignant-cell threshold, different null or reduced pathway family is justified. The pre-effect decision against robust MSI nomination remains binding.

## Other results and unavailable follow-up

The other 30 coordination-assessable programs did not have adjusted values below 0.05; for example, TNFA signaling via NFKB had BY Q approximately 0.06749, unfolded protein response 0.35994 and G2M checkpoint 0.39368. Report these continuous values and complete negative results without promoting an uncorrected P value. They represent no sufficient evidence against their precise conditional null at that descriptive threshold, not proof that the programs are absent or irrelevant to resistance.

IFN-gamma response had good assayed coverage (194/200 genes) but only **77/194** assayed members in the common variable coordination universe, below the frozen 50% requirement. Its coordination is **unassessable**, not negative. Available activity scores do not override that failure. The prepared NSCLC CD38/IDO1/CD274 protein-component runner therefore supplies no actual validation result. Neither this three-marker component nor any unrelated available protein panel can validate OXPHOS or an entire RNA Hallmark by substitution. No actual NSCLC follow-up should be executed under this run's primary gate.

## Required presentation

Keep all 50 programs visible, distinguish activity coverage from coordination assessability, and label the six-cell/five-cell melanoma denominators prominently. Report fixed-specimen conditional diagnostics separately from patient-population recurrence. Never describe the result as treatment-induced change, resistant-clone selection, response enrichment, genomic conservation or causal survival activity. No responder cohort is needed for the narrow descriptive observation, but resistance-specificity remains untested; stronger malignant-cell sampling and independent patients are needed for robust recurrence and coordination claims.

Recommended concluding wording: **“We executed frozen measurements of 50 predefined programs in three acquired-resistant patients across two cancer types. OXPHOS showed a conditional matched-gene-set co-expression signal in the primary specimens, but the melanoma sample and unavailable coordination sensitivity prevented robust MSI nomination. Independent NSCLC validation was not reached, and the primary discovery–validation objective remains inconclusive.”**
