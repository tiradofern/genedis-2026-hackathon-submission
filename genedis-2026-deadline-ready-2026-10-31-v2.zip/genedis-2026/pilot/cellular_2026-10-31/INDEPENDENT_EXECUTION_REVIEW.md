# Independent pre-effect execution and adequacy review

Recorded 2026-10-31, 20:53 UTC. Reviewer: independent gate-review agent. No functional program scores, coordination effects, P/Q values or candidate rankings were inspected for this review. This document records claim-specific decisions; it does not change the investigator's two-non-NSCLC-cancer discovery followed by independent NSCLC component-validation design.

## Decision

- **GO: descriptive measurement of the complete predefined program family** in the available melanoma lineage-positive cells, with all coverage failures retained and the frozen stricter cell-mask sensitivity reported. Comparable measurements in MCC and measured NSCLC protein components can remain part of the original design. This is execution of bounded measurements, not substitution of an easier primary study.
- **GO only as an explicitly exploratory technical diagnostic:** the frozen matched-gene coordination calculation where its numerical prerequisites pass. Its null concerns genes in these fixed specimens, not recurrence in a patient population. A nominal or multiplicity-adjusted conditional result must not automatically create an MSI nomination.
- **HOLD: a robust primary cross-cancer MSI nomination or a claim that the complete discovery-and-validation objective has been demonstrated.** The melanoma resistance endpoint has six primary-mask cells and five under the frozen stricter mask. With the proposed four-column technical model, its residual dimensions are two and one respectively. The stricter analysis is therefore unassessable under the existing engine. Coordination robustness in this acquired-resistant melanoma specimen is unresolved before effects, rather than a tested biological negative.

This decision introduces neither a universal minimum number of cells nor a majority-cell requirement. A rare malignant population may be important. The limitation concerns the precision and robustness of this particular coordination measurement with this model, not the biological importance of rare populations.

## Clinical and sample-identity adjudication

The original publication's Table S1 identifies MIA1 as initial partial response followed by acquired resistance under ipilimumab/nivolumab, with a post-treatment lymph-node specimen. The published treatment diagram independently supports response, progression and resistance-stage biopsy before subsequent dabrafenib/trametinib. Exact last-dose dates are unavailable. This is adequate source-supported acquired-resistance eligibility under the agreed treatment-specific criteria; it is stronger than an unexplained benefit-to-progression sequence. The baseline anatomical-site disagreement between Table S1 and Figure 1 prevents an assumed same-site paired comparison. It does not invalidate a clearly labelled resistance-endpoint description.

Released RNA donor labels conflict substantially with released ADT labels and demultiplexing assignments. There are no triple-concordant MIA1 resistance cells. Majority voting among these files is not proof, and the ADT/assignment sources may share an upstream origin.

Subsequent independent RNA identity evidence supports retaining the **unmodified RNA metadata** for RNA analysis: the source-concordant MIA1 pretreatment reference is strongly multi-Y-positive (334/398 cells detect at least two of the fixed Y-panel genes). In the two-donor second library, RNA-labelled MIA1 resistance immune cells are predominantly multi-Y-positive (368/515), whereas RNA-labelled MIA11 pretreatment immune cells are overwhelmingly XIST-positive (629/839) and rarely multi-Y-positive (3/839), at comparable RNA depths. The pretreatment reference has no cells passing the strict immune mask; its positive multi-Y anchor uses all reference cells and this limitation remains explicit. These observations support the RNA clinical-sample mapping without claiming DNA genotype confirmation, a published correction, or independent knowledge of clinical sex.

Do not modify the ADT/assignment labels, use Y expression to select individual malignant cells, or describe the provenance conflict as author-resolved. Earlier HOLD records remain historical; this adjudication reopens **RNA sample mapping only**, not every downstream adequacy gate.

## Frozen cell identification and observed feasibility

The reviewed RNA-lineage protocol requires technical QC, multiple independent melanocytic lineage markers, expression above a same-library immune-cell ambient threshold, and immune/stromal/endothelial exclusion. It excludes identity-marker genes from primary program testing and forbids response, IFN/HLA, functional program scores and proliferation for cell classification. All other cells remain unclassified/reference/mixed; they are not declared normal.

This is a reasonable prospective identification of **lineage-positive putative malignant melanocytic cells** in a pathology-confirmed melanoma specimen, with limitations for dedifferentiation, nodal nevi, ambient RNA and doublets. It is not reproduction of unavailable author barcode annotations or a complete census of malignant cells. The fixed algorithm produced 99 MIA1 pretreatment cells and six MIA1 resistance cells; the stricter resistance mask retains five. No thresholds should be adjusted to increase the endpoint after this finding.

## Statistical adequacy

The reviewed engine ranks gene expression across cells, residualizes an intercept plus log library total, detected genes and mitochondrial fraction using the actual design rank, and normalizes residual gene vectors. It requires at least two residual dimensions and applies a shared matched-gene permutation, complete-family maximum-P conjunction and Benjamini–Yekutieli correction across 50 programs.

At six cells and design rank four, gene vectors occupy a two-dimensional residual space. Correlations can be computed, but are sensitive to individual cells, ties, covariate leverage and the chosen cell mask. Twenty or more program genes do not create twenty independent cellular observations. A gene-label null can still ask whether this fixed set is unusually aligned relative to matched sets, conditional on approximate gene exchangeability and the selected cells. It does not manufacture additional patients, cancer types, clones, independent cells or reliable population uncertainty. BY correction addresses the complete testing family under valid conditional P values; it does not repair an inadequate biological sampling frame or an exchangeability failure.

At five cells and rank four, the stricter analysis has one residual dimension and the existing engine correctly marks it unassessable. Do not remove technical covariates, lower the residual-dimension rule, relax cell identification or substitute a more favourable null after effects. Do not call the missing sensitivity result negative evidence against a program.

Descriptive mean-rank activity is separately measurable where fixed coverage requirements pass. Report the six-cell denominator, per-cell values or clearly labelled aggregate, the five-cell sensitivity, assay membership and uncertainty limits. Nonzero activity is not an established biological activation threshold. Cell-derived intervals cannot be presented as patient-population confidence intervals. A change from 99 pretreatment to six resistance cells is additionally vulnerable to site, sampling, processing and phenotype-selection differences; it does not demonstrate selection or expansion.

## Permitted and unsupported conclusions

A permissible observation is: "Predefined program measurements were obtained from two MCC resistance specimens and six lineage-positive putative melanoma cells from one documented acquired-resistance specimen; melanoma coordination sensitivity was unassessable." Report any conditional gene-set statistic with its exact restricted null and all programs, independently of its direction or significance.

The current melanoma endpoint cannot establish reliable prevalence among malignant cells, population-level recurrence, resistance specificity, genomic conservation, selection or a causal mechanism. Independent NSCLC protein-component measurements cannot retrospectively supply the missing melanoma cellular precision or establish whole-RNA-program replication. An attractive descriptive heatmap or a significant conditional P value must not override these limits.

The primary design therefore remains **inconclusive for robust MSI discovery**, pending better malignant-cell assignment coverage supported by independent evidence, a better-covered eligible melanoma specimen/cohort, or a new prospectively justified study design. Preserve these feasibility findings and the full pan-cancer requirement. A future scope change belongs to the investigator; this review does not authorize one.

## Reviewed artifacts

- `QUEK_CELL_ID_PROTOCOL.json`, SHA256 `425c4bf6fea44f9d1dc18faee719655ccf6d554f3f9a5da405d05f9ce5a3a013`.
- `QUEK_CELL_ID_QC.json`, SHA256 `b1ec84942748243267a1421b5502b75c95040159190ea7bd34720e19021f2104`.
- `rna_coordination.py`, SHA256 `79b32c4846a81c5d6d687ba84d839a5a1a164e7c1035ec64cb3f41019ea7b78b`.
- Independent technical-identity receipt: `QUEK_COUNT_STRUCTURE_QC.json`; clinical and source-access records: `QUEK_EXECUTION_GATE.md` and `CLINICAL_ELIGIBILITY.md`.

No effects were inspected, no candidates selected, no existing files modified, and no molecular analysis executed by this reviewer.
