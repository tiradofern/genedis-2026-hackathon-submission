"""Recover publication case IDs from bounded public MCD XML footers only.

Never download a full MCD, read image data, or use molecular effects to match IDs.
"""
import argparse
import concurrent.futures
import csv
import hashlib
import json
from pathlib import Path
import re
import urllib.request
import xml.etree.ElementTree as ET

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--cellmetadata", required=True, type=Path)
p.add_argument("--xml-directory", required=True, type=Path)
p.add_argument("--receipt", required=True, type=Path)
a = p.parse_args()
a.xml_directory.mkdir(parents=True, exist_ok=True)
sample_map = {}
with a.cellmetadata.open() as handle:
    for row in csv.DictReader(handle):
        sample_map.setdefault(row["SampleID"], set()).add((row["PatientID"], row["TherapyStatus"]))
record_url = "https://zenodo.org/api/records/8041882"
record = json.load(urllib.request.urlopen(record_url, timeout=25))
files = [f for f in record["files"] if f["key"].endswith(".mcd")]
start_tag, end_tag = "<MCDSchema".encode("utf-16-le"), "</MCDSchema>".encode("utf-16-le")

def recover(f):
    start = max(0, f["size"] - 1048576)
    request = urllib.request.Request(f["links"]["self"], headers={
        "Range": f"bytes={start}-{f['size']-1}", "Accept-Encoding": "identity"})
    response = urllib.request.urlopen(request, timeout=40)
    if response.status != 206:
        response.close()
        raise RuntimeError(f"Range not honored for {f['key']}; no full file read")
    content_range = response.headers.get("Content-Range")
    body = response.read(1048577)
    response.close()
    if len(body) != min(1048576, f["size"]):
        raise RuntimeError("Unexpected range byte count")
    begin, end = body.rfind(start_tag), body.rfind(end_tag)
    if begin < 0 or end <= begin:
        raise RuntimeError(f"Complete XML footer not in bounded range: {f['key']}")
    xml = body[begin:end+len(end_tag)]
    root = ET.fromstring(xml.decode("utf-16-le"))
    slides = []
    for child in root:
        if child.tag.split("}")[-1] == "Slide":
            fields = {item.tag.split("}")[-1]: item.text for item in child}
            slides.append((fields.get("Filename") or "").replace("\\", "/").split("/")[-1])
    match = re.search(r"_P(\d+)[ _](response|resistance)\.mcd$", f["key"])
    if not match:
        raise RuntimeError("Unrecognized public case label")
    matches = {}
    for slide in slides:
        for sample in sample_map:
            if re.search(r"(?:^|_)" + re.escape(sample) + r"(?:_real)?\.mcd$", slide):
                matches[sample] = sorted([list(v) for v in sample_map[sample]])
    path = a.xml_directory / f"P{match.group(1)}_{match.group(2)}.xml"
    path.write_bytes(xml)
    expected_state = "pre" if match.group(2) == "response" else "post"
    matched_states = {state for values in matches.values() for pid, state in values}
    return {
        "public_file": f["key"], "source_url": f["links"]["self"],
        "publication_patient_id": "P"+match.group(1), "file_state": match.group(2),
        "HTTP_status": 206, "content_range": content_range, "range_bytes": len(body),
        "range_sha256": hashlib.sha256(body).hexdigest(),
        "XML_bytes": len(xml), "XML_sha256": hashlib.sha256(xml).hexdigest(),
        "slide_filename_basenames": slides, "matched_SCE_samples": matches,
        "expected_SCE_state_from_public_filename": expected_state,
        "slide_filename_state_agrees_with_public_state": matched_states == {expected_state},
    }

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(recover, files))
by_case = {}
for item in results:
    case = item["publication_patient_id"]
    by_case.setdefault(case, set())
    for mappings in item["matched_SCE_samples"].values():
        by_case[case].update(pid for pid, state in mappings)
q = {
    "audit": "Publication P1-P7 to processed SCE crosswalk using raw-file XML metadata only",
    "date": "2026-10-31", "source_record": record_url, "files": results,
    "publication_to_SCE_patient_ids": {k: sorted(v) for k, v in sorted(by_case.items())},
    "all_cases_uniquely_mapped": all(len(v) == 1 for v in by_case.values()) and len(by_case) == 7,
    "state_header_matches": sum(item["slide_filename_state_agrees_with_public_state"] for item in results),
    "state_header_mismatches": [item["public_file"] for item in results if not item["slide_filename_state_agrees_with_public_state"]],
    "mapping_uses_ordinal_order_or_molecular_effects": False,
    "full_MCD_or_image_intensity_read": False,
}
a.receipt.write_text(json.dumps(q, indent=2) + "\n")
print(json.dumps({"all_cases_uniquely_mapped": q["all_cases_uniquely_mapped"],
                  "publication_to_SCE_patient_ids": q["publication_to_SCE_patient_ids"]}))
