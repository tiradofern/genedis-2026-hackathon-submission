# Yang melanoma source gate — October 31, 2026

**Status: promising clinical/access recovery; no automatic GO.** This metadata-only audit identifies a public melanoma source that may replace the inaccessible Quek file route. It does not adjudicate acquired resistance definitively, open the full pan-cancer gate, fix a program panel or authorize candidate selection.

Primary source: Yang et al., *Mature and migratory dendritic cells promote immune infiltration and response to anti-PD-1 checkpoint blockade in metastatic melanoma*, Nature Communications 2025, DOI [10.1038/s41467-025-62878-5](https://doi.org/10.1038/s41467-025-62878-5), [PMC12402436](https://pmc.ncbi.nlm.nih.gov/articles/PMC12402436/). Clinical metadata were recovered from [Supplementary Data 1](https://media.springernature.com/full/springer-static/esm/art%3A10.1038%2Fs41467-025-62878-5/MediaObjects/41467_2025_62878_MOESM2_ESM.xlsx). This is a strict-OOXML workbook; its clinical table was read in memory from workbook XML because the installed openpyxl did not recognize its sheet namespace.

## Verified clinical metadata and specimen crosswalk

| Source field | Patient 509, specimen 509_1 | Patient 509, specimen 509_2 | Separate patient 620, specimen 620_2 |
|---|---|---|---|
| Accession | [GSM8330653](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM8330653) | [GSM8330650](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM8330650) | [GSM8330678](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM8330678) |
| Long sample ID | D19-11994 | D19-11971 | D21-194011 |
| Melanoma subtype | Cutaneous | Cutaneous | Cutaneous |
| Treatment field | Pembrolizumab | Pembrolizumab | Ipilimumab+nivolumab; prior pembrolizumab and targeted treatment |
| Prior therapy field | None | None | Targeted plus ICI |
| Treatment state | POST | POST | POST |
| Days relative to treatment start | 1,130 | 1,200 | 455 |
| PFS / `censure_pfs` | 1,126 / 1 | 1,126 / 1 | 446 / 1 |
| OS / `censure_os` | 1,850 / 0 | 1,850 / 0 | 778 / 0 |
| Lesion response | R | R | R |
| Sampled tissue | Skin | Lymph node | Bone |

The paper states that survival intervals are measured from treatment initiation and lesional response was assessed using RECIST 1.1. The binary R/NR field does not expose the original CR/PR/SD category. The authors' [survival notebook](https://github.com/KellisLab/scCancer/blob/main/Figures/Survival_curves_F3B_ExtF3B_SuppF3E.ipynb) passes `censure_pfs` directly to `Surv(pfs, censure_pfs)`, supporting interpretation of **1 as an event**, despite the column's potentially confusing name.

**Clinical adjudication: probable, strongly supported acquired resistance; not an explicit source label.** Patient 509 combines a RECIST-linked response annotation, long PFS, an observed PFS event and two POST specimens collected after that event. This is more evidence than PFS duration or post-treatment status alone. Later censored OS is consistent with progression rather than death at the PFS event. The first specimen is four days after the PFS event and therefore has less temporal ambiguity than the second, collected 74 days afterward. The two specimens are **one independent patient**, from different sites; no pretreatment specimen for patient 509 appears in the inspected clinical table. Patient 620 supplies another independent lead but a different combination regimen and prior-exposure history.

## Public molecular access verified without retrieving matrices

[GSE269936](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE269936) lists per-specimen processed Matrix Market counts, feature/barcode files and HDF5 matrices. A HEAD-only request to the [509_1 matrix](https://ftp.ncbi.nlm.nih.gov/geo/samples/GSM8330nnn/GSM8330653/suppl/GSM8330653_D19-11994_matrix.mtx.gz) returned **HTTP 200**, `application/x-gzip`, and **143,873,479 bytes**. No matrix body was requested.

The primary paper links [Zenodo 15603513](https://zenodo.org/records/15603513), whose public manifest specifies **CC BY 4.0** and nine processed R objects. A subsequent check recovered [version 15843679](https://zenodo.org/records/15843679), dated July 9, 2025, also CC BY 4.0, with this complete inventory:

| Filename | Bytes in version 15843679 | Material |
|---|---:|---|
| `1_RNA_all_cleaned.rds` | 6,461,335,186 | All-cell RNA object |
| `2_integrated_six_studies_060125.qs` | 19,933,435,720 | Integrated multi-study object |
| `3_tumor_metaprograms_cleaned.rds` | 3,031,205,961 | Tumor RNA object |
| `4_RNA_myeloid_cells_cleaned.rds` | 513,803,760 | Myeloid RNA object |
| `5_RNA_CD8T_cells_cleaned.rds` | 1,059,190,708 | CD8 T-cell RNA object |
| `6_RNA_CD4T_cells_filtered.rds` | 982,835,071 | CD4 T-cell RNA object |
| `7_RNA_cDC_cells_filtered.RDS` | 214,749,170 | Dendritic-cell RNA object |
| `8_ATAC_cDC_cells.rds` | 237,419,658 | Dendritic-cell ATAC object |
| `9_coembed_cDC_cells_filtered.rds` | 432,012,120 | Dendritic-cell co-embedding object |

The tumor object is identical across these two versions: deposited MD5 `baaa3e39a74ae249bd1c184a40fc25e0`. Version 15843679 changes the two ATAC-related objects; it does not add metadata-only files. The smaller immune-cell objects cannot substitute for malignant-cell classifications.

The [public object-documentation notebook](https://github.com/KellisLab/scCancer/blob/main/Figures/Final_objects.ipynb) displays tumor-object metadata fields including `patient_sample`, `patient`, `sample_ID_long`, `cell_barcode`, `compartment` and `cell_type`; it reports tumor-only cell type. This is evidence that a barcode/sample classification crosswalk is represented in the authors' objects, **not verification of the downloaded object's integrity or contents**. The paper describes marker annotation and inferCNV against normal clusters for malignant-cell identification, with ambient-RNA and multiplet handling.

**No separate small cell-annotation download was located.** The [GEO archive manifest](https://ftp.ncbi.nlm.nih.gov/geo/series/GSE269nnn/GSE269936/suppl/filelist.txt) contains 154 rows: a header, the 8,257,505,280-byte archive entry and four count/barcode/feature/HDF5 files for each of 38 specimens. No annotation file is listed. Both Zenodo versions contain molecular objects rather than a standalone metadata CSV. The [GitHub workflow](https://github.com/KellisLab/scCancer/blob/main/Methods/scRNA_workflow/scRNA_workflow_metastatic_all.ipynb) references local `scCancer_metadata.csv` and per-sample pseudobulk metadata export paths; those paths are not public assets. The repository has one branch, no issues and no release assets at this check. Inspected annotation/schema notebook outputs contain field names but no complete barcode mapping.

Extracting the authors' annotations from the tumor RDS is a concrete technical route, but requires retrieving an object that also contains molecular values. That retrieval was not performed under this audit's metadata-only scope. Independently recreating classifications from smaller counts would require a documented QC method and validation. No `Rscript` executable was available in the inspected environment; object extraction therefore also needs an appropriate R runtime or another validated reader.

## Remaining decisions and uncertainties

1. Preserve the distinction between the source's RECIST-linked lesional R and patient-level benefit. Exact CR/PR/SD categories or calendar dates are not universal eligibility requirements; their absence alone does not invalidate the combined clinical evidence.
2. Resolve, where possible, progression while receiving treatment versus relapse after discontinuation and intervening therapy. The source ties these specimens to pembrolizumab but does not explicitly state biopsy at progression before the next treatment. A missing next-therapy field is uncertainty, not evidence of ineligibility; a four-day interval alone does not prove its absence.
3. Verify actual malignant-cell barcode coverage for the selected specimens, object/raw-count compatibility, sample identifiers, chemotherapy/platform metadata and viable cell counts during authorized technical QC. Availability is established more strongly than specimen-level analysis readiness.
4. Keep pembrolizumab monotherapy separate from ipilimumab+nivolumab and other combinations until an explicit treatment-family rule is adopted. No patients are selected using program effects.
5. Complete the second non-NSCLC cancer and independent NSCLC gates before molecular discovery. The PI has now permitted NSCLC protein validation of reliably measured program components. The component definitions and cross-modal endpoint still need to be frozen; this would not establish replication of an entire RNA program.

## Metadata receipts

| Inspected record | Bytes | SHA256 |
|---|---:|---|
| Supplementary Data 1 clinical workbook | 15,581 | `6501d56bce4aa4da3b59efde3e77b1db63f02a474a07c0302da56f13ef541346` |
| [GEO sample metadata response](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE269936&targ=gsm&form=text&view=quick) | 103,017 | `4ae4c82441631de572fca09a60f7979b61d40a6f0fd0dfdad050d7d77f6852fa` |
| [Zenodo record JSON](https://zenodo.org/api/records/15603513) | 5,839 | `1fa5f93f5809e22a774c43cbf9c8df8808b3274d2047c75a0e1d45378f1f806a` |
| [Latest-version Zenodo JSON](https://zenodo.org/api/records/15843679) | 5,837 | `c6a9ff5386a7c56e2d2a25959bc33cc4cb7ff30b973caac7b98cc9432829f725` |
| [GEO archive file inventory](https://ftp.ncbi.nlm.nih.gov/geo/series/GSE269nnn/GSE269936/suppl/filelist.txt) | 11,528 | `baebcfb8744564bf1970fc6c2542d4377421518c258c05cecabce1ba2a65d5a2` |

These identify inspected responses, some of which are dynamic. They are not expression-file checksums. Only clinical/access metadata, methods and annotation schemas were inspected. No expression matrix/R object was downloaded, no programs were scored, no expression effects were used for selection, and no author contact or access application was made.
