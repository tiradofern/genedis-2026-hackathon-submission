"""Pure numerical preparation helpers; no file access or biological analysis.

These utilities do not define a clinical cohort, freeze a program collection,
calibrate a biological activity threshold, test coordination, or nominate MSIs.
All identifiers, measurable universes and coverage policies come from callers.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Mapping, Sequence

import numpy as np
from scipy.stats import rankdata


def _labels(values, name, *, unique=False, allow_spaces=False):
    if isinstance(values, (str, bytes)):
        raise ValueError(f"Supply a sequence of {name} identifiers, not one string")
    values = tuple(values)
    for value in values:
        if (not isinstance(value, str) or not value or value != value.strip()
                or (not allow_spaces and any(c.isspace() for c in value))):
            raise ValueError(f"Invalid explicit {name} identifier: {value!r}")
    if unique and len(set(values)) != len(values):
        raise ValueError(f"Duplicate {name} identifiers")
    return values


def _matrix(values, name):
    values = np.asarray(values, dtype=float)
    if values.ndim != 2 or not all(values.shape):
        raise ValueError(f"{name} must be a nonempty rows-by-features matrix")
    if not np.all(np.isfinite(values)):
        raise ValueError(f"{name} contains missing or nonfinite values")
    return values


def _finite_mean(values, *, axis=0):
    """Reject numerical overflow instead of exporting nonfinite summaries."""
    with np.errstate(over="ignore", invalid="ignore"):
        result = np.mean(values, axis=axis)
    if not np.all(np.isfinite(result)):
        raise ValueError("Mean aggregation produced nonfinite values")
    return result


def parse_gmt(text: str) -> dict[str, tuple[str, ...]]:
    """Parse supplied GMT text, preserving exact IDs without alias conversion.

    Reject duplicate program IDs and repeated genes within a program. Sharing
    genes between different programs is allowed and does not imply independence.
    The second GMT field is descriptive metadata and is not a gene identifier.
    """
    if not isinstance(text, str):
        raise TypeError("GMT input must be text, not a path or file handle")
    programs = {}
    for number, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        fields = line.split("\t")
        if len(fields) < 3:
            raise ValueError(f"GMT line {number} needs a program, description and genes")
        program = _labels([fields[0]], "program")[0]
        if program in programs:
            raise ValueError(f"Duplicate program identifier: {program}")
        programs[program] = _labels(fields[2:], "gene", unique=True)
    if not programs:
        raise ValueError("GMT contains no programs")
    return programs


@dataclass(frozen=True)
class ProgramCoverage:
    original_genes: int
    measured_genes: tuple[str, ...]
    fraction: float
    eligible: bool


@dataclass(frozen=True)
class RankScores:
    """Scores are unitless relative-expression summaries, never binary states."""

    scores: dict[str, np.ndarray]
    coverage: dict[str, ProgramCoverage]
    universe: tuple[str, ...]


def rank_program_scores(
    values,
    gene_ids: Sequence[str],
    programs: Mapping[str, Sequence[str]],
    universe: Sequence[str],
    *,
    minimum_coverage_fraction: float,
    minimum_measured_genes: int,
) -> RankScores:
    """Mean normalized within-row gene ranks over an explicit measured universe.

    ``values`` has samples/cells in rows and ``gene_ids`` in columns. Ranks use
    average ties over exactly ``universe``; each rank becomes
    ``(rank - 1) / (G - 1) - 0.5``. A program is the uniform mean of its measured
    members. Missing program genes are absent, not imputed as zero. Missing
    universe genes are an error. Coverage is against the complete supplied gene
    set, using the caller's explicit fraction AND gene-count requirements.

    Every program is returned. Ineligible programs have all-NaN scores, with
    coverage retained. No cross-sample normalization, learned feature selection,
    reference calibration, binary activity call or statistical test occurs.
    """
    values = _matrix(values, "expression")
    gene_ids = _labels(gene_ids, "expression gene", unique=True)
    universe = _labels(universe, "universe gene", unique=True)
    if len(gene_ids) != values.shape[1]:
        raise ValueError("Expression column count does not match gene identifiers")
    if len(universe) < 2:
        raise ValueError("The explicit measurable universe needs at least two genes")
    if (isinstance(minimum_coverage_fraction, bool)
            or not np.isfinite(minimum_coverage_fraction)
            or not 0 <= minimum_coverage_fraction <= 1):
        raise ValueError("Coverage fraction must be finite and between zero and one")
    if (isinstance(minimum_measured_genes, bool)
            or not isinstance(minimum_measured_genes, (int, np.integer))
            or minimum_measured_genes < 1):
        raise ValueError("Minimum measured genes must be a positive integer")
    if not programs:
        raise ValueError("Supply at least one explicit program")
    _labels(programs.keys(), "program", unique=True)
    positions = {gene: i for i, gene in enumerate(gene_ids)}
    missing = set(universe) - positions.keys()
    if missing:
        raise ValueError(f"Universe genes are absent from expression: {sorted(missing)}")
    ranked = rankdata(values[:, [positions[g] for g in universe]], axis=1, method="average")
    ranked = (ranked - 1) / (len(universe) - 1) - 0.5
    universe_positions = {gene: i for i, gene in enumerate(universe)}
    scores, coverage = {}, {}
    for program, members in programs.items():
        members = _labels(members, f"{program} gene", unique=True)
        if not members:
            raise ValueError(f"Empty program: {program}")
        measured = tuple(gene for gene in members if gene in universe_positions)
        fraction = len(measured) / len(members)
        eligible = (len(measured) >= minimum_measured_genes
                    and fraction >= minimum_coverage_fraction)
        coverage[program] = ProgramCoverage(len(members), measured, fraction, eligible)
        scores[program] = (
            ranked[:, [universe_positions[g] for g in measured]].mean(axis=1)
            if eligible else np.full(values.shape[0], np.nan)
        )
    return RankScores(scores, coverage, universe)


def cell_cpm(counts) -> np.ndarray:
    """Normalize each cell's supplied library to one million count units.

    Input is cells by genes, with finite nonnegative count-like abundances. The
    caller must supply the complete measured library used for normalization,
    not just program genes, and establish that input units are appropriate.
    No logarithm, imputation, count model or gene-length correction is applied.
    Zero-total libraries are rejected rather than assigned artificial zeros.
    """
    counts = _matrix(counts, "counts")
    if np.any(counts < 0):
        raise ValueError("Counts must be nonnegative")
    with np.errstate(over="ignore"):
        totals = counts.sum(axis=1)
    if np.any(~np.isfinite(totals)) or np.any(totals <= 0):
        raise ValueError("Each cell needs a finite positive library total")
    return counts / totals[:, None] * 1_000_000


def mean_cell_cpm(counts) -> np.ndarray:
    """Equal-cell mean CPM (genes), distinct from library-size-weighted pseudobulk."""
    return _finite_mean(cell_cpm(counts))


@dataclass(frozen=True)
class SpecimenAggregation:
    patient_ids: tuple[str, ...]
    specimen_ids: tuple[str, ...]
    states: tuple[str, ...]
    cell_counts: tuple[int, ...]
    values: np.ndarray

    @property
    def independent_patient_count(self):
        return len(set(self.patient_ids))


def aggregate_cells_by_specimen(
    values, *, cell_ids, patient_ids, specimen_ids, states,
) -> SpecimenAggregation:
    """Equal-cell means within explicit specimens; never pool treatment states.

    ``values`` is cells by features (e.g. CPM or a specified cell-level score).
    Every cell requires explicit patient, specimen and sampling-state labels.
    Cell IDs must be unique, and each globally unique specimen ID must map to
    exactly one patient and state. Repeated specimens remain separate rows.
    Values keep the input units. This function performs no normalization.
    Callers must namespace identifiers across source cohorts and independently
    establish patient identity; matching labels do not establish independence.
    """
    values = _matrix(values, "cell values")
    cell_ids = _labels(cell_ids, "cell", unique=True)
    patient_ids = _labels(patient_ids, "patient")
    specimen_ids = _labels(specimen_ids, "specimen")
    states = _labels(states, "sampling state", allow_spaces=True)
    if any(len(labels) != values.shape[0]
           for labels in (cell_ids, patient_ids, specimen_ids, states)):
        raise ValueError("Each cell requires one patient, specimen and state label")
    groups, metadata = defaultdict(list), {}
    for i, (patient, specimen, state) in enumerate(zip(patient_ids, specimen_ids, states)):
        if specimen in metadata and metadata[specimen] != (patient, state):
            raise ValueError(f"Conflicting patient or sampling state for specimen {specimen}")
        metadata[specimen] = patient, state
        groups[specimen].append(i)
    ordered = sorted(groups, key=lambda specimen: (metadata[specimen][0], specimen))
    return SpecimenAggregation(
        tuple(metadata[s][0] for s in ordered), tuple(ordered),
        tuple(metadata[s][1] for s in ordered),
        tuple(len(groups[s]) for s in ordered),
        np.vstack([_finite_mean(values[groups[s]]) for s in ordered]),
    )


@dataclass(frozen=True)
class PatientAggregation:
    patient_ids: tuple[str, ...]
    specimen_counts: tuple[int, ...]
    state: str
    values: np.ndarray

    @property
    def cohort_mean(self):
        """Equal-patient descriptive mean; no inferential uncertainty is implied."""
        return _finite_mean(self.values)


def aggregate_specimens_by_patient(
    specimens: SpecimenAggregation, *, state: str, repeated_specimens: str,
) -> PatientAggregation:
    """Aggregate only an explicitly selected state, returning one row per patient.

    The caller must choose ``repeated_specimens='error'`` or explicitly permit
    ``'equal_specimen_mean'``. The latter gives each specimen equal weight within
    its patient, then each patient equal weight in ``cohort_mean``. It does not
    justify combining different lesions, timing or treatment episodes: those
    scientific decisions and any earlier specimen selection remain external.
    """
    state = _labels([state], "selected sampling state", allow_spaces=True)[0]
    if repeated_specimens not in {"error", "equal_specimen_mean"}:
        raise ValueError("Explicitly choose error or equal_specimen_mean for repeated specimens")
    values = _matrix(specimens.values, "specimen values")
    patients = _labels(specimens.patient_ids, "patient")
    identifiers = _labels(specimens.specimen_ids, "specimen", unique=True)
    states = _labels(specimens.states, "sampling state", allow_spaces=True)
    if any(len(labels) != values.shape[0]
           for labels in (patients, identifiers, states, specimens.cell_counts)):
        raise ValueError("Specimen values and metadata lengths differ")
    groups = defaultdict(list)
    for i, (patient, observed_state) in enumerate(zip(patients, states)):
        if observed_state == state:
            groups[patient].append(i)
    if not groups:
        raise ValueError(f"No specimens for selected state {state}")
    if repeated_specimens == "error" and any(len(rows) > 1 for rows in groups.values()):
        raise ValueError("Repeated specimens require explicit selection or aggregation")
    ordered = sorted(groups)
    return PatientAggregation(
        tuple(ordered), tuple(len(groups[p]) for p in ordered), state,
        np.vstack([_finite_mean(values[groups[p]]) for p in ordered]),
    )
