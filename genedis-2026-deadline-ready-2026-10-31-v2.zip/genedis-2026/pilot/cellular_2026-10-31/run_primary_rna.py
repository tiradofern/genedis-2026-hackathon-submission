#!/usr/bin/env python3
"""Fail-closed frozen-protocol runner; never decides clinical eligibility or MSIs."""
from __future__ import annotations
import argparse
import csv
import hashlib
import inspect
import json
from pathlib import Path
import platform
import sys
from datetime import datetime, timezone
import numpy as np
import scipy
from scipy import sparse

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
from program_scores import parse_gmt
from rna_coordination import RNACase, run_rna_coordination

ANALYSIS_ID = 'PAN_CANCER_FIXED_PROGRAMS_20261031'


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def load_json(path):
    def reject(value):
        raise ValueError(f'Non-standard JSON numeric constant: {value}')
    return json.loads(Path(path).read_text(), parse_constant=reject)


def checked_file(path, expected):
    path = Path(path)
    if not path.is_file() or not isinstance(expected, str) or len(expected) != 64:
        raise ValueError(f'Missing file or explicit SHA256: {path}')
    actual = sha256(path)
    if actual != expected:
        raise ValueError(f'SHA256 mismatch: {path}')
    return path


def require_unique(values, name):
    if not values or len(values) != len(set(values)):
        raise ValueError(f'Missing/duplicate {name}')


def members_hash(programs):
    payload = {name: list(genes) for name, genes in programs.items()}
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def validate_gate(protocol_path, gate_path):
    protocol, gate = load_json(protocol_path), load_json(gate_path)
    if gate.get('decision') != 'GO_DESCRIPTIVE_CONDITIONAL':
        raise ValueError('Explicit GO_DESCRIPTIVE_CONDITIONAL gate is required')
    if gate.get('analysis_id') != ANALYSIS_ID or protocol.get('analysis_id') != ANALYSIS_ID:
        raise ValueError('Unexpected analysis identity')
    if gate.get('protocol_sha256') != sha256(protocol_path):
        raise ValueError('Gate does not authorize this exact frozen protocol file')
    if protocol.get('status') != 'FROZEN_BEFORE_REAL_PROGRAM_EFFECTS':
        raise ValueError('Protocol was not explicitly frozen before effects')
    if protocol.get('primary_nomination_enabled') is not False:
        raise ValueError('Primary molecular-candidate nomination must remain disabled')
    if not isinstance(protocol.get('limitations'), list) or not all(isinstance(x, str) for x in protocol['limitations']):
        raise ValueError('Explicit protocol limitation metadata is required')
    artifacts = protocol.get('execution_artifacts')
    if not isinstance(artifacts, dict):
        raise ValueError('Frozen execution artifacts are required before any assay load')
    expected_names = {'rna_coordination.py', 'run_primary_rna.py', 'program_scores.py', 'MEASUREMENT_PROTOCOL.md', 'INDEPENDENT_EXECUTION_REVIEW.md'}
    if not expected_names.issubset({Path(path).name for path in artifacts}):
        raise ValueError('Missing frozen engine, runner, parser or scientific review artifacts')
    for path, expected_hash in artifacts.items():
        checked_file(path, expected_hash)
    for name in ('rna_coordination.py', 'run_primary_rna.py', 'program_scores.py'):
        matching = [Path(path).resolve() for path in artifacts if Path(path).name == name]
        if matching != [(HERE / name).resolve()]:
            raise ValueError('Execution artifact does not identify the actual imported code')
    return protocol, gate


def load_case(receipt, cancer_type):
    cohort = receipt['cohort']
    if receipt.get('status') != 'STRUCTURAL_INGEST_ONLY_NO_PROGRAM_SCORES':
        raise ValueError(f'Missing prior structural assay receipt: {cohort}')
    if receipt.get('all_source_values_validated') is not True:
        raise ValueError('Source count validation was not completed')
    inputs = receipt.get('inputs', [])
    if not inputs:
        raise ValueError('Source input hashes are missing from the prior assay receipt')
    for item in inputs:
        path = checked_file(item['path'], item['sha256'])
        if path.stat().st_size != item['bytes']:
            raise ValueError('Source input byte length mismatch')
    outputs = receipt.get('outputs', [])
    require_unique([item['path'] for item in outputs], 'receipt output paths')
    for item in outputs:
        path = checked_file(item['path'], item['sha256'])
        if path.stat().st_size != item['bytes']:
            raise ValueError('Receipt byte length mismatch')
    def role(suffix):
        found = [Path(item['path']) for item in outputs if Path(item['path']).name == f'{cohort}{suffix}']
        if len(found) != 1:
            raise ValueError(f'Expected exact one hashed {suffix} output for {cohort}')
        return found[0]
    counts = sparse.load_npz(role('_counts.npz'))
    if not sparse.isspmatrix_csr(counts) or not counts.has_canonical_format:
        raise ValueError('Expected canonical cells-by-genes CSR counts')
    genes = load_json(role('_genes.json'))
    with role('_cells.csv').open(newline='') as handle:
        rows = list(csv.DictReader(handle))
    require_unique(genes, 'source genes')
    require_unique([row['cell_id'] for row in rows], 'source cells')
    if counts.shape != (len(rows), len(genes)) or list(counts.shape) != receipt['output_shape_cells_by_genes']:
        raise ValueError('Counts, genes, cells and receipt dimensions differ')
    if counts.nnz != receipt['output_nnz'] or counts.shape[0] != receipt['technical_QC_pass_cells']:
        raise ValueError('Receipt matrix nonzero/cell counts differ')
    data = np.asarray(counts.data)
    if np.any(~np.isfinite(data)) or np.any(data <= 0) or np.any(data != np.floor(data)):
        raise ValueError('Nonpositive, nonfinite or fractional stored counts')
    patient_ids = sorted({row['patient_id'] for row in rows})
    if len(patient_ids) != 1 or patient_ids != receipt['patients']:
        raise ValueError('One explicitly identified patient per specimen receipt is required')
    if any(row['technical_QC_pass'] != 'True' for row in rows):
        raise ValueError('Primary matrix contains a technical-QC failure')
    totals = np.asarray(counts.sum(axis=1)).ravel().astype(float)
    detected = np.diff(counts.indptr)
    mt_indices = [i for i, gene in enumerate(genes) if gene.upper().startswith('MT-')]
    mt_counts = np.asarray(counts[:, mt_indices].sum(axis=1)).ravel().astype(float)
    mt_percent = 100 * mt_counts / totals
    recorded_totals = np.array([float(row['UMI']) for row in rows])
    recorded_detected = np.array([int(row['detected_genes']) for row in rows])
    recorded_mt = np.array([float(row['MT_UMI']) for row in rows])
    recorded_mt_percent = np.array([float(row['MT_percent']) for row in rows])
    if (not np.array_equal(totals, recorded_totals) or not np.array_equal(detected, recorded_detected)
            or not np.array_equal(mt_counts, recorded_mt)
            or not np.allclose(mt_percent, recorded_mt_percent, rtol=0, atol=1e-10)):
        raise ValueError('Actual full-library UMI, detected genes or MT QC differ from cell metadata')
    if np.any(totals < 500) or np.any(detected < 200) or np.any(mt_percent > 20):
        raise ValueError('Actual counts fail frozen technical QC')
    if any(row['cancer'] != cancer_type for row in rows):
        raise ValueError('Frozen cancer type differs from cell metadata')
    return RNACase(patient_id=patient_ids[0], cancer_type=cancer_type, counts=counts,
                   gene_ids=genes, cell_ids=[row['cell_id'] for row in rows],
                   mitochondrial_fraction=recorded_mt_percent / 100.)


def prepare_inputs(protocol):
    source = protocol['input_manifest']
    manifest_path = checked_file(source['path'], source['sha256'])
    manifest = load_json(manifest_path)
    if manifest.get('status') != 'STRUCTURAL_INPUTS_NO_PROGRAM_SCORES':
        raise ValueError('Missing prior assay/input manifest')
    cohorts = protocol['cohort_ids']
    require_unique(cohorts, 'frozen cohort identifiers')
    receipts = manifest.get('cohorts', [])
    require_unique([item['cohort'] for item in receipts], 'input receipt cohort identifiers')
    if set(cohorts) != {item['cohort'] for item in receipts}:
        raise ValueError('Input receipt cohorts differ from the exact frozen cohort set')
    cancer_types = protocol['cohort_cancer_types']
    if set(cancer_types) != set(cohorts):
        raise ValueError('Each frozen cohort requires an explicit cancer type')
    by_cohort = {item['cohort']: item for item in receipts}
    cases = [load_case(by_cohort[name], cancer_types[name]) for name in cohorts]
    require_unique([case.patient_id for case in cases], 'independent patient identifiers')
    if len(set(case.cancer_type for case in cases)) < 2:
        raise ValueError('Two frozen non-NSCLC discovery cancer types are required')
    if any(case.cancer_type.upper() in {'NSCLC', 'LUAD', 'LUSC'} for case in cases):
        raise ValueError('NSCLC is reserved for independent validation')
    program_spec = protocol['programs']
    gmt_path = checked_file(program_spec['gmt_path'], program_spec['gmt_sha256'])
    programs = parse_gmt(gmt_path.read_text())
    if program_spec['family_size'] != 50 or len(programs) != 50:
        raise ValueError('The complete fixed 50-program testing family is required')
    if members_hash(programs) != program_spec['members_sha256']:
        raise ValueError('Program membership identity differs from the frozen family')
    params = protocol['engine_parameters']
    expected = set(inspect.signature(run_rna_coordination).parameters) - {'datasets', 'programs', 'excluded_identity_genes', 'return_null'}
    if set(params) != expected or params['expected_family_size'] != 50:
        raise ValueError(f'Every engine parameter must be explicitly frozen: {sorted(expected)}')
    excluded = protocol['excluded_identity_genes']
    if not isinstance(excluded, list):
        raise ValueError('Excluded identity genes must be explicit')
    return cases, programs, params, manifest


def write_results(output_dir, label, result, provenance, protocol):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    result['analysis_id'] = ANALYSIS_ID
    result['primary_nomination_enabled'] = False
    result['protocol_limitations'] = protocol['limitations']
    result['provenance'] = provenance
    full = output_dir / f'{label}_full_result.json'
    full.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    patient_rows, family_rows = [], []
    for program in result['programs']:
        shared = {'program': program['program'], 'activity_coverage': program['activity_coverage'],
            'assayed_genes': len(program['assayed_members']), 'coordination_genes': len(program['coordination_members']),
            'coordination_assessable': program['coordination_assessable'],
            'conditional_pmax': program['conditional_pmax'], 'conditional_by_q': program['conditional_by_q']}
        patient_rows.extend([{**shared, **patient} for patient in program['patients']])
        family_rows.append({**shared,
            'conditional_p_by_cancer': json.dumps(program['conditional_p_by_cancer'], sort_keys=True),
            'all_positive_coordination_and_excess': program['all_positive_coordination_and_excess']})
    for path, rows in ((output_dir / f'{label}_all_programs_by_patient.csv', patient_rows),
                       (output_dir / f'{label}_conditional_by_family.csv', family_rows)):
        with path.open('w', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader(); writer.writerows(rows)
    return full


def prepare_sensitivity(protocol, cases):
    if not protocol.get('sensitivity'):
        return None
    spec = protocol['sensitivity']
    if (not isinstance(spec['name'], str) or not spec['name'] or
            spec['name'] == 'primary' or not all(c.isascii() and (c.isalnum() or c in '_-') for c in spec['name'])):
        raise ValueError('Sensitivity requires a distinct simple output name')
    mask_path = checked_file(spec['cell_mask_path'], spec['cell_mask_sha256'])
    with mask_path.open(newline='') as handle:
        mask_rows = list(csv.DictReader(handle))
    require_unique([row['cell_id'] for row in mask_rows], 'sensitivity mask cell IDs')
    if not mask_rows or spec['column'] not in mask_rows[0]:
        raise ValueError('Missing exact frozen sensitivity column')
    by_cell = {row['cell_id']: row[spec['column']] for row in mask_rows}
    target = protocol['cohort_ids'].index(spec['cohort_id'])
    case = cases[target]
    if any(cell not in by_cell for cell in case.cell_ids):
        raise ValueError('Sensitivity mask does not cover the exact primary cells')
    if any(by_cell[cell] not in {'True', 'False'} for cell in case.cell_ids):
        raise ValueError('Unassessable sensitivity identity cannot be converted to a primary decision')
    keep = np.array([by_cell[cell] == 'True' for cell in case.cell_ids])
    if not keep.any():
        raise ValueError('No cells in the frozen sensitivity; no threshold relaxation')
    strict = RNACase(case.patient_id, case.cancer_type, case.counts[keep], case.gene_ids,
                     [cell for cell, flag in zip(case.cell_ids, keep) if flag], np.asarray(case.mitochondrial_fraction)[keep])
    strict_cases = cases.copy(); strict_cases[target] = strict
    return strict_cases, spec


def run(protocol_path, gate_path, output_dir):
    output_dir = Path(output_dir)
    if output_dir.exists() and (not output_dir.is_dir() or any(output_dir.iterdir())):
        raise ValueError('Refusing an existing nonempty output directory before any effects')
    protocol, gate = validate_gate(protocol_path, gate_path)
    cases, programs, params, manifest = prepare_inputs(protocol)
    sensitivity = prepare_sensitivity(protocol, cases)
    output_dir.mkdir(parents=True, exist_ok=True)
    if any(output_dir.iterdir()):
        raise ValueError('Output directory became nonempty before effects')
    provenance = {'created_UTC': datetime.now(timezone.utc).isoformat(),
        'protocol': {'path': str(protocol_path), 'sha256': sha256(protocol_path)},
        'gate': {'path': str(gate_path), 'sha256': sha256(gate_path)},
        'input_manifest': protocol['input_manifest'], 'programs': protocol['programs'],
        'execution_artifacts': protocol['execution_artifacts'],
        'runner_sha256': sha256(__file__), 'engine_sha256': sha256(HERE / 'rna_coordination.py'),
        'program_parser_sha256': sha256(HERE / 'program_scores.py'),
        'python_version': platform.python_version(), 'numpy_version': np.__version__, 'scipy_version': scipy.__version__,
        'input_receipts': manifest['cohorts'], 'gate_decision': gate['decision']}
    result = run_rna_coordination(cases, programs, excluded_identity_genes=protocol['excluded_identity_genes'], **params)
    written = [write_results(output_dir, 'primary', result, provenance, protocol)]
    if sensitivity is not None:
        strict_cases, spec = sensitivity
        strict_result = run_rna_coordination(strict_cases, programs, excluded_identity_genes=protocol['excluded_identity_genes'], **params)
        strict_provenance = {**provenance, 'sensitivity': spec}
        written.append(write_results(output_dir, spec['name'], strict_result, strict_provenance, protocol))
    return written


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol', required=True, type=Path)
    parser.add_argument('--gate', required=True, type=Path)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    paths = run(args.protocol, args.gate, args.output_dir)
    print(json.dumps({'outputs': [str(path) for path in paths]}))


if __name__ == '__main__':
    main()
