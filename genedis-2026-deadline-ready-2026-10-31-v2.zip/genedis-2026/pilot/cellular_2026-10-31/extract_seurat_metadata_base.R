# Base-R metadata-only logical extraction. readRDS itself eagerly deserializes
# the complete object. Do not call Seurat methods or access any assay slot.
args <- commandArgs(trailingOnly=TRUE)
if (length(args) != 4L) stop("Expected input.rds, metadata.csv, metadata.rds, schema.tsv")
x <- readRDS(args[[1]])
md <- attr(x, "meta.data", exact=TRUE)
if (!is.data.frame(md)) stop("meta.data is not a data.frame")
if (anyDuplicated(rownames(md))) stop("Metadata cell IDs are duplicated")
missing_token <- "__R_NA__"
for (v in md) {
  if (is.character(v) || is.factor(v)) {
    if (any(as.character(v) == missing_token, na.rm=TRUE)) stop("Missing-value token collides with source value")
  }
}
# The metadata-only RDS retains R factor levels, ordered factors, NA and types.
saveRDS(md, args[[3]], version=3)
write.csv(cbind(source_cell_id=rownames(md), md), args[[2]], row.names=FALSE, na=missing_token)
schema <- data.frame(
  column=names(md),
  R_class=vapply(md, function(v) paste(class(v), collapse=";"), character(1)),
  missing=vapply(md, function(v) sum(is.na(v)), integer(1)),
  factor_levels=vapply(md, function(v) if (is.factor(v)) paste(levels(v), collapse="|") else "", character(1)),
  stringsAsFactors=FALSE
)
write.table(schema, args[[4]], sep="\t", quote=TRUE, row.names=FALSE, na=missing_token)
cat("BASE_R_METADATA_EXTRACTED cells=", nrow(md), " fields=", ncol(md), "\n", sep="")
