# Independent final evidence and claim review

Reviewed October 31, 2026, after execution and the recorded exact replay. This is an AI-assisted independent audit, not Justin's personal approval. Unlike the pre-effect review, this audit inspected completed outputs. No molecular calculation, parameter change, candidate selection or frozen-artifact edit was performed.

**Verdict: no critical numerical or claim inconsistency identified in the reviewed result narrative.** The bounded calculations completed; robust MSI discovery remains inconclusive, no MSI is nominated, and independent NSCLC validation was not reached. The oxidative-phosphorylation conditional observation does not reverse the pre-effect adequacy decision.

## Independently checked numerical facts

The [primary JSON](results/primary_full_result.json), [strict JSON](results/quek_three_gene_full_result.json), both 150-row patient CSVs and both 50-row family CSVs agree exactly for the reported activity, coordination, null mean/excess, conditional P/Q values and assessability flags. The [result report](RESULTS_2026-10-31.md), README, readiness record and measurement specification accurately distinguish:

- Three independent patients across two cancers: MCC cells **5,147 and 4,864**, melanoma **six**; coordination uses **512, 512 and six** cells, with residual dimensions **508, 508 and two**. The stricter melanoma subset has **five** cells and residual dimension **one**. Cells are not clinical replicates.
- All **50** predefined programs retained. **46** meet descriptive activity coverage; **31** have an assessable primary shared coordination endpoint and **19** are unassessable. The four activity failures have represented fractions 108/138, 148/200, 30/40 and 104/135, each below 80%. Unassessable P=1 entries are family bookkeeping, not biological negative tests.
- Primary assayed/common-variable universes of **20,732/9,046** genes and **4,999** completed null draws. The stricter shared coordination universe is empty, all 50 coordination endpoints are unavailable, and its null calculation is not applicable. This does not negate MCC-only coordination.
- OXPHOS membership **184/200 assayed**, **172 common-variable**. In the report's patient order, coordination T is **0.0083100262, 0.0121613090, 0.0608384317**; matched-null excess is **0.0082654393, 0.0105596470, 0.0600286746**. Each conditional P and their maximum are **0.0002**. Independently recomputing `0.0002 × 50 × sum(1/i, i=1..50)` gives BY Q **0.04499205338**, matching the saved value. It is the only row below 0.05; the next Q is **0.06748808007**. These are finite-resolution conditional gene-set statistics.
- IFN-gamma response has **194/200** assayed genes but only **77/194** common-variable members, below the 50% coordination rule. Its coordination is unavailable, not a negative replication.
- The complete protein coverage audit confirms **zero direct nominal OXPHOS gene-product overlap**. IFN-gamma's three direct nominal genes are **CD274, CD38 and IDO1**; they cannot validate the entire RNA program. The NSCLC gate is explicitly **HOLD / NOT_REACHED** and no protein program effects are claimed.

## Frozen provenance and replay

The current RNA protocol, execution gate, frozen input manifest, cell-identification protocol, coordination engine and runner are byte-identical to their versions in pre-effect commit **85b3694**, following the initial freeze **74cf912**. The frozen manifest confirms all three named patients and cell counts.

The saved primary/strict JSON hashes and all four CSV hashes match [RNA_EXECUTION_QC.json](RNA_EXECUTION_QC.json). Independently removing only `timing_seconds` and `provenance.created_UTC` from the original results reproduces both recorded semantic SHA256 values. The QC record reports that independent replay matched all other scientific fields and CSV bytes. These checks verify numerical/provenance consistency, not biological validation.

## Claim boundary and presentation

The reviewed documents correctly refrain from population recurrence, resistance enrichment, treatment-induced change, convergent selection, causal survival function, new network discovery, genomic conservation or independently discovered conserved-gene-core claims. Shared Hallmark membership is fixed by definition. The six-cell lineage-positive melanoma population, unresolved source-label provenance, differing regimens, approximate matched-gene background and ordinary respiratory-chain biology remain explicit alternative explanations and limitations.

The original two-non-NSCLC-cancer to NSCLC design remains the scientific objective. Descriptive execution is not labelled successful primary discovery, and unavailable robustness/validation endpoints are not reported as tested negatives. Further work needs prospectively specified improved malignant-cell coverage, additional independent patients and an NSCLC assay adequate for any eventual nominated function; future methods must not be tuned to rescue this result.

The local Markdown-link check covered **14 new/changed documents and 77 local links** before this review was added, with **no missing targets**. It included the results, main cellular README, methods, reproducibility handoff, reviews and figure README; legacy repository documentation was outside this check. The figures' numerical descriptions and denominator statements agree with the saved tables; this audit does not replace the separately recorded visual inspection.

No changes to the frozen scientific artifacts are requested. Preserve the pre-effect HOLD, all negative/unassessable rows and the explicit NSCLC-not-reached status in any repository summary, presentation or future submission.
