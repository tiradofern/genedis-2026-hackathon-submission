"""Rebuild GSE248249 metadata eligibility; never calculate expression effects.

Requires the public series matrix in sources/, fetched separately or with
--retrieve. Only its metadata header is parsed. No expression values are parsed.
Uses only Python's standard library. Outputs belong to this isolated pilot.
"""
from __future__ import annotations

import argparse
import csv
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import urllib.request

ROOT = Path(__file__).resolve().parent
SOURCES = ROOT / "sources"
MATRIX_URL = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE248nnn/GSE248249/matrix/GSE248249_series_matrix.txt.gz"
MATRIX_SHA256 = "d6841e253c5e3c5494e7d5794c6b244878e868c35a01fc34268ec2e664a9d1ff"
PUBLICATION_URL = "https://pmc.ncbi.nlm.nih.gov/articles/PMC11249385/"
TABLE_S2_URL = "https://pmc.ncbi.nlm.nih.gov/articles/instance/11249385/bin/NIHMS1954849-supplement-2.xlsx"


def metadata_header(path: Path) -> dict[str, list[list[str]]]:
    """Stop before the data table. A matrix-integrity analysis is not performed."""
    lines = []
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        for line in stream:
            if line.startswith("!series_matrix_table_begin"):
                break
            lines.append(line)
        else:
            raise ValueError("Missing series-matrix data boundary")
    meta = defaultdict(list)
    for row in csv.reader(io.StringIO("".join(lines)), delimiter="\t"):
        if row and row[0].startswith("!"):
            meta[row[0]].append(row[1:])
    return dict(meta)


def sample_rows(meta):
    ids = meta["!Sample_geo_accession"][0]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate deposited GSMs")
    rows = []
    for index, gsm in enumerate(ids):
        title = meta["!Sample_title"][0][index]
        match = re.fullmatch(r"Tumor sample from Patient (\d+), (pre|post)-immunotherapy treatment", title)
        if not match:
            raise ValueError(f"Unrecognized patient/timepoint title: {title}")
        patient, phase = match.groups()
        characteristics = {}
        for values in meta["!Sample_characteristics_ch1"]:
            if len(values) != len(ids):
                raise ValueError("Inconsistent sample-characteristic width")
            key, separator, value = values[index].partition(": ")
            if not separator or key in characteristics:
                raise ValueError("Invalid or repeated deposited characteristic")
            characteristics[key] = value
        if characteristics["timepoint"] != {"pre": "Pre-treatment", "post": "Post-treatment"}[phase]:
            raise ValueError("Title/characteristic timepoint disagreement")
        cel = next(values[index] for values in meta["!Sample_supplementary_file"] if values[index].endswith(".CEL.gz"))
        file_group = re.search(r"_SMP4_(\d+)[A-Z]_", cel)
        processing = " ".join(values[index] for values in meta["!Sample_data_processing"])
        if "SST-RMA normalization alone" not in processing or "two separate batches" not in processing:
            raise ValueError("Deposited normalization provenance changed")
        rows.append({
            "accession": "GSE248249", "gsm": gsm, "patient_id": patient,
            "source_title": title, "phase": phase,
            "specimen_site": characteristics["tumor site"],
            "specimen_processing": characteristics["sample type"],
            "modality": "bulk_transcriptomic_microarray", "platform": meta["!Sample_platform_id"][0][index],
            "treatment_class_paper": "PD-(L)1 blockade", "individual_regimen": "NR",
            "post_state_paper": "progression_before_next_systemic_therapy" if phase == "post" else "not_applicable",
            "patient_best_response": "NR", "strict_PR_CR_then_progression_verified": "unresolved",
            "exact_collection_interval": "NR", "histology": "NR", "purity": "NR",
            "confirmed_processing_batch": "NR", "filename_group_not_batch": file_group.group(1) if file_group else "NR",
            "deposited_normalization": "SST-RMA_only", "same_lesion_linkage": "NR",
            "clinical_crosswalk_source": "Table_S2_linked_but_not_retrieved",
            "source_url": f"https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={gsm}",
        })
    return rows


def paired_rows(samples):
    grouped = defaultdict(dict)
    for row in samples:
        phases = grouped[row["patient_id"]]
        if row["phase"] in phases:
            raise ValueError("Repeated phase per author patient; needs prespecified specimen prioritization")
        phases[row["phase"]] = row
    pairs = []
    for patient in sorted(grouped):
        if set(grouped[patient]) != {"pre", "post"}:
            continue
        pre, post = grouped[patient]["pre"], grouped[patient]["post"]
        same_site = pre["specimen_site"] == post["specimen_site"]
        blockers = ["strict_patient_AR_crosswalk_unresolved", "processing_batch_unresolved", "gene_annotation_unverified"]
        if not same_site:
            blockers.append("anatomic_site_changed")
        pairs.append({
            "patient_id": patient, "pre_gsm": pre["gsm"], "post_gsm": post["gsm"],
            "pre_site": pre["specimen_site"], "post_site": post["specimen_site"],
            "same_broad_anatomic_site": str(same_site).lower(),
            "same_lesion_verified": "unresolved",
            "same_filename_group_not_batch": str(pre["filename_group_not_batch"] == post["filename_group_not_batch"]).lower(),
            "pre_confirmed_batch": "NR", "post_confirmed_batch": "NR",
            "strict_acquired_resistance_eligible": "unresolved", "inferential_eligible_now": "false",
            "blockers": ";".join(blockers),
        })
    return pairs, grouped


def write_tsv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--retrieve", action="store_true", help="retrieve the public processed matrix only; do not analyze values")
    args = parser.parse_args()
    SOURCES.mkdir(exist_ok=True)
    matrix = SOURCES / "GSE248249_series_matrix.txt.gz"
    if args.retrieve:
        with urllib.request.urlopen(MATRIX_URL, timeout=60) as response:
            body = response.read()
        observed = hashlib.sha256(body).hexdigest()
        if observed != MATRIX_SHA256:
            raise ValueError(f"Public matrix checksum changed: {observed}")
        matrix.write_bytes(body)
    observed = hashlib.sha256(matrix.read_bytes()).hexdigest()
    if observed != MATRIX_SHA256:
        raise ValueError("Matrix checksum mismatch")
    samples = sample_rows(metadata_header(matrix))
    pairs, grouped = paired_rows(samples)
    assert len(samples) == 42 and len(grouped) == 29 and len(pairs) == 13
    same_site = [r["patient_id"] for r in pairs if r["same_broad_anatomic_site"] == "true"]
    assert same_site == ["01", "12", "19", "23"]
    write_tsv(ROOT / "samples.tsv", samples)
    write_tsv(ROOT / "pairs.tsv", pairs)
    gate = {
        "cohort": "GSE248249", "assessment_date_utc": datetime.now(timezone.utc).isoformat(),
        "verdict": "STOP_INFERENTIAL", "fallback": "metadata_feasibility_report",
        "primary_effects_run": False, "expression_values_parsed": False,
        "source_counts": {"profiles": len(samples), "author_patient_ids": len(grouped), "complete_pairs": len(pairs),
            "pretreatment": sum(r["phase"] == "pre" for r in samples), "posttreatment": sum(r["phase"] == "post" for r in samples),
            "same_broad_site_pairs": len(same_site), "strict_AR_eligibility_verified_pairs": 0, "fully_ready_inferential_pairs": 0},
        "same_broad_site_patient_ids": same_site,
        "independence": "29 distinct author-provided patient identifiers; no genotype identity verification performed",
        "clinical_definition": {
            "clinical_cohort_AR": "RECIST PR/CR followed by progression",
            "molecular_cohort": "29 patients; 22 had CR/PR, remainder includes SD with <10% tumor shrinkage",
            "post_biopsy": "all after radiographic progression and before new systemic therapy, publication-level",
            "paired_subset_strict_AR": "unresolved without sample-linked best overall response",
            "scheduled_on_treatment": False, "primary_resistance_pooled": False,
        },
        "hard_blockers": [
            "13 paired patients cannot be classified individually under strict acquired-resistance criterion from deposited metadata",
            "9/13 pairs change anatomic site; four match broad site, not verified lesion",
            "two independent SST-RMA processing batches; sample batch labels not deposited in parsed metadata",
            "GEO states deposited values have SST-RMA alone; final ComBat/LOESS-normalized gene values are available on request",
            "complete Clariom_D feature-to-gene annotation not verified here; 138745 features must not be called genes",
        ],
        "precision_limit": {"same_site_upper_bound_n": 4, "one_sided_exact_sign_flip_minimum_p": 0.0625,
            "implication": "Even four flawless same-site pairs cannot attain raw one-sided p<0.05, before correction across programs/directions."},
        "expression_descriptive_analysis": "Not performed; would need fixed mapping, root authorization and conspicuous processing/site/clinical limitations",
        "genomic_inference": "Unsupported by this transcriptomic input; publication WES is a separate controlled-access dataset",
        "resistance_specificity": "No matched longitudinal durable-responder comparator verified; not needed for descriptive recurrence but required for resistance-specific enrichment",
        "unlock_requirements": ["retrieve/verify Table S2 clinical crosswalk", "obtain confirmed sample batch assignments or public final normalized matrix", "verify feature annotation", "prespecify site-confounding strategy and adequate independent patients"],
        "sources": [MATRIX_URL, PUBLICATION_URL, TABLE_S2_URL, "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM7908985"],
    }
    (ROOT / "gate.json").write_text(json.dumps(gate, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"verdict": gate["verdict"], "counts": gate["source_counts"], "matrix_sha256": observed}))


if __name__ == "__main__":
    main()
