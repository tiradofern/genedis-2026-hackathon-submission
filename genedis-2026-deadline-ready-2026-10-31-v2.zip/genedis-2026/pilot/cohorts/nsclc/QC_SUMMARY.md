# GSE248249 longitudinal NSCLC feasibility gate — 31 October 2026

**Decision: stop inferential program testing in this cohort for the current submission.** Retain a transparent metadata feasibility result. The present audit is not a biological negative result, and it does not refute the Molecular Survival Islands hypothesis. No expression effects, program scores, differential expression, or resistance-enrichment tests were calculated.

## What was verified afresh

The original publication is Memon et al., *Cancer Cell* (2024), DOI [10.1016/j.ccell.2023.12.013](https://doi.org/10.1016/j.ccell.2023.12.013), PMID 38215748, [PMC11249385](https://pmc.ncbi.nlm.nih.gov/articles/PMC11249385/). Its clinical cohort defines acquired resistance as RECIST partial/complete response followed by progression. Its molecular methods explicitly include a different, broader subset: 29 patients, of whom 22 (76%) had a best overall CR/PR, plus a small stable-disease subgroup with less than 10% tumor shrinkage. Therefore the generic cohort label cannot establish strict acquired resistance separately for every molecular pair.

The public [GEO accession](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE248249) and a fresh retrieval of the processed [series matrix](https://ftp.ncbi.nlm.nih.gov/geo/series/GSE248nnn/GSE248249/matrix/GSE248249_series_matrix.txt.gz) were examined. The compressed matrix is 20,017,929 bytes and SHA-256 `d6841e253c5e3c5494e7d5794c6b244878e868c35a01fc34268ec2e664a9d1ff`, matching the preserved historical audit. Only the metadata header was parsed; the expression data table was not parsed. Agreement of a checksum establishes source continuity, not biological validity.

| Quantity | Verified result |
| --- | --- |
| Deposited expression profiles | 42 |
| Distinct author-provided patient identifiers | 29 |
| Pretreatment / post-treatment profiles | 13 / 29 |
| Complete one-pre / one-post patient pairs | 13 |
| Same broad anatomic site pairs | 4: patients 01, 12, 19, 23 |
| Site-changing pairs | 9 |
| Pairs with verified individual PR/CR-to-progression eligibility | 0 at this audit; unknown is not ineligible |
| Pairs with confirmed explicit processing-batch labels | 0 |
| Pairs meeting all current inferential readiness conditions | 0 |

The late baseline GSM7911924 is correctly linked to patient 23; the GSM range alone is insufficient to enumerate pairs. All specimens are FFPE. The molecular modality is bulk transcriptomic microarray, Affymetrix Clariom D, platform GPL23126. The deposited table has 138,745 features; these must not be described as 138,745 genes.

Publication-level timing is suitable for a progression endpoint: all post-treatment biopsies followed radiographic progression to PD-1 blockade and preceded initiation of new systemic therapy. The median progression-to-biopsy interval is 3.7 weeks, IQR 1.8–10.4. PD-1 plus chemotherapy combinations were not used in this molecular cohort. These are progression samples, not scheduled on-treatment biopsies. Individual drug regimen, exact intervals, best overall response, histology, purity, and lesion linkage remain unverified in the deposited sample metadata.

## Why the inferential gate fails

1. **Clinical crosswalk unresolved.** The original publication links [Table S2](https://pmc.ncbi.nlm.nih.gov/articles/instance/11249385/bin/NIHMS1954849-supplement-2.xlsx), “Overview of the samples analyzed in the study.” The public link returned an HTML browser download interstitial during this audit; the publisher endpoint returned HTTP 403, and Europe PMC's supplementary-file API reports that this article is not open access. Europe PMC metadata confirms `isOpenAccess=N` and that supplements exist. Ordinary preprint supplement/source-XML requests returned HTTP 403; its public API exposed metadata but no clinical table. The ETH institutional mirror returned HTTP 429, so no further requests were made to that host. No clinical workbook was recovered from these inspected public endpoints. This is an access/readiness limitation, not evidence that Table S2 lacks the required fields or that the workbook is globally unavailable. No author was contacted and no browser challenge was solved. A companion supplement request also returned only an interstitial; no published effects workbook was obtained or inspected.
2. **Anatomic site confounding.** Nine of thirteen pairs change organ/site. Four pairs share only a broad label (lung, adrenal, or lymph node); this does not verify the same lesion, exact location, or equivalent cellular composition. Pairing controls stable patient attributes but cannot remove these time-varying differences.
3. **Processing provenance unresolved.** The publication and deposited sample processing text say arrays were processed independently in two batches. The study then used ComBat and LOESS. GEO explicitly states that deposited CHP values have SST-RMA alone and final normalized gene expression values can be provided on request. No confirmed per-sample batch assignment is present in the parsed header. Filename groups are recorded solely as filename provenance and must not be relabelled as verified batches or used for an unsupported correction. Patient 12 changes filename group despite matching broad site; patient 26 also changes group.
4. **Feature annotation readiness.** A complete verified feature-to-gene mapping was not established in this audit. Published selection of the highest-coefficient-of-variation measurement is a study method, not an automatically approved mapping rule for a predefined-program pilot.
5. **Inferential resolution after a conservative site restriction.** Even if all four broad-site-matched pairs eventually pass the other criteria, an exact one-sided sign-flip test on four independent nonzero paired changes has minimum attainable p = 1/16 = 0.0625. It cannot meet raw p < 0.05, before correction across programs and directions. This mathematical limit must not be rescued by switching tests after seeing effects. It is not an observed biological p-value.

The count of zero verified strict-AR pairs means eligibility remains unknown; it does not mean all thirteen fail the clinical definition. A sufficiently documented future cohort could support a different prespecified analysis. This audit does not assume that site adjustment, rank-based scoring, or batch correction can repair unresolved confounding.

## Permitted conclusion and future unlock

The defensible current statement is: “Public expression profiles contain thirteen apparent pretreatment/progression patient pairs, but clinical eligibility, processing provenance, and sampling-site differences prevent an inferential acquired-resistance convergence test in the current submission.” This is a feasibility finding. No statement about recurrent program changes, genomic conservation, selection, resistance specificity, causality, or absence of a biological effect follows.

Future use requires a verified clinical specimen crosswalk; confirmed sample processing batches or the publicly documented final normalized matrix; complete feature annotation; a prespecified response to site and composition differences; and adequate independent patients under the chosen inference. No longitudinal durable-responder comparator was verified. Its absence would limit resistance-specific enrichment, but it is not itself a reason to reject a well-controlled recurrence analysis. Publication WES and dbGaP phs002834.v1.p1 are separate genomic inputs and were not retrieved or analyzed here.

The original study already reports IFN-related expression findings. A future six-program pilot would be literature-informed; it should not be presented as a blinded de novo discovery. Known-program recurrence alone also would not establish a newly coordinated network MSI.

## Reproduction and preserved artifacts

Run `python pilot/cohorts/nsclc/qc_manifest.py --retrieve` to retrieve the pinned processed matrix and rebuild the metadata-derived outputs with the Python standard library. Run without `--retrieve` to reuse the verified local matrix. The script validates the checksum, patient/timepoint labels, uniqueness, complete pairs, and site counts; it stops before the expression table. `samples.tsv`, `pairs.tsv`, `gate.json`, and `sources.json` retain unknowns and source provenance. Raw retrievals are excluded from version control by the local `.gitignore`. Existing project inputs, manifests, and the October 14 audit were not changed.
