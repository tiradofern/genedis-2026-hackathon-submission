#!/usr/bin/env python3
"""GSE65185 source/metadata and numeric integrity audit; no program effects.

Run from any directory. Public raw/source downloads stay ignored. This script
does not repair conflicting source annotations or substitute biopsy numbering
for collection dates. Existing source files are checksum-verified on reuse.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import gzip
import hashlib
import json
import math
import re
import urllib.request
from collections import Counter, defaultdict
from pathlib import Path

BASE = Path(__file__).resolve().parent
URLS = {
    "sources/GSE65185_family.soft.gz":
        "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE65nnn/GSE65185/soft/GSE65185_family.soft.gz",
    "raw/GSE65185_CuffnormFPKM.txt.gz":
        "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE65nnn/GSE65185/suppl/GSE65185_CuffnormFPKM.txt.gz",
}


def write_json(name, obj):
    (BASE / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")


def write_tsv(name, rows):
    with (BASE / name).open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]), delimiter="\t")
        w.writeheader()
        w.writerows(rows)


def fetch_sources():
    manifest_path = BASE / "source_manifest.json"
    previous = json.loads(manifest_path.read_text()) if manifest_path.exists() else []
    by_path = {row["path"]: row for row in previous}
    for rel, url in URLS.items():
        path = BASE / rel
        if path.exists():
            content = path.read_bytes()
            old = by_path.get(rel)
            if old and hashlib.sha256(content).hexdigest() != old["sha256"]:
                raise ValueError(f"Source checksum changed: {rel}")
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            content = urllib.request.urlopen(url, timeout=60).read()
            if not content.startswith(b"\x1f\x8b"):
                raise ValueError(f"Expected gzip; did not save invalid response: {url}")
            old = by_path.get(rel)
            if old and hashlib.sha256(content).hexdigest() != old["sha256"]:
                raise ValueError(f"Downloaded source differs from pinned checksum: {rel}")
            path.write_bytes(content)
        if rel not in by_path:
            by_path[rel] = {
                "path": rel, "url": url, "bytes": len(content),
                "sha256": hashlib.sha256(content).hexdigest(),
                "retrieved_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                "valid_source": True,
            }
    write_json("source_manifest.json", list(by_path.values()))


def sample_records():
    path = BASE / "sources/GSE65185_family.soft.gz"
    content = gzip.decompress(path.read_bytes()).decode()
    records = []
    for block in content.split("^SAMPLE = ")[1:]:
        lines = block.splitlines()
        fields = defaultdict(list)
        for line in lines[1:]:
            if line.startswith("!Sample_") and " = " in line:
                key, value = line.split(" = ", 1)
                fields[key.removeprefix("!Sample_")].append(value)
        title = fields["title"][0]
        description = " | ".join(fields["description"])
        characteristics = {}
        for value in fields["characteristics_ch1"]:
            key, val = value.split(": ", 1)
            characteristics[key] = val
        title_patient = re.match(r"Pt(\d+)-", title)
        description_patient = re.search(r"Patient (\d+) melanoma", description)
        patient = f"Pt{title_patient.group(1)}" if title_patient else ""
        patient_desc = f"Pt{description_patient.group(1)}" if description_patient else ""
        identity_conflict = bool(patient and patient_desc and patient != patient_desc)
        tx = characteristics.get("mapki treatment", "")
        treatment_conflict = tx == "BRAFi" and "post BRAFi+MEKi resistance" in description
        records.append({
            "gsm": lines[0], "title": title, "patient_title": patient,
            "patient_description": patient_desc,
            "specimen_class": "patient_tumor" if patient else "cell_line",
            "state": "pretreatment" if title.endswith("-baseline") else
                     ("resistant" if characteristics.get("mapki sensitivity") == "resistant" else "experimental_control"),
            "mapki_treatment": tx,
            "sensitivity_label": characteristics.get("mapki sensitivity", ""),
            "description": description,
            "identity_conflict": identity_conflict,
            "treatment_conflict": treatment_conflict,
            "anatomic_site": "unknown", "collection_date": "unknown",
            "best_response": "unknown", "processing_batch": "unknown",
            "source_name": " | ".join(fields["source_name_ch1"]),
            "genome_build": "hg19" if any("hg19" in s for s in fields["data_processing"]) else "unknown",
            "processing": " | ".join(fields["data_processing"]),
        })
    return records


def matrix_audit(records):
    path = BASE / "raw/GSE65185_CuffnormFPKM.txt.gz"
    with gzip.open(path, "rt") as f:
        reader = csv.reader((s for s in f if s.strip()), delimiter="\t")
        header = next(reader)
        samples = header[1:]
        duplicate_sample_names = [k for k, v in Counter(samples).items() if v > 1]
        genes = []
        malformed, nonnumeric, nonfinite, negative, values = 0, 0, 0, 0, 0
        for row in reader:
            if len(row) != len(header):
                malformed += 1
                continue
            genes.append(row[0])
            for text in row[1:]:
                values += 1
                try:
                    value = float(text)
                except ValueError:
                    nonnumeric += 1
                    continue
                nonfinite += not math.isfinite(value)
                negative += value < 0
    # These exact source aliases are reported, not treated as clinical fixes.
    aliases = {"Pt22-baseline": "Pt22-baseline1"}
    for rec in records:
        title = rec["title"]
        candidate = aliases.get(title, title.replace("-DDP", "-DD-DP"))
        rec["matrix_column"] = candidate if candidate in samples else "unresolved"
        rec["matrix_alias_rule"] = (
            "explicit_Pt22_baseline1_alias_clinical_identity_unverified" if title in aliases else
            ("DDP_to_DD-DP_orthography_only" if "-DDP" in title else "exact")
        )
    return {
        "gene_rows": len(genes), "sample_columns": len(samples),
        "numeric_values_examined": values, "malformed_rows": malformed,
        "nonnumeric_values": nonnumeric, "nonfinite_values": nonfinite,
        "negative_values": negative,
        "duplicate_gene_labels": [k for k, v in Counter(genes).items() if v > 1],
        "duplicate_sample_names": duplicate_sample_names,
        "unresolved_sample_columns": [r["gsm"] for r in records if r["matrix_column"] == "unresolved"],
        "units": "GEO Cuffnorm FPKM; not counts; no additional transformation performed",
        "effect_analysis_performed": False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--download", action="store_true")
    args = parser.parse_args()
    if args.download:
        fetch_sources()
    records = sample_records()
    qc = matrix_audit(records)
    write_tsv("sample_metadata.tsv", records)
    patients = defaultdict(list)
    for rec in records:
        if rec["patient_title"]:
            patients[rec["patient_title"]].append(rec)
    rows = []
    for patient in sorted(patients, key=lambda p: int(p[2:])):
        pre = [r for r in patients[patient] if r["state"] == "pretreatment"]
        post = [r for r in patients[patient] if r["state"] == "resistant"]
        reasons = ["site_unknown", "collection_dates_unknown", "processing_batch_unknown",
                   "sample_level_best_response_and_regimen_timing_unverified"]
        if not pre:
            reasons.append("no_untreated_baseline")
        if any(r["identity_conflict"] for r in patients[patient]):
            reasons.append("title_description_patient_identity_conflict")
        if any(r["treatment_conflict"] for r in patients[patient]):
            reasons.append("treatment_annotation_conflict")
        rows.append({
            "patient_title": patient,
            "baseline_gsms": ";".join(r["gsm"] for r in pre),
            "resistant_gsms": ";".join(r["gsm"] for r in post),
            "resistant_specimen_count": len(post),
            "candidate_paired_by_title": len(pre) == 1 and len(post) >= 1,
            "inferential_eligibility": "blocked",
            "block_reasons": ";".join(reasons),
            "selected_post_gsm": "none; dates and clinical crosswalk unresolved",
        })
    write_tsv("patient_pair_candidates.tsv", rows)
    write_json("matrix_integrity.json", qc)
    write_json("gate.json", {
        "accession": "GSE65185", "gate_version": "2026-10-31-metadata-v1",
        "verdict": "DESCRIPTIVE_FEASIBILITY_ONLY",
        "inferential_go": False,
        "permitted_now": ["metadata feasibility reporting", "numeric source integrity QC"],
        "not_permitted_without_resolving_gate": [
            "primary paired program inference", "cross-cancer convergence claim",
            "resistance specificity or causal mechanism claim"],
        "counts": {
            "geo_samples": len(records), "patient_tumor_specimens": sum(bool(r["patient_title"]) for r in records),
            "cell_line_samples": sum(not bool(r["patient_title"]) for r in records),
            "distinct_patient_title_ids": len(patients),
            "pretreatment_tumor_specimens": sum(r["state"] == "pretreatment" for r in records),
            "resistant_tumor_specimens": sum(r["state"] == "resistant" and bool(r["patient_title"]) for r in records),
            "candidate_baseline_bearing_patients_maximum": sum(r["candidate_paired_by_title"] for r in rows),
            "patients_adjudicated_ready_for_inference": 0,
        },
        "zero_ready_interpretation": "Zero patients are fully adjudicated ready in this audit; this is not proof that no truly eligible patients exist.",
        "independence": "Patient is unit; multiple lesions/biopsies are not independent patients.",
        "resistance": "Article describes acquired MAPKi resistance; GEO records label clinical post biopsies resistant. Individual clinical best response/time/site crosswalk remains unverified.",
        "hard_blocks": [
            "Anatomic biopsy sites not found in inspected deposited sample records; site-changing effects cannot be excluded.",
            "Individual response duration, collection dates, and intervening therapies not found in inspected records.",
            "Explicit processing batches not found in inspected records; a uniform protocol does not establish time/batch separability.",
            "Pt22 post sample titles conflict with patient 21 in descriptions; Pt20-DP1 treatment field conflicts with description.",
            "Original Table S1 identified but download returned challenge/interstitial, not an XLS workbook.",
            "Article says patients 10-14 used microarrays, whereas GEO includes Pt10 in the Cuffnorm FPKM matrix with RNA-seq metadata; measurement provenance needs reconciliation.",
        ],
        "preserved_exclusions": {
            "Pt21": "All three tumors already resistant; BRAFi-resistant surrogate is not untreated baseline.",
            "cell_lines": "Eight experimental samples excluded from patient cohort.",
        },
        "effects_tested": False,
        "molecular_result": "UNTESTED_INCONCLUSIVE; failed readiness is not a negative molecular-program result.",
        "source_references": [
            "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE65185",
            "https://doi.org/10.1016/j.cell.2015.07.061",
            "https://pmc.ncbi.nlm.nih.gov/articles/PMC4821508/",
        ],
    })
    print(json.dumps({"matrix": qc, "patient_title_ids": len(patients), "verdict": "DESCRIPTIVE_FEASIBILITY_ONLY"}, indent=2))


if __name__ == "__main__":
    main()
