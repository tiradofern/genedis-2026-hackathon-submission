# GSE65185: fresh eligibility and source audit

**Decision: descriptive feasibility only; no inferential go.** No Hallmark scores,
paired effects, hypothesis tests, or biological discovery results were computed.
This decision concerns what the currently verified inputs can support. It does
not establish that the original study is invalid or that no treatment-associated
program exists.

## Verified observations

- The public GEO SOFT record contains 70 profiles: 62 clinical tumor specimens
  and eight experimental cell-line profiles. Cell lines are excluded from the
  clinical candidate cohort.
- Clinical sample titles contain 19 patient IDs, 18 untreated-baseline profiles,
  and 44 resistant tumor profiles. Eighteen baseline-bearing patients is an
  **upper bound on candidate paired patients**, not an eligible analysis count.
- Hugo et al. describe acquired resistance to BRAFi or BRAFi+MEKi in melanoma,
  using baseline and disease-progressive specimens. These are not scheduled
  on-treatment biopsies. Source-level acquired-resistance labeling does not
  replace individual response-duration and exposure verification.
- Patient 21 has no untreated baseline in this accession. `GSM1588905` is
  explicitly a BRAFi-resistant surrogate reference for combination-resistant
  samples. It cannot be recoded as a treatment-naive baseline.
- The deposited processed matrix has 25,268 unique gene labels and 70 unique
  columns. All 1,768,760 examined values are numeric, finite and nonnegative;
  no malformed rows were found. These checks establish readable inputs, not
  biological validity or homogeneous measurement units.
- Metadata describe TopHat2/Cuffnorm and hg19. The file is labeled FPKM, not
  raw counts. No count-based model, pooled normalization, or extra logarithm
  was applied.

## Unresolved evidence that blocks primary inference

1. **Biopsy site:** deposited sample records do not supply anatomic sites. A
   change of sampled lesion or organ can produce molecular differences. A
   same-site subset cannot currently be identified.
2. **Clinical chronology:** no individual best response, response duration,
   collection date, or intervening-therapy crosswalk was verified. The ordinal
   "1st biopsy" is not a dated clinical chronology. We did not choose a first
   progression specimen based only on this ordinal.
3. **Processing:** explicit processing batches are absent. Uniform extraction
   wording does not demonstrate that technical processing and time point are
   separable.
4. **Identity and exposure conflicts:** the three `Pt22-DDP*` titles identify
   patient 22 while their descriptions identify patient 21. `Pt20-DP1` is
   annotated BRAFi in its treatment field but post-BRAFi+MEKi resistance in its
   description. Both alternatives are preserved; neither was silently fixed.
5. **Platform provenance:** the original article's Experimental Procedures
   state that patients 10–14 used microarrays. GEO nevertheless includes ten
   `Pt10-*` columns within its Cuffnorm FPKM file, with RNA-seq sample metadata.
   This is an unresolved source discrepancy, not evidence that we know which
   measurement is correct. The common-platform assumption needs reconciliation.
6. **Original clinical supplement:** Table S1 was identified as
   `NIHMS716531-supplement-10.xls`. Public download attempts returned browser
   challenge/interstitial HTML rather than a workbook. Publisher assets returned
   HTTP 403. HTML responses were marked invalid and were not parsed as tables.
   No author was contacted and no access controls were changed.

Missing durable-responder biopsies would limit **resistance specificity**, but
would not by itself invalidate recurrence or paired-change analyses. The blocks
above concern the integrity and interpretation of the paired measurements.

## Preserved artifacts and reproduction

`sample_metadata.tsv` preserves every GEO profile, clinical versus experimental
status, source text, conflicts, unknown fields, and matrix-column crosswalk.
`patient_pair_candidates.tsv` preserves all 19 title-defined patient groups and
candidate baseline/progression profiles without treating repeated lesions as
independent patients. `matrix_integrity.json` records the complete numeric check;
`gate.json` is the machine-readable decision. `source_manifest.json` records
retrieval URLs, SHA256, byte counts, and invalid-response flags.

Raw/source blobs are ignored and excluded from the distributable archive.
Retrieve the two public GEO inputs and rerun the audit with:

```bash
python pilot/cohorts/melanoma/audit_metadata.py --download
```

Without `--download`, the same command audits cached sources. Source checksum
changes abort reuse or retrieval. The script writes only this audit directory;
it does not fit molecular programs or alter existing project artifacts.

## Consequence for tonight

Retain GSE65185 as a documented feasibility candidate. Do not report a
two-cohort convergence result or a single-cohort inferential paired-program
result unless the clinical/site/processing and platform discrepancies are
resolved under the frozen protocol. A future analysis should fix the choice
of one eligible resistance biopsy per patient before program scoring.

## Primary sources

- [GEO GSE65185](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE65185),
  downloaded SOFT metadata and deposited `GSE65185_CuffnormFPKM.txt.gz`.
- Hugo W et al. *Non-genomic and Immune Evolution of Melanoma Acquiring MAPKi
  Resistance*. Cell (2015).
  [DOI:10.1016/j.cell.2015.07.061](https://doi.org/10.1016/j.cell.2015.07.061),
  [PMCID:PMC4821508](https://pmc.ncbi.nlm.nih.gov/articles/PMC4821508/),
  Results sections on genomic/transcriptomic landscapes and Experimental
  Procedures: Analyses of Tumor Specimens; Genomic and Transcriptomic Analysis.

Audit date: October 31, 2026. Independent reproduction of the published
biological conclusions was not attempted.
