# Longitudinal pilot: cohort-readiness decision

**Release decision: stop inferential pilot work and retain the existing NSCLC
project plus this reproducible feasibility assessment.** Neither candidate is
fully adjudicated ready for the frozen paired-program analysis. No primary
program scores, effects, significance tests, or cross-cancer convergence results
were generated. This is an **inconclusive readiness outcome**, not a negative
molecular discovery result.

The frozen question remains useful: *Do predefined molecular programs show
recurring changes between pretreatment and acquired-resistance biopsies in two
independently collected cancer cohorts?* Readiness was evaluated before examining
those effects. The frozen protocol and its six Hallmark programs are preserved
in [the protocol](../PROTOCOL_2026-10-31.md).

## Audited evidence

| Requirement | Melanoma GSE65185 | NSCLC GSE248249 |
|---|---|---|
| Publication | Hugo et al., Cell 2015; DOI 10.1016/j.cell.2015.07.061 | Memon et al., Cancer Cell 2024; DOI 10.1016/j.ccell.2023.12.013 |
| Selective pressure | BRAFi or BRAFi+MEKi | PD-(L)1 blockade |
| Deposited profiles | 70: 62 clinical tumors plus 8 cell-line profiles | 42 clinical tumor profiles |
| Independent-patient accounting | 19 title-defined IDs; identity conflict prevents treating all titles as verified identities | 29 source patient IDs |
| Candidate baseline-bearing patients | At most 18 | At most 13 |
| Resistance evidence | Article describes acquired resistance; post GEO samples labeled resistant | Article molecular subset includes CR/PR and SD; strict clinical AR crosswalk must be verified individually |
| Timing | Pretreatment versus disease progression at study level; individual dates and intervening therapies unresolved | Baseline versus progression; post biopsy before next systemic therapy at study level; individual eligibility crosswalk unresolved |
| Same-site pairing | Not adjudicable from inspected sample metadata | Four candidate pairs have same broad site: 01, 12, 19, 23 |
| Primary accessible measurement | Deposited Cuffnorm FPKM expression; Pt10 platform discrepancy unresolved | Clariom D SST-RMA expression; final authors' ComBat/LOESS values request-only |
| Explicit processing-batch crosswalk | Not found in inspected deposited records | Not found in inspected deposited records |
| Inferential decision | No go | No go |

Candidate-pair counts are upper bounds before full clinical and technical
adjudication. Repeated progression biopsies are not additional independent
patients. Tumor-normal pairs, cell-line experiments and scheduled on-treatment
biopsies are not substituted for baseline–acquired-resistance patient pairs.

## Why the gates remain closed

For **GSE65185**, three post-biopsy titles `Pt22-DDP1`, `Pt22-DDP2`, and
`Pt22-DDP3` identify patient 22, but all corresponding descriptions identify
patient 21. The `Pt20-DP1` treatment field and description disagree about the
therapy. Patient 21 has only resistant tumors, including the explicitly
BRAFi-resistant surrogate reference `GSM1588905`; none is a naive baseline.
Eight cell-line profiles are excluded from the clinical cohort. The article
states that patients 10–14 used microarrays, whereas deposited Pt10 profiles
carry RNA-seq/Cuffnorm annotations. These conflicts require source reconciliation,
not automatic repair. Biopsy sites and explicit batches were not found in
inspected GEO records. No post biopsy was selected merely because its ordinal
label was "1".

For **GSE248249**, the article's clinical AR definition requires prior CR/PR,
while its molecular analysis also includes SD patients. Group-level counts
cannot identify which of the 13 candidate paired patients meet the frozen
definition. Broad biopsy-site matching exists for only four pairs, and matching
organ labels alone does not prove the same lesion. Explicit technical batches
cannot be inferred from filenames. Public deposited processing and the authors'
final adjusted values are distinguished; absence of the latter alone is not the
sole veto. Unresolved clinical eligibility, site confounding and processing are
the material blocks.

Even under ideal measurements, four independent pairs give a minimum exact
one-sided sign-flip probability of **1/16 = 0.0625**, before correcting the
frozen multiple-testing family. The subgroup cannot support a positive primary
inferential claim under that protocol. Eligibility and correction were not
relaxed to circumvent this limit.

## Source retrieval and verification

Original articles and deposited sample-level records were inspected. Public GEO
processed data were retrieved for integrity/metadata checks. The melanoma file
contains 25,268 unique gene labels and 70 columns, with all 1,768,760 values
numeric, finite and nonnegative. The NSCLC processed-file SHA256 matches the
preserved historical audit; its current audit extracted metadata without
computing expression effects. Numeric readability does not establish clinical
eligibility, batch comparability or biological validity.

The original clinical supplements were identified, but were **not recovered as
valid workbooks in this audit**. Ordinary PMC supplementary links returned
browser challenge/interstitial HTML; file signatures were checked. EuropePMC's
ordinary supplementary API reports that these articles are not open access for
its supplementary-file service. Candidate publisher endpoints returned access
errors. These observations describe inspected endpoints; they do not establish
that no usable public copy or clinical metadata exist anywhere. No access
challenge was solved, author contacted, or sharing permission changed.

## Claims this assessment supports

- Two biologically relevant published longitudinal candidates were audited with
  patient/sample distinctions, exact source conflicts and explicit missingness.
- The public inputs require additional clinical, site and processing verification
  before a defensible paired-program inference.
- The immediate cross-cancer pilot was stopped before testing primary effects.
  No evidence for or against recurrent program changes was generated.
- Missing durable-responder cohorts would limit resistance-specific enrichment;
  it is not by itself a reason to reject recurrence among resistant tumors.

Expression recurrence would be a transcriptomic observation. It would not
establish genomic conservation, selective acquisition, cancer-cell-intrinsic
resistance or a causal mechanism. Six predefined pathway scores alone would
also not establish a novel coordinated Molecular Survival Island. Independent
coordination tests and cross-cohort replication remain required.

## Auditable artifacts

- [Melanoma QC summary](melanoma/QC_SUMMARY.md),
  [gate](melanoma/gate.json),
  [all sample records](melanoma/sample_metadata.tsv),
  [candidate patient groups](melanoma/patient_pair_candidates.tsv),
  [matrix integrity](melanoma/matrix_integrity.json),
  [source provenance](melanoma/source_manifest.json),
  [supplement endpoint checks](melanoma/supplement_retrieval_attempts.json).
- [NSCLC gate](nsclc/gate.json),
  [sample manifest](nsclc/samples.tsv),
  [candidate-pair manifest](nsclc/pairs.tsv).

Source/raw third-party blobs are ignored and excluded from the distributable
archive. Small curated public metadata, source URLs, checksums, parsers and gates
are retained. Existing project artifacts and negative findings remain intact.

## Reopening the pilot after the submission

Recover and reconcile the original clinical crosswalks; verify patient identity,
best response, response duration, index regimen, biopsy dates, intervening
therapy, site and processing batch. Resolve Pt10 modality and Pt20/Pt22 source
contradictions. Fix a clinically defensible per-patient specimen rule before
scoring. Assess sample size against the unchanged testing family and simulate
precision using declared assumptions. If only one cohort becomes adequate,
report a single-cohort paired study; cross-cancer recurrence still requires an
independent second context. Responder comparators and functional perturbations
are later, separately justified evidence levels.
