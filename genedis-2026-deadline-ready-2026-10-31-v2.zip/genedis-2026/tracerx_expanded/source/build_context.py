"""Build context-only CNA/WGD exports after the independently frozen policy.

No CNA enters mutation ancestry, an ordered model, a gene-pair test or a branch.
"""
from __future__ import annotations
import csv
import hashlib
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / "tracerx_expanded/source"
OUT = HERE / "output"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))

def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))

def finite(value):
    return value not in (None, "", "NA") and math.isfinite(float(value))

def measured(value):
    # Infinite log ratios are explicit source values (e.g. log2 of zero copy).
    # Retain them literally; do not turn a source measurement into a missing assay.
    return value not in (None, "", "NA", "NaN") and not math.isnan(float(value))

def sample_key(value):
    """Normalize only the observed region separator, preserving every prefix."""
    return re.sub(r"([.-])((?:R|LN)\d+)$", r".\2", value)

def classify_state(reported, measured):
    return "reported" if reported else "not_reported" if measured else "assay_unavailable"

def segment_key(row):
    return ":".join(row[key] for key in ("tumour_id", "chr", "startpos", "endpos"))

def aggregate(events, patients, role):
    selected = [patient for patient in patients if patient["role"] == role]
    result = []
    for event in events:
        states = Counter(patient["event_states"][event["id"]] for patient in selected)
        measured = sum(patient["event_assay"][event["id"]]["any_regional_measurement"] for patient in selected)
        complete = sum(patient["event_assay"][event["id"]]["all_primary_regions_measured"] for patient in selected)
        result.append({"id": event["id"], "eligible": len(selected), "reported": states["reported"],
                       "not_reported": states["not_reported"], "assay_unavailable": states["assay_unavailable"],
                       "source_measurement_present": measured, "all_primary_regions_measured": complete,
                       "reported_without_measurement": sum(patient["event_states"][event["id"]] == "reported" and
                           not patient["event_assay"][event["id"]]["any_regional_measurement"] for patient in selected)})
    return result

def verify_frozen():
    freeze = read_json(ROOT / "tracerx_expanded/config_freeze_2026-10-18.json")
    for entry in freeze["configurations"]:
        if digest(ROOT / entry["path"]) != entry["sha256"]:
            raise ValueError("Frozen config changed")
    for name, key in (("source_manifest.json", "source_manifest_sha256"),
                      ("core_archive_manifest.json", "core_archive_manifest_sha256")):
        if digest(HERE / name) != freeze[key]:
            raise ValueError("Frozen source manifest changed")
    for item in read_json(HERE / "source_manifest.json")["files"]:
        if digest(HERE / "raw" / item["filename"]) != item["sha256"]:
            raise ValueError("Source file changed: " + item["filename"])
    core = read_json(HERE / "core_archive_manifest.json")
    if digest(HERE / "raw/figurecode.zip") != core["sha256"]:
        raise ValueError("Core archive changed")
    for item in core["members"]:
        if digest(HERE / "raw/core" / item["filename"]) != item["sha256"]:
            raise ValueError("Core archive member changed")
    return freeze

def build():
    freeze = verify_frozen()
    with (HERE / "raw/cn_drivers.csv").open(encoding="utf-8", newline="") as handle:
        panel = list(csv.DictReader(handle))
    if len(panel) != 67 or len({item["gene"] for item in panel}) != 67:
        raise ValueError("Source panel must have exactly67 unique genes")
    events = [{"id": ("AMP:" if item["type"] == "OG" else "HOMDEL:") + item["gene"],
               "label": item["gene"] + (" amplification" if item["type"] == "OG" else " homozygous deletion"),
               "gene": item["gene"], "event_type": "amplification" if item["type"] == "OG" else "homozygous_deletion",
               "source_consequence": "Amp" if item["type"] == "OG" else "Homdel", "source_panel_role": item["type"],
               "unit_definition": "Source-reported tumour/gene/consequence presence; may share genomic segment with other calls",
               "order_status": "presence_only_no_comparable_branch_placement"} for item in panel]
    events.append({"id": "WGD", "label": "Whole-genome doubling", "gene": None, "event_type": "whole_genome_doubling",
                   "source_consequence": "GD", "source_panel_role": None,
                   "unit_definition": "At least one source GD call; multiple raw events and coarse labels retained separately",
                   "order_status": "context_only_no_comparable_branch_placement"})
    by_key = {(item["gene"], item["source_consequence"]): item["id"] for item in events if item["gene"]}
    calls = rows(HERE / "raw/20221109_TRACERx421_gd_driver_signature_events.tsv")
    selected_calls = defaultdict(list)
    excluded = Counter()
    source_duplicate = Counter(tuple(row.items()) for row in calls)
    duplicate_by_type = {kind: sum(n - 1 for record, n in source_duplicate.items() if n > 1 and dict(record)["type"] == kind)
                         for kind in sorted({row["type"] for row in calls})}
    for index, row in enumerate(calls, start=2):
        if row["type"] != "copy_number" or row["is_driver"] != "TRUE":
            continue
        identifier = "WGD" if row["gene"] == "WGD" and row["consequence"] == "GD" else by_key.get((row["gene"], row["consequence"]))
        if identifier is None:
            excluded[row["consequence"] + ":outside_panel_or_role"] += 1
            continue
        selected_calls[row["tumour_id"]].append({"event_id": identifier, "source_tsv_line": index, **row})
    gene_values = defaultdict(list)
    for row in rows(OUT / "source_regional_gene_copy_number.tsv"):
        gene_values[row["tumour_id_mphase_cruk"]].append(row)
    regional = defaultdict(list)
    for row in rows(OUT / "source_regional_assay.tsv"):
        regional[row["tumour_id"]].append(row)
    wgd_tumours = {row["tumour_id"]: row for row in rows(OUT / "source_wgd_tumours.tsv")}
    if len(wgd_tumours) != len(rows(OUT / "source_wgd_tumours.tsv")):
        raise ValueError("Duplicate source WGD tumour record")
    wgd_regions = defaultdict(list)
    for row in rows(OUT / "source_wgd_regions.tsv"):
        wgd_regions[row["tumour_id"]].append(row)
    segments = defaultdict(dict)
    overlap_rows = rows(OUT / "source_panel_segment_overlaps.tsv")
    for row in overlap_rows:
        key = segment_key(row)
        unit = segments[row["tumour_id"]].setdefault(key, {"id": key,
            "chromosome": row["chr"], "start": int(row["startpos"]), "end": int(row["endpos"]),
            "genome_build": "hg19", "overlapping_panel_genes": set(), "regional_source_rows": {}})
        unit["overlapping_panel_genes"].add(row["panel_gene"])
        sample = row["sample"]
        values = {key: row[key] for key in row if key != "panel_gene"}
        previous = unit["regional_source_rows"].setdefault(sample, values)
        if previous != values:
            raise ValueError("Conflicting source values for same tumour/segment/sample")
    annotation_rows = rows(OUT / "panel_annotations.tsv")
    annotation_genes = {row["gene_name"] for row in annotation_rows}
    summaries = {}
    artifacts = {}
    for cohort in ("luad", "lusc"):
        config = read_json(ROOT / f"configs/tracerx_expanded_{cohort}_v0_1.json")
        source = ROOT / config["baseline"]["source_path"]
        if digest(source) != config["baseline"]["source_sha256"]:
            raise ValueError("Frozen cohort changed")
        original = read_json(source)
        # Read original engine inputs solely to recover original roles; no model result chooses context.
        engine_path = ROOT / ("tracerx_routes/inference/output/engine_inputs.json" if cohort == "luad" else "tracerx_routes/inference/output/lusc/engine_inputs.json")
        roles = {item["id"]: item["role"] for item in read_json(engine_path)["patients"]}
        if set(roles) != {item["patient_id"] for item in original["patients"]}:
            raise ValueError("Original role/cohort mismatch")
        patients = []
        for person in original["patients"]:
            tid, pid = person["tumour_id"], person["patient_id"]
            primary = {sample_key(value) for value in person["region_ids"] if re.search(r"[.-]R\d+$", value)}
            frozen_regions = {sample_key(value) for value in person["region_ids"]}
            if len(primary) != person["n_primary_regions"]:
                raise ValueError("Primary-region parsing disagrees with frozen source")
            source_calls = selected_calls.get(tid, [])
            if any(row["patient_id"] != pid for row in source_calls):
                raise ValueError("Source patient/tumour mismatch")
            reported = {row["event_id"] for row in source_calls}
            states, assays = {}, {}
            for event in events:
                if event["id"] == "WGD":
                    measured_regions = {sample_key(pid + "_" + row["sample_id"]) for row in wgd_regions.get(tid, [])}
                    available = tid in wgd_tumours
                else:
                    measured_regions = {sample_key(row["sample_name_cruk"]) for row in gene_values.get(tid, []) if measured(row.get(event["gene"]))}
                    available = bool(measured_regions)
                states[event["id"]] = classify_state(event["id"] in reported, available)
                assays[event["id"]] = {"any_regional_measurement": available,
                    "primary_regions_expected": len(primary), "primary_regions_measured": len(primary & measured_regions),
                    "all_primary_regions_measured": primary <= measured_regions, "source_regions_measured": sorted(measured_regions)}
            units = []
            for value in segments.get(tid, {}).values():
                units.append({**value, "overlapping_panel_genes": sorted(value["overlapping_panel_genes"]),
                              "regional_source_rows": list(value["regional_source_rows"].values())})
            assay_rows = regional.get(tid, [])
            if any(row["patient_id"] != pid for row in assay_rows):
                raise ValueError("Regional assay patient/tumour mismatch")
            regional_measured = {sample_key(row["sample"]) for row in assay_rows}
            segment_target = OUT / cohort / "segments" / (tid + ".json")
            segment_target.parent.mkdir(parents=True, exist_ok=True)
            segment_target.write_text(json.dumps({"tumour_id": tid, "shared_segment_units": units}, indent=2) + "\n", encoding="utf-8")
            segment_summary = {"coordinate_units": len(units),
                "units_overlapping_multiple_panel_genes": sum(len(unit["overlapping_panel_genes"]) > 1 for unit in units),
                "regional_rows": sum(len(unit["regional_source_rows"]) for unit in units),
                "path": segment_target.relative_to(ROOT).as_posix(), "sha256": digest(segment_target),
                "bytes": segment_target.stat().st_size,
                "interpretation": "Shared source coordinates with panel-overlap location annotations; not verified causal linkage of each curated CNA call."}
            patients.append({"patient_id": pid, "tumour_id": tid, "role": roles[pid], "histology": cohort.upper(),
                "primary_regions_expected": sorted(primary), "primary_regions_with_SCNA": sorted(primary & regional_measured),
                "all_primary_regions_with_SCNA": primary <= regional_measured,
                "frozen_tree_regions": sorted(frozen_regions),
                "source_SCNA_regions_not_in_frozen_tree": sorted(regional_measured - frozen_regions),
                "source_call_scope": "Tumour-level source call; the event table does not identify its exact supporting regions or mutation-tree branch. Additional source regions and raw labels remain explicit context.",
                "regional_assay": assay_rows, "source_calls": source_calls, "event_states": states, "event_assay": assays,
                "source_wgd_tumour": wgd_tumours.get(tid), "source_wgd_regions": wgd_regions.get(tid, []),
                "shared_segment_artifact": segment_summary, "ordered_CNA_events": []})
        catalog = []
        for event in events:
            catalog.append({**event, **{role: next(item for item in aggregate([event], patients, role) if item["id"] == event["id"])
                                      for role in ("training", "evaluation")}})
        coverage = {role: {"patients": sum(p["role"] == role for p in patients),
            "any_primary_region_with_SCNA": sum(p["role"] == role and bool(p["primary_regions_with_SCNA"]) for p in patients),
            "all_primary_regions_with_SCNA": sum(p["role"] == role and p["all_primary_regions_with_SCNA"] for p in patients),
            "source_WGD_tumour_record": sum(p["role"] == role and p["source_wgd_tumour"] is not None for p in patients)}
            for role in ("training", "evaluation")}
        for role in ("training", "evaluation"):
            coverage[role]["patients_with_source_SCNA_regions_outside_frozen_tree"] = sum(
                p["role"] == role and bool(p["source_SCNA_regions_not_in_frozen_tree"]) for p in patients)
        provenance = {"config_path": str(Path(f"configs/tracerx_expanded_{cohort}_v0_1.json")),
            "config_sha256": digest(ROOT / f"configs/tracerx_expanded_{cohort}_v0_1.json"),
            "source_manifest_sha256": freeze["source_manifest_sha256"], "core_archive_manifest_sha256": freeze["core_archive_manifest_sha256"],
            "frozen_cohort_sha256": digest(source), "original_role_input_sha256": digest(engine_path),
            "builder_sha256": digest(Path(__file__)), "R_translator_sha256": digest(HERE / "extract_cna.R"),
            "source_record": "https://zenodo.org/records/7683605", "core_record": "https://zenodo.org/records/7822002",
            "source_terms": "Academic non-commercial use only"}
        limitations = ["Source CNA/WGD calls are context only; no comparable mutation-branch placement or ordered test.",
            "Not reported is not verified diploid, wild type, or complete locus callability.",
            "Regional sharing, coarse clonality and doubled-cluster patterns do not establish a unique event order.",
            "Genes overlapping a shared segment are location annotations, not independent steps or proof a curated call arose from that segment.",
            "No new amplification/deletion/LOH calling or later-source Del/Homdel merging."]
        payload = {"schema_version": "1.0", "histology": cohort.upper(), "patient_count": len(patients),
            "order_status": "presence_only_no_comparable_branch_placement", "events": catalog,
            "coverage": coverage, "patients": patients, "source_panel": panel, "source_panel_annotations": annotation_rows,
            "limitations": limitations, "provenance": provenance}
        target = OUT / cohort / "cna_context.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        artifacts[cohort] = {"path": target.relative_to(ROOT).as_posix(), "sha256": digest(target), "bytes": target.stat().st_size}
        summaries[cohort] = {"histology": cohort.upper(), "patients": len(patients), "coverage": coverage,
            "reported_gene_event_patient_units": sum(len({r["event_id"] for r in p["source_calls"] if r["event_id"] != "WGD"}) for p in patients),
            "shared_coordinate_units": sum(p["shared_segment_artifact"]["coordinate_units"] for p in patients),
            "unique_reported_gene_event_units_with_repeated_source_rows": sum(sum(n > 1 for e, n in Counter(
                r["event_id"] for r in p["source_calls"] if r["event_id"] != "WGD").items()) for p in patients),
            "reported_gene_event_units_with_both_raw_clonal_labels": sum(sum(len(labels) > 1 for labels in {
                e: {r["is_clonal"] for r in p["source_calls"] if r["event_id"] == e}
                for e in {r["event_id"] for r in p["source_calls"] if r["event_id"] != "WGD"}}.values()) for p in patients),
            "shared_units_overlapping_multiple_panel_genes": sum(p["shared_segment_artifact"]["units_overlapping_multiple_panel_genes"] for p in patients),
            "gene_event_patient_state_counts": dict(Counter(state for p in patients for event, state in p["event_states"].items() if event != "WGD")),
            "gene_patient_units_with_any_measurement_but_incomplete_primary_coverage": sum(
                info["any_regional_measurement"] and not info["all_primary_regions_measured"]
                for p in patients for event, info in p["event_assay"].items() if event != "WGD"),
            "reported_gene_event_units_without_gene_mean_measurement": sum(
                state == "reported" and not p["event_assay"][event]["any_regional_measurement"]
                for p in patients for event, state in p["event_states"].items() if event != "WGD"),
            "ordered_CNA_events": 0, "events": catalog, "provenance": provenance}
    audit = {"schema_version": "1.0", "source_panel_genes": 67, "panel_genes_with_source_coordinates": len(annotation_genes),
        "panel_genes_without_source_coordinates": sorted({p["gene"] for p in panel} - annotation_genes),
        "source_exact_duplicate_extra_rows": sum(n - 1 for n in source_duplicate.values() if n > 1),
        "source_exact_duplicate_extra_rows_by_type": duplicate_by_type,
        "excluded_copy_number_rows_by_reason": dict(excluded), "source_schema_counts": read_json(OUT / "schema_audit.json"),
        "cohorts": summaries, "artifacts": artifacts,
        "branch_mapping_audit": "No comparable CNA-to-mutation-tree branch map; CCF best-fit heuristic audited but not executed.",
        "new_CNA_threshold_calls": False, "CNA_hypothesis_tests": False}
    (HERE / "cna_source_audit.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: {"patients": value["patients"], "coverage": value["coverage"],
                           "reported_gene_event_patient_units": value["reported_gene_event_patient_units"]}
                      for key, value in summaries.items()}, indent=2))

if __name__ == "__main__":
    build()
