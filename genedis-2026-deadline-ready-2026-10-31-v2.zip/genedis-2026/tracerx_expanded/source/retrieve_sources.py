"""Pinned public processed TRACERx source retrieval; no analyses or event frequencies."""
from pathlib import Path
import hashlib
import json
import urllib.request
import zipfile

HERE = Path(__file__).resolve().parent
RECORD = "https://zenodo.org/api/records/7683605"
NAMES = (
    "20221109_TRACERx421_scna_table.fst",
    "20221108_sequenza_seg_df_cruk.fst",
    "20221108_driver_mean.adj.cpn_df_cruk.RDS",
    "20221108_sequenza_cyto_gene_drivers_cruk.RDS",
    "20221108_tx421_FLOH.wGII_seq_cruk.RDS",
    "20221109_TRACERx421_gd_driver_signature_events.tsv",
    "cn_drivers.csv",
    "Fig.1bc.2c.3ef.S2l.S3cef.S5abcdef.R",
    "Fig.2ab.S2defi.R",
    "Fig.S2abc.S3b.S5ghi.R",
    "Fig.3bd.S4abcdefgh.R",
)

def fingerprint(path):
    data = path.read_bytes()
    return {"bytes": len(data), "md5": hashlib.md5(data).hexdigest(),
            "sha256": hashlib.sha256(data).hexdigest()}

def fetch(url, path):
    request = urllib.request.Request(url, headers={"User-Agent": "GeNeDis-TRACERx-academic-research/1.0"})
    with urllib.request.urlopen(request, timeout=180) as response, path.open("wb") as output:
        while chunk := response.read(1024 * 1024):
            output.write(chunk)

def main():
    raw = HERE / "raw"
    raw.mkdir(parents=True, exist_ok=True)
    path = HERE / "source_manifest.json"
    pinned_manifest_exists = path.exists()
    if pinned_manifest_exists:
        manifest = json.loads(path.read_text())
        records = manifest["files"]
    else:
        fetch(RECORD, raw / "zenodo_record.json")
        record = json.loads((raw / "zenodo_record.json").read_text())
        files = {item["key"]: item for item in record["files"]}
        records = [{"filename": name, "url": "https://zenodo.org/records/7683605/files/" + name + "?download=1",
                    "bytes": files[name]["size"], "md5": files[name]["checksum"].removeprefix("md5:")}
                   for name in NAMES]
        manifest = {"record": RECORD, "source_terms": "Academic non-commercial use only; source record notes",
                    "files": records}
    for item in records:
        target = raw / item["filename"]
        if not target.exists():
            temporary = target.with_suffix(target.suffix + ".partial")
            fetch(item["url"], temporary)
            actual = fingerprint(temporary)
            if any(actual[key] != item[key] for key in ("bytes", "md5")):
                raise ValueError("Published checksum mismatch: " + item["filename"])
            temporary.replace(target)
        actual = fingerprint(target)
        if any(key in item and actual[key] != item[key] for key in actual):
            raise ValueError("Pinned checksum mismatch: " + item["filename"])
        item.update(actual)
        print("Verified", item["filename"], actual["bytes"], flush=True)
    if not pinned_manifest_exists:
        path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    core = json.loads((HERE / "core_archive_manifest.json").read_text(encoding="utf-8"))
    archive = raw / "figurecode.zip"
    if not archive.exists():
        temporary = raw / "figurecode.zip.partial"
        fetch(core["url"], temporary)
        if fingerprint(temporary) != {key: core[key] for key in ("bytes", "md5", "sha256")}:
            raise ValueError("Pinned core archive checksum mismatch")
        temporary.replace(archive)
    if fingerprint(archive) != {key: core[key] for key in ("bytes", "md5", "sha256")}:
        raise ValueError("Core archive changed")
    (raw / "core").mkdir(exist_ok=True)
    with zipfile.ZipFile(archive) as zipped:
        for item in core["members"]:
            if Path(item["filename"]).name != item["filename"]:
                raise ValueError("Unexpected member target path")
            data = zipped.read(item["archive_member"])
            if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
                raise ValueError("Pinned archive member mismatch")
            target = raw / "core" / item["filename"]
            if target.exists() and target.read_bytes() != data:
                raise ValueError("Existing extracted core file changed")
            if not target.exists():
                target.write_bytes(data)
    print("Verified pinned core archive and", len(core["members"]), "selected members", flush=True)

if __name__ == "__main__":
    main()
