"""Independent source-to-result review without calling inference implementation."""
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def category(source, a, b):
    aa = [r for r in source["drivers"] if r["gene"] == a]
    bb = [r for r in source["drivers"] if r["gene"] == b]
    if not aa or not bb:
        return None
    if any(row["mapping_status"] != "mapped_retained" for row in aa + bb):
        return "mapping_ambiguous"
    ca, cb = {str(r["cluster_id"]) for r in aa}, {str(r["cluster_id"]) for r in bb}
    if len(ca) != 1 or len(cb) != 1:
        return "repeated_gene_ambiguous"
    ac, bc = next(iter(ca)), next(iter(cb))
    if ac == bc:
        return "same_cluster"
    strict = {tuple(map(str, pair)) for pair in source["strict_ancestor_pairs"]}
    possible = {tuple(map(str, pair)) for pair in source["possible_ancestor_pairs"]}
    if (ac, bc) in strict:
        return "source_ancestor"
    if (bc, ac) in strict:
        return "reverse_ancestor"
    if (ac, bc) not in possible and (bc, ac) not in possible:
        return "incomparable"
    return "topology_ambiguous"

def close(a, b):
    assert abs(a - b) < 1e-10, (a, b)

def main():
    reviews = {}
    for cohort in ("luad", "lusc"):
        config_path = ROOT / f"configs/tracerx_expanded_{cohort}_v0_1.json"
        config = read(config_path)
        model_path = ROOT / f"tracerx_expanded/inference/output/{cohort}/model.json"
        model = read(model_path)
        source_path = ROOT / config["baseline"]["source_path"]
        source = read(source_path)["patients"]
        assert sha(source_path) == config["baseline"]["source_sha256"]
        ranking = sorted((s["patient_id"] for s in source), key=lambda pid: (
            hashlib.sha256((config["split"]["salt"] + pid).encode()).hexdigest(), pid))
        roles = {pid: "training" if index < config["split"]["training_participants"] else "evaluation"
                 for index, pid in enumerate(ranking)}
        assert roles == {p["id"]: p["role"] for p in model["patients"]}
        carrier = Counter()
        all_presence = {}
        for s in source:
            present = {r["gene"] for r in s["drivers"] if r["source_driver"] is True}
            assert len([r for r in s["drivers"] if r["source_driver"] is True]) == len(s["drivers"])
            all_presence[s["patient_id"]] = present
            if roles[s["patient_id"]] == "training":
                carrier.update(present)
        assert sorted(carrier) == [e["id"] for e in model["candidate_events"]]
        ntrain = config["split"]["training_participants"]
        events = sorted(g for g in carrier if carrier[g] >= 10 and ntrain - carrier[g] >= 10)
        assert events == [e["id"] for e in model["events"]]
        for e in model["candidate_events"]:
            assert e["carriers_training"] == carrier[e["id"]]
            assert e["noncarriers_training"] == ntrain - carrier[e["id"]]
        pair_counts = {}
        vote_totals = {role: Counter() for role in ("training", "evaluation")}
        for a, b in combinations(events, 2):
            for role in ("training", "evaluation"):
                counts = Counter(category(s, a, b) for s in source if roles[s["patient_id"]] == role)
                counts.pop(None, None)
                pair_counts[a, b, role] = counts
                vote_totals[role].update(counts)
        pair_index = {(row["a"], row["b"]): row for row in model["pair_evidence"]}
        assert len(pair_index) == len(events) * (len(events) - 1) // 2
        fields = ("source_ancestor", "reverse_ancestor", "same_cluster", "incomparable", "topology_ambiguous", "repeated_gene_ambiguous", "mapping_ambiguous")
        for (a, b), row in pair_index.items():
            for role in ("training", "evaluation"):
                counts = pair_counts[a, b, role]
                assert all(row[role][field] == counts[field] for field in fields)
                assert row[role]["co_carriers"] == sum(counts.values())
        null_path = ROOT / f"tracerx_expanded/inference/output/{cohort}/ordering_null_all_pairs.json"
        null = read(null_path)
        assert len(null) == len(events) * (len(events) - 1)
        p_values = []
        for row in null:
            assert row["permutations"] == 10000
            close(row["p"], (row["exceedances"] + 1) / 10001)
            a, b = row["source"], row["target"]
            first, second = sorted((a, b))
            counts = pair_counts[first, second, "training"]
            difference = counts["source_ancestor"] - counts["reverse_ancestor"]
            assert row["statistic"] == (difference if a == first else -difference)
            p_values.append(row["p"])
        adjusted = [1.0] * len(null)
        running = 1.0
        order = sorted(range(len(null)), key=lambda i: p_values[i])
        for index in reversed(range(len(order))):
            position = order[index]
            running = min(running, p_values[position] * len(order) / (index + 1))
            adjusted[position] = min(1.0, running)
        for actual, expected in zip(null, adjusted):
            close(actual["BH_q"], expected)
        # Independent joint score from original source presences, training-only CPTs,
        # and the complete selected incoming-parent sets, including negative associations.
        training = [pid for pid, role in roles.items() if role == "training"]
        evaluation = [s["patient_id"] for s in source if roles[s["patient_id"]] == "evaluation"]
        parents = {gene: sorted(e["source"] for e in model["edges"] if e["target"] == gene) for gene in events}
        buckets = {gene: defaultdict(lambda: [0, 0]) for gene in events}
        for gene in events:
            for pid in training:
                pattern = tuple(parent in all_presence[pid] for parent in parents[gene])
                buckets[gene][pattern][0] += 1
                buckets[gene][pattern][1] += gene in all_presence[pid]
        joint = independent = 0.0
        for pid in evaluation:
            for gene in events:
                pattern = tuple(parent in all_presence[pid] for parent in parents[gene])
                n, k = buckets[gene].get(pattern, (0, 0))
                p = (k + 1) / (n + 2)
                marginal = (carrier[gene] + 1) / (ntrain + 2)
                joint += math.log(p if gene in all_presence[pid] else 1 - p)
                independent += math.log(marginal if gene in all_presence[pid] else 1 - marginal)
        reported = model["validation"]["holdout"]
        close(joint, reported["joint_log_score"])
        close(independent, reported["marginal_log_score"])
        assert parents == reported["parents"]
        for edge in model["edges"]:
            a, b = edge["source"], edge["target"]
            for role in ("training", "evaluation"):
                counts = Counter(category(s, a, b) for s in source if roles[s["patient_id"]] == role)
                for field in fields:
                    assert edge[role][field] == counts[field]
        reviews[cohort] = {"model_sha256": sha(model_path), "source_sha256": sha(source_path),
            "candidate_genes": len(carrier), "eligible_events": len(events), "patients": len(source),
            "training": len(training), "evaluation": len(evaluation), "all_pair_categories_rederived": len(pair_index),
            "all_directional_p_and_BH_recomputed": len(null), "directional_BH_q_below_0_05": sum(x < .05 for x in adjusted),
            "selected_edges_source_categories_rechecked": len(model["edges"]),
            "source_vote_totals": {role: dict(counts) for role, counts in vote_totals.items()},
            "holdout_from_source_training_CPTs": {"joint": joint, "independent": independent, "difference_per_patient": (joint - independent) / len(evaluation)},
            "result": "PASS", "scope": "Independent source/gate/role/category/multiplicity/CPT rederivation; no refit or permutation rerun."}
    (HERE / "expanded_model_source_review.json").write_text(json.dumps(reviews, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(reviews, indent=2))

if __name__ == "__main__":
    main()
