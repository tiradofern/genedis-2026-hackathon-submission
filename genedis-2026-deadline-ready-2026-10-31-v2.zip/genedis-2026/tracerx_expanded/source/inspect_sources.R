# Source schemas/availability only: no gene-event frequency or inference.
args <- commandArgs(trailingOnly=TRUE)
root <- normalizePath(args[[1]], winslash="/", mustWork=TRUE)
setwd(root)
.libPaths(c("tracerx_routes/source/.rlibrary", "population_routes/inference/.rlibrary", .libPaths()))
raw <- "tracerx_expanded/source/raw"
out <- "tracerx_expanded/source/output"
dir.create(out, recursive=TRUE, showWarnings=FALSE)
summary <- list()
for (path in list.files(raw, full.names=TRUE)) {
  if (grepl("\\.fst$", path)) {
    object <- fst::read_fst(path)
  } else if (grepl("\\.[Rr][Dd][Ss]$", path)) {
    object <- readRDS(path)
  } else if (grepl("\\.tsv$", path)) {
    object <- read.delim(path, check.names=FALSE)
  } else if (grepl("\\.csv$", path)) {
    object <- read.csv(path, check.names=FALSE)
  } else next
  capture.output(str(object, max.level=2), file=file.path(out,paste0(basename(path),".schema.txt")))
  item <- list(class=class(object), dimensions=dim(object), columns=names(object))
  if (is.data.frame(object)) {
    item$classes <- lapply(object, class)
    write.table(utils::head(object,8),file.path(out,paste0(basename(path),".head.tsv")), sep="\t", quote=FALSE,row.names=FALSE,na="")
    for (key in intersect(c("type","consequence","is_driver","is_clonal","Tumour.cluster","classification","source","histology"),names(object))) {
      item[[paste0(key,"_literal_values")]] <- as.list(unique(as.character(object[[key]])))
    }
  }
  summary[[basename(path)]] <- item
}
jsonlite::write_json(summary,file.path(out,"schema_audit.json"),auto_unbox=TRUE,pretty=TRUE,na="null")
cat("Source schema audit complete; no event frequency/model calculation.\n")
