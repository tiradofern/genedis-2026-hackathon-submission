# Targeted exact-key source audit only; no mutation model repair or new assignment.
args <- commandArgs(trailingOnly=TRUE)
setwd(normalizePath(args[[1]],winslash="/",mustWork=TRUE))
.libPaths(c("tracerx_routes/source/.rlibrary","population_routes/inference/.rlibrary",.libPaths()))
cohort <- jsonlite::read_json("tracerx_routes/source/output/cohort_trees.json")$patients
ids <- vapply(cohort,function(x)x$tumour_id,character(1))
mut <- fst::read_fst("tracerx_routes/source/raw/20221109_TRACERx421_mutation_table.fst")
mut <- mut[mut$DriverMut & mut$Hugo_Symbol=="ATRX" & mut$tumour_id %in% ids,]
trees <- readRDS("nextstrain/source/raw/20221109_TRACERx421_phylogenetic_trees.rds")
keys <- paste(mut$tumour_id,sub("^chr","",mut$chr),mut$start,mut$ref,mut$var,sep=":")
exact <- mapply(function(tid,key)sum(rownames(trees[[tid]]$ccf_table_pyclone_clean)==key),mut$tumour_id,keys)
has_sex_chr <- vapply(unique(mut$tumour_id),function(tid)any(grepl(":(X|Y|23|24):",rownames(trees[[tid]]$ccf_table_pyclone_clean))),logical(1))
out <- list(gene="ATRX",eligible_patients=length(unique(mut$patient_id)),curated_variant_rows=nrow(mut),
  source_chromosomes=as.list(unique(as.character(mut$chr))),
  corrected_cluster_unavailable=sum(is.na(mut$PyCloneCluster_SC_TB_corrected)),
  source_clean_cluster_unavailable=sum(is.na(mut$cleanCluster_SC)),
  exact_embedded_full_variant_key_matches=sum(exact),
  carrier_source_objects_with_any_X_Y_23_24_mapping=sum(has_sex_chr),
  interpretation="Reported presence retained; no source mutation-cluster placement. No explanation for source sex-chromosome omission is imputed and no order is repaired.")
jsonlite::write_json(out,"tracerx_expanded/source/atrx_mapping_audit.json",auto_unbox=TRUE,pretty=TRUE,na="null")
cat("Targeted ATRX source audit written.\n")
