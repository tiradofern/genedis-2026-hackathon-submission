# Source translation, with no event selection or new CNA thresholding/placement.
args <- commandArgs(trailingOnly=TRUE)
root <- normalizePath(args[[1]], winslash="/", mustWork=TRUE)
setwd(root)
.libPaths(c("tracerx_routes/source/.rlibrary", "population_routes/inference/.rlibrary", .libPaths()))
reader <- jsonlite::read_json("tracerx_routes/source/source_manifest.json", simplifyVector=FALSE)$reader
for(package in reader$packages) stopifnot(as.character(utils::packageVersion(package$name)) == package$version)
raw <- "tracerx_expanded/source/raw"
out <- "tracerx_expanded/source/output"
dir.create(out, recursive=TRUE, showWarnings=FALSE)
write_tsv <- function(x,name) write.table(x,file.path(out,name),sep="\t",quote=FALSE,row.names=FALSE,na="")
cn <- fst::read_fst(file.path(raw,"20221109_TRACERx421_scna_table.fst"))
mean_cn <- readRDS(file.path(raw,"20221108_driver_mean.adj.cpn_df_cruk.RDS"))
annotation <- fst::read_fst(file.path(raw,"core/gene_anno_df.fst"))
panel <- read.csv(file.path(raw,"cn_drivers.csv"))
annotation <- annotation[annotation$gene_name %in% panel$gene,c("gene_name","chromosome","start","end","cytoband_name","is_cn_driver","cn_driver_OG_TSG")]
write_tsv(annotation,"panel_annotations.tsv")
annotation_intervals <- unique(annotation[,c("gene_name","chromosome","start","end")])
stopifnot(!anyDuplicated(annotation_intervals$gene_name))
write_tsv(mean_cn,"source_regional_gene_copy_number.tsv")
write_tsv(unique(cn[,c("patient_id","tumour_id","sample","Ploidy","ACF")]),"source_regional_assay.tsv")
# Retain coordinate-level minimum consistent segments as shared genomic units.
# Panel overlap is a location annotation, not proof a curated call came from that segment.
overlaps <- vector("list", nrow(annotation_intervals))
for(i in seq_len(nrow(annotation_intervals))) {
  g <- annotation_intervals[i,]
  keep <- as.character(cn$chr)==as.character(g$chromosome) & cn$startpos <= g$end & cn$endpos >= g$start
  value <- cn[keep,]
  value$panel_gene <- g$gene_name
  overlaps[[i]] <- value
}
write_tsv(do.call(rbind,overlaps),"source_panel_segment_overlaps.tsv")
write_tsv(read.delim(file.path(raw,"core/20221109_TRACERx421_gd_table_per_tumour.tsv")),"source_wgd_tumours.tsv")
write_tsv(read.delim(file.path(raw,"core/20221109_TRACERx421_gd_table_per_region.tsv")),"source_wgd_regions.tsv")
# No mutations or candidate carrier counts are calculated by this source translator.
cat("Translated exact CNA records, source panel coordinates and WGD context.\n")
