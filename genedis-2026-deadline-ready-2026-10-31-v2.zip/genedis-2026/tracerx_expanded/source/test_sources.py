import csv
import hashlib
import json
import unittest
from collections import Counter
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
from build_context import classify_state, measured, sample_key, segment_key, verify_frozen

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

class SourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.audit = read(HERE / "cna_source_audit.json")
        cls.context = {cohort: read(HERE / "output" / cohort / "cna_context.json") for cohort in ("luad", "lusc")}

    def test_frozen_config_and_all_source_bytes(self):
        verify_frozen()

    def test_missingness_is_not_absence(self):
        self.assertEqual(classify_state(True, False), "reported")
        self.assertEqual(classify_state(False, True), "not_reported")
        self.assertEqual(classify_state(False, False), "assay_unavailable")
        self.assertTrue(measured("-Inf"))
        self.assertFalse(measured(""))

    def test_sample_normalization_is_narrow(self):
        self.assertEqual(sample_key("FICTIONAL_SU_T1-R12"), "FICTIONAL_SU_T1.R12")
        self.assertEqual(sample_key("FICTIONAL_SU_T1.LN1"), "FICTIONAL_SU_T1.LN1")
        self.assertEqual(sample_key("FICTIONAL-Tumour1-R1extra"), "FICTIONAL-Tumour1-R1extra")

    def test_context_catalog_has_all_typed_panel_events(self):
        for context in self.context.values():
            self.assertEqual(len(context["events"]), 68)
            self.assertEqual({item["gene"] for item in context["events"] if item["gene"]},
                             {item["gene"] for item in context["source_panel"]})
            self.assertEqual(len({item["id"] for item in context["events"]}), 68)
            for event in context["events"]:
                self.assertNotIn("ancestor", event)
                self.assertTrue("no_comparable_branch_placement" in event["order_status"])

    def test_independent_original_cohort_and_roles(self):
        for cohort, context in self.context.items():
            config = read(ROOT / f"configs/tracerx_expanded_{cohort}_v0_1.json")
            original = read(ROOT / config["baseline"]["source_path"])
            role_path = "tracerx_routes/inference/output/engine_inputs.json" if cohort == "luad" else "tracerx_routes/inference/output/lusc/engine_inputs.json"
            roles = {item["id"]: item["role"] for item in read(ROOT / role_path)["patients"]}
            self.assertEqual({p["patient_id"] for p in context["patients"]}, {p["patient_id"] for p in original["patients"]})
            self.assertEqual({p["patient_id"]: p["role"] for p in context["patients"]}, roles)

    def test_rederive_every_call_and_presence_from_original_tsv(self):
        with (HERE / "raw/20221109_TRACERx421_gd_driver_signature_events.tsv").open(newline="", encoding="utf-8") as handle:
            source = list(csv.DictReader(handle, delimiter="\t"))
        for context in self.context.values():
            policy = {(event["gene"], event["source_consequence"]): event["id"] for event in context["events"] if event["gene"]}
            for patient in context["patients"]:
                actual = []
                for line, row in enumerate(source, start=2):
                    if row["tumour_id"] != patient["tumour_id"] or row["type"] != "copy_number" or row["is_driver"] != "TRUE":
                        continue
                    identifier = "WGD" if row["gene"] == "WGD" and row["consequence"] == "GD" else policy.get((row["gene"], row["consequence"]))
                    if identifier:
                        actual.append({"event_id": identifier, "source_tsv_line": line, **row})
                self.assertEqual(patient["source_calls"], actual)
                self.assertEqual({key for key, value in patient["event_states"].items() if value == "reported"}, {row["event_id"] for row in actual})
                self.assertEqual(patient["ordered_CNA_events"], [])

    def test_every_role_event_denominator_and_unknowns(self):
        for context in self.context.values():
            for event in context["events"]:
                for role in ("training", "evaluation"):
                    persons = [p for p in context["patients"] if p["role"] == role]
                    counts = Counter(p["event_states"][event["id"]] for p in persons)
                    self.assertEqual(event[role]["eligible"], len(persons))
                    for state in ("reported", "not_reported", "assay_unavailable"):
                        self.assertEqual(event[role][state], counts[state])
                    self.assertEqual(sum(event[role][state] for state in ("reported", "not_reported", "assay_unavailable")), len(persons))
            for gene in ("AMER1", "GPC3", "KDM6A"):
                event = next(e for e in context["events"] if e["gene"] == gene)
                self.assertEqual(event["training"]["assay_unavailable"], context["coverage"]["training"]["patients"])

    def test_independent_gene_measurement_and_partial_coverage(self):
        with (HERE / "output/source_regional_gene_copy_number.tsv").open(newline="", encoding="utf-8") as handle:
            raw = list(csv.DictReader(handle, delimiter="\t"))
        for context in self.context.values():
            for patient in context["patients"]:
                relevant = [r for r in raw if r["tumour_id_mphase_cruk"] == patient["tumour_id"]]
                for event in context["events"]:
                    if event["id"] == "WGD":
                        continue
                    observed = {sample_key(r["sample_name_cruk"]) for r in relevant if r.get(event["gene"], "") not in ("", "NA", "NaN")}
                    actual = patient["event_assay"][event["id"]]
                    self.assertEqual(set(actual["source_regions_measured"]), observed)
                    expected = set(patient["primary_regions_expected"])
                    self.assertEqual(actual["primary_regions_measured"], len(expected & observed))
                    self.assertEqual(actual["all_primary_regions_measured"], expected <= observed)

    def test_shared_segments_preserve_source_units_and_rows(self):
        for context in self.context.values():
            for patient in context["patients"]:
                record = patient["shared_segment_artifact"]
                path = ROOT / record["path"]
                self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), record["sha256"])
                units = read(path)["shared_segment_units"]
                self.assertEqual(len(units), record["coordinate_units"])
                self.assertEqual(len({item["id"] for item in units}), len(units))
                for unit in units:
                    for row in unit["regional_source_rows"]:
                        self.assertEqual(segment_key(row), unit["id"])
                        self.assertEqual(row["tumour_id"], patient["tumour_id"])
                    self.assertEqual(len({r["sample"] for r in unit["regional_source_rows"]}), len(unit["regional_source_rows"]))

    def test_all_source_scope_regions_are_explicit(self):
        for context in self.context.values():
            for patient in context["patients"]:
                source = {sample_key(row["sample"]) for row in patient["regional_assay"]}
                frozen = set(patient["frozen_tree_regions"])
                self.assertEqual(set(patient["source_SCNA_regions_not_in_frozen_tree"]), source - frozen)
                self.assertEqual(set(patient["primary_regions_with_SCNA"]), set(patient["primary_regions_expected"]) & source)
                self.assertTrue(patient["all_primary_regions_with_SCNA"])
                self.assertIn("Tumour-level", patient["source_call_scope"])

    def test_export_artifact_hashes_match_versioned_audit(self):
        for cohort, entry in self.audit["artifacts"].items():
            path = ROOT / entry["path"]
            self.assertEqual(path.stat().st_size, entry["bytes"])
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), entry["sha256"])

if __name__ == "__main__":
    unittest.main()
