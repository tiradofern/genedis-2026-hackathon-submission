[CmdletBinding()]
param(
    [ValidateRange(1024, 65535)] [int]$Port = 4003,
    [string]$PythonPath,
    [switch]$Foreground,
    [switch]$Restart
)
$ErrorActionPreference = 'Stop'
$repoRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..\..')).Path
if (-not $PythonPath) {
    $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
    if ($pythonCommand) { $PythonPath = $pythonCommand.Source }
}
if (-not $PythonPath -or -not (Test-Path -LiteralPath $PythonPath)) { throw 'Python 3 is required. Supply its executable with -PythonPath.' }
$serverScript = Join-Path $PSScriptRoot 'server.py'
$runtimeRoot = Join-Path $PSScriptRoot '.runtime'
New-Item -ItemType Directory -Path $runtimeRoot -Force | Out-Null
$statePath = Join-Path $runtimeRoot "server-$Port.json"
$url = "http://127.0.0.1:$Port/"
if (Test-Path -LiteralPath $statePath) {
    $savedState = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
    $savedProcess = Get-Process -Id $savedState.pid -ErrorAction SilentlyContinue
    if ($savedProcess -and $savedState.scriptPath -eq $serverScript -and $savedState.projectRoot -eq $repoRoot -and
        $savedProcess.StartTime.ToUniversalTime() -eq ([datetime]$savedState.startedUtc).ToUniversalTime()) {
        if ($Restart) {
            Stop-Process -InputObject $savedProcess
            $null = $savedProcess.WaitForExit(3000)
        } else {
            try {
                $null = Invoke-RestMethod -Uri ($url + 'model.json') -TimeoutSec 3
                Write-Host "Expanded TRACERx evidence is already running at $url (PID $($savedState.pid))."
                return
            } catch { }
        }
    }
}
$probe = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $Port)
try { $probe.Start() }
catch { throw "Port $Port is already in use. Choose another port; no existing process was stopped." }
finally { $probe.Stop() }
if ($Foreground) {
    & $PythonPath $serverScript --port $Port
    if ($LASTEXITCODE -ne 0) { throw "Companion exited with status $LASTEXITCODE." }
    return
}
$stdoutPath = Join-Path $runtimeRoot "server-$Port.stdout.log"
$stderrPath = Join-Path $runtimeRoot "server-$Port.stderr.log"
$serverProcess = Start-Process -FilePath $PythonPath -ArgumentList @('"' + $serverScript + '"', '--port', [string]$Port) `
    -WorkingDirectory $repoRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath
$state = [ordered]@{pid=$serverProcess.Id; startedUtc=$serverProcess.StartTime.ToUniversalTime().ToString('o'); url=$url; scriptPath=$serverScript; projectRoot=$repoRoot}
$state | ConvertTo-Json | Set-Content -LiteralPath $statePath -Encoding utf8
$ready = $false
for ($attempt = 0; $attempt -lt 30; $attempt++) {
    $serverProcess.Refresh()
    if ($serverProcess.HasExited) { throw "Companion exited. See $stderrPath" }
    try { $null = Invoke-RestMethod -Uri ($url + 'model.json') -TimeoutSec 1; $ready=$true; break }
    catch { Start-Sleep -Milliseconds 250 }
}
if (-not $ready) { throw "A valid model was not served. See $stdoutPath and $stderrPath" }
Write-Host "Expanded TRACERx evidence is running at $url (PID $($serverProcess.Id))."
Write-Host 'Baseline and expanded histology analyses are distinct; copy-number context is separate from strict mutation-cluster ancestry.'
