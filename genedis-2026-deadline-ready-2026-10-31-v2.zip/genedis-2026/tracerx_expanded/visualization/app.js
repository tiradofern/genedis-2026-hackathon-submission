const $ = (id) => document.getElementById(id);
const NS = 'http://www.w3.org/2000/svg';
const states = [
  ['a_ancestor_b','source_ancestor','state-a'],['b_ancestor_a','reverse_ancestor','state-b'],['same_cluster','same_cluster','state-same'],['incomparable','incomparable','state-incomparable'],['topology_ambiguous','topology_ambiguous','state-topology'],['repeated_gene_ambiguous','repeated_gene_ambiguous','state-repeated'],['mapping_ambiguous','mapping_ambiguous','state-mapping']
];
let model, selectedPair, selectedPatient, treeLinks = {};
let cnaContext,cnaFingerprint,cnaQuery,cnaEventPayload,cnaSelectedEvent,cnaPatientSequence=0;
function el(tag,text,attrs={}){const node=document.createElement(tag);if(text!==undefined)node.textContent=text;for(const[key,value]of Object.entries(attrs))node.setAttribute(key,value);return node;}
function svg(tag,attrs={},text){const node=document.createElementNS(NS,tag);for(const[key,value]of Object.entries(attrs))node.setAttribute(key,value);if(text!==undefined)node.textContent=text;return node;}
const ids=(row)=>[row.a??row.source,row.b??row.target];
const pairLabel=(pair)=>ids(pair).join(' / ');
function categoryLabel(state,a,b){return {a_ancestor_b:`${a} ancestral to ${b}`,b_ancestor_a:`${b} ancestral to ${a}`,same_cluster:'Same mutation cluster · order unresolved',incomparable:'Incomparable branches',topology_ambiguous:'Relationship differs across deposited alternatives',repeated_gene_ambiguous:'Repeated gene placements across clusters · unresolved',mapping_ambiguous:'Driver-to-cluster mapping unresolved'}[state]||state;}
function relationFor(patient,a,b){const row=(patient.relations||[]).find((item)=>{const[x,y]=ids(item);return(x===a&&y===b)||(x===b&&y===a);});if(!row)return null;const result={...row};if(ids(row)[0]!==a)result.state={a_ancestor_b:'b_ancestor_a',b_ancestor_a:'a_ancestor_b'}[row.state]||row.state;return result;}
function eventPlacement(patient,gene){const entries=(patient.events||[]).filter((event)=>(event.gene??event.id)===gene);return entries.length?entries.map((event)=>`${(event.cluster_ids||[]).join(', ')||'No retained placement'} · ${event.mapping_status||'Source mapping status not supplied'}`).join('; '):'No source event record';}
function nativeUrl(patient){const url=treeLinks[patient.id]||patient.evidence_url||patient.source_patient_evidence;try{const parsed=new URL(url);return parsed.protocol==='http:'&&parsed.hostname==='127.0.0.1'&&parsed.port==='4000'&&parsed.pathname.startsWith('/tracerx/patient/')?parsed.href:null;}catch{return null;}}
function treeAnchor(patient,primary=false){const url=nativeUrl(patient);return url?el('a',primary?'Open this published tree in actual Nextstrain ↗':'Open in Nextstrain ↗',{href:url,target:'_blank',rel:'noopener',class:primary?'native-action':'tree-link'}):el('span','Published tree export not ready',{class:'tree-link'});}
function choosePair(index){selectedPair=model.pair_evidence[index];$('pair-select').value=String(index);renderPair();renderPatientEvidence();}
function choosePatient(id){selectedPatient=model.patients.find((patient)=>patient.id===id);$('patient-select').value=id;renderPatientDetail();}
function renderBar(role,pair){const chart=$(`${role}-bar`),counts=pair[role],total=counts.co_carriers,[a,b]=ids(pair);chart.replaceChildren();chart.setAttribute('viewBox','0 0 600 32');chart.append(svg('title',{},`${role}: ${total} co-carrier patients, with all relationship categories retained`));if(!total){chart.append(svg('text',{x:0,y:21,fill:'#586c78','font-size':12},'No co-carrier patients in this role'));return;}let x=0;for(const[state,key,cls]of states){const width=600*counts[key]/total;const rect=svg('rect',{x,y:3,width,height:24,class:cls});rect.append(svg('title',{},`${categoryLabel(state,a,b)}: ${counts[key]} / ${total}`));chart.append(rect);x+=width;}}
function renderPair(){const body=$('categories');body.replaceChildren();$('pair-summary').replaceChildren();if(!selectedPair){body.append(el('tr'));body.firstChild.append(el('td','No eligible source gene pairs supplied.',{colspan:3}));return;}const[a,b]=ids(selectedPair);for(const role of ['training','evaluation']){const c=selectedPair[role],part=el('span');part.append(el('strong',`${role==='training'?'Training':'Evaluation'}: ${c.co_carriers} co-carriers`),document.createTextNode(` · ${c.source_ancestor+c.reverse_ancestor} strict-order resolved`));$('pair-summary').append(part);renderBar(role,selectedPair);}for(const[state,key,cls]of states){const row=el('tr'),label=el('td'),line=el('span',undefined,{class:'category-label'});line.append(el('i',undefined,{class:`swatch ${cls}`}),document.createTextNode(categoryLabel(state,a,b)));label.append(line);row.append(label,el('td',`${selectedPair.training[key]} / ${selectedPair.training.co_carriers}`),el('td',`${selectedPair.evaluation[key]} / ${selectedPair.evaluation.co_carriers}`));body.append(row);}$('pair-diagnostics').textContent=JSON.stringify(selectedPair,null,2);for(const option of $('state-filter').options){if(option.value!=='all')option.textContent=categoryLabel(option.value,a,b);}}
function renderPatientEvidence(){const body=$('patient-evidence');body.replaceChildren();if(!selectedPair)return;const[a,b]=ids(selectedPair);const role=$('role-filter').value,state=$('state-filter').value;let visible=0,total=0;for(const patient of model.patients){const relation=relationFor(patient,a,b);if(!relation)continue;total++;if(role!=='all'&&patient.role!==role||state!=='all'&&relation.state!==state)continue;visible++;const row=el('tr');const name=el('td'),button=el('button',patient.id,{type:'button',class:'text-button'});button.addEventListener('click',()=>{choosePatient(patient.id);$('patient-section').scrollIntoView({behavior:'auto',block:'start'});});name.append(button);const relationship=el('td',categoryLabel(relation.state,a,b),{class:'state-cell'});row.append(name,el('td',patient.role),relationship,el('td',eventPlacement(patient,a),{class:'placement'}),el('td',eventPlacement(patient,b),{class:'placement'}),el('td',patient.n_topologies));const link=el('td');link.append(treeAnchor(patient));row.append(link);body.append(row);}if(!visible){const row=el('tr');row.append(el('td','No source patient traces match these display filters.',{colspan:7}));body.append(row);}$('patient-count').textContent=`${visible} of ${total} pair co-carrier traces shown · filters do not alter aggregate evidence`;}
function renderAllPairs(){const body=$('all-pairs');body.replaceChildren();const role=$('table-role').value;model.pair_evidence.forEach((pair,index)=>{const row=el('tr'),name=el('td'),button=el('button',pairLabel(pair),{type:'button',class:'text-button'});button.addEventListener('click',()=>{choosePair(index);$('pair-section').scrollIntoView({behavior:'auto',block:'start'});});name.append(button);row.append(name,el('td',pair[role].co_carriers));for(const[,key]of states)row.append(el('td',pair[role][key]));body.append(row);});}
function renderPatientDetail(){const box=$('patient-detail');box.replaceChildren();if(!selectedPatient){box.append(el('p','No eligible patient records supplied.'));return;}const p=selectedPatient,meta=el('div',undefined,{class:'patient-meta'});for(const[label,value]of [['Source patient',p.id],['Published tumour',p.tumour_id??p.tumor_id??'Not supplied'],['Locked role',p.role],['Source regions',p.n_regions],['Deposited topologies',p.n_topologies]]){const item=el('span');item.append(el('strong',`${label}: `),document.createTextNode(value));meta.append(item);}box.append(meta,treeAnchor(p,true),el('p','The linked view displays the authors’ corrected source topology only. It is a representative reconstruction; it does not replace uncertainty across deposited alternatives.',{class:'source-warning'}));const table=el('table'),head=el('thead'),header=el('tr');for(const text of ['Curated source-driver gene','Source cluster placement','Mapping status','Exact source event metadata'])header.append(el('th',text,{scope:'col'}));head.append(header);table.append(head);const body=el('tbody');for(const event of p.events||[]){const row=el('tr');row.append(el('td',event.gene??event.id??'Not supplied'),el('td',(event.cluster_ids||[]).join(', ')||'No retained placement'),el('td',event.mapping_status||'Not supplied'));const detail=el('td'),disclosure=el('details');disclosure.append(el('summary','Inspect source event'),el('pre',JSON.stringify(event,null,2)));detail.append(disclosure);row.append(detail);body.append(row);}table.append(body);const scroll=el('div',undefined,{class:'table-scroll'});scroll.append(table);box.append(scroll);if(p.limitations)box.append(el('p',Array.isArray(p.limitations)?p.limitations.join(' '):p.limitations));}
function renderEventMapping(){const body=$('event-mapping');body.replaceChildren();for(const event of model.events){const row=el('tr'),train=event.uniquely_mapped_training,evaln=event.uniquely_mapped_evaluation,presenceOnly=train===0&&evaln===0;row.append(el('td',event.label||event.id),el('td',`${event.carriers_training} / ${event.eligible_denominator_training??model.cohort.training_count}`),el('td',train===undefined?'Not reported':`${train} / ${event.carriers_training}`),el('td',`${event.carriers_evaluation} / ${event.eligible_denominator_evaluation??model.cohort.evaluation_count}`),el('td',evaln===undefined?'Not reported':`${evaln} / ${event.carriers_evaluation}`),el('td',presenceOnly?'Presence only; no resolved cluster placement':'Use per-patient mapping and relation categories'));if(presenceOnly)row.classList.add('presence-only');body.append(row);}}
function renderAssessment(){const edges=(model.edges||[]).filter((edge)=>edge.selected!==false),tests=model.pair_evidence.flatMap((pair)=>Object.values(pair.ordering_null||{})),q=tests.filter((test)=>typeof test.BH_q==='number'),zeroEval=edges.filter((edge)=>edge.evaluation?.strict_order_resolved===0).length;$('assessment').hidden=false;$('ordering-assessment').textContent=`${q.length?q.filter((test)=>test.BH_q<0.05).length+' / '+q.length+' ordering tests have BH q < 0.05. ':''}${edges.length?zeroEval+' / '+edges.length+' selected model dependencies have no strict-order-resolved evaluation patients.':'No genuine selected population dependencies are supplied.'}`;const presenceOnly=model.events.filter((event)=>event.uniquely_mapped_training===0&&event.uniquely_mapped_evaluation===0);$('mapping-assessment').textContent=presenceOnly.length?'Presence-only event(s): '+presenceOnly.map((event)=>`${event.id} (${event.carriers_training} training and ${event.carriers_evaluation} evaluation carriers, zero uniquely placed in both roles)`).join('; ')+'. Their presence is preserved and their unresolved pair categories remain in the denominators.':'Cluster mapping availability is reported for every event below; unresolved placements are not recoded as absence.';}
function modelGraph(edges){const chart=svg('svg',{class:'model-graph',role:'img','aria-label':'Selected population model dependency DAG; not a clonal tree'}),parents=Object.fromEntries(model.events.map((event)=>[event.id,[]])),children=Object.fromEntries(model.events.map((event)=>[event.id,[]]));for(const edge of edges){const[a,b]=ids(edge);parents[b].push(a);children[a].push(b);}const degree=Object.fromEntries(model.events.map((event)=>[event.id,parents[event.id].length])),depth=Object.fromEntries(model.events.map((event)=>[event.id,0])),ready=model.events.filter((event)=>!degree[event.id]).map((event)=>event.id);let visited=0;while(ready.length){const id=ready.shift();visited++;for(const child of children[id]){depth[child]=Math.max(depth[child],depth[id]+1);if(!--degree[child])ready.push(child);}}if(visited!==model.events.length)return el('p','Selected model graph is not acyclic; no false DAG layout was substituted.');const used=new Set(edges.flatMap(ids)),layers=new Map(),positions=new Map();for(const event of model.events.filter((item)=>used.has(item.id))){if(!layers.has(depth[event.id]))layers.set(depth[event.id],[]);layers.get(depth[event.id]).push(event);}let tallest=1;for(const[column,events]of layers){tallest=Math.max(tallest,events.length);events.forEach((event,i)=>positions.set(event.id,{x:35+column*260,y:40+i*85}));}const isolated=model.events.filter((event)=>!used.has(event.id)),isolatedStart=Math.max(180,tallest*85+90);isolated.forEach((event,i)=>positions.set(event.id,{x:35+(i%4)*230,y:isolatedStart+Math.floor(i/4)*75}));const height=isolatedStart+Math.ceil(isolated.length/4)*75+35;chart.setAttribute('viewBox',`0 0 ${Math.max(1000,layers.size*260+70)} ${height}`);chart.setAttribute('width',Math.max(1000,layers.size*260+70));chart.setAttribute('height',height);const defs=svg('defs'),marker=svg('marker',{id:'model-arrow',viewBox:'0 0 10 10',refX:9,refY:5,markerWidth:7,markerHeight:7,orient:'auto'});marker.append(svg('path',{d:'M0,0L10,5L0,10z',fill:'#637783'}));defs.append(marker);chart.append(defs);for(const edge of edges){const[a,b]=ids(edge),from=positions.get(a),to=positions.get(b),x1=from.x+150,y1=from.y+24,x2=to.x,y2=to.y+24;const path=svg('path',{d:`M${x1},${y1} C${x1+40},${y1} ${x2-40},${y2} ${x2-7},${y2}`,class:'model-edge','marker-end':'url(#model-arrow)'});path.append(svg('title',{},`${a} → ${b}: training ${edge.training?.source_ancestor} ancestral / ${edge.training?.co_carriers} co-carriers; evaluation ${edge.evaluation?.source_ancestor} / ${edge.evaluation?.co_carriers}. Dependency, not direct transition.`));chart.append(path,svg('text',{x:(x1+x2)/2,y:(y1+y2)/2-7,'text-anchor':'middle',class:'model-edge-count'},`T ${edge.training?.source_ancestor}/${edge.training?.co_carriers} · E ${edge.evaluation?.source_ancestor}/${edge.evaluation?.co_carriers}`));}if(isolated.length)chart.append(svg('text',{x:35,y:isolatedStart-15,class:'model-layout-note'},'Events with no selected dependencies · position is unordered'));for(const event of model.events){const{x,y}=positions.get(event.id),group=svg('g',{transform:`translate(${x},${y})`});group.append(svg('rect',{width:150,height:48,rx:5,class:event.uniquely_mapped_training===0&&event.uniquely_mapped_evaluation===0?'model-event-presence':'model-event'}),svg('text',{x:12,y:29,class:'model-event-name'},event.id));group.append(svg('title',{},event.uniquely_mapped_training===0&&event.uniquely_mapped_evaluation===0?'Reported driver presence; no uniquely placed clusters':event.label));chart.append(group);}return chart;}
function renderModel(){const box=$('model-detail');box.replaceChildren();box.append(el('p',`Source model status: ${model.model_status||'Not supplied'}`,{class:'model-status'}),el('p','The primary evidence does not depend on population-model selection. A selected dependency is not a confirmed direct mutation transition or a universal evolutionary route.'));const edges=(model.edges||[]).filter((edge)=>edge.selected!==false);if(!edges.length){box.append(el('p','No genuine selected population-model dependencies are supplied. The source pair evidence remains available without invented model edges.'));return;}box.append(el('p','Compare bootstrap selection with strict source-order counts, co-carriers and every unresolved category. A dependency may reflect negative reported-event association; it is not automatically positive cooperation.',{class:'source-warning'}));const graphScroll=el('div',undefined,{class:'table-scroll'});graphScroll.append(modelGraph(edges));box.append(graphScroll,el('p','Arrow labels show training (T) and evaluation (E) patients with the stated ancestral direction / all pair co-carriers. Dependency layout has no time or mutation-length scale.'));const table=el('table'),head=el('thead'),tr=el('tr');for(const text of ['Selected dependency / complete parents','Bootstrap selection','Training ancestral / co-carriers','Training unresolved categories','Evaluation ancestral / co-carriers','Evaluation unresolved categories','Ordering p / BH q','Reported-event Δ P','Exact source'])tr.append(el('th',text,{scope:'col'}));head.append(tr);table.append(head);const body=el('tbody');for(const edge of edges){const[source,target]=ids(edge),parents=edges.filter((other)=>ids(other)[1]===target).map((other)=>ids(other)[0]),row=el('tr'),frequency=edge.bootstrap?.selection_frequency,countsText=(c)=>c?`same ${c.same_cluster}; incomparable ${c.incomparable}; topology ${c.topology_ambiguous}; repeated ${c.repeated_gene_ambiguous}; mapping ${c.mapping_ambiguous}; reverse ${c.reverse_ancestor}`:'Not reported',test=edge.null?.pair_direction,difference=edge.training_reported_cooccurrence?.difference;row.append(el('td',`${source} → ${target} · parents: ${parents.join(', ')}`),el('td',frequency===undefined||frequency===null?'Not reported':`${(100*frequency).toFixed(1)}% (${edge.bootstrap.selected_count} / ${edge.bootstrap.successful_runs})`),el('td',`${edge.training?.source_ancestor} / ${edge.training?.co_carriers}`),el('td',countsText(edge.training)),el('td',`${edge.evaluation?.source_ancestor} / ${edge.evaluation?.co_carriers}`),el('td',countsText(edge.evaluation)),el('td',test?`${Number(test.p).toPrecision(3)} / ${Number(test.BH_q).toPrecision(3)}`:'Not reported'),el('td',difference===undefined?'Not reported':`${difference>=0?'+':''}${(100*difference).toFixed(1)} pp`));const cell=el('td'),details=el('details');details.append(el('summary','Inspect record'),el('pre',JSON.stringify(edge,null,2)));cell.append(details);row.append(cell);body.append(row);}table.append(body);const scroll=el('div',undefined,{class:'table-scroll'});scroll.append(table);box.append(scroll,el('p','Parents form the selected model’s joint conditioning set; multiple incoming parents are not automatically a deterministic AND gate. Positive or negative reported-event Δ P describes co-occurrence, not biological cooperation.'));}
function renderResolution(payload,analysis){
  const box=$('resolution-comparison'),table=el('table'),head=el('thead'),header=el('tr');
  for(const title of ['Driver analysis','Locked role','Genes / pairs','Co-carrier pair observations','Strict-order resolved','Same mutation cluster','Mapping unresolved','Other unresolved'])header.append(el('th',title,{scope:'col'}));
  head.append(header);table.append(head);const body=el('tbody');
  const sources=payload.comparison?[['Baseline',payload.comparison.baseline],['Expanded',payload.comparison.expanded]]:[[analysis==='baseline'?'Baseline':'Expanded',{events:model.events.length,pairs:model.pair_evidence.length,resolution:payload.resolution}]];
  for(const[label,source]of sources)for(const role of ['training','evaluation']){
    const counts=source.resolution[role],total=counts.co_carriers,resolved=counts.strict_order_resolved,row=el('tr');
    row.append(el('td',label),el('td',role),el('td',`${source.events} / ${source.pairs}`),el('td',total),el('td',`${resolved} / ${total}${total?' · '+(100*resolved/total).toFixed(1)+'%':''}`,{class:'resolution-value'}),el('td',counts.same_cluster),el('td',counts.mapping_ambiguous),el('td',total-resolved-counts.same_cluster-counts.mapping_ambiguous));body.append(row);
  }
  table.append(body);box.replaceChildren(table);
}
function renderCatalogue(){
  if(!Array.isArray(model.candidate_events))return;
  const section=$('event-mapping').closest('section'),details=el('details',undefined,{class:'diagnostics'}),retained=new Set(model.events.map(event=>event.id));
  details.append(el('summary',`Training-only candidate catalogue · ${model.candidate_events.length} genes inspected; ${retained.size} retained`));
  details.append(el('p','The configured training gate selects genes. Evaluation frequencies do not determine event retention.',{class:'catalogue-summary'}));
  const table=el('table'),head=el('thead'),header=el('tr');
  for(const text of ['Candidate gene','Training carriers','Training non-carriers','Frozen gate result'])header.append(el('th',text,{scope:'col'}));
  head.append(header);table.append(head);const body=el('tbody');
  for(const event of model.candidate_events){const row=el('tr');row.append(el('td',event.label||event.id),el('td',event.carriers_training??'Not supplied'),el('td',event.noncarriers_training??'Not supplied'),el('td',retained.has(event.id)?'Retained':event.exclusion||'Not retained'));body.append(row);}
  table.append(body);const scroll=el('div',undefined,{class:'catalogue-table table-scroll'});scroll.append(table);details.append(scroll);section.append(details);
}
function renderPredictiveCheck(){
  const check=model.validation?.holdout;
  if(typeof check?.difference_per_evaluation_patient!=='number')return;
  $('assessment').append(el('p',`Exploratory evaluation co-occurrence check: ${check.difference_per_evaluation_patient>=0?'+':''}${check.difference_per_evaluation_patient.toFixed(5)} nats per patient versus this analysis’s own training-fitted independent-event comparator. This scores reported event combinations, not chronological truth. Baseline and expanded gene universes differ, so their score differences are not a common-target improvement metric.`));
}
function simpleTable(headers,rows){
  const table=el('table'),head=el('thead'),header=el('tr');
  for(const label of headers)header.append(el('th',label,{scope:'col'}));
  head.append(header);table.append(head);const body=el('tbody');
  for(const values of rows){const row=el('tr');for(const value of values)row.append(el('td',value));body.append(row);}
  table.append(body);const scroll=el('div',undefined,{class:'table-scroll'});scroll.append(table);return scroll;
}
async function cnaRequest(path,extra={}){
  const query=new URLSearchParams({...cnaQuery,...extra}),response=await fetch(`${path}?${query}`);
  if(!response.ok)throw new Error(`Source copy-number evidence is unavailable (${response.status}); reload after verifying the source files.`);
  const payload=await response.json();
  if(cnaFingerprint&&payload.source_context_sha256&&payload.source_context_sha256!==cnaFingerprint)throw new Error('The source copy-number context changed. Reload to use one consistent source fingerprint.');
  return payload;
}
function cnaEventRows(events){
  return events.map(event=>[event.label,event.source_consequence,
    `${event.training.reported} / ${event.training.eligible}`,
    `${event.training.not_reported} / ${event.training.assay_unavailable}`,
    `${event.training.all_primary_regions_measured} / ${event.training.eligible}`,
    `${event.evaluation.reported} / ${event.evaluation.eligible}`,
    `${event.evaluation.not_reported} / ${event.evaluation.assay_unavailable}`,
    `${event.evaluation.all_primary_regions_measured} / ${event.evaluation.eligible}`]);
}
function cnaEventTable(events){return simpleTable(['Source event','Source call','Training reported / eligible','Training not reported / unavailable','Training all primary regions measured','Evaluation reported / eligible','Evaluation not reported / unavailable','Evaluation all primary regions measured'],cnaEventRows(events));}
function renderCnaTrace(){
  const body=$('cna-trace'),role=$('cna-role').value,state=$('cna-state').value;body.replaceChildren();
  if(!cnaEventPayload)return;
  let visible=0;for(const patient of cnaEventPayload.patients){
    if(role!=='all'&&patient.role!==role||state!=='all'&&patient.state!==state)continue;
    visible++;const row=el('tr'),name=el('td'),button=el('button',patient.id,{type:'button',class:'text-button'});
    button.addEventListener('click',()=>loadCnaPatient(patient.id));name.append(button);
    const assay=patient.assay,clonality=patient.source_calls.map(call=>call.is_clonal).join('; ')||'No source call';
    row.append(name,el('td',patient.role),el('td',patient.state.replaceAll('_',' ')),el('td',`${assay.primary_regions_measured} / ${assay.primary_regions_expected}`),el('td',clonality));body.append(row);
  }
  if(!visible){const row=el('tr');row.append(el('td','No source patients match these display filters.',{colspan:5}));body.append(row);}
  $('cna-trace-count').textContent=`${visible} / ${cnaEventPayload.patients.length} source patient rows shown. Filters do not change event totals.`;
}
async function chooseCnaEvent(eventId){
  cnaSelectedEvent=eventId;cnaEventPayload=null;cnaPatientSequence++;$('cna-patient-detail').replaceChildren();
  $('cna-event-summary').textContent='Loading exact source event states…';$('cna-trace').replaceChildren();
  try{
    const payload=await cnaRequest('cna-event.json',{event:eventId});
    if(cnaSelectedEvent!==eventId)return;
    cnaEventPayload=payload;const event=payload.event;
    $('cna-event-summary').textContent=`${event.label}: training ${event.training.reported} reported / ${event.training.eligible}; evaluation ${event.evaluation.reported} / ${event.evaluation.eligible}. Source clonality labels below are coarse annotations and do not place this event on a mutation-tree branch.`;
    renderCnaTrace();
  }catch(error){if(cnaSelectedEvent===eventId)$('cna-event-summary').textContent=error.message;}
}
async function loadCnaPatient(patientId){
  const sequence=++cnaPatientSequence,eventId=cnaSelectedEvent,box=$('cna-patient-detail');
  box.replaceChildren(el('p','Loading one patient’s source records…',{role:'status'}));
  try{
    const payload=await cnaRequest('cna-patient.json',{patient:patientId});
    if(sequence!==cnaPatientSequence)return;
    const patient=payload.patient,event=cnaContext.events.find(item=>item.id===eventId),assay=patient.event_assay[eventId];
    box.replaceChildren(el('h3',`${patient.patient_id} · ${patient.role} · ${event.label}`));
    box.append(el('p',`Source state: ${patient.event_states[eventId].replaceAll('_',' ')}. Target-region measurements: ${assay.primary_regions_measured} / ${assay.primary_regions_expected} expected primary regions.`));
    box.append(el('p','Source copy counts, regional sharing and clonality do not establish a comparable mutation-branch placement. Genomic overlap below is location context; it does not prove the curated call originated from that segment.',{class:'copy-number-status'}));
    const mutationPatient=model.patients.find(item=>item.id===patientId),url=mutationPatient&&nativeUrl(mutationPatient);
    if(url)box.append(el('a','Open separate published mutation tree ↗',{href:url,target:'_blank',rel:'noopener',class:'native-action'}));
    const calls=patient.source_calls.filter(call=>call.event_id===eventId),details=el('details');
    details.append(el('summary',`${calls.length} exact source call record(s), with original clonality labels`),el('pre',JSON.stringify(calls,null,2)));box.append(details);
    if(event.gene){
      const segments=await cnaRequest('cna-segments.json',{patient:patientId,event:eventId});
      if(sequence!==cnaPatientSequence)return;
      box.append(el('p',`${segments.units.length} shared genomic coordinate unit(s) overlap ${event.gene}; ${segments.artifact.coordinate_units} total panel-overlap coordinate units are retained in this patient’s source artifact. These are genomic units, not independent evolutionary events.`));
      const rows=[];for(const unit of segments.units)for(const region of unit.regional_source_rows)rows.push([`${unit.genome_build} chr${unit.chromosome}:${unit.start}–${unit.end}`,unit.overlapping_panel_genes.join(', '),region.sample,region.cnTotal,region.nMajor,region.nMinor,region.Ploidy,region.ACF,region.cpn_event_vs_ploidy,region.MSAI]);
      if(rows.length)box.append(simpleTable(['Shared source coordinates','Overlapping panel genes','Source region','Total copies','Major copies','Minor copies','Ploidy','Aberrant cell fraction','Source copy-state label','Source MSAI'],rows));
      else box.append(el('p','No deposited panel-overlap segment coordinates are available for this target. No segment placement is invented.'));
      const source=el('details');source.append(el('summary','Inspect exact selected-gene shared-segment records'),el('pre',JSON.stringify(segments,null,2)));box.append(source);
    }else{
      const wgd=el('details');wgd.append(el('summary','Inspect separate tumour and regional WGD source records'),el('pre',JSON.stringify({tumour:patient.source_wgd_tumour,regions:patient.source_wgd_regions},null,2)));box.append(wgd);
    }
  }catch(error){if(sequence===cnaPatientSequence)box.append(el('p',error.message,{class:'copy-number-status',role:'alert'}));}
}
async function loadCna(cohort,analysis){
  const box=$('copy-number-detail');cnaQuery={cohort,analysis};
  try{
    const payload=await cnaRequest('cna-context.json');cnaContext=payload.context;cnaFingerprint=payload.sha256;
    box.replaceChildren(el('p',`${cnaContext.source_panel.length} complete source-panel gene targets plus separate whole-genome doubling context. No copy-number event has a verified comparable mutation-branch assignment. CNA/WGD are excluded from the ordered model.`,{class:'copy-number-status'}));
    box.append(el('p','This source context uses the same independent patients in baseline and expanded views. “Not reported” is not verified diploid, wild type or complete gene callability; missing target measurements remain assay unavailable.'));
    const rows=['training','evaluation'].map(role=>{const c=cnaContext.coverage[role];return[role,c.patients,c.any_primary_region_with_SCNA,c.all_primary_regions_with_SCNA,c.source_WGD_tumour_record,c.patients_with_source_SCNA_regions_outside_frozen_tree];});
    box.append(simpleTable(['Locked role','Eligible patients','Any primary SCNA region','All primary SCNA regions','Source tumour WGD record','Patients with SCNA regions outside frozen tree'],rows));
    box.append(el('h3','Whole-genome doubling · separate context'),cnaEventTable(cnaContext.events.filter(event=>event.id==='WGD')));
    const catalogue=el('details');catalogue.append(el('summary',`All ${cnaContext.source_panel.length} source-panel CNA targets and coverage denominators`),cnaEventTable(cnaContext.events.filter(event=>event.id!=='WGD')));box.append(catalogue);
    const controls=el('div',undefined,{class:'cna-controls'}),label=el('label','Copy-number event'),select=el('select',undefined,{id:'cna-event'});
    for(const event of cnaContext.events)select.append(el('option',event.label,{value:event.id}));
    label.append(select);controls.append(label);box.append(controls,el('p','No source event selected',{id:'cna-event-summary',role:'status'}));
    const filters=el('div',undefined,{class:'cna-controls'});
    for(const[id,title,options]of [['cna-role','CNA patient role',[['all','Both locked roles'],['training','Training'],['evaluation','Evaluation']]],['cna-state','CNA source state',[['reported','Reported'],['all','All source states'],['not_reported','Not reported'],['assay_unavailable','Assay unavailable']]]]){
      const label=el('label',title),select=el('select',undefined,{id});for(const[value,text]of options)select.append(el('option',text,{value}));select.addEventListener('change',renderCnaTrace);label.append(select);filters.append(label);
    }
    box.append(filters,el('p','No source trace selected',{id:'cna-trace-count'}));
    const table=simpleTable(['Source patient','Locked role','Source event state','Primary target regions measured / expected','Original is_clonal label(s)'],[]);table.querySelector('tbody').id='cna-trace';box.append(table,el('div',undefined,{id:'cna-patient-detail'}));
    const audit=el('details');audit.append(el('summary','CNA source, assumptions and exact context download'),el('pre',JSON.stringify({sha256:payload.sha256,display_audit:payload.display_audit,limitations:cnaContext.limitations,provenance:cnaContext.provenance},null,2)),el('a','Download exact CNA context; patient segment artifacts are separate',{href:`source-cna-context.json?${new URLSearchParams(cnaQuery)}`,download:`tracerx-${cohort}-cna-context.json`}));box.append(audit);
    select.addEventListener('change',()=>chooseCnaEvent(select.value));
    await chooseCnaEvent(cnaContext.events[0].id);
  }catch(error){box.replaceChildren(el('p',`${error.message} No other histology, synthetic context or fabricated copy-number placement is substituted.`,{role:'alert',class:'copy-number-status'}));}
}
async function start(){
  const params=new URLSearchParams(window.location.search),values=params.getAll('cohort'),analyses=params.getAll('analysis');
  const cohort=values.length?values[0]:'luad';
  const analysis=analyses.length?analyses[0]:'expanded';
  const selector=$('cohort-select');
  const analysisSelector=$('analysis-select');
  selector.value=cohort;
  analysisSelector.value=analysis;
  const navigate=()=>{
    const next=new URL(window.location.href);
    next.search='';next.searchParams.set('cohort',selector.value);next.searchParams.set('analysis',analysisSelector.value);next.hash='';
    window.location.assign(next.href);
  };
  selector.addEventListener('change',navigate);
  analysisSelector.addEventListener('change',navigate);
  try{
    if(values.length>1||!['luad','lusc'].includes(cohort))throw new Error('Choose one supported histology using the analysis selector.');
    if(analyses.length>1||!['baseline','expanded'].includes(analysis))throw new Error('Choose one supported driver analysis.');
    const suffix=`?cohort=${cohort}&analysis=${analysis}`;
    const response=await fetch('model.json'+suffix);
    if(!response.ok)throw new Error(`Validated ${cohort.toUpperCase()} source evidence is not ready (${response.status}).`);
    const payload=await response.json();
    model=payload.model;
    if(payload.requested_cohort!==cohort||payload.requested_analysis!==analysis||model.cohort.histology!==cohort.toUpperCase())throw new Error('Requested histology or analysis does not match the source evidence.');
    treeLinks=payload.patient_tree_links||{};
    document.title=`TRACERx ${model.cohort.histology} ${analysis} evidence`;
    $('cohort').textContent=`TRACERx ${model.cohort.histology} · ${model.cohort.patient_count} independent patients · training ${model.cohort.training_count} · evaluation ${model.cohort.evaluation_count} · ${model.events.length} retained driver-gene events`;
    $('estimand').textContent=model.method.estimand;
    $('status').textContent=`${model.title} · status: ${model.model_status||'Not supplied'}`;
    $('fingerprint').textContent=`${model.cohort.histology} ${analysis} source evidence SHA256 ${payload.sha256}`;
    const native=$('native-model-link');
    native.href=payload.native_model_url;
    native.textContent=`Open ${model.cohort.histology} ${analysis} model edge list in Nextstrain ↗`;
    native.hidden=!model.events.length;
    const pairs=$('pair-select');pairs.replaceChildren();
    model.pair_evidence.forEach((pair,index)=>pairs.append(el('option',`${pairLabel(pair)} · training co-carriers ${pair.training.co_carriers}`,{value:index})));
    pairs.disabled=!model.pair_evidence.length;
    pairs.addEventListener('change',()=>choosePair(Number(pairs.value)));
    for(const[state]of states)$('state-filter').append(el('option',categoryLabel(state,'A','B'),{value:state}));
    $('role-filter').addEventListener('change',renderPatientEvidence);
    $('state-filter').addEventListener('change',renderPatientEvidence);
    $('table-role').addEventListener('change',renderAllPairs);
    const patients=$('patient-select');patients.replaceChildren();
    for(const patient of model.patients)patients.append(el('option',`${patient.id} · ${patient.role} · ${patient.n_topologies} topologies`,{value:patient.id}));
    patients.disabled=!model.patients.length;
    patients.addEventListener('change',()=>choosePatient(patients.value));
    if(model.pair_evidence.length)choosePair(0);else renderPair();
    renderAllPairs();renderEventMapping();renderAssessment();renderResolution(payload,analysis);renderCatalogue();renderPredictiveCheck();
    if(model.patients.length)choosePatient(model.patients[0].id);else renderPatientDetail();
    renderModel();
    $('limitations').replaceChildren(...(model.limitations||[]).map((text)=>el('li',text)));
    $('audit').textContent=JSON.stringify({method:model.method,cohort:model.cohort,validation:model.validation,audit:model.audit,provenance:model.provenance,display_audit:payload.display_audit},null,2);
    $('download').disabled=false;
    $('download').addEventListener('click',()=>{el('a',undefined,{href:'source-model.json'+suffix,download:`tracerx-${cohort}-${analysis}-driver-order-evidence.json`}).click();});
    await loadCna(cohort,analysis);
  }catch(error){
    $('error').hidden=false;
    $('error').textContent=`${error.message} No other histology, example or synthetic results are substituted.`;
    $('cohort').textContent='Validated source evidence unavailable';
  }
}
start();
