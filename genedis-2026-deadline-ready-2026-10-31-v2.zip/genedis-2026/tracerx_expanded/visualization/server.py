"""Read-only loopback companion for expanded and baseline TRACERx evidence."""
from pathlib import Path
import argparse
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from threading import Lock
from urllib.parse import parse_qs, urlparse

from expanded_contract import compare_sources, resolution, validate_cna_context, validate_model

ROOT = Path(__file__).resolve().parents[2]


def default_sources(root: Path = ROOT) -> dict:
    return {
        (cohort, analysis): (
            root / (f"tracerx_expanded/inference/output/{cohort}/model.json" if analysis == "expanded"
                    else f"tracerx_routes/inference/output/{'lusc/' if cohort == 'lusc' else ''}model.json"),
            root / f"tracerx_routes/visualization/output/{'lusc/' if cohort == 'lusc' else ''}patient_exports.json",
        ) for cohort in ("luad", "lusc") for analysis in ("baseline", "expanded")
    }


def make_handler(sources: dict | None = None, cna_paths: dict | None = None):
    sources = default_sources() if sources is None else sources
    static = Path(__file__).resolve().parent
    inherited = ROOT / "tracerx_routes/visualization"
    cna_paths = {cohort: ROOT / f"tracerx_expanded/source/output/{cohort}/cna_context.json" for cohort in ("luad", "lusc")} if cna_paths is None else cna_paths
    cache, lock = {}, Lock()

    def read_source(cohort, analysis):
        source_path, report_path = sources[(cohort, analysis)]
        raw = source_path.read_bytes()
        fingerprint = hashlib.sha256(raw).hexdigest()
        with lock:
            key = (cohort, analysis, fingerprint)
            if key not in cache:
                model = json.loads(raw)
                audit = validate_model(model)
                if model["cohort"]["histology"] != cohort.upper():
                    raise ValueError("Requested histology differs from source model")
                cache[key] = (model, audit, resolution(model))
            model, audit, resolved = cache[key]
        return raw, model, audit, resolved, fingerprint, report_path

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urlparse(self.path)
            query = parse_qs(parsed.query, keep_blank_values=True)
            cohorts, analyses = query.get("cohort", ["luad"]), query.get("analysis", ["expanded"])
            permitted = {"cohort", "analysis"}
            if parsed.path in {"/cna-event.json", "/cna-segments.json"}:
                permitted.add("event")
            if parsed.path in {"/cna-patient.json", "/cna-segments.json"}:
                permitted.add("patient")
            if len(cohorts) != 1 or cohorts[0] not in {"luad", "lusc"} or len(analyses) != 1 or analyses[0] not in {"baseline", "expanded"} or set(query) - permitted or any(len(values) != 1 for values in query.values()):
                self.send_error(400, "Choose exactly one histology and analysis")
                return
            cohort, analysis = cohorts[0], analyses[0]
            path = parsed.path
            try:
                if path in {"/cna-context.json", "/source-cna-context.json", "/cna-event.json", "/cna-patient.json", "/cna-segments.json"}:
                    _, model, _, _, model_hash, _ = read_source(cohort, analysis)
                    raw = cna_paths[cohort].read_bytes()
                    fingerprint = hashlib.sha256(raw).hexdigest()
                    key = ("cna", cohort, fingerprint, model_hash)
                    with lock:
                        if key not in cache:
                            context = json.loads(raw)
                            audit = validate_cna_context(context, model)
                            cache[key] = context, audit
                        context, audit = cache[key]
                    events = {event["id"]: event for event in context["events"]}
                    patients = {patient["patient_id"]: patient for patient in context["patients"]}
                    if path == "/source-cna-context.json":
                        data = raw
                    elif path == "/cna-context.json":
                        summary = {key: value for key, value in context.items() if key != "patients"}
                        summary["patients"] = [{"id": patient["patient_id"], "role": patient["role"]} for patient in context["patients"]]
                        data = json.dumps({"context": summary, "sha256": fingerprint, "display_audit": audit}, allow_nan=False).encode("utf-8")
                    else:
                        event_id, patient_id = query.get("event", [None])[0], query.get("patient", [None])[0]
                        if path in {"/cna-event.json", "/cna-segments.json"} and event_id not in events or path in {"/cna-patient.json", "/cna-segments.json"} and patient_id not in patients:
                            self.send_error(400, "Choose a source CNA event and patient")
                            return
                        if path == "/cna-event.json":
                            traces = [{"id": patient["patient_id"], "role": patient["role"],
                                       "state": patient["event_states"][event_id], "assay": patient["event_assay"][event_id],
                                       "source_calls": [call for call in patient["source_calls"] if call["event_id"] == event_id]}
                                      for patient in context["patients"]]
                            payload = {"event": events[event_id], "patients": traces, "source_context_sha256": fingerprint}
                        elif path == "/cna-patient.json":
                            payload = {"patient": patients[patient_id], "source_context_sha256": fingerprint}
                        else:
                            patient, event = patients[patient_id], events[event_id]
                            if not event.get("gene"):
                                self.send_error(400, "WGD has no target-gene segment placement")
                                return
                            artifact = patient["shared_segment_artifact"]
                            segment_path = (ROOT / artifact["path"]).resolve()
                            allowed = (ROOT / f"tracerx_expanded/source/output/{cohort}/segments").resolve()
                            if not segment_path.is_relative_to(allowed):
                                raise ValueError("Source segment artifact escaped its cohort directory")
                            segment_raw = segment_path.read_bytes()
                            if len(segment_raw) != artifact["bytes"] or hashlib.sha256(segment_raw).hexdigest() != artifact["sha256"]:
                                raise ValueError("Source segment artifact fingerprint differs")
                            segment = json.loads(segment_raw)
                            if segment["tumour_id"] != patient["tumour_id"]:
                                raise ValueError("Source segment belongs to another tumour")
                            units = segment["shared_segment_units"]
                            if len(units) != artifact["coordinate_units"] or len({unit["id"] for unit in units}) != len(units):
                                raise ValueError("Shared source segment units changed or repeated")
                            payload = {"patient_id": patient_id, "gene": event["gene"],
                                       "units": [unit for unit in units if event["gene"] in unit["overlapping_panel_genes"]],
                                       "artifact": artifact, "source_context_sha256": fingerprint}
                        data = json.dumps(payload, allow_nan=False).encode("utf-8")
                    content_type = "application/json; charset=utf-8"
                elif path in {"/model.json", "/source-model.json"}:
                    raw, model, audit, resolved, fingerprint, report_path = read_source(cohort, analysis)
                    comparison = None
                    if analysis == "expanded":
                        _, baseline, _, _, baseline_hash, _ = read_source(cohort, "baseline")
                        comparison = compare_sources(baseline, model, cohort)
                        comparison["baseline_sha256"] = baseline_hash
                    report = json.loads(report_path.read_bytes())
                    patients = {row["id"] for row in model["patients"]}
                    links = {}
                    for row in report["published_tree_exports"]:
                        patient_id = str(row["patient_id"])
                        link = urlparse(row["evidence_url"])
                        if patient_id not in patients or patient_id in links:
                            raise ValueError("Foreign or duplicate patient in tree report")
                        if link.scheme != "http" or link.netloc != "127.0.0.1:4000" or not link.path.startswith("/tracerx/patient/") or link.query or link.fragment:
                            raise ValueError("Nonlocal or invalid source-tree link")
                        links[patient_id] = row["evidence_url"]
                    if set(links) != patients:
                        raise ValueError("Source-tree report does not cover every patient")
                    native = f"http://127.0.0.1:4000/tracerx/{cohort}/{'expanded/' if analysis == 'expanded' else ''}population/edges"
                    payload = {"model": model, "sha256": fingerprint, "display_audit": audit,
                               "resolution": resolved, "comparison": comparison,
                               "patient_tree_links": links, "requested_cohort": cohort,
                               "requested_analysis": analysis, "native_model_url": native}
                    data = raw if path == "/source-model.json" else json.dumps(payload, allow_nan=False).encode("utf-8")
                    content_type = "application/json; charset=utf-8"
                elif path in {"/", "/index.html", "/app.js", "/styles.css", "/source-styles.css"}:
                    filename = "index.html" if path == "/" else path[1:]
                    source = inherited / "styles.css" if filename == "source-styles.css" else static / filename
                    data = source.read_bytes()
                    content_type = "text/javascript; charset=utf-8" if filename.endswith(".js") else "text/css; charset=utf-8" if filename.endswith(".css") else "text/html; charset=utf-8"
                else:
                    self.send_error(404)
                    return
            except (OSError, ValueError, KeyError, TypeError) as error:
                self.send_error(503, f"Validated source evidence unavailable: {error}")
                return
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self'; script-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
            if path == "/source-model.json":
                self.send_header("Content-Disposition", f'attachment; filename="tracerx-{cohort}-{analysis}-evidence.json"')
            if path == "/source-cna-context.json":
                self.send_header("Content-Disposition", f'attachment; filename="tracerx-{cohort}-source-cna-context.json"')
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, *_):
            pass

    return Handler


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=4003)
    args = parser.parse_args()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler())
    print(f"Expanded TRACERx evidence: http://127.0.0.1:{args.port}/", flush=True)
    server.serve_forever()
