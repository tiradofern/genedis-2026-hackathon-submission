"""Display-only checks for the separately frozen expanded TRACERx analyses.

This layer counts source evidence. It neither fits models nor resolves order.
"""
from __future__ import annotations

import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
_spec = importlib.util.spec_from_file_location(
    "_tracerx_original_display_contract", ROOT / "tracerx_routes/visualization/contract.py"
)
_source = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_source)
EvidenceError = _source.EvidenceError
validate_model = _source.validate_model
COUNT_FIELDS = _source.COUNT_FIELDS


def resolution(model: dict) -> dict:
    """Recount pair-observations, which reuse patients across different pairs."""
    validate_model(model)
    output = {}
    for role in ("training", "evaluation"):
        totals = {key: sum(pair[role][key] for pair in model["pair_evidence"])
                  for key in ("co_carriers", "strict_order_resolved", *COUNT_FIELDS)}
        if sum(totals[key] for key in COUNT_FIELDS) != totals["co_carriers"]:
            raise EvidenceError("Pair category totals do not partition observations")
        output[role] = totals
    return output


def compare_sources(baseline: dict, expanded: dict, cohort: str) -> dict:
    """Reject changed patient roles or a silent histology mixture."""
    for model in (baseline, expanded):
        validate_model(model)
        if model["cohort"]["histology"] != cohort.upper():
            raise EvidenceError("Requested histology differs from source evidence")
    roles = lambda model: {row["id"]: row["role"] for row in model["patients"]}
    if roles(baseline) != roles(expanded):
        raise EvidenceError("Baseline and expanded patient identities or locked roles differ")
    old_events = {row["id"]: row for row in baseline["events"]}
    new_events = {row["id"]: row for row in expanded["events"]}
    if not set(old_events) <= set(new_events):
        raise EvidenceError("Expanded catalogue lost a previously retained baseline event")
    for gene, old in old_events.items():
        for key in ("carriers_training", "carriers_evaluation", "uniquely_mapped_training", "uniquely_mapped_evaluation"):
            if old.get(key) != new_events[gene].get(key):
                raise EvidenceError("A shared event's source presence or placement changed")
    new_pairs = {frozenset(_source.pair_ids(row)): row for row in expanded["pair_evidence"]}
    for old in baseline["pair_evidence"]:
        a, b = _source.pair_ids(old)
        new = new_pairs[frozenset((a, b))]
        flipped = _source.pair_ids(new)[0] != a
        for role in ("training", "evaluation"):
            for key in ("co_carriers", "strict_order_resolved", *COUNT_FIELDS):
                target = {"source_ancestor": "reverse_ancestor", "reverse_ancestor": "source_ancestor"}.get(key, key) if flipped else key
                if old[role][key] != new[role][target]:
                    raise EvidenceError("A shared pair's categorical source evidence changed")
    return {
        "same_independent_patients_and_roles": True,
        "shared_baseline_source_event_and_pair_counts_unchanged": True,
        "baseline": {"events": len(baseline["events"]), "pairs": len(baseline["pair_evidence"]),
                     "resolution": resolution(baseline)},
        "expanded": {"events": len(expanded["events"]), "pairs": len(expanded["pair_evidence"]),
                     "resolution": resolution(expanded)},
        "interpretation": "Pair observations reuse patients across pairs; different event universes have different denominators. A larger count is not validation of shared chronology.",
    }


def validate_cna_context(context: dict, model: dict) -> dict:
    """Recount source three-state presence and coverage; no CNA ordering model."""
    if context.get("histology") != model["cohort"]["histology"]:
        raise EvidenceError("Copy-number context histology differs from the mutation analysis")
    if context.get("order_status") != "presence_only_no_comparable_branch_placement":
        raise EvidenceError("CNA context has no verified comparable branch assignment")
    patients = context.get("patients", [])
    roles = {row["patient_id"]: row["role"] for row in patients}
    if len(roles) != len(patients) or roles != {row["id"]: row["role"] for row in model["patients"]} or context.get("patient_count") != len(roles):
        raise EvidenceError("CNA patient identities or locked roles differ from mutation source")
    events = {event["id"]: event for event in context.get("events", [])}
    panel = {row["gene"]: row["type"] for row in context.get("source_panel", [])}
    if len(events) != len(context.get("events", [])) or len(panel) != len(context.get("source_panel", [])):
        raise EvidenceError("Repeated CNA event or source panel identity")
    expected = {("AMP:" if role == "OG" else "HOMDEL:") + gene for gene, role in panel.items()} | {"WGD"}
    if set(events) != expected or set(panel.values()) - {"OG", "TSG"}:
        raise EvidenceError("CNA catalogue differs from the complete source role-defined panel plus WGD")
    for event_id, event in events.items():
        consequence = "GD" if event_id == "WGD" else "Amp" if event_id.startswith("AMP:") else "Homdel"
        gene = None if event_id == "WGD" else event_id.split(":", 1)[1]
        if event["source_consequence"] != consequence or event.get("gene") != gene:
            raise EvidenceError("CNA event source consequence or exact gene identity changed")
    for patient in patients:
        if patient.get("histology") != context["histology"] or patient.get("ordered_CNA_events") != []:
            raise EvidenceError("CNA context mixed histology or invented an ordered event")
        if set(patient["event_states"]) != set(events) or set(patient["event_assay"]) != set(events):
            raise EvidenceError("CNA patient trace omits an event state or assay state")
        reported = set()
        for call in patient["source_calls"]:
            event_id = call["event_id"]
            if event_id not in events or call.get("type") != "copy_number" or call.get("is_driver") != "TRUE" or call.get("consequence") != events[event_id]["source_consequence"]:
                raise EvidenceError("CNA trace contains an unsupported source curated call")
            reported.add(event_id)
        for event_id, state in patient["event_states"].items():
            measured = patient["event_assay"][event_id]["any_regional_measurement"]
            expected_state = "reported" if event_id in reported else "not_reported" if measured else "assay_unavailable"
            if not isinstance(measured, bool) or state != expected_state:
                raise EvidenceError("CNA reported, unreported and unavailable states were conflated")
    for event_id, event in events.items():
        if "no_comparable_branch_placement" not in event.get("order_status", ""):
            raise EvidenceError("A CNA event claims an unsupported branch position")
        for role in ("training", "evaluation"):
            subset = [patient for patient in patients if patient["role"] == role]
            source = event[role]
            for state in ("reported", "not_reported", "assay_unavailable"):
                expected_count = sum(patient["event_states"][event_id] == state for patient in subset)
                if source[state] != expected_count:
                    raise EvidenceError("CNA event aggregate differs from independent patient states")
            if source["eligible"] != len(subset):
                raise EvidenceError("CNA event denominator differs from locked patient role")
            for field, predicate in (
                ("source_measurement_present", lambda p: p["event_assay"][event_id]["any_regional_measurement"]),
                ("all_primary_regions_measured", lambda p: p["event_assay"][event_id]["all_primary_regions_measured"]),
                ("reported_without_measurement", lambda p: p["event_states"][event_id] == "reported" and not p["event_assay"][event_id]["any_regional_measurement"]),
            ):
                if source[field] != sum(bool(predicate(patient)) for patient in subset):
                    raise EvidenceError("CNA source assay coverage differs from patient records")
    for role in ("training", "evaluation"):
        subset = [patient for patient in patients if patient["role"] == role]
        expected_coverage = {
            "patients": len(subset),
            "any_primary_region_with_SCNA": sum(bool(patient["primary_regions_with_SCNA"]) for patient in subset),
            "all_primary_regions_with_SCNA": sum(patient["all_primary_regions_with_SCNA"] for patient in subset),
            "source_WGD_tumour_record": sum(bool(patient["source_wgd_tumour"]) for patient in subset),
            "patients_with_source_SCNA_regions_outside_frozen_tree": sum(bool(patient["source_SCNA_regions_not_in_frozen_tree"]) for patient in subset),
        }
        if context["coverage"][role] != expected_coverage:
            raise EvidenceError("CNA regional coverage summary differs from patient records")
    return {"patients": len(patients), "gene_targets": len(panel), "context_events": len(events),
            "three_state_counts_recounted": True, "CNA_ordered_votes_created": False,
            "shared_genomic_segments_are_independent_events": False}
