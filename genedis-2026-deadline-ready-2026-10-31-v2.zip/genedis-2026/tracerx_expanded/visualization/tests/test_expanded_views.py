"""Fictional boundary fixtures and actual local source-display invariants."""
import copy
import importlib.util
import itertools
import json
from http.server import ThreadingHTTPServer
from pathlib import Path
import sys
import tempfile
from threading import Thread
import unittest
from urllib.error import HTTPError
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "tracerx_expanded/visualization"))
from expanded_contract import EvidenceError, compare_sources, resolution, validate_cna_context
spec = importlib.util.spec_from_file_location("expanded_readonly_server", ROOT / "tracerx_expanded/visualization/server.py")
server_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(server_module)
make_handler = server_module.make_handler


def fixture(histology="LUAD"):
    patients = [{"id": "Fictional-1", "role": "training", "n_regions": 2,
                 "n_topologies": 1, "events": [{"gene": "A"}, {"gene": "B"}],
                 "relations": [{"a": "A", "b": "B", "state": "same_cluster"}]},
                {"id": "Fictional-2", "role": "evaluation", "n_regions": 2,
                 "n_topologies": 2, "events": [{"gene": "A"}, {"gene": "B"}],
                 "relations": [{"a": "A", "b": "B", "state": "mapping_ambiguous"}]}]
    fields = ["source_ancestor", "reverse_ancestor", "same_cluster", "incomparable",
              "topology_ambiguous", "repeated_gene_ambiguous", "mapping_ambiguous"]
    pair = {"a": "A", "b": "B"}
    for role, state in (("training", "same_cluster"), ("evaluation", "mapping_ambiguous")):
        pair[role] = dict.fromkeys(fields, 0)
        pair[role].update(co_carriers=1, strict_order_resolved=0)
        pair[role][state] = 1
    return {"model_id": "fictional-boundary", "title": "Explicit fictional fixture",
            "method": {"name": "Fictional", "estimand": "Boundary check"},
            "cohort": {"histology": histology, "patient_count": 2, "training_count": 1, "evaluation_count": 1},
            "patients": patients, "events": [{"id": gene, "label": gene, "carriers_training": 1,
                                               "carriers_evaluation": 1} for gene in "AB"],
            "pair_evidence": [pair], "edges": []}


def cna_fixture(histology="LUAD"):
    events = [{"id": "AMP:A", "label": "A amplification", "gene": "A", "source_consequence": "Amp"},
              {"id": "HOMDEL:B", "label": "B homozygous deletion", "gene": "B", "source_consequence": "Homdel"},
              {"id": "WGD", "label": "Whole genome doubling", "gene": None, "source_consequence": "GD"}]
    patients = []
    for i, role in enumerate(("training", "evaluation")):
        states = {"AMP:A": "reported" if i == 0 else "assay_unavailable", "HOMDEL:B": "not_reported", "WGD": "reported" if i == 0 else "not_reported"}
        assay = {event["id"]: {"any_regional_measurement": not (i == 1 and event["id"] == "AMP:A"),
                                 "all_primary_regions_measured": not (i == 1 and event["id"] == "AMP:A"),
                                 "primary_regions_expected": 2, "primary_regions_measured": 0 if i == 1 and event["id"] == "AMP:A" else 2}
                 for event in events}
        calls = [{"event_id": event["id"], "is_driver": "TRUE", "type": "copy_number", "consequence": event["source_consequence"], "is_clonal": "TRUE"} for event in events if states[event["id"]] == "reported"]
        patients.append({"patient_id": f"Fictional-{i+1}", "tumour_id": f"Fictional-{i+1}", "role": role, "histology": histology,
                         "event_states": states, "event_assay": assay, "source_calls": calls, "ordered_CNA_events": [],
                         "primary_regions_with_SCNA": ["Fictional-R1", "Fictional-R2"], "all_primary_regions_with_SCNA": True,
                         "source_wgd_tumour": {"source_record": "Fictional"}, "source_SCNA_regions_not_in_frozen_tree": []})
    for event in events:
        event["order_status"] = "presence_only_no_comparable_branch_placement"
        for patient in patients:
            event_id = event["id"]
            measured = patient["event_assay"][event_id]["any_regional_measurement"]
            event[patient["role"]] = {"eligible": 1, **{state: int(patient["event_states"][event_id] == state) for state in ("reported", "not_reported", "assay_unavailable")},
                                      "source_measurement_present": int(measured), "all_primary_regions_measured": int(measured), "reported_without_measurement": 0}
    coverage = {role: {"patients": 1, "any_primary_region_with_SCNA": 1, "all_primary_regions_with_SCNA": 1, "source_WGD_tumour_record": 1, "patients_with_source_SCNA_regions_outside_frozen_tree": 0} for role in ("training", "evaluation")}
    return {"histology": histology, "patient_count": 2, "order_status": "presence_only_no_comparable_branch_placement",
            "source_panel": [{"gene": "A", "type": "OG"}, {"gene": "B", "type": "TSG"}],
            "events": events, "patients": patients, "coverage": coverage}


class ExpandedContractTests(unittest.TestCase):
    def test_cna_presence_absence_missingness_and_no_fabricated_order(self):
        context = cna_fixture()
        self.assertEqual(validate_cna_context(context, fixture())["context_events"], 3)
        for field, value, message in (("ordered_CNA_events", ["AMP:A"], "invented"),
                                      ("event_states", {"AMP:A": "not_reported", "HOMDEL:B": "not_reported", "WGD": "reported"}, "conflated")):
            changed = copy.deepcopy(context)
            changed["patients"][0][field] = value
            with self.assertRaisesRegex(EvidenceError, message):
                validate_cna_context(changed, fixture())
        changed = copy.deepcopy(context)
        changed["events"][1]["source_consequence"] = "Del"
        with self.assertRaisesRegex(EvidenceError, "consequence"):
            validate_cna_context(changed, fixture())
        changed = copy.deepcopy(context)
        changed["events"][0]["evaluation"]["assay_unavailable"] = 0
        with self.assertRaisesRegex(EvidenceError, "aggregate"):
            validate_cna_context(changed, fixture())

    def test_resolution_retains_unresolved_and_original_denominator(self):
        actual = resolution(fixture())
        self.assertEqual(actual["training"]["co_carriers"], 1)
        self.assertEqual(actual["training"]["strict_order_resolved"], 0)
        self.assertEqual(actual["training"]["same_cluster"], 1)
        self.assertEqual(actual["evaluation"]["mapping_ambiguous"], 1)

    def test_comparison_rejects_patient_role_drift_and_histology_pooling(self):
        baseline, expanded = fixture(), fixture()
        self.assertTrue(compare_sources(baseline, expanded, "luad")["same_independent_patients_and_roles"])
        expanded["patients"][0]["id"] = "Another-fictional-patient"
        with self.assertRaisesRegex(EvidenceError, "identities or locked roles"):
            compare_sources(baseline, expanded, "luad")
        with self.assertRaisesRegex(EvidenceError, "histology"):
            compare_sources(baseline, fixture("LUSC"), "luad")

    def test_four_sources_exact_downloads_and_safe_query_boundary(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            sources = {}
            for cohort, analysis in itertools.product(("luad", "lusc"), ("baseline", "expanded")):
                path = folder / f"{cohort}-{analysis}.json"
                model = fixture(cohort.upper())
                model["title"] += " " + analysis
                raw = (json.dumps(model, indent=3) + "\n").encode()
                path.write_bytes(raw)
                report = folder / f"{cohort}-trees.json"
                report.write_text(json.dumps({"published_tree_exports": [{"patient_id": p["id"], "evidence_url": f"http://127.0.0.1:4000/tracerx/patient/fictional-{i}"} for i, p in enumerate(model["patients"])]}))
                sources[(cohort, analysis)] = path, report
            server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(sources))
            thread = Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                url = f"http://127.0.0.1:{server.server_port}"
                for (cohort, analysis), (path, _) in sources.items():
                    query = f"?cohort={cohort}&analysis={analysis}"
                    with urlopen(url + "/source-model.json" + query) as response:
                        self.assertEqual(response.read(), path.read_bytes())
                    with urlopen(url + "/model.json" + query) as response:
                        payload = json.load(response)
                    self.assertEqual(payload["requested_analysis"], analysis)
                    self.assertEqual(payload["model"]["cohort"]["histology"], cohort.upper())
                for path, status in (("/model.json?cohort=all", 400), ("/model.json?analysis=all", 400),
                                     ("/model.json?cohort=luad&cohort=lusc", 400), ("/model.json?extra=x", 400),
                                     ("/../source/raw/data.json", 404)):
                    with self.assertRaises(HTTPError) as caught:
                        urlopen(url + path)
                    self.assertEqual(caught.exception.code, status)
                missing, _ = sources[("luad", "expanded")]
                missing.unlink()
                with self.assertRaises(HTTPError) as caught:
                    urlopen(url + "/model.json?cohort=luad&analysis=expanded")
                self.assertEqual(caught.exception.code, 503)
            finally:
                server.shutdown()
                thread.join()
                server.server_close()

    def test_actual_sources_preserve_locked_cohorts_and_full_categories(self):
        for cohort in ("luad", "lusc"):
            baseline = ROOT / f"tracerx_routes/inference/output/{'lusc/' if cohort == 'lusc' else ''}model.json"
            expanded = ROOT / f"tracerx_expanded/inference/output/{cohort}/model.json"
            if not expanded.exists():
                self.skipTest("Actual frozen expanded result is not yet available")
            comparison = compare_sources(json.loads(baseline.read_bytes()), json.loads(expanded.read_bytes()), cohort)
            self.assertTrue(comparison["same_independent_patients_and_roles"])

    def test_cna_http_is_summary_first_with_exact_source_and_safe_patient_ids(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            sources, cna_paths = {}, {}
            for cohort in ("luad", "lusc"):
                path = folder / f"{cohort}-model.json"
                model = fixture(cohort.upper())
                path.write_text(json.dumps(model))
                report = folder / f"{cohort}-trees.json"
                report.write_text(json.dumps({"published_tree_exports": [{"patient_id": p["id"], "evidence_url": f"http://127.0.0.1:4000/tracerx/patient/fictional-{i}"} for i, p in enumerate(model["patients"])]}))
                for analysis in ("baseline", "expanded"):
                    sources[(cohort, analysis)] = path, report
                cna_path = folder / f"{cohort}-cna.json"
                cna_path.write_text(json.dumps(cna_fixture(cohort.upper()), indent=2))
                cna_paths[cohort] = cna_path
            server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(sources, cna_paths))
            thread = Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                url = f"http://127.0.0.1:{server.server_port}"
                for cohort, analysis in itertools.product(("luad", "lusc"), ("baseline", "expanded")):
                    query = f"?cohort={cohort}&analysis={analysis}"
                    with urlopen(url + "/cna-context.json" + query) as response:
                        payload = json.load(response)
                    self.assertEqual(payload["context"]["histology"], cohort.upper())
                    self.assertEqual(payload["context"]["patients"], [{"id": "Fictional-1", "role": "training"}, {"id": "Fictional-2", "role": "evaluation"}])
                    self.assertNotIn("event_states", payload["context"]["patients"][0])
                    with urlopen(url + "/source-cna-context.json" + query) as response:
                        self.assertEqual(response.read(), cna_paths[cohort].read_bytes())
                    with urlopen(url + "/cna-event.json" + query + "&event=AMP%3AA") as response:
                        traces = json.load(response)["patients"]
                    self.assertEqual([p["state"] for p in traces], ["reported", "assay_unavailable"])
                    with urlopen(url + "/cna-patient.json" + query + "&patient=Fictional-1") as response:
                        patient = json.load(response)["patient"]
                    self.assertEqual(patient["ordered_CNA_events"], [])
                for path in ("/cna-patient.json?patient=../foreign", "/cna-event.json?event=foreign", "/cna-event.json?event=AMP%3AA&event=WGD", "/cna-segments.json?event=WGD&patient=Fictional-1"):
                    with self.assertRaises(HTTPError) as caught:
                        urlopen(url + path)
                    self.assertEqual(caught.exception.code, 400)
                cna_paths["lusc"] = cna_paths["luad"]
                with self.assertRaises(HTTPError) as caught:
                    urlopen(url + "/cna-context.json?cohort=lusc")
                self.assertEqual(caught.exception.code, 503)
            finally:
                server.shutdown()
                thread.join()
                server.server_close()

    def test_actual_cna_counts_match_each_mutation_cohort_without_order(self):
        for cohort, analysis in itertools.product(("luad", "lusc"), ("baseline", "expanded")):
            model_path = server_module.default_sources()[(cohort, analysis)][0]
            context_path = ROOT / f"tracerx_expanded/source/output/{cohort}/cna_context.json"
            if not model_path.exists() or not context_path.exists():
                self.skipTest("Actual frozen local model/context is unavailable")
            audit = validate_cna_context(json.loads(context_path.read_bytes()), json.loads(model_path.read_bytes()))
            self.assertEqual(audit["context_events"], 68)
            self.assertFalse(audit["CNA_ordered_votes_created"])

    def test_actual_native_expanded_models_match_exact_sources_and_official_schema(self):
        sys.path.insert(0, str(ROOT / "nextstrain/tests"))
        from schema_validation import validate_dataset
        from native_models import validate_projection
        for cohort in ("luad", "lusc"):
            model_path = ROOT / f"tracerx_expanded/inference/output/{cohort}/model.json"
            native_path = ROOT / f"nextstrain/datasets/tracerx_{cohort}_expanded_population_edges.json"
            if not model_path.exists() or not native_path.exists():
                self.skipTest("Actual expanded model/native export is unavailable")
            model, dataset = json.loads(model_path.read_bytes()), json.loads(native_path.read_bytes())
            validate_dataset(dataset)
            self.assertEqual(validate_projection(model, dataset)["source_edges"], len(model["edges"]))
            self.assertIn("expanded SNV/indel", dataset["meta"]["title"])
            self.assertIn("do not create arrows or clone placements", dataset["meta"]["description"])


if __name__ == "__main__":
    unittest.main()
