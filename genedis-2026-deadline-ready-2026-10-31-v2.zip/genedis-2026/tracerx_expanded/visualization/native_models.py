"""Add separately named genuine Auspice projections of expanded SNV/indel models.

Reuse the loss-audited baseline renderer without altering any previous dataset.
Copy-number context never creates a mutation-tree position or model arrow here.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tracerx_routes/visualization"))
from population_forest import convert, validate_projection


def export(cohort: str, *, root: Path = ROOT) -> dict:
    path = root / f"tracerx_expanded/inference/output/{cohort}/model.json"
    raw = path.read_bytes()
    model = json.loads(raw)
    if model["cohort"]["histology"] != cohort.upper():
        raise ValueError("Requested histology differs from the source model")
    fingerprint = hashlib.sha256(raw).hexdigest()
    dataset = convert(model, source_sha256=fingerprint,
                      companion_url=f"http://127.0.0.1:4003/?cohort={cohort}&analysis=expanded")
    if dataset is None:
        return {"cohort": cohort, "exported": False, "reason": "No real retained events"}
    dataset["meta"]["title"] = f"TRACERx {cohort.upper()} expanded SNV/indel model — independent abstract edge components; unitless positions"
    dataset["meta"]["description"] += (
        "\n\n**Expanded source-curated SNV/indel analysis.** Previous baseline models remain separate. "
        "Copy-number calls and WGD are separate source context and do not create arrows or clone placements in this model. "
        "The evaluation patients have been inspected in prior analyses; this is an exploratory sequential assessment, not independent external validation."
    )
    audit = validate_projection(model, dataset)
    output = root / f"nextstrain/datasets/tracerx_{cohort}_expanded_population_edges.json"
    if output.exists():
        previous = json.loads(output.read_bytes())
        if previous.get("meta", {}).get("extensions", {}).get("tracerx_population_model", {}).get("source_model_sha256") != fingerprint:
            raise ValueError("A different expanded model already owns this native route; preserve and version it before replacing")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(dataset, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    return {"cohort": cohort, "exported": True, "source_model_sha256": fingerprint,
            "dataset": str(output), "audit": audit}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohort", choices=("luad", "lusc"), required=True)
    args = parser.parse_args()
    print(json.dumps(export(args.cohort), indent=2))
