# Independent read-only check of unchanged official ASCETIC fitted objects.
args <- commandArgs(trailingOnly=TRUE)
if (length(args) != 1L) stop("Usage: test_official_fit.R REPOSITORY_ROOT")
root <- normalizePath(args[1], winslash="/", mustWork=TRUE)
.libPaths(c(file.path(root,"tracerx_routes/inference/.rlibrary"),
            file.path(root,"population_routes/inference/.rlibrary"), .Library))
reviews <- list()
for (cohort in c("luad","lusc")) {
  output <- file.path(root,"tracerx_expanded/inference/output",cohort)
  input <- jsonlite::fromJSON(file.path(output,"engine_inputs.json"),simplifyVector=FALSE)
  fitted <- readRDS(file.path(output,"official_ascetic_fit.rds"))
  final <- jsonlite::fromJSON(file.path(output,"model.json"),simplifyVector=FALSE)
  events <- unlist(input$events,use.names=FALSE)
  records <- Filter(function(patient) patient$role == "training", input$patients)
  evaluation <- Filter(function(patient) patient$role == "evaluation", input$patients)
  ids <- vapply(records,function(patient) patient$id,"")
  evaluationIds <- vapply(evaluation,function(patient) patient$id,"")
  expected <- matrix(0L,length(records),length(events),dimnames=list(ids,events))
  for (i in seq_along(records)) {
    patient <- records[[i]]
    present <- unlist(patient$present,use.names=FALSE)
    expected[i,present] <- 1L
    order <- matrix(0L,length(present),length(present),dimnames=list(present,present))
    for (arrow in patient$arrows) order[arrow[[1]],arrow[[2]]] <- 1L
    actual <- fitted$models[[ids[i]]]
    if (!identical(dimnames(actual),dimnames(order)) || !all(actual == order)) stop("A saved official patient-order matrix differs from frozen input")
  }
  stopifnot(identical(dimnames(fitted$dataset),dimnames(expected)),all(fitted$dataset == expected))
  stopifnot(!any(evaluationIds %in% rownames(fitted$dataset)), !any(evaluationIds %in% names(fitted$models)))
  indexNames <- as.character(seq_along(events))
  adjacency <- fitted$inference$aic
  stopifnot(identical(rownames(adjacency),indexNames),identical(colnames(adjacency),indexNames))
  where <- which(adjacency == 1L,arr.ind=TRUE)
  expectedEdges <- sort(vapply(seq_len(nrow(where)),function(i) paste(events[where[i,1]],events[where[i,2]],sep="->"),""))
  actualEdges <- sort(vapply(final$edges,function(edge) paste(edge$source,edge$target,sep="->"),""))
  stopifnot(identical(expectedEdges,actualEdges))
  reviews[[cohort]] <- list(training_patients=length(records),evaluation_patients_excluded=length(evaluationIds),
    mutation_event_columns=length(events),saved_patient_order_matrices_matched=length(records),
    selected_edges_matched=length(actualEdges),CNA_columns_added=FALSE,
    dataset_and_all_patient_orders_equal_frozen_input=TRUE,official_numeric_indexing_confirmed=TRUE,
    model_md5=unname(tools::md5sum(file.path(output,"model.json"))),
    engine_inputs_md5=unname(tools::md5sum(file.path(output,"engine_inputs.json"))),
    official_fit_rds_md5=unname(tools::md5sum(file.path(output,"official_ascetic_fit.rds"))))
}
jsonlite::write_json(reviews,file.path(root,"tracerx_expanded/inference/official_fit_review.json"),
  pretty=TRUE,auto_unbox=TRUE,null="null")
cat("Both official expanded RDS datasets, all 240 patient-order matrices, evaluation exclusions and all nine selected dependencies matched frozen inputs.\n")
