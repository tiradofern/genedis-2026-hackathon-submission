"""Additive training-only expansion of source-curated point-mutation events.

Original LUAD/LUSC inputs, fitted artifacts and software remain immutable. Copy
number context is a separately audited source layer, never a fabricated order.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
from itertools import combinations
import json
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = ROOT / "tracerx_routes/inference"
sys.path.insert(0, str(BASE))
from evidence import consensus_gene_relations, counts, joint_holdout, ordering_null, split_patients
from prepare_inputs import validate_source


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: dict | list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8", newline="\n")


def load_frozen(config_path: Path) -> tuple[dict, dict, dict, dict]:
    """Require a pre-fit lock and the exact baseline source/model/split."""
    config = json.loads(config_path.read_text())
    if config["primary_cohort"] not in {"LUAD", "LUSC"}:
        raise ValueError("One separately configured LUAD or LUSC cohort is required")
    spec = config["baseline"]
    source_path, model_path = ROOT / spec["source_path"], ROOT / spec["model_path"]
    source = json.loads(source_path.read_text())
    baseline = json.loads(model_path.read_text())
    old_path = ROOT / spec["config_path"]
    old_config = json.loads(old_path.read_text())
    if sha(source_path) != spec["source_sha256"] or sha(model_path) != spec["model_sha256"] or sha(old_path) != spec["config_sha256"]:
        raise ValueError("A baseline source, model or configuration changed")
    validate_source(source, old_config, sha(old_path))
    if config["primary_cohort"] != old_config["primary_cohort"] or config["split"] != old_config["split"] or config["eligibility"] != old_config["eligibility"]:
        raise ValueError("Expanded analysis cannot change original eligibility or patient roles")
    roles = split_patients([row["patient_id"] for row in source["patients"]], config)
    if roles != {row["id"]: row["role"] for row in baseline["patients"]}:
        raise ValueError("Patient identifiers or fixed roles differ from the frozen baseline")
    lock_path = ROOT / config["freeze_record"]
    lock = json.loads(lock_path.read_text())
    if not any(row["path"] == config_path.relative_to(ROOT).as_posix() and row["sha256"] == sha(config_path) for row in lock["configurations"]):
        raise ValueError("Expanded configuration is absent from the pre-fit freeze record")
    if config["events"]["candidate_universe"] != "all_author_curated_DriverMut_TRUE_training_genes":
        raise ValueError("Unsupported expanded event universe")
    return config, source, baseline, roles


def candidate_genes(source: dict, roles: dict[str, str]) -> list[str]:
    """Evaluation genes and counts cannot influence feature selection."""
    result = set()
    for patient in source["patients"]:
        if roles[patient["patient_id"]] != "training":
            continue
        for row in patient["drivers"]:
            if row.get("source_driver") is not True:
                raise ValueError("Noncurated mutation in the expanded source driver list")
            if not isinstance(row["gene"], str) or not row["gene"].strip():
                raise ValueError("Driver event lacks an exact source gene symbol")
            result.add(row["gene"])
    return sorted(result)


def prepare(config_path: Path, output: Path) -> dict:
    config, source, baseline, roles = load_frozen(config_path)
    if not output.resolve().is_relative_to((HERE / "output").resolve()):
        raise ValueError("Expanded outputs must stay inside the new ignored output directory")
    candidates = candidate_genes(source, roles)
    derived = {row["patient_id"]: consensus_gene_relations(row, candidates) for row in source["patients"]}
    training_counts = Counter(event["gene"] for patient in source["patients"] if roles[patient["patient_id"]] == "training" for event in derived[patient["patient_id"]]["events"])
    n_training = config["split"]["training_participants"]
    candidate_rows = []
    for gene in candidates:
        n = training_counts[gene]
        eligible = n >= config["events"]["minimum_training_carriers"] and n_training-n >= config["events"]["minimum_training_noncarriers"]
        candidate_rows.append({"id": gene, "label": gene, "event_type": "curated_SNV_indel", "carriers_training": n,
            "noncarriers_training": n_training-n, "eligible": eligible,
            "exclusion": None if eligible else "Frozen training carrier/noncarrier frequency gate; not negative biological evidence"})
    selected = [row["id"] for row in candidate_rows if row["eligible"]]
    patients = []
    for row in source["patients"]:
        detail = derived[row["patient_id"]]
        patients.append({"id": row["patient_id"], "tumour_id": row["tumour_id"], "histology": row["histology"],
            "role": roles[row["patient_id"]], "n_regions": row["n_regions"], "n_primary_regions": row["n_primary_regions"],
            "n_ln_regions": row["n_ln_regions"], "n_topologies": row["n_topologies"], "region_ids": row["region_ids"],
            "treatment": row["treatment"], "evidence_url": "http://127.0.0.1:4000/tracerx/patient/" + row["tumour_id"].lower(),
            "canonical_warning": "Displayed corrected topology is one source-selected alternative; ordered votes require all alternatives to agree.",
            "events": [event for event in detail["events"] if event["gene"] in selected],
            "relations": [pair for pair in detail["relations"] if pair["a"] in selected and pair["b"] in selected]})
    training = [row for row in patients if row["role"] == "training"]
    evaluation = [row for row in patients if row["role"] == "evaluation"]
    events = []
    for gene in selected:
        original = next(row for row in candidate_rows if row["id"] == gene)
        events.append({**original, "carriers_evaluation": sum(any(event["gene"] == gene for event in patient["events"]) for patient in evaluation),
            "uniquely_mapped_training": sum(any(event["gene"] == gene and event["mapping_status"] == "unique_cluster" for event in patient["events"]) for patient in training),
            "uniquely_mapped_evaluation": sum(any(event["gene"] == gene and event["mapping_status"] == "unique_cluster" for event in patient["events"]) for patient in evaluation),
            "eligible_denominator_training": len(training), "eligible_denominator_evaluation": len(evaluation),
            "definition": config["events"]["definition"], "absence_meaning": config["events"]["zero"]})
    pairs = [{"a": a, "b": b, "training": counts(training, a, b), "evaluation": counts(evaluation, a, b)} for a, b in combinations(selected, 2)]
    cohort = config["primary_cohort"].lower()
    code = {"expanded_wrapper_sha256": sha(Path(__file__)), "evidence_code_sha256": sha(BASE / "evidence.py"),
        "source_validator_sha256": sha(BASE / "prepare_inputs.py"), "engine_wrapper_sha256": sha(BASE / "run_ascetic.R"),
        "runtime_lock_sha256": sha(BASE / "runtime_lock.json")}
    model = {"schema_version": "1.0", "model_id": f"tracerx_expanded_{cohort}_v0_1",
        "title": f"TRACERx {cohort.upper()}: expanded source-curated point-mutation events",
        "model_status": "prepared_not_fitted", "method": {"name": "Strict all-alternative source ancestry; expanded source-curated driver-gene universe; ASCETIC secondary model",
            "estimand": config["question"], "input_adaptation": config["engine"]["input_adaptation"],
            "assumptions": ["Author-curated DriverMut annotations are reused, not independently validated", "Same-cluster and separate-branch events receive no invented order", "All evaluation-selected results are exploratory and cannot be a fresh independent confirmation of prior analysis", "CNAs lacking comparable branch placement remain separate source context"]},
        "cohort": baseline["cohort"], "candidate_events": candidate_rows, "events": events,
        "pair_evidence": pairs, "patients": patients, "edges": [],
        "provenance": {"source": source["provenance"], "configuration_sha256": sha(config_path),
            "baseline": config["baseline"], "freeze_record_sha256": sha(ROOT / config["freeze_record"]), **code},
        "limitations": baseline["limitations"] + [
            "Expanded training-only source-curated driver universe is a new exploratory analysis after the original held-out results were inspected; fixed roles prevent direct tuning but do not make this a pristine confirmatory holdout.",
            "Copy-number source records without validated comparable branch placement supply presence context only, no CNA/SNV or CNA/CNA ancestry votes.",
            "More candidate events increase multiplicity and may not increase the number of resolved co-carrier orders."]}
    inputs = {"events": selected, "patients": []}
    for patient in patients:
        arrows = [[pair["a"], pair["b"]] if pair["state"] == "a_ancestor_b" else [pair["b"], pair["a"]] for pair in patient["relations"] if pair["state"] in {"a_ancestor_b", "b_ancestor_a"}]
        inputs["patients"].append({"id": patient["id"], "role": patient["role"], "present": [event["gene"] for event in patient["events"]],
            "unique": [event["gene"] for event in patient["events"] if event["mapping_status"] == "unique_cluster"], "arrows": arrows})
    write_json(output / "engine_inputs.json", inputs)
    model["provenance"]["engine_inputs_sha256"] = sha(output / "engine_inputs.json")
    write_json(output / "prepared_evidence.json", model)
    snapshot = output / "reproducibility_snapshot"
    snapshot.mkdir(exist_ok=True)
    for path in (config_path, ROOT / config["baseline"]["source_path"], ROOT / config["freeze_record"], Path(__file__), BASE / "evidence.py", BASE / "prepare_inputs.py", BASE / "run_ascetic.R", BASE / "runtime_lock.json"):
        shutil.copyfile(path, snapshot / path.name)
    print(f"Prepared {cohort}: {len(patients)} patients; {len(candidates)} training-observed curated genes; {len(events)} passing frozen frequency gate")
    return model


def finalize(config_path: Path, output: Path, aggregate_path: Path) -> dict:
    config, _, _, _ = load_frozen(config_path)
    if not output.resolve().is_relative_to((HERE / "output").resolve()) or aggregate_path.parent.resolve() != HERE.resolve():
        raise ValueError("Expanded analysis cannot overwrite original artifacts")
    model = json.loads((output / "prepared_evidence.json").read_text())
    code = {"expanded_wrapper_sha256": Path(__file__), "evidence_code_sha256": BASE / "evidence.py", "source_validator_sha256": BASE / "prepare_inputs.py", "engine_wrapper_sha256": BASE / "run_ascetic.R", "runtime_lock_sha256": BASE / "runtime_lock.json"}
    if any(model["provenance"][key] != sha(path) for key, path in code.items()) or model["provenance"]["configuration_sha256"] != sha(config_path):
        raise ValueError("Expanded frozen code or configuration changed after preparation")
    inputs_path = output / "engine_inputs.json"
    if model["provenance"]["engine_inputs_sha256"] != sha(inputs_path):
        raise ValueError("Prepared engine inputs changed")
    engine_path = output / "engine_output.json"
    engine = json.loads(engine_path.read_text())
    ids = [row["id"] for row in model["events"]]
    integrity = engine["input_integrity"]
    if integrity["event_ids"] != ids or integrity["input_md5"] != hashlib.md5(inputs_path.read_bytes()).hexdigest() or integrity["config_md5"] != hashlib.md5(config_path.read_bytes()).hexdigest():
        raise ValueError("Genuine engine output is not bound to these exact inputs")
    training = [row for row in model["patients"] if row["role"] == "training"]
    evaluation = [row for row in model["patients"] if row["role"] == "evaluation"]
    null = ordering_null(training, ids, config["assessment"]["ordering_null_permutations"], config["engine"]["seed"]+40000)
    write_json(output / "ordering_null_all_pairs.json", null)
    null_lookup = {(row["source"], row["target"]): row for row in null}
    for pair in model["pair_evidence"]:
        pair["ordering_null"] = {"a_to_b": null_lookup[pair["a"], pair["b"]], "b_to_a": null_lookup[pair["b"], pair["a"]]}
    all_pairs = {(row["source"], row["target"]): row for row in engine["all_ordered_pairs"]}
    for edge in engine["selected_edges"]:
        a, b = edge["source"], edge["target"]
        row = all_pairs[a, b]
        tc, ec = counts(training, a, b), counts(evaluation, a, b)
        positives = [patient for patient in training if any(event["gene"] == a for event in patient["events"])]
        negatives = [patient for patient in training if not any(event["gene"] == a for event in patient["events"])]
        b_pos = sum(any(event["gene"] == b for event in patient["events"]) for patient in positives)
        b_neg = sum(any(event["gene"] == b for event in patient["events"]) for patient in negatives)
        model["edges"].append({"source": a, "target": b, "selected": True, "relation": "ASCETIC model dependency", "training": tc, "evaluation": ec,
            "training_reported_cooccurrence": {"target_with_source": b_pos, "source_carriers": len(positives), "target_without_source": b_neg, "source_noncarriers": len(negatives),
                "P_target_given_source": b_pos/len(positives), "P_target_given_no_source": b_neg/len(negatives), "difference": b_pos/len(positives)-b_neg/len(negatives),
                "meaning": "Descriptive reported-driver cooccurrence; negative difference is not positive cooperation"},
            "bootstrap": {"selected_count": row["bootstrap_selected"], "successful_runs": row["bootstrap_successful"], "selection_frequency": row["bootstrap_frequency"]},
            "null": {"engine_selection_count": row["ordering_null_selected"], "engine_successful_runs": row["ordering_null_successful"], "engine_selection_frequency": row["ordering_null_frequency"], "pair_direction": null_lookup[a, b]},
            "strict_source_evidence_status": "At least one strict source ancestry vote; not necessarily adjacent clusters" if tc["source_ancestor"] else "No resolved source ancestry evidence",
            "heldout_direction_status": "No resolved evaluation order" if not ec["strict_order_resolved"] else "Evaluation majority compatible" if ec["source_ancestor"] > ec["reverse_ancestor"] else "Evaluation majority reversed" if ec["source_ancestor"] < ec["reverse_ancestor"] else "Evaluation resolved directions tied",
            "status": "Exploratory model-selected dependency; not a confirmed route"})
    edges = [(row["source"], row["target"]) for row in model["edges"]]
    model["model_status"] = "genuine_ASCETIC_fitted_exploratory"
    model["method"]["engine"] = engine["engine"]
    model["validation"] = {"patient_bootstrap": engine["patient_bootstrap"], "ordering_null_engine_fits": engine["ordering_null"],
        "ordering_permutation_tests": {"permutations": config["assessment"]["ordering_null_permutations"], "ordered_pairs": len(null),
            "multiplicity": config["assessment"]["multiplicity"], "null": config["assessment"]["null"], "direction_statistic": config["assessment"]["direction_statistic"],
            "all_pairs_BH_q_below_0_05": sum(row["BH_q"] < .05 for row in null),
            "selected_edges_BH_q_below_0_05": sum(null_lookup[a, b]["BH_q"] < .05 for a, b in edges)},
        "selected_edges_meeting_0_8_stability": sum(row["bootstrap"]["selection_frequency"] is not None and row["bootstrap"]["selection_frequency"] >= config["assessment"]["stability_display_threshold"] for row in model["edges"]),
        "holdout": joint_holdout(model["patients"], ids, edges),
        "interpretation": "New exploratory expanded universe, with fixed original patient roles; previously inspected holdout is not a fresh independent confirmation. Bootstrap frequency is not an ancestry probability."}
    model["audit"] = {"independent_patients": len(model["patients"]), "regions_or_topologies_used_as_patients": False,
        "all_source_topologies_structurally_validated": True, "all_pair_categories_preserved": True, "same_cluster_order_invented": False,
        "CCF_or_VAF_as_time_used": False, "source_corrected_topology_used_to_break_ties": False, "CNA_presence_as_order_used": False,
        "evaluation_used_for_candidate_universe_or_frequency_gate": False, "heldout_used_for_gene_or_edge_selection": False,
        "selected_edge_count": len(edges), "full_parent_sets": {gene: sorted(a for a, b in edges if b == gene) for gene in ids}}
    sys.path.insert(0, str(ROOT / "tracerx_routes/visualization"))
    from contract import validate_model
    model["audit"]["independent_display_contract"] = validate_model(model)
    model["provenance"].update({"prepared_evidence_sha256": sha(output / "prepared_evidence.json"), "actual_engine_output_sha256": sha(engine_path), "ordering_null_all_pairs_sha256": sha(output / "ordering_null_all_pairs.json")})
    write_json(output / "model.json", model)
    aggregate = {key: value for key, value in model.items() if key != "patients"}
    aggregate["model_sha256"] = sha(output / "model.json")
    aggregate["purpose"] = "Aggregate scientific evidence; no source patient identifiers or per-patient data"
    aggregate["validation"] = {**aggregate["validation"], "holdout": {key: value for key, value in model["validation"]["holdout"].items() if key not in {"patient_scores", "training_CPTs"}}}
    write_json(aggregate_path, aggregate)
    return model


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohort", choices=["luad", "lusc"], required=True)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--rscript", default="C:/Program Files/R/R-4.5.1/bin/Rscript.exe")
    parser.add_argument("--summarize-only", action="store_true")
    args = parser.parse_args()
    config_path = args.config or ROOT / f"configs/tracerx_expanded_{args.cohort}_v0_1.json"
    if json.loads(config_path.read_text())["primary_cohort"].lower() != args.cohort:
        raise ValueError("CLI cohort and frozen configuration differ")
    output = HERE / "output" / args.cohort
    if not args.summarize_only:
        prepare(config_path, output)
        subprocess.run([args.rscript, "--vanilla", str(BASE / "run_ascetic.R"), str(output / "engine_inputs.json"), str(config_path), str(output), str(BASE / "runtime_lock.json")], check=True)
    model = finalize(config_path, output, HERE / f"{args.cohort}_results_summary.json")
    print(f"Completed {args.cohort}: {len(model['events'])} events, {len(model['pair_evidence'])} unordered pairs, {len(model['edges'])} selected dependencies")
    print("Adjusted ordering discoveries:", model["validation"]["ordering_permutation_tests"]["all_pairs_BH_q_below_0_05"])
    print("Evaluation score difference:", model["validation"]["holdout"]["difference_per_evaluation_patient"])


if __name__ == "__main__":
    main()
