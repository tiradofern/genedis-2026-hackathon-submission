"""Focused checks of the additive, training-only expanded analysis contract."""
from __future__ import annotations

from collections import Counter
import copy
from itertools import combinations
import json
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import run as expanded


def mutation(gene: str, cluster: str | None, status: str = "mapped_retained") -> dict:
    return {"gene": gene, "source_driver": True, "mapping_status": status,
            "cluster_id": cluster, "variant_id": gene + "_fixture_variant"}


def patient(pid: str, drivers: list[dict]) -> dict:
    return {"patient_id": pid, "drivers": drivers, "consensus_relations": [
        {"a_cluster": "1", "b_cluster": "2", "state": "a_ancestor_b"},
        {"a_cluster": "1", "b_cluster": "3", "state": "a_ancestor_b"},
        {"a_cluster": "2", "b_cluster": "3", "state": "incomparable"}]}


class FrozenUniverseTests(unittest.TestCase):
    def test_evaluation_names_and_frequencies_do_not_enter_candidate_inventory(self):
        source = {"patients": [patient("FICTIONAL_T", [mutation("A", "1")]),
                               patient("FICTIONAL_E", [mutation("HELDOUT_ONLY", "2")])]}
        roles = {"FICTIONAL_T": "training", "FICTIONAL_E": "evaluation"}
        self.assertEqual(expanded.candidate_genes(source, roles), ["A"])
        altered = copy.deepcopy(source)
        altered["patients"][1]["drivers"] = [mutation("A", "2"), mutation("EVAL_OTHER", "3")]
        self.assertEqual(expanded.candidate_genes(altered, roles), ["A"])

    def test_exact_annotation_required_without_reclassifying_passengers(self):
        source = {"patients": [patient("FICTIONAL_T", [{**mutation("A", "1"), "source_driver": False}])]}
        with self.assertRaisesRegex(ValueError, "Noncurated"):
            expanded.candidate_genes(source, {"FICTIONAL_T": "training"})

    def test_expansion_does_not_turn_same_cluster_or_branches_into_time(self):
        row = patient("FICTIONAL_T", [mutation("A", "1"), mutation("B", "1"),
            mutation("C", "2"), mutation("D", "3"), mutation("X", None, "unavailable")])
        derived = expanded.consensus_gene_relations(row, ["A", "B", "C", "D", "X"])
        p = {"events": derived["events"], "relations": derived["relations"]}
        self.assertEqual(expanded.counts([p], "A", "B")["same_cluster"], 1)
        self.assertEqual(expanded.counts([p], "C", "D")["incomparable"], 1)
        self.assertEqual(expanded.counts([p], "A", "X")["mapping_ambiguous"], 1)
        self.assertEqual(expanded.counts([p], "A", "C")["source_ancestor"], 1)


class ActualExpandedContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.models = {}
        for cohort in ("luad", "lusc"):
            path = HERE / "output" / cohort / "model.json"
            if path.exists():
                cls.models[cohort] = json.loads(path.read_text())
        if len(cls.models) != 2:
            raise unittest.SkipTest("Both separately frozen expanded analyses have not completed")

    def test_actual_original_roles_and_artifacts_are_unchanged(self):
        for cohort, model in self.models.items():
            config_path = expanded.ROOT / f"configs/tracerx_expanded_{cohort}_v0_1.json"
            config, source, old, roles = expanded.load_frozen(config_path)
            self.assertEqual({row["id"]: row["role"] for row in model["patients"]}, roles)
            self.assertEqual(model["cohort"], old["cohort"])
            self.assertEqual(model["provenance"]["configuration_sha256"], expanded.sha(config_path))
            self.assertFalse(model["audit"]["CNA_presence_as_order_used"])
            self.assertEqual(model["provenance"]["baseline"], config["baseline"])

    def test_training_gate_is_exhaustive_and_evaluation_independent(self):
        for cohort, model in self.models.items():
            config, source, _, roles = expanded.load_frozen(expanded.ROOT / f"configs/tracerx_expanded_{cohort}_v0_1.json")
            training_only = {"patients": [row for row in source["patients"] if roles[row["patient_id"]] == "training"]}
            candidates = expanded.candidate_genes(training_only, roles)
            self.assertEqual(candidates, [row["id"] for row in model["candidate_events"]])
            carriers = Counter()
            for row in training_only["patients"]:
                carriers.update({hit["gene"] for hit in row["drivers"]})
            selected = [gene for gene in candidates if carriers[gene] >= 10 and config["split"]["training_participants"]-carriers[gene] >= 10]
            self.assertEqual(selected, [row["id"] for row in model["events"]])
            self.assertTrue(all(row["event_type"] == "curated_SNV_indel" for row in model["events"]))

    def test_actual_all_pair_votes_match_exact_source_and_categories(self):
        for cohort, model in self.models.items():
            config, source, _, roles = expanded.load_frozen(expanded.ROOT / f"configs/tracerx_expanded_{cohort}_v0_1.json")
            event_ids = [row["id"] for row in model["events"]]
            independent = []
            for row in source["patients"]:
                # Independently rebuild from exact curated variant placements,
                # strict ancestry closures and possible ancestry closures, not
                # the already-computed source consensus-relations field.
                variants = {}
                for hit in row["drivers"]:
                    if hit["gene"] in event_ids:
                        variants.setdefault(hit["gene"], []).append(hit)
                strict = {tuple(map(str, pair)) for pair in row["strict_ancestor_pairs"]}
                possible = {tuple(map(str, pair)) for pair in row["possible_ancestor_pairs"]}
                categories = []
                for a, b in combinations(sorted(variants), 2):
                    aa, bb = variants[a], variants[b]
                    ca = {str(hit["cluster_id"]) for hit in aa}
                    cb = {str(hit["cluster_id"]) for hit in bb}
                    if any(hit["mapping_status"] != "mapped_retained" for hit in aa+bb):
                        state = "mapping_ambiguous"
                    elif len(ca) != 1 or len(cb) != 1:
                        state = "repeated_gene_ambiguous"
                    else:
                        ac, bc = next(iter(ca)), next(iter(cb))
                        if ac == bc: state = "same_cluster"
                        elif (ac, bc) in strict: state = "a_ancestor_b"
                        elif (bc, ac) in strict: state = "b_ancestor_a"
                        elif (ac, bc) not in possible and (bc, ac) not in possible: state = "incomparable"
                        else: state = "topology_ambiguous"
                    categories.append({"a": a, "b": b, "state": state})
                independent.append({"id": row["patient_id"], "role": roles[row["patient_id"]], "relations": categories})
            for pair in model["pair_evidence"]:
                for role in ("training", "evaluation"):
                    self.assertEqual(pair[role], expanded.counts([row for row in independent if row["role"] == role], pair["a"], pair["b"]))

    def test_multiplicity_engine_denominators_and_holdout_reproduce(self):
        for cohort, model in self.models.items():
            ids = [row["id"] for row in model["events"]]
            null = json.loads((HERE / "output" / cohort / "ordering_null_all_pairs.json").read_text())
            self.assertEqual(len(null), len(ids)*(len(ids)-1))
            from evidence import bh
            self.assertEqual([row["BH_q"] for row in null], bh([row["p"] for row in null]))
            self.assertTrue(all(row["permutations"] == 10000 for row in null))
            for key in ("patient_bootstrap", "ordering_null_engine_fits"):
                record = model["validation"][key]
                self.assertEqual(record["requested"], 100)
                self.assertEqual(record["successful"]+len(record["failures"]), 100)
            arrows = [(row["source"], row["target"]) for row in model["edges"]]
            self.assertEqual(model["validation"]["holdout"], expanded.joint_holdout(model["patients"], ids, arrows))


if __name__ == "__main__":
    unittest.main()
