# Source translation only: no event selection, reconstruction, or model fitting.
args <- commandArgs(trailingOnly=TRUE)
root <- if (length(args)) normalizePath(args[[1]], winslash="/", mustWork=TRUE) else normalizePath(".", winslash="/", mustWork=TRUE)
setwd(root)
.libPaths(c("tracerx_routes/source/.rlibrary", "population_routes/inference/.rlibrary", .libPaths()))
reader <- jsonlite::read_json("tracerx_routes/source/source_manifest.json", simplifyVector=FALSE)$reader
for (package in reader$packages) stopifnot(as.character(utils::packageVersion(package$name)) == package$version)
dir.create("tracerx_routes/source/output/intermediate", recursive=TRUE, showWarnings=FALSE)
trees <- readRDS("nextstrain/source/raw/20221109_TRACERx421_phylogenetic_trees.rds")
tumours <- readRDS("nextstrain/source/raw/20221109_TRACERx421_all_tumour_df.rds")
patients <- readRDS("nextstrain/source/raw/20221109_TRACERx421_all_patient_df.rds")
regions <- readRDS("nextstrain/source/raw/20221109_LUAD_input_plot_df_all_LUAD_region_df_full.RDS")
mutations <- fst::read_fst("tracerx_routes/source/raw/20221109_TRACERx421_mutation_table.fst",
  columns=c("mutation_id", "patient_id", "tumour_id", "chr", "start", "stop", "ref", "var", "Hugo_Symbol", "func", "exonic.func", "AAChange", "DriverMut", "cleanCluster_SC", "PyCloneCluster_SC_TB_corrected", "PyCloneClonal_SC_TB_corrected", "combTiming_SC"))
mutations$full_variant_key <- paste(mutations$tumour_id, sub("^chr", "", mutations$chr), mutations$start, mutations$ref, mutations$var, sep=":")
driver_rows <- mutations[!is.na(mutations$DriverMut) & mutations$DriverMut, ]
write.table(driver_rows, "tracerx_routes/source/output/curated_driver_rows.tsv", sep="\t", quote=FALSE, row.names=FALSE, na="")
source_audit <- list(rows=nrow(mutations), columns=names(mutations), DriverMut_values=as.list(table(mutations$DriverMut, useNA="always")),
  full_variant_key_duplicate_rows=sum(duplicated(mutations$full_variant_key) | duplicated(mutations$full_variant_key, fromLast=TRUE)),
  source_mutation_id_duplicate_rows=sum(duplicated(mutations$mutation_id) | duplicated(mutations$mutation_id, fromLast=TRUE)),
  missing_full_key_fields=sum(!complete.cases(mutations[,c("tumour_id","chr","start","ref","var")])) )
jsonlite::write_json(source_audit, "tracerx_routes/source/output/mutation_source_audit.json", auto_unbox=TRUE, na="null", pretty=TRUE)
jsonlite::write_json(list(tumours=tumours, patients=patients), "tracerx_routes/source/output/metadata.json", dataframe="rows", auto_unbox=TRUE, na="null", pretty=TRUE)
edge_list <- function(value) {
  if (is.null(value) || !length(value)) return(list())
  if (!is.matrix(value)) value <- matrix(value,ncol=2)
  stopifnot(ncol(value)==2)
  lapply(seq_len(nrow(value)), function(i) as.list(as.character(value[i,])))
}
for (id in names(trees)) {
  z <- trees[[id]]
  graph <- z$graph_pyclone
  metadata <- tumours[tumours$tumour_id_muttable_cruk==id,]
  stopifnot(nrow(metadata)==1)
  pat <- patients[patients$cruk_id==metadata$cruk_id,]
  stopifnot(nrow(pat)==1)
  ccf <- z$nested_pyclone$ccf_cluster_table
  if (is.null(dim(ccf))) stop("CCF matrix unexpectedly unshaped")
  mapping <- z$ccf_table_pyclone_clean
  driver <- driver_rows[driver_rows$tumour_id==id,]
  driver$embedded_cluster <- mapping$PycloneCluster[match(driver$full_variant_key, rownames(mapping))]
  driver$embedded_key_matches <- vapply(driver$full_variant_key, function(k) sum(rownames(mapping)==k), integer(1))
  counts <- as.list(as.integer(graph$edgelength)); names(counts) <- names(graph$edgelength)
  ccf_records <- lapply(seq_len(nrow(ccf)), function(i) {
    values <- as.list(as.numeric(ccf[i,])); names(values) <- colnames(ccf)
    list(cluster_id=rownames(ccf)[i], regional_ccf_percent=values)
  })
  payload <- list(tumour_id=id, metadata=metadata, patient_metadata=pat,
    regions=as.list(colnames(ccf)), regional_metadata=regions[regions$tumour_id_muttable_cruk==id,c("sample_name_cruk","regional_pattern.new","Histology_per_tumour_id_muttable")],
    corrected_edges=edge_list(graph$Corrected_tree), trunk=as.list(as.character(graph$trunk)),
    branch_snv_counts=counts, alternative_trees=lapply(graph$alt_trees,edge_list),
    consensus_branches=as.list(graph$consensus_branches), consensus_relationships=as.list(graph$consensus_relationships),
    tree_removed_clusters=as.list(z$tree_removed_clusters), cpn_removed_clusters=as.list(z$cpn_removed_clusters),
    merged_clusters=z$merged_clusters, ccf=ccf_records, drivers=driver,
    embedded_mapping_rows=nrow(mapping), embedded_mapping_duplicate_keys=sum(duplicated(rownames(mapping))))
  jsonlite::write_json(payload,paste0("tracerx_routes/source/output/intermediate/",id,".json"), dataframe="rows", auto_unbox=TRUE,na="null",digits=NA)
}
cat("Translated",length(trees),"source objects; no new tree or population model was fitted.\n")
jsonlite::write_json(list(tumours=length(trees), input_md5=as.list(tools::md5sum(c(
  "nextstrain/source/raw/20221109_TRACERx421_phylogenetic_trees.rds",
  "nextstrain/source/raw/20221109_TRACERx421_all_tumour_df.rds",
  "nextstrain/source/raw/20221109_TRACERx421_all_patient_df.rds",
  "nextstrain/source/raw/20221109_LUAD_input_plot_df_all_LUAD_region_df_full.RDS",
  "tracerx_routes/source/raw/20221109_TRACERx421_mutation_table.fst",
  "tracerx_routes/source/extract_sources.R")))), "tracerx_routes/source/output/extraction_provenance.json",auto_unbox=TRUE,pretty=TRUE)
