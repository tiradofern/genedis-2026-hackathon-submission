"""Contract tests for source-derived order resolution, not biological validation."""
import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("tracerx_audit", ROOT / "tracerx_routes/audit_sources.py")
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


def source_tree():
    return {"trunk": ["1"], "corrected_edges": [["1", "2"], ["2", "3"]],
            "alternative_trees": [[["1", "2"], ["2", "3"]], [["1", "2"], ["1", "3"]]],
            "consensus_branches": ["1:2"], "consensus_relationships": ["1:2", "1:3"],
            "branch_snv_counts": {"1": 50, "2": 10, "3": 5}, "embedded_mapping_duplicate_keys": 0}


class SourceContractTests(unittest.TestCase):
    def test_all_topologies_prevent_representative_only_ancestry(self):
        tree = audit.audit_tree(source_tree())
        self.assertEqual(audit.classify_pair("2", "3", tree["strict"], tree["possible"]), "topology_ambiguous")
        self.assertNotIn(("2", "3"), tree["strict"])
        self.assertIn(("1", "3"), tree["strict"])

    def test_source_consensus_mismatch_fails(self):
        raw = source_tree()
        raw["consensus_relationships"].append("2:3")
        with self.assertRaisesRegex(ValueError, "consensus_relationships"):
            audit.audit_tree(raw)

    def test_missing_alternative_node_fails(self):
        raw = source_tree()
        raw["alternative_trees"][1] = [["1", "2"]]
        with self.assertRaisesRegex(ValueError, "coverage"):
            audit.audit_tree(raw)

    def test_same_cluster_and_sibling_branches_remain_unordered(self):
        relations = audit.closure([["1", "2"], ["1", "3"]], {"1", "2", "3"}, "1")
        self.assertEqual(audit.classify_pair("2", "2", relations, relations), "same_cluster")
        self.assertEqual(audit.classify_pair("2", "3", relations, relations), "incomparable")

    def test_exact_single_cluster_sentinel_only(self):
        raw = {"trunk": ["1"], "corrected_edges": [["1", "1"]], "alternative_trees": [[["1", "1"]]],
               "consensus_branches": ["1:1"], "consensus_relationships": ["1:1"], "branch_snv_counts": {"1": 50}}
        tree = audit.audit_tree(raw)
        self.assertEqual(tree["edges"], [])
        self.assertEqual(tree["strict"], set())
        raw["branch_snv_counts"]["2"] = 5
        with self.assertRaises(ValueError):
            audit.audit_tree(raw)

    def test_repeated_hits_and_bad_mappings_keep_presence(self):
        rows = [{"gene": "TP53", "cluster_id": "1", "mapping_status": "mapped_retained", "variant_id": "v1", "source_clean_cluster": True},
                {"gene": "TP53", "cluster_id": "2", "mapping_status": "mapped_retained", "variant_id": "v2", "source_clean_cluster": True},
                {"gene": "KRAS", "cluster_id": None, "mapping_status": "variant_not_in_embedded_mapping", "variant_id": "v3", "source_clean_cluster": None}]
        events = {row["gene"]: row for row in audit.gene_events(rows)}
        self.assertTrue(events["TP53"]["present"])
        self.assertEqual(events["TP53"]["mapping_status"], "repeated_hit_different_clusters")
        self.assertTrue(events["KRAS"]["present"])
        self.assertEqual(events["KRAS"]["mapping_status"], "unresolved_driver_mapping")

    def test_alternate_allele_is_part_of_exact_key(self):
        row = {"DriverMut": True, "embedded_cluster": 1, "PyCloneCluster_SC_TB_corrected": 1,
               "tumour_id": "TEST", "chr": "chr1", "start": "100", "ref": "A", "var": "T",
               "full_variant_key": "TEST:1:100:A:G", "embedded_key_matches": 1}
        with self.assertRaisesRegex(ValueError, "full variant key"):
            audit.map_drivers({"drivers": [row]}, {"nodes": {"1"}})

    @unittest.skipUnless((ROOT / "tracerx_routes/source/output/cohort_trees.json").exists(), "Public source export has not been reproduced locally")
    def test_actual_frozen_source_export_is_independent_and_complete(self):
        path = ROOT / "tracerx_routes/source/output/cohort_trees.json"
        lock = json.loads((ROOT / "tracerx_routes/source/cohort_export_lock.json").read_text())
        self.assertEqual(audit.digest(path), lock["cohort_trees_sha256"])
        source = json.loads(path.read_text())
        patients = source["patients"]
        self.assertEqual(source["structural_gate"], "passed")
        self.assertEqual(len(patients), 217)
        self.assertEqual(len({p["patient_id"] for p in patients}), 217)
        self.assertTrue(all(p["n_primary_regions"] >= 2 and p["histology"] == "LUAD" for p in patients))
        self.assertTrue(all(p["source_consensus_relationships_verified"] for p in patients))


if __name__ == "__main__":
    unittest.main()
