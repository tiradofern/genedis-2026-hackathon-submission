"""Retrieve public processed TRACERx inputs and isolated CRAN fst reader.

Academic non-commercial source terms: https://zenodo.org/records/7683605.
No controlled-access payloads are requested. Patient-level files remain ignored.
"""
from pathlib import Path
import argparse
import hashlib
import json
import urllib.request
import zipfile

HERE = Path(__file__).resolve().parent
RECORD = "https://zenodo.org/api/records/7683605"
MUTATION = "20221109_TRACERx421_mutation_table.fst"


def fetch(url, target):
    request = urllib.request.Request(url, headers={"User-Agent": "GeNeDis-TRACERx-academic-pilot/1.0"})
    with urllib.request.urlopen(request, timeout=180) as response, target.open("wb") as output:
        while chunk := response.read(1024 * 1024):
            output.write(chunk)


def fingerprint(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "md5": hashlib.md5(data).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bootstrap", action="store_true", help="Record current official checksums before analysis; inspect/version manifest")
    args = parser.parse_args()
    (HERE / "raw").mkdir(parents=True, exist_ok=True)
    (HERE / ".downloads").mkdir(exist_ok=True)
    (HERE / ".rlibrary").mkdir(exist_ok=True)
    manifest_path = HERE / "source_manifest.json"
    if args.bootstrap:
        record_path = HERE / "raw" / "zenodo_record.json"
        fetch(RECORD, record_path)
        record = json.loads(record_path.read_text(encoding="utf-8"))
        item = next(f for f in record["files"] if f["key"] == MUTATION)
        destination = HERE / "raw" / MUTATION
        download_url = "https://zenodo.org/records/7683605/files/" + MUTATION + "?download=1"
        if not destination.exists() or destination.stat().st_size != item["size"]:
            temporary = destination.with_suffix(destination.suffix + ".partial")
            fetch(download_url, temporary)
            temporary.replace(destination)
        metadata = fingerprint(destination)
        if "md5:" + metadata["md5"] != item["checksum"] or metadata["bytes"] != item["size"]:
            raise ValueError("Zenodo published checksum or size mismatch")
        mutation = {"filename": MUTATION, "url": download_url, **metadata}
        packages_path = HERE / ".downloads" / "PACKAGES"
        fetch("https://cloud.r-project.org/bin/windows/contrib/4.5/PACKAGES", packages_path)
        blocks = [{line.split(": ", 1)[0]: line.split(": ", 1)[1] for line in block.splitlines() if ": " in line and not line.startswith(" ")}
                  for block in packages_path.read_text(encoding="utf-8").replace("\r\n", "\n").split("\n\n")]
        packages = []
        for name in ("fst", "fstcore", "Rcpp"):
            info = next(b for b in blocks if b.get("Package") == name)
            filename = name + "_" + info["Version"] + ".zip"
            url = "https://cloud.r-project.org/bin/windows/contrib/4.5/" + filename
            archive = HERE / ".downloads" / filename
            if not archive.exists():
                fetch(url, archive)
            packages.append({"name": name, "version": info["Version"], "filename": filename, "url": url, **fingerprint(archive)})
        manifest = {"record": RECORD, "license": "Academic non-commercial use only; see Zenodo record notes", "mutation_file": mutation,
                    "reader": {"R_binary": "R 4.5.x Windows x86_64 UCRT", "packages": packages}}
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    for item in [manifest["mutation_file"], *manifest["reader"]["packages"]]:
        target = HERE / ("raw" if item["filename"].endswith(".fst") else ".downloads") / item["filename"]
        if not target.exists():
            temporary = target.with_suffix(target.suffix + ".partial")
            fetch(item["url"], temporary)
            if fingerprint(temporary) != {k: item[k] for k in ("bytes", "sha256", "md5")}:
                raise ValueError("Pinned source mismatch: " + item["filename"])
            temporary.replace(target)
        if fingerprint(target) != {k: item[k] for k in ("bytes", "sha256", "md5")}:
            raise ValueError("Pinned source mismatch: " + item["filename"])
        if target.suffix == ".zip" and not (HERE / ".rlibrary" / item["name"] / "DESCRIPTION").exists():
            with zipfile.ZipFile(target) as archive:
                archive.extractall(HERE / ".rlibrary")
        print("Verified", item["filename"], item["bytes"], flush=True)


if __name__ == "__main__":
    main()
