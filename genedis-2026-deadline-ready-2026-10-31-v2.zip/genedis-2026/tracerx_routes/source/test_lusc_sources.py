"""Isolation and source-cohort safeguards for the separate LUSC analysis."""
import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("tracerx_lusc_audit", ROOT / "tracerx_routes/audit_sources.py")
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


class SeparateCohortSourceTests(unittest.TestCase):
    def config(self):
        return {"primary_cohort": "LUSC", "eligibility": {"minimum_distinct_primary_R_regions": 2}}

    def test_separate_cohort_requires_explicit_isolated_outputs(self):
        with self.assertRaisesRegex(ValueError, "explicit"):
            audit.cohort_output_paths(self.config())
        for output, record in ((audit.OUTPUT, audit.SOURCE / "lusc_source_audit.json"),
                               (audit.OUTPUT / "lusc", audit.SOURCE / "source_audit.json")):
            with self.assertRaisesRegex(ValueError, "frozen LUAD"):
                audit.cohort_output_paths(self.config(), output, record)

    def test_explicit_lusc_paths_are_separate_and_depth_cannot_be_relaxed(self):
        output, record = audit.cohort_output_paths(self.config(), audit.OUTPUT / "lusc", audit.SOURCE / "lusc_source_audit.json")
        self.assertEqual(output, (audit.OUTPUT / "lusc").resolve())
        self.assertEqual(record, (audit.SOURCE / "lusc_source_audit.json").resolve())
        config = self.config()
        config["eligibility"]["minimum_distinct_primary_R_regions"] = 1
        with self.assertRaisesRegex(ValueError, "cannot be relaxed"):
            audit.cohort_output_paths(config, output, record)

    def test_literature_alias_changes_gene_only_and_preserves_source_symbol(self):
        row = {"DriverMut": True, "embedded_cluster": 1, "PyCloneCluster_SC_TB_corrected": 1,
               "tumour_id": "FICTIONAL", "chr": "chr1", "start": "100", "ref": "A", "var": "T",
               "full_variant_key": "FICTIONAL:1:100:A:T", "embedded_key_matches": 1, "Hugo_Symbol": "MLL2",
               "mutation_id": "source-short-key", "cleanCluster_SC": True, "PyCloneClonal_SC_TB_corrected": True,
               "combTiming_SC": "source timing", "AAChange": "source protein", "exonic.func": "source consequence", "func": "source function"}
        raw = {"drivers": [row], "tree_removed_clusters": [], "cpn_removed_clusters": []}
        original = audit.map_drivers(raw, {"nodes": {"1"}})[0]
        self.assertEqual(original["gene"], "MLL2")
        self.assertNotIn("raw_source_gene", original)
        canonical = audit.map_drivers(raw, {"nodes": {"1"}}, {"MLL2": "KMT2D"})[0]
        self.assertEqual(canonical["gene"], "KMT2D")
        self.assertEqual(canonical["raw_source_gene"], "MLL2")
        self.assertEqual(canonical["variant_id"], original["variant_id"])
        self.assertEqual(canonical["cluster_id"], original["cluster_id"])
        self.assertEqual(canonical["mapping_status"], "mapped_retained")

    @unittest.skipUnless((ROOT / "tracerx_routes/source/output/lusc/cohort_trees.json").exists(), "Separate public LUSC source export has not been reproduced locally")
    def test_actual_lusc_export_independence_histology_depth_and_lock(self):
        path = ROOT / "tracerx_routes/source/output/lusc/cohort_trees.json"
        lock = json.loads((ROOT / "tracerx_routes/source/lusc_cohort_export_lock.json").read_text())
        self.assertEqual(audit.digest(path), lock["cohort_trees_sha256"])
        source = json.loads(path.read_text())
        patients = source["patients"]
        self.assertEqual(source["structural_gate"], "passed")
        self.assertEqual(len(patients), 125)
        self.assertEqual(len({row["patient_id"] for row in patients}), 125)
        self.assertEqual(len({row["tumour_id"] for row in patients}), 125)
        self.assertTrue(all(row["histology"] == "LUSC" and row["n_primary_regions"] >= 2 for row in patients))
        inventory = json.loads((ROOT / "tracerx_routes/source/output/lusc/cohort_inventory.json").read_text())
        self.assertEqual(len(inventory), 403)
        self.assertTrue(all(row["n_deposited_tumours_for_patient"] == 1 for row in inventory if row["eligible"]))
        luad = json.loads((ROOT / "tracerx_routes/source/output/cohort_trees.json").read_text())
        self.assertFalse({row["patient_id"] for row in patients} & {row["patient_id"] for row in luad["patients"]})


if __name__ == "__main__":
    unittest.main()
