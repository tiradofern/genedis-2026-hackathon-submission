"""Read-only localhost view of source-grounded TRACERx order evidence."""
from pathlib import Path
import argparse
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from threading import Lock
from urllib.parse import parse_qs, urlparse

from contract import validate_model


def make_handler(model_path: Path, tree_report: Path, *, lusc_model_path: Path | None = None, lusc_tree_report: Path | None = None, strict_histology: bool = False):
    static = Path(__file__).resolve().parent
    sources = {"luad": (model_path, tree_report)}
    if lusc_model_path is not None:
        if lusc_tree_report is None:
            raise ValueError("The separate LUSC model requires its own tree export report")
        sources["lusc"] = (lusc_model_path, lusc_tree_report)
    cache = {}
    lock = Lock()

    def read_source(cohort):
        source_path, report_path = sources[cohort]
        raw = source_path.read_bytes()
        fingerprint = hashlib.sha256(raw).hexdigest()
        with lock:
            entry = cache.setdefault(cohort, {})
            if entry.get("sha256") != fingerprint:
                model = json.loads(raw)
                audit = validate_model(model)
                if (strict_histology or cohort == "lusc") and model["cohort"]["histology"] != cohort.upper():
                    raise ValueError("Requested histology differs from the validated source model; no cohort fallback is allowed")
                entry.update(model=model, audit=audit, sha256=fingerprint)
            return raw, entry["model"], entry["audit"], fingerprint, report_path

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urlparse(self.path)
            path = parsed.path
            values = parse_qs(parsed.query, keep_blank_values=True).get("cohort", ["luad"])
            if len(values) != 1 or values[0] not in {"luad", "lusc"}:
                self.send_error(400, "Choose exactly one supported cohort: luad or lusc")
                return
            cohort = values[0]
            if path in {"/model.json", "/source-model.json"}:
                try:
                    if cohort not in sources:
                        raise ValueError(f"The separate {cohort.upper()} source is not configured; no other cohort is substituted")
                    raw, model, audit, fingerprint, report_path = read_source(cohort)
                    links = {}
                    if report_path.exists():
                        report = json.loads(report_path.read_bytes())
                        patients = {patient["id"] for patient in model["patients"]}
                        for row in report["published_tree_exports"]:
                            patient_id = str(row["patient_id"])
                            if patient_id not in patients or patient_id in links:
                                raise ValueError("Tree export report contains a foreign or repeated patient")
                            links[patient_id] = row["evidence_url"]
                    data = raw if path == "/source-model.json" else json.dumps({"model": model, "sha256": fingerprint, "display_audit": audit, "patient_tree_links": links, "requested_cohort": cohort, "native_model_url": f"http://127.0.0.1:4000/tracerx/{cohort}/population/edges"}, allow_nan=False).encode("utf-8")
                    content_type = "application/json; charset=utf-8"
                except (OSError, ValueError, KeyError) as error:
                    self.send_error(503, f"Validated source evidence is not ready: {error}")
                    return
            elif path in {"/", "/index.html", "/app.js", "/styles.css"}:
                filename = "index.html" if path == "/" else path[1:]
                data = (static / filename).read_bytes()
                content_type = {"index.html": "text/html; charset=utf-8", "app.js": "text/javascript; charset=utf-8", "styles.css": "text/css; charset=utf-8"}[filename]
            else:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self'; script-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
            if path == "/source-model.json":
                self.send_header("Content-Disposition", f'attachment; filename="tracerx-{cohort}-driver-order-evidence.json"')
            self.end_headers()
            self.wfile.write(data)

    return Handler


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, default=Path("tracerx_routes/inference/output/model.json"))
    parser.add_argument("--tree-report", type=Path, default=Path("tracerx_routes/visualization/output/patient_exports.json"))
    parser.add_argument("--lusc-model", type=Path, default=Path("tracerx_routes/inference/output/lusc/model.json"))
    parser.add_argument("--lusc-tree-report", type=Path, default=Path("tracerx_routes/visualization/output/lusc/patient_exports.json"))
    parser.add_argument("--port", type=int, default=4002)
    args = parser.parse_args()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(args.model.resolve(), args.tree_report.resolve(), lusc_model_path=args.lusc_model.resolve(), lusc_tree_report=args.lusc_tree_report.resolve(), strict_histology=True))
    print(f"TRACERx patient-grounded order evidence: http://127.0.0.1:{args.port}/", flush=True)
    server.serve_forever()
