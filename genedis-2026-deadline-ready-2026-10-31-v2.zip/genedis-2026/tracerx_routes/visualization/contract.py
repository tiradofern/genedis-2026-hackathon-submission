"""Display-contract validation for source-grounded multi-region order evidence.

No model fitting, source chronology reconstruction or ambiguity resolution occurs
here. Each eligible patient contributes at most one categorical vote per pair.
"""
from __future__ import annotations

from collections import Counter
import hashlib
from itertools import combinations
import json
from pathlib import Path


STATES = {
    "a_ancestor_b": ("source_ancestor", "A ancestral to B across deposited alternatives"),
    "b_ancestor_a": ("reverse_ancestor", "B ancestral to A across deposited alternatives"),
    "same_cluster": ("same_cluster", "Same mutation cluster: within-cluster order unresolved"),
    "incomparable": ("incomparable", "Incomparable branches"),
    "topology_ambiguous": ("topology_ambiguous", "Relation differs across deposited alternatives"),
    "repeated_gene_ambiguous": ("repeated_gene_ambiguous", "Repeated gene hits: order unresolved"),
    "mapping_ambiguous": ("mapping_ambiguous", "Mapping unresolved"),
}
COUNT_FIELDS = tuple(value[0] for value in STATES.values())


class EvidenceError(ValueError):
    pass


def pair_ids(row: dict) -> tuple[str, str]:
    a, b = row.get("a", row.get("source")), row.get("b", row.get("target"))
    if not isinstance(a, str) or not isinstance(b, str) or not a or not b or a == b:
        raise EvidenceError("A gene pair needs two distinct event IDs")
    if "a" in row and "source" in row and row["a"] != row["source"]:
        raise EvidenceError("Pair a/source IDs disagree")
    if "b" in row and "target" in row and row["b"] != row["target"]:
        raise EvidenceError("Pair b/target IDs disagree")
    return a, b


def relation_for(patient: dict, a: str, b: str) -> dict | None:
    """Orient an existing source categorical vote; never resolve its uncertainty."""
    matches = [row for row in patient.get("relations", []) if set(pair_ids(row)) == {a, b}]
    if len(matches) > 1:
        raise EvidenceError(f"Patient {patient.get('id')} votes more than once for {a}/{b}")
    if not matches:
        return None
    result = dict(matches[0])
    original_a, _ = pair_ids(result)
    if original_a != a:
        result["state"] = {"a_ancestor_b": "b_ancestor_a", "b_ancestor_a": "a_ancestor_b"}.get(result["state"], result["state"])
    result["a"], result["b"] = a, b
    return result


def _count(value: object, field: str, maximum: int | None = None) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0 or maximum is not None and value > maximum:
        raise EvidenceError(f"Invalid source count {field}: {value!r}")
    return value


def validate_model(model: dict, *, audit_patient_votes: bool = True) -> dict:
    if not isinstance(model, dict) or not model.get("title") or not model.get("model_id"):
        raise EvidenceError("An explicit evidence-model ID and title are required")
    method = model.get("method", {})
    if not method.get("name") or not method.get("estimand"):
        raise EvidenceError("Method name and explicit order-evidence estimand are required")
    cohort = model.get("cohort", {})
    if not cohort.get("histology"):
        raise EvidenceError("Histology must be explicit; no silent cohort pooling")
    for field in ("patient_count", "training_count", "evaluation_count"):
        _count(cohort.get(field), f"cohort.{field}")
    if cohort["training_count"] + cohort["evaluation_count"] != cohort["patient_count"]:
        raise EvidenceError("Training/evaluation patient counts do not partition the cohort")
    events = model.get("events")
    patients = model.get("patients")
    pairs = model.get("pair_evidence")
    if not all(isinstance(value, list) for value in (events, patients, pairs)):
        raise EvidenceError("events, patients and pair_evidence must be arrays")
    event_ids = [row.get("id") for row in events]
    if any(not isinstance(key, str) or not key for key in event_ids) or len(set(event_ids)) != len(event_ids):
        raise EvidenceError("Event IDs must be unique nonempty strings")
    for event in events:
        if not event.get("label"):
            raise EvidenceError("Every event needs its source label")
        _count(event.get("carriers_training"), f"{event['id']} training carriers", cohort["training_count"])
        _count(event.get("carriers_evaluation"), f"{event['id']} evaluation carriers", cohort["evaluation_count"])
    patient_ids = [row.get("id") for row in patients]
    if any(not isinstance(key, str) or not key for key in patient_ids) or len(set(patient_ids)) != len(patient_ids):
        raise EvidenceError("One independent patient record per source ID is required")
    if len(patients) != cohort["patient_count"]:
        raise EvidenceError("Patient records do not match the source cohort denominator")
    roles = Counter(row.get("role") for row in patients)
    if roles.get("training", 0) != cohort["training_count"] or roles.get("evaluation", 0) != cohort["evaluation_count"] or set(roles) - {"training", "evaluation"}:
        raise EvidenceError("Patient source roles do not match training/evaluation denominators")
    for patient in patients:
        _count(patient.get("n_regions"), f"{patient['id']} region count")
        _count(patient.get("n_topologies"), f"{patient['id']} deposited topology count")
        seen = set()
        genes = [row.get("gene", row.get("id")) for row in patient.get("events", [])]
        if any(not isinstance(gene, str) or not gene for gene in genes) or len(genes) != len(set(genes)):
            raise EvidenceError("Patient gene events must be unique explicit source gene IDs")
        retained_genes = set(genes) & set(event_ids)
        for relation in patient.get("relations", []):
            a, b = pair_ids(relation)
            if a not in event_ids or b not in event_ids or frozenset((a, b)) in seen:
                raise EvidenceError("Unknown pair event or repeated patient vote")
            if relation.get("state") not in STATES:
                raise EvidenceError(f"Unknown categorical source state: {relation.get('state')}")
            seen.add(frozenset((a, b)))
        if seen != {frozenset(pair) for pair in combinations(retained_genes, 2)}:
            raise EvidenceError("Patient co-carrier traces omit or invent a reported-event pair")
    for event in events:
        for role in ("training", "evaluation"):
            carriers = [patient for patient in patients if patient["role"] == role and any(row.get("gene", row.get("id")) == event["id"] for row in patient.get("events", []))]
            if len(carriers) != event[f"carriers_{role}"]:
                raise EvidenceError("Event carrier totals differ from independent patient event records")
    seen_pairs = set()
    for pair in pairs:
        a, b = pair_ids(pair)
        key = frozenset((a, b))
        if a not in event_ids or b not in event_ids or key in seen_pairs:
            raise EvidenceError("Unknown or repeated population pair")
        seen_pairs.add(key)
        for role in ("training", "evaluation"):
            counts = pair.get(role)
            if not isinstance(counts, dict):
                raise EvidenceError(f"Missing {role} source counts for {a}/{b}")
            co_carriers = _count(counts.get("co_carriers"), f"{a}/{b} {role} co-carriers", cohort[f"{role}_count"])
            for field in COUNT_FIELDS:
                _count(counts.get(field), f"{a}/{b} {role} {field}", co_carriers)
            if sum(counts[field] for field in COUNT_FIELDS) != co_carriers:
                raise EvidenceError(f"Source categories do not partition {a}/{b} {role} co-carriers")
            if counts.get("strict_order_resolved") != counts["source_ancestor"] + counts["reverse_ancestor"]:
                raise EvidenceError("Strict-order denominator must contain only the two ancestral directions")
            if audit_patient_votes:
                votes = Counter()
                for patient in patients:
                    if patient["role"] != role:
                        continue
                    relation = relation_for(patient, a, b)
                    if relation is not None:
                        votes[STATES[relation["state"]][0]] += 1
                if sum(votes.values()) != co_carriers or any(votes[field] != counts[field] for field in COUNT_FIELDS):
                    raise EvidenceError(f"Population counts differ from independent patient trace for {a}/{b} {role}")
    if seen_pairs != {frozenset(pair) for pair in combinations(event_ids, 2)}:
        raise EvidenceError("All unordered retained-event pairs must remain in the evidence report")
    return {"patient_count": len(patients), "events": len(events), "pairs": len(pairs), "independent_patient_votes_checked": audit_patient_votes, "ambiguity_categories_preserved": True, "population_common_ancestor_created": False}


def read_model(path: Path) -> tuple[dict, str]:
    raw = path.read_bytes()
    model = json.loads(raw)
    validate_model(model)
    return model, hashlib.sha256(raw).hexdigest()
