"""Display published corrected TRACERx trees without re-inferring any ancestry.

This accepts valid singleton and nonbranching published trees. It does not alter
the stricter selected-example converter used by the original integration proof.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import re


class TreeError(ValueError):
    pass


def tree_slug(tumour_id: str) -> str:
    result = re.sub(r"[^A-Za-z0-9.-]", "-", str(tumour_id))
    if not result or result in {".", ".."}:
        raise TreeError("Source tumour ID cannot form a safe dataset filename")
    return result


def _trait(value):
    # Preserve raw booleans in embedded source; the stock popup drops bools.
    return "Yes" if value is True else "No" if value is False else value


def validate_source(source: dict):
    rows = source.get("nodes")
    if not isinstance(rows, list) or not rows:
        raise TreeError("A published reconstruction needs at least one source node")
    if not source.get("patient_id") or not source.get("tumor_id"):
        raise TreeError("Explicit source patient and tumour IDs are required")
    provenance = source.get("source", {})
    for key in ("publication_title", "publication_url", "data_url", "license", "license_url", "source_file", "sha256"):
        if not provenance.get(key):
            raise TreeError(f"Missing source provenance {key}")
    if not re.fullmatch(r"[0-9a-f]{64}", provenance["sha256"]):
        raise TreeError("A raw source-file SHA256 is required")
    branch = source.get("branch_length", {})
    if branch.get("mode") != "published" or not branch.get("units") or not branch.get("source_evidence"):
        raise TreeError("Verified published branch units/evidence are required")
    nodes = {}
    for row in rows:
        key = str(row.get("id"))
        if row.get("id") is None or key in nodes:
            raise TreeError("Missing or duplicate source cluster ID")
        if not row.get("source_node_type") or not isinstance(row.get("label"), (str, int)):
            raise TreeError("Explicit source node type and label are required")
        length = row.get("branch_length")
        if isinstance(length, bool) or not isinstance(length, (int, float)) or not math.isfinite(length) or length < 0:
            raise TreeError("Source SNV counts must be finite, nonnegative numbers")
        for value in row.get("attributes", {}).values():
            if value is not None and not isinstance(value, (str, int, float, bool)):
                raise TreeError("Native display source traits must be scalar; retain structured evidence in the source extract")
            if isinstance(value, float) and not math.isfinite(value):
                raise TreeError("Nonfinite source display trait")
        nodes[key] = row
    children = {key: [] for key in nodes}
    roots = []
    for key, row in nodes.items():
        parent = row.get("parent_id")
        if parent is None:
            roots.append(key)
        elif str(parent) not in nodes or str(parent) == key:
            raise TreeError("Unknown or self-parent source edge")
        else:
            children[str(parent)].append(key)
    if len(roots) != 1:
        raise TreeError("One source root is required; separate tumours cannot share a fabricated root")
    root = roots[0]
    if source.get("root_id") is not None and str(source["root_id"]) != root:
        raise TreeError("Declared source root differs from the published parent graph")
    seen, pending = set(), [root]
    while pending:
        key = pending.pop()
        if key in seen:
            raise TreeError("Source tree has a cycle or duplicate traversal")
        seen.add(key)
        pending.extend(children[key])
    if seen != set(nodes):
        raise TreeError("Source graph is disconnected or contains a cycle")
    stem = nodes[root]["branch_length"]
    if source.get("root_stem") is not None and source["root_stem"].get("length") != stem:
        raise TreeError("Declared root stem differs from the source root SNV count")
    if stem and (source.get("root_stem", {}).get("length") != stem or not source["root_stem"].get("description")):
        raise TreeError("A nonzero truncal count requires a matching documented root_stem")
    return nodes, children, root


def convert(source: dict, *, source_sha256: str, updated="2026-10-18") -> dict:
    nodes, children, root = validate_source(source)
    tumour = str(source["tumor_id"])
    histology = source.get("histology")
    raw_source = source["source"]
    alt_count = source.get("n_topologies", source.get("alternative_topology_count", source.get("verification", {}).get("source_alternative_topologies")))
    alt_text = str(alt_count) if alt_count is not None else "not reported in this extract"
    description = (
        f"## Published corrected within-tumour tree: {tumour}\n\n"
        f"[{raw_source['publication_title']}]({raw_source['publication_url']}); [deposited data]({raw_source['data_url']}); "
        f"[source terms]({raw_source['license_url']}): {raw_source['license']}.\n\n"
        f"**Representative view:** This is the authors' corrected source topology, one representative display. "
        f"Deposited topology count: **{alt_text}**. Displaying the corrected tree does not resolve conflicting "
        f"relationships in other deposited alternatives. Source per-edge consensus/alternative information, "
        f"when supplied, remains in the node metadata. Alternative frequency is not a calibrated ancestry probability.\n\n"
        f"**Horizontal distance:** cumulative source-assigned SNV counts. {source['branch_length'].get('description', '')} "
        f"Units: **{source['branch_length']['units']}**. {source['branch_length']['source_evidence']} "
        f"No calendar dates, molecular clock, sequence mutation strings, or new branch support are inferred.\n\n"
        f"**Driver events:** only exact source-linked cluster annotations are displayed. Two events in one cluster "
        f"have no resolved within-cluster order. Repeated hits in one gene remain distinct/ambiguous as recorded. "
        f"Absence of a displayed driver is not a verified wild-type call.\n\n"
        f"**Population evidence:** The companion keeps same-cluster, incomparable, topology-ambiguous, repeated-gene "
        f"and unresolved-mapping categories separate. An ancestry vote is accepted only under the source analysis's "
        f"stated agreement across deposited topologies. There is no common clonal ancestor connecting patients.\n\n"
        f"**Display conventions:** The explicit display-only origin, if present, draws the published truncal stem. "
        f"It is not a sampled normal or an inferred biological clone. Terminal source clusters are not sampled "
        f"regions. Stock 'genomes' wording does not change this; 'No sequence changes observed' means sequence-level "
        f"strings were not supplied, not zero somatic mutations.\n\n"
        f"Raw source SHA256 `{raw_source['sha256']}`; extract SHA256 `{source_sha256}`. "
        f"Build date {updated} is not a specimen date."
    )
    if source.get("limitations"):
        description += "\n\n**Source limitations:** " + " ".join(str(item) for item in source["limitations"])
    if source.get("source_encoding"):
        description += "\n\n**Source encoding:** " + str(source["source_encoding"]) + ". Literal source edge/consensus encodings remain unchanged in the embedded extract. An approved singleton sentinel is displayed as one source cluster with no source ancestry edge; its published truncal SNV count is retained."
    description += "\n\nRegional cancer-cell-fraction values, when supplied, are the deposited percentage estimates and may exceed 100; they are not clamped or treated as clocks."
    if histology == "LUSC":
        description += "\n\n**Separate histology:** LUSC (squamous cell carcinoma), as explicitly labelled in the deposited source. Its population evidence is analysed separately from LUAD; patients and event models are never pooled."
    stem = nodes[root]["branch_length"]

    def make_node(key, cumulative):
        row = nodes[key]
        attrs = {
            "div": cumulative,
            "source_cluster_id": {"value": key},
            "source_label": {"value": str(row["label"])},
            "source_node_type": {"value": str(row["source_node_type"])},
            "source_snv_count": {"value": row["branch_length"]},
            "tumour_id": {"value": tumour},
            "patient_id": {"value": str(source["patient_id"])},
            "sequence_calls": {"value": "Not supplied; use source-assigned SNV counts"},
        }
        if histology == "LUSC":
            attrs["source_histology"] = {"value": histology}
        for trait, value in row.get("attributes", {}).items():
            if trait in attrs or trait in {"num_date", "vaccine", "hidden", "url", "author", "accession"}:
                raise TreeError(f"Reserved display trait {trait}")
            if value is not None and value != "":
                attrs[trait] = {"value": _trait(value)}
        node = {"name": f"{tree_slug(tumour)}_cluster_{key}", "node_attrs": attrs, "branch_attrs": {"labels": {"cluster": str(row["label"])}}}
        driver_genes = row.get("attributes", {}).get("curated_driver_genes")
        if driver_genes and driver_genes != "none assigned":
            node["branch_attrs"]["labels"]["drivers"] = str(driver_genes)
        if children[key]:
            node["children"] = [make_node(child, cumulative + nodes[child]["branch_length"]) for child in children[key]]
        return node

    tree = make_node(root, stem)
    if stem:
        tree = {"name": f"{tree_slug(tumour)}_DISPLAY_ONLY_ORIGIN", "node_attrs": {"div": 0, "display_role": {"value": "Display-only origin, not a biological clone"}}, "children": [tree]}
    values = {}

    def visit(node):
        for key, value in node["node_attrs"].items():
            if key != "div":
                values.setdefault(key, []).append(value["value"])
        for child in node.get("children", []):
            visit(child)

    visit(tree)
    colorings = [{"key": key, "title": key.replace("_", " ").capitalize(), "type": "continuous" if all(isinstance(value, (int, float)) and not isinstance(value, bool) for value in items) else "categorical"} for key, items in values.items()]
    dataset = {
        "version": "v2",
        "meta": {
            "title": f"TRACERx {'LUSC ' if histology == 'LUSC' else ''}published tumour {tumour} — corrected representative; source SNV counts",
            "updated": updated,
            "warning": f"ONE CORRECTED WITHIN-PATIENT REPRESENTATIVE · {alt_text} deposited topologies. Alternative-tree uncertainty remains unresolved; no between-patient common ancestry is drawn.",
            "description": description,
            "panels": ["tree"], "stream_labels": [],
            "colorings": colorings,
            "filters": ["source_node_type"],
            "display_defaults": {"distance_measure": "div", "layout": "rect", "color_by": "source_snv_count", "branch_label": "drivers", "tip_label": "source_label", "sidebar": "open"},
            "maintainers": [{"name": "GeNeDis source-grounded TRACERx evidence view"}],
            "data_provenance": [{"name": raw_source["publication_title"], "url": raw_source["publication_url"]}, {"name": "Published processed reconstructions", "url": raw_source["data_url"]}],
            "extensions": {"tracerx_patient_source": {"source_extract_sha256": source_sha256, "representation": "corrected_source_tree_only", "source_extract": copy.deepcopy(source)}},
        },
        "tree": tree,
    }
    validate_fidelity(source, dataset)
    return dataset


def validate_fidelity(source: dict, dataset: dict):
    nodes, children, root = validate_source(source)
    output = {}
    actual_edges = set()

    def visit(node, parent_id=None, parent_div=0):
        attrs = node["node_attrs"]
        if "source_cluster_id" in attrs:
            key = attrs["source_cluster_id"]["value"]
            if key in output or key not in nodes:
                raise TreeError("Unknown or repeated source cluster in native tree")
            output[key] = node
            if parent_id is not None:
                actual_edges.add((parent_id, key))
            if not math.isclose(attrs["div"] - parent_div, nodes[key]["branch_length"], rel_tol=1e-12, abs_tol=1e-12):
                raise TreeError("A published source SNV length changed")
            if attrs["source_label"]["value"] != str(nodes[key]["label"]):
                raise TreeError("Source cluster label changed")
            if attrs.get("source_snv_count", {}).get("value") != nodes[key]["branch_length"] or attrs.get("source_node_type", {}).get("value") != str(nodes[key]["source_node_type"]):
                raise TreeError("Source cluster SNV count or type changed")
            if attrs.get("patient_id", {}).get("value") != str(source["patient_id"]) or attrs.get("tumour_id", {}).get("value") != str(source["tumor_id"]):
                raise TreeError("Source patient or tumour identity changed")
            if source.get("histology") == "LUSC" and attrs.get("source_histology", {}).get("value") != "LUSC":
                raise TreeError("Explicit source squamous histology changed")
            for trait, value in nodes[key].get("attributes", {}).items():
                if value is not None and value != "" and attrs.get(trait, {}).get("value") != _trait(value):
                    raise TreeError("Source cluster annotation changed")
            genes = nodes[key].get("attributes", {}).get("curated_driver_genes")
            expected_label = str(genes) if genes and genes != "none assigned" else None
            if node.get("branch_attrs", {}).get("labels", {}).get("drivers") != expected_label:
                raise TreeError("Source driver branch label changed or an unassigned driver was invented")
            parent_id = key
        elif attrs.get("display_role", {}).get("value") != "Display-only origin, not a biological clone" or attrs["div"] != 0 or len(node.get("children", [])) != 1:
            raise TreeError("Unexpected nonsource node")
        if "num_date" in attrs or "mutations" in node.get("branch_attrs", {}):
            raise TreeError("Dates or sequence mutations were invented")
        for child in node.get("children", []):
            visit(child, parent_id, attrs["div"])

    visit(dataset["tree"])
    expected_edges = {(parent, child) for parent, descendants in children.items() for child in descendants}
    if set(output) != set(nodes) or actual_edges != expected_edges:
        raise TreeError("Source nodes or directed edges changed")
    if dataset["meta"]["extensions"]["tracerx_patient_source"]["source_extract"] != source:
        raise TreeError("Embedded source extract changed")
    return {"source_nodes": len(nodes), "source_edges": len(expected_edges), "source_root": root, "source_snv_count": sum(row["branch_length"] for row in nodes.values()), "published_topology_and_lengths_preserved": True, "driver_annotations_preserved": True, "new_ancestry_inferred": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohort", choices=("luad", "lusc"), default="luad")
    parser.add_argument("--source-dir", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("nextstrain/datasets"))
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    cohort_dir = "lusc/" if args.cohort == "lusc" else ""
    args.source_dir = args.source_dir or Path(f"tracerx_routes/source/output/{cohort_dir}patient_trees")
    args.report = args.report or Path(f"tracerx_routes/visualization/output/{cohort_dir}patient_exports.json")
    paths = sorted(args.source_dir.glob("*.json"))
    if not paths:
        raise SystemExit("No genuine source patient-tree extracts are ready; no fixture was substituted")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    records, slugs = [], set()
    for path in paths:
        raw = path.read_bytes()
        source = json.loads(raw)
        if source.get("histology") != args.cohort.upper():
            raise TreeError("Source histology differs from requested cohort; no cross-cohort export is allowed")
        slug = tree_slug(source["tumor_id"])
        if slug.casefold() in slugs:
            raise TreeError("Source IDs collide after safe filename mapping")
        slugs.add(slug.casefold())
        source_sha256 = hashlib.sha256(raw).hexdigest()
        dataset = convert(source, source_sha256=source_sha256)
        output_path = args.output_dir / f"tracerx_patient_{slug}.json"
        if output_path.exists():
            old_source = json.loads(output_path.read_bytes())["meta"]["extensions"]["tracerx_patient_source"]["source_extract"]
            if old_source.get("histology") != source["histology"] or old_source["patient_id"] != source["patient_id"] or old_source["tumor_id"] != source["tumor_id"]:
                raise TreeError("A native patient dataset collision would overwrite another histology or identity")
        output_path.write_text(json.dumps(dataset, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
        records.append({"patient_id": source["patient_id"], "tumour_id": source["tumor_id"], "source_extract_sha256": source_sha256, "dataset_sha256": hashlib.sha256(output_path.read_bytes()).hexdigest(), "filename": output_path.name, "evidence_url": f"http://127.0.0.1:4000/tracerx/patient/{slug}", "fidelity": validate_fidelity(source, dataset)})
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps({"published_tree_exports": records, "count": len(records)}, indent=2) + "\n", encoding="utf-8")
    print(f"Exported {len(records)} faithful published patient trees; report {args.report}")


if __name__ == "__main__":
    main()
