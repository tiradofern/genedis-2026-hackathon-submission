"""A loss-audited ASCETIC edge list in genuine Auspice, separate from source trees.

The complete pair evidence is authoritative for source ancestry. Selected model
edges are abstract dependencies, each rendered once in an independent component.
No patients, source mutation clusters, dates or mutation lengths are constructed.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path

from contract import COUNT_FIELDS, EvidenceError, pair_ids, relation_for, validate_model


def selected_graph(model):
    validate_model(model)
    events = {row["id"]: row for row in model["events"]}
    parents = {key: [] for key in events}
    children = {key: [] for key in events}
    seen = set()
    for edge in model.get("edges", []):
        a, b = pair_ids(edge)
        if a not in events or b not in events or (a, b) in seen or edge.get("selected") is not True:
            raise EvidenceError("Selected model edges require unique known endpoints and an explicit selected flag")
        seen.add((a, b))
        parents[b].append(a)
        children[a].append(b)
        for role in ("training", "evaluation"):
            counts = edge[role]
            votes = {key: 0 for key in COUNT_FIELDS}
            from contract import STATES
            for patient in model["patients"]:
                if patient["role"] == role:
                    relation = relation_for(patient, a, b)
                    if relation is not None:
                        votes[STATES[relation["state"]][0]] += 1
            if any(counts[key] != votes[key] for key in COUNT_FIELDS) or counts["co_carriers"] != sum(votes.values()):
                raise EvidenceError("Selected model-edge source counts differ from independent patient votes")
            if counts["strict_order_resolved"] != counts["source_ancestor"] + counts["reverse_ancestor"]:
                raise EvidenceError("Resolved denominator excludes same-cluster and all ambiguous states")
        for field in ("bootstrap", "null"):
            if not isinstance(edge.get(field), dict):
                raise EvidenceError("Source resampling/null metadata must be explicit")
    degree = {key: len(value) for key, value in parents.items()}
    ready = [key for key in events if degree[key] == 0]
    visited = 0
    while ready:
        current = ready.pop()
        visited += 1
        for child in children[current]:
            degree[child] -= 1
            if degree[child] == 0:
                ready.append(child)
    if visited != len(events):
        raise EvidenceError("The selected model is cyclic; a false DAG projection will not be exported")
    return events, parents


def edge_traits(edge):
    traits = {"relation": str(edge["relation"])}
    for role in ("training", "evaluation"):
        c = edge[role]
        traits[f"{role}_ancestral"] = c["source_ancestor"]
        traits[f"{role}_co_carriers"] = c["co_carriers"]
        traits[f"{role}_strict_resolved"] = c["strict_order_resolved"]
        traits[f"{role}_source_categories"] = "; ".join(f"{key}: {c[key]}" for key in COUNT_FIELDS)
        traits[f"{role}_source_order"] = f"{c['source_ancestor']} ancestral / {c['co_carriers']} co-carriers; {c['strict_order_resolved']} strict-order resolved"
    for key, value in edge["bootstrap"].items():
        if value is not None:
            traits[f"bootstrap_{key}"] = value
    for key in ("engine_selection_count", "engine_successful_runs", "engine_selection_frequency"):
        if edge["null"].get(key) is not None:
            traits[f"null_{key}"] = edge["null"][key]
    for key in ("p", "BH_q", "exceedances", "permutations"):
        if edge["null"].get("pair_direction", {}).get(key) is not None:
            traits[f"ordering_null_{key}"] = edge["null"]["pair_direction"][key]
    cooccurrence = edge.get("training_reported_cooccurrence", {})
    if cooccurrence.get("difference") is not None:
        traits["reported_event_cooccurrence_delta"] = cooccurrence["difference"]
    traits["cooccurrence_interpretation"] = "Reported-event association, not positive cooperation or a test of temporal truth"
    for key in ("strict_source_evidence_status", "heldout_direction_status", "status"):
        if edge.get(key) is not None:
            traits[key] = str(edge[key])
    return traits


def convert(model, *, source_sha256, updated="2026-10-18", companion_url=None):
    events, parents = selected_graph(model)
    histology = model["cohort"]["histology"]
    if companion_url is None:
        companion_url = "http://127.0.0.1:4002/" + ("?cohort=lusc" if histology == "LUSC" else "")
    if not events:
        return None
    components, mapping, used = [], [], set()

    def event_copy(event_id, name, position, edge=None):
        event = events[event_id]
        attrs = {
            "div": position,
            "event_id": {"value": event_id},
            "event_label": {"value": event["label"]},
            "component": {"value": f"{edge['source']} → {edge['target']}" if edge else f"Isolated event: {event_id}"},
            "representation": {"value": "Abstract model-event display copy; not a patient or clone"},
            "full_parent_set": {"value": "; ".join(parents[event_id]) or "No selected model parents"},
            "parent_semantics": {"value": "Selected joint conditioning set; no deterministic AND or mandatory-event claim"},
            "distance_units": {"value": "Unitless layout position 0 to 1; no mutation or time meaning"},
            "sequence_calls_status": {"value": "Not supplied; model-event components contain no sequence mutation strings"},
        }
        for role in ("training", "evaluation"):
            attrs[f"{role}_carriers"] = {"value": event[f"carriers_{role}"]}
            attrs[f"{role}_eligible"] = {"value": model["cohort"][f"{role}_count"]}
            if event.get(f"uniquely_mapped_{role}") is not None:
                attrs[f"{role}_uniquely_placed"] = {"value": event[f"uniquely_mapped_{role}"]}
        if edge:
            for key, value in edge_traits(edge).items():
                # Stock Auspice suppresses boolean popup values; preserve raw
                # booleans only in embedded source, explicit strings in display.
                attrs[key] = {"value": ("Yes" if value else "No") if isinstance(value, bool) else value}
        node = {"name": name, "node_attrs": attrs}
        mapping.append({"name": name, "event_id": event_id, "edge": [edge["source"], edge["target"]] if edge else None})
        return node

    for index, edge in enumerate(model.get("edges", [])):
        a, b = pair_ids(edge)
        component = event_copy(a, f"model_edge_{index}_source", 0, edge)
        component["children"] = [event_copy(b, f"model_edge_{index}_target", 1, edge)]
        components.append(component)
        used.update((a, b))
    for index, event_id in enumerate(events):
        if event_id not in used:
            components.append(event_copy(event_id, f"model_isolated_{index}", 0))
    all_values = {}
    for component in components:
        for node in [component, *component.get("children", [])]:
            for key, item in node["node_attrs"].items():
                if key != "div":
                    all_values.setdefault(key, []).append(item["value"])
    titles = {
        "training_source_order": "Training ancestral / co-carrier / strict-resolved patients",
        "evaluation_source_order": "Evaluation ancestral / co-carrier / strict-resolved patients",
        "bootstrap_selection_frequency": "Bootstrap model-selection frequency; not temporal confidence",
        "ordering_null_BH_q": "Ordering permutation BH q; all tested directions corrected",
        "training_source_categories": "Training source evidence; all seven categories",
        "evaluation_source_categories": "Evaluation source evidence; all seven categories",
        "reported_event_cooccurrence_delta": "Reported-event cooccurrence delta P; not cooperation",
    }
    colorings = [{"key": key, "title": titles.get(key, key.replace("_", " ").capitalize()), "type": "continuous" if all(isinstance(value, (int, float)) and not isinstance(value, bool) for value in values) else "categorical"} for key, values in all_values.items()]
    qvalues = [edge["null"].get("pair_direction", {}).get("BH_q") for edge in model.get("edges", [])]
    zero_eval = sum(edge["evaluation"]["strict_order_resolved"] == 0 for edge in model.get("edges", []))
    n_edges = len(model.get("edges", []))
    assessment = f"{zero_eval}/{n_edges} selected dependencies have zero strict-order-resolved evaluation patients; {sum(q is not None and q < .05 for q in qvalues)}/{len(qvalues)} selected ordering BH q values are below .05."
    description = (
        "## Separate ASCETIC selected-model edge list\n\n"
        f"{model['method']['name']}. {model['method']['input_adaptation']}\n\n"
        f"**Primary evidence remains the complete categorical patient-pair report**, not this model. [Open source evidence and exact selected DAG]({companion_url}). "
        f"Training patients: {model['cohort']['training_count']}; frozen evaluation patients: {model['cohort']['evaluation_count']}. {assessment}\n\n"
        "Every selected model edge appears once as an **independent two-event component**; repeated labels are display copies. "
        "Isolated reported events remain singleton components. These are model dependencies, not patients, clones, direct mutation transitions or reconstructed shared ancestry. "
        "Ancestral source counts use strict ancestor closure and can include intervening clusters. Same-cluster and ambiguous states remain in the co-carrier denominator. "
        "Bootstrap model-selection frequency is not probability of true ordering, and cannot replace missing resolved patient observations. Negative reported-event association must not be described as cooperation.\n\n"
        "**Horizontal position 0 to 1 is unitless display layout.** Auspice's stock Divergence, genomes and sequence-popup terms have no mutation, time or patient meaning here. "
        "No sequence changes observed means sequence mutation strings were not supplied. No sequence changes are fabricated.\n\n"
        "**Projection loss:** Native components cannot show a merged event once or a joint conditioning set as a DAG. "
        "Every copy retains the full selected-parent set; no parent is omitted or preferred and no deterministic AND or mandatory prerequisite is inferred. "
        "Auspice's hidden software forest root is not a biological ancestor. The complete exact source model, pair evidence, patient trace and copy mapping are embedded unchanged in meta.extensions.tracerx_population_model.\n\n"
        "**Limitations:** " + " ".join(map(str, model.get("limitations", []))) +
        f"\n\nSource model SHA256: `{source_sha256}`. Build date {updated} is not a patient sampling date."
    )
    result = {"version": "v2", "meta": {
        "title": f"TRACERx {histology} ASCETIC model — independent abstract edge components; unitless positions",
        "updated": updated, "warning": "SEPARATE MODEL, NOT A TUMOUR PHYLOGENY. " + assessment + " Source-category denominators matter more than a bootstrap percentage alone.",
        "description": description, "panels": ["tree"], "stream_labels": [],
        "colorings": colorings, "filters": ["event_label", "component"],
        "display_defaults": {"distance_measure": "div", "layout": "rect", "color_by": "component", "branch_label": "none", "tip_label": "component", "sidebar": "open"},
        "maintainers": [{"name": "GeNeDis source-grounded TRACERx model integration"}],
        "extensions": {"tracerx_population_model": {"source_model_sha256": source_sha256, "authoritative_model": copy.deepcopy(model), "copy_mapping": mapping, "representation": "selected_edges_as_independent_abstract_components"}},
    }, "tree": components}
    validate_projection(model, result)
    return result


def validate_projection(model, dataset):
    events, parents = selected_graph(model)
    if not isinstance(dataset["tree"], list):
        raise EvidenceError("No common population root may be created")
    observed, represented, names = [], set(), set()
    for component in dataset["tree"]:
        children = component.get("children", [])
        if component["node_attrs"]["div"] != 0 or len(children) > 1:
            raise EvidenceError("Each component contains one model edge at most")
        copies = [component, *children]
        if children:
            if children[0].get("children") or children[0]["node_attrs"]["div"] != 1:
                raise EvidenceError("Model-component position must be zero to one")
            pair = tuple(node["node_attrs"]["event_id"]["value"] for node in copies)
            observed.append(pair)
            edge = next((edge for edge in model["edges"] if pair_ids(edge) == pair), None)
            if edge is None:
                raise EvidenceError("An unselected model edge was invented")
        else:
            edge = None
        for node in copies:
            attrs = node["node_attrs"]
            event_id = attrs["event_id"]["value"]
            if node["name"] in names or event_id not in events:
                raise EvidenceError("Unknown event or duplicate display-copy identity")
            names.add(node["name"])
            represented.add(event_id)
            if attrs["full_parent_set"]["value"] != ("; ".join(parents[event_id]) or "No selected model parents"):
                raise EvidenceError("A selected joint-conditioning parent was lost")
            if edge:
                for key, value in edge_traits(edge).items():
                    expected = ("Yes" if value else "No") if isinstance(value, bool) else value
                    if attrs.get(key, {}).get("value") != expected:
                        raise EvidenceError("Source edge evidence, denominator or null metadata changed")
            if "num_date" in attrs or "mutations" in node.get("branch_attrs", {}):
                raise EvidenceError("Population dates or sequence mutations were invented")
    if set(observed) != {pair_ids(edge) for edge in model["edges"]} or len(observed) != len(model["edges"]) or represented != set(events):
        raise EvidenceError("Model edges or isolated events were lost or repeated")
    if dataset["meta"]["extensions"]["tracerx_population_model"]["authoritative_model"] != model:
        raise EvidenceError("Embedded authoritative source changed")
    return {"source_events": len(events), "source_edges": len(observed), "all_source_categories_preserved": True, "all_parent_sets_preserved": True, "biological_common_root_created": False, "invented_dates_or_mutation_lengths": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohort", choices=("luad", "lusc"), default="luad")
    parser.add_argument("--model", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    args.model = args.model or Path("tracerx_routes/inference/output/" + ("lusc/" if args.cohort == "lusc" else "") + "model.json")
    args.output = args.output or Path(f"nextstrain/datasets/tracerx_{args.cohort}_population_edges.json")
    raw = args.model.read_bytes()
    model = json.loads(raw)
    if model["cohort"]["histology"] != args.cohort.upper():
        raise EvidenceError("Source histology differs from requested cohort; no cross-cohort projection is allowed")
    result = convert(model, source_sha256=hashlib.sha256(raw).hexdigest())
    if result is None:
        print("No real retained events; no native dataset invented")
    else:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
        print(json.dumps(validate_projection(model, result)))
