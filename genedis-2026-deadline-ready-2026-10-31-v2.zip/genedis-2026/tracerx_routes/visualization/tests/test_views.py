"""Fictional boundary fixtures plus checks against the actual local source outputs."""
import copy
import hashlib
from http.server import ThreadingHTTPServer
import itertools
import json
from pathlib import Path
import sys
import tempfile
from threading import Thread
import unittest
from urllib.error import HTTPError
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "tracerx_routes" / "visualization"))
sys.path.insert(0, str(ROOT / "nextstrain" / "tests"))
from contract import COUNT_FIELDS, EvidenceError, STATES, relation_for, validate_model
from patient_trees import TreeError, convert as convert_tree, tree_slug, validate_fidelity, validate_source
from population_forest import convert as convert_model, validate_projection
from schema_validation import official_validator
from server import make_handler


def counts(states=()):
    result = dict.fromkeys(COUNT_FIELDS, 0)
    for state in states:
        result[STATES[state][0]] += 1
    result.update(co_carriers=sum(result.values()), strict_order_resolved=result["source_ancestor"] + result["reverse_ancestor"])
    return result


def fictional_model():
    # Each fictional patient carries two events. Aggregate directions across
    # patients form A->B->C->A without inventing a cyclic within-patient tree.
    patients = []
    for number, (a, b) in enumerate((("A", "B"), ("B", "C"), ("C", "A"))):
        patients.append({"id": f"Fictional-{number}", "role": "training" if number < 2 else "evaluation", "n_regions": 2, "n_topologies": 1, "events": [{"gene": a, "cluster_ids": ["1"]}, {"gene": b, "cluster_ids": ["2"]}], "relations": [{"a": a, "b": b, "state": "a_ancestor_b"}]})
    events = [{"id": gene, "label": gene, **{f"carriers_{role}": sum(p["role"] == role and any(e["gene"] == gene for e in p["events"]) for p in patients) for role in ("training", "evaluation")}} for gene in "ABC"]
    pairs = []
    for a, b in itertools.combinations("ABC", 2):
        pairs.append({"a": a, "b": b, **{role: counts([r["state"] for p in patients if p["role"] == role and (r := relation_for(p, a, b))]) for role in ("training", "evaluation")}})
    return {"model_id": "fictional-boundary-only", "title": "Explicitly fictional test fixture", "method": {"name": "Fictional fixture", "estimand": "Boundary tests", "input_adaptation": "Test only"}, "cohort": {"histology": "Fictional", "patient_count": 3, "training_count": 2, "evaluation_count": 1}, "patients": patients, "events": events, "pair_evidence": pairs, "edges": []}


def fictional_tree(chain=False):
    source = {"patient_id": "FICTIONAL", "tumor_id": "FICTIONAL", "source": {"publication_title": "Fictional source used only in tests", "publication_url": "https://example.invalid/publication", "data_url": "https://example.invalid/data", "license": "Fictional test only", "license_url": "https://example.invalid/terms", "source_file": "fixture", "sha256": "a" * 64}, "branch_length": {"mode": "published", "units": "SNVs per cluster", "source_evidence": "Fictional boundary fixture"}, "root_id": "1", "root_stem": {"length": 9, "description": "Fictional source stem"}, "n_topologies": 2, "source_encoding": "approved exact singleton sentinel", "literal_source_corrected_edges": [["1", "1"]], "nodes": [{"id": "1", "parent_id": None, "label": "Cluster 1", "branch_length": 9, "source_node_type": "inferred cluster", "attributes": {"curated_driver_genes": "A; B", "region_1_ccf_percent": 101, "source_edge_consensus": "yes"}}]}
    if chain:
        source["nodes"].append({"id": "2", "parent_id": "1", "label": "Cluster 2", "branch_length": 3, "source_node_type": "inferred cluster", "attributes": {"curated_driver_genes": "C", "source_edge_consensus": "no"}})
    return source


class EvidenceContractTests(unittest.TestCase):
    def test_category_partition_independent_votes_and_aggregate_cycle(self):
        model = fictional_model()
        self.assertEqual(validate_model(model)["pairs"], 3)
        changed = copy.deepcopy(model)
        changed["pair_evidence"][0]["training"]["same_cluster"] = 1
        with self.assertRaisesRegex(EvidenceError, "partition"):
            validate_model(changed)
        changed = copy.deepcopy(model)
        changed["pair_evidence"][0]["training"].update(source_ancestor=0, same_cluster=1, strict_order_resolved=0)
        with self.assertRaisesRegex(EvidenceError, "independent patient trace"):
            validate_model(changed)

    def test_reverse_orientation_and_patient_pair_completeness(self):
        model = fictional_model()
        self.assertEqual(relation_for(model["patients"][2], "A", "C")["state"], "b_ancestor_a")
        model["patients"][0]["relations"].clear()
        with self.assertRaisesRegex(EvidenceError, "omit or invent"):
            validate_model(model)

    def test_duplicate_vote_and_missing_pair_are_rejected(self):
        model = fictional_model()
        model["patients"][0]["relations"] *= 2
        with self.assertRaises(EvidenceError):
            validate_model(model)
        model = fictional_model()
        model["pair_evidence"].pop()
        with self.assertRaisesRegex(EvidenceError, "All unordered"):
            validate_model(model)

    def test_native_model_merges_keep_all_parents_without_patient_roots(self):
        model = fictional_model()
        for a, b in (("A", "C"), ("B", "C")):
            edge = {"source": a, "target": b, "selected": True, "relation": "Fictional model dependency", "bootstrap": {"selected_count": 1, "successful_runs": 2, "selection_frequency": .5}, "null": {"pair_direction": {"p": 1, "BH_q": 1}}}
            for role in ("training", "evaluation"):
                edge[role] = counts([r["state"] for p in model["patients"] if p["role"] == role and (r := relation_for(p, a, b))])
            model["edges"].append(edge)
        output = convert_model(model, source_sha256="a" * 64)
        self.assertEqual(len(output["tree"]), 2)
        for component in output["tree"]:
            child = component["children"][0]
            self.assertEqual(child["node_attrs"]["event_id"]["value"], "C")
            self.assertEqual(child["node_attrs"]["full_parent_set"]["value"], "A; B")
            self.assertEqual((component["node_attrs"]["div"], child["node_attrs"]["div"]), (0, 1))
        validate_projection(model, output)

    def test_no_selected_edges_remain_isolated_events_without_fake_routes(self):
        model = fictional_model()
        output = convert_model(model, source_sha256="a" * 64)
        self.assertEqual(len(output["tree"]), 3)
        self.assertTrue(all(not node.get("children") for node in output["tree"]))
        self.assertEqual(validate_projection(model, output)["source_edges"], 0)


class SourceTreeTests(unittest.TestCase):
    def test_singleton_stem_literal_encoding_and_chain_are_preserved(self):
        for chain in (False, True):
            source = fictional_tree(chain)
            output = convert_tree(source, source_sha256="b" * 64)
            report = validate_fidelity(source, output)
            self.assertEqual(report["source_edges"], int(chain))
            self.assertEqual(report["source_snv_count"], 12 if chain else 9)
            node = output["tree"]["children"][0]
            self.assertEqual(node["node_attrs"]["div"], 9)
            self.assertEqual(node["node_attrs"]["region_1_ccf_percent"]["value"], 101)
            self.assertEqual(output["meta"]["extensions"]["tracerx_patient_source"]["source_extract"]["literal_source_corrected_edges"], [["1", "1"]])
            self.assertFalse(list(official_validator().iter_errors(output)))

    def test_arbitrary_self_loop_missing_provenance_or_changed_source_annotation_rejected(self):
        source = fictional_tree()
        source["nodes"][0]["parent_id"] = "1"
        with self.assertRaises(TreeError):
            validate_source(source)
        source = fictional_tree()
        source["source"].pop("license_url")
        with self.assertRaises(TreeError):
            validate_source(source)
        source = fictional_tree()
        output = convert_tree(source, source_sha256="b" * 64)
        output["tree"]["children"][0]["node_attrs"]["source_snv_count"]["value"] = 0
        with self.assertRaisesRegex(TreeError, "SNV count"):
            validate_fidelity(source, output)


class ActualLocalIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.path = ROOT / "tracerx_routes/inference/output/model.json"
        if not cls.path.exists():
            raise unittest.SkipTest("Actual ignored source evidence not prepared; no fixture substituted")
        cls.raw = cls.path.read_bytes()
        cls.model = json.loads(cls.raw)

    def test_actual_patient_event_pair_denominators(self):
        report = validate_model(self.model)
        self.assertEqual((report["patient_count"], report["events"], report["pairs"]), (217, 12, 66))
        event = next(e for e in self.model["events"] if e["id"] == "RBM10")
        self.assertEqual((event["carriers_training"], event["carriers_evaluation"], event["uniquely_mapped_training"], event["uniquely_mapped_evaluation"]), (19, 8, 0, 0))

    def test_every_actual_patient_tree_source_fidelity_and_official_schema(self):
        paths = sorted((ROOT / "tracerx_routes/source/output/patient_trees").glob("*.json"))
        self.assertEqual(len(paths), 217)
        validator = official_validator()
        singletons = 0
        for path in paths:
            with self.subTest(source=path.name):
                source = json.loads(path.read_bytes())
                output = json.loads((ROOT / "nextstrain/datasets" / f"tracerx_patient_{tree_slug(source['tumor_id'])}.json").read_bytes())
                report = validate_fidelity(source, output)
                self.assertFalse(list(validator.iter_errors(output)))
                singletons += report["source_nodes"] == 1
                self.assertEqual(output["meta"]["extensions"]["tracerx_patient_source"]["source_extract_sha256"], hashlib.sha256(path.read_bytes()).hexdigest())
        self.assertEqual(singletons, 3)

    def test_actual_model_forest_preserves_uncertain_source_evidence_and_parent_sets(self):
        dataset = convert_model(self.model, source_sha256=hashlib.sha256(self.raw).hexdigest())
        report = validate_projection(self.model, dataset)
        self.assertEqual(report["source_edges"], 3)
        self.assertFalse(list(official_validator().iter_errors(dataset)))
        component = next(c for c in dataset["tree"] if c["node_attrs"]["component"]["value"] == "KEAP1 → STK11")
        attrs = component["children"][0]["node_attrs"]
        self.assertEqual(attrs["bootstrap_selection_frequency"]["value"], .85)
        self.assertEqual(attrs["training_source_order"]["value"], "2 ancestral / 12 co-carriers; 2 strict-order resolved")
        self.assertEqual(attrs["evaluation_source_order"]["value"], "0 ancestral / 5 co-carriers; 0 strict-order resolved")
        self.assertEqual(attrs["ordering_null_BH_q"]["value"], 1.0)
        attrs["training_co_carriers"]["value"] = 2
        with self.assertRaisesRegex(EvidenceError, "denominator"):
            validate_projection(self.model, dataset)

    def test_model_edge_evidence_cannot_disagree_with_primary_patient_trace(self):
        model = copy.deepcopy(self.model)
        model["edges"][1]["training"]["source_ancestor"] += 1
        with self.assertRaisesRegex(EvidenceError, "independent patient votes"):
            convert_model(model, source_sha256="a" * 64)

    def test_actual_internal_driver_branch_labels_follow_source_clusters(self):
        patient = next(p for p in self.model["patients"] if p["role"] == "training" and (r := relation_for(p, "KEAP1", "STK11")) and r["state"] == "a_ancestor_b")
        source = json.loads((ROOT / "tracerx_routes/source/output/patient_trees" / f"{patient['tumour_id']}.json").read_bytes())
        output = convert_tree(source, source_sha256="a" * 64)
        labels = {}
        def visit(node):
            attrs = node["node_attrs"]
            if "source_cluster_id" in attrs:
                labels[attrs["source_cluster_id"]["value"]] = node.get("branch_attrs", {}).get("labels", {}).get("drivers")
            for child in node.get("children", []):
                visit(child)
        visit(output["tree"])
        expected = {str(row["id"]): row.get("attributes", {}).get("curated_driver_genes") if row.get("attributes", {}).get("curated_driver_genes") not in (None, "", "none assigned") else None for row in source["nodes"]}
        self.assertEqual(labels, expected)
        self.assertTrue(any(value and "KEAP1" in value for value in labels.values()))
        self.assertTrue(any(value and "STK11" in value for value in labels.values()))
        self.assertEqual(output["meta"]["display_defaults"]["branch_label"], "drivers")


class ReadonlyHTTPTests(unittest.TestCase):
    def test_validated_source_bytes_whitelist_and_fail_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            model_path = Path(directory) / "model.json"
            raw = json.dumps(fictional_model()).encode()
            model_path.write_bytes(raw)
            server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(model_path, Path(directory) / "absent.json"))
            thread = Thread(target=server.serve_forever, daemon=True)
            thread.start()
            url = f"http://127.0.0.1:{server.server_port}"
            try:
                self.assertEqual(urlopen(url + "/source-model.json").read(), raw)
                response = json.load(urlopen(url + "/model.json"))
                self.assertEqual(response["sha256"], hashlib.sha256(raw).hexdigest())
                self.assertEqual(response["display_audit"]["pairs"], 3)
                with self.assertRaises(HTTPError) as caught:
                    urlopen(url + "/contract.py")
                self.assertEqual(caught.exception.code, 404)
                model_path.write_text("{}")
                with self.assertRaises(HTTPError) as caught:
                    urlopen(url + "/model.json")
                self.assertEqual(caught.exception.code, 503)
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=2)

    def test_separate_histology_routes_exact_bytes_and_no_wrong_source_fallback(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            paths = {key: root / f"{key}.json" for key in ("luad", "lusc")}
            raw = {}
            for cohort, path in paths.items():
                model = fictional_model()
                model["cohort"]["histology"] = cohort.upper()
                raw[cohort] = json.dumps(model).encode()
                path.write_bytes(raw[cohort])
            handler = make_handler(paths["luad"], root / "no-luad-report.json", lusc_model_path=paths["lusc"], lusc_tree_report=root / "no-lusc-report.json", strict_histology=True)
            server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
            thread = Thread(target=server.serve_forever, daemon=True)
            thread.start()
            url = f"http://127.0.0.1:{server.server_port}"
            try:
                self.assertEqual(urlopen(url + "/source-model.json").read(), raw["luad"])
                self.assertEqual(urlopen(url + "/source-model.json?cohort=lusc").read(), raw["lusc"])
                result = json.load(urlopen(url + "/model.json?cohort=lusc"))
                self.assertEqual(result["model"]["cohort"]["histology"], "LUSC")
                self.assertEqual(result["native_model_url"], "http://127.0.0.1:4000/tracerx/lusc/population/edges")
                for suffix in ("?cohort=pooled", "?cohort=", "?cohort=luad&cohort=lusc"):
                    with self.assertRaises(HTTPError) as caught:
                        urlopen(url + "/model.json" + suffix)
                    self.assertEqual(caught.exception.code, 400)
                paths["lusc"].write_bytes(raw["luad"])
                with self.assertRaises(HTTPError) as caught:
                    urlopen(url + "/model.json?cohort=lusc")
                self.assertEqual(caught.exception.code, 503)
                paths["lusc"].unlink()
                with self.assertRaises(HTTPError) as caught:
                    urlopen(url + "/source-model.json?cohort=lusc")
                self.assertEqual(caught.exception.code, 503)
                self.assertEqual(urlopen(url + "/source-model.json").read(), raw["luad"])
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=2)

    def test_foreign_patient_tree_report_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, report = root / "model.json", root / "report.json"
            path.write_text(json.dumps(fictional_model()))
            report.write_text(json.dumps({"published_tree_exports": [{"patient_id": "FICTIONAL-FOREIGN", "evidence_url": "http://127.0.0.1:4000/tracerx/patient/FICTIONAL-FOREIGN"}]}))
            server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(path, report))
            thread = Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                with self.assertRaises(HTTPError) as caught:
                    urlopen(f"http://127.0.0.1:{server.server_port}/model.json")
                self.assertEqual(caught.exception.code, 503)
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=2)


class SeparateHistologyProjectionTests(unittest.TestCase):
    def test_squamous_native_titles_metadata_and_zero_edge_components(self):
        source = fictional_tree()
        source["histology"] = "LUSC"
        output = convert_tree(source, source_sha256="b" * 64)
        self.assertIn("TRACERx LUSC", output["meta"]["title"])
        self.assertEqual(output["tree"]["children"][0]["node_attrs"]["source_histology"]["value"], "LUSC")
        self.assertFalse(list(official_validator().iter_errors(output)))
        model = fictional_model()
        model["cohort"]["histology"] = "LUSC"
        projection = convert_model(model, source_sha256="c" * 64)
        self.assertIn("TRACERx LUSC", projection["meta"]["title"])
        self.assertIn("http://127.0.0.1:4002/?cohort=lusc", projection["meta"]["description"])
        self.assertEqual(validate_projection(model, projection)["source_edges"], 0)
        self.assertFalse(list(official_validator().iter_errors(projection)))

    def test_existing_luad_native_model_projection_content_is_unchanged(self):
        path = ROOT / "tracerx_routes/inference/output/model.json"
        dataset = ROOT / "nextstrain/datasets/tracerx_luad_population_edges.json"
        if not path.exists() or not dataset.exists():
            self.skipTest("Actual LUAD source or native projection not prepared")
        raw = path.read_bytes()
        self.assertEqual(convert_model(json.loads(raw), source_sha256=hashlib.sha256(raw).hexdigest()), json.loads(dataset.read_bytes()))


class ActualSquamousIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.path = ROOT / "tracerx_routes/inference/output/lusc/model.json"
        if not cls.path.exists():
            raise unittest.SkipTest("Actual separate LUSC evidence not prepared; no fixture substituted")
        cls.raw = cls.path.read_bytes()
        cls.model = json.loads(cls.raw)

    def test_actual_cohort_independence_categories_and_native_model(self):
        audit = validate_model(self.model)
        self.assertEqual(audit["patient_count"], 125)
        self.assertEqual(self.model["cohort"]["histology"], "LUSC")
        self.assertEqual((self.model["cohort"]["training_count"], self.model["cohort"]["evaluation_count"]), (88, 37))
        luad = json.loads((ROOT / "tracerx_routes/inference/output/model.json").read_bytes())
        self.assertFalse({p["id"] for p in self.model["patients"]} & {p["id"] for p in luad["patients"]})
        output = convert_model(self.model, source_sha256=hashlib.sha256(self.raw).hexdigest())
        if self.model["events"]:
            self.assertEqual(validate_projection(self.model, output)["source_edges"], len(self.model["edges"]))
            self.assertFalse(list(official_validator().iter_errors(output)))
        else:
            self.assertIsNone(output)

    def test_all_actual_squamous_patient_trees_source_fidelity_and_schema(self):
        paths = sorted((ROOT / "tracerx_routes/source/output/lusc/patient_trees").glob("*.json"))
        self.assertEqual(len(paths), 125)
        validator = official_validator()
        for path in paths:
            with self.subTest(source=path.name):
                source = json.loads(path.read_bytes())
                self.assertEqual(source["histology"], "LUSC")
                output = json.loads((ROOT / "nextstrain/datasets" / f"tracerx_patient_{tree_slug(source['tumor_id'])}.json").read_bytes())
                validate_fidelity(source, output)
                self.assertIn("TRACERx LUSC", output["meta"]["title"])
                self.assertFalse(list(validator.iter_errors(output)))
                self.assertEqual(output["meta"]["extensions"]["tracerx_patient_source"]["source_extract_sha256"], hashlib.sha256(path.read_bytes()).hexdigest())


if __name__ == "__main__":
    unittest.main()
