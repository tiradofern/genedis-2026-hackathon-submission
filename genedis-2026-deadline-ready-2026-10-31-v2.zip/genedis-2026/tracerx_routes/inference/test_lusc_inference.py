"""Independent actual-data checks for the separately frozen squamous extension."""
from collections import Counter
import copy
import hashlib
from itertools import combinations
import json
from pathlib import Path
import unittest

from evidence import bh, counts, joint_holdout, ordering_null, split_patients
from prepare_inputs import HERE, ROOT, sha
from run_lusc import finalize, prepare_lusc, verify_frozen_inputs


class LuscExtensionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source_path = HERE.parent / "source/output/lusc/cohort_trees.json"
        cls.config_path = ROOT / "configs/tracerx_routes_lusc_v0_1.json"
        cls.output = HERE / "output/lusc"
        if not cls.source_path.exists() or not (cls.output / "model.json").exists():
            raise unittest.SkipTest("Public source and completed LUSC analysis are absent")
        cls.source = json.loads(cls.source_path.read_text())
        cls.config = json.loads(cls.config_path.read_text())
        cls.model = json.loads((cls.output / "model.json").read_text())

    def test_independent_lusc_population_and_frozen_role_assignment(self):
        ids = [row["patient_id"] for row in self.source["patients"]]
        luad = json.loads((HERE / "output/model.json").read_text())
        self.assertEqual(len(set(ids)), 125)
        self.assertTrue(set(ids).isdisjoint(row["id"] for row in luad["patients"]))
        expected = split_patients(ids, self.config)
        self.assertEqual({row["id"]: row["role"] for row in self.model["patients"]}, expected)
        self.assertEqual(Counter(expected.values()), {"training": 88, "evaluation": 37})
        self.assertTrue(all(row["histology"] == "LUSC" and row["n_primary_regions"] >= 2 for row in self.source["patients"]))

    def test_all_ten_candidates_receive_exact_training_only_gate(self):
        roles = {row["id"]: row["role"] for row in self.model["patients"]}
        observed = {row["id"]: row for row in self.model["candidate_events"]}
        self.assertEqual(set(observed), set(self.config["events"]["candidate_genes"]))
        self.assertEqual(len(observed), 10)
        for gene, event in observed.items():
            carriers = sum(any(driver["gene"] == gene for driver in row["drivers"])
                for row in self.source["patients"] if roles[row["patient_id"]] == "training")
            self.assertEqual(event["carriers_training"], carriers)
            self.assertEqual(event["noncarriers_training"], 88 - carriers)
            self.assertEqual(event["eligible"], carriers >= 10 and 88 - carriers >= 10)
        self.assertEqual({row["id"] for row in self.model["events"]}, {gene for gene, row in observed.items() if row["eligible"]})

    def test_literal_source_gene_is_preserved_and_only_frozen_alias_applied(self):
        aliases = self.config["events"]["candidate_gene_symbol_aliases"]
        self.assertEqual(aliases, {"MLL2": "KMT2D"})
        for row in self.source["patients"]:
            for driver in row["drivers"]:
                self.assertIn("raw_source_gene", driver)
                self.assertEqual(driver["gene"], aliases.get(driver["raw_source_gene"], driver["raw_source_gene"]))

    def test_every_actual_vote_matches_separately_exported_ancestor_closures(self):
        sources = {row["patient_id"]: row for row in self.source["patients"]}
        for patient in self.model["patients"]:
            row = sources[patient["id"]]
            events = {event["gene"]: event for event in row["events"]}
            strict = {tuple(pair) for pair in row["strict_ancestor_pairs"]}
            possible = {tuple(pair) for pair in row["possible_ancestor_pairs"]}
            self.assertEqual(len(patient["relations"]), len(patient["events"]) * (len(patient["events"]) - 1) // 2)
            for pair in patient["relations"]:
                a, b = events[pair["a"]], events[pair["b"]]
                states = {a["mapping_status"], b["mapping_status"]}
                if "unresolved_driver_mapping" in states: expected = "mapping_ambiguous"
                elif "repeated_hit_different_clusters" in states: expected = "repeated_gene_ambiguous"
                else:
                    ca, cb = a["cluster_ids"][0], b["cluster_ids"][0]
                    if ca == cb: expected = "same_cluster"
                    elif (ca, cb) in strict: expected = "a_ancestor_b"
                    elif (cb, ca) in strict: expected = "b_ancestor_a"
                    elif (ca, cb) in possible or (cb, ca) in possible: expected = "topology_ambiguous"
                    else: expected = "incomparable"
                self.assertEqual(pair["state"], expected)
        for pair in self.model["pair_evidence"]:
            for role in ("training", "evaluation"):
                self.assertEqual(pair[role], counts([p for p in self.model["patients"] if p["role"] == role], pair["a"], pair["b"]))

    def test_primary_null_is_exactly_reproducible_and_uses_all_twenty_directions(self):
        events = [row["id"] for row in self.model["events"]]
        training = [row for row in self.model["patients"] if row["role"] == "training"]
        expected = ordering_null(training, events, 10000, self.config["engine"]["seed"] + 40000)
        actual = json.loads((self.output / "ordering_null_all_pairs.json").read_text())
        self.assertEqual(actual, expected)
        self.assertEqual(len(actual), 20)
        self.assertEqual({(row["source"], row["target"]) for row in actual}, {(a, b) for a in events for b in events if a != b})
        self.assertEqual([row["BH_q"] for row in actual], bh([row["p"] for row in actual]))

    def test_real_engine_integrity_all_fits_and_full_selected_parents(self):
        engine = json.loads((self.output / "engine_output.json").read_text())
        integrity = engine["input_integrity"]
        self.assertEqual(integrity["input_md5"], hashlib.md5((self.output / "engine_inputs.json").read_bytes()).hexdigest())
        self.assertEqual(integrity["config_md5"], hashlib.md5(self.config_path.read_bytes()).hexdigest())
        self.assertEqual(integrity["event_ids"], [row["id"] for row in self.model["events"]])
        self.assertEqual(engine["patient_bootstrap"]["successful"], 100)
        self.assertEqual(engine["ordering_null"]["successful"], 100)
        self.assertEqual(engine["engine"]["version"], "1.2.0")
        self.assertTrue(engine["engine"]["source_unchanged"])
        arrows = {(row["source"], row["target"]) for row in engine["selected_edges"]}
        self.assertEqual(arrows, {(row["source"], row["target"]) for row in self.model["edges"]})
        for gene, parents in self.model["audit"]["full_parent_sets"].items():
            self.assertEqual(parents, sorted(a for a, b in arrows if b == gene))

    def test_actual_holdout_has_no_refit_and_training_CPTs_ignore_evaluation(self):
        events = [row["id"] for row in self.model["events"]]
        edges = [(row["source"], row["target"]) for row in self.model["edges"]]
        actual = joint_holdout(self.model["patients"], events, edges)
        self.assertEqual(actual, self.model["validation"]["holdout"])
        changed = copy.deepcopy(self.model["patients"])
        for patient in changed:
            if patient["role"] == "evaluation": patient["events"] = []
        altered = joint_holdout(changed, events, edges)
        self.assertEqual(actual["training_CPTs"], altered["training_CPTs"])
        self.assertEqual(actual["evaluation_n"], 37)

    def test_frozen_source_audit_and_code_snapshots_are_exact(self):
        lock, audit = verify_frozen_inputs(self.source_path, self.config_path)
        self.assertEqual(self.model["provenance"]["frozen_source_audit_sha256"], lock["source_audit_sha256"])
        self.assertEqual(sha(audit), lock["source_audit_sha256"])
        provenance_files = {"cohort_wrapper_sha256": "run_lusc.py", "preparation_code_sha256": "prepare_inputs.py",
            "evidence_code_sha256": "evidence.py", "engine_wrapper_sha256": "run_ascetic.R", "runtime_lock_sha256": "runtime_lock.json"}
        for key, name in provenance_files.items():
            self.assertEqual(self.model["provenance"][key], sha(HERE / name))
            self.assertEqual((HERE / name).read_bytes(), (self.output / "reproducibility_snapshot" / name).read_bytes())

    def test_luad_inputs_and_outputs_are_guarded_and_model_unchanged(self):
        with self.assertRaisesRegex(ValueError, "LUSC configuration"):
            prepare_lusc(self.source_path, ROOT / "configs/tracerx_routes_v0_1.json", self.output)
        with self.assertRaisesRegex(ValueError, "LUAD source"):
            prepare_lusc(HERE.parent / "source/output/cohort_trees.json", self.config_path, self.output)
        with self.assertRaisesRegex(ValueError, "LUAD output"):
            prepare_lusc(self.source_path, self.config_path, HERE / "output")
        with self.assertRaisesRegex(ValueError, "immutable LUAD"):
            finalize(self.output, self.config_path, HERE / "results_summary.json")
        self.assertEqual(sha(HERE / "output/model.json"), "4c8fb4ad79684a4dfe37363ffe88c7adcec4b4604498c2ed2131cf84d0b7c04b")


if __name__ == "__main__":
    unittest.main()
