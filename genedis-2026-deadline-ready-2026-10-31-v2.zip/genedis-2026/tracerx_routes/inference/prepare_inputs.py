"""Validate frozen TRACERx input contract and prepare independent patient orders."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
from itertools import combinations
import json
from pathlib import Path
import shutil

from evidence import consensus_gene_relations, counts, split_patients

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_source(source: dict, config: dict, config_hash: str) -> None:
    if source.get("structural_gate") != "passed" or source.get("structural_issues"):
        raise ValueError("Source structural input gate did not pass")
    if source["provenance"]["config_sha256"] != config_hash:
        raise ValueError("Source cohort was not prepared against this frozen configuration")
    patients = source["patients"]
    if len(patients) != config["eligibility"]["expected_participants_before_structural_input_checks"]:
        raise ValueError("Unexpected frozen independent patient denominator")
    ids = [row["patient_id"] for row in patients]
    tumours = [row["tumour_id"] for row in patients]
    if len(set(ids)) != len(ids) or len(set(tumours)) != len(tumours):
        raise ValueError("Source patients/tumours are not independent")
    for patient in patients:
        if patient["histology"] != config["primary_cohort"] or patient["n_primary_regions"] < config["eligibility"]["minimum_distinct_primary_R_regions"]:
            raise ValueError("Cohort or multiregion gate failed")
        if patient["structural_gate"] != "passed" or patient["source_consensus_relationships_verified"] is not True or patient["n_topologies"] < 1:
            raise ValueError("Not every alternative is validated and consensus checked")
        parents = {str(row["id"]): str(row["parent"]) if row["parent"] is not None else None for row in patient["nodes"]}
        if len(parents) != len(patient["nodes"]) or sum(value is None for value in parents.values()) != 1:
            raise ValueError("Corrected tree does not have unique nodes and one root")
        for node in parents:
            seen = set()
            current = node
            while current is not None:
                if current in seen or current not in parents:
                    raise ValueError("Corrected tree has a cycle or missing parent")
                seen.add(current)
                current = parents[current]
        seen_variants = set()
        for row in patient["drivers"]:
            if row["source_driver"] is not True or row["variant_id"] in seen_variants:
                raise ValueError("Driver provenance or exact variant uniqueness failed")
            seen_variants.add(row["variant_id"])
            if row["mapping_status"] == "mapped_retained" and (str(row["cluster_id"]) not in parents or str(row["embedded_cluster_id"]) != str(row["cluster_id"])):
                raise ValueError("Curated variant is not exactly mapped to a retained cluster")
        expected = len(parents)*(len(parents)-1)//2
        if len(patient["consensus_relations"]) != expected:
            raise ValueError("Source consensus does not cover all retained cluster pairs")


def prepare(source: dict, config: dict, config_hash: str) -> dict:
    validate_source(source, config, config_hash)
    roles = split_patients([row["patient_id"] for row in source["patients"]], config)
    candidates = config["events"]["candidate_genes"]
    patients = []
    for row in source["patients"]:
        derived = consensus_gene_relations(row, candidates)
        # Independently compare the mutation-level lift with the source audit's
        # gene summary; no first variant or source timing label is substituted.
        source_events = {event["gene"]: event for event in row["events"] if event["gene"] in candidates}
        if set(source_events) != {event["gene"] for event in derived["events"]}:
            raise ValueError("Mutation-derived source gene presence disagrees with source audit")
        for event in derived["events"]:
            original = source_events[event["gene"]]
            if sorted(original["cluster_ids"]) != event["cluster_ids"]:
                raise ValueError("Mutation-level cluster aggregation disagrees with source audit")
            if (original["mapping_status"] == "unique_source_cluster") != (event["mapping_status"] == "unique_cluster"):
                raise ValueError("Mutation-level mapping certainty disagrees with source audit")
        patients.append({"id": row["patient_id"], "tumour_id": row["tumour_id"], "histology": row["histology"],
                         "role": roles[row["patient_id"]], "n_regions": row["n_regions"], "n_primary_regions": row["n_primary_regions"],
                         "n_ln_regions": row["n_ln_regions"], "n_topologies": row["n_topologies"], "region_ids": row["region_ids"],
                         "treatment": row["treatment"], "canonical_warning": "Displayed corrected topology is one authors-selected alternative; population ordered votes require every deposited alternative to agree.",
                         "evidence_url": "http://127.0.0.1:4000/tracerx/patient/" + row["tumour_id"].lower(), **derived})
    training = [row for row in patients if row["role"] == "training"]
    evaluation = [row for row in patients if row["role"] == "evaluation"]
    candidate_rows = []
    for gene in candidates:
        carriers = sum(any(event["gene"] == gene for event in patient["events"]) for patient in training)
        noncarriers = len(training)-carriers
        eligible = carriers >= config["events"]["minimum_training_carriers"] and noncarriers >= config["events"]["minimum_training_noncarriers"]
        candidate_rows.append({"id": gene, "label": gene, "carriers_training": carriers,
                               "noncarriers_training": noncarriers, "eligible": eligible,
                               "exclusion": None if eligible else "Frozen training carrier/noncarrier frequency gate; not negative biological evidence"})
    selected = [row["id"] for row in candidate_rows if row["eligible"]]
    for patient in patients:
        patient["events"] = [row for row in patient["events"] if row["gene"] in selected]
        patient["relations"] = [row for row in patient["relations"] if row["a"] in selected and row["b"] in selected]
    events = []
    for gene in selected:
        original = next(row for row in candidate_rows if row["id"] == gene)
        events.append({**original, "carriers_evaluation": sum(any(event["gene"] == gene for event in patient["events"]) for patient in evaluation),
                       "uniquely_mapped_training": sum(any(event["gene"] == gene and event["mapping_status"] == "unique_cluster" for event in patient["events"]) for patient in training),
                       "uniquely_mapped_evaluation": sum(any(event["gene"] == gene and event["mapping_status"] == "unique_cluster" for event in patient["events"]) for patient in evaluation),
                       "eligible_denominator_training": len(training), "eligible_denominator_evaluation": len(evaluation),
                       "definition": config["events"]["definition"], "absence_meaning": config["events"]["zero"]})
    pairs = [{"a": a, "b": b, "training": counts(training, a, b), "evaluation": counts(evaluation, a, b)} for a, b in combinations(selected, 2)]
    return {"schema_version": "1.0", "model_id": "tracerx_luad_multiregion_v0_1", "title": "TRACERx LUAD: source-grounded multi-region ordering evidence",
            "model_status": "prepared_not_fitted", "method": {"name": "Strict all-alternative source ancestry evidence; ASCETIC secondary model",
                 "estimand": config["question"], "input_adaptation": config["engine"]["input_adaptation"], "assumptions": ["Published inferred trees and curated driver annotation are inputs, not independently validated truth", "Same-cluster and separate-branch events do not receive invented time orders", "Gene event presence does not imply every variant is functionally equivalent", "Source ancestor closure can contain intervening clusters and is not a direct next-mutation transition"]},
            "cohort": {"histology": config["primary_cohort"], "patient_count": len(patients), "training_count": len(training), "evaluation_count": len(evaluation),
                       "single_topology_patients": sum(row["n_topologies"] == 1 for row in patients), "multiple_topology_patients": sum(row["n_topologies"] > 1 for row in patients),
                       "minimum_primary_regions": config["eligibility"]["minimum_distinct_primary_R_regions"], "multiprimary_patients_excluded": True,
                       "lymph_node_context": config["eligibility"]["retain_full_same_surgery_source_tree_including_lymph_nodes"]},
            "candidate_events": candidate_rows, "events": events, "pair_evidence": pairs, "patients": patients, "edges": [],
            "provenance": {"source": source["provenance"], "configuration_sha256": config_hash},
            "limitations": [config["assessment"]["claim_status"], config["events"]["zero"],
                            "Cluster-level same-branch events have unresolved within-cluster order; incomparable branches are not temporal ties.",
                            "Alternative topology disagreement, repeated gene hits and failed/removed mappings cast no ordered vote.",
                            "Authors-selected driver labels and gene aggregation do not establish functional equivalence of variants.",
                            "Lymph-node samples in the same-surgery source reconstruction are retained; at least two primary R regions are separately required.",
                            "Per-patient neoadjuvant status is not supplied; missing treatment metadata are not imputed."]}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=HERE.parent / "source/output/cohort_trees.json")
    parser.add_argument("--config", type=Path, default=ROOT / "configs/tracerx_routes_v0_1.json")
    parser.add_argument("--output", type=Path, default=HERE / "output")
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    source = json.loads(args.source.read_text())
    model = prepare(source, config, sha(args.config))
    model["provenance"].update({"cohort_trees_sha256": sha(args.source), "runtime_lock_sha256": sha(HERE / "runtime_lock.json"),
                              "preparation_code_sha256": sha(Path(__file__)), "evidence_code_sha256": sha(HERE / "evidence.py"), "engine_wrapper_sha256": sha(HERE / "run_ascetic.R")})
    args.output.mkdir(parents=True, exist_ok=True)
    inputs = {"events": [event["id"] for event in model["events"]], "patients": []}
    for row in model["patients"]:
        arrows = []
        for pair in row["relations"]:
            if pair["state"] == "a_ancestor_b": arrows.append([pair["a"], pair["b"]])
            elif pair["state"] == "b_ancestor_a": arrows.append([pair["b"], pair["a"]])
        inputs["patients"].append({"id": row["id"], "role": row["role"], "present": [event["gene"] for event in row["events"]],
                                   "unique": [event["gene"] for event in row["events"] if event["mapping_status"] == "unique_cluster"], "arrows": arrows})
    (args.output / "engine_inputs.json").write_text(json.dumps(inputs, indent=2) + "\n")
    model["provenance"]["engine_inputs_sha256"] = sha(args.output / "engine_inputs.json")
    frozen_audit = HERE.parent / "source/output/at_freeze/input_readiness_audit.json"
    if not frozen_audit.exists():
        frozen_audit = HERE.parent / "source/output/at_freeze/source_audit.json"
    if frozen_audit.exists():
        model["provenance"]["frozen_source_audit_sha256"] = sha(frozen_audit)
    (args.output / "prepared_evidence.json").write_text(json.dumps(model, indent=2, allow_nan=False) + "\n")
    snapshot = args.output / "reproducibility_snapshot"
    snapshot.mkdir(exist_ok=True)
    for file in (args.config, args.source, HERE / "runtime_lock.json", HERE / "evidence.py", Path(__file__), HERE / "run_ascetic.R"):
        shutil.copyfile(file, snapshot / file.name)
    print(f"Prepared {len(model['patients'])} independent patients and {len(model['events'])} frozen-training-eligible events")


if __name__ == "__main__":
    main()
