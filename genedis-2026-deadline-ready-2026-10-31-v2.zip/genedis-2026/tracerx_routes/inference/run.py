"""Run the frozen genuine engine and assess strict source-order patient evidence."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from evidence import counts, joint_holdout, ordering_null
from prepare_inputs import HERE, ROOT, sha


def finalize(output: Path, config_path: Path) -> dict:
    config = json.loads(config_path.read_text())
    prepared_path = output / "prepared_evidence.json"
    model = json.loads(prepared_path.read_text())
    if model["provenance"]["configuration_sha256"] != sha(config_path):
        raise ValueError("Frozen configuration changed after preparation")
    inputs_path = output / "engine_inputs.json"
    if model["provenance"]["engine_inputs_sha256"] != sha(inputs_path):
        raise ValueError("Engine input changed after preparation")
    engine_path = output / "engine_output.json"
    engine = json.loads(engine_path.read_text())
    integrity = engine["input_integrity"]
    if integrity["input_md5"] != hashlib.md5(inputs_path.read_bytes()).hexdigest() or integrity["config_md5"] != hashlib.md5(config_path.read_bytes()).hexdigest():
        raise ValueError("Actual engine fit does not match these prepared inputs/configuration")
    event_ids = [row["id"] for row in model["events"]]
    if integrity["event_ids"] != event_ids:
        raise ValueError("Actual engine event indexing differs")
    training = [row for row in model["patients"] if row["role"] == "training"]
    evaluation = [row for row in model["patients"] if row["role"] == "evaluation"]
    null = ordering_null(training, event_ids, config["assessment"]["ordering_null_permutations"], config["engine"]["seed"] + 40000)
    null_lookup = {(row["source"],row["target"]): row for row in null}
    (output / "ordering_null_all_pairs.json").write_text(json.dumps(null, indent=2) + "\n")
    for pair in model["pair_evidence"]:
        pair["ordering_null"] = {"a_to_b": null_lookup[pair["a"],pair["b"]], "b_to_a": null_lookup[pair["b"],pair["a"]]}
    ordered = {(row["source"],row["target"]): row for row in engine["all_ordered_pairs"]}
    edges = []
    for arrow in engine["selected_edges"]:
        a,b = arrow["source"],arrow["target"]
        row = ordered[a,b]
        train_counts, evaluation_counts = counts(training,a,b),counts(evaluation,a,b)
        with_source = [patient for patient in training if any(event["gene"] == a for event in patient["events"])]
        without_source = [patient for patient in training if not any(event["gene"] == a for event in patient["events"])]
        b_with = sum(any(event["gene"] == b for event in patient["events"]) for patient in with_source)
        b_without = sum(any(event["gene"] == b for event in patient["events"]) for patient in without_source)
        probability_with, probability_without = b_with/len(with_source), b_without/len(without_source)
        edges.append({"source": a, "target": b, "selected": True, "relation": "ASCETIC model dependency",
                      "training": train_counts, "evaluation": evaluation_counts,
                      "training_reported_cooccurrence": {"target_with_source": b_with, "source_carriers": len(with_source),
                          "target_without_source": b_without, "source_noncarriers": len(without_source),
                          "P_target_given_source": probability_with, "P_target_given_no_source": probability_without,
                          "difference": probability_with-probability_without,
                          "meaning": "Descriptive reported-driver cooccurrence; a negative difference may encode negative association and is not positive cooperation"},
                      "bootstrap": {"selected_count": row["bootstrap_selected"], "successful_runs": row["bootstrap_successful"], "selection_frequency": row["bootstrap_frequency"]},
                      "null": {"engine_selection_count": row["ordering_null_selected"], "engine_successful_runs": row["ordering_null_successful"],
                               "engine_selection_frequency": row["ordering_null_frequency"], "pair_direction": null_lookup[a,b]},
                      "strict_source_evidence_status": "At least one strict source ancestry vote; not necessarily adjacent clusters" if train_counts["source_ancestor"] else "No direct resolved ancestry evidence",
                      "heldout_direction_status": "No resolved evaluation order" if not evaluation_counts["strict_order_resolved"] else
                          "Evaluation majority compatible" if evaluation_counts["source_ancestor"] > evaluation_counts["reverse_ancestor"] else
                          "Evaluation majority reversed" if evaluation_counts["source_ancestor"] < evaluation_counts["reverse_ancestor"] else "Evaluation resolved directions tied",
                      "status": "Exploratory model-selected dependency; not a confirmed route"})
    arrows = [(row["source"],row["target"]) for row in edges]
    model["edges"] = edges
    model["model_status"] = "genuine_ASCETIC_fitted_exploratory"
    model["method"]["engine"] = engine["engine"]
    model["validation"] = {"patient_bootstrap": engine["patient_bootstrap"], "ordering_null_engine_fits": engine["ordering_null"],
                            "ordering_permutation_tests": {"permutations": config["assessment"]["ordering_null_permutations"], "ordered_pairs": len(null),
                                                           "multiplicity": config["assessment"]["multiplicity"], "null": config["assessment"]["null"],
                                                           "direction_statistic": config["assessment"]["direction_statistic"], "selected_edges_BH_q_below_0_05": sum(edge["null"]["pair_direction"]["BH_q"] < .05 for edge in edges)},
                            "selected_edges_meeting_0_8_stability": sum(edge["bootstrap"]["selection_frequency"] is not None and edge["bootstrap"]["selection_frequency"] >= config["assessment"]["stability_display_threshold"] for edge in edges),
                            "holdout": joint_holdout(model["patients"],event_ids,arrows),
                            "interpretation": "Ordering tests condition on reported co-carrier labels and exchangeability of unique gene placements; bootstrap selection is not chronology probability. Shared source, sampling bias, limited resolved pairs and mapping uncertainty remain."}
    model["audit"] = {"independent_patients": len(model["patients"]), "regions_or_topologies_used_as_patients": False,
                       "all_source_topologies_structurally_validated": True, "all_pair_categories_preserved": True,
                       "same_cluster_order_invented": False, "CCF_or_VAF_as_time_used": False, "source_corrected_topology_used_to_break_ties": False,
                       "heldout_used_for_gene_or_edge_selection": False, "selected_edge_count": len(edges), "full_parent_sets": {gene: sorted(a for a,b in arrows if b == gene) for gene in event_ids}}
    model["provenance"].update({"prepared_evidence_sha256": sha(prepared_path), "actual_engine_output_sha256": sha(engine_path),
                               "ordering_null_all_pairs_sha256": sha(output / "ordering_null_all_pairs.json"), "finalizer_sha256": sha(Path(__file__))})
    # Visual contract independently recomputes every source patient vote.
    sys.path.insert(0,str(HERE.parent / "visualization"))
    from contract import validate_model
    model["audit"]["independent_display_contract"] = validate_model(model)
    (output / "model.json").write_text(json.dumps(model,indent=2,allow_nan=False) + "\n")
    holdout = model["validation"]["holdout"]
    aggregate = {"schema_version": "1.0", "date": "2026-10-18", "purpose": "Aggregate scientific evidence; no patient identifiers or per-patient source data",
                 "model_sha256": sha(output / "model.json"), "configuration_sha256": sha(config_path), "provenance": model["provenance"],
                 "method": model["method"], "cohort": model["cohort"], "candidate_events": model["candidate_events"], "events": model["events"],
                 "pair_evidence": model["pair_evidence"], "selected_edges": model["edges"],
                 "validation": {key: value for key,value in model["validation"].items() if key != "holdout"},
                 "holdout": {key: value for key,value in holdout.items() if key not in {"training_CPTs", "patient_scores"}}, "audit": model["audit"], "limitations": model["limitations"]}
    (HERE / "results_summary.json").write_text(json.dumps(aggregate,indent=2,allow_nan=False) + "\n")
    return model


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=ROOT / "configs/tracerx_routes_v0_1.json")
    parser.add_argument("--output", type=Path, default=HERE / "output")
    parser.add_argument("--rscript", default="C:/Program Files/R/R-4.5.1/bin/Rscript.exe")
    parser.add_argument("--summarize-only", action="store_true")
    args = parser.parse_args()
    if not args.summarize_only:
        subprocess.run([sys.executable,str(HERE / "prepare_inputs.py"),"--config",str(args.config),"--output",str(args.output)],check=True)
        subprocess.run([args.rscript,"--vanilla",str(HERE / "run_ascetic.R"),str(args.output / "engine_inputs.json"),str(args.config),str(args.output),str(HERE / "runtime_lock.json")],check=True)
    model = finalize(args.output,args.config)
    print(f"Completed {len(model['events'])} events, {len(model['pair_evidence'])} unordered evidence pairs, {len(model['edges'])} genuine selected edges")
    for edge in model["edges"]:
        print(edge["source"],"->",edge["target"],"bootstrap",edge["bootstrap"]["selection_frequency"],"train ancestry",edge["training"]["source_ancestor"],"/",edge["training"]["co_carriers"],"BHq",edge["null"]["pair_direction"]["BH_q"])


if __name__ == "__main__":
    main()
