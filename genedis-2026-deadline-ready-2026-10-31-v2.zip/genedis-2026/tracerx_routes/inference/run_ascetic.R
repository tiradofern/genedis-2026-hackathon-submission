args <- commandArgs(trailingOnly=TRUE)
if (length(args) != 4L) stop("Usage: run_ascetic.R INPUT CONFIG OUTPUT RUNTIME_LOCK")
inputPath <- normalizePath(args[1], winslash="/", mustWork=TRUE)
configPath <- normalizePath(args[2], winslash="/", mustWork=TRUE)
output <- args[3]
lockPath <- normalizePath(args[4], winslash="/", mustWork=TRUE)
here <- dirname(lockPath)
root <- dirname(dirname(here))
.libPaths(c(file.path(here, ".rlibrary"), file.path(root,"population_routes/inference/.rlibrary"), .Library))
lock <- jsonlite::fromJSON(lockPath, simplifyVector=FALSE)
baseLock <- jsonlite::fromJSON(file.path(root,"population_routes/inference/runtime_lock.json"),simplifyVector=FALSE)
for (package in baseLock$packages) {
  if (packageVersion(package$name) != package_version(package$version)) stop("Pinned shared package version mismatch: ",package$name)
}
for (package in lock$packages) {
  if (packageVersion(package$name) != package_version(package$version)) stop("Pinned package version mismatch: ", package$name)
}
stopifnot(as.character(packageVersion("ASCETIC")) == lock$engine$version)
input <- jsonlite::fromJSON(inputPath, simplifyVector=FALSE)
config <- jsonlite::fromJSON(configPath, simplifyVector=FALSE)
events <- unlist(input$events, use.names=FALSE)
records <- Filter(function(patient) patient$role == "training", input$patients)
ids <- vapply(records, function(patient) patient$id, "")
if (anyDuplicated(ids)) stop("Repeated patient ID")
dataset <- matrix(0L,nrow=length(records),ncol=length(events),dimnames=list(ids,events))
models <- setNames(vector("list",length(records)),ids)
uniqueGenes <- setNames(vector("list",length(records)),ids)
for (i in seq_along(records)) {
  patient <- records[[i]]
  present <- unlist(patient$present,use.names=FALSE)
  uniqueGenes[[i]] <- unlist(patient$unique,use.names=FALSE)
  if (any(!present %in% events) || anyDuplicated(present)) stop("Invalid named event set")
  dataset[i,present] <- 1L
  model <- matrix(0L,nrow=length(present),ncol=length(present),dimnames=list(present,present))
  for (arrow in patient$arrows) {
    a <- arrow[[1]]; b <- arrow[[2]]
    if (!a %in% present || !b %in% present || a == b) stop("Invalid patient order edge")
    model[a,b] <- 1L
  }
  models[[i]] <- model
}
fitOne <- function(data, temporalModels, seed) {
  if (ncol(data) < 2L || any(colSums(data) == 0L | colSums(data) == nrow(data))) stop("Nonvarying event or fewer than two eligible events")
  if (!any(vapply(temporalModels,function(model) sum(model)>0,FALSE))) stop("No strict resolved ordering: ASCETIC empty-order input is gated")
  set.seed(seed)
  # Genuine unchanged authors' public entrypoint. Unknown order remains zero;
  # named nodes still count in the authors' cooccurrence denominator.
  fitted <- ASCETIC::asceticPhylogenies(dataset=data,models=temporalModels,
           regularization=config$engine$regularization,
           command=config$engine$command,restarts=config$engine$restarts)
  adjacency <- fitted$inference[[config$engine$regularization]]
  stopifnot(all(dim(adjacency) == c(length(events),length(events))))
  # The unchanged public entrypoint explicitly returns sequential numeric IDs
  # corresponding to its input dataset columns. Fail rather than relabel any
  # unexpected order or silently accept a package that sorted event names.
  expectedNames <- as.character(seq_len(ncol(data)))
  if (!identical(colnames(data),events) ||
      !identical(rownames(adjacency),expectedNames) || !identical(colnames(adjacency),expectedNames) ||
      !identical(rownames(fitted$poset),expectedNames) || !identical(colnames(fitted$poset),expectedNames)) stop("ASCETIC returned unexpected event indexing")
  dimnames(adjacency) <- list(events,events)
  dimnames(fitted$poset) <- list(events,events)
  list(fit=fitted,adjacency=adjacency)
}
dir.create(output,recursive=TRUE,showWarnings=FALSE)
baseline <- fitOne(dataset,models,config$engine$seed)
saveRDS(baseline$fit,file.path(output,"official_ascetic_fit.rds"))
capture.output(sessionInfo(),file=file.path(output,"sessionInfo.txt"))
edges <- function(adjacency) {
  where <- which(adjacency == 1L,arr.ind=TRUE)
  if (!nrow(where)) return(list())
  lapply(seq_len(nrow(where)),function(i) list(source=rownames(adjacency)[where[i,1]],target=colnames(adjacency)[where[i,2]]))
}
bootCount <- nullCount <- matrix(0L,length(events),length(events),dimnames=list(events,events))
bootFailures <- nullFailures <- list()
bootSuccessful <- nullSuccessful <- 0L
nullEdgeCounts <- list()
for (iteration in seq_len(config$engine$patient_bootstrap_fits)) {
  set.seed(config$engine$seed + iteration)
  draw <- sample.int(nrow(dataset),replace=TRUE)
  currentData <- dataset[draw,,drop=FALSE]
  rownames(currentData) <- paste0("BOOT_DRAW_",seq_len(nrow(currentData)))
  currentModels <- models[draw]
  names(currentModels) <- rownames(currentData)
  fitted <- tryCatch(fitOne(currentData,currentModels,config$engine$seed+10000L+iteration),error=function(e)e)
  if (inherits(fitted,"error")) {
    bootFailures[[length(bootFailures)+1L]] <- list(iteration=iteration,message=conditionMessage(fitted))
  } else {
    bootSuccessful <- bootSuccessful+1L
    bootCount <- bootCount+fitted$adjacency
  }
  if (iteration %% 10L == 0L) cat("patient bootstrap",iteration,"/",config$engine$patient_bootstrap_fits,"\n")
}
for (iteration in seq_len(config$engine$ordering_null_engine_fits)) {
  set.seed(config$engine$seed+20000L+iteration)
  currentModels <- models
  for (i in seq_along(currentModels)) {
    genes <- uniqueGenes[[i]]
    if (length(genes) > 1L) {
      shuffled <- genes[sample.int(length(genes))]
      replacements <- setNames(shuffled,genes)
      named <- rownames(currentModels[[i]])
      hit <- which(named %in% genes)
      named[hit] <- replacements[named[hit]]
      dimnames(currentModels[[i]]) <- list(named,named)
    }
  }
  fitted <- tryCatch(fitOne(dataset,currentModels,config$engine$seed+30000L+iteration),error=function(e)e)
  if (inherits(fitted,"error")) {
    nullFailures[[length(nullFailures)+1L]] <- list(iteration=iteration,message=conditionMessage(fitted))
  } else {
    nullSuccessful <- nullSuccessful+1L
    nullCount <- nullCount+fitted$adjacency
    nullEdgeCounts[[length(nullEdgeCounts)+1L]] <- sum(fitted$adjacency)
  }
  if (iteration %% 10L == 0L) cat("ordering null",iteration,"/",config$engine$ordering_null_engine_fits,"\n")
}
allPairs <- list()
for (a in events) for (b in events) if (a != b) {
  allPairs[[length(allPairs)+1L]] <- list(source=a,target=b,
      selected=baseline$adjacency[a,b] == 1L,allowed_poset=baseline$fit$poset[a,b] == 1L,
      bootstrap_selected=bootCount[a,b],bootstrap_successful=bootSuccessful,
      bootstrap_frequency=if (bootSuccessful>0L) bootCount[a,b]/bootSuccessful else NULL,
      ordering_null_selected=nullCount[a,b],ordering_null_successful=nullSuccessful,
      ordering_null_frequency=if(nullSuccessful>0L) nullCount[a,b]/nullSuccessful else NULL)
}
result <- list(input_integrity=list(input_md5=unname(tools::md5sum(inputPath)),config_md5=unname(tools::md5sum(configPath)),event_ids=events),
         engine=list(name="ASCETIC",version=as.character(packageVersion("ASCETIC")),
         entrypoint="ASCETIC::asceticPhylogenies",upstream_commit=lock$engine$upstream_commit,
         regularization=config$engine$regularization,command=config$engine$command,restarts=config$engine$restarts,
         R_version=R.version.string,source_unchanged=TRUE),
         selected_edges=edges(baseline$adjacency),all_ordered_pairs=allPairs,
         patient_bootstrap=list(requested=config$engine$patient_bootstrap_fits,successful=bootSuccessful,failures=bootFailures),
         ordering_null=list(requested=config$engine$ordering_null_engine_fits,successful=nullSuccessful,failures=nullFailures,
                            selected_edge_counts=unlist(nullEdgeCounts)))
jsonlite::write_json(result,file.path(output,"engine_output.json"),pretty=TRUE,auto_unbox=TRUE,null="null",digits=16)
cat("Genuine ASCETIC completed; selected edges",sum(baseline$adjacency),"\n")
