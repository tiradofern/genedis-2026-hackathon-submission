"""Patient-level source-phylogeny evidence; no chronology is invented here."""
from __future__ import annotations

from collections import Counter
import hashlib
from itertools import combinations
import math
import random

STATES = ("a_ancestor_b", "b_ancestor_a", "same_cluster", "incomparable", "topology_ambiguous", "repeated_gene_ambiguous", "mapping_ambiguous")
FIELDS = ("source_ancestor", "reverse_ancestor", "same_cluster", "incomparable", "topology_ambiguous", "repeated_gene_ambiguous", "mapping_ambiguous")
STATE_FIELD = dict(zip(STATES, FIELDS))
REVERSE = {"a_ancestor_b": "b_ancestor_a", "b_ancestor_a": "a_ancestor_b"}


def split_patients(ids: list[str], config: dict) -> dict[str, str]:
    if len(ids) != len(set(ids)):
        raise ValueError("Repeated patient ID; patient independence not established")
    spec = config["split"]
    order = sorted(ids, key=lambda key: (hashlib.sha256((spec["salt"] + key).encode()).hexdigest(), key))
    n = spec["training_participants"]
    if len(ids) != n + spec["evaluation_participants"]:
        raise ValueError("Audited patient count differs from frozen split")
    return {key: "training" if i < n else "evaluation" for i, key in enumerate(order)}


def relation(patient: dict, a: str, b: str) -> str | None:
    for row in patient["relations"]:
        if row["a"] == a and row["b"] == b:
            return row["state"]
        if row["a"] == b and row["b"] == a:
            return REVERSE.get(row["state"], row["state"])
    return None


def counts(patients: list[dict], a: str, b: str) -> dict:
    observed = Counter(relation(patient, a, b) for patient in patients)
    result = {field: observed[state] for state, field in STATE_FIELD.items()}
    result["co_carriers"] = sum(result.values())
    result["strict_order_resolved"] = result["source_ancestor"] + result["reverse_ancestor"]
    result["resolved_fraction"] = result["strict_order_resolved"] / result["co_carriers"] if result["co_carriers"] else None
    result["direction_agreement"] = result["source_ancestor"] / result["strict_order_resolved"] if result["strict_order_resolved"] else None
    result["direction_agreement_wilson_95"] = wilson(result["source_ancestor"], result["strict_order_resolved"])
    return result


def wilson(successes: int, total: int) -> list[float] | None:
    if not total:
        return None
    z = 1.959963984540054
    proportion = successes / total
    denominator = 1 + z*z/total
    center = (proportion + z*z/(2*total)) / denominator
    radius = z * math.sqrt(proportion*(1-proportion)/total + z*z/(4*total*total)) / denominator
    return [max(0.0, center-radius), min(1.0, center+radius)]


def bh(values: list[float]) -> list[float]:
    n = len(values)
    order = sorted(range(n), key=values.__getitem__)
    result = [1.0]*n
    previous = 1.0
    for rank in range(n, 0, -1):
        index = order[rank-1]
        previous = min(previous, values[index]*n/rank)
        result[index] = min(1.0, previous)
    return result


def consensus_gene_relations(source: dict, event_ids: list[str]) -> dict:
    """Lift exact source variant/cluster mappings without choosing a first hit.

    Source `drivers` must contain EVERY authors-curated reported driver, including
    failed/removed mappings. A gene is unique only if every such call maps and
    all calls share a retained node. The source parser supplies the consensus
    relation among all retained cluster pairs after validating every alternative.
    """
    drivers: dict[str, list[dict]] = {}
    for row in source["drivers"]:
        if row.get("source_driver") is not True:
            raise ValueError("Noncurated mutation in driver input")
        if row["gene"] in event_ids:
            drivers.setdefault(row["gene"], []).append(row)
    event_rows = []
    for gene, rows in sorted(drivers.items()):
        good = [row for row in rows if row["mapping_status"] == "mapped_retained"]
        # Preserve a reported cluster label even when its exact variant join is
        # unresolved. Its mapping status prevents it from casting an order vote.
        clusters = sorted({str(row["cluster_id"]) for row in rows if row["cluster_id"] is not None})
        if len(good) != len(rows):
            status = "mapping_ambiguous"
        elif len(clusters) != 1:
            status = "repeated_gene_ambiguous"
        else:
            status = "unique_cluster"
        event_rows.append({"gene": gene, "cluster_ids": clusters, "mapping_status": status,
                           "driver_variant_count": len(rows), "variant_ids": [row["variant_id"] for row in rows]})
    by_gene = {row["gene"]: row for row in event_rows}
    cluster_relations = {}
    for row in source["consensus_relations"]:
        a, b = str(row["a_cluster"]), str(row["b_cluster"])
        if (a, b) in cluster_relations or (b, a) in cluster_relations:
            raise ValueError("Repeated source cluster pair")
        if row["state"] not in STATES[:5]:
            raise ValueError("Invalid source consensus state")
        cluster_relations[a, b] = row["state"]
    relations = []
    for a, b in combinations(sorted(by_gene), 2):
        aa, bb = by_gene[a], by_gene[b]
        if "mapping_ambiguous" in {aa["mapping_status"], bb["mapping_status"]}:
            state = "mapping_ambiguous"
        elif "repeated_gene_ambiguous" in {aa["mapping_status"], bb["mapping_status"]}:
            state = "repeated_gene_ambiguous"
        else:
            ca, cb = aa["cluster_ids"][0], bb["cluster_ids"][0]
            if ca == cb:
                state = "same_cluster"
            elif (ca, cb) in cluster_relations:
                state = cluster_relations[ca, cb]
            elif (cb, ca) in cluster_relations:
                state = REVERSE.get(cluster_relations[cb, ca], cluster_relations[cb, ca])
            else:
                raise ValueError(f"Missing validated consensus relation for {ca}/{cb}")
        relations.append({"a": a, "b": b, "state": state})
    return {"events": event_rows, "relations": relations}


def permuted_patient(patient: dict, rng: random.Random) -> dict:
    """Shuffle labels only among uniquely mapped selected genes within a patient."""
    unique = [row["gene"] for row in patient["events"] if row["mapping_status"] == "unique_cluster"]
    shuffled = list(unique)
    rng.shuffle(shuffled)
    renamed = dict(zip(unique, shuffled))
    rows = []
    for row in patient["relations"]:
        rows.append({"a": renamed.get(row["a"], row["a"]), "b": renamed.get(row["b"], row["b"]), "state": row["state"]})
    return {**patient, "relations": rows}


def ordering_null(patients: list[dict], event_ids: list[str], permutations: int, seed: int) -> list[dict]:
    """Monte Carlo label-null tests for every ordered pair, including unselected."""
    pairs = list(combinations(event_ids, 2))
    lookup = {gene: index for index, gene in enumerate(event_ids)}
    offsets = {(lookup[a], lookup[b]): i for i, (a, b) in enumerate(pairs)}
    observed = []
    for a, b in pairs:
        value = counts(patients, a, b)
        observed.append(value["source_ancestor"]-value["reverse_ancestor"])
    exceed_forward, exceed_reverse = [0]*len(pairs), [0]*len(pairs)
    # Cache the strict relations only: unknown and same-cluster pairs score zero.
    structures = []
    for patient in patients:
        unique = [lookup[row["gene"]] for row in patient["events"] if row["mapping_status"] == "unique_cluster"]
        arrows = []
        for row in patient["relations"]:
            if row["state"] == "a_ancestor_b":
                arrows.append((lookup[row["a"]], lookup[row["b"]]))
            elif row["state"] == "b_ancestor_a":
                arrows.append((lookup[row["b"]], lookup[row["a"]]))
        structures.append((unique, arrows))
    rng = random.Random(seed)
    for _ in range(permutations):
        statistics = [0]*len(pairs)
        for unique, arrows in structures:
            if not arrows:
                continue
            shuffled = list(unique)
            rng.shuffle(shuffled)
            renamed = dict(zip(unique, shuffled))
            for a, b in arrows:
                na, nb = renamed[a], renamed[b]
                if na < nb:
                    statistics[offsets[na, nb]] += 1
                else:
                    statistics[offsets[nb, na]] -= 1
        for i, value in enumerate(statistics):
            exceed_forward[i] += value >= observed[i]
            exceed_reverse[i] += -value >= -observed[i]
    rows = []
    for i, (a, b) in enumerate(pairs):
        rows.append({"source": a, "target": b, "statistic": observed[i], "exceedances": exceed_forward[i], "permutations": permutations, "p": (1+exceed_forward[i])/(1+permutations)})
        rows.append({"source": b, "target": a, "statistic": -observed[i], "exceedances": exceed_reverse[i], "permutations": permutations, "p": (1+exceed_reverse[i])/(1+permutations)})
    adjusted = bh([row["p"] for row in rows])
    for row, q in zip(rows, adjusted):
        row["BH_q"] = q
    return rows


def joint_holdout(patients: list[dict], event_ids: list[str], arrows: list[tuple[str, str]]) -> dict:
    """Training-only Beta(1,1) CPTs, joint held-out score, marginal comparator."""
    training = [row for row in patients if row["role"] == "training"]
    evaluation = [row for row in patients if row["role"] == "evaluation"]
    bits = {row["id"]: {event["gene"] for event in row["events"]} for row in patients}
    parents = {gene: sorted(a for a, b in arrows if b == gene) for gene in event_ids}
    parameters = {}
    marginals = {}
    for gene in event_ids:
        pa = parents[gene]
        buckets = {}
        for patient in training:
            present = bits[patient["id"]]
            key = "".join("1" if parent in present else "0" for parent in pa)
            seen, positive = buckets.get(key, (0, 0))
            buckets[key] = seen+1, positive+int(gene in present)
        parameters[gene] = {key: {"training_n": n, "training_positive": k, "p": (k+1)/(n+2)} for key, (n, k) in buckets.items()}
        marginals[gene] = (sum(gene in bits[p["id"]] for p in training)+1)/(len(training)+2)
    scores = []
    for patient in evaluation:
        present = bits[patient["id"]]
        joint = marginal = 0.0
        for gene in event_ids:
            key = "".join("1" if parent in present else "0" for parent in parents[gene])
            probability = parameters[gene].get(key, {"p": .5})["p"]
            baseline = marginals[gene]
            joint += math.log(probability if gene in present else 1-probability)
            marginal += math.log(baseline if gene in present else 1-baseline)
        scores.append({"patient_id": patient["id"], "joint_log_score": joint, "marginal_log_score": marginal, "difference": joint-marginal})
    total = sum(row["difference"] for row in scores)
    return {"training_n": len(training), "evaluation_n": len(evaluation), "joint_log_score": sum(row["joint_log_score"] for row in scores),
            "marginal_log_score": sum(row["marginal_log_score"] for row in scores), "difference": total,
            "difference_per_evaluation_patient": total/len(evaluation) if evaluation else None,
            "training_CPTs": parameters, "parents": parents, "smoothing": "Beta(1,1); unobserved parent configurations p=0.5",
            "meaning": "Held-out reported-driver cooccurrence prediction, not a test of temporal truth or clinical prediction", "patient_scores": scores}
