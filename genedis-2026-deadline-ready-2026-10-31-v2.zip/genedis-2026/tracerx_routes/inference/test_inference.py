"""Meaningful contracts for source ordering, patient independence and assessment."""
from __future__ import annotations

from collections import Counter
import copy
import hashlib
from itertools import combinations
import json
from pathlib import Path
import random
import tarfile
import unittest

from evidence import bh, consensus_gene_relations, counts, joint_holdout, ordering_null, permuted_patient, relation, split_patients, wilson
from prepare_inputs import HERE, ROOT, validate_source


def driver(gene, cluster, variant, status="mapped_retained"):
    return {"gene":gene,"cluster_id":cluster,"variant_id":variant,"mapping_status":status,"source_driver":True}


class SourceOrderTests(unittest.TestCase):
    def source(self):
        return {"drivers":[driver("A","1","v1"),driver("B","2","v2"),driver("C","3","v3")],
                "consensus_relations":[{"a_cluster":"1","b_cluster":"2","state":"a_ancestor_b"},
                                       {"a_cluster":"1","b_cluster":"3","state":"topology_ambiguous"},
                                       {"a_cluster":"2","b_cluster":"3","state":"incomparable"}]}

    def test_no_order_is_invented_for_same_cluster(self):
        source=self.source();source["drivers"][1]["cluster_id"]="1"
        result=consensus_gene_relations(source,["A","B","C"])
        self.assertEqual(relation(result,"A","B"),"same_cluster")

    def test_alternative_disagreement_and_separate_branches_preserved(self):
        result=consensus_gene_relations(self.source(),["A","B","C"])
        self.assertEqual(relation(result,"A","C"),"topology_ambiguous")
        self.assertEqual(relation(result,"B","C"),"incomparable")
        self.assertEqual(relation(result,"B","A"),"b_ancestor_a")

    def test_same_gene_same_cluster_multivariant_allowed_but_repeated_clusters_not(self):
        source=self.source();source["drivers"].append(driver("A","1","v4"))
        self.assertEqual(relation(consensus_gene_relations(source,["A","B"]),"A","B"),"a_ancestor_b")
        source["drivers"].append(driver("A","3","v5"))
        self.assertEqual(relation(consensus_gene_relations(source,["A","B"]),"A","B"),"repeated_gene_ambiguous")

    def test_failed_variant_join_keeps_presence_and_does_not_use_reported_cluster(self):
        source=self.source();source["drivers"][0]["mapping_status"]="variant_not_in_embedded_mapping"
        result=consensus_gene_relations(source,["A","B"])
        self.assertEqual({row["gene"] for row in result["events"]},{"A","B"})
        self.assertEqual(relation(result,"A","B"),"mapping_ambiguous")

    def test_removed_mapping_has_priority_over_apparent_repeated_hit(self):
        source=self.source();source["drivers"].append(driver("A",None,"v5","source_cluster_removed_from_corrected_tree"))
        self.assertEqual(relation(consensus_gene_relations(source,["A","B"]),"A","B"),"mapping_ambiguous")

    def test_missing_source_consensus_fails_closed(self):
        source=self.source();source["consensus_relations"]=source["consensus_relations"][:1]
        with self.assertRaisesRegex(ValueError,"Missing validated consensus"):
            consensus_gene_relations(source,["A","B","C"])

    def test_patient_split_independent_of_input_order_and_rejects_duplicates(self):
        config={"split":{"salt":"test|","training_participants":2,"evaluation_participants":1}}
        self.assertEqual(split_patients(["p1","p2","p3"],config),split_patients(["p3","p1","p2"],config))
        with self.assertRaises(ValueError): split_patients(["p1","p1","p3"],config)


class AssessmentTests(unittest.TestCase):
    def patient(self):
        return {"id":"fictional","role":"training","events":[{"gene":"A","mapping_status":"unique_cluster"},
                {"gene":"B","mapping_status":"unique_cluster"},{"gene":"C","mapping_status":"mapping_ambiguous"}],
                "relations":[{"a":"A","b":"B","state":"a_ancestor_b"},{"a":"A","b":"C","state":"mapping_ambiguous"},
                             {"a":"B","b":"C","state":"mapping_ambiguous"}]}

    def test_null_retains_carrier_set_and_fixed_ambiguous_gene(self):
        patient=self.patient()
        for seed in range(10):
            shuffled=permuted_patient(patient,random.Random(seed))
            self.assertEqual({e["gene"] for e in shuffled["events"]},{"A","B","C"})
            self.assertEqual(relation(shuffled,"A","C"),"mapping_ambiguous")
            self.assertEqual(relation(shuffled,"B","C"),"mapping_ambiguous")
            self.assertIn(relation(shuffled,"A","B"),{"a_ancestor_b","b_ancestor_a"})

    def test_each_patient_contributes_one_category_with_full_denominator(self):
        patients=[]
        for state in ["a_ancestor_b","b_ancestor_a","same_cluster","incomparable","topology_ambiguous","repeated_gene_ambiguous","mapping_ambiguous"]:
            patients.append({"relations":[{"a":"A","b":"B","state":state}]})
        result=counts(patients,"A","B")
        self.assertEqual(result["co_carriers"],7)
        self.assertEqual(result["strict_order_resolved"],2)
        self.assertEqual(result["resolved_fraction"],2/7)

    def test_direction_null_reproducible_and_tests_all_ordered_pairs(self):
        p=self.patient();rows=ordering_null([p],["A","B","C"],99,123)
        self.assertEqual(rows,ordering_null([p],["A","B","C"],99,123))
        self.assertEqual(len(rows),6)
        self.assertTrue(all(0 < row["p"] <= row["BH_q"] <= 1 for row in rows))
        self.assertTrue(all(row["p"] == 1 for row in rows if "C" in {row["source"],row["target"]}))

    def test_bh_known_values_and_zero_resolved_interval(self):
        self.assertEqual(bh([.01,.04,.03]),[.03,.04,.04])
        self.assertIsNone(wilson(0,0))
        low,high=wilson(1,1)
        self.assertLess(low,.21);self.assertEqual(high,1)

    def test_holdout_values_do_not_change_training_CPTs(self):
        patients=[]
        for ident,role,genes in [("t1","training",["A","B"]),("t2","training",[]),("e1","evaluation",["B"])]:
            patients.append({"id":ident,"role":role,"events":[{"gene":g} for g in genes]})
        first=joint_holdout(patients,["A","B"],[("A","B")])
        altered=copy.deepcopy(patients);altered[-1]["events"]=[{"gene":"A"}]
        second=joint_holdout(altered,["A","B"],[("A","B")])
        self.assertEqual(first["training_CPTs"],second["training_CPTs"])
        self.assertEqual(first["evaluation_n"],1)
        self.assertEqual(first["parents"]["B"],["A"])


class ActualPublishedDataTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        source_path=HERE.parent/"source/output/cohort_trees.json"
        model_path=HERE/"output/model.json"
        if not source_path.exists() or not model_path.exists():
            raise unittest.SkipTest("Published downloads and completed actual model not present")
        cls.source=json.loads(source_path.read_text());cls.model=json.loads(model_path.read_text())

    def test_actual_patient_votes_agree_with_separately_exported_ancestry_closures(self):
        source_by_id={p["patient_id"]:p for p in self.source["patients"]}
        self.assertEqual(len(self.model["patients"]),217)
        self.assertEqual(Counter(p["role"] for p in self.model["patients"]),{"training":152,"evaluation":65})
        for patient in self.model["patients"]:
            source=source_by_id[patient["id"]]
            event_by_gene={e["gene"]:e for e in source["events"]}
            strict={tuple(pair) for pair in source["strict_ancestor_pairs"]}
            possible={tuple(pair) for pair in source["possible_ancestor_pairs"]}
            present={e["gene"] for e in patient["events"]}
            self.assertEqual(len(patient["relations"]),len(present)*(len(present)-1)//2)
            for row in patient["relations"]:
                a,b=event_by_gene[row["a"]],event_by_gene[row["b"]]
                if "unresolved_driver_mapping" in {a["mapping_status"],b["mapping_status"]}: expected="mapping_ambiguous"
                elif "repeated_hit_different_clusters" in {a["mapping_status"],b["mapping_status"]}: expected="repeated_gene_ambiguous"
                else:
                    ca,cb=a["cluster_ids"][0],b["cluster_ids"][0]
                    if ca == cb: expected="same_cluster"
                    elif (ca,cb) in strict: expected="a_ancestor_b"
                    elif (cb,ca) in strict: expected="b_ancestor_a"
                    elif (ca,cb) in possible or (cb,ca) in possible: expected="topology_ambiguous"
                    else: expected="incomparable"
                self.assertEqual(row["state"],expected,(patient["id"],row))

    def test_actual_engine_and_holdout_integrity(self):
        engine=json.loads((HERE/"output/engine_output.json").read_text())
        self.assertEqual(engine["engine"]["version"],"1.2.0")
        self.assertTrue(engine["engine"]["source_unchanged"])
        self.assertEqual(engine["patient_bootstrap"]["successful"],100)
        self.assertEqual(engine["ordering_null"]["successful"],100)
        self.assertEqual(engine["input_integrity"]["event_ids"],[e["id"] for e in self.model["events"]])
        self.assertEqual(self.model["validation"]["ordering_permutation_tests"]["ordered_pairs"],132)
        self.assertEqual(self.model["validation"]["holdout"]["evaluation_n"],65)
        self.assertEqual(len(self.model["edges"]),len(engine["selected_edges"]))

    def test_locked_archive_and_windows_checkout_are_line_ending_equivalent(self):
        lock=json.loads((HERE/"runtime_lock.json").read_text())
        archive=HERE/".downloads"/lock["source"]["filename"]
        if not archive.exists(): self.skipTest("Source archive not cached")
        self.assertEqual(hashlib.sha256(archive.read_bytes()).hexdigest(),lock["source"]["sha256"])
        with tarfile.open(archive) as tar:
            for relative,digest in lock["source_files_sha256"].items():
                raw=tar.extractfile("ASCETIC-"+lock["engine"]["upstream_commit"]+"/"+relative).read()
                windows=raw.replace(b"\r\n",b"\n").replace(b"\n",b"\r\n")
                self.assertIn(digest,{hashlib.sha256(raw).hexdigest(),hashlib.sha256(windows).hexdigest()})


if __name__ == "__main__":
    unittest.main()
