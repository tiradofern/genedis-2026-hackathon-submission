"""Build the unchanged pinned ASCETIC source with workspace-only official tools.

The original CAPRI library supplies already locked shared dependencies. New
archives and the official portable GCC toolchain are hash checked. No system
installation or R user-library mutation is performed.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import urllib.request
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = ROOT / "population_routes/inference"
RSCRIPT = Path("C:/Program Files/R/R-4.5.1/bin/Rscript.exe")
RCMD = RSCRIPT.parent / "x64/Rcmd.exe"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def download(item: dict, offline: bool = False) -> Path:
    target = HERE / ".downloads" / item["filename"]
    target.parent.mkdir(exist_ok=True)
    if not target.exists():
        if offline:
            raise FileNotFoundError(target)
        partial = target.with_suffix(target.suffix + ".partial")
        with urllib.request.urlopen(item["url"], timeout=120) as source, partial.open("wb") as output:
            shutil.copyfileobj(source, output)
        if sha(partial) != item["sha256"] or partial.stat().st_size != item["bytes"]:
            raise ValueError(f"Archive checksum mismatch: {partial}")
        partial.replace(target)
    if sha(target) != item["sha256"] or target.stat().st_size != item["bytes"]:
        raise ValueError(f"Archive checksum mismatch: {target}")
    return target


def r_literal(path: Path) -> str:
    return json.dumps(path.as_posix())


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()
    lock = json.loads((HERE / "runtime_lock.json").read_text())
    if sha(BASE / "runtime_lock.json") != lock["base_runtime_lock_sha256"]:
        raise ValueError("Shared CAPRI dependency lock changed")
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        archives = list(executor.map(lambda x: download(x, args.offline), lock["packages"]))
    library = HERE / ".rlibrary"
    library.mkdir(exist_ok=True)
    vector = "c(" + ",".join(r_literal(p) for p in archives) + ")"
    subprocess.run([str(RSCRIPT), "--vanilla", "-e", f"install.packages({vector},repos=NULL,type='win.binary',lib={r_literal(library)})"], check=True)

    toolchain = HERE / ".toolchain"
    compiler = toolchain / "x86_64-w64-mingw32.static.posix/bin/g++.exe"
    if not compiler.exists():
        archive = download(lock["toolchain"], args.offline)
        toolchain.mkdir(exist_ok=True)
        # Native tar understands zstd. Windows link entries need ordinary host
        # permissions; all destinations remain inside this workspace directory.
        # Terminal/font documentation contains case-colliding Unix aliases;
        # those are unrelated to GCC and cannot be represented on Windows.
        subprocess.run(["tar", "-xf", str(archive), "-C", str(toolchain),
                        "--exclude", "*/share/*", "--exclude", "*/etc/*"], check=True)
    source = HERE / ".upstream/ASCETIC"
    if not source.exists():
        archive = download(lock["source"], args.offline)
        staging = HERE / ".upstream"
        staging.mkdir(exist_ok=True)
        with tarfile.open(archive) as tar:
            tar.extractall(staging, filter="data")
        extracted = staging / ("ASCETIC-" + lock["engine"]["upstream_commit"])
        extracted.rename(source)
    current = subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip() if (source / ".git").exists() else lock["engine"]["upstream_commit"]
    if current != lock["engine"]["upstream_commit"]:
        raise ValueError("Unexpected ASCETIC source revision")
    for relative, digest in lock["source_files_sha256"].items():
        raw = (source / relative).read_bytes()
        # The inspected Git checkout used Git's ordinary Windows CRLF
        # conversion; the hash-locked GitHub archive contains LF. Accept only
        # that exact line-ending equivalence, never another source alteration.
        windows_lines = raw.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
        if hashlib.sha256(raw).hexdigest() != digest and hashlib.sha256(windows_lines).hexdigest() != digest:
            raise ValueError(f"Official source changed: {relative}")

    # The package has no custom Makevars/configure logic. Compile every original
    # .cpp, including the original Rcpp registration, using the R45 UCRT GCC.
    # Static C++/GCC runtime linking matches the Rtools Windows convention.
    dll = source / "src/ASCETIC.dll"
    command = [str(compiler), "-shared", "-O2", "-std=gnu++17", "-DNDEBUG",
               "-DSTRICT_R_HEADERS", "-DWIN32", "-D_WIN64", "-D__USE_MINGW_ANSI_STDIO=1",
               "-I" + str(RSCRIPT.parent.parent / "include"),
               "-I" + str(library / "Rcpp/include"),
               *[str(p) for p in sorted((source / "src").glob("*.cpp"))],
               "-L" + str(RSCRIPT.parent / "x64"), "-lR", "-static-libgcc", "-static-libstdc++", "-o", str(dll)]
    env = os.environ.copy()
    env["PATH"] = str(compiler.parent) + os.pathsep + env.get("PATH", "")
    subprocess.run(command, env=env, check=True)
    # Standard R installation builds the unmodified R code/data/documentation;
    # only its normal make-based library compile is replaced by the above GCC
    # command. The same compiled original DLL is then placed in libs/x64.
    env["R_LIBS"] = os.pathsep.join([str(library), str(BASE / ".rlibrary")])
    subprocess.run([str(RCMD), "INSTALL", "--no-libs", "--no-test-load", "--library=" + str(library), str(source)], env=env, check=True)
    dll_dir = library / "ASCETIC/libs/x64"
    dll_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(dll, dll_dir / "ASCETIC.dll")
    subprocess.run([str(RSCRIPT), "--vanilla", "-e", "library(ASCETIC); stopifnot(as.character(packageVersion('ASCETIC')) == '1.2.0'); cat('Genuine ASCETIC load PASS\\n')"], env=env, check=True)
    build = {"source_commit": current, "compiler_command": command, "dll_sha256": sha(dll), "compiler": subprocess.check_output([str(compiler), "--version"], text=True).splitlines()[0]}
    (HERE / ".upstream/build_record.json").write_text(json.dumps(build, indent=2) + "\n")


if __name__ == "__main__":
    main()
