"""Verify public TRACERx objects and export independent-patient partial orders.

No tree, driver annotation, event-frequency gate, or population model is fitted.
Every alternative is checked; ambiguous, repeated, removed and unplaced events
retain presence without an invented order. Patient-level output stays ignored.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import itertools
import json
import math
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "tracerx_routes" / "source"
OUTPUT = SOURCE / "output"


def digest(path: Path, algorithm="sha256") -> str:
    return hashlib.new(algorithm, path.read_bytes()).hexdigest()


def checked_sources() -> list[dict]:
    entries = json.loads((ROOT / "nextstrain/source/source_manifest.json").read_text(encoding="utf-8-sig"))
    for entry in entries:
        path = ROOT / "nextstrain/source/raw" / entry["filename"]
        assert path.stat().st_size == entry["bytes"], entry["filename"]
        assert digest(path) == entry["sha256"], entry["filename"]
        assert digest(path, "md5") == entry["md5"], entry["filename"]
    manifest = json.loads((SOURCE / "source_manifest.json").read_text(encoding="utf-8-sig"))
    entry = manifest["mutation_file"]
    path = SOURCE / "raw" / entry["filename"]
    assert path.stat().st_size == entry["bytes"]
    assert digest(path) == entry["sha256"]
    assert digest(path, "md5") == entry["md5"]
    return entries + [entry]


def numeric_cluster(value) -> str | None:
    if value is None:
        return None
    value = str(value)
    try:
        numeric = float(value)
        if not math.isfinite(numeric) or not numeric.is_integer():
            raise ValueError("Non-integral source cluster")
        return str(int(numeric))
    except (TypeError, ValueError):
        raise ValueError("Unsupported source cluster identifier: " + value)


def sorted_nodes(values):
    return sorted(values, key=lambda value: (int(value), value))


def closure(edges, expected_nodes: set[str], root: str) -> set[tuple[str, str]]:
    """Validate a complete rooted tree, then return its strict ancestor closure."""
    edges = [tuple(map(str, edge)) for edge in edges]
    if any(len(edge) != 2 for edge in edges) or len(set(edges)) != len(edges):
        raise ValueError("Malformed or duplicate source edge")
    parent = {child: ancestor for ancestor, child in edges}
    if len(parent) != len(edges) or root in parent:
        raise ValueError("Invalid source root or multiple parents")
    actual_nodes = {node for edge in edges for node in edge} or {root}
    if actual_nodes != expected_nodes or len(edges) != len(expected_nodes) - 1:
        raise ValueError("Alternative lacks complete retained-node coverage")
    if expected_nodes - set(parent) != {root}:
        raise ValueError("Source tree is disconnected")
    result = set()
    for node in expected_nodes:
        ancestor, seen = node, {node}
        while ancestor in parent:
            ancestor = parent[ancestor]
            if ancestor in seen:
                raise ValueError("Cycle in source topology")
            seen.add(ancestor)
            result.add((ancestor, node))
        if ancestor != root:
            raise ValueError("Source tree does not terminate at source trunk")
    return result


def classify_pair(a, b, strict, possible):
    if a == b:
        return "same_cluster"
    if (a, b) in strict:
        return "a_ancestor_b"
    if (b, a) in strict:
        return "b_ancestor_a"
    if (a, b) not in possible and (b, a) not in possible:
        return "incomparable"
    return "topology_ambiguous"


def audit_tree(raw):
    if len(raw["trunk"]) != 1:
        raise ValueError("Source trunk is missing or nonunique")
    root = str(raw["trunk"][0])
    corrected_edges = [tuple(edge) for edge in raw["corrected_edges"]]
    # Exact published single-cluster sentinel, never a general self-loop repair.
    singleton = (root == "1" and corrected_edges == [("1", "1")]
                 and set(raw["branch_snv_counts"]) == {"1"}
                 and raw["alternative_trees"] and all(value == [["1", "1"]] for value in raw["alternative_trees"])
                 and raw["consensus_branches"] == ["1:1"] and raw["consensus_relationships"] == ["1:1"])
    if singleton:
        return {"root": "1", "nodes": {"1"}, "edges": [], "strict": set(), "possible": set(),
                "edge_counts": Counter(), "n_topologies": len(raw["alternative_trees"]), "distinct_topologies": 1,
                "source_consensus_verified": True, "source_encoding": "exact single-cluster 1:1 sentinel; zero intercluster edges"}
    nodes = {i for edge in corrected_edges for i in edge} or {root}
    closure(corrected_edges, nodes, root)
    alternatives = raw["alternative_trees"]
    if not alternatives:
        raise ValueError("No deposited alternative topology; no corrected-tree fallback")
    strict, possible, edge_counts, alternative_keys = None, set(), Counter(), set()
    for alternative in alternatives:
        relations = closure(alternative, nodes, root)
        strict = relations if strict is None else strict & relations
        possible |= relations
        edges = {tuple(edge) for edge in alternative}
        edge_counts.update(edges)
        alternative_keys.add(tuple(sorted(edges)))
    strict = strict or set()
    source_consensus = {tuple(str(item).split(":")) for item in raw["consensus_relationships"]}
    if strict != source_consensus:
        raise ValueError("Computed all-alternative strict closure disagrees with deposited consensus_relationships")
    source_edges = {tuple(str(item).split(":")) for item in raw["consensus_branches"]}
    common_edges = {edge for edge, count in edge_counts.items() if count == len(alternatives)}
    if common_edges != source_edges:
        raise ValueError("Computed all-alternative edge intersection disagrees with deposited consensus_branches")
    if tuple(sorted(set(corrected_edges))) not in alternative_keys:
        raise ValueError("Corrected representative is absent from deposited alternatives")
    counts = raw["branch_snv_counts"]
    if not nodes <= set(counts) or any(not isinstance(counts[i], int) or counts[i] < 0 for i in nodes):
        raise ValueError("Retained source cluster lacks an integral SNV count")
    if raw["embedded_mapping_duplicate_keys"] != 0:
        raise ValueError("Duplicated embedded mutation keys")
    return {"root": root, "nodes": nodes, "edges": corrected_edges, "strict": strict,
            "possible": possible, "edge_counts": edge_counts, "n_topologies": len(alternatives),
            "distinct_topologies": len(alternative_keys), "source_consensus_verified": True, "source_encoding": "ordinary rooted cluster tree"}


def map_drivers(raw, tree, gene_symbol_aliases=None):
    drivers = []
    for row in raw["drivers"]:
        if row["DriverMut"] is not True:
            raise ValueError("Non-driver row entered curated driver export")
        embedded = numeric_cluster(row["embedded_cluster"])
        corrected = numeric_cluster(row["PyCloneCluster_SC_TB_corrected"])
        key = ":".join((row["tumour_id"], re.sub(r"^chr", "", row["chr"]), row["start"], row["ref"], row["var"]))
        if key != row["full_variant_key"]:
            raise ValueError("Source full variant key transformation changed")
        if row["embedded_key_matches"] == 0:
            status = "variant_not_in_embedded_mapping"
        elif row["embedded_key_matches"] != 1:
            status = "nonunique_embedded_key"
        elif embedded is not None and embedded not in tree["nodes"] and embedded in {str(c) for c in raw["tree_removed_clusters"] + raw["cpn_removed_clusters"]}:
            status = "source_cluster_removed_from_corrected_tree"
        elif embedded is None or corrected is None:
            status = "missing_source_cluster"
        elif embedded != corrected:
            status = "embedded_corrected_cluster_disagreement"
        elif corrected not in tree["nodes"]:
            status = "source_cluster_removed_from_corrected_tree"
        else:
            status = "mapped_retained"
        gene = (gene_symbol_aliases or {}).get(row["Hugo_Symbol"], row["Hugo_Symbol"])
        drivers.append({"gene": gene, "variant_id": key, "source_mutation_id": row["mutation_id"],
                        "cluster_id": corrected, "embedded_cluster_id": embedded,
                        "mapping_status": status, "source_driver": True, "source_driver_status": "DriverMut TRUE",
                        "source_clean_cluster": row["cleanCluster_SC"], "source_clonality": row["PyCloneClonal_SC_TB_corrected"],
                        "source_combined_timing": row["combTiming_SC"], "protein_change": row["AAChange"],
                        "source_consequence": row["exonic.func"], "source_function": row["func"]})
        if gene_symbol_aliases is not None:
            drivers[-1]["raw_source_gene"] = row["Hugo_Symbol"]
    return drivers


def gene_events(drivers):
    grouped = defaultdict(list)
    for driver in drivers:
        grouped[driver["gene"]].append(driver)
    output = []
    for gene, rows in sorted(grouped.items()):
        clusters = sorted_nodes({row["cluster_id"] for row in rows if row["cluster_id"] is not None})
        if any(row["mapping_status"] != "mapped_retained" for row in rows):
            status = "unresolved_driver_mapping"
        elif len(clusters) != 1:
            status = "repeated_hit_different_clusters"
        else:
            status = "unique_source_cluster"
        output.append({"gene": gene, "present": True, "cluster_ids": clusters, "mapping_status": status,
                       "variant_ids": [row["variant_id"] for row in rows], "n_curated_variants": len(rows),
                       "source_clean_cluster_values": sorted({str(row["source_clean_cluster"]) for row in rows})})
    return output


def patient_display(raw, tree, drivers, provenance):
    metadata = raw["metadata"][0]
    ccf = {row["cluster_id"]: row["regional_ccf_percent"] for row in raw["ccf"]}
    parent = {child: ancestor for ancestor, child in tree["edges"]}
    parents = {ancestor for ancestor, child in tree["edges"]}
    nodes = []
    for node in sorted_nodes(tree["nodes"]):
        assigned = [row for row in drivers if row["mapping_status"] == "mapped_retained" and row["cluster_id"] == node]
        attributes = {"cluster_id": node, "snv_count": raw["branch_snv_counts"][node],
                      "curated_driver_genes": "; ".join(sorted({row["gene"] for row in assigned})) or "none assigned",
                      "curated_driver_variants": "; ".join(row["variant_id"] for row in assigned) or "none assigned",
                      "deposited_topologies": tree["n_topologies"]}
        if node in parent:
            support = tree["edge_counts"][(parent[node], node)]
            attributes.update({"source_edge_present_in_alternatives": support,
                               "source_edge_consensus": "yes" if support == tree["n_topologies"] else "no"})
        else:
            attributes["source_edge_consensus"] = "truncal stem; no deposited normal parent"
        for i, region in enumerate(raw["regions"], 1):
            if region not in ccf[node] or not math.isfinite(ccf[node][region]):
                raise ValueError("Retained cluster regional CCF missing/nonfinite")
            attributes[f"region_{i}_ccf_percent"] = ccf[node][region]
        nodes.append({"id": node, "label": "Cluster " + node, "parent_id": parent.get(node),
                      "branch_length": raw["branch_snv_counts"][node],
                      "source_node_type": "inferred_truncal_cluster" if node == tree["root"] else (
                          "inferred_ancestral_subclone" if node in parents else "inferred_terminal_subclone"),
                      "attributes": attributes})
    regions = []
    for label in raw["regions"]:
        matching = [row for row in raw["regional_metadata"] if row["sample_name_cruk"] == label.replace(".", "-")]
        if len(matching) > 1:
            raise ValueError("Nonunique exact regional metadata join")
        regions.append({"region_id": label, "ccf_matrix_label": label, "published_specimen_label": label.replace(".", "-"),
                        "regional_growth_pattern": matching[0]["regional_pattern.new"] if matching else None,
                        "metadata_join_status": "exact documented punctuation substitution" if matching else "no matching morphology row; unknown",
                        "sampling_class": "primary tumour R region" if re.search(r"\.R\d+$", label) else "surgery lymph node" if re.search(r"_SU_LN\d+$", label) else "unclassified"})
    display_provenance = {**provenance, "license_url": "https://zenodo.org/records/7683605"}
    return {"schema_version": "1.0", "source": display_provenance, "patient_id": metadata["cruk_id"], "tumor_id": raw["tumour_id"],
            "histology": metadata["histology_3"], "histology_source_value": metadata["Histology_per_tumour_id_muttable"],
            "tumor_predominant_growth_pattern": metadata["LUAD_pred_subtype_with.IMA_per_tumour"],
            "root_id": tree["root"], "root_stem": {"length": raw["branch_snv_counts"][tree["root"]], "description": "Published truncal SNV count; no source normal-origin node"},
            "branch_length": {"mode": "published", "units": "SNVs per mutation cluster", "description": "Cumulative assigned SNV counts; neither time nor substitutions per genomic site",
                              "source_evidence": "Fig.3bd.S4abcdefgh.R:531-535 selects Corrected_tree clusters and extracts graph_pyclone.edgelength as numSNVs; script SHA256 8f5c89db52e09c20ef81ecad993f95024f15670e2b845ba5f895d32568f94cc7"},
            "nodes": nodes, "regions": regions, "n_topologies": tree["n_topologies"],
            "source_encoding": tree["source_encoding"], "literal_source_corrected_edges": raw["corrected_edges"],
            "literal_source_consensus_branches": raw["consensus_branches"], "literal_source_consensus_relationships": raw["consensus_relationships"],
            "verification": {"source_nodes": len(nodes), "source_edges": len(tree["edges"]), "source_ccf_regions": len(regions),
                             "source_alternative_topologies": tree["n_topologies"], "all_source_alternatives_structurally_valid": True,
                             "all_alternative_consensus_relationships_independently_verified": True},
            "limitations": ["Displayed topology is one authors-selected corrected representative; multiple alternatives may disagree.",
                            "Population order uses unanimity across every deposited alternative, not this displayed representative alone.",
                            "Regional specimens are mixtures of clones; their morphology is not assigned to clones.",
                            "Authors-curated driver annotations are copied; no new functional validation is implied.",
                            "Alternative topology counts are not calibrated posterior probabilities.",
                            "Source CCF estimates are copied in percent, including values outside 0-100; they are not clamped."]}


def cohort_output_paths(config, output_dir=None, audit_path=None):
    """Keep independently frozen cohorts from overwriting original LUAD files."""
    original = config["primary_cohort"] == "LUAD"
    if not original and (output_dir is None or audit_path is None):
        raise ValueError("A separate cohort requires explicit --output and --audit-output paths")
    output_dir = Path(output_dir).resolve() if output_dir is not None else OUTPUT.resolve()
    audit_path = Path(audit_path).resolve() if audit_path is not None else (SOURCE / "source_audit.json").resolve()
    if not original and (output_dir == OUTPUT.resolve() or audit_path == (SOURCE / "source_audit.json").resolve()):
        raise ValueError("A separate cohort cannot overwrite the frozen LUAD export or audit")
    if config["eligibility"]["minimum_distinct_primary_R_regions"] < 2:
        raise ValueError("Multiregion eligibility cannot be relaxed below two primary regions")
    return output_dir, audit_path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--config", type=Path, default=ROOT / "configs/tracerx_routes_v0_1.json")
    parser.add_argument("--translation", type=Path, default=OUTPUT,
                        help="Immutable all-histology native translation directory")
    parser.add_argument("--output", type=Path,
                        help="Separate patient-level cohort export directory; required outside the original LUAD slice")
    parser.add_argument("--audit-output", type=Path,
                        help="Separate aggregate audit file; required outside the original LUAD slice")
    args = parser.parse_args()
    manifest = checked_sources()
    if args.verify_only:
        print("All pinned public source files verified.")
        return
    config_path = args.config.resolve()
    config = json.loads(config_path.read_text(encoding="utf-8-sig"))
    output_dir, audit_path = cohort_output_paths(config, args.output, args.audit_output)
    output_dir.mkdir(parents=True, exist_ok=True)
    translation = args.translation.resolve()
    extraction = json.loads((translation / "extraction_provenance.json").read_text(encoding="utf-8-sig"))
    for relative, expected in extraction["input_md5"].items():
        if digest(ROOT / relative, "md5") != expected:
            raise ValueError("Stale native source translation: " + relative)
    config_sha = digest(config_path)
    metadata = json.loads((translation / "metadata.json").read_text(encoding="utf-8-sig"))
    files = sorted((translation / "intermediate").glob("*.json"))
    if len(files) != 403 or extraction["tumours"] != 403:
        raise ValueError("Expected all 403 deposited tree objects")
    tumour_meta = {row["tumour_id_muttable_cruk"]: row for row in metadata["tumours"]}
    counts = Counter(tumour_meta[path.stem]["cruk_id"] for path in files)
    patients, inventory, issues = [], [], []
    structural_counts, mapping_counts, clean_mapping_counts = Counter(), Counter(), Counter()
    (output_dir / "patient_trees").mkdir(exist_ok=True)
    provenance = {"publication_title": "Evolutionary characterization of lung adenocarcinoma morphology in TRACERx", "doi": "10.1038/s41591-023-02230-w",
                  "publication_url": "https://doi.org/10.1038/s41591-023-02230-w", "data_url": "https://zenodo.org/records/7683605",
                  "source_file": "20221109_TRACERx421_phylogenetic_trees.rds", "sha256": manifest[0]["sha256"],
                  "mutation_file_sha256": manifest[-1]["sha256"], "license": "Academic non-commercial use only; see Zenodo record notes",
                  "source_object_path": "[tumour_id].graph_pyclone.Corrected_tree; exact curated mutation join via full variant key",
                  "config_sha256": config_sha}
    for file in files:
        raw = json.loads(file.read_text(encoding="utf-8-sig"))
        meta = raw["metadata"][0]
        patient_id, tumour_id = meta["cruk_id"], raw["tumour_id"]
        primary = [r for r in raw["regions"] if re.search(r"\.R\d+$", r)]
        lymph = [r for r in raw["regions"] if re.search(r"_SU_LN\d+$", r)]
        eligible = (meta["histology_3"] == config["primary_cohort"] and counts[patient_id] == 1
                    and len(set(primary)) >= config["eligibility"]["minimum_distinct_primary_R_regions"])
        record = {"patient_id": patient_id, "tumour_id": tumour_id, "histology": meta["histology_3"], "n_regions": len(raw["regions"]),
                  "n_primary_regions": len(primary), "n_ln_regions": len(lymph), "n_deposited_tumours_for_patient": counts[patient_id], "eligible": eligible}
        try:
            tree = audit_tree(raw)
            record.update({"structural_gate": "passed", "n_topologies": tree["n_topologies"], "nodes": len(tree["nodes"])})
            structural_counts["passed"] += 1
        except ValueError as error:
            record["structural_gate"] = str(error)
            structural_counts["failed"] += 1
            if eligible:
                issues.append({"tumour_id": tumour_id, "error": str(error)})
            inventory.append(record)
            continue
        if eligible:
            drivers = map_drivers(raw, tree, config["events"].get("candidate_gene_symbol_aliases"))
            for driver in drivers:
                mapping_counts[driver["mapping_status"]] += 1
                clean_mapping_counts[str(driver["source_clean_cluster"]) + ":" + driver["mapping_status"]] += 1
            events = gene_events(drivers)
            pairs = [{"a_cluster": a, "b_cluster": b, "state": classify_pair(a, b, tree["strict"], tree["possible"])}
                     for a, b in itertools.combinations(sorted_nodes(tree["nodes"]), 2)]
            patient = {"patient_id": patient_id, "tumour_id": tumour_id, "histology": meta["histology_3"],
                       "n_regions": len(raw["regions"]), "n_primary_regions": len(primary), "n_ln_regions": len(lymph), "region_ids": raw["regions"],
                       "n_topologies": tree["n_topologies"], "nodes": [{"id": node, "parent": {b:a for a,b in tree["edges"]}.get(node)} for node in sorted_nodes(tree["nodes"])],
                       "drivers": drivers, "events": events, "consensus_relations": pairs,
                       "strict_ancestor_pairs": [list(pair) for pair in sorted(tree["strict"])],
                       "possible_ancestor_pairs": [list(pair) for pair in sorted(tree["possible"])],
                       "treatment": {"source_adjuvant_label": raw["patient_metadata"][0]["adjuvant_treatment_YN"],
                                     "neoadjuvant_status": "not supplied as a per-patient field in these source tables",
                                     "sampling_context": "same-surgery source tree; primary regions and recorded surgery lymph nodes retained"},
                       "structural_gate": "passed", "source_consensus_relationships_verified": True}
            patient["source_encoding"] = tree["source_encoding"]
            patients.append(patient)
            display = patient_display(raw, tree, drivers, provenance)
            (output_dir / "patient_trees" / (tumour_id + ".json")).write_text(json.dumps(display, indent=2, allow_nan=False) + "\n", encoding="utf-8")
        inventory.append(record)
    expected = config["eligibility"]["expected_participants_before_structural_input_checks"]
    expected_eligible = sum(row["eligible"] for row in inventory)
    if expected_eligible != expected:
        raise ValueError("Frozen participant count changed")
    output = {"schema_version": "1.0", "provenance": provenance, "source_files": manifest, "patients": patients,
              "structural_gate": "passed" if not issues and len(patients) == expected else "failed", "structural_issues": issues}
    (output_dir / "cohort_trees.json").write_text(json.dumps(output, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    (output_dir / "cohort_inventory.json").write_text(json.dumps(inventory, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    audit = {"schema_version": "1.0", "config_sha256": config_sha, "source_record": provenance["data_url"], "source_files": manifest,
             "all_source_tumours": len(inventory), "all_source_patients": len(counts), "source_histology_counts": dict(Counter(row["histology"] for row in inventory)),
             "patients_with_multiple_deposited_tumours": sum(n > 1 for n in counts.values()),
             "frozen_cohort_eligible_before_structural_checks": expected_eligible, "structurally_eligible_exported": len(patients),
             "structural_audit_all_tumours": dict(structural_counts), "eligible_structural_issue_count": len(issues),
             "eligible_primary_region_counts": dict(Counter(row["n_primary_regions"] for row in inventory if row["eligible"])),
             "eligible_single_topology_tumours": sum(p["n_topologies"] == 1 for p in patients),
             "eligible_multiple_topology_tumours": sum(p["n_topologies"] > 1 for p in patients),
             "eligible_exact_single_cluster_sentinel_tumours": sum("sentinel" in p["source_encoding"] for p in patients),
             "curated_driver_mapping_counts": dict(mapping_counts), "source_clean_cluster_by_mapping": dict(clean_mapping_counts),
             "cohort_trees_sha256": digest(output_dir / "cohort_trees.json"), "structural_gate": output["structural_gate"],
             "limitations": ["Source driver calls and source phylogenies are not newly validated.", "No driver-gene frequency gate or population fit was performed by this extractor.",
                             "Same-surgery lymph-node specimens remain in source trees but do not qualify primary-region sampling depth.",
                             "No per-patient neoadjuvant status is imputed from the source adjuvant field.", "Topology alternatives are not independent patients or calibrated probability samples."]}
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    audit_path.write_text(json.dumps(audit, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({k:v for k,v in audit.items() if k not in ("source_files","limitations")}, indent=2))
    if issues:
        raise SystemExit("Frozen structural gate failed; no corrected-tree fallback permitted")


if __name__ == "__main__":
    main()
