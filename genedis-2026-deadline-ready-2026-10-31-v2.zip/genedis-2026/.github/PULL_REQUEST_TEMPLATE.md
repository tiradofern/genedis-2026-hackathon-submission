## Problem and resulting change

What scientific or technical problem does this address, and what changes for the reader/user?

## Evidence and validation

Source files/data versions, sample universe, methods or parameters changed, and checks actually run. State unverified checks clearly.

## Scientific interpretation and decisions

What can be inferred, what remains uncertain, and does this require a decision by the research lead? Link the relevant task or review.
