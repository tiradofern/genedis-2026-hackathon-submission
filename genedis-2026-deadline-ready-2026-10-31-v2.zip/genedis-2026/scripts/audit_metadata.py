"""Rebuild sample manifests and file-integrity summaries; performs no hypothesis tests.

Uses the Python standard library, including a read-only XLSX value reader.
The delivered tables are derived from public source files, not invented fixtures.
"""
from __future__ import annotations

import csv
import gzip
import hashlib
import json
import math
import re
import sys
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXTERNAL = ROOT / "data" / "external"
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def xlsx_first_sheet(path):
    """Read values of the first worksheet; preserve source text and cell positions."""
    with zipfile.ZipFile(path) as z:
        strings = []
        if "xl/sharedStrings.xml" in z.namelist():
            tree = ET.fromstring(z.read("xl/sharedStrings.xml"))
            strings = ["".join(si.itertext()) for si in tree.findall("m:si", NS)]
        sheet = ET.fromstring(z.read("xl/worksheets/sheet1.xml"))
        rows = []
        for row in sheet.findall("m:sheetData/m:row", NS):
            cells = {}
            for c in row.findall("m:c", NS):
                col = re.match(r"([A-Z]+)", c.attrib["r"])[1]
                index = 0
                for char in col:
                    index = index * 26 + ord(char) - 64
                v = c.find("m:v", NS)
                value = v.text if v is not None else ""
                if c.attrib.get("t") == "s" and value:
                    value = strings[int(value)]
                elif c.attrib.get("t") == "inlineStr":
                    value = "".join(c.find("m:is", NS).itertext())
                cells[index - 1] = value
            if cells:
                rows.append([cells.get(i, "") for i in range(max(cells) + 1)])
        width = max(map(len, rows))
        rows = [row + [""] * (width - len(row)) for row in rows]
    header = rows[0]
    return [dict(zip(header, row)) for row in rows[1:] if row[0]]


def geo_metadata(path):
    result = defaultdict(list)
    with path.open(encoding="utf-8", newline="") as f:
        for row in csv.reader(f, delimiter="\t"):
            if row and row[0].startswith("!"):
                result[row[0]].append(row[1:])
    return result


def geo_samples(metadata):
    accessions = metadata["!Sample_geo_accession"][0]
    if len(accessions) != len(set(accessions)):
        raise ValueError("Duplicate GSM accessions")
    samples = []
    for i, gsm in enumerate(accessions):
        sample = {"gsm": gsm, "source_title": metadata["!Sample_title"][0][i]}
        for row in metadata["!Sample_characteristics_ch1"]:
            if len(row) != len(accessions):
                raise ValueError("Inconsistent GEO metadata widths")
            key, sep, value = row[i].partition(": ")
            if sep:
                if key in sample:
                    raise ValueError(f"Repeated characteristic {key}")
                sample[key] = value
        samples.append(sample)
    return samples


def write_tsv(path, rows, fields=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = fields or list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fields, delimiter="\t", restval="NR")
        writer.writeheader()
        writer.writerows(rows)


def matrix_integrity(path, thousands=False, series_matrix=False):
    identifiers = Counter()
    header = None
    samples = []
    column_sums = []
    invalid = missing = converted = rows = 0
    minimum, maximum = math.inf, -math.inf
    with gzip.open(path, "rt", encoding="utf-8", newline="") as f:
        if series_matrix:
            for line in f:
                if line.startswith("!series_matrix_table_begin"):
                    break
            else:
                raise ValueError("Missing matrix start marker")
        for row in csv.reader(f, delimiter="\t"):
            if not row:
                continue
            if row[0].startswith("!series_matrix_table_end"):
                break
            if header is None:
                header = row
                if header[-1] == "":
                    header = header[:-1]
                samples = header[1:]
                if len(samples) != len(set(samples)):
                    raise ValueError("Duplicate expression column identifiers")
                column_sums = [0.0] * len(samples)
                continue
            if row[-1] == "" and len(row) == len(header) + 1:
                row = row[:-1]
            if len(row) != len(header):
                raise ValueError(f"Unexpected matrix width at data row {rows + 1}")
            rows += 1
            identifiers[row[0]] += 1
            for i, value in enumerate(row[1:]):
                if value in ("", "NA", "NaN", "null"):
                    missing += 1
                    continue
                if thousands and "," in value:
                    if not re.fullmatch(r"\d{1,3}(,\d{3})+(\.\d+)?", value):
                        raise ValueError(f"Invalid thousands grouping: {value}")
                    value = value.replace(",", "")
                    converted += 1
                try:
                    number = float(value)
                    if not math.isfinite(number):
                        raise ValueError("Nonfinite expression")
                except ValueError:
                    invalid += 1
                    continue
                column_sums[i] += number
                minimum = min(minimum, number)
                maximum = max(maximum, number)
    return dict(filename=path.name, features=rows, samples=len(samples),
                duplicate_feature_ids=sum(n - 1 for n in identifiers.values()),
                missing_cells=missing, invalid_cells=invalid,
                thousands_separator_cells=converted, minimum=minimum, maximum=maximum,
                sample_ids=samples, column_sums=column_sums,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def main():
    summaries = {}
    meta207 = geo_metadata(EXTERNAL / "GSE207422/GSE207422_matrix_metadata.txt")
    mapping207 = dict(zip(meta207["!Sample_title"][0], meta207["!Sample_geo_accession"][0]))
    cohorts207 = {}
    for assay, name, pattern in [
        ("bulk_RNAseq", "GSE207422_NSCLC_bulk_RNAseq_metadata.xlsx", r"R\d+LR\d+"),
        ("scRNAseq", "GSE207422_NSCLC_scRNAseq_metadata.xlsx", r"BD_immune\d+"),
    ]:
        original = xlsx_first_sheet(EXTERNAL / "GSE207422" / name)
        rows = [r for r in original if re.fullmatch(pattern, r.get("Sample", ""))]
        patients = [r["Patient"] for r in rows]
        if len(patients) != len(set(patients)):
            raise ValueError("Repeated patients within GSE207422 assay; review design")
        output = []
        for r in rows:
            response = r["Pathologic Response"]
            normalized = "MPR" if response in ("MPR", "MPR (pCR)", "pCR") else response
            resource = r["Resource"]
            state = "pretreatment" if resource in ("Pre_biopsy", "Pre-treatment biopsy") else "posttreatment_resection"
            if state == "posttreatment_resection" and resource != "Post-treatment surgery":
                raise ValueError(f"Unrecognized resource: {resource}")
            output.append(dict(accession="GSE207422", assay=assay, gsm=mapping207[r["Sample"]],
                               sample_id=r["Sample"], patient_id=r["Patient"], biological_state=state,
                               response_group=normalized, source_file=name, **r))
        write_tsv(ROOT / "manifests" / f"GSE207422_{assay}_samples.tsv", output)
        cohorts207[assay] = set(patients)
        summaries[f"GSE207422_{assay}"] = dict(samples=len(rows), patients=len(set(patients)),
            source_response_counts=dict(Counter(r["Pathologic Response"] for r in rows)),
            response_group_counts=dict(Counter(r["response_group"] for r in output)),
            timepoint_counts=dict(Counter(r["biological_state"] for r in output)),
            histology_counts=dict(Counter(r["Pathology"] for r in rows)),
            paired_within_assay_patients=0)
        if assay == "bulk_RNAseq":
            summaries[f"GSE207422_{assay}"]["histology_by_response"] = dict(Counter(
                f"{r['Pathology']}|{r['response_group']}" for r in output))
    summaries["GSE207422_cross_assay_overlap"] = sorted(cohorts207["bulk_RNAseq"] & cohorts207["scRNAseq"])
    summaries["GSE207422_union_patients"] = len(set.union(*cohorts207.values()))

    meta248 = geo_metadata(EXTERNAL / "GSE248249/GSE248249_matrix_metadata.txt")
    samples248 = geo_samples(meta248)
    by_patient = defaultdict(list)
    for i, r in enumerate(samples248):
        match = re.fullmatch(r"Tumor sample from Patient (\d+), (pre|post)-immunotherapy treatment", r["source_title"])
        if not match:
            raise ValueError("Unexpected GSE248249 title; cannot identify patient")
        patient, phase = match.groups()
        if r["timepoint"] != ("Pre-treatment" if phase == "pre" else "Post-treatment"):
            raise ValueError("Title and timepoint disagree")
        filename = meta248["!Sample_supplementary_file"][0][i]
        file_group = re.search(r"_(002\d+)[AB]_", filename)
        # Filename token is a technical proxy, never an author-confirmed batch label.
        r.update(accession="GSE248249", patient_id=patient,
                 biological_state="pretreatment" if phase == "pre" else "acquired_resistance",
                 technical_file_group=file_group[1] if file_group else "NR",
                 confirmed_batch="NR", histology="NR", cel_reference=filename)
        by_patient[patient].append(r)
    pairs = []
    for patient, records in by_patient.items():
        states = [r["biological_state"] for r in records]
        if len(states) != len(set(states)):
            raise ValueError("Duplicate patient/timepoint in GSE248249")
        if len(records) == 2:
            pre = next(r for r in records if r["biological_state"] == "pretreatment")
            post = next(r for r in records if r["biological_state"] == "acquired_resistance")
            pairs.append(dict(patient_id=patient, pre_gsm=pre["gsm"], post_gsm=post["gsm"],
                pre_site=pre["tumor site"], post_site=post["tumor site"],
                same_anatomic_site=pre["tumor site"] == post["tumor site"],
                pre_file_group=pre["technical_file_group"], post_file_group=post["technical_file_group"],
                same_technical_file_group=pre["technical_file_group"] == post["technical_file_group"],
                confirmed_batch="NR"))
    write_tsv(ROOT / "manifests/GSE248249_samples.tsv", samples248)
    write_tsv(ROOT / "manifests/GSE248249_pairs.tsv", pairs)
    summaries["GSE248249"] = dict(samples=len(samples248), patients=len(by_patient), complete_pairs=len(pairs),
        timepoint_counts=dict(Counter(r["biological_state"] for r in samples248)),
        same_site_pairs=sum(p["same_anatomic_site"] for p in pairs),
        same_file_group_pairs=sum(p["same_technical_file_group"] for p in pairs),
        same_site_and_file_group_pairs=sum(p["same_anatomic_site"] and p["same_technical_file_group"] for p in pairs),
        paired_patient_ids=[p["patient_id"] for p in pairs])

    meta156 = geo_metadata(EXTERNAL / "GSE156054/GSE156054_matrix_metadata.txt")
    samples156 = geo_samples(meta156)
    for r in samples156:
        r.update(accession="GSE156054", independent_profiles_per_model_state=1)
    write_tsv(ROOT / "manifests/GSE156054_samples.tsv", samples156)
    summaries["GSE156054"] = dict(samples=len(samples156), parental_resistant_model_pairs=3,
        response_counts=dict(Counter(r["tki response"] for r in samples156)),
        exposure_counts=dict(Counter(r["treatment"] for r in samples156)))

    # Additional matched epigenomic candidate: explicit title stems, never row order.
    additional = {}
    for acc in ("GSE126043", "GSE126044"):
        path = EXTERNAL / acc / f"{acc}_matrix_metadata.txt"
        if not path.exists():
            continue
        records = geo_samples(geo_metadata(path))
        for r in records:
            match = re.fullmatch(r"(?:methylation|RNA-seq)_(Dis_\d+)", r["source_title"])
            if not match:
                raise ValueError("Unexpected additional-cohort title")
            r.update(accession=acc, published_patient_code=match[1])
        if len({r["published_patient_code"] for r in records}) != len(records):
            raise ValueError("Duplicate published patient code")
        additional[acc] = {r["published_patient_code"]: r for r in records}
        write_tsv(ROOT / "manifests" / f"{acc}_samples.tsv", records)
        summaries[acc] = dict(samples=len(records),
            response_counts=dict(Counter(r["patient response"] for r in records)),
            timepoint_counts=dict(Counter(r["treatment status"] for r in records)))
        if acc == "GSE126044":
            summaries[acc]["response_by_preservation"] = dict(Counter(
                f"{r['patient response']}|{r['sample']}" for r in records))
    if len(additional) == 2:
        matched = []
        for code in sorted(set(additional["GSE126043"]) & set(additional["GSE126044"])):
            methylation, rna = additional["GSE126043"][code], additional["GSE126044"][code]
            if methylation["patient response"] != rna["patient response"]:
                raise ValueError("Cross-modality response labels disagree")
            matched.append(dict(published_patient_code=code, methylation_gsm=methylation["gsm"],
                rna_gsm=rna["gsm"], patient_response=rna["patient response"],
                rna_preservation=rna["sample"], match_basis="shared published Dis code; pretreatment cohort"))
        write_tsv(ROOT / "manifests/GSE126045_patient_matches.tsv", matched)
        summaries["GSE126045_matched_patient_codes"] = len(matched)

    matrices = [
        ("GSE207422", "GSE207422_NSCLC_bulk_RNAseq_log2TPM.txt.gz", False, False),
        ("GSE156054", "GSE156054_Raw_gene_counts_TPM.txt.gz", True, False),
        ("GSE248249", "GSE248249_series_matrix.txt.gz", False, True),
    ]
    integrity = []
    for acc, name, thousands, series in matrices:
        path = EXTERNAL / acc / name
        if path.exists():
            result = matrix_integrity(path, thousands, series)
            result["accession"] = acc
            if acc == "GSE207422":
                expected = {r["Sample"] for r in xlsx_first_sheet(EXTERNAL / acc / "GSE207422_NSCLC_bulk_RNAseq_metadata.xlsx") if re.fullmatch(r"R\d+LR\d+", r.get("Sample", ""))}
            elif acc == "GSE248249":
                expected = {r["gsm"] for r in samples248}
            else:
                expected = {r["source_title"].replace("-", "") for r in samples156}
            result["metadata_column_match"] = set(result["sample_ids"]) == expected
            if not result["metadata_column_match"] or result["invalid_cells"] or result["missing_cells"]:
                raise ValueError(f"Integrity failure for {name}")
            integrity.append(result)
    write_tsv(ROOT / "results/tables/matrix_integrity.tsv", [
        {k: v for k, v in r.items() if k not in ("sample_ids", "column_sums")} for r in integrity])
    report = dict(metadata=summaries, matrix_integrity=integrity,
                  scope="Feasibility and integrity only; no differential expression, module discovery, or replication performed")
    target = ROOT / "results/reports/audit_summary.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summaries, indent=2))
    for r in integrity:
        print(r["accession"],r["features"],r["samples"],"metadata match",r["metadata_column_match"],
              "missing",r["missing_cells"],"thousands cells",r["thousands_separator_cells"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
