"""Prepare real audited TCGA inputs for the local explorer. No external API calls."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import sqlite3
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import numpy as np
import scipy
from survival_islands.explorer_model import fit_components, fit_features, participant_split, project, provisional_modules

RAW = ROOT / "data/external/public_tcga_2026-10-17"
OUT = ROOT / "data/processed/explorer_v0_1"


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def table(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader((line for line in stream if not line.startswith("#")), delimiter="\t"))


def number(value):
    try:
        result = float(value)
        return result if np.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def stage_group(value):
    value = value.upper().replace("STAGE", "").strip()
    for group in ("IV", "III", "II", "I"):
        if value.startswith(group):
            return group
    return "Unknown"


def read_matrix(path, requested=None):
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.reader(stream, delimiter="\t")
        header = next(reader)
        id_column = header.index("Entrez_Gene_Id")
        first = next(i for i, item in enumerate(header) if item.startswith("TCGA-"))
        columns = header[first:] if requested is None else requested
        positions = [header.index(sid) for sid in columns]
        source = [(row[id_column], row[0], [number(row[i]) for i in positions]) for row in reader]
    counts = Counter(row[0] for row in source)
    accepted = [row for row in source if row[0].isdigit() and int(row[0]) > 0 and counts[row[0]] == 1]
    excluded = [dict(entrez=row[0], symbol=row[1], reason="missing_or_repeated_stable_id")
                for row in source if not row[0].isdigit() or int(row[0] or 0) <= 0 or counts[row[0]] != 1]
    values = np.array([row[2] for row in accepted], dtype=float).T
    return dict(ids=[row[0] for row in accepted], symbols=[row[1] for row in accepted],
                values=values, samples=columns, excluded=excluded, source_rows=len(source))


def verify_sources():
    inventory = table(ROOT / "manifests/public_tcga_files_2026-10-17.tsv")
    for record in inventory:
        if record["study"] == "DATAHUB":
            path = RAW / ".lfsconfig"
        elif record["study"] in {"GDC_PANCAN", "GDC_TCGA_LUNG_SLIDES"}:
            path = RAW / record["resource"]
        else:
            path = RAW / record["study"] / record["resource"]
        if not path.exists() or digest(path) != record["sha256"]:
            raise ValueError(f"Missing or changed verified source: {record['study']}/{record['resource']}")
    return inventory


def prepare(destination=OUT):
    destination.mkdir(parents=True, exist_ok=True)
    inventory = verify_sources()
    criteria_path = ROOT / "configs/candidate_island_v0_1.json"
    build_path = ROOT / "configs/explorer_build_v0_1.json"
    criteria = json.loads(criteria_path.read_text())
    build = json.loads(build_path.read_text())
    crosswalk = table(ROOT / "manifests/public_tcga_samples_2026-10-17.tsv")
    slides = table(ROOT / "manifests/public_tcga_gdc_slides_2026-10-17.tsv")
    recipe_files = {name: digest(ROOT / name) for name in (
        "configs/candidate_island_v0_1.json", "configs/explorer_build_v0_1.json",
        "manifests/public_tcga_samples_2026-10-17.tsv", "manifests/public_tcga_gdc_slides_2026-10-17.tsv",
        "scripts/prepare_explorer.py", "src/survival_islands/explorer_model.py")}
    fingerprint = hashlib.sha256((json.dumps(recipe_files, sort_keys=True) +
        "".join(record["sha256"] for record in inventory)).encode()).hexdigest()
    database_path = destination / "measurements.sqlite"
    database = sqlite3.connect(database_path)
    database.execute("DROP TABLE IF EXISTS variants")
    database.execute("CREATE TABLE variants(study TEXT,sample TEXT,gene TEXT,symbol TEXT,classification TEXT,protein TEXT,chromosome TEXT,position TEXT,reference TEXT,alternate TEXT)")
    bootstrap = dict(version=build["app_version"], fingerprint=fingerprint, criteria=criteria, build=build,
        source_commit="7a4b4ec142f76ac04db22834232b23142d25bd2a", cohorts={},
        linkage="TCGA sample key; identical vial, aliquot and histology section are not established",
        created_utc=datetime.now(timezone.utc).isoformat(),
        runtime=dict(python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__),
        recipe_files=recipe_files)
    gene_catalog, exclusion_log = {}, []
    for study, code in (("luad_tcga_pan_can_atlas_2018", "LUAD"), ("lusc_tcga_pan_can_atlas_2018", "LUSC")):
        print(f"Preparing {code} from verified source files", flush=True)
        folder = RAW / study
        core = sorted([row for row in crosswalk if row["study"] == study and row["proposed_core"] == "True"],
                      key=lambda row: row["sample_id"])
        ids = [row["sample_id"] for row in core]
        patients = {row["PATIENT_ID"]: row for row in table(folder / "data_clinical_patient.txt")}
        clinical = {row["SAMPLE_ID"]: row for row in table(folder / "data_clinical_sample.txt")}
        rna = read_matrix(folder / "data_mrna_seq_v2_rsem.txt", ids)
        cna = read_matrix(folder / "data_cna.txt", ids)
        normal = read_matrix(folder / "normals/data_mrna_seq_v2_rsem_normal_samples.txt")
        for assay, matrix in (("rna", rna), ("cna", cna), ("normal_rna", normal)):
            exclusion_log.extend(dict(study=code, assay=assay, **row) for row in matrix["excluded"])
        train, evaluation = participant_split([row["patient_id"] for row in core], build["seed"],
                                              criteria["discovery"]["training_fraction"])
        if len(train) < criteria["discovery"]["minimum_training_participants"] or len(evaluation) < criteria["discovery"]["minimum_holdout_participants"]:
            raise ValueError("Cohort is too small for the prespecified participant split")
        if build["discovery_gene_cap"] > criteria["discovery"]["maximum_discovery_genes_by_training_mad"]:
            raise ValueError("Exploration feature cap exceeds the scientific criteria")
        transform = fit_features(rna["values"], train, rna["ids"], criteria["discovery"], build["discovery_gene_cap"])
        z = transform["normalized"]
        components, explained = fit_components(z[train], 2)
        coordinates = z @ components
        modules = provisional_modules(z, train, build, criteria["discovery"],
                                      [rna["ids"][i] for i in transform["selected"]])
        program_records, score_map = [], {}
        selected = transform["selected"]
        for index, module in enumerate(modules, 1):
            identity = f"{code}-P{index:02}"
            positions = selected[module["indices"]]
            member_order = np.argsort(-np.abs(module["weights"]))
            genes = [dict(id=rna["ids"][positions[i]], symbol=rna["symbols"][positions[i]],
                          weight=float(module["weights"][i])) for i in member_order]
            record = dict(id=identity, name=f"RNA program {index:02}", genes=genes,
                gene_count=len(genes), pc1_variance=module["pc1_variance"],
                coordinated_fraction=module["coordinated_fraction"], coordination_pass=module["coordination_pass"],
                broad=module["broad"], high_threshold=module["high_threshold"],
                computational_status="provisional_module", evidence_tier=None,
                resampling_status="not_run", preservation_status="not_run",
                score_scale=module["score_scale"],
                note="Training coordination only; resampling, holdout preservation and functional evidence are pending")
            program_records.append(record)
            score_map[identity] = np.round(module["scores"], 6).tolist()
        with (folder / "data_mutations.txt").open(encoding="utf-8", newline="") as stream:
            reader = csv.DictReader((line for line in stream if not line.startswith("#")), delimiter="\t")
            batch = []
            for row in reader:
                sid = row["Tumor_Sample_Barcode"][:15]
                if sid not in ids:
                    continue
                batch.append((code, sid, row.get("Entrez_Gene_Id", ""), row["Hugo_Symbol"],
                    row["Variant_Classification"], row.get("HGVSp_Short", row.get("Protein_Change", "")),
                    row.get("Chromosome", ""), row.get("Start_Position", ""),
                    row.get("Reference_Allele", ""), row.get("Tumor_Seq_Allele2", "")))
                if len(batch) == 10000:
                    database.executemany("INSERT INTO variants VALUES (?,?,?,?,?,?,?,?,?,?)", batch)
                    batch = []
            database.executemany("INSERT INTO variants VALUES (?,?,?,?,?,?,?,?,?,?)", batch)
        samples = []
        for i, row in enumerate(core):
            p, s = patients[row["patient_id"]], clinical[row["sample_id"]]
            samples.append(dict(id=ids[i], patient_id=row["patient_id"], study=code,
                x=round(float(coordinates[i, 0]), 6), y=round(float(coordinates[i, 1]), 6),
                role="training" if i in train else "evaluation", stage=p.get("AJCC_PATHOLOGIC_TUMOR_STAGE", ""),
                stage_group=stage_group(p.get("AJCC_PATHOLOGIC_TUMOR_STAGE", "")), age=number(p.get("AGE")),
                sex=p.get("SEX", "Unknown"), purity=number(row.get("absolute_purity")),
                histology=s.get("TUMOR_TYPE", s.get("CANCER_TYPE_DETAILED", "")),
                rppa=row["rppa"] == "True", slide_count=sum(slide["sample_key"] == ids[i] for slide in slides),
                diagnostic_slide_count=sum(slide["patient_id"] == row["patient_id"] and slide["diagnostic_slide"] == "True" for slide in slides),
                clinical=p, pathology=s))
        normal_lookup = {gene: i for i, gene in enumerate(normal["ids"])}
        normal_aligned = np.full((len(normal["samples"]), len(rna["ids"])), np.nan)
        for i, gene in enumerate(rna["ids"]):
            if gene in normal_lookup:
                normal_aligned[:, i] = normal["values"][:, normal_lookup[gene]]
        normal_z = project(normal_aligned, transform)
        normal_xy = normal_z @ components
        references = [dict(id=sid, x=round(float(normal_xy[i, 0]), 6), y=round(float(normal_xy[i, 1]), 6))
                      for i, sid in enumerate(normal["samples"])]
        normal_coverage = float(np.mean([rna["ids"][i] in normal_lookup for i in selected]))
        cohort_slides = [row for row in slides if row["project"] == f"TCGA-{code}"]
        (destination / f"{code}_slides.json").write_text(json.dumps(cohort_slides), encoding="utf-8")
        arrays = dict(rna=np.asarray(transform["logged"], dtype=np.float32),
                      cna=np.asarray(cna["values"], dtype=np.float32), selected=selected,
                      center=transform["center"], scale=transform["scale"], impute=transform["impute"],
                      components=components, train=train, evaluation=evaluation)
        np.savez_compressed(destination / f"{code}_matrices.npz", **arrays)
        catalog = dict(rna_ids=rna["ids"], rna_symbols=rna["symbols"], cna_ids=cna["ids"], cna_symbols=cna["symbols"])
        (destination / f"{code}_genes.json").write_text(json.dumps(catalog), encoding="utf-8")
        for gid, symbol in zip(rna["ids"], rna["symbols"]):
            gene_catalog[gid] = symbol
        bootstrap["cohorts"][code] = dict(name="Lung adenocarcinoma" if code == "LUAD" else "Lung squamous cell carcinoma",
            samples=samples, programs=program_records, scores=score_map, normal_references=references,
            explained_variance=explained.tolist(), training_n=len(train), evaluation_n=len(evaluation),
            normal_feature_coverage=normal_coverage,
            source_study=study, discovery_features=len(selected), eligible_training_features=transform["eligible_count"],
            excluded_feature_rows={assay: len(matrix["excluded"]) for assay, matrix in (("rna", rna), ("cna", cna), ("normal_rna", normal))},
            available=dict(ihc=False, grade=False, longitudinal_resistance=False))
        print(f"{code}: {len(ids)} tumors, {len(program_records)} provisional programs; no biological tiers assigned", flush=True)
    database.execute("CREATE INDEX variant_sample ON variants(study,sample)")
    database.execute("CREATE INDEX variant_gene ON variants(study,gene)")
    database.commit()
    for code in bootstrap["cohorts"]:
        records = database.execute("SELECT gene,symbol,COUNT(DISTINCT sample) FROM variants WHERE study=? GROUP BY gene,symbol ORDER BY COUNT(DISTINCT sample) DESC LIMIT 25", (code,)).fetchall()
        bootstrap["cohorts"][code]["frequent_reported_genes"] = [dict(id=r[0], symbol=r[1], n=r[2]) for r in records]
    database.close()
    bootstrap["genes"] = [dict(id=gene, symbol=symbol) for gene, symbol in sorted(gene_catalog.items(), key=lambda pair: pair[1])]
    (destination / "feature_exclusions.json").write_text(json.dumps(exclusion_log, indent=2), encoding="utf-8")
    (destination / "bootstrap.json").write_text(json.dumps(bootstrap, allow_nan=False), encoding="utf-8")
    manifest = dict(fingerprint=fingerprint, criteria_sha256=digest(criteria_path), build_sha256=digest(build_path), recipe_files=recipe_files,
                    files={p.name: digest(p) for p in destination.iterdir() if p.is_file() and p.name != "prepared_manifest.json"})
    (destination / "prepared_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(dict(output=str(destination), fingerprint=fingerprint,
        cohorts={code:dict(samples=len(c["samples"]), programs=len(c["programs"])) for code,c in bootstrap["cohorts"].items()})), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", type=Path, default=OUT)
    prepare(parser.parse_args().destination)
