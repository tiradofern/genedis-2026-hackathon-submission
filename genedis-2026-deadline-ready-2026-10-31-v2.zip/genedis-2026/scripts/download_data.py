"""Bounded public-data retrieval for the feasibility audit (Python standard library).

Default: metadata only. --small-matrices adds two small RNA-seq matrices.
No FASTQ, BAM, CEL archives, or single-cell matrix is requested.
"""
from __future__ import annotations

import argparse
import hashlib
import gzip
import json
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ACCESSIONS = ("GSE207422", "GSE248249", "GSE156054")


def resources(include_matrices=False, comparison_matrix=False, paper_metadata=False, additional_metadata=False):
    out = []
    for acc in ACCESSIONS:
        bucket = acc[:-3] + "nnn"
        base = f"https://ftp.ncbi.nlm.nih.gov/geo/series/{bucket}/{acc}"
        out.extend([
            (acc, f"{acc}_series.soft", f"https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={acc}&targ=self&form=text&view=full", 300_000),
            (acc, f"{acc}_matrix_metadata.txt", base + f"/matrix/{acc}_series_matrix.txt.gz", 1_000_000),
            (acc, "supplementary_index.html", base + "/suppl/", 300_000),
            (acc, "matrix_index.html", base + "/matrix/", 300_000),
        ])
    base = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE207nnn/GSE207422/suppl/"
    for name in ("GSE207422_NSCLC_bulk_RNAseq_metadata.xlsx", "GSE207422_NSCLC_scRNAseq_metadata.xlsx"):
        out.append(("GSE207422", name, base + name, 100_000))
    if include_matrices:
        out.extend([
            ("GSE207422", "GSE207422_NSCLC_bulk_RNAseq_log2TPM.txt.gz", base + "GSE207422_NSCLC_bulk_RNAseq_log2TPM.txt.gz", 7_000_000),
            ("GSE156054", "GSE156054_Raw_gene_counts_TPM.txt.gz", "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE156nnn/GSE156054/suppl/GSE156054_Raw_gene_counts_TPM.txt.gz", 1_000_000),
        ])
    if comparison_matrix:
        out.append(("GSE248249", "GSE248249_series_matrix.txt.gz", "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE248nnn/GSE248249/matrix/GSE248249_series_matrix.txt.gz", 25_000_000))
    if paper_metadata:
        out.extend([
            ("GSE207422", "Hu2023_TableS1.xlsx", "https://pmc.ncbi.nlm.nih.gov/articles/instance/9985263/bin/13073_2023_1164_MOESM1_ESM.xlsx", 100_000),
            ("GSE248249", "Memon2024_TableS2.xlsx", "https://pmc.ncbi.nlm.nih.gov/articles/instance/11249385/bin/NIHMS1954849-supplement-2.xlsx", 100_000),
        ])
    if additional_metadata:
        for acc in ("GSE126043", "GSE126044"):
            base = f"https://ftp.ncbi.nlm.nih.gov/geo/series/GSE126nnn/{acc}"
            out.extend([
                (acc, f"{acc}_series.soft", f"https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={acc}&targ=self&form=text&view=full", 300_000),
                (acc, f"{acc}_matrix_metadata.txt", base + f"/matrix/{acc}_series_matrix.txt.gz", 1_000_000),
                (acc, "supplementary_index.html", base + "/suppl/", 300_000),
            ])
        for acc, study in (("TCGA-LUAD", "luad_tcga_pan_can_atlas_2018"), ("TCGA-LUSC", "lusc_tcga_pan_can_atlas_2018")):
            out.append((acc, "meta_study.txt", f"https://raw.githubusercontent.com/cBioPortal/datahub/master/public/{study}/meta_study.txt", 100_000))
    return out


def retrieve(acc, name, url, cap, destination):
    target = destination / acc / name
    target.parent.mkdir(parents=True, exist_ok=True)
    start = datetime.now(timezone.utc).isoformat()
    record = dict(accession=acc, filename=name, url=url, attempted_at_utc=start, max_bytes=cap)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "GeNeDis-feasibility-audit/0.1"})
        with urllib.request.urlopen(req, timeout=40) as response:
            declared = response.headers.get("Content-Length")
            prefix_only = name.endswith("_matrix_metadata.txt")
            if declared and int(declared) > cap and not prefix_only:
                raise ValueError(f"Declared file size exceeds audit cap: {declared} > {cap}")
            chunks, total = [], 0
            if prefix_only:
                # Stream only metadata; never retrieve the expression table in this mode.
                with gzip.GzipFile(fileobj=response) as compressed:
                    while line := compressed.readline(cap + 1 - total):
                        chunks.append(line)
                        total += len(line)
                        if total > cap:
                            raise ValueError(f"Decompressed metadata exceeded audit cap {cap}")
                        if line.startswith(b"!series_matrix_table_begin"):
                            break
                if not chunks or not chunks[0].startswith(b"!Series"):
                    raise ValueError("Expected GEO series matrix metadata")
            else:
                while chunk := response.read(min(65536, cap + 1 - total)):
                    chunks.append(chunk)
                    total += len(chunk)
                    if total > cap:
                        raise ValueError(f"Response exceeded audit cap {cap}")
            data = b"".join(chunks)
            if name.endswith(".soft") and not data.lstrip().startswith(b"^SERIES"):
                raise ValueError("Expected GEO SOFT; received a different response")
            if name.endswith(".xlsx") and not data.startswith(b"PK"):
                raise ValueError("Expected XLSX ZIP signature")
            if name.endswith(".gz") and not data.startswith(b"\x1f\x8b"):
                raise ValueError("Expected gzip signature")
            if name.endswith(".zip") and not data.startswith(b"PK"):
                raise ValueError("Expected ZIP signature")
            record.update(status="downloaded", bytes=total, sha256=hashlib.sha256(data).hexdigest(),
                          final_url=response.url, http_status=response.status,
                          stored_representation="decompressed_metadata_prefix" if prefix_only else "complete_file")
        temporary = target.with_name(target.name + ".partial")
        temporary.write_bytes(data)
        temporary.replace(target)
    except Exception as exc:
        record.update(status="failed", error=f"{type(exc).__name__}: {exc}")
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--small-matrices", action="store_true")
    parser.add_argument("--comparison-matrix", action="store_true", help="Retrieve the ~19MB processed GSE248249 array matrix")
    parser.add_argument("--paper-metadata", action="store_true", help="Retrieve two small publication sample tables")
    parser.add_argument("--additional-metadata", action="store_true", help="Audit two additional GEO accessions and TCGA study identities")
    parser.add_argument("--destination", type=Path, default=ROOT / "data" / "external")
    parser.add_argument("--list", action="store_true", help="Print URLs without network requests")
    args = parser.parse_args()
    selected = resources(args.small_matrices, args.comparison_matrix, args.paper_metadata, args.additional_metadata)
    if args.list:
        print(json.dumps(selected, indent=2))
        return 0
    args.destination.mkdir(parents=True, exist_ok=True)
    records = []
    for acc, name, url, cap in selected:
        result = retrieve(acc, name, url, cap, args.destination)
        records.append(result)
        print(f"{acc} {name}: {result['status']} {result.get('bytes', result.get('error'))}", flush=True)
        time.sleep(0.4)
    log = args.destination / "retrieval_log.json"
    log.write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    with (args.destination / "retrieval_attempts.jsonl").open("a", encoding="utf-8") as history:
        for record in records:
            history.write(json.dumps(record) + "\n")
    return 1 if any(r["status"] == "failed" for r in records) else 0


if __name__ == "__main__":
    raise SystemExit(main())
