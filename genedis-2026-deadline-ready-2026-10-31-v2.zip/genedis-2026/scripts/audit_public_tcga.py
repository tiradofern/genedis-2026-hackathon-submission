"""Bounded, pinned TCGA processed-data readiness audit; no hypothesis tests.

Downloads remain under ignored data/external/public_tcga_2026-10-17/.
Versioned outputs are a source inventory, sample crosswalk, slide links, and QC.
Never writes the October 14 audit files. Uses Python's standard library only.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATE = "2026-10-17"
REF = "7a4b4ec142f76ac04db22834232b23142d25bd2a"
# Declared in the pinned DataHub .lfsconfig; GitHub's mirror omits some objects.
LFS_BATCH_URL = "https://nsssw8k94d.execute-api.us-east-1.amazonaws.com/objects/batch"
STUDIES = ("luad_tcga_pan_can_atlas_2018", "lusc_tcga_pan_can_atlas_2018")
MISSING = {"", "NA", "N/A", "NAN", "NULL", "UNKNOWN", "NOT REPORTED", "NOT AVAILABLE",
           "NOT APPLICABLE", "[NOT REPORTED]", "[NOT AVAILABLE]", "[NOT APPLICABLE]", "[UNKNOWN]", "[NOT EVALUATED]"}
SMALL = ["LICENSE", "README.md", "meta_study.txt", "meta_mrna_seq_v2_rsem.txt",
         "meta_cna.txt", "meta_mutations.txt", "meta_rppa.txt",
         "normals/meta_mrna_seq_v2_rsem_normal_samples.txt"]
CASES = {"all": "cases_all.txt", "mutation": "cases_sequenced.txt",
         "rna": "cases_RNA_Seq_v2_mRNA.txt", "cna": "cases_cna.txt", "rppa": "cases_rppa.txt"}
DATA = ["data_clinical_patient.txt", "data_clinical_sample.txt", "data_mrna_seq_v2_rsem.txt",
        "data_cna.txt", "data_rppa.txt", "data_timeline_treatment.txt"]


def is_missing(value):
    return value.strip().upper() in MISSING


def sample_key(barcode):
    """cBioPortal TCGA sample-type key; NOT proof of identical vial/aliquot."""
    if not re.fullmatch(r"TCGA-[A-Za-z0-9]{2}-[A-Za-z0-9]{4}-[0-9]{2}.*", barcode):
        raise ValueError(f"Unrecognized TCGA barcode: {barcode}")
    return barcode[:15]


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_pointer(body):
    text = body.decode("utf-8")
    match = re.fullmatch(r"version https://git-lfs.github.com/spec/v1\noid sha256:([0-9a-f]{64})\nsize ([0-9]+)\n?", text)
    if not match:
        raise ValueError("Invalid Git LFS pointer")
    return match.group(1), int(match.group(2))


def retrieve(url, target, cap, download, expected_hash=None, expected_size=None):
    if target.exists():
        size = target.stat().st_size
        if size > cap or (expected_size is not None and size != expected_size):
            raise ValueError(f"Cached file size invalid: {target.name}")
        digest = sha256(target)
        if expected_hash and digest != expected_hash:
            raise ValueError(f"Cached checksum mismatch: {target.name}")
        return dict(url=url, bytes=size, sha256=digest, status="verified_cache")
    if not download:
        raise FileNotFoundError(f"Run with --download to retrieve {target.name}")
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + ".partial")
    request = urllib.request.Request(url, headers={"User-Agent": "GeNeDis-public-readiness/0.2"})
    digest, size = hashlib.sha256(), 0
    with urllib.request.urlopen(request, timeout=40) as response, temporary.open("wb") as stream:
        declared = response.headers.get("Content-Length")
        if declared and int(declared) > cap:
            raise ValueError(f"Declared response exceeds cap: {url}")
        while chunk := response.read(1024 * 1024):
            size += len(chunk)
            if size > cap:
                raise ValueError(f"Response exceeds cap: {url}")
            digest.update(chunk)
            stream.write(chunk)
    if expected_size is not None and size != expected_size:
        raise ValueError(f"Downloaded size mismatch: {target.name}")
    if expected_hash and digest.hexdigest() != expected_hash:
        raise ValueError(f"Downloaded checksum mismatch: {target.name}")
    temporary.replace(target)
    return dict(url=url, bytes=size, sha256=digest.hexdigest(), status="downloaded")


def acquire(study, name, destination, download):
    relative = f"public/{study}/{name}"
    raw_url = f"https://raw.githubusercontent.com/cBioPortal/datahub/{REF}/{relative}"
    target = destination / study / name
    if Path(name).name.startswith("data_"):
        pointer = target.with_name(target.name + ".lfs-pointer")
        retrieve(raw_url, pointer, 2000, download)
        digest, size = parse_pointer(pointer.read_bytes())
        url = f"https://media.githubusercontent.com/media/cBioPortal/datahub/{REF}/{relative}"
        try:
            record = retrieve(url, target, 250_000_000, download, digest, size)
        except urllib.error.HTTPError as exc:
            if exc.code != 404 or not download:
                raise
            payload = json.dumps({"operation": "download", "transfers": ["basic"],
                                  "objects": [{"oid": digest, "size": size}]}).encode()
            request = urllib.request.Request(LFS_BATCH_URL, data=payload, method="POST", headers={
                "Accept": "application/vnd.git-lfs+json", "Content-Type": "application/vnd.git-lfs+json"})
            with urllib.request.urlopen(request, timeout=40) as response:
                obj = json.load(response)["objects"][0]
            if obj.get("error"):
                raise ValueError(f"Declared DataHub LFS storage: {obj['error']}")
            href = obj["actions"]["download"]["href"]
            record = retrieve(href, target, 250_000_000, download, digest, size)
            # Signed temporary download links are not durable source identifiers.
            record["url"] = raw_url
            record["retrieval_route"] = "DataHub declared LFS batch endpoint"
        record.update(lfs_pointer_url=raw_url, lfs_oid=digest)
    else:
        record = retrieve(raw_url, target, 200_000, download)
    record.update(study=study, resource=name, source_commit=REF)
    return record


def read_table(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader((line for line in stream if not line.startswith("#")), delimiter="\t")
        columns = reader.fieldnames
        if not columns or len(columns) != len(set(columns)):
            raise ValueError(f"Missing/duplicate clinical header: {path.name}")
        rows = list(reader)
    if any(None in row or any(value is None for value in row.values()) for row in rows):
        raise ValueError(f"Ragged clinical table: {path.name}")
    return columns, rows


def unique_rows(rows, key):
    result = {}
    for row in rows:
        identity = row[key]
        if not identity or identity in result:
            raise ValueError(f"Missing/duplicate {key}: {identity}")
        result[identity] = row
    return result


def case_ids(path):
    lines = path.read_text(encoding="utf-8").splitlines()
    line = next(line for line in lines if line.startswith("case_list_ids:"))
    ids = line.split(":", 1)[1].split()
    if len(ids) != len(set(ids)):
        raise ValueError(f"Duplicate case-list entry: {path.name}")
    return set(ids)


def matrix_audit(path, kind):
    missing_by_sample, genes, duplicate_genes = Counter(), set(), 0
    cells = Counter()
    rows, constant_rows, malformed_rows = 0, 0, 0
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.reader(stream, delimiter="\t")
        header = next(reader)
        first = next((i for i, value in enumerate(header) if value.startswith("TCGA-")), None)
        if first is None:
            raise ValueError(f"No TCGA matrix sample columns: {path.name}")
        samples = header[first:]
        if len(samples) != len(set(samples)):
            raise ValueError(f"Duplicate matrix sample: {path.name}")
        for row in reader:
            rows += 1
            if len(row) != len(header):
                malformed_rows += 1
                continue
            key = tuple(row[:first])
            duplicate_genes += key in genes
            genes.add(key)
            lower, upper = math.inf, -math.inf
            for sample, value in zip(samples, row[first:]):
                if is_missing(value):
                    cells["missing"] += 1
                    missing_by_sample[sample] += 1
                    continue
                try:
                    number = float(value)
                except ValueError:
                    cells["invalid_numeric"] += 1
                    continue
                if not math.isfinite(number):
                    cells["nonfinite"] += 1
                    continue
                cells["finite"] += 1
                cells["zero"] += number == 0
                cells["negative"] += number < 0
                cells["invalid_cna"] += kind == "cna" and number not in {-2, -1, 0, 1, 2}
                lower, upper = min(lower, number), max(upper, number)
            constant_rows += lower == upper or lower == math.inf
    fatal = malformed_rows or cells["invalid_numeric"] or cells["nonfinite"] or cells["invalid_cna"]
    fatal = fatal or (kind in {"rna", "normal_rna"} and cells["negative"])
    return dict(rows=rows, sample_columns=len(samples), id_columns=header[:first],
                duplicate_feature_keys=duplicate_genes, constant_or_all_missing_rows=constant_rows,
                malformed_rows=malformed_rows, cells=dict(cells),
                missing_cells_by_sample=dict(missing_by_sample), samples=samples,
                structural_numeric_checks_passed=not bool(fatal))


def mutation_audit(path):
    counts, full_barcodes, genes, builds = Counter(), set(), set(), Counter()
    rows = 0
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader((line for line in stream if not line.startswith("#")), delimiter="\t")
        required = {"Tumor_Sample_Barcode", "Hugo_Symbol", "Variant_Classification", "NCBI_Build"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError("Mutation schema lacks required fields")
        for row in reader:
            if None in row or any(value is None for value in row.values()):
                raise ValueError("Ragged mutation table")
            barcode = row["Tumor_Sample_Barcode"]
            counts[sample_key(barcode)] += 1
            full_barcodes.add(barcode)
            genes.add(row["Hugo_Symbol"])
            builds[row["NCBI_Build"]] += 1
            rows += 1
    return dict(rows=rows, samples_with_reported_events=len(counts), unique_genes=len(genes),
                genome_builds=dict(builds), barcode_lengths=dict(Counter(map(len, full_barcodes))),
                full_barcodes=sorted(full_barcodes), records_by_sample=dict(counts))


def coverage(rows, columns):
    return {column: dict(observed=sum(not is_missing(row[column]) for row in rows), total=len(rows))
            for column in columns}


def write_tsv(path, rows, columns):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, delimiter="\t", extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def gdc_slides(destination, download):
    filters = {"op": "and", "content": [
        {"op": "in", "content": {"field": "cases.project.project_id", "value": ["TCGA-LUAD", "TCGA-LUSC"]}},
        {"op": "in", "content": {"field": "data_type", "value": ["Slide Image"]}}]}
    fields = "file_id,file_name,access,file_size,md5sum,cases.submitter_id,cases.project.project_id,cases.samples.submitter_id,cases.samples.sample_type"
    url = "https://api.gdc.cancer.gov/files?" + urllib.parse.urlencode(
        {"filters": json.dumps(filters), "fields": fields, "size": 10000, "sort": "file_id:asc"})
    path = destination / "gdc_slide_metadata.json"
    record = retrieve(url, path, 15_000_000, download)
    response = json.loads(path.read_text(encoding="utf-8"))
    hits = response["data"]["hits"]
    if len(hits) != response["data"]["pagination"]["total"]:
        raise ValueError("GDC slide response is incomplete; paginate before using")
    rows = []
    for hit in hits:
        for case in hit["cases"]:
            samples = case.get("samples") or [{}]
            for sample in samples:
                barcode = sample.get("submitter_id", "")
                rows.append(dict(project=case["project"]["project_id"], patient_id=case["submitter_id"],
                                 source_sample_barcode=barcode, sample_key=sample_key(barcode) if barcode else "",
                                 file_id=hit["file_id"], file_name=hit["file_name"], access=hit["access"],
                                 file_size=hit["file_size"], md5sum=hit["md5sum"],
                                 diagnostic_slide="-DX" in hit["file_name"]))
    record.update(study="GDC_TCGA_LUNG_SLIDES", resource=path.name, source_commit="NA_live_GDC_snapshot")
    return rows, record


def run(args):
    destination = args.destination
    report = dict(audit_date=DATE, generated_at_utc=datetime.now(timezone.utc).isoformat(),
                  datahub_commit=REF, analysis_status="readiness audit only; no discovery or hypothesis tests",
                  linkage="cBioPortal 15-character sample-type key, not verified identical vial/aliquot/block",
                  studies={})
    inventory, specimen_rows = [], []
    config_record = retrieve(f"https://raw.githubusercontent.com/cBioPortal/datahub/{REF}/.lfsconfig",
                             destination / ".lfsconfig", 2000, args.download)
    config_record.update(study="DATAHUB", resource=".lfsconfig", source_commit=REF)
    inventory.append(config_record)
    purity_path = destination / "TCGA_mastercalls.abs_tables_JSedit.fixed.txt"
    purity_record = retrieve("https://api.gdc.cancer.gov/data/4f277128-f793-4354-a13d-30cc7fe9f6b5",
                             purity_path, 5_000_000, args.download)
    purity_record.update(study="GDC_PANCAN", resource=purity_path.name, source_commit="NA_GDC_publication_UUID")
    inventory.append(purity_record)
    _, purity_rows = read_table(purity_path)
    purity = unique_rows(purity_rows, "array")
    for row in purity_rows:
        if not is_missing(row["purity"]):
            value = float(row["purity"])
            if not math.isfinite(value) or not 0 <= value <= 1:
                raise ValueError("Invalid ABSOLUTE purity fraction")
    slides, gdc_record = gdc_slides(destination, args.download)
    inventory.append(gdc_record)
    for study in STUDIES:
        print(f"Acquiring/verifying {study}", flush=True)
        resources = SMALL + [f"case_lists/{name}" for name in CASES.values()] + DATA
        if args.include_mutations:
            resources.append("data_mutations.txt")
        for name in resources:
            try:
                inventory.append(acquire(study, name, destination, args.download))
            except Exception as exc:
                raise RuntimeError(f"Required resource failed: {study}/{name}: {exc}") from exc
        # This optional resource currently has a public LFS pointer but its
        # payload may be unavailable. GDC slide metadata is audited separately.
        for optional_name in ("data_resource_patient.txt", "normals/data_mrna_seq_v2_rsem_normal_samples.txt"):
            try:
                inventory.append(acquire(study, optional_name, destination, args.download))
            except Exception as exc:
                inventory.append(dict(study=study, resource=optional_name, source_commit=REF,
                    url=f"https://media.githubusercontent.com/media/cBioPortal/datahub/{REF}/public/{study}/{optional_name}",
                    status="unavailable", error=f"{type(exc).__name__}: {exc}"))
        folder = destination / study
        sample_columns, sample_records = read_table(folder / "data_clinical_sample.txt")
        patient_columns, patient_records = read_table(folder / "data_clinical_patient.txt")
        samples = unique_rows(sample_records, "SAMPLE_ID")
        patients = unique_rows(patient_records, "PATIENT_ID")
        lists = {kind: case_ids(folder / "case_lists" / name) for kind, name in CASES.items()}
        matrices = {kind: matrix_audit(folder / name, kind) for kind, name in [
            ("rna", "data_mrna_seq_v2_rsem.txt"), ("cna", "data_cna.txt"),
            ("rppa", "data_rppa.txt")]}
        normal_path = folder / "normals/data_mrna_seq_v2_rsem_normal_samples.txt"
        matrices["normal_rna"] = matrix_audit(normal_path, "normal_rna") if normal_path.exists() else dict(available=False, samples=[])
        sets = {kind: set(value["samples"]) for kind, value in matrices.items()}
        primary = {sid for sid in samples if sample_key(sid).endswith("-01")}
        core = primary & sets["rna"] & sets["cna"] & lists["mutation"]
        project = "TCGA-LUAD" if study.startswith("luad") else "TCGA-LUSC"
        cohort_slides = [row for row in slides if row["project"] == project]
        patient_slide = {row["patient_id"] for row in cohort_slides}
        sample_slide = {row["sample_key"] for row in cohort_slides if row["sample_key"]}
        diagnostic_patient = {row["patient_id"] for row in cohort_slides if row["diagnostic_slide"]}
        mutations = mutation_audit(folder / "data_mutations.txt") if args.include_mutations else None
        for sid in sorted(samples):
            pid = samples[sid]["PATIENT_ID"]
            if pid not in patients:
                raise ValueError(f"Clinical patient join failed: {sid}")
            specimen_rows.append(dict(study=study, sample_id=sid, patient_id=pid, primary_tumor=sid in primary,
                                      rna=sid in sets["rna"], cna=sid in sets["cna"],
                                      mutation_profiled=sid in lists["mutation"], rppa=sid in sets["rppa"],
                                      proposed_core=sid in core, gdc_slide_patient_link=pid in patient_slide,
                                      gdc_slide_sample_type_key_link=sid in sample_slide,
                                      gdc_diagnostic_slide_patient_link=pid in diagnostic_patient,
                                      absolute_purity=purity.get(sid, {}).get("purity", ""),
                                      absolute_ploidy=purity.get(sid, {}).get("ploidy", ""),
                                      absolute_dna_aliquot=purity.get(sid, {}).get("sample", "")))
        core_sample_rows = [samples[sid] for sid in sorted(core)]
        core_patient_ids = {row["PATIENT_ID"] for row in core_sample_rows}
        if len(core_patient_ids) != len(core):
            raise ValueError("Core cohort contains repeated participants; adjudication required")
        core_patients = [patients[pid] for pid in sorted(core_patient_ids)]
        profile_discrepancies = {kind: dict(in_matrix_not_case_list=sorted(sets[kind] - lists[kind]),
                                           in_case_list_not_matrix=sorted(lists[kind] - sets[kind]))
                                 for kind in ("rna", "cna", "rppa")}
        report["studies"][study] = dict(
            clinical_samples=len(samples), clinical_patients=len(patients), primary_tumor_samples=len(primary),
            clinical_sample_type_values=dict(Counter(row.get("SAMPLE_TYPE", "NR") for row in sample_records)),
            case_list_counts={kind: len(ids) for kind, ids in lists.items()}, matrices=matrices,
            profile_list_discrepancies=profile_discrepancies,
            core_rna_cna_mutation_profiled_primary=dict(samples=len(core), patients=len(core_patient_ids),
                with_rppa=len(core & sets["rppa"]), with_patient_slide_link=len(core_patient_ids & patient_slide),
                with_sample_type_key_slide_link=len(core & sample_slide),
                with_diagnostic_slide_patient_link=len(core_patient_ids & diagnostic_patient),
                with_absolute_purity=sum(sid in purity and not is_missing(purity[sid]["purity"]) for sid in core)),
            normal_rna_sample_type_codes=dict(Counter(sample_key(sid)[-2:] for sid in sets["normal_rna"])) if normal_path.exists() else None,
            core_patients_with_normal_rna=len(core_patient_ids & {sid[:12] for sid in sets["normal_rna"]}) if normal_path.exists() else None,
            core_patient_field_coverage=coverage(core_patients, patient_columns),
            core_sample_field_coverage=coverage(core_sample_rows, sample_columns),
            clinical_ihc_named_fields=[name for name in patient_columns + sample_columns if re.search(r"IHC|PD.?L1|TTF|P40|P63|NAPSIN", name, re.I)],
            mutation_audit=mutations,
            mutation_samples_outside_profile_list=sorted(set(mutations["records_by_sample"]) - lists["mutation"]) if mutations else None,
            mutation_profiled_no_reported_event=sorted(lists["mutation"] - set(mutations["records_by_sample"])) if mutations else None,
            gdc_slide_metadata=dict(files=len({row["file_id"] for row in cohort_slides}),
                patients=len(patient_slide), open_files=len({row["file_id"] for row in cohort_slides if row["access"] == "open"})))
    report["cross_study_duplicate_core_patients"] = sorted(
        {row["patient_id"] for row in specimen_rows if row["proposed_core"] and row["study"] == STUDIES[0]} &
        {row["patient_id"] for row in specimen_rows if row["proposed_core"] and row["study"] == STUDIES[1]})
    report_path = ROOT / "results" / "reports" / f"public_tcga_readiness_{DATE}.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    write_tsv(ROOT / "manifests" / f"public_tcga_files_{DATE}.tsv", inventory,
              ["study", "resource", "source_commit", "url", "bytes", "sha256", "lfs_pointer_url", "lfs_oid", "retrieval_route", "status", "error"])
    write_tsv(ROOT / "manifests" / f"public_tcga_samples_{DATE}.tsv", specimen_rows, list(specimen_rows[0]))
    write_tsv(ROOT / "manifests" / f"public_tcga_gdc_slides_{DATE}.tsv", slides, list(slides[0]))
    concise = {study: {"core": value["core_rna_cna_mutation_profiled_primary"],
                "rna": {key: value["matrices"]["rna"][key] for key in ("rows", "sample_columns", "structural_numeric_checks_passed")},
                "ihc_fields": value["clinical_ihc_named_fields"]} for study, value in report["studies"].items()}
    print(json.dumps(dict(report=str(report_path), studies=concise), indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--include-mutations", action="store_true", help="Also verify the complete ~425 MB of processed public MAF files")
    parser.add_argument("--destination", type=Path, default=ROOT / "data" / "external" / f"public_tcga_{DATE}")
    run(parser.parse_args())
