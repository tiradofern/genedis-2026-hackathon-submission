"""Run the local, read-only explorer after preparing the audited data."""
import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from survival_islands.explorer_server import serve

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8766)
    parser.add_argument("--data", type=Path, default=ROOT / "data/processed/explorer_v0_1")
    args = parser.parse_args()
    if not (args.data / "prepared_manifest.json").exists():
        parser.error("Prepared data are missing. Run .venv\\Scripts\\python.exe scripts\\prepare_explorer.py first.")
    serve(args.data, args.port)
