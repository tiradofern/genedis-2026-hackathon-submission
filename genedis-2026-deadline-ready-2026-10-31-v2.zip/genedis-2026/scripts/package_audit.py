"""Package the first-assignment audit, excluding complete datasets and scratch work."""
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT.parent / "genedis-survival-islands-audit.zip"


def include(path):
    relative = path.relative_to(ROOT)
    if any(part in ("__pycache__", ".git", ".venv", "work") for part in relative.parts):
        return False
    if path.suffix in (".pyc", ".zip") or path.name.endswith("_error.xml"):
        return False
    if relative.parts[:2] == ("data", "external"):
        return not (path.suffix == ".gz" or path.name in ("GSE248249_quick.soft", "pride_record.html"))
    return True


def main():
    with zipfile.ZipFile(TARGET, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(ROOT.rglob("*")):
            if not include(path):
                continue
            relative = path.relative_to(ROOT)
            if path.is_file():
                archive.write(path, str(Path(ROOT.name) / relative))
            elif path.is_dir() and not any(path.iterdir()):
                archive.writestr(str(Path(ROOT.name) / relative).replace("\\", "/") + "/", b"")
    with zipfile.ZipFile(TARGET) as archive:
        assert archive.testzip() is None
        names = archive.namelist()
        assert not any(name.endswith((".gz", ".pyc")) for name in names)
        assert all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in names)
        assert any(name.endswith("dataset_manifest.tsv") for name in names)
        assert any(name.endswith("scientific_decision_report.md") for name in names)
    print(TARGET)
    print(f"Archive size: {TARGET.stat().st_size:,} bytes; {len(names)} members")


if __name__ == "__main__":
    main()
