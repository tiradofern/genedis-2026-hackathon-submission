"""Read-only validation of genuine MEDICC2 outputs; no inference implementation."""
from __future__ import annotations

from collections import Counter, defaultdict
from bisect import bisect_left, bisect_right
import csv
import hashlib
import math
from pathlib import Path
import re

from .contracts import arm_loh_state, event_placement, validate_tree, wgd_placement


def sha256(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_newick(path: str | Path) -> dict:
    """Parse the ordinary named Newick written by Bio.Phylo in official MEDICC2.

    Quoted labels and scientific branch lengths are accepted. Every non-root
    node must be named, since unnamed internal nodes cannot match model profiles.
    Comments/extended Newick are deliberately rejected instead of guessed.
    """
    source = Path(path).read_text(encoding="utf-8").strip()
    tokens = re.findall(r"'(?:[^']|'')*'|[(),:;]|[^\s(),:;]+", source)
    position = 0
    parent, lengths = {}, {}

    def node():
        nonlocal position
        children = []
        if position < len(tokens) and tokens[position] == "(":
            position += 1
            children.append(node())
            while position < len(tokens) and tokens[position] == ",":
                position += 1
                children.append(node())
            if position >= len(tokens) or tokens[position] != ")":
                raise ValueError("Malformed Newick child list")
            position += 1
        name = None
        if position < len(tokens) and tokens[position] not in {",", ")", ":", ";"}:
            name = tokens[position]
            if "[" in name or "]" in name:
                raise ValueError("Extended Newick comments are outside this contract")
            if name.startswith("'"):
                name = name[1:-1].replace("''", "'")
            position += 1
        length = 0.0
        if position < len(tokens) and tokens[position] == ":":
            position += 1
            if position >= len(tokens):
                raise ValueError("Missing branch length")
            length = float(tokens[position])
            position += 1
            if not math.isfinite(length) or length < 0:
                raise ValueError("Invalid branch length")
        return {"name": name, "length": length, "children": children}

    parsed = node()
    if position >= len(tokens) or tokens[position] != ";" or position != len(tokens) - 1:
        raise ValueError("Newick must end at a single semicolon")
    parsed["name"] = parsed["name"] or "__synthetic_root__"

    def collect(value, ancestor):
        name = value["name"]
        if name is None or name in parent:
            raise ValueError("Every model node needs a unique name")
        parent[name] = ancestor
        lengths[name] = value["length"]
        for child in value["children"]:
            collect(child, name)
    collect(parsed, None)
    root = validate_tree(parent, lengths)
    internal = {value for value in parent.values() if value is not None}
    return {"root": root, "parent": parent, "lengths": lengths,
            "terminals": sorted(set(parent) - internal)}


def integer(value: str) -> int:
    # Genuine model outputs can serialize integer states as '1.0'. Accept the
    # exact integer only; do not repeat the engine reader's float rounding.
    number = float(value)
    if not math.isfinite(number) or number < 0 or number != int(number):
        raise ValueError("Noninteger or negative model state")
    return int(number)


def read_profiles(path: str | Path, allele_columns=("cn_a", "cn_b"), require_common_segments=True) -> dict:
    result = defaultdict(list)
    seen = set()
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if not {"sample_id", "chrom", "start", "end", *allele_columns}.issubset(reader.fieldnames or []):
            raise ValueError("Missing official profile columns")
        for row in reader:
            start, end = integer(row["start"]), integer(row["end"])
            key = (row["sample_id"], row["chrom"], start, end)
            if start >= end or key in seen:
                raise ValueError("Duplicate or invalid model segment")
            seen.add(key)
            result[row["sample_id"]].append({"chrom": row["chrom"], "start": start,
                "end": end, **{name: integer(row[column]) for name, column
                               in zip(("cn_a", "cn_b"), allele_columns)}})
    if len(allele_columns) != 2:
        raise ValueError("LOH parser requires two allele columns; total-CN is a separate diagnostic")
    for rows in result.values():
        rows.sort(key=lambda row: (row["chrom"], row["start"], row["end"]))
    if not result:
        raise ValueError("Empty model profile output")
    keys = [{(row["chrom"], row["start"], row["end"]) for row in rows} for rows in result.values()]
    if require_common_segments and any(key != keys[0] for key in keys[1:]):
        raise ValueError("Ancestral profiles have inconsistent segments")
    return dict(result)


def project_profiles_to_atoms(profiles: dict, atoms: list[dict]) -> dict:
    """Intersect model states with exact measured atoms; never measure a gap.

    Coalesced model intervals can bridge omitted short gaps under the explicit
    engine adjacency assumption. Such enclosing intervals are not coverage.
    Every source atom must be fully covered by one constant model allele state.
    """
    output = {}
    for node, rows in profiles.items():
        exact = {(row["chrom"], row["start"], row["end"]): row for row in rows}
        by_chrom = defaultdict(list)
        for row in rows:
            by_chrom[row["chrom"]].append(row)
        starts = {chrom: [row["start"] for row in chrom_rows] for chrom, chrom_rows in by_chrom.items()}
        result = []
        for atom in atoms:
            left, right, chrom = atom["start"], atom["end"], atom["pseudochrom"]
            if atom["observed_bp"] != right - left:
                raise ValueError("Measured atom must exclude every unmeasured gap")
            if (chrom, left, right) in exact:
                row = exact[(chrom, left, right)]
                result.append({"chrom": chrom, "start": left, "end": right,
                               "cn_a": row["cn_a"], "cn_b": row["cn_b"]})
                continue
            chrom_rows = by_chrom[chrom]
            begin = max(0, bisect_right(starts.get(chrom, []), left) - 1)
            finish = bisect_left(starts.get(chrom, []), right)
            overlaps = [(max(left, row["start"]), min(right, row["end"]), row["cn_a"], row["cn_b"])
                        for row in chrom_rows[begin:finish] if row["end"] > left]
            overlaps.sort()
            cursor = left
            for start, end, _, _ in overlaps:
                if start != cursor:
                    raise ValueError("Model output leaves a hole or overlaps within a measured atom")
                cursor = end
            if cursor != right or len({(a, b) for _, _, a, b in overlaps}) != 1:
                raise ValueError("Measured atom lacks a single exact model state")
            result.append({"chrom": chrom, "start": left, "end": right,
                           "cn_a": overlaps[0][2], "cn_b": overlaps[0][3]})
        output[node] = sorted(result, key=lambda row: (row["chrom"], row["start"], row["end"]))
    return output


def read_events(path: str | Path) -> list[dict]:
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        required = {"sample_id", "allele", "chrom", "start", "end", "type", "cn_child"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError("Missing official event columns")
        result = []
        for row in reader:
            if row["type"] not in {"gain", "loss", "wgd"}:
                raise ValueError("Unexpected official event type")
            result.append({**{name: row[name] for name in ("sample_id", "allele", "chrom", "type")},
                **{name: integer(row[name]) for name in ("start", "end", "cn_child")}})
    return result


def validate_histories(tree: dict, profiles: dict, events: list[dict],
                       normal_name="diploid") -> dict:
    """Validate a canonical physical event history, not TSV row chronology.

    Reconstruct the source's LOH-first interval reductions directly from the
    parent/child profiles, match those primitive rows, then apply x2 WGD and
    remaining losses/gains. A passing check shows a compatible conditional
    minimum history exists. It does not identify the actual biological history
    or enumerate all equally parsimonious ancestral states/decompositions.
    """
    parent, lengths, root = tree["parent"], tree["lengths"], tree["root"]
    grouped = defaultdict(list)
    for row in events:
        if row["sample_id"] not in parent or row["sample_id"] == root:
            raise ValueError("Event identifies an absent branch or synthetic root")
        grouped[row["sample_id"]].append(row)
    report = {"all_valid": True, "branches": {}, "wgd_counts": {}}
    for child, ancestor in parent.items():
        if ancestor is None:
            continue
        source_ancestor = normal_name if ancestor == root and root not in profiles else ancestor
        source_child = normal_name if child == root and root not in profiles else child
        if source_ancestor not in profiles or source_child not in profiles:
            raise ValueError("Tree node has no matching ancestral profile")
        before, after = profiles[source_ancestor], profiles[source_child]
        keys = [(row["chrom"], row["start"], row["end"]) for row in before]
        if keys != [(row["chrom"], row["start"], row["end"]) for row in after]:
            raise ValueError("Parent/child segment order differs")
        branch_events = grouped[child]
        index_by_chrom = defaultdict(list)
        for index, key in enumerate(keys):
            index_by_chrom[key[0]].append(index)
        starts_by_chrom = {chrom: [keys[index][1] for index in indices]
                           for chrom, indices in index_by_chrom.items()}
        interval_cache = {}
        def affected_indices(chrom, start, end):
            key = (chrom, start, end)
            if key not in interval_cache:
                indices = index_by_chrom[chrom]
                starts = starts_by_chrom.get(chrom, [])
                left, right = bisect_left(starts, start), bisect_left(starts, end)
                interval_cache[key] = [index for index in indices[left:right] if keys[index][2] <= end]
            return interval_cache[key]
        flags = []
        if len(branch_events) != lengths[child]:
            flags.append("primitive_event_count_differs_from_MED_length")
        wgd_count = sum(row["type"] == "wgd" for row in branch_events)
        report["wgd_counts"][child] = wgd_count
        remaining = Counter((row["allele"], row["chrom"], row["start"], row["end"],
                             row["type"], row["cn_child"]) for row in branch_events if row["type"] != "wgd")
        reconstructed = {}
        for allele in ("cn_a", "cn_b"):
            current = [row[allele] for row in before]
            target = [row[allele] for row in after]
            maximum = max((p for p, c in zip(current, target) if p > 0 and c == 0), default=0)
            for height in range(maximum):
                active = [i for i, value in enumerate(current) if value != 0]
                groups, group = [], []
                for index in active:
                    negative = target[index] < current[index]
                    if group and (not negative or keys[index][0] != keys[group[-1]][0]):
                        groups.append(group)
                        group = []
                    if negative:
                        group.append(index)
                if group:
                    groups.append(group)
                for group in groups:
                    if not any(target[index] == 0 for index in group):
                        continue
                    loh_event = (allele, keys[group[0]][0], keys[group[0]][1],
                                 keys[group[-1]][2], "loss", maximum - height - 1)
                    if remaining[loh_event] < 1:
                        flags.append("canonical_LOH_primitive_row_missing")
                    else:
                        remaining[loh_event] -= 1
                    for index in group:
                        current[index] -= 1
            reconstructed[allele] = [value * (2 ** wgd_count) for value in current]
        for event, count in remaining.items():
            allele, chrom, start, end, kind, _ = event
            if not count:
                continue
            if allele not in reconstructed:
                flags.append("unexpected_event_allele")
                continue
            affected = affected_indices(chrom, start, end)
            if not affected:
                flags.append("event_overlaps_no_model_segment")
        # All remaining losses precede gains in the official minimum-distance
        # factorization. The event table itself is sorted and not a timeline.
        for kind, direction in (("loss", -1), ("gain", 1)):
            for event, count in remaining.items():
                allele, chrom, start, end, event_kind, _ = event
                if not count or event_kind != kind or allele not in reconstructed:
                    continue
                for index in affected_indices(chrom, start, end):
                    if reconstructed[allele][index] == 0:
                        continue  # physically absent DNA is ignored, never regained
                    reconstructed[allele][index] += direction * count
                    if reconstructed[allele][index] < 0:
                        flags.append("physical_negative_copy_number")
        if any(reconstructed[allele] != [row[allele] for row in after] for allele in reconstructed):
            flags.append("primitive_history_does_not_recreate_child_profile")
        flags = sorted(set(flags))
        report["branches"][child] = {"valid": not flags, "flags": flags,
            "MED_length": lengths[child], "primitive_events": len(branch_events),
            "wgd_events": wgd_count}
        report["all_valid"] = report["all_valid"] and not flags
    return report


def state_conversion(tree: dict, profiles: dict, history: dict, arms: list[dict],
                     block_chromosomes: dict[str, str], normal_name="diploid") -> dict:
    """Convert real ancestral profiles to arm states and conditional placements.

    Block coordinates remain the original BED coordinates; mapping changes only
    the chromosome identity. The caller pins each arm's reference intervals.
    """
    root, parent, lengths = tree["root"], tree["parent"], tree["lengths"]
    nodes = {}
    for node in parent:
        source_node = normal_name if node == root and node not in profiles else node
        if source_node not in profiles:
            raise ValueError("Missing model profile for state conversion")
        rows = []
        for row in profiles[source_node]:
            if row["chrom"] not in block_chromosomes:
                raise ValueError("Unmapped synthetic chromosome block")
            rows.append({**row, "chrom": block_chromosomes[row["chrom"]]})
        nodes[node] = {}
        for arm in arms:
            node_rows = [row for row in rows if row["chrom"] == arm["chrom"]]
            nodes[node][arm["id"]] = arm_loh_state(node_rows, arm["start"], arm["end"])
    placements = {}
    for arm in arms:
        state = {node: values[arm["id"]]["state"] for node, values in nodes.items()}
        placements[arm["id"]] = event_placement(state, parent, lengths)
    placements["WGD"] = wgd_placement(history["wgd_counts"], parent, lengths,
                                       history["all_valid"])
    return {"node_states": nodes, "placements": placements}
