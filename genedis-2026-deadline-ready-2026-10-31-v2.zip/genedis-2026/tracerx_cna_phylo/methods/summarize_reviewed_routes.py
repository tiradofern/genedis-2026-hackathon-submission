"""Aggregate categories only after an exact independently reviewed final screen."""
from collections import Counter
import json
from pathlib import Path

from .engine_output import sha256


def summarize():
    root = Path(__file__).resolve().parents[2]
    review_path = Path(__file__).with_name("route_screen_review.json")
    review = json.loads(review_path.read_text())
    if not review["passed"]:
        raise ValueError("Independent route review has not passed")
    cohorts = {}
    for histology in ("luad", "lusc"):
        path = root / f"tracerx_cna_phylo/routes/output/{histology}/summary.json"
        verified = review["cohorts"][histology]
        if verified["summary_sha256"] != sha256(path):
            raise ValueError("Final summary changed after its independent rederivation")
        summary = json.loads(path.read_text())
        if summary["status"] != "completed_reconstruction_screen" or not summary["chromosome_uncertainty_complete"]:
            raise ValueError("Final aggregate requires both histologies' complete uncertainty assessment")
        config = json.loads((root / f"configs/tracerx_cna_phylo_{histology}_v0_1.json").read_text())
        categories = {}
        for label in ("primary", "qualified"):
            roles = {}
            for role in ("training", "evaluation"):
                values = Counter()
                for pair in summary["pairs"]:
                    item = pair[role] if label == "primary" else pair["sensitivity_qualified"][role]
                    values.update(item["categories"])
                expected = summary["cohort"][role] * summary["pair_count"]
                if sum(values.values()) != expected:
                    raise ValueError("Category rollup changed a fixed patient-pair denominator")
                roles[role] = {"patient_pair_observations": expected,
                    "categories": dict(sorted(values.items())),
                    "strict_direction_observations": values["a_ancestor_b"] + values["b_ancestor_a"]}
            categories[label] = roles
        cohorts[histology] = {"summary_sha256": sha256(path), "patients": summary["patients"],
            "eligible_events": len(summary["eligible_events"]), "pairs": summary["pair_count"],
            "directions": summary["direction_count"], "BH_below_0_05": summary["directions_BH_below_0_05"],
            "actual_patient_bootstrap_seed": config["robustness"]["bootstrap_seed"],
            "patient_bootstrap_seed_config_field": "robustness.bootstrap_seed",
            "chromosome_bootstrap_base_seed": config["random_seed"],
            "patient_bootstrap_replicates": verified["patient_bootstrap_replicates"],
            "categories": categories}
    original = root / "tracerx_cna_phylo/methods/.runtime/pre_patient_bootstrap_seed_repair"
    original_categories = json.loads((original / "final_route_category_review.json").read_text())
    seed_repair = {}
    for histology in ("luad", "lusc"):
        old = original_categories["cohorts"][histology]
        current = cohorts[histology]
        for field in ("patients", "eligible_events", "pairs", "directions", "BH_below_0_05", "categories"):
            if old[field] != current[field]:
                raise ValueError("Patient seed correction changed an unrelated category/count/BH result")
        old_summary = json.loads((original / f"{histology}_summary.json").read_text())
        new_summary = json.loads((root / f"tracerx_cna_phylo/routes/output/{histology}/summary.json").read_text())
        if old_summary["pairs"] and len(old_summary["pairs"]) != len(new_summary["pairs"]):
            raise ValueError("A pair disappeared during the seed correction")
        changed = 0
        for before, after in zip(old_summary["pairs"], new_summary["pairs"]):
            if any(before[field] != after[field] for field in (
                    "events", "key", "training", "evaluation", "sensitivity_qualified")):
                raise ValueError("Seed correction changed route categories, P values or BH values")
            if before["patient_bootstrap"]["planned"] != after["patient_bootstrap"]["planned"]:
                raise ValueError("Patient bootstrap replicate count changed")
            changed += any(before["patient_bootstrap"][field] != after["patient_bootstrap"][field]
                           for field in ("forward_minus_reverse_positive", "negative", "ties",
                                         "forward_sign_frequency", "reverse_sign_frequency"))
        seed_repair[histology] = {"original_summary_sha256": sha256(original / f"{histology}_summary.json"),
            "original_executed_patient_seed": old["actual_patient_bootstrap_seed"],
            "corrected_patient_seed": current["actual_patient_bootstrap_seed"],
            "pairs_with_changed_descriptive_patient_bootstrap": changed,
            "all_primary_qualified_categories_P_and_BH_unchanged": True}
    return {"passed": True, "independent_route_review_sha256": sha256(review_path),
            "aggregation_code_sha256": sha256(Path(__file__)), "cohorts": cohorts,
            "patient_bootstrap_seed_correction": seed_repair,
            "seed_provenance": "The original screen used the general random_seed for patient bootstraps. The corrected screen and independent reviewer use the specific frozen robustness.bootstrap_seed (20261018 for both histologies). Chromosome resampling retains the unchanged general seed per histology. Original executed results and proof are preserved in the ignored pre-repair snapshot; no frozen file or CNA fit changed.",
            "interpretation": "Aggregation of independently rederived categories; observations reuse patients across pairs and are not independent patients; no biological validation"}


if __name__ == "__main__":
    report = summarize()
    Path(__file__).with_name("final_route_category_review.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(report, indent=2))
