"""Finite scientific safeguards using fictional node labels and CNA states."""
import json
from pathlib import Path
import tempfile
import unittest

from .contracts import (arm_loh_state, bh_adjust, consensus_category, event_placement,
                        exact_direction_p, pair_category, wgd_placement)
from .engine_output import project_profiles_to_atoms, read_newick, read_profiles, validate_histories
from .convert_outputs import convert_job
from .engine_output import sha256
from .review_route_screen import qualified


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.parent = {"N": None, "A": "N", "B": "A", "C": "A"}
        self.lengths = {"N": 0, "A": 2, "B": 1, "C": 3}

    def placement(self, **states):
        return event_placement({"N": False, "A": False, "B": False, "C": False, **states},
                               self.parent, self.lengths)

    def test_arm_missing_bounds_preserve_unknown_and_strict_half_tie(self):
        row = lambda left, right, a, b: {"start": left, "end": right, "cn_a": a, "cn_b": b}
        self.assertIsNone(arm_loh_state([row(0, 45, 1, 0), row(45, 80, 1, 1)], 0, 100)["state"])
        self.assertIs(arm_loh_state([row(0, 30, 1, 0), row(30, 80, 1, 1)], 0, 100)["state"], False)
        self.assertIs(arm_loh_state([row(0, 51, 1, 0), row(51, 90, 1, 1)], 0, 100)["state"], True)
        self.assertIs(arm_loh_state([row(0, 50, 1, 0), row(50, 100, 1, 1)], 0, 100)["state"], False)
        self.assertIsNone(arm_loh_state([row(0, 70, 1, 0)], 0, 100)["state"])

    def test_arm_overlap_and_fractional_copy_number_rejected(self):
        with self.assertRaises(ValueError):
            arm_loh_state([{"start": 0, "end": 100, "cn_a": 1.5, "cn_b": 0}], 0, 100)
        with self.assertRaises(ValueError):
            arm_loh_state([{"start": 0, "end": 75, "cn_a": 1, "cn_b": 1},
                           {"start": 50, "end": 100, "cn_a": 1, "cn_b": 0}], 0, 100)

    def test_same_branch_unordered_and_transitive_order(self):
        early = self.placement(A=True, B=True, C=True)
        late = self.placement(B=True)
        self.assertEqual(pair_category(early, early, self.parent, self.lengths), "same_branch_unordered")
        self.assertEqual(pair_category(early, late, self.parent, self.lengths), "a_ancestor_b")
        self.assertEqual(pair_category(late, early, self.parent, self.lengths), "b_ancestor_a")
        self.assertEqual(pair_category(late, self.placement(C=True), self.parent, self.lengths), "incomparable_branches")

    def test_repeated_reverted_missing_and_zero_events_never_become_strict(self):
        early = self.placement(A=True, B=True, C=True)
        self.assertEqual(pair_category(early, self.placement(B=True, C=True), self.parent, self.lengths), "repeated_event")
        self.assertEqual(pair_category(early, self.placement(A=True, B=True), self.parent, self.lengths), "state_reversion")
        self.assertEqual(pair_category(early, self.placement(B=None, C=None), self.parent, self.lengths), "assay_or_state_unknown")
        lengths = {**self.lengths, "B": 0}
        late = event_placement({"N": False, "A": False, "B": True, "C": False}, self.parent, lengths)
        self.assertEqual(pair_category(early, late, self.parent, lengths), "placement_unknown")

    def test_wgd_requires_valid_history_and_unique_acquisition(self):
        loh = self.placement(B=True)
        valid = wgd_placement({"A": 1}, self.parent, self.lengths, True)
        invalid = wgd_placement({"A": 1}, self.parent, self.lengths, False)
        self.assertEqual(pair_category(valid, loh, self.parent, self.lengths), "a_ancestor_b")
        self.assertIsNone(invalid["carrier"])
        self.assertTrue(invalid["reported_model_carrier"])
        self.assertEqual(pair_category(invalid, loh, self.parent, self.lengths), "assay_or_state_unknown")
        self.assertEqual(pair_category(wgd_placement({"A": 2}, self.parent, self.lengths, True), loh,
                                       self.parent, self.lengths), "repeated_event")

    def test_sensitivity_disagreement_is_not_majority_vote(self):
        self.assertEqual(consensus_category(["a_ancestor_b", "a_ancestor_b"]), "a_ancestor_b")
        self.assertEqual(consensus_category(["a_ancestor_b", "same_branch_unordered"]), "sensitivity_disagreement")

    def test_direction_test_and_all_direction_bh(self):
        self.assertEqual(exact_direction_p(0, 0), 1)
        self.assertEqual(exact_direction_p(4, 0), 1 / 16)
        self.assertEqual(exact_direction_p(0, 4), 1)
        adjusted = bh_adjust({"A->B": .01, "B->A": .9, "C->D": .03, "D->C": 1})
        self.assertAlmostEqual(adjusted["A->B"], .04)
        self.assertAlmostEqual(adjusted["C->D"], .06)

    def test_invalid_cycle_rejected(self):
        with self.assertRaises(ValueError):
            event_placement({"N": False, "A": True, "B": True},
                            {"N": None, "A": "B", "B": "A"}, {"A": 1, "B": 1})

    def test_real_output_grammar_and_noninteger_rejection(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Path(tmp) / "tree.new"
            tree.write_text("(diploid:0,(S1:1e0,'S 2':2)internal1:3):0;", encoding="utf-8")
            parsed = read_newick(tree)
            self.assertEqual(set(parsed["terminals"]), {"diploid", "S1", "S 2"})
            profiles = Path(tmp) / "profile.tsv"
            profiles.write_text("sample_id\tchrom\tstart\tend\tcn_a\tcn_b\nS1\tchr10001\t0\t100\t1.2\t0\n")
            with self.assertRaises(ValueError):
                read_profiles(profiles)

    def test_sorted_event_table_can_recreate_loh_before_true_doubling(self):
        rows = lambda a, b: [{"chrom": "chr10001", "start": 0, "end": 100, "cn_a": a, "cn_b": b}]
        tree = {"root": "N", "parent": {"N": None, "A": "N"}, "lengths": {"N": 0, "A": 2}}
        # The table has no chronological row order. Loss before WGD produces
        # (0,2); loss after WGD would need two losses, not this 2-event history.
        events = [{"sample_id": "A", "allele": "both", "chrom": "chr0", "start": 0,
                   "end": 100, "type": "wgd", "cn_child": 0},
                  {"sample_id": "A", "allele": "cn_a", "chrom": "chr10001", "start": 0,
                   "end": 100, "type": "loss", "cn_child": 0}]
        audit = validate_histories(tree, {"N": rows(1, 1), "A": rows(0, 2)}, events)
        self.assertTrue(audit["all_valid"])
        self.assertEqual(audit["wgd_counts"]["A"], 1)

    def test_corrupt_event_count_and_physically_impossible_regain_rejected(self):
        rows = lambda a, b: [{"chrom": "chr10001", "start": 0, "end": 100, "cn_a": a, "cn_b": b}]
        tree = {"root": "N", "parent": {"N": None, "A": "N"}, "lengths": {"N": 0, "A": 1}}
        event = {"sample_id": "A", "allele": "cn_a", "chrom": "chr10001", "start": 0,
                 "end": 100, "type": "gain", "cn_child": 1}
        audit = validate_histories(tree, {"N": rows(0, 1), "A": rows(1, 1)}, [event])
        self.assertFalse(audit["all_valid"])
        missing = validate_histories(tree, {"N": rows(1, 1), "A": rows(2, 1)}, [])
        self.assertFalse(missing["all_valid"])

    def test_coalesced_model_interval_never_makes_gap_measured(self):
        atoms = [{"pseudochrom": "chr10001", "start": 0, "end": 45, "observed_bp": 45},
                 {"pseudochrom": "chr10001", "start": 65, "end": 100, "observed_bp": 35}]
        profiles = {"A": [{"chrom": "chr10001", "start": 0, "end": 100, "cn_a": 1, "cn_b": 0}]}
        projected = project_profiles_to_atoms(profiles, atoms)
        state = arm_loh_state(projected["A"], 0, 100)
        self.assertEqual(state["measured_bases"], 80)
        self.assertEqual(state["missing_bases"], 20)
        broken = {"A": [{"chrom": "chr10001", "start": 0, "end": 99, "cn_a": 1, "cn_b": 0}]}
        with self.assertRaises(ValueError):
            project_profiles_to_atoms(broken, atoms)

    def test_complete_job_preserves_region_membership_hash_and_shared_unordered_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            input_path = folder / "input.tsv"
            input_path.write_text("sample_id\tchrom\tstart\tend\tcn_a\tcn_b\nS1\tchr10001\t0\t100\t1\t0\nS2\tchr10001\t0\t100\t1\t0\n")
            profiles = folder / "profiles.tsv"
            profiles.write_text(input_path.read_text() + "diploid\tchr10001\t0\t100\t1\t1\ninternal0\tchr10001\t0\t100\t1\t0\n")
            tree = folder / "tree.new"
            tree.write_text("(diploid:0,(S1:0,S2:0)internal0:1):0;")
            events = folder / "events.tsv"
            events.write_text("sample_id\tallele\tchrom\tstart\tend\ttype\tcn_child\ninternal0\tcn_b\tchr10001\t0\t100\tloss\t0\n")
            mapping = folder / "mapping.json"
            mapping.write_text(json.dumps({"atoms": [{"chrom": "1", "pseudochrom": "chr10001", "start": 0, "end": 100, "observed_bp": 100}]}))
            job = {"patient_id": "fictional", "histology": "luad", "role": "training",
                   "variant": "primary", "status": "success", "input_path": str(input_path),
                   "input_sha256": sha256(input_path), "mapping_path": str(mapping),
                   "paths": {"tree": str(tree), "profiles": str(profiles), "events": str(events)}}
            output = convert_job(job, [{"id": "1p", "chrom": "1", "start": 0, "end": 100}])
            self.assertEqual(output["regions"], ["S1", "S2"])
            self.assertEqual(output["events"]["LOH:1p"]["unique_branch"], "internal0")
            self.assertIs(output["events"]["WGD"]["carrier"], False)
            self.assertTrue(output["history_audit"]["all_valid"])
            job["input_sha256"] = "0" * 64
            with self.assertRaises(ValueError):
                convert_job(job, [{"id": "1p", "chrom": "1", "start": 0, "end": 100}])

    def test_overlap_loss_history_ignores_zero_locus_after_wgd(self):
        rows = lambda values: [{"chrom": "chr10001", "start": i * 100, "end": (i + 1) * 100,
                                 "cn_a": value, "cn_b": 1 if values[0] == 3 else 2}
                                for i, value in enumerate(values)]
        parent_rows, child_rows = rows([3, 3, 3]), rows([4, 0, 4])
        events = [{"sample_id": "A", "allele": "cn_a", "chrom": "chr10001", "start": 100,
                   "end": 200, "type": "loss", "cn_child": value} for value in (2, 1, 0)]
        events += [{"sample_id": "A", "allele": "cn_a", "chrom": "chr10001", "start": 0,
                    "end": 300, "type": "loss", "cn_child": value} for value in (4, 5)]
        events += [{"sample_id": "A", "allele": "both", "chrom": "chr0", "start": 0,
                    "end": 300, "type": "wgd", "cn_child": 0}]
        tree = {"root": "N", "parent": {"N": None, "A": "N"}, "lengths": {"N": 0, "A": 6}}
        self.assertTrue(validate_histories(tree, {"N": parent_rows, "A": child_rows}, events)["all_valid"])

    def test_independent_uncertainty_recount_keeps_twenty_planned_slots(self):
        parent = {"N": None, "A": "N", "B": "A"}
        forward = ({"status": "success", "parent": parent},
                   {"LOH:1p": (True, "A", set()), "LOH:2p": (True, "B", set())})
        failed = ({"status": "failed_engine"}, {})
        mains = [forward] * 4
        self.assertEqual(qualified(mains, [forward] * 16 + [failed] * 4,
                                   "LOH:1p", "LOH:2p"), "a_ancestor_b")
        self.assertEqual(qualified(mains, [forward] * 15 + [failed] * 5,
                                   "LOH:1p", "LOH:2p"), "chromosome_resampling_unresolved")
        same = (forward[0], {"LOH:1p": (True, "A", set()), "LOH:2p": (True, "A", set())})
        self.assertEqual(qualified([same] * 4, [failed] * 20,
                                   "LOH:1p", "LOH:2p"), "same_branch_unordered")
        self.assertEqual(qualified([same, *mains[:3]], [forward] * 20,
                                   "LOH:1p", "LOH:2p"), "sensitivity_disagreement")
        self.assertEqual(qualified([failed, *mains[:3]], [forward] * 20,
                                   "LOH:1p", "LOH:2p"), "sensitivity_unavailable")


if __name__ == "__main__":
    unittest.main()
