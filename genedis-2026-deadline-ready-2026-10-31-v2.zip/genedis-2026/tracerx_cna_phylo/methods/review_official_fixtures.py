"""Independently read actual official fixture outputs without re-running inference."""
from pathlib import Path
import json

from .engine_output import read_events, read_newick, read_profiles, sha256, validate_histories


def main():
    root = Path(__file__).resolve().parents[2]
    fixtures = []
    for name in ("shipped_default", "shipped_x2", "known_shared_wgd", "known_shared_loh", "explicit_cap"):
        directory = root / "tracerx_cna_phylo/runtime/output/smoke" / name
        paths = {"tree": directory / (name + "_final_tree.new"),
                 "profiles": directory / (name + "_final_cn_profiles.tsv"),
                 "events": directory / (name + "_copynumber_events_df.tsv")}
        tree = read_newick(paths["tree"])
        profiles, events = read_profiles(paths["profiles"]), read_events(paths["events"])
        audit = validate_histories(tree, profiles, events)
        if not audit["all_valid"]:
            raise ValueError(f"Official fixture {name} fails independent event history checks")
        wgd = sum(row["type"] == "wgd" for row in events)
        if name == "known_shared_wgd" and (wgd != 1 or len(events) != 4):
            raise ValueError("Known x2 WGD fixture lost the expected one-WGD/three-gain history")
        fixtures.append({"fixture": name, "all_branches_valid": True,
                         "branches_checked": len(audit["branches"]),
                         "minimum_event_count": len(events), "wgd_events": wgd,
                         "output_sha256": {key: sha256(path) for key, path in paths.items()}})
    report = {"official_source_commit": "04e9bfec8a9b8fb585a703c5a10d6ee62bec7b35",
              "reviewer": "Independent methods reader of actual official outputs",
              "passed": True, "fixtures_checked": len(fixtures), "fixtures": fixtures,
              "checks": ["Actual Newick and TSV schemas", "Explicit normal anchor and node profiles",
                         "Every branch primitive count equals its MED length",
                         "Canonical physical LOH/x2-WGD/loss/gain replay recreates child profiles",
                         "Known shared x2 WGD yields exactly one WGD and three gains"],
              "limit": "Fixture and transformation fidelity only; no validation of patient biology or uniqueness of histories"}
    destination = root / "tracerx_cna_phylo/methods/official_fixture_review.json"
    destination.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"passed": True, "fixtures_checked": len(fixtures),
                      "branches_checked": sum(item["branches_checked"] for item in fixtures)}))


if __name__ == "__main__":
    main()
