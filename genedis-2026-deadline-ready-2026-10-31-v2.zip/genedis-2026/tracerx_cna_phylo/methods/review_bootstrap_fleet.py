"""Final draw/cache audit plus full-input CNA-state audit; never reruns inference."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

from .engine_output import sha256
from .review_main_fleet import review as review_model_records

VARIANTS = {f"bootstrap_{index:03d}" for index in range(20)}
NONTERMINAL = {"planned", "pending", "running", "not_run"}
PARAMETERS = {"normal_name": "diploid", "prune_weight": 0, "alleles": ["cn_a", "cn_b"],
              "wgd_x2": True, "no_wgd": False, "total_cn": False, "maxcn": 8,
              "n_cores": 1, "ancestral_reconstruction": True, "reconstruct_events": True}


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def input_rows(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        return [(row["sample_id"], row["chrom"], int(row["start"]), int(row["end"]),
                 int(row["cn_a"]), int(row["cn_b"])) for row in reader]


def local_name(element):
    return element.tag.rsplit("}", 1)[-1]


def xml_topology(path):
    """Read meaningful saved order/names; ignore diagnostic NJ edge lengths.

    Provided topology lengths are not reconstructed event counts and can be
    negative. Only the root length is part of the conditional cache key.
    """
    document = ET.parse(path).getroot()
    phylogeny = next(element for element in document if local_name(element) == "phylogeny")
    clade = next(element for element in phylogeny if local_name(element) == "clade")
    def child_text(element, tag):
        return next((child.text for child in element if local_name(child) == tag), None)
    def node(element):
        return {"name": child_text(element, "name"),
                "children": [node(child) for child in element if local_name(child) == "clade"]}
    root_length = child_text(clade, "branch_length")
    return {"rooted": phylogeny.attrib.get("rooted") in {"true", "True", "1"},
            "root_branch_length": None if root_length is None else float(root_length),
            "ordered_root": node(clade)}


def contract_shape(node):
    return {"name": node["attributes"].get("name"),
            "children": [contract_shape(child) for child in node["children"]]}


def named_descendants(node):
    result = {}
    def visit(value, is_root=False):
        if value["children"]:
            leaves = set().union(*(visit(child) for child in value["children"]))
        else:
            if not value["name"]:
                raise ValueError("A diagnostic leaf has no sample identity")
            leaves = {value["name"]}
        name = value["name"] if value["name"] is not None else "__synthetic_root__"
        if name in result or (value["name"] is None and not is_root):
            raise ValueError("Diagnostic tree has absent or repeated internal identities")
        result[name] = sorted(leaves)
        return leaves
    visit(node, True)
    return result


def audit_draw(job, locked, patient, config, root):
    """Verify one actual draw, independent of canonical conversion and cache use."""
    index = int(job["variant"].removeprefix("bootstrap_"))
    if job.get("bootstrap_index") != index or not 0 <= index < 20:
        raise ValueError("Bootstrap slot identity changed")
    if (job["role"] != patient["role"] or job["histology"].lower() != patient["histology"].lower()
            or set(job["primary_regions"]) != set(patient["primary_regions"])):
        raise ValueError("A draw changes the patient's role, histology or required regions")
    if job["source_variant"] != "primary" or job["input_sha256"] != locked["sha256"]:
        raise ValueError("A chromosome draw does not use the frozen full primary input")
    if (sha256(root / job["input_path"]) != locked["sha256"] or
            sha256(root / job["mapping_path"]) != locked["mapping_sha256"]):
        raise ValueError("Full primary input or measured-atom mapping changed")
    if len(job.get("attempts", [])) != 1:
        raise ValueError("Every ready bootstrap slot must have exactly one attempt; no redraw after failure")
    if job["status"] in NONTERMINAL:
        raise ValueError("Final audit cannot count pending draws as completed uncertainty")
    if "bootstrap" not in job:
        if job["status"] == "success":
            raise ValueError("A successful draw lacks its seed/resample provenance")
        return {"status": job["status"], "draw_provenance_unavailable_after_failure": True}
    metadata = job["bootstrap"]
    seed = config["random_seed"]
    identity = f"{seed}|{job['histology']}|{job['patient_id']}|{index}"
    derived = int.from_bytes(hashlib.sha256(identity.encode()).digest()[:8], "big")
    if (metadata["replica"] != index or metadata["base_seed"] != seed
            or metadata["derived_seed"] != derived):
        raise ValueError("Draw seed differs from the frozen patient/replicate identity")
    mapping = read(root / locked["mapping_path"])
    block_chrom = {atom["pseudochrom"]: str(atom["chrom"]) for atom in mapping["atoms"]}
    chromosomes = sorted(set(block_chrom.values()), key=int)
    draws = np.random.default_rng(derived).choice(chromosomes, size=len(chromosomes), replace=True).tolist()
    if metadata["original_autosomes"] != chromosomes or metadata["autosome_draws"] != draws:
        raise ValueError("Recorded chromosome draws differ from independent seeded regeneration")
    resample = root / job["output_dir"] / "resampled_input.tsv"
    if sha256(resample) != metadata["resample_sha256"]:
        raise ValueError("Actual resampled data differ from the recorded draw hash")
    original = defaultdict(list)
    for row in input_rows(root / locked["input_path"]):
        original[row[1]].append(row)
    expected = Counter()
    for ordinal, chromosome in enumerate(draws):
        blocks = sorted((block for block, chrom in block_chrom.items() if chrom == chromosome),
                        key=lambda block: int(block.removeprefix("chr")))
        for block_number, block in enumerate(blocks):
            pseudo = f"chr{1000000 + ordinal * 10000 + block_number}"
            expected.update((sample, pseudo, left, right, a, b)
                            for sample, _, left, right, a, b in original[block])
    observed = Counter(input_rows(resample))
    if expected != observed:
        raise ValueError("An actual chromosome draw loses, changes or invents a source region/block/state")
    result = {"status": job["status"], "autosome_draws_checked": len(draws),
              "resampled_rows_checked": sum(observed.values()), "resample_sha256": sha256(resample)}
    if job["status"] != "success":
        return result
    output_dir = (root / job["output_dir"]).resolve()
    diagnostic_paths = job["diagnostic_paths"]
    for path in diagnostic_paths.values():
        (root / path).resolve().relative_to(output_dir / "resampled_topology")
        if not (root / path).is_file():
            raise ValueError("A draw lacks its own genuine diagnostic output")
    if "distances" in job["paths"] or job["fit"]["distance_status"] != "not_computed_fixed_topology":
        raise ValueError("Fixed-tree placeholder distances cannot be presented as computed distances")
    if job["diagnostic"]["wgd_model"] != "official_major_minor_x2":
        raise ValueError("Chromosome topology uses a different WGD model")
    diagnostic = xml_topology(root / diagnostic_paths["xml"])
    final = xml_topology(root / job["paths"]["xml"])
    if named_descendants(diagnostic["ordered_root"]) != named_descendants(final["ordered_root"]):
        raise ValueError("Full-input ancestors use a different named rooted topology from this draw")
    cache = job["conditional_refit_cache"]
    cached = read(root / cache["contract_path"])
    contract = cached["contract"]
    key = hashlib.sha256(json.dumps(contract, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    if key != cache["key"] or key != cached["key"]:
        raise ValueError("Conditional cache key does not reproduce its complete contract")
    if contract["parameters"] != PARAMETERS or contract["input_sha256"] != locked["sha256"]:
        raise ValueError("Cache changes the full assay or declared reconstruction parameters")
    if (contract["official_source_commit"] != "04e9bfec8a9b8fb585a703c5a10d6ee62bec7b35"
            or contract["fit_worker_sha256"] != job["attempts"][0]["worker_sha256"]
            or contract["runtime_manifest_sha256"] != sha256(root / "tracerx_cna_phylo/runtime/runtime_manifest.json")
            or contract["conditional_cache_sha256"] != sha256(root / "tracerx_cna_phylo/runtime/conditional_cache.py")):
        raise ValueError("Cache is not bound to the attempted wrapper and pinned runtime/source")
    topology = contract["ordered_topology"]
    if (diagnostic["ordered_root"] != contract_shape(topology["ordered_root"])
            or diagnostic["rooted"] != topology["rooted"]
            or diagnostic["root_branch_length"] != topology["root_branch_length"]):
        raise ValueError("Cache contract changes this draw's exact ordered named rooted topology")
    patient_output = root / "tracerx_cna_phylo/runtime/output" / job["histology"] / job["patient_id"]
    for name, path in job["paths"].items():
        (root / path).resolve().relative_to(patient_output.resolve())
        actual_hash = sha256(root / path)
        if actual_hash != job["output_hashes"][name] or actual_hash != cached["output_hashes"][name]:
            raise ValueError("Cache source or full-input artifact bytes differ")
    if cache["hit"]:
        source_status = patient_output / cache["source_variant"] / "job_status.json"
        source = read(source_status)
        if (source["status"] != "success" or source["paths"] != job["paths"] or
                source["output_hashes"] != job["output_hashes"] or
                source["conditional_refit_cache"]["key"] != cache["key"] or
                source["input_sha256"] != locked["sha256"]):
            raise ValueError("Cache reuse does not identify its exact successful source job/artifacts")
    result.update(cache_hit=cache["hit"],
                  diagnostic_tree_sha256=sha256(root / diagnostic_paths["tree"]),
                  cache_contract_sha256=sha256(root / cache["contract_path"]))
    return result


def verify_main_boundary(root):
    boundary_path = root / "tracerx_cna_phylo/methods/.runtime/main_conversion_boundary.json"
    boundary = read(boundary_path)
    public = read(root / "tracerx_cna_phylo/methods/main_conversion_boundary_review.json")
    if sha256(boundary_path) != public["ignored_boundary_sha256"]:
        raise ValueError("Main byte-boundary manifest changed")
    for name, expected in boundary["producer_sha256"].items():
        if sha256(root / "tracerx_cna_phylo/methods" / name) != expected:
            raise ValueError("A conversion producer changed; immutable main-audit reuse requires explicit re-audit")
    for entry in boundary["canonical_records"]:
        if sha256(root / entry["path"]) != entry["sha256"]:
            raise ValueError("An audited main canonical record changed during final conversion")
    if sha256(root / "tracerx_cna_phylo/methods/main_fleet_review.json") != boundary["main_audit_sha256"]:
        raise ValueError("The reused main audit changed")
    return len(boundary["canonical_records"])


def ordered_job_digest(jobs):
    values = sorted(jobs, key=lambda job: (job["patient_id"], job["variant"]))
    return hashlib.sha256(json.dumps(values, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def audit_producers(root):
    return {name: sha256(root / "tracerx_cna_phylo/methods" / name) for name in (
        "contracts.py", "engine_output.py", "convert_outputs.py", "review_main_fleet.py",
        "review_bootstrap_fleet.py")}


def save_scoped_boundary(root, snapshot, converted, histology, report_path):
    """Bind a completed histology audit for exact deep-model reuse at final audit."""
    document = read(snapshot)
    selected = [job for job in document["jobs"] if job["variant"] in VARIANTS
                and job["histology"].lower() == histology]
    report = read(report_path)
    if (not report["passed"] or report["selected_histologies"] != [histology]
            or report["final_snapshot_sha256"] != sha256(snapshot)):
        raise ValueError("Scoped audit is not bound to the completed checkpoint")
    entries = []
    for job in selected:
        path = converted / histology / job["patient_id"] / (job["variant"] + ".json")
        entries.append({"path": path.resolve().relative_to(root).as_posix(), "sha256": sha256(path)})
    boundary = {"histology": histology, "job_records_sha256": ordered_job_digest(selected),
                "audit_path": report_path.resolve().relative_to(root).as_posix(),
                "audit_sha256": sha256(report_path), "audit_producer_sha256": audit_producers(root),
                "canonical_records": entries}
    destination = root / f"tracerx_cna_phylo/methods/.runtime/{histology}_bootstrap_boundary.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(boundary, indent=2) + "\n", encoding="utf-8", newline="\n")
    return {"histology": histology, "audit_sha256": sha256(report_path),
            "ignored_boundary_sha256": sha256(destination), "records": len(entries)}


def reused_model_audit(root, jobs, histology):
    boundary_path = root / f"tracerx_cna_phylo/methods/.runtime/{histology}_bootstrap_boundary.json"
    if not boundary_path.is_file():
        return None
    boundary = read(boundary_path)
    selected = [job for job in jobs if job["histology"].lower() == histology]
    if (boundary["histology"] != histology or boundary["job_records_sha256"] != ordered_job_digest(selected)
            or boundary["audit_producer_sha256"] != audit_producers(root)):
        raise ValueError("Completed histology audit cannot be reused after its jobs or producers change")
    report_path = root / boundary["audit_path"]
    if sha256(report_path) != boundary["audit_sha256"]:
        raise ValueError("Completed histology audit bytes changed")
    for entry in boundary["canonical_records"]:
        if sha256(root / entry["path"]) != entry["sha256"]:
            raise ValueError("Completed histology canonical record changed")
    report = read(report_path)
    if not report["passed"] or len(selected) != len(boundary["canonical_records"]):
        raise ValueError("Completed histology audit has a different scope")
    return report["model_record_audit"], {"histology": histology,
        "canonical_records": len(selected), "audit_sha256": boundary["audit_sha256"],
        "ignored_boundary_sha256": sha256(boundary_path)}


def review(snapshot, converted, histology=None):
    root = Path(__file__).resolve().parents[2]
    main_unchanged = verify_main_boundary(root)
    document = read(snapshot)
    selected_histologies = {"luad", "lusc"} if histology is None else {histology.lower()}
    if not selected_histologies.issubset({"luad", "lusc"}):
        raise ValueError("Unknown histology selection")
    selected_document_jobs = [job for job in document["jobs"]
                              if job["histology"].lower() in selected_histologies]
    if any(job["status"] in NONTERMINAL for job in selected_document_jobs):
        raise ValueError("Final fleet snapshot still contains a nonterminal planned job")
    scope = {p["patient_id"]: p for p in read(root / "tracerx_cna_phylo/source/output/canonical_manifest.json")["patients"]}
    scope = {pid: patient for pid, patient in scope.items()
             if patient["histology"].lower() in selected_histologies}
    inputs = {(j["patient_id"], j["variant"]): j for j in read(root / "tracerx_cna_phylo/source/output/input_manifest.json")["jobs"]}
    configs = {cohort: read(root / f"configs/tracerx_cna_phylo_{cohort}_v0_1.json") for cohort in ("luad", "lusc")}
    jobs = [job for job in selected_document_jobs if job["variant"] in VARIANTS]
    if len(jobs) != len(scope) * 20 or {(j["patient_id"], j["variant"]) for j in jobs} != {
            (pid, variant) for pid in scope for variant in VARIANTS}:
        raise ValueError("Exactly all 20 distinct planned slots per original patient are required")
    counts, outcomes = defaultdict(Counter), []
    for job in jobs:
        result = audit_draw(job, inputs[(job["patient_id"], "primary")], scope[job["patient_id"]],
                            configs[job["histology"]], root)
        group = job["histology"]
        counts[group]["planned_slots"] += 1
        counts[group]["status:" + job["status"]] += 1
        counts[group]["genuine_seeded_draws_checked"] += "resample_sha256" in result
        counts[group]["resampled_rows_checked"] += result.get("resampled_rows_checked", 0)
        counts[group]["conditional_cache_hits"] += result.get("cache_hit") is True
        counts[group]["conditional_cache_misses"] += result.get("cache_hit") is False
        outcomes.append(result)
    # This existing raw-model audit now targets only the 20 bootstrap variants;
    # the exact unchanged main-byte boundary replaces re-deriving stable mains.
    reused, model_reports, new_histologies = [], [], set(selected_histologies)
    if histology is None:
        for group in sorted(selected_histologies):
            prior = reused_model_audit(root, jobs, group)
            if prior is not None:
                model_reports.append(prior[0])
                reused.append(prior[1])
                new_histologies.remove(group)
    if new_histologies:
        model_reports.append(review_model_records(snapshot, converted, variants=VARIANTS,
            histologies=new_histologies,
            review_scope="All 20 planned chromosome draws per selected patient; immutable main audit reused"))
    if len(model_reports) == 1:
        models = model_reports[0]
    else:
        models = {"passed": True, "unique_patients": sum(r["unique_patients"] for r in model_reports),
                  "reconstruction_records": sum(r["reconstruction_records"] for r in model_reports),
                  "groups": {k: v for r in model_reports for k, v in r["groups"].items()},
                  "history_flags": {k: v for r in model_reports for k, v in r["history_flags"].items()},
                  "component_audits": model_reports,
                  "interpretation": "Exact hash-bound completed histology model audit reused; current raw provenance rechecked for every draw"}
    return {"passed": True, "unique_patients": len(scope), "planned_bootstrap_slots": len(jobs),
            "unchanged_main_records_reused": main_unchanged, "draw_provenance": dict(counts),
            "draw_outcome_rollup_sha256": hashlib.sha256(json.dumps(outcomes, sort_keys=True,
                separators=(",", ":")).encode()).hexdigest(),
            "model_record_audit": models, "final_snapshot_sha256": sha256(snapshot),
            "selected_histologies": sorted(selected_histologies), "reused_model_audits": reused,
            "full_fleet_complete": histology is None,
            "interpretation": "All draws retain the fixed20 denominator; cache hits are not new patients or independent refits; no biological validation"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--converted", type=Path, default=Path("tracerx_cna_phylo/methods/output"))
    parser.add_argument("--histology", choices=("luad", "lusc"),
                        help="Audit one completed histology while the other continues; default requires both terminal")
    parser.add_argument("--smoke-current", action="store_true",
                        help="Read one completed cache hit and miss for development; no canonical writes or final-fleet claim")
    args = parser.parse_args()
    if args.smoke_current:
        root = Path(__file__).resolve().parents[2]
        blob = args.snapshot.read_bytes()
        document = json.loads(blob)
        scope = {p["patient_id"]: p for p in read(root / "tracerx_cna_phylo/source/output/canonical_manifest.json")["patients"]}
        locked = {(j["patient_id"], j["variant"]): j for j in read(root / "tracerx_cna_phylo/source/output/input_manifest.json")["jobs"]}
        jobs = [j for j in document["jobs"] if j["variant"] in VARIANTS and j["status"] == "success"]
        selected = [next(j for j in jobs if j["conditional_refit_cache"]["hit"] == hit) for hit in (False, True)]
        results = [audit_draw(job, locked[(job["patient_id"], "primary")], scope[job["patient_id"]],
                    read(root / f"configs/tracerx_cna_phylo_{job['histology']}_v0_1.json"), root) for job in selected]
        result = {"passed": True, "draws_checked": len(results),
                  "distinct_patients": len({j["patient_id"] for j in selected}),
                  "cache_hits_checked": 1, "cache_misses_checked": 1, "checks": results,
                  "source_job_document_sha256": hashlib.sha256(blob).hexdigest(),
                  "full_fleet_complete": False,
                  "interpretation": "Early genuine draw/cache provenance check only; no final chromosome uncertainty or biological validation claim"}
        Path(__file__).with_name("bootstrap_provenance_smoke_review.json").write_text(
            json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
        print(json.dumps({"passed": True, "draws_checked": len(results),
                          "cache_hits_checked": 1, "cache_misses_checked": 1}, indent=2))
        return
    result = review(args.snapshot, args.converted, histology=args.histology)
    report_name = f"bootstrap_{args.histology}_fleet_review.json" if args.histology else "bootstrap_fleet_review.json"
    report_path = Path(__file__).with_name(report_name)
    report_path.write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
    if args.histology:
        boundary = save_scoped_boundary(Path(__file__).resolve().parents[2], args.snapshot,
                                       args.converted, args.histology, report_path)
        print(json.dumps({"scoped_model_audit_boundary": boundary}), flush=True)
    print(json.dumps({"passed": True, "planned_bootstrap_slots": result["planned_bootstrap_slots"],
                      "unchanged_main_records_reused": result["unchanged_main_records_reused"],
                      "draw_provenance": result["draw_provenance"]}, indent=2))


if __name__ == "__main__":
    main()
