"""Convert hash-bound official CNA outputs to local patient evidence JSON.

Run from the checkout with ``python -m tracerx_cna_phylo.methods.convert_outputs
--jobs path/to/jobs.json --out path/to/ignored/output``. The job manifest is
patient-level data and must stay ignored; only aggregate checks belong in Git.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re

from .engine_output import (project_profiles_to_atoms, read_events, read_newick, read_profiles, sha256,
                            state_conversion, validate_histories)


def convert_job(job: dict, arms: list[dict]) -> dict:
    mandatory = {"patient_id", "histology", "role", "variant", "input_path", "input_sha256", "mapping_path", "status"}
    if not mandatory.issubset(job):
        raise ValueError(f"Engine job missing fields: {sorted(mandatory - job.keys())}")
    if job["histology"].upper() not in {"LUAD", "LUSC"} or job["role"] not in {"training", "evaluation"}:
        raise ValueError("Unknown histology or frozen patient role")
    result = {name: job[name] for name in ("patient_id", "histology", "role", "variant", "input_sha256")}
    result.update({"schema_version": "1.0", "status": job["status"],
        "interpretation": "Conditional CNA-only sampled-region reconstruction; not a joint SNV/CNA clone tree"})
    if "bootstrap_index" in job:
        result["bootstrap_index"] = job["bootstrap_index"]
    elif match := re.fullmatch(r"bootstrap_(\d+)", job["variant"]):
        result["bootstrap_index"] = int(match.group(1))
    if job["status"] != "success":
        result["failure_reason"] = job.get("failure_reason", "Engine reconstruction unavailable")
        return result
    if sha256(job["input_path"]) != job["input_sha256"]:
        raise ValueError("Engine input hash differs from frozen job")
    normal = job.get("normal_name", "diploid")
    mapping = json.loads(Path(job["mapping_path"]).read_text(encoding="utf-8-sig"))
    profiles = project_profiles_to_atoms(read_profiles(job["paths"]["profiles"], require_common_segments=False),
                                         mapping["atoms"])
    inputs = read_profiles(job["input_path"])
    if normal in inputs:
        raise ValueError("Artificial normal must not replace a required regional input")
    tree = read_newick(job["paths"]["tree"])
    if set(tree["terminals"]) != {*inputs, normal}:
        raise ValueError("Official tree does not preserve exactly the required regions and normal anchor")
    for name, input_rows in inputs.items():
        if profiles.get(name) != input_rows:
            raise ValueError("Official terminal copy-number profile differs from exact engine input")
    if normal not in profiles or any(row[allele] != 1 for row in profiles[normal]
                                    for allele in ("cn_a", "cn_b")):
        raise ValueError("Missing or non-diploid artificial normal profile")
    events = read_events(job["paths"]["events"])
    history = validate_histories(tree, profiles, events, normal)
    blocks = {}
    for atom in mapping["atoms"]:
        pseudo = atom["pseudochrom"]
        if pseudo in blocks and blocks[pseudo] != atom["chrom"]:
            raise ValueError("Continuity block maps to several reference chromosomes")
        blocks[pseudo] = atom["chrom"]
        if atom["observed_bp"] != atom["end"] - atom["start"]:
            raise ValueError("Input atom improperly bridges unmeasured bases")
    typed_arms = [{**arm, "id": "LOH:" + arm["id"].removeprefix("LOH:")} for arm in arms]
    converted = state_conversion(tree, profiles, history, typed_arms, blocks, normal)
    result.update({"parent": tree["parent"], "lengths": tree["lengths"], "root": tree["root"],
        "normal_name": normal, "regions": sorted(inputs), "events": converted["placements"],
        "arm_states": {arm["id"]: {node: values[arm["id"]] for node, values in converted["node_states"].items()}
                       for arm in typed_arms},
        "history_audit": history, "model_assumptions": {
            "allele_orientation": "Source major/minor ordering; phase unresolved",
            "wgd_operation": "Explicit x2 official model",
            "normal_anchor": "Artificial diploid",
            "minimum_history": "One deterministic minimum solution; alternatives not exhaustively enumerated",
            "within_branch_order": "Unresolved"},
        "source_artifacts": {"input": job["input_path"], "mapping": job["mapping_path"], **job["paths"]},
        "fingerprints": {"input_sha256": job["input_sha256"], "mapping_sha256": sha256(job["mapping_path"]),
            **{name + "_sha256": sha256(path) for name, path in job["paths"].items()}}})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jobs", required=True)
    parser.add_argument("--arms", default="tracerx_cna_phylo/source/hg19_arms.json")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    jobs = json.loads(Path(args.jobs).read_text(encoding="utf-8-sig"))
    jobs = jobs["jobs"] if isinstance(jobs, dict) else jobs
    arms = json.loads(Path(args.arms).read_text(encoding="utf-8-sig"))["arms"]
    summary = {"jobs": len(jobs), "success": 0, "unavailable": 0,
               "valid_histories": 0, "histories_with_flags": 0, "variants": {}}
    for job in jobs:
        result = convert_job(job, arms)
        destination = Path(args.out) / job["histology"].lower() / job["patient_id"] / (job["variant"] + ".json")
        destination.parent.mkdir(parents=True, exist_ok=True)
        pending = destination.with_suffix(destination.suffix + f".pending.{os.getpid()}")
        pending.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8", newline="\n")
        pending.replace(destination)
        success = result["status"] == "success"
        summary["success" if success else "unavailable"] += 1
        summary["variants"][job["variant"]] = summary["variants"].get(job["variant"], 0) + 1
        if success:
            summary["valid_histories" if result["history_audit"]["all_valid"] else "histories_with_flags"] += 1
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
