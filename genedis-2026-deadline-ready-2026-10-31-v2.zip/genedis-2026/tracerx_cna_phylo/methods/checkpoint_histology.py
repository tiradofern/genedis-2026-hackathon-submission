"""Convert and audit one terminal histology without changing the other cohort.

Notify the root coordinator before dispatching this sole-writer command. The raw
ledger is retained exactly. The derived analysis checkpoint explicitly defers
the other histology's bootstrap evidence, irrespective of its live fit progress.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

from .engine_output import sha256
from .review_bootstrap_fleet import NONTERMINAL, VARIANTS, verify_main_boundary

MAIN = {"primary", "highcopy_mask", "gap100k", "total_cn_topology"}


def atomic_bytes(path, blob):
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_suffix(path.suffix + f".pending.{os.getpid()}")
    pending.write_bytes(blob)
    pending.replace(path)


def encode(value):
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()


def checkpoint(jobs_path, converted, histology):
    root = Path(__file__).resolve().parents[2]
    verify_main_boundary(root)
    raw_blob = jobs_path.read_bytes()
    document = json.loads(raw_blob)
    if (document["config_freeze_sha256"] != sha256(root / "tracerx_cna_phylo/config_freeze_2026-10-18.json")
            or document["input_manifest_sha256"] != sha256(root / "tracerx_cna_phylo/source/output/input_manifest.json")):
        raise ValueError("Ledger is not bound to the effective configuration/input freeze")
    scope = json.loads((root / "tracerx_cna_phylo/source/output/canonical_manifest.json").read_text())["patients"]
    selected_patients = {p["patient_id"] for p in scope if p["histology"].lower() == histology}
    expected = {(pid, variant) for pid in selected_patients for variant in VARIANTS}
    selected = [job for job in document["jobs"] if job["variant"] in VARIANTS
                and job["histology"].lower() == histology]
    if (len(selected) != len(expected) or {(j["patient_id"], j["variant"]) for j in selected} != expected
            or any(j["status"] in NONTERMINAL for j in selected)):
        raise ValueError("Selected histology does not retain exactly all 20 terminal bootstrap slots")
    deferred = [job for job in document["jobs"] if job["variant"] in VARIANTS
                and job["histology"].lower() != histology]
    immutable = []
    for job in deferred:
        path = converted / job["histology"].lower() / job["patient_id"] / (job["variant"] + ".json")
        immutable.append({"path": path.resolve().relative_to(root).as_posix(), "sha256": sha256(path)})
    snapshots = root / "tracerx_cna_phylo/runtime/output/snapshots"
    raw_path = snapshots / f"{histology}_bootstrap_raw_ledger.json"
    analysis_path = snapshots / f"{histology}_bootstrap_analysis.json"
    convert_path = snapshots / f"{histology}_bootstrap_conversion_jobs.json"
    atomic_bytes(raw_path, raw_blob)
    checkpoint_document = {key: value for key, value in document.items() if key != "jobs"}
    checkpoint_document["jobs"] = [job for job in document["jobs"] if job["variant"] in MAIN
                                   or (job["variant"] in VARIANTS and job["histology"].lower() == histology)]
    checkpoint_document["analysis_checkpoint"] = {
        "completed_bootstrap_histology": histology,
        "raw_ledger_path": raw_path.relative_to(root).as_posix(), "raw_ledger_sha256": sha256(raw_path),
        "deferred_bootstrap_histologies": sorted({j["histology"].lower() for j in deferred}),
        "deferred_bootstrap_slots": len(deferred),
        "deferred_status_semantics": "Absent bootstrap slots are not_run in this analysis checkpoint because not yet converted/assessed; this is not the live engine queue status",
        "full_fleet_complete": False}
    atomic_bytes(analysis_path, encode(checkpoint_document))
    atomic_bytes(convert_path, encode({"jobs": selected,
        "source_raw_ledger_sha256": sha256(raw_path), "analysis_checkpoint_sha256": sha256(analysis_path)}))
    print(json.dumps({"stage": "atomic_scoped_snapshot", "histology": histology,
                      "bootstrap_records": len(selected), "deferred_slots": len(deferred),
                      "raw_ledger_sha256": sha256(raw_path),
                      "analysis_checkpoint_sha256": sha256(analysis_path)}), flush=True)
    subprocess.run([sys.executable, "-u", "-m", "tracerx_cna_phylo.methods.convert_outputs",
                    "--jobs", str(convert_path), "--out", str(converted)], cwd=root, check=True)
    verify_main_boundary(root)
    for entry in immutable:
        if sha256(root / entry["path"]) != entry["sha256"]:
            raise ValueError("Deferred histology canonical record changed")
    print(json.dumps({"stage": "scoped_conversion_complete_starting_read_only_audit"}), flush=True)
    subprocess.run([sys.executable, "-u", "-m", "tracerx_cna_phylo.methods.review_bootstrap_fleet",
                    "--snapshot", str(analysis_path), "--converted", str(converted),
                    "--histology", histology], cwd=root, check=True)
    audit_path = root / f"tracerx_cna_phylo/methods/bootstrap_{histology}_fleet_review.json"
    audit = json.loads(audit_path.read_text())
    if not audit["passed"] or audit["final_snapshot_sha256"] != sha256(analysis_path):
        raise ValueError("Scoped audit differs from the analysis snapshot")
    ignored = root / f"tracerx_cna_phylo/methods/.runtime/{histology}_deferred_conversion_boundary.json"
    atomic_bytes(ignored, encode({"deferred_canonical_records": immutable,
                                 "raw_ledger_sha256": sha256(raw_path)}))
    report = {"passed": True, "completed_histology": histology,
              "patients": len(selected_patients), "terminal_bootstrap_slots": len(selected),
              "deferred_bootstrap_slots": len(deferred), "unchanged_main_records": verify_main_boundary(root),
              "deferred_canonical_records_unchanged": len(immutable),
              "raw_ledger_sha256": sha256(raw_path), "analysis_checkpoint_sha256": sha256(analysis_path),
              "scoped_conversion_jobs_sha256": sha256(convert_path), "scoped_audit_sha256": sha256(audit_path),
              "deferred_byte_boundary_sha256": sha256(ignored), "controller_sha256": sha256(Path(__file__)),
              "deferred_status_semantics": checkpoint_document["analysis_checkpoint"]["deferred_status_semantics"],
              "full_fleet_complete": False,
              "interpretation": "Completed selected-histology computational fidelity audit; other histology remains pending analysis; no biological validation"}
    atomic_bytes(root / f"tracerx_cna_phylo/methods/{histology}_checkpoint_review.json", encode(report))
    print(json.dumps(report, indent=2), flush=True)


def main():
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--histology", choices=("luad", "lusc"), required=True)
    parser.add_argument("--jobs", type=Path, default=root / "tracerx_cna_phylo/runtime/output/job_manifest.json")
    parser.add_argument("--converted", type=Path, default=root / "tracerx_cna_phylo/methods/output")
    args = parser.parse_args()
    checkpoint(args.jobs, args.converted, args.histology)


if __name__ == "__main__":
    main()
