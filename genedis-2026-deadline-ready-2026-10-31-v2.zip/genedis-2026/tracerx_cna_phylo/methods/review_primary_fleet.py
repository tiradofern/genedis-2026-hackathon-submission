"""Read-only review of all primary conversions against locked regions and assays."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path

from .engine_output import read_profiles, sha256


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def review(snapshot, converted):
    root = Path(__file__).resolve().parents[2]
    canonical_path = root / "tracerx_cna_phylo/source/output/canonical_manifest.json"
    scope = {p["patient_id"]: p for p in read(canonical_path)["patients"]}
    inputs_path = root / "tracerx_cna_phylo/source/output/input_manifest.json"
    inputs = {(p["patient_id"], p["variant"]): p for p in read(inputs_path)["jobs"]}
    arms_path = root / "tracerx_cna_phylo/source/hg19_arms.json"
    arms = read(arms_path)["arms"]
    events = {"LOH:" + arm["id"] for arm in arms} | {"WGD"}
    jobs = [j for j in read(snapshot)["jobs"] if j["variant"] == "primary"]
    if len(jobs) != len(scope) or {j["patient_id"] for j in jobs} != set(scope):
        raise ValueError("Primary snapshot does not retain the exact frozen patient cohort")
    count = defaultdict(Counter)
    flags = defaultdict(Counter)
    status = defaultdict(Counter)
    for job in jobs:
        pid = job["patient_id"]
        patient, locked = scope[pid], inputs[(pid, "primary")]
        cohort = patient["histology"].lower()
        path = converted / cohort / pid / "primary.json"
        value = read(path)
        if (value["patient_id"] != pid or value["variant"] != "primary" or
                value["role"] != patient["role"] or value["histology"].lower() != cohort or
                value["status"] != job["status"]):
            raise ValueError("Converted patient identity/role/status differs from the exact snapshot")
        if value["input_sha256"] != locked["sha256"] or sha256(root / locked["input_path"]) != locked["sha256"]:
            raise ValueError("Primary assay differs from its frozen source-derived input")
        status[cohort][value["status"]] += 1
        count[cohort]["patients"] += 1
        count[cohort][patient["role"] + "_patients"] += 1
        if value["status"] != "success":
            continue
        if set(value["events"]) != events or set(value["regions"]) != set(patient["primary_regions"]):
            raise ValueError("A success dropped an event or a required primary region")
        count[cohort]["required_regions_preserved"] += len(value["regions"])
        count[cohort]["all_45_event_records_preserved"] += 1
        count[cohort]["branches_checked"] += len(value["history_audit"]["branches"])
        count[cohort]["valid_primitive_histories"] += value["history_audit"]["all_valid"]
        for branch in value["history_audit"]["branches"].values():
            flags[cohort].update(branch["flags"])
        wgd = value["events"]["WGD"]
        count[cohort]["WGD_known_present"] += wgd["carrier"] is True
        count[cohort]["WGD_known_absent"] += wgd["carrier"] is False
        count[cohort]["WGD_unknown"] += wgd["carrier"] is None
        # Independently calculate terminal arm-state lower/upper bounds from
        # exact measured input intervals, without calling arm_loh_state().
        profiles = read_profiles(root / locked["input_path"])
        mapping = read(root / locked["mapping_path"])
        blocks = {atom["pseudochrom"]: atom["chrom"] for atom in mapping["atoms"]}
        for region, rows in profiles.items():
            for arm in arms:
                measured = loh = 0
                for row in rows:
                    if blocks[row["chrom"]] != arm["chrom"]:
                        continue
                    width = max(0, min(arm["end"], row["end"]) - max(arm["start"], row["start"]))
                    measured += width
                    loh += width * (min(row["cn_a"], row["cn_b"]) == 0)
                size = arm["end"] - arm["start"]
                missing = size - measured
                state = None
                if measured * 5 >= size * 4:
                    if loh * 2 > size:
                        state = True
                    elif (loh + missing) * 2 <= size:
                        state = False
                actual = value["arm_states"]["LOH:" + arm["id"]][region]
                if (actual["state"] is not state or actual["measured_bases"] != measured or
                        actual["missing_bases"] != missing or actual["loh_bases"] != loh):
                    raise ValueError("Terminal arm state or missing-data bound differs from exact measured source intervals")
                count[cohort]["terminal_arm_state_bounds_checked"] += 1
    return {"review_scope": "All frozen primary patient conversions; uncertainty stages remain separate",
            "passed": True, "patients_reviewed": len(jobs), "cohorts": dict(count),
            "history_flags": dict(flags), "statuses": dict(status),
            "source_fingerprints": {"job_snapshot_sha256": sha256(snapshot),
                "canonical_manifest_sha256": sha256(canonical_path),
                "input_manifest_sha256": sha256(inputs_path), "arms_sha256": sha256(arms_path)},
            "checks": ["Exact all-patient cohort and locked roles",
                       "Every required primary region and all 45 typed states retained",
                       "Actual primary input hashes match frozen source-derived variants",
                       "Independent terminal LOH/missing-base bound calculation from exact source intervals",
                       "All physical history flags and unknown WGD states retained"],
            "limit": "Computational source fidelity only; no validation of biological ancestry or uniqueness"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--converted", type=Path, default=Path("tracerx_cna_phylo/methods/output"))
    args = parser.parse_args()
    result = review(args.snapshot, args.converted)
    path = Path(__file__).with_name("primary_fleet_review.json")
    path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
