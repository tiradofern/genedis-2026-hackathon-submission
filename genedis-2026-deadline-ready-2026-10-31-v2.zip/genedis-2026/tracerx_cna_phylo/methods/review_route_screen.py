"""Independent arithmetic/category review of actual primary CNA route summaries."""
from __future__ import annotations

import argparse
from collections import Counter
from itertools import combinations
import json
from pathlib import Path

import numpy as np
from scipy.stats import binom

from .engine_output import sha256


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def derive(record, event):
    if record["status"] != "success":
        return None, None, {"unavailable"}
    if event == "WGD":
        history = record["history_audit"]
        if not history["all_valid"]:
            return None, None, {"history_unavailable"}
        counts = history["wgd_counts"]
        number = sum(counts.values())
        node = next((node for node, n in counts.items() if n), None)
        flags = {"repeat"} if number > 1 else set()
        if node is not None and record["lengths"][node] == 0:
            flags.add("unknown")
        return bool(number), node, flags
    states = {node: value["state"] for node, value in record["arm_states"][event].items()}
    terminal_states = [states[node] for node in record["regions"]]
    presence = True if any(state is True for state in terminal_states) else (
        False if all(state is False for state in terminal_states) else None)
    acquired, reverted, flags = [], [], set()
    if states[record["root"]] is not False:
        flags.add("unknown")
    for node, parent in record["parent"].items():
        if parent is None:
            continue
        before, after = states[parent], states[node]
        if before is None or after is None:
            flags.add("unknown")
        elif not before and after:
            acquired.append(node)
            if record["lengths"][node] == 0:
                flags.add("unknown")
        elif before and not after:
            reverted.append(node)
    if len(acquired) > 1:
        flags.add("repeat")
    if reverted:
        flags.add("revert")
    return presence, acquired[0] if len(acquired) == 1 else None, flags


def category(record, a, b, derived=None):
    if record["status"] != "success":
        return "reconstruction_unavailable"
    first, second = (derived[a], derived[b]) if derived is not None else (derive(record, a), derive(record, b))
    if first[0] is None or second[0] is None:
        return "assay_or_state_unknown"
    if first[0] is False or second[0] is False:
        return "not_co_carrier"
    flags = first[2] | second[2]
    if "repeat" in flags:
        return "repeated_event"
    if "revert" in flags:
        return "state_reversion"
    if flags or first[1] is None or second[1] is None:
        return "placement_unknown"
    if first[1] == second[1]:
        return "same_branch_unordered"
    def ancestors(node):
        result = set()
        while record["parent"][node] is not None:
            node = record["parent"][node]
            result.add(node)
        return result
    if first[1] in ancestors(second[1]):
        return "a_ancestor_b"
    if second[1] in ancestors(first[1]):
        return "b_ancestor_a"
    return "incomparable_branches"


def compact_record(path, events):
    """Derive independent states once, then discard large node-arm dictionaries."""
    value = read(path) if path.is_file() else {"status": "not_run"}
    states = {event: derive(value, event) for event in events}
    compact = {"status": value["status"]}
    if value["status"] == "success":
        compact["parent"] = value["parent"]
    return compact, states


def qualified(main, bootstraps, a, b):
    """Independent four-variant consensus and fixed 16-of-20 qualification."""
    if any(record["status"] != "success" for record, _ in main):
        return "sensitivity_unavailable"
    labels = [category(record, a, b, states) for record, states in main]
    if len(set(labels)) != 1:
        return "sensitivity_disagreement"
    agreed = labels[0]
    if agreed not in {"a_ancestor_b", "b_ancestor_a"}:
        return agreed
    if len(bootstraps) != 20:
        raise ValueError("All 20 planned chromosome slots must remain in the denominator")
    matches = sum(category(record, a, b, states) == agreed for record, states in bootstraps)
    return agreed if matches >= 16 else "chromosome_resampling_unresolved"


def review(summary_root, converted):
    root = Path(__file__).resolve().parents[2]
    scope = read(root / "tracerx_cna_phylo/source/output/canonical_manifest.json")["patients"]
    reports = {}
    for cohort in ("luad", "lusc"):
        patients = [p for p in scope if p["histology"].lower() == cohort]
        config = read(root / f"configs/tracerx_cna_phylo_{cohort}_v0_1.json")
        summary_path = summary_root / cohort / "summary.json"
        summary = read(summary_path)
        main, chromosome = {}, {}
        for patient in patients:
            pid = patient["patient_id"]
            folder = converted / cohort / pid
            main[pid] = [compact_record(folder / (variant + ".json"), summary["event_catalogue"])
                         for variant in ("primary", "highcopy_mask", "gap100k", "total_cn_topology")]
            chromosome[pid] = [compact_record(folder / f"bootstrap_{index:03d}.json", summary["event_catalogue"])
                               for index in range(20)]
        records = {pid: values[0][0] for pid, values in main.items()}
        derived = {pid: values[0][1] for pid, values in main.items()}
        training = [p for p in patients if p["role"] == "training"]
        eligible = []
        for event in summary["event_catalogue"]:
            counts = Counter(derived[p["patient_id"]][event][0] for p in training)
            gate = summary["event_gate"][event]
            passed = counts[True] >= 10 and counts[False] >= 10
            if (gate["training_carriers"] != counts[True] or gate["training_known_noncarriers"] != counts[False]
                    or gate["training_unknown"] != counts[None] or gate["eligible"] != passed):
                raise ValueError("Actual training frequency gate differs from independently derived source states")
            if passed:
                eligible.append(event)
        if eligible != summary["eligible_events"]:
            raise ValueError("Actual eligible event inventory differs")
        pairs = list(combinations(eligible, 2))
        pairs = [(a, b) for a, b in pairs if "WGD" in (a, b) or a.split(":")[1][:-1] != b.split(":")[1][:-1]]
        if len(pairs) != summary["pair_count"] or 2 * len(pairs) != summary["direction_count"]:
            raise ValueError("Multiplicity family omitted an eligible direction or included same-chromosome arms")
        patient_seed = config["robustness"]["bootstrap_seed"]
        weights = np.random.default_rng(patient_seed).multinomial(
            len(training), np.repeat(1 / len(training), len(training)), size=1000)
        actual_pairs = {tuple(pair["events"]): pair for pair in summary["pairs"]}
        pvalues, keys = [], []
        votes_checked = 0
        for a, b in pairs:
            actual = actual_pairs[(a, b)]
            categories = {p["patient_id"]: category(records[p["patient_id"]], a, b,
                                                   derived[p["patient_id"]]) for p in patients}
            qualified_categories = {p["patient_id"]: qualified(main[p["patient_id"]],
                                       chromosome[p["patient_id"]], a, b) for p in patients}
            for role in ("training", "evaluation"):
                counts = Counter(categories[p["patient_id"]] for p in patients if p["role"] == role)
                if dict(counts) != actual[role]["categories"]:
                    raise ValueError("Actual pair category denominators differ from independent node-state ancestry")
                forward, reverse = counts["a_ancestor_b"], counts["b_ancestor_a"]
                if (forward, reverse) != (actual[role]["forward"], actual[role]["reverse"]):
                    raise ValueError("Actual directional patient counts differ")
                for label, successes in (("forward", forward), ("reverse", reverse)):
                    probability = float(binom.sf(successes - 1, forward + reverse, .5))
                    if abs(probability - actual[role][label + "_p"]) > 1e-13:
                        raise ValueError("Directional P value differs from independent SciPy exact binomial calculation")
                    if role == "training":
                        keys.append((a, b, label))
                        pvalues.append(probability)
                votes_checked += sum(counts.values())
                robust = Counter(qualified_categories[p["patient_id"]] for p in patients if p["role"] == role)
                actual_robust = actual["sensitivity_qualified"][role]
                if (dict(robust) != actual_robust["categories"] or
                        robust["a_ancestor_b"] != actual_robust["forward"] or
                        robust["b_ancestor_a"] != actual_robust["reverse"]):
                    raise ValueError("Qualified categories differ from independent four-variant and fixed 16-of-20 chromosome logic")
            votes = np.array([{"a_ancestor_b": 1, "b_ancestor_a": -1}.get(categories[p["patient_id"]], 0)
                              for p in training])
            signs = weights @ votes
            boot = actual["patient_bootstrap"]
            if (int(sum(signs > 0)), int(sum(signs < 0)), int(sum(signs == 0))) != (
                    boot["forward_minus_reverse_positive"], boot["negative"], boot["ties"]):
                raise ValueError("Patient-bootstrap sign/tie frequencies differ")
        # Independent BH implementation: sorted rank adjustment and reverse
        # cumulative minimum, rather than the inference module's dictionary loop.
        if pvalues:
            values = np.array(pvalues)
            order = np.argsort(values, kind="stable")
            ranked = values[order] * len(values) / np.arange(1, len(values) + 1)
            qvalues = np.minimum(1, np.minimum.accumulate(ranked[::-1])[::-1])
            for index, q in zip(order, qvalues):
                a, b, label = keys[index]
                if abs(actual_pairs[(a, b)]["training"][label + "_BH_q"] - q) > 1e-13:
                    raise ValueError("BH-adjusted P values differ for the complete directional family")
        reports[cohort] = {"patients": len(patients), "event_gates_checked": len(summary["event_catalogue"]),
            "eligible_events": len(eligible), "pairs_checked": len(pairs), "directions_checked": len(pvalues),
            "patient_pair_categories_checked": votes_checked, "patient_bootstrap_replicates": 1000,
            "patient_bootstrap_seed": patient_seed,
            "patient_bootstrap_seed_config_field": "robustness.bootstrap_seed",
            "chromosome_bootstrap_base_seed": config["random_seed"],
            "qualified_patient_pair_categories_checked": votes_checked,
            "planned_chromosome_slots_per_patient": 20, "matching_strict_direction_required": 16,
            "chromosome_slot_statuses": dict(Counter(record["status"] for slots in chromosome.values()
                                                      for record, _ in slots)),
            "summary_sha256": sha256(summary_path)}
    return {"passed": True, "reviewer": "Independent state/ancestry/count/arithmetic implementation",
            "cohorts": reports, "interpretation": "Model-output fidelity only; no biological validation"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--summary-root", type=Path, default=Path("tracerx_cna_phylo/routes/output"))
    parser.add_argument("--converted", type=Path, default=Path("tracerx_cna_phylo/methods/output"))
    args = parser.parse_args()
    report = review(args.summary_root, args.converted)
    Path(__file__).with_name("route_screen_review.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
