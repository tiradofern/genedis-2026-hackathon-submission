"""Audit every actual main-variant node state and retained history flag."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path

from .engine_output import project_profiles_to_atoms, read_events, read_newick, read_profiles, sha256

VARIANTS = {"primary", "highcopy_mask", "gap100k", "total_cn_topology"}


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def review(snapshot, converted, variants=None, review_scope=None, histologies=None):
    variants = VARIANTS if variants is None else set(variants)
    root = Path(__file__).resolve().parents[2]
    scope_path = root / "tracerx_cna_phylo/source/output/canonical_manifest.json"
    scope = {p["patient_id"]: p for p in read(scope_path)["patients"]}
    if histologies is not None:
        selected = {value.lower() for value in histologies}
        if not selected or not selected.issubset({"luad", "lusc"}):
            raise ValueError("Unknown or empty histology selection")
        scope = {pid: patient for pid, patient in scope.items()
                 if patient["histology"].lower() in selected}
    inputs_path = root / "tracerx_cna_phylo/source/output/input_manifest.json"
    locked_inputs = {(j["patient_id"], j["variant"]): j for j in read(inputs_path)["jobs"]}
    arms_path = root / "tracerx_cna_phylo/source/hg19_arms.json"
    arms = read(arms_path)["arms"]
    expected_events = {"LOH:" + arm["id"] for arm in arms} | {"WGD"}
    jobs = [j for j in read(snapshot)["jobs"] if j["variant"] in variants and j["patient_id"] in scope]
    expected = {(pid, variant) for pid in scope for variant in variants}
    if {(j["patient_id"], j["variant"]) for j in jobs} != expected or len(jobs) != len(expected):
        raise ValueError("Snapshot drops or duplicates a frozen main reconstruction")
    if any(j["status"] in {"planned", "pending", "running", "not_run"} for j in jobs):
        raise ValueError("Main-variant audit requires a terminal snapshot")
    groups = defaultdict(Counter)
    flags = defaultdict(Counter)
    for job in jobs:
        pid, variant = job["patient_id"], job["variant"]
        patient = scope[pid]
        cohort = patient["histology"].lower()
        group = cohort + "/" + variant
        source_variant = variant if variant in {"primary", "highcopy_mask", "gap100k"} else "primary"
        locked = locked_inputs[(pid, source_variant)]
        value = read(converted / cohort / pid / (variant + ".json"))
        if (value["patient_id"] != pid or value["variant"] != variant or
                value["role"] != patient["role"] or value["histology"].lower() != cohort or
                value["status"] != job["status"]):
            raise ValueError("Converted identity, role or terminal status differs from the stable snapshot")
        if value["input_sha256"] != locked["sha256"] or sha256(root / locked["input_path"]) != locked["sha256"]:
            raise ValueError("Reconstruction assay differs from its frozen source variant")
        groups[group]["reconstruction_records"] += 1
        groups[group]["status:" + value["status"]] += 1
        groups[group]["role:" + patient["role"]] += 1
        if value["status"] != "success":
            continue
        if set(value["events"]) != expected_events or set(value["regions"]) != set(patient["primary_regions"]):
            raise ValueError("A success drops an event or required primary region")
        groups[group]["all_45_states_preserved"] += 1
        groups[group]["regions_preserved"] += len(value["regions"])
        if (value["fingerprints"]["mapping_sha256"] != locked["mapping_sha256"] or
                sha256(root / locked["mapping_path"]) != locked["mapping_sha256"]):
            raise ValueError("Ancestral states use different measured genomic atoms")
        for name, path in job["paths"].items():
            if value["fingerprints"][name + "_sha256"] != sha256(root / path):
                raise ValueError("Official output differs from converted source fingerprint")
        actual_tree = read_newick(root / job["paths"]["tree"])
        if actual_tree["parent"] != value["parent"] or actual_tree["lengths"] != value["lengths"]:
            raise ValueError("Converted parent relations or event lengths differ from the actual official tree")
        mapping = read(root / locked["mapping_path"])
        blocks = {atom["pseudochrom"]: atom["chrom"] for atom in mapping["atoms"]}
        profiles = project_profiles_to_atoms(read_profiles(root / job["paths"]["profiles"],
                    require_common_segments=False), mapping["atoms"])
        # Independently derive all ancestral and terminal arm bounds from actual
        # model allele states intersected with exact measured input atoms.
        for node in value["parent"]:
            profile_node = value["normal_name"] if node == value["root"] and node not in profiles else node
            by_chrom = defaultdict(list)
            for row in profiles[profile_node]:
                by_chrom[blocks[row["chrom"]]].append(row)
            for arm in arms:
                measured = loh = 0
                for row in by_chrom[arm["chrom"]]:
                    width = max(0, min(arm["end"], row["end"]) - max(arm["start"], row["start"]))
                    measured += width
                    loh += width * (min(row["cn_a"], row["cn_b"]) == 0)
                size = arm["end"] - arm["start"]
                missing, state = size - measured, None
                if measured * 5 >= size * 4:
                    if loh * 2 > size:
                        state = True
                    elif (loh + missing) * 2 <= size:
                        state = False
                actual = value["arm_states"]["LOH:" + arm["id"]][node]
                if (actual["state"] is not state or actual["measured_bases"] != measured or
                        actual["missing_bases"] != missing or actual["loh_bases"] != loh):
                    raise ValueError("Node arm state/missing-data bound differs from actual model/source intervals")
                groups[group]["node_arm_state_bounds_checked"] += 1
        events = read_events(root / job["paths"]["events"])
        branch_counts = Counter(row["sample_id"] for row in events)
        wgd_counts = Counter(row["sample_id"] for row in events if row["type"] == "wgd")
        for node, audit in value["history_audit"]["branches"].items():
            if audit["primitive_events"] != branch_counts[node] or audit["MED_length"] != value["lengths"][node]:
                raise ValueError("Primitive history count differs from the actual sorted event table/tree")
            mismatch = branch_counts[node] != value["lengths"][node]
            if mismatch != ("primitive_event_count_differs_from_MED_length" in audit["flags"]):
                raise ValueError("An actual primitive-count mismatch was hidden or invented")
            flags[group].update(audit["flags"])
            if value["history_audit"]["wgd_counts"][node] != wgd_counts[node]:
                raise ValueError("Reconstructed WGD counts differ from actual event rows")
            groups[group]["branches_checked"] += 1
        valid = value["history_audit"]["all_valid"]
        wgd = value["events"]["WGD"]
        if not valid and wgd["carrier"] is not None:
            raise ValueError("Invalid event history supplied a known WGD state")
        if valid and wgd["carrier"] is not bool(sum(wgd_counts.values())):
            raise ValueError("Known WGD state differs from validated actual event rows")
        groups[group]["valid_primitive_histories"] += valid
        groups[group]["WGD_known_present"] += wgd["carrier"] is True
        groups[group]["WGD_known_absent"] += wgd["carrier"] is False
        groups[group]["WGD_unknown"] += wgd["carrier"] is None
    return {"passed": True, "review_scope": review_scope or "All four main variants; chromosome resampling remains separate",
            "unique_patients": len(scope), "reconstruction_records": len(jobs),
            "groups": dict(groups), "history_flags": dict(flags),
            "source_fingerprints": {"snapshot_sha256": sha256(snapshot),
                "canonical_manifest_sha256": sha256(scope_path),
                "input_manifest_sha256": sha256(inputs_path), "arms_sha256": sha256(arms_path)},
            "interpretation": "Repeated reconstructions are not independent patients; fidelity checks do not establish biological truth or unique histories"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--converted", type=Path, default=Path("tracerx_cna_phylo/methods/output"))
    args = parser.parse_args()
    result = review(args.snapshot, args.converted)
    Path(__file__).with_name("main_fleet_review.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
