"""Fingerprint the already-audited immutable main conversions; no canonical writes."""
from pathlib import Path
import hashlib
import json

from .engine_output import sha256


def prepare():
    root = Path(__file__).resolve().parents[2]
    snapshot = root / "tracerx_cna_phylo/runtime/output/snapshots/main_sensitivity_fleet.json"
    audit_path = root / "tracerx_cna_phylo/methods/main_fleet_review.json"
    audit = json.loads(audit_path.read_text())
    if not audit["passed"] or audit["source_fingerprints"]["snapshot_sha256"] != sha256(snapshot):
        raise ValueError("Main audit is not bound to the stable main snapshot")
    document = json.loads(snapshot.read_text())
    main = {"primary", "highcopy_mask", "gap100k", "total_cn_topology"}
    entries = []
    for job in document["jobs"]:
        if job["variant"] not in main:
            continue
        path = root / "tracerx_cna_phylo/methods/output" / job["histology"].lower() / job["patient_id"] / (job["variant"] + ".json")
        value = json.loads(path.read_text())
        if (value["status"] != job["status"] or value["input_sha256"] != job["input_sha256"] or
                value["role"] != job["role"] or value["variant"] != job["variant"]):
            raise ValueError("Main canonical record differs from the audited snapshot")
        entries.append({"path": path.relative_to(root).as_posix(), "sha256": sha256(path)})
    if len(entries) != 1368:
        raise ValueError("Expected exactly 342 patients times four main records")
    entries.sort(key=lambda entry: entry["path"])
    rolled = hashlib.sha256(json.dumps(entries, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    producers = {name: sha256(root / "tracerx_cna_phylo/methods" / name)
                 for name in ("contracts.py", "engine_output.py", "convert_outputs.py")}
    boundary = {"main_snapshot_sha256": sha256(snapshot), "main_audit_sha256": sha256(audit_path),
                "canonical_records": entries, "canonical_record_rollup_sha256": rolled,
                "producer_sha256": producers}
    ignored = root / "tracerx_cna_phylo/methods/.runtime/main_conversion_boundary.json"
    ignored.parent.mkdir(parents=True, exist_ok=True)
    ignored.write_text(json.dumps(boundary, indent=2) + "\n", encoding="utf-8", newline="\n")
    public = {"passed": True, "main_records_fingerprinted": len(entries),
              "main_snapshot_sha256": sha256(snapshot), "main_audit_sha256": sha256(audit_path),
              "ignored_boundary_sha256": sha256(ignored), "canonical_record_rollup_sha256": rolled,
              "producer_sha256": producers,
              "interpretation": "Exact byte boundary of previously audited main records; no additional patients or biological validation"}
    (root / "tracerx_cna_phylo/methods/main_conversion_boundary_review.json").write_text(
        json.dumps(public, indent=2) + "\n", encoding="utf-8", newline="\n")
    return {"passed": True, "main_records_fingerprinted": len(entries), "rollup_sha256": rolled}


if __name__ == "__main__":
    print(json.dumps(prepare(), indent=2))
