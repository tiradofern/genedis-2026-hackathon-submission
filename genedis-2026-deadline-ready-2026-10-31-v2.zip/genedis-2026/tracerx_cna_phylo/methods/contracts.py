"""Pure contracts for conditional CNA-state partial orders; no engine or data fit."""
from __future__ import annotations

from collections import Counter
import math
from typing import Iterable, Mapping


def arm_loh_state(segments: Iterable[Mapping], start: int, end: int,
                  min_coverage: float = 0.8) -> dict:
    """Classify an arm from nonoverlapping BED segments, retaining missing bounds.

    Inputs have ``start``, ``end``, ``cn_a`` and ``cn_b``. Coordinates must have
    already been mapped back from continuity blocks to the reference chromosome.
    Unmeasured bases never become diploid or non-LOH. A homozygous deletion has
    minor zero and is part of this broad LOH state, not an independent arm step.
    """
    if not (isinstance(start, int) and isinstance(end, int) and 0 <= start < end):
        raise ValueError("Arm must be a nonempty BED interval")
    clipped = []
    for row in segments:
        left, right = max(start, int(row["start"])), min(end, int(row["end"]))
        if left >= right:
            continue
        alleles = (row["cn_a"], row["cn_b"])
        if any(isinstance(x, bool) or not isinstance(x, int) or x < 0 for x in alleles):
            raise ValueError("Allele states must be nonnegative source/model integers")
        clipped.append((left, right, min(alleles) == 0))
    clipped.sort()
    if any(a[1] > b[0] for a, b in zip(clipped, clipped[1:])):
        raise ValueError("Overlapping coverage would count bases twice")
    size = end - start
    measured = sum(right - left for left, right, _ in clipped)
    loh = sum(right - left for left, right, positive in clipped if positive)
    missing = size - measured
    state = None
    reason = "threshold_intersects_missing_bases"
    if measured / size < min_coverage:
        reason = "insufficient_arm_coverage"
    elif loh * 2 > size:
        state, reason = True, "observed_loh_exceeds_half_reference_arm"
    elif (loh + missing) * 2 <= size:
        state, reason = False, "even_all_missing_loh_cannot_exceed_half_arm"
    return {"state": state, "reason": reason, "reference_bases": size,
            "measured_bases": measured, "missing_bases": missing,
            "loh_bases": loh, "coverage": measured / size,
            "loh_fraction_lower": loh / size,
            "loh_fraction_upper": (loh + missing) / size}


def validate_tree(parent: Mapping[str, str | None], lengths: Mapping[str, float]) -> str:
    roots = [node for node, ancestor in parent.items() if ancestor is None]
    if len(roots) != 1:
        raise ValueError("Exactly one explicit root is required")
    root = roots[0]
    for node in parent:
        seen = set()
        cur = node
        while cur != root:
            if cur in seen or cur not in parent or parent[cur] is None:
                raise ValueError("Tree contains a cycle or disconnected node")
            seen.add(cur)
            value = lengths.get(cur)
            if value is None or not math.isfinite(float(value)) or value < 0:
                raise ValueError("Every non-root branch needs a finite nonnegative length")
            cur = parent[cur]
    return root


def event_placement(states: Mapping[str, bool | None], parent: Mapping[str, str | None],
                    lengths: Mapping[str, float], extra_flags: Iterable[str] = ()) -> dict:
    """Identify every state-acquisition/reversion branch, never a within-branch rank."""
    root = validate_tree(parent, lengths)
    if set(states) != set(parent):
        raise ValueError("Every tree node must have an explicit state, including unknown")
    if any(value is not None and type(value) is not bool for value in states.values()):
        raise ValueError("States must be true, false or unknown")
    internal = {ancestor for ancestor in parent.values() if ancestor is not None}
    terminals = [node for node in parent if node not in internal]
    # A synthetic normal leaf is harmless: its negative state cannot make an
    # otherwise unknown collection of regional states a known noncarrier.
    leaf_states = [states[node] for node in terminals]
    carrier = True if True in leaf_states else (False if all(x is False for x in leaf_states) else None)
    acquisitions, reversions = [], []
    flags = set(extra_flags)
    if states[root] is not False:
        flags.add("uncertain_root_state")
    for node, ancestor in parent.items():
        if ancestor is None:
            continue
        before, after = states[ancestor], states[node]
        if before is None or after is None:
            flags.add("unknown_ancestral_or_terminal_state")
        elif before is False and after is True:
            acquisitions.append(node)
            if lengths[node] == 0:
                flags.add("zero_length_acquisition")
        elif before is True and after is False:
            reversions.append(node)
    if len(acquisitions) > 1:
        flags.add("repeated_acquisition")
    if reversions:
        flags.add("state_reversion")
    if carrier is True and not acquisitions:
        flags.add("no_unique_acquisition")
    return {"carrier": carrier, "acquisition_branches": sorted(acquisitions),
            "reversion_branches": sorted(reversions), "flags": sorted(flags),
            "unique_branch": acquisitions[0] if len(acquisitions) == 1 and not flags else None}


def wgd_placement(branch_counts: Mapping[str, int], parent: Mapping[str, str | None],
                  lengths: Mapping[str, float], history_valid: bool) -> dict:
    """WGD state from actual event rows, not a regional ploidy threshold."""
    root = validate_tree(parent, lengths)
    if any(node not in parent or type(count) is not int or count < 0
           for node, count in branch_counts.items()):
        raise ValueError("WGD counts must identify actual branches and be nonnegative integers")
    if branch_counts.get(root, 0):
        raise ValueError("A synthetic root cannot have an incoming WGD event")
    states = {root: False}
    pending = set(parent) - {root}
    while pending:
        progress = [node for node in pending if parent[node] in states]
        if not progress:
            raise ValueError("Disconnected WGD tree")
        for node in progress:
            states[node] = states[parent[node]] or bool(branch_counts.get(node, 0))
            pending.remove(node)
    flags = [] if history_valid else ["unvalidated_wgd_event_history"]
    if sum(branch_counts.values()) > 1:
        flags.append("multiple_wgd_events")
    result = event_placement(states, parent, lengths, flags)
    result["branch_counts"] = dict(branch_counts)
    result["reported_model_carrier"] = result["carrier"]
    if not history_valid:
        result["carrier"] = None  # unvalidated history is not a known model event state
    return result


def pair_category(a: Mapping, b: Mapping, parent: Mapping[str, str | None],
                  lengths: Mapping[str, float]) -> str:
    """One exhaustive categorical observation per independent patient and pair."""
    validate_tree(parent, lengths)
    if a["carrier"] is None or b["carrier"] is None:
        return "assay_or_state_unknown"
    if not a["carrier"] or not b["carrier"]:
        return "not_co_carrier"
    flags = set(a["flags"]) | set(b["flags"])
    if "repeated_acquisition" in flags or "multiple_wgd_events" in flags:
        return "repeated_event"
    if "state_reversion" in flags:
        return "state_reversion"
    if flags or not a["unique_branch"] or not b["unique_branch"]:
        return "placement_unknown"
    left, right = a["unique_branch"], b["unique_branch"]
    if left == right:
        return "same_branch_unordered"
    def ancestor_path(older, younger):
        path = []
        while parent[younger] is not None:
            path.append(younger)
            younger = parent[younger]
            if younger == older:
                return path
        return None
    forward = ancestor_path(left, right)
    reverse = ancestor_path(right, left)
    path = forward if forward is not None else reverse
    if path is None:
        return "incomparable_branches"
    if sum(lengths[node] for node in path) <= 0:
        return "zero_length_separation"
    return "a_ancestor_b" if forward is not None else "b_ancestor_a"


def consensus_category(categories: Iterable[str]) -> str:
    values = list(categories)
    if not values:
        return "reconstruction_unavailable"
    return values[0] if len(set(values)) == 1 else "sensitivity_disagreement"


def exact_direction_p(forward: int, reverse: int) -> float:
    """One-sided binomial P(X>=forward | n, p=.5); unresolved never enter n."""
    if any(type(x) is not int or x < 0 for x in (forward, reverse)):
        raise ValueError("Patient vote counts must be nonnegative integers")
    n = forward + reverse
    return sum(math.comb(n, k) for k in range(forward, n + 1)) / (2 ** n)


def bh_adjust(pvalues: Mapping[str, float]) -> dict[str, float]:
    if any(not 0 <= value <= 1 for value in pvalues.values()):
        raise ValueError("P values must be finite probabilities")
    ordered = sorted(pvalues, key=lambda key: (pvalues[key], key))
    result, running, n = {}, 1.0, len(ordered)
    for rank in range(n, 0, -1):
        key = ordered[rank - 1]
        running = min(running, pvalues[key] * n / rank)
        result[key] = min(1.0, running)
    return result


def pair_counts(categories: Iterable[str]) -> dict:
    count = Counter(categories)
    forward, reverse = count["a_ancestor_b"], count["b_ancestor_a"]
    return {"patients": sum(count.values()), "categories": dict(sorted(count.items())),
            "forward": forward, "reverse": reverse, "resolved": forward + reverse,
            "forward_p": exact_direction_p(forward, reverse),
            "reverse_p": exact_direction_p(reverse, forward)}
