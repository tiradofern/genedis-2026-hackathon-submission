"""Atomic terminal snapshot, sole canonical conversion, then read-only final audit.

This command must be dispatched only after notifying the root coordinator that
canonical writing will begin. It never runs the root-owned population screen.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

from .engine_output import sha256
from .review_bootstrap_fleet import NONTERMINAL, VARIANTS, reused_model_audit, verify_main_boundary


def finalize(jobs_path, snapshot, converted):
    root = Path(__file__).resolve().parents[2]
    if jobs_path.resolve() == snapshot.resolve():
        raise ValueError("Final snapshot must not overwrite the live runtime job ledger")
    unchanged = verify_main_boundary(root)
    blob = jobs_path.read_bytes()
    document = json.loads(blob)
    scope = json.loads((root / "tracerx_cna_phylo/source/output/canonical_manifest.json").read_text())["patients"]
    variants = {"primary", "highcopy_mask", "gap100k", "total_cn_topology"} | {
        f"bootstrap_{index:03d}" for index in range(20)}
    expected = {(p["patient_id"], variant) for p in scope for variant in variants}
    jobs = document["jobs"]
    if len(jobs) != len(expected) or {(j["patient_id"], j["variant"]) for j in jobs} != expected:
        raise ValueError("Terminal snapshot must retain exactly all 24 planned records per original patient")
    if any(job["status"] in NONTERMINAL for job in jobs):
        raise ValueError("The full reconstruction fleet is not terminal; no canonical writing started")
    freeze = root / "tracerx_cna_phylo/config_freeze_2026-10-18.json"
    inputs = root / "tracerx_cna_phylo/source/output/input_manifest.json"
    if (document["config_freeze_sha256"] != sha256(freeze) or
            document["input_manifest_sha256"] != sha256(inputs)):
        raise ValueError("Runtime ledger is not bound to the effective source/configuration freeze")
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    pending = snapshot.with_suffix(snapshot.suffix + f".pending.{os.getpid()}")
    pending.write_bytes(blob)
    pending.replace(snapshot)
    reused_histologies, reused_histology_records = [], 0
    for histology in ("luad", "lusc"):
        prior = reused_model_audit(root, [job for job in jobs if job["variant"] in VARIANTS], histology)
        if prior is not None:
            reused_histologies.append(histology)
            reused_histology_records += prior[1]["canonical_records"]
    writes = [job for job in jobs if job["variant"] in VARIANTS
              and job["histology"].lower() not in reused_histologies]
    conversion_manifest = snapshot.with_name("final_conversion_jobs.json")
    filtered = {"jobs": writes, "terminal_snapshot_sha256": sha256(snapshot),
                "unchanged_main_records_reused": unchanged,
                "completed_histologies_reused": reused_histologies}
    pending = conversion_manifest.with_suffix(conversion_manifest.suffix + f".pending.{os.getpid()}")
    pending.write_text(json.dumps(filtered, indent=2, allow_nan=False) + "\n", encoding="utf-8", newline="\n")
    pending.replace(conversion_manifest)
    print(json.dumps({"stage": "atomic_terminal_snapshot", "records": len(jobs),
                      "unchanged_main_records": unchanged, "completed_histology_records_reused": reused_histology_records,
                      "records_to_write": len(writes), "snapshot_sha256": sha256(snapshot)}), flush=True)
    subprocess.run([sys.executable, "-u", "-m", "tracerx_cna_phylo.methods.convert_outputs",
                    "--jobs", str(conversion_manifest), "--out", str(converted)], cwd=root, check=True)
    print(json.dumps({"stage": "canonical_conversion_complete_starting_read_only_audit"}), flush=True)
    subprocess.run([sys.executable, "-u", "-m", "tracerx_cna_phylo.methods.review_bootstrap_fleet",
                    "--snapshot", str(snapshot), "--converted", str(converted)], cwd=root, check=True)
    audit_path = root / "tracerx_cna_phylo/methods/bootstrap_fleet_review.json"
    audit = json.loads(audit_path.read_text())
    if not audit["passed"] or audit["final_snapshot_sha256"] != sha256(snapshot):
        raise ValueError("Final bootstrap audit is not bound to this terminal snapshot")
    report = {"passed": True, "canonical_reconstruction_records": len(jobs),
              "records_written_this_boundary": len(writes),
              "completed_histology_records_reused": reused_histology_records,
              "completed_histologies_reused": reused_histologies,
              "unique_patients": len(scope), "planned_bootstrap_slots": len(scope) * 20,
              "unchanged_main_records_reused": unchanged, "final_snapshot_sha256": sha256(snapshot),
              "conversion_manifest_sha256": sha256(conversion_manifest),
              "bootstrap_audit_sha256": sha256(audit_path), "controller_sha256": sha256(Path(__file__)),
              "next_step": "Root-owned final route screen using the same final snapshot; then independent extended screen review",
              "interpretation": "Completed computational fidelity audit; no biological validation claim"}
    (root / "tracerx_cna_phylo/methods/final_conversion_review.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(report, indent=2), flush=True)


def main():
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jobs", type=Path, default=root / "tracerx_cna_phylo/runtime/output/job_manifest.json")
    parser.add_argument("--snapshot", type=Path, default=root / "tracerx_cna_phylo/runtime/output/snapshots/final_fleet.json")
    parser.add_argument("--converted", type=Path, default=root / "tracerx_cna_phylo/methods/output")
    args = parser.parse_args()
    finalize(args.jobs, args.snapshot, args.converted)


if __name__ == "__main__":
    main()
