"""Compare own output-writing wrapper with the official CLI, byte for byte."""
from pathlib import Path
import json

from fit_worker import official_fit, sha

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
source = HERE / "raw/medicc2/examples/simple_example/simple_example.tsv"
destination = HERE / "output/smoke/programmatic_x2"
_, paths, fit = official_fit(source, destination, "programmatic_x2")
suffixes = {"tree": "final_tree.new", "xml": "final_tree.xml", "branches": "branch_lengths.tsv",
            "distances": "pairwise_distances.tsv", "profiles": "final_cn_profiles.tsv",
            "events": "copynumber_events_df.tsv", "summary": "summary.tsv"}
comparisons = {}
for key, suffix in suffixes.items():
    reference = HERE / "output/smoke/shipped_x2" / f"shipped_x2_{suffix}"
    actual = ROOT / paths[key]
    same = sha(reference) == sha(actual)
    comparisons[key] = {"reference_sha256": sha(reference), "wrapper_sha256": sha(actual), "equal": same}
    if not same:
        raise AssertionError(f"Programmatic wrapper differs from official CLI: {key}")
record = {"fixture": "Official shipped simple example with explicit x2 model",
          "all_seven_output_artifacts_byte_identical": True, "comparisons": comparisons,
          "fit": fit, "interpretation": "Output fidelity check; no biological-validity claim"}
(HERE / "programmatic_review.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"all_seven_output_artifacts_byte_identical": True}))
