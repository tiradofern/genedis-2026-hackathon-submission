"""Unpack only the downloaded portable package-manager executable."""
from pathlib import Path
import tarfile
import hashlib

root = Path(__file__).resolve().parent
archive_path = root / "raw/micromamba-linux-64.tar.bz2"
if hashlib.sha256(archive_path.read_bytes()).hexdigest() != "8761c382127e6363bd9e0a2451aa3ef90d071a79133f736e2f759a3bf13040dd":
    raise ValueError("Micromamba 2.9.0 archive checksum differs from the audited download")
with tarfile.open(archive_path) as archive:
    member = archive.getmember("bin/micromamba")
    if not member.isfile():
        raise ValueError("Expected executable is not a regular file")
    target = root / ".runtime/micromamba/bin/micromamba"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(archive.extractfile(member).read())
    target.chmod(0o755)
print(target)
