"""Resumeable, bounded orchestration of unchanged official MEDICC2 patient jobs.

All patient inputs/outputs and statuses are local and ignored. Frozen source,
configuration and reference bytes are checked before any process is launched.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict, deque
from datetime import datetime, timezone
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import subprocess
import signal
import sys
import time
import traceback

# Import the unchanged official engine once before any child or worker exists.
# Linux fork then shares only read-only library/code pages; every fit is isolated.
from fit_worker import execute as execute_worker

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PIN = "04e9bfec8a9b8fb585a703c5a10d6ee62bec7b35"
FREEZE = ROOT / "tracerx_cna_phylo/config_freeze_2026-10-18.json"
INPUTS = ROOT / "tracerx_cna_phylo/source/output/input_manifest.json"
RESULTS = HERE / "output/job_manifest.json"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_atomic(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_suffix(path.suffix + ".pending")
    pending.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    pending.replace(path)


def lock(path, expected):
    if sha(path) != expected:
        raise ValueError(f"Frozen bytes changed: {path.relative_to(ROOT)}")


def load_locked():
    freeze = read(FREEZE)
    inputs = read(INPUTS)
    lock(FREEZE, inputs["config_freeze_sha256"])
    configs = {}
    for entry in freeze["configurations"]:
        path = ROOT / entry["path"]
        lock(path, entry["sha256"])
        if path.stat().st_size != entry["bytes"]:
            raise ValueError("Frozen configuration length changed")
        config = read(path)
        if config["histology"] != entry["cohort"]:
            raise ValueError("Histology configuration mismatch")
        for name in ("canonical_manifest", "reference_manifest", "arms", "previous_source_manifest"):
            lock(ROOT / config["source"][name + "_path"], config["source"][name + "_sha256"])
        lock(ROOT / config["cohort"]["frozen_source_path"], config["cohort"]["frozen_source_sha256"])
        engine = config["engine"]
        expected = {"source_commit": PIN, "version": "1.1.2", "wgd_x2": True,
                    "primary_per_allele_cap": 8, "maxcn": 8,
                    "internal_evolutionary_phasing": False, "reconstruct_ancestors": True,
                    "reconstruct_events": True, "n_cores_per_fit": 1,
                    "max_concurrent_fits": 4, "variant_timeout_seconds": 600,
                    "bootstrap_replica_timeout_seconds": 90, "bootstrap_replicates": 20}
        if any(engine.get(key) != value for key, value in expected.items()):
            raise ValueError("Engine settings differ from implemented frozen policy")
        configs[entry["cohort"]] = config
    if set(configs) != {"luad", "lusc"}:
        raise ValueError("Both separately configured histologies are required")
    for source in inputs["jobs"]:
        if source["config_freeze_sha256"] != sha(FREEZE):
            raise ValueError("Input refers to a different freeze")
        for path_key, hash_key in (("input_path", "sha256"), ("mapping_path", "mapping_sha256"),
                                   ("canonical_path", "canonical_sha256")):
            lock(ROOT / source[path_key], source[hash_key])
    return configs, inputs


def identifier(job):
    return "|".join(job[key] for key in ("histology", "patient_id", "variant"))


def plan_jobs(configs, inputs):
    jobs = []
    for source in inputs["jobs"]:
        variants = [source["variant"]]
        if source["variant"] == "primary":
            variants += ["total_cn_topology"]
            variants += [f"bootstrap_{index:03d}" for index in range(20)]
        for variant in variants:
            record = dict(source)
            record.update(variant=variant, input_sha256=source["sha256"],
                          status="planned" if source["source_status"] == "ready" else source["source_status"],
                          source_variant=source["variant"], attempts=[])
            output = HERE / "output" / source["histology"] / source["patient_id"] / variant
            record["output_dir"] = output.relative_to(ROOT).as_posix()
            record["timeout_seconds"] = 90 if variant.startswith("bootstrap_") else 600
            record["seed"] = configs[source["histology"]]["random_seed"]
            if variant.startswith("bootstrap_"):
                record["bootstrap_index"] = int(variant.split("_")[-1])
            jobs.append(record)
    if len({identifier(job) for job in jobs}) != len(jobs):
        raise ValueError("Duplicate engine job identity")
    return jobs


def aggregate(jobs):
    groups = defaultdict(Counter)
    for job in jobs:
        variant = "bootstrap" if job["variant"].startswith("bootstrap_") else job["variant"]
        groups[job["histology"] + "/" + variant][job["status"]] += 1
    return {key: dict(value) for key, value in sorted(groups.items())}


def selected(job, phase):
    if phase == "primary":
        return job["variant"] == "primary"
    if phase == "sensitivities":
        return job["variant"] in {"highcopy_mask", "gap100k", "total_cn_topology"}
    if phase == "bootstrap":
        return job["variant"].startswith("bootstrap_")
    return True


def child_execute(specification, output):
    os.setsid()
    with (output / "stdout.log").open("w") as stdout, (output / "stderr.log").open("w") as stderr:
        os.dup2(stdout.fileno(), 1)
        os.dup2(stderr.fileno(), 2)
        try:
            execute_worker(specification)
            sys.stdout.flush()
            sys.stderr.flush()
        except BaseException:
            traceback.print_exc()
            sys.stderr.flush()
            raise


def start_job(job):
    output = ROOT / job["output_dir"]
    output.mkdir(parents=True, exist_ok=True)
    specification = output / "job_specification.json"
    value = {**job, "source_job": {**job, "variant": job["source_variant"]}}
    write_atomic(specification, value)
    attempt = {"started_utc": datetime.now(timezone.utc).isoformat(),
               "worker_sha256": sha(HERE / "fit_worker.py"),
                "driver_sha256": sha(Path(__file__)), "timeout_seconds": job["timeout_seconds"],
               "isolation": "Single-parent Linux fork; preloaded unchanged official modules; one owned process group per fit"}
    process = multiprocessing.get_context("fork").Process(target=child_execute, args=(value, output))
    start = time.monotonic()
    process.start()
    job["status"] = "running"
    return process, job, start, attempt


def finish_job(active, timed_out=False):
    process, job, start, attempt = active
    output = ROOT / job["output_dir"]
    if timed_out:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    process.join()
    attempt["returncode"] = process.exitcode
    try:
        if timed_out:
            job.update(status="timed_out", error="Prespecified wall-clock limit; no result-based retry or exclusion")
        elif process.exitcode:
            job.update(status="failed_engine", error_log=(output / "stderr.log").relative_to(ROOT).as_posix())
        else:
            result_path = output / "worker_result.json"
            if not result_path.is_file():
                raise ValueError("Worker returned without a result record")
            job.update(read(result_path))
            logs = (output / "stdout.log").read_text() + (output / "stderr.log").read_text()
            job["engine_reported_faulty_history"] = ("Event recreation was faulty" in logs or
                job.get("fit", {}).get("global_event_count_equals_tree_length") is False)
    except Exception as exc:
        job.update(status="failed_orchestration", error=repr(exc))
    attempt.update(status=job["status"], elapsed_s=time.monotonic()-start)
    job["elapsed_s"] = attempt["elapsed_s"]
    job["attempts"].append(attempt)
    write_atomic(output / "job_status.json", job)
    return job


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=["primary", "sensitivities", "bootstrap", "all"], default="primary")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--histology", choices=["luad", "lusc"])
    args = parser.parse_args()
    if not 1 <= args.workers <= 4:
        raise SystemExit("Frozen concurrency ceiling is four single-core jobs")
    configs, inputs = load_locked()
    jobs = plan_jobs(configs, inputs)
    if RESULTS.is_file():
        prior = read(RESULTS)
        if prior["config_freeze_sha256"] != sha(FREEZE) or prior["input_manifest_sha256"] != sha(INPUTS):
            raise ValueError("Cannot resume outputs made with different source/configuration bytes")
        by_id = {identifier(job): job for job in prior["jobs"]}
        for index, job in enumerate(jobs):
            old = by_id.get(identifier(job))
            if old and old["status"] != "planned":
                if old.get("input_sha256") != job["input_sha256"]:
                    raise ValueError("Prior result input differs")
                for key, expected in old.get("output_hashes", {}).items():
                    lock(ROOT / old["paths"][key], expected)
                jobs[index] = old
    # Each finished process has a durable local status, even between aggregate
    # checkpoints. Resume it without rerunning an already attempted history.
    for index, job in enumerate(jobs):
        status_path = ROOT / job["output_dir"] / "job_status.json"
        if job["status"] == "planned" and status_path.is_file():
            old = read(status_path)
            if old.get("input_sha256") != job["input_sha256"] or old.get("config_freeze_sha256") != sha(FREEZE):
                raise ValueError("Per-job checkpoint refers to different frozen bytes")
            for key, expected in old.get("output_hashes", {}).items():
                lock(ROOT / old["paths"][key], expected)
            jobs[index] = old
    index_by_id = {identifier(job): index for index, job in enumerate(jobs)}
    manifest = {"schema_version": "1.0", "config_freeze_path": FREEZE.relative_to(ROOT).as_posix(),
                "config_freeze_sha256": sha(FREEZE), "input_manifest_sha256": sha(INPUTS),
                "upstream_source_commit": PIN, "jobs": jobs,
                "interpretation": "Local model outputs; success is not a history-validation or biological-validity claim."}
    def checkpoint():
        manifest.update(updated_utc=datetime.now(timezone.utc).isoformat(), aggregate=aggregate(jobs))
        write_atomic(RESULTS, manifest)
        write_atomic(HERE / "run_summary.json", {key: value for key, value in manifest.items() if key != "jobs"})
    candidates = [job for job in jobs if job["status"] == "planned" and selected(job, args.phase)
                  and (args.histology is None or job["histology"] == args.histology)]
    if args.limit is not None:
        candidates = candidates[:args.limit]
    checkpoint()
    last_checkpoint = time.monotonic()
    pending, active = deque(candidates), {}
    while pending or active:
        while pending and len(active) < args.workers:
            running = start_job(pending.popleft())
            active[running[0].pid] = running
        for pid, running in list(active.items()):
            process, job, started, _ = running
            timed_out = time.monotonic() - started >= job["timeout_seconds"]
            if process.is_alive() and not timed_out:
                continue
            result = finish_job(running, timed_out=timed_out)
            identity = identifier(result)
            jobs[index_by_id[identity]] = result
            del active[pid]
            if time.monotonic() - last_checkpoint >= 5:
                checkpoint()
                last_checkpoint = time.monotonic()
            print(json.dumps({"job": identity, "status": result["status"],
                              "elapsed_s": round(result.get("elapsed_s", 0), 3)}), flush=True)
        if active:
            time.sleep(0.05)
    checkpoint()
    print(json.dumps({"aggregate": aggregate(jobs)}), flush=True)


if __name__ == "__main__":
    main()
