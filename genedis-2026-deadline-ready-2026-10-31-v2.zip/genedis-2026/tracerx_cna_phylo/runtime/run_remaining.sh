#!/usr/bin/env bash
set -euo pipefail
runtime_root="$(cd -- "$(dirname -- "$0")" && pwd)"
repo_root="$(cd -- "$runtime_root/../.." && pwd)"
cd -- "$repo_root"
echo 'Starting prespecified CNA sensitivity jobs (four isolated single-core workers).'
bash "$runtime_root/run_python.sh" "$runtime_root/run_patients.py" \
  --phase sensitivities --workers 4 > "$runtime_root/output/sensitivity_driver.log" 2>&1
echo 'Sensitivity phase finished; all statuses retained. Starting twenty chromosome replicas per patient.'
bash "$runtime_root/run_python.sh" "$runtime_root/run_patients.py" \
  --phase bootstrap --workers 4 > "$runtime_root/output/bootstrap_driver.log" 2>&1
echo 'Prespecified local CNA reconstruction phases finished; inspect aggregate and independent history audits.'
