#!/usr/bin/env bash
set -euo pipefail
runtime_root="$(cd -- "$(dirname -- "$0")" && pwd)"
native_root="${XDG_CACHE_HOME:-$HOME/.cache}/genedis-cna-medicc2-04e9bfec"
export MAMBA_ROOT_PREFIX="$native_root/mamba-root"
export MPLBACKEND=Agg
export PYTHONHASHSEED=0
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
exec "$runtime_root/.runtime/micromamba/bin/micromamba" run \
  -p "$native_root/env" python "$@"
