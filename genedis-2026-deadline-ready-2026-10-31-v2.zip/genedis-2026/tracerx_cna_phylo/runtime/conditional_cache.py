"""Exact conditional-refit cache; every resampled topology is still inferred.

Only supplied non-root branch lengths are excluded from the key. Upstream
ancestors.py never reads them, and core.py recomputes them before events. Exact
node names, child order and root length are retained; no tree canonicalization
or renaming is performed to create additional hits.
"""
import hashlib
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def topology_contract(tree):
    def node(clade):
        attributes = {key: value for key, value in vars(clade).items()
                      if key not in {"clades", "branch_length"}}
        return {"attributes": attributes, "children": [node(child) for child in clade.clades]}
    return {"rooted": tree.rooted, "tree_name": tree.name, "tree_id": tree.id,
            "root_branch_length": tree.root.branch_length, "ordered_root": node(tree.root)}


def key_record(source, tree):
    contract = {"input_sha256": source["sha256"],
                "runtime_manifest_sha256": sha(HERE / "runtime_manifest.json"),
                "fit_worker_sha256": sha(HERE / "fit_worker.py"),
                "conditional_cache_sha256": sha(Path(__file__)),
                "official_source_commit": "04e9bfec8a9b8fb585a703c5a10d6ee62bec7b35",
                "ordered_topology": topology_contract(tree),
                "parameters": {"normal_name": "diploid", "prune_weight": 0,
                               "alleles": ["cn_a", "cn_b"], "wgd_x2": True,
                               "no_wgd": False, "total_cn": False, "maxcn": 8,
                               "n_cores": 1, "ancestral_reconstruction": True,
                               "reconstruct_events": True}}
    encoded = json.dumps(contract, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    key = hashlib.sha256(encoded).hexdigest()
    path = HERE / "output/conditional_refit_cache" / source["histology"] / source["patient_id"] / (key + ".json")
    return key, contract, path


def lookup(source, tree):
    key, contract, path = key_record(source, tree)
    if not path.is_file():
        return key, contract, path, None
    cached = json.loads(path.read_text())
    if cached["key"] != key or cached["contract"] != contract:
        raise ValueError("Conditional cache fingerprint differs")
    for name, expected in cached["output_hashes"].items():
        if sha(ROOT / cached["paths"][name]) != expected:
            raise ValueError("Conditional cache output changed")
    return key, contract, path, cached


def remember(key, contract, path, paths, fit, variant):
    value = {"key": key, "contract": contract, "paths": paths, "fit": fit,
             "source_variant": variant, "output_hashes": {name: sha(ROOT / item) for name, item in paths.items()}}
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        prior = json.loads(path.read_text())
        if prior["output_hashes"] != value["output_hashes"]:
            raise ValueError("Identical conditional contract produced different output bytes")
        return
    pending = path.with_suffix(f".pending.{os.getpid()}")
    pending.write_text(json.dumps(value, indent=2) + "\n")
    # The pointer is published only after all unique per-job files are complete.
    # Concurrent identical misses never write each other's artifact files.
    pending.replace(path)
