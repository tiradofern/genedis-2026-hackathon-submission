"""Distinguish multiplication-by-two from the default +1 on abnormal states."""
import json
from pathlib import Path

import fstlib
import medicc
import pandas as pd

HERE = Path(__file__).resolve().parent
destination = HERE / "output/smoke/non_diploid_doubling"
destination.mkdir(parents=True, exist_ok=True)
rows = [{"sample_id": sample, "chrom": str(chrom), "start": 0, "end": 1000000,
         "cn_a": major, "cn_b": minor}
        for sample, major, minor in (("synthetic_parent", 2, 1), ("synthetic_child", 4, 2))
        for chrom in range(1, 23)]
input_path = destination / "input.tsv"
pd.DataFrame(rows).to_csv(input_path, sep="\t", index=False)
frame = medicc.io.read_and_parse_input_data(str(input_path))
scores = {}
for label, x2 in (("explicit_x2", True), ("default_add_one", False)):
    model = medicc.io.read_fst(wgd_x2=x2)
    fsa, _ = medicc.core.create_standard_fsa_dict_from_data(frame, model.input_symbols())
    scores[label] = float(fstlib.score(model, fsa["synthetic_parent"], fsa["synthetic_child"]))
assert scores["explicit_x2"] == 1, scores
assert scores["default_add_one"] > 1, scores
record = {"synthetic_states": "All22autosomes major/minor2,1 to4,2",
          "official_directed_minimum_costs": scores, "passed": True,
          "interpretation": "Genuine finite-state model distinction; no inferred patient chronology"}
(HERE / "x2_model_review.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record))
