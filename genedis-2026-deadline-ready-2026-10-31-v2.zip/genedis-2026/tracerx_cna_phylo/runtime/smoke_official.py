"""Execute unchanged upstream MEDICC2 on shipped and known synthetic fixtures.

Run with the isolated Linux Python. These establish runtime behavior, not clinical
or biological validity of subsequently reconstructed patient trees.
"""
from __future__ import annotations

import csv
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

import pandas as pd
from Bio import Phylo

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "raw/medicc2"
OUTPUT = ROOT / "output/smoke"
PIN = "04e9bfec8a9b8fb585a703c5a10d6ee62bec7b35"
RECORDS = []


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fixture(name: str, profiles: dict[str, list[tuple[int, int]]]) -> Path:
    path = OUTPUT / "inputs" / f"{name}.tsv"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(["sample_id", "chrom", "start", "end", "cn_a", "cn_b"])
        for sample, states in profiles.items():
            for chrom, (major, minor) in enumerate(states, 1):
                writer.writerow([sample, str(chrom), 0, 1000000, major, minor])
    return path


def run(name: str, input_path: Path, *flags: str):
    destination = OUTPUT / name
    destination.mkdir(parents=True, exist_ok=True)
    command = [sys.executable, str(Path(sys.prefix) / "bin/medicc2"),
               str(input_path), str(destination), "--prefix", name,
               "--events", "--plot", "none", "--no-plot-tree", "-j", "1", *flags]
    before = digest(input_path)
    result = subprocess.run(command, text=True, capture_output=True, check=False,
                            env={**os.environ, "MPLBACKEND": "Agg",
                                 "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1"})
    (destination / "stdout.log").write_text(result.stdout)
    (destination / "stderr.log").write_text(result.stderr)
    if result.returncode:
        raise AssertionError(f"Official CLI failed ({result.returncode}): {result.stderr[-3000:]}")
    if "Event recreation was faulty" in result.stdout + result.stderr:
        raise AssertionError("Official event reconstruction signaled an invalid history")
    if digest(input_path) != before:
        raise AssertionError("Upstream input changed")
    paths = {key: destination / f"{name}_{suffix}" for key, suffix in {
        "profiles": "final_cn_profiles.tsv", "events": "copynumber_events_df.tsv",
        "tree": "final_tree.new", "xml": "final_tree.xml",
        "distances": "pairwise_distances.tsv", "branches": "branch_lengths.tsv",
        "summary": "summary.tsv"}.items()}
    for path in paths.values():
        if not path.is_file():
            raise AssertionError(f"Missing official output {path.name}")
    profiles = pd.read_csv(paths["profiles"], sep="\t")
    events = pd.read_csv(paths["events"], sep="\t")
    tree = Phylo.read(paths["tree"], "newick")
    if len(events) != tree.total_branch_length():
        raise AssertionError("Official events do not sum to the inferred tree cost")
    RECORDS.append({"fixture": name, "input_sha256": before,
                    "flags": list(flags), "event_count": len(events),
                    "event_counts": {str(k): int(v) for k, v in events["type"].value_counts().items()},
                    "tree_length": tree.total_branch_length(),
                    "output_sha256": {key: digest(path) for key, path in paths.items()},
                    "profiles_columns": list(profiles.columns),
                    "events_columns": list(events.columns)})
    return profiles, events, tree


class OfficialRuntimeSmoke(unittest.TestCase):
    def test_01_shipped_fixture_default(self):
        profiles, events, _ = run("shipped_default", SOURCE / "examples/simple_example/simple_example.tsv")
        # Exact expectations shipped in upstream medicc/test_medicc.py.
        self.assertEqual(int(profiles.is_gain.sum()), 7)
        self.assertEqual(int(profiles.is_loss.sum()), 5)
        self.assertEqual(int((events.type == "gain").sum()), 4)
        self.assertEqual(int((events.type == "loss").sum()), 3)

    def test_02_shipped_fixture_x2(self):
        profiles, events, _ = run("shipped_x2", SOURCE / "examples/simple_example/simple_example.tsv", "--wgd-x2")
        self.assertEqual(int(profiles.is_gain.sum()), 7)
        self.assertEqual(int(profiles.is_loss.sum()), 5)
        self.assertEqual(int((events.type == "gain").sum()), 4)
        self.assertEqual(int((events.type == "loss").sum()), 3)

    def test_03_known_shared_wgd(self):
        profiles = {sample: [(2, 2)] * 22 for sample in ("synthetic_a", "synthetic_b", "synthetic_c")}
        for index, sample in enumerate(profiles):
            profiles[sample][index] = (3, 2)
        observed, events, tree = run("known_shared_wgd", fixture("known_shared_wgd", profiles), "--wgd-x2")
        self.assertEqual(int((events.type == "wgd").sum()), 1)
        self.assertEqual(int((events.type == "gain").sum()), 3)
        self.assertEqual(len(events), 4)
        ancestor = tree.common_ancestor(list(profiles))
        ancestral_states = observed.loc[observed.sample_id == ancestor.name, ["cn_a", "cn_b"]]
        self.assertEqual(len(ancestral_states), 22)
        self.assertTrue((ancestral_states == 2).all().all())

    def test_04_known_shared_loh(self):
        profiles = {"synthetic_a": [(1, 0), (1, 1), (1, 1), (1, 1)],
                    "synthetic_b": [(1, 0), (2, 1), (1, 1), (1, 1)],
                    "synthetic_c": [(1, 1), (1, 1), (2, 1), (1, 1)]}
        observed, _, tree = run("known_shared_loh", fixture("known_shared_loh", profiles), "--wgd-x2")
        ancestor = tree.common_ancestor(["synthetic_a", "synthetic_b"])
        self.assertEqual(set(leaf.name for leaf in ancestor.get_terminals()), {"synthetic_a", "synthetic_b"})
        state = observed.loc[(observed.sample_id == ancestor.name) & (observed.chrom.astype(str).str.replace("chr", "") == "1")]
        self.assertEqual(state.cn_b.tolist(), [0])

    def test_05_explicit_cap(self):
        profiles = {"synthetic_a": [(9, 1), (1, 1)],
                    "synthetic_b": [(8, 1), (2, 1)]}
        observed, _, _ = run("explicit_cap", fixture("explicit_cap", profiles), "--wgd-x2", "--maxcn", "8")
        a = observed.loc[(observed.sample_id == "synthetic_a") & (observed.chrom.astype(str).str.replace("chr", "") == "1")]
        self.assertEqual(a.cn_a.tolist(), [8])


if __name__ == "__main__":
    if subprocess.check_output(["git", "-C", str(SOURCE), "rev-parse", "HEAD"], text=True).strip() != PIN:
        raise SystemExit("Wrong upstream source pin")
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(OfficialRuntimeSmoke)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    record = {"upstream_commit": PIN, "python": sys.version,
              "packages": {package: importlib.metadata.version(package) for package in
                           ("medicc2", "numpy", "pandas", "scipy", "biopython", "matplotlib", "Cython")},
              "tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
              "passed": result.wasSuccessful(), "fixtures": RECORDS,
              "interpretation": "Runtime and known synthetic behavior only; no patient validity claim."}
    (ROOT / "runtime_validation.json").write_text(json.dumps(record, indent=2) + "\n")
    raise SystemExit(0 if result.wasSuccessful() else 1)
