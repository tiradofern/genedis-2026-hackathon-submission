"""Pin installed official code against the unchanged checked-out source."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys

import medicc
import fstlib

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "raw/medicc2"
PIN = "04e9bfec8a9b8fb585a703c5a10d6ee62bec7b35"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(SOURCE), *args], text=True).strip()


commit = git("rev-parse", "HEAD")
if commit != PIN or git("status", "--porcelain", "--untracked-files=no"):
    raise SystemExit("Official source pin or tracked bytes changed")
matches = []
for package, installed in (("medicc", Path(medicc.__file__).parent),
                           ("fstlib", Path(fstlib.__file__).parent)):
    for original in sorted((SOURCE / package).glob("*.py")):
        target = installed / original.name
        if not target.is_file() or sha(target) != sha(original):
            raise SystemExit(f"Installed upstream module differs: {package}/{original.name}")
        matches.append({"file": package + "/" + original.name, "sha256": sha(original)})
fst_hashes = {path.name: sha(path) for path in sorted((SOURCE / "medicc/objects").glob("*.fst"))}
for name, expected in fst_hashes.items():
    if sha(Path(medicc.__file__).parent / "objects" / name) != expected:
        raise SystemExit("Installed FST differs from upstream source")
packages = []
for path in sorted((Path(sys.prefix) / "conda-meta").glob("*.json")):
    data = json.loads(path.read_text())
    packages.append({key: data[key] for key in ("name", "version", "build", "url", "md5", "sha256") if key in data})
lock_lines = ["@EXPLICIT"]
for package in packages:
    lock_lines.append(package["url"] + "#" + package["md5"])
(HERE / "conda-linux-64.lock.txt").write_text("\n".join(lock_lines) + "\n")
record = {"official_repository": "https://github.com/schwarzlab-ccb/medicc2",
          "source_commit": commit, "version": medicc.__version__,
          "submodule_commit": git("-C", "submodule-fstlib", "rev-parse", "HEAD"),
          "tracked_upstream_source_unchanged": True,
          "installed_python_modules_identical_to_upstream": matches,
          "installed_fst_files_identical_to_upstream": fst_hashes,
          "conda_lock_sha256": sha(HERE / "conda-linux-64.lock.txt"),
          "conda_packages": packages, "python": sys.version,
          "platform": platform.platform(), "environment_prefix": sys.prefix,
          "micromamba_version": "2.9.0",
          "micromamba_archive_sha256": sha(HERE / "raw/micromamba-linux-64.tar.bz2"),
          "isolation": "Existing Ubuntu WSL2; persistent native user cache; no system Python or OS components installed",
          "notes": ["Official pinned environment YAML uses Cython3.1.2 despite older README0.29 wording.",
                    "Official CLI bootstrap omits the x2 model flag, so it is not used.",
                    "Total-copy official diagnostic uses +2, followed by full-input major/minor x2 ancestor refit."]}
(HERE / "runtime_manifest.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"source_commit": commit, "version": medicc.__version__,
                  "unchanged_modules": len(matches), "unchanged_fsts": len(fst_hashes),
                  "conda_packages": len(packages)}))
