"""Check supplied-length invariance on the first two source-ordered real trees.

This performance check changes no input copy state, topology, child order or
scientific parameter. Patient-specific outputs remain ignored.
"""
import copy
import json
from pathlib import Path

import medicc

from conditional_cache import key_record
from fit_worker import official_fit, sha

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
manifest = json.loads((HERE / "output/job_manifest.json").read_text())
examples = [job for job in manifest["jobs"] if job["variant"] == "primary" and job["status"] == "success"][:2]
if len(examples) != 2:
    raise SystemExit("Two completed source-ordered primary trees required")
checks = []
for index, job in enumerate(examples):
    original = medicc.io.import_tree(str(ROOT / job["paths"]["tree"]))
    original.root.branch_length = 0.0
    altered = copy.deepcopy(original)
    for position, clade in enumerate(altered.find_clades()):
        if clade is not altered.root:
            clade.branch_length = 100.0 + position * 11.5
    source = {"sha256": job["input_sha256"], "histology": job["histology"], "patient_id": job["patient_id"]}
    first_key = key_record(source, original)[0]
    if key_record(source, altered)[0] != first_key:
        raise AssertionError("Cache unexpectedly includes supplied non-root lengths")
    swapped = copy.deepcopy(original)
    swapped.root.clades = list(reversed(swapped.root.clades))
    if key_record(source, swapped)[0] == first_key:
        raise AssertionError("Cache loses child order")
    renamed = copy.deepcopy(original)
    next(clade for clade in renamed.find_clades() if clade.name and "internal" in clade.name).name += "_changed"
    if key_record(source, renamed)[0] == first_key:
        raise AssertionError("Cache loses internal identity")
    changed_root = copy.deepcopy(original)
    changed_root.root.branch_length = 1.0
    if key_record(source, changed_root)[0] == first_key:
        raise AssertionError("Cache loses root branch length")
    changed_source = {**source, "sha256": "changed"}
    if key_record(changed_source, original)[0] == first_key:
        raise AssertionError("Cache loses input identity")
    destination = HERE / "output/cache_validation" / str(index)
    _, original_paths, _ = official_fit(ROOT / job["input_path"], destination / "original", "comparison", input_tree=original)
    _, altered_paths, _ = official_fit(ROOT / job["input_path"], destination / "altered", "comparison", input_tree=altered)
    matches = {name: sha(ROOT / path) == sha(ROOT / altered_paths[name]) for name, path in original_paths.items()}
    if not all(matches.values()):
        raise AssertionError("Conditional refit depends on supplied non-root lengths")
    checks.append({"ordinal": index + 1, "all_six_outputs_byte_identical": True,
                   "artifacts": sorted(matches), "root_held_zero": True,
                   "preserved_key_distinctions": ["child order", "internal identity", "root length", "full input hash"]})
record = {"real_source_ordered_examples": len(checks), "passed": True, "checks": checks,
          "official_code_review": ["ancestors.py uses ordered names/children/FSA/FST/prune only",
                                   "core.py recomputes all non-root MED lengths before event reconstruction"],
          "interpretation": "Performance equivalence check; no ancestry validation or history repair"}
(HERE / "conditional_cache_review.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"real_source_ordered_examples": len(checks), "all_outputs_identical": True}))
