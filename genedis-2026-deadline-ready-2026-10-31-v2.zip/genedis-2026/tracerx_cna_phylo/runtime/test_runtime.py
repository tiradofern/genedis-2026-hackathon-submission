"""Focused orchestration checks; run in the isolated Linux engine environment."""
from collections import Counter
import json
from pathlib import Path
import tempfile
import time
import unittest

import pandas as pd

import fit_worker
import run_patients

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sleeper(_):
    time.sleep(5)


class RuntimeOrchestrationTests(unittest.TestCase):
    def setUp(self):
        directory = HERE / "output/unit_fixtures"
        directory.mkdir(parents=True, exist_ok=True)
        self.temporary = tempfile.TemporaryDirectory(dir=directory)
        self.path = Path(self.temporary.name).resolve()
        self.path.relative_to(ROOT)  # Bound every automatic fixture cleanup.

    def tearDown(self):
        self.temporary.cleanup()

    def test_whole_autosome_resampling_preserves_blocks_regions_and_exact_calls(self):
        atoms = [{"chrom": "1", "pseudochrom": "chr10001"},
                 {"chrom": "1", "pseudochrom": "chr10002"},
                 {"chrom": "2", "pseudochrom": "chr20001"}]
        rows = []
        for index, atom in enumerate(atoms):
            for region, major, minor in (("synthetic_a", index + 1, 0), ("synthetic_b", index + 2, 1)):
                rows.append({"sample_id": region, "chrom": atom["pseudochrom"],
                             "start": index * 10, "end": index * 10 + 5,
                             "cn_a": major, "cn_b": minor})
        input_path = self.path / "input.tsv"
        original = pd.DataFrame(rows)
        original.to_csv(input_path, sep="\t", index=False)
        before = fit_worker.sha(input_path)
        mapping = self.path / "mapping.json"
        mapping.write_text(json.dumps({"atoms": atoms}))
        source = {"histology": "luad", "patient_id": "synthetic",
                  "input_path": input_path.relative_to(ROOT).as_posix(),
                  "mapping_path": mapping.relative_to(ROOT).as_posix()}
        first, metadata = fit_worker.make_bootstrap_input(source, self.path / "first.tsv", 0, 20261018)
        second, again = fit_worker.make_bootstrap_input(source, self.path / "second.tsv", 0, 20261018)
        self.assertEqual(fit_worker.sha(self.path / "first.tsv"), fit_worker.sha(self.path / "second.tsv"))
        self.assertEqual(metadata, again)
        self.assertEqual(fit_worker.sha(input_path), before)
        self.assertEqual(len(metadata["autosome_draws"]), 2)
        for draw_index, chromosome in enumerate(metadata["autosome_draws"]):
            take = first.loc[first.chrom.map(lambda value: (int(value[3:]) - 1000000) // 10000) == draw_index]
            blocks = {atom["pseudochrom"] for atom in atoms if atom["chrom"] == chromosome}
            expected = original.loc[original.chrom.isin(blocks)]
            columns = ["sample_id", "start", "end", "cn_a", "cn_b"]
            self.assertEqual(take[columns].sort_values(columns).values.tolist(), expected[columns].sort_values(columns).values.tolist())
            self.assertEqual(take.chrom.nunique(), len(blocks))
        self.assertTrue(first.equals(second))

    def test_every_patient_keeps_four_variants_and_twenty_planned_bootstrap_slots(self):
        inputs = {"jobs": []}
        for histology, role in (("luad", "training"), ("lusc", "evaluation")):
            for variant in ("primary", "gap100k", "highcopy_mask"):
                inputs["jobs"].append({"histology": histology, "patient_id": "synthetic_" + histology,
                    "role": role, "variant": variant, "sha256": "fixed", "source_status": "ready"})
        configs = {histology: {"random_seed": 20261018} for histology in ("luad", "lusc")}
        jobs = run_patients.plan_jobs(configs, inputs)
        self.assertEqual(len(jobs), 48)
        for histology, role in (("luad", "training"), ("lusc", "evaluation")):
            own = [job for job in jobs if job["histology"] == histology]
            self.assertEqual({job["role"] for job in own}, {role})
            bootstrap = [job for job in own if job["variant"].startswith("bootstrap_")]
            self.assertEqual({job["bootstrap_index"] for job in bootstrap}, set(range(20)))
            self.assertEqual(Counter(job["variant"] for job in own)["total_cn_topology"], 1)
            self.assertTrue(all(job["status"] == "planned" for job in own))

    def test_timeout_kills_only_owned_isolated_process_and_retains_status(self):
        original = run_patients.execute_worker
        run_patients.execute_worker = sleeper
        try:
            job = {"output_dir": self.path.relative_to(ROOT).as_posix(),
                   "source_variant": "primary", "timeout_seconds": 0.1, "attempts": []}
            running = run_patients.start_job(job)
            time.sleep(0.15)
            result = run_patients.finish_job(running, timed_out=True)
            self.assertEqual(result["status"], "timed_out")
            self.assertLess(result["attempts"][0]["returncode"], 0)
            self.assertEqual(len(result["attempts"]), 1)
            self.assertEqual(json.loads((self.path / "job_status.json").read_text())["status"], "timed_out")
        finally:
            run_patients.execute_worker = original


if __name__ == "__main__":
    unittest.main(verbosity=2)
