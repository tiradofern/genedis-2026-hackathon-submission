"""One isolated job using unchanged installed MEDICC2 functions.

Own code only prepares a declared diagnostic/resample and writes official output
objects. It does not alter the distance model, neighbor joining, ancestors or
event reconstruction. The parent enforces wall-clock limits on this process.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import time

import medicc
import numpy as np
import pandas as pd

from conditional_cache import lookup as cache_lookup, remember as cache_remember

ROOT = Path(__file__).resolve().parents[2]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n")


def relative(path):
    return Path(path).resolve().relative_to(ROOT).as_posix()


def validate_raw_frame(frame, alleles):
    if frame.empty or frame.duplicated(["sample_id", "chrom", "start", "end"]).any():
        raise ValueError("Empty or duplicated engine input")
    for column in alleles:
        if not pd.api.types.is_integer_dtype(frame[column]) or (frame[column] < 0).any():
            raise ValueError("Engine input must be nonnegative integers without rounding")
    if (frame.end <= frame.start).any():
        raise ValueError("Input intervals must be positive BED lengths")


def nondiploid_count(frame, alleles, baseline):
    changed = frame.loc[(frame[alleles] != baseline).any(axis=1), "sample_id"]
    return changed.nunique()


def make_total_input(source, destination):
    canonical = read(ROOT / source["canonical_path"])
    mapping = read(ROOT / source["mapping_path"])["atoms"]
    coordinates = {(str(atom["chrom"]), atom["start"], atom["end"]): atom for atom in mapping}
    rows = []
    for atom in canonical["atoms"]:
        key = (str(atom["chrom"]), atom["start"], atom["end"])
        if key not in coordinates:
            continue
        mapped = coordinates[key]
        for region in atom["regions"]:
            rows.append({"sample_id": region["sample_id"], "chrom": mapped["pseudochrom"],
                         "start": atom["start"], "end": atom["end"],
                         "cn_total": min(region["cn_major"] + region["cn_minor"], 8)})
    frame = pd.DataFrame(rows)
    validate_raw_frame(frame, ["cn_total"])
    frame.to_csv(destination, sep="\t", index=False)
    return frame


def make_bootstrap_input(source, destination, replica, seed):
    """Whole original autosomes, preserving every discontinuity block per draw."""
    mapping = read(ROOT / source["mapping_path"])["atoms"]
    block_chrom = {}
    for atom in mapping:
        block_chrom[atom["pseudochrom"]] = str(atom["chrom"])
    chromosomes = sorted(set(block_chrom.values()), key=int)
    identity = f"{seed}|{source['histology']}|{source['patient_id']}|{replica}"
    derived_seed = int.from_bytes(hashlib.sha256(identity.encode()).digest()[:8], "big")
    rng = np.random.default_rng(derived_seed)
    draws = rng.choice(chromosomes, size=len(chromosomes), replace=True).tolist()
    original = pd.read_csv(ROOT / source["input_path"], sep="\t")
    validate_raw_frame(original, ["cn_a", "cn_b"])
    pieces = []
    for draw_index, chromosome in enumerate(draws):
        blocks = sorted([block for block, chrom in block_chrom.items() if chrom == chromosome],
                        key=lambda block: int(block.removeprefix("chr")))
        for block_index, block in enumerate(blocks):
            piece = original.loc[original.chrom == block].copy()
            piece["chrom"] = f"chr{1000000 + draw_index * 10000 + block_index}"
            pieces.append(piece)
    frame = pd.concat(pieces, ignore_index=True)
    validate_raw_frame(frame, ["cn_a", "cn_b"])
    frame.to_csv(destination, sep="\t", index=False)
    return frame, {"replica": replica, "base_seed": seed, "derived_seed": derived_seed,
                   "original_autosomes": chromosomes, "autosome_draws": draws,
                   "resample_sha256": sha(destination),
                   "phasing": "Unresolved sorted major/minor; no evolutionary phasing"}


def official_fit(input_path, destination, prefix, *, total=False, topology_only=False, input_tree=None):
    alleles = ["cn_total"] if total else ["cn_a", "cn_b"]
    frame = pd.read_csv(input_path, sep="\t")
    validate_raw_frame(frame, alleles)
    input_df = medicc.io.read_and_parse_input_data(
        str(input_path), normal_name="diploid", input_type="tsv", allele_columns=alleles,
        maxcn=8, total_copy_numbers=total)
    # The official total-copy FST is +2; the major/minor FST is explicit x2.
    model = medicc.io.read_fst(total_copy_numbers=total, wgd_x2=not total)
    returned = medicc.main(input_df=input_df, asymm_fst=model,
                          normal_name="diploid", input_tree=input_tree,
                          ancestral_reconstruction=not topology_only,
                          allele_columns=alleles, wgd_x2=not total, total_cn=total,
                          no_wgd=False, n_cores=1, reconstruct_events=not topology_only)
    sample_labels, distances, _, tree, profiles, events = returned
    destination.mkdir(parents=True, exist_ok=True)
    stem = destination / prefix
    paths = {}
    medicc.io.write_tree_files(tree, normal_name="diploid", out_name=str(stem) + "_final_tree",
                              plot_tree=False, draw_ascii=False)
    paths["tree"] = relative(str(stem) + "_final_tree.new")
    paths["xml"] = relative(str(stem) + "_final_tree.xml")
    medicc.io.write_branch_lengths(tree, str(stem) + "_branch_lengths.tsv")
    paths["branches"] = relative(str(stem) + "_branch_lengths.tsv")
    if input_tree is None:
        medicc.io.write_pairwise_distances(sample_labels, distances, str(stem) + "_pairwise_distances")
        paths["distances"] = relative(str(stem) + "_pairwise_distances.tsv")
    # Official fixed-tree calls return a zero placeholder distance matrix. Omit it
    # rather than exposing those placeholders as calculated evolutionary distances.
    if not topology_only:
        profiles.to_csv(str(stem) + "_final_cn_profiles.tsv", sep="\t")
        events.to_csv(str(stem) + "_copynumber_events_df.tsv", sep="\t")
        paths["profiles"] = relative(str(stem) + "_final_cn_profiles.tsv")
        paths["events"] = relative(str(stem) + "_copynumber_events_df.tsv")
    summary = medicc.summarize_patient(tree, distances.values, sample_labels, "diploid", events)
    summary.to_csv(str(stem) + "_summary.tsv", index=True, header=False, sep="\t")
    paths["summary"] = relative(str(stem) + "_summary.tsv")
    return tree, paths, {
        "event_count": None if events is None else int(len(events)),
        "tree_length": float(tree.total_branch_length()),
        "global_event_count_equals_tree_length": None if events is None else len(events) == tree.total_branch_length(),
        "distance_status": "not_computed_fixed_topology" if input_tree is not None else "official_pairwise_MED",
        "wgd_model": "official_total_copy_+2" if total else "official_major_minor_x2",
        "profiles_columns": [] if topology_only else list(profiles.reset_index().columns),
        "events_columns": [] if topology_only else list(events.reset_index().columns),
        "interpretation": "Conditional sampled-region model output; history validity requires independent replay audit."}


def execute(job):
    source = job["source_job"]
    destination = ROOT / job["output_dir"]
    destination.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    record = {key: source[key] for key in ("histology", "patient_id", "role", "input_path",
                                          "mapping_path", "mapping_sha256", "canonical_path",
                                          "canonical_sha256", "primary_regions", "n_regions")}
    record.update(variant=job["variant"], normal_name="diploid", input_sha256=source["sha256"],
                  status="running", upstream_version=medicc.__version__)
    for key, field in (("input_path", "sha256"), ("mapping_path", "mapping_sha256"),
                       ("canonical_path", "canonical_sha256")):
        if sha(ROOT / source[key]) != source[field]:
            raise ValueError(f"Pinned source bytes changed: {key}")
    source_path = ROOT / source["input_path"]
    input_tree = None
    if job["variant"] == "total_cn_topology":
        diagnostic_input = destination / "total_cn_input.tsv"
        total_frame = make_total_input(source, diagnostic_input)
        if nondiploid_count(total_frame, ["cn_total"], 2) < 2:
            record.update(status="not_run_total_cn_uninformative", elapsed_s=time.monotonic()-start)
            write(destination / "worker_result.json", record)
            return
        input_tree, diagnostic_paths, diagnostic = official_fit(
            diagnostic_input, destination / "diagnostic", "total_cn", total=True, topology_only=True)
        record.update(diagnostic_paths=diagnostic_paths, diagnostic=diagnostic,
                      diagnostic_input_sha256=sha(diagnostic_input))
    elif job["variant"].startswith("bootstrap_"):
        replica = int(job["variant"].split("_")[-1])
        resampled = destination / "resampled_input.tsv"
        frame, resample_metadata = make_bootstrap_input(source, resampled, replica, job["seed"])
        record["bootstrap"] = resample_metadata
        if nondiploid_count(frame, ["cn_a", "cn_b"], 1) < 2:
            record.update(status="not_run_bootstrap_uninformative", elapsed_s=time.monotonic()-start)
            write(destination / "worker_result.json", record)
            return
        input_tree, diagnostic_paths, diagnostic = official_fit(
            resampled, destination / "resampled_topology", "bootstrap", topology_only=True)
        record.update(diagnostic_paths=diagnostic_paths, diagnostic=diagnostic)
    if input_tree is None:
        _, paths, fit = official_fit(source_path, destination, "medicc2")
    else:
        key, contract, cache_path, cached = cache_lookup(source, input_tree)
        if cached is None:
            _, paths, fit = official_fit(source_path, destination, "medicc2", input_tree=input_tree)
            cache_remember(key, contract, cache_path, paths, fit, job["variant"])
            record["conditional_refit_cache"] = {"hit": False, "key": key,
                                                 "contract_path": relative(cache_path)}
        else:
            paths, fit = cached["paths"], cached["fit"]
            record["conditional_refit_cache"] = {"hit": True, "key": key,
                "contract_path": relative(cache_path), "source_variant": cached["source_variant"],
                "interpretation": "Exact full-input conditional refit reused; this draw's topology was independently inferred."}
    record.update(status="success", paths=paths, fit=fit,
                  output_hashes={key: sha(ROOT / value) for key, value in paths.items()},
                  elapsed_s=time.monotonic()-start)
    write(destination / "worker_result.json", record)


if __name__ == "__main__":
    execute(read(sys.argv[1]))
