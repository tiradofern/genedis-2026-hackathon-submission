#!/usr/bin/env bash
# Isolated upstream MEDICC2 install in the pre-existing Ubuntu WSL2 distribution.
set -euo pipefail
runtime_root="$(cd -- "$(dirname -- "$0")" && pwd)"
source_commit=04e9bfec8a9b8fb585a703c5a10d6ee62bec7b35
source_root="$runtime_root/raw/medicc2"
native_root="${XDG_CACHE_HOME:-$HOME/.cache}/genedis-cna-medicc2-04e9bfec"
export MAMBA_ROOT_PREFIX="$native_root/mamba-root"
manager="$runtime_root/.runtime/micromamba/bin/micromamba"
prefix="$native_root/env"
mkdir -p "$runtime_root/raw" "$runtime_root/output"
mkdir -p "$native_root"
# Reuse downloaded package archives from an interrupted NTFS attempt; no source
# or output files are moved or deleted. Micromamba verifies their checksums.
for subdir in linux-64 noarch; do
  prior="$runtime_root/.runtime/mamba-root/pkgs/https/conda.anaconda.org/conda-forge/$subdir"
  current="$MAMBA_ROOT_PREFIX/pkgs/https/conda.anaconda.org/conda-forge/$subdir"
  mkdir -p "$current"
  for archive in "$prior"/*.conda "$prior"/*.tar.bz2; do
    if [[ -f "$archive" && ! -f "$current/$(basename -- "$archive")" ]]; then
      cp -- "$archive" "$current/"
    fi
  done
done
if [[ ! -f "$manager" ]]; then
  curl --fail --location https://conda.anaconda.org/conda-forge/linux-64/micromamba-2.9.0-0.tar.bz2 \
    -o "$runtime_root/raw/micromamba-linux-64.tar.bz2"
  python3 "$runtime_root/extract_micromamba.py"
fi
if [[ ! -d "$source_root/.git" ]]; then
  git clone --no-checkout https://github.com/schwarzlab-ccb/medicc2.git "$source_root"
  git -C "$source_root" checkout --detach "$source_commit"
  git -C "$source_root" submodule update --init --recursive
fi
test "$(git -C "$source_root" rev-parse HEAD)" = "$source_commit"
if [[ -f "$runtime_root/conda-linux-64.lock.txt" ]]; then
  "$manager" create -y -p "$prefix" --file "$runtime_root/conda-linux-64.lock.txt"
else
  "$manager" create -y -p "$prefix" -c conda-forge --strict-channel-priority \
    python=3.10 openfst=1.8.4 numpy=1.26.4 pandas=2.0.3 cython=3.1.2 \
    pyyaml joblib biopython scipy matplotlib pip setuptools gxx_linux-64
fi
"$manager" run -p "$prefix" python -m pip install --no-build-isolation --no-deps "$source_root"
"$manager" run -p "$prefix" medicc2 --version
"$manager" list -p "$prefix" --explicit > "$runtime_root/output/conda-explicit.txt"
