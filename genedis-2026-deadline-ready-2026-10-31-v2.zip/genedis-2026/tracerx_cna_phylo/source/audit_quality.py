"""Audit exact frozen primary-region genome-wide SCNA coverage before fitting."""
from __future__ import annotations
import csv
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / 'tracerx_cna_phylo/source'
OUT = HERE / 'output'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def sample_key(value):
    return re.sub(r'([.-])((?:R|LN)\d+)$', r'.\2', value)

def source_scope():
    scope = []
    for hist, name in [('luad', 'cohort_trees.json'), ('lusc', 'lusc/cohort_trees.json')]:
        tree_path = ROOT / 'tracerx_routes/source/output' / name
        context = read(ROOT / f'tracerx_expanded/source/output/{hist}/cna_context.json')
        roles = {p['patient_id']: p['role'] for p in context['patients']}
        for p in read(tree_path)['patients']:
            primary = [sample_key(r) for r in p['region_ids'] if re.search(r'[.-]R\d+$', r)]
            assert len(primary) == p['n_primary_regions'] >= 2
            scope.append(dict(histology=hist, patient_id=p['patient_id'], tumour_id=p['tumour_id'], role=roles[p['patient_id']], primary_regions=primary))
    assert len(scope) == 342 and len({p['patient_id'] for p in scope}) == 342
    return scope

def segment_rows(name):
    with (OUT / f'{name}_frozen_full.tsv').open(encoding='utf-8', newline='') as f:
        yield from csv.DictReader(f, delimiter='\t')

def main():
    scope = source_scope()
    by_region = defaultdict(list)
    seq_boundaries = defaultdict(lambda: (set(), set()))
    for row in segment_rows('scna'):
        by_region[sample_key(row['sample'])].append(row)
    for row in segment_rows('sequenza'):
        key = (sample_key(row['sample']), row['chr'])
        seq_boundaries[key][0].add(int(row['startpos']))
        seq_boundaries[key][1].add(int(row['endpos']))
    aggregate = {}
    patient_audits = []
    for hist in ('luad', 'lusc'):
        count = Counter()
        maxes = defaultdict(int)
        span_summaries = []
        for p in [q for q in scope if q['histology'] == hist]:
            samples = p['primary_regions']
            count['patients'] += 1
            count['primary_regions'] += len(samples)
            raw = {s: by_region[s] for s in samples}
            assert all(raw.values())
            audit = dict(p, rows=sum(len(r) for r in raw.values()), chromosomes=[], gaps=0, gap_bp=0, overlap_rows=0, high_copy_rows=0, raw_noninteger_rows=0, common_covered_bp=0, common_supported_le8_bp=0)
            count['rows'] += audit['rows']
            for chrom in map(str, range(1, 23)):
                reg = {}
                for sample in samples:
                    rows = sorted([r for r in raw[sample] if r['chr'] == chrom],key=lambda r:int(r['startpos']))
                    reg[sample] = rows
                    maxes['largest_source_segments_in_one_region_chromosome'] = max(maxes['largest_source_segments_in_one_region_chromosome'],len(rows))
                    prior_end = None
                    for r in rows:
                        source_start, end = int(r['startpos']),int(r['endpos'])
                        start = source_start-1  # verified original GRanges one-based closed input
                        a, b = int(r['nMajor']),int(r['nMinor'])
                        assert a>=b>=0 and a+b==int(r['cnTotal']) and end>start>=0
                        count['major_above8_rows'] += a>8
                        count['minor_above8_rows'] += b>8
                        audit['high_copy_rows'] += a>8 or b>8
                        audit['raw_noninteger_rows'] += any(float(r[x])!=int(float(r[x])) for x in ('nAraw','nBraw'))
                        starts, ends = seq_boundaries[(sample, chrom)]
                        count['SCNA_start_matches_Sequenza_start'] += source_start in starts
                        count['SCNA_start_plus1_matches_Sequenza_start'] += source_start+1 in starts
                        count['SCNA_end_matches_Sequenza_end'] += end in ends
                        count['SCNA_end_minus1_matches_Sequenza_end'] += end-1 in ends
                        if prior_end is not None:
                            gap = start-prior_end
                            if gap>0:
                                audit['gaps'] += 1; audit['gap_bp'] += gap
                                count['interior_gaps'] += 1; count['interior_gap_bp'] += gap
                                maxes['largest_interior_gap_bp']=max(maxes['largest_interior_gap_bp'],gap)
                                for threshold in (1000,10000,100000,1000000):
                                    if gap>=threshold:
                                        count[f'regional_gaps_ge_{threshold}bp'] += 1
                                        count[f'regional_gap_bp_ge_{threshold}bp'] += gap
                            elif gap<0:
                                audit['overlap_rows'] += 1; count['overlap_rows'] += 1
                        prior_end = max(prior_end or 0,end)
                if not all(reg.values()):
                    count['patient_chromosomes_missing_one_or_more_regions'] += 1
                    continue
                audit['chromosomes'].append(chrom)
                bounds = sorted({value for rr in reg.values() for r in rr for value in (int(r['startpos'])-1,int(r['endpos']))})
                positions = {s:0 for s in samples}
                last_valid_end = None
                for start,end in zip(bounds,bounds[1:]):
                    covering=[]
                    for s,rr in reg.items():
                        while positions[s]<len(rr) and int(rr[positions[s]]['endpos'])<=start: positions[s]+=1
                        i=positions[s]
                        covering.append(rr[i] if i<len(rr) and int(rr[i]['startpos'])-1<=start and int(rr[i]['endpos'])>=end else None)
                    count['union_breakpoint_atoms'] += 1
                    if not all(covering):
                        count['atoms_uncovered_in_some_region'] += 1
                        count['bp_uncovered_in_some_region'] += end-start
                        continue
                    audit['common_covered_bp'] += end-start
                    count['common_covered_atoms'] += 1; count['common_covered_bp'] += end-start
                    if any(int(r['nMajor'])>8 or int(r['nMinor'])>8 for r in covering):
                        count['common_high_copy_excluded_atoms'] += 1;count['common_high_copy_excluded_bp'] += end-start
                        continue
                    audit['common_supported_le8_bp'] += end-start
                    count['common_supported_le8_atoms'] += 1;count['common_supported_le8_bp'] += end-start
                    if last_valid_end != start: count['valid_contiguous_blocks'] += 1
                    last_valid_end=end
            audit['supported_fraction_of_common_covered'] = audit['common_supported_le8_bp']/audit['common_covered_bp'] if audit['common_covered_bp'] else None
            count['patients_with_high_copy'] += audit['high_copy_rows']>0
            count['patients_with_gaps'] += audit['gaps']>0
            count['patients_with_overlaps'] += audit['overlap_rows']>0
            span_summaries.append(audit['common_covered_bp'])
            patient_audits.append(audit)
        aggregate[hist] = {'counts':dict(count), 'maxima':dict(maxes), 'common_covered_bp_per_patient_min':min(span_summaries),'common_covered_bp_per_patient_max':max(span_summaries)}
    (OUT/'patient_quality_audit.json').write_text(json.dumps(patient_audits,indent=2)+'\n',encoding='utf-8')
    result=dict(status='pre_fit_source_quality_only',source_scope='exact frozen primary R regions; original patient roles retained',coordinate_comparison='Legacy Refphase GRanges input explicitly one-based closed. Convert SCNA startpos-1,endpos to BED. Endpoint comparisons alone do not establish convention.',aggregate=aggregate,source_hashes={str(path.relative_to(ROOT)).replace('\\','/'):digest(path) for path in [ROOT/'tracerx_expanded/source/raw/20221109_TRACERx421_scna_table.fst',ROOT/'tracerx_expanded/source/raw/20221108_sequenza_seg_df_cruk.fst']})
    (HERE/'source_quality_audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
