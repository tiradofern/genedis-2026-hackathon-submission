"""Retrieve only pinned public reference/generation-code files; verify bytes."""
from __future__ import annotations
import json
import os
import subprocess
import urllib.request
from pathlib import Path
from audit_quality import HERE,digest

def retrieve():
    manifest=json.loads((HERE/'reference_manifest.json').read_text(encoding='utf-8'))
    raw=HERE/'raw';raw.mkdir(exist_ok=True,parents=True)
    for entry in manifest['files']:
        path=raw/entry['filename']
        if not path.exists() or digest(path)!=entry['sha256']:
            if os.name=='nt':
                # Windows' trusted certificate store includes the host's configured roots.
                quote=lambda s:"'"+str(s).replace("'","''")+"'"
                command='$ErrorActionPreference="Stop"; Invoke-WebRequest -Uri '+quote(entry['url'])+' -OutFile '+quote(path)
                subprocess.run(['powershell.exe','-NoProfile','-Command',command],check=True)
            else:
                with urllib.request.urlopen(entry['url'],timeout=90) as response:path.write_bytes(response.read())
        if path.stat().st_size!=entry['bytes'] or digest(path)!=entry['sha256']:raise ValueError('Reference mismatch: '+entry['filename'])
    print('All pinned public references verified.')

if __name__=='__main__':retrieve()
