"""Independent fidelity/geometry checks of the real source-to-engine translation."""
import csv
import gzip
import json
import re
import unittest
from collections import Counter,defaultdict
from pathlib import Path
from audit_quality import ROOT,HERE,OUT,digest,read,source_scope,sample_key,segment_rows

class SourceChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.canonical=read(OUT/'canonical_manifest.json')
        cls.jobs=read(OUT/'input_manifest.json')
        cls.original_rows={int(r['source_row_index']):r for r in segment_rows('scna')}

    def test_01_pinned_public_sources_and_references(self):
        old=ROOT/'tracerx_expanded/source'
        for e in read(old/'source_manifest.json')['files']:
            self.assertEqual(digest(old/'raw'/e['filename']),e['sha256'])
        for e in read(HERE/'reference_manifest.json')['files']:
            self.assertEqual(digest(HERE/'raw'/e['filename']),e['sha256'])
        self.assertEqual(digest(HERE/'hg19_arms.json'),self.canonical['arms_sha256'])

    def test_02_exact_original_patient_roles_and_primary_regions(self):
        scope={p['patient_id']:p for p in source_scope()}
        original_roles={}
        for h,suffix in [('luad',''),('lusc','lusc/')]:
            source=read(ROOT/f'tracerx_routes/inference/output/{suffix}model.json')
            for original_patient in source['patients']:
                original_roles[original_patient['id']]=(h,original_patient['role'])
        self.assertEqual(len(scope),342)
        for p in self.canonical['patients']:
            original=scope[p['patient_id']]
            for key in ('patient_id','tumour_id','histology','role','primary_regions'):self.assertEqual(p[key],original[key])
            self.assertEqual((p['histology'],p['role']),original_roles[p['patient_id']])
            self.assertGreaterEqual(p['n_regions'],2)
            self.assertTrue(all(re.search(r'\.R\d+$',r) for r in p['primary_regions']))
        self.assertEqual(Counter(p['histology'] for p in scope.values()),{'luad':217,'lusc':125})
        self.assertEqual(Counter((p['histology'],p['role']) for p in scope.values()),{('luad','training'):152,('luad','evaluation'):65,('lusc','training'):88,('lusc','evaluation'):37})

    def test_03_source_coordinate_and_phasing_evidence(self):
        code=(HERE/'raw/legacy_minimum_consistent_segmentation_functions.R').read_text(encoding='utf-8')
        self.assertIn('starts.in.df.are.0based=FALSE',code)
        code=(HERE/'raw/legacy_final_output_segmentation_file_generation_functions_v3.R').read_text(encoding='utf-8')
        self.assertIn('ret.mrc$nAraw <- max(',code)
        self.assertIn('ret.mrc$nBraw <- min(',code)
        self.assertIn('ret.mrc$ph_int_cpnA',code)
        for row in self.original_rows.values():
            self.assertGreaterEqual(float(row['nAraw']),float(row['nBraw']))
            self.assertGreaterEqual(int(row['nMajor']),int(row['nMinor']))

    def test_04_every_canonical_atom_matches_exact_original_source_row(self):
        for p in self.canonical['patients']:
            path=ROOT/p['canonical_path'];self.assertEqual(digest(path),p['sha256'])
            data=read(path)
            last={}
            for a in data['atoms']:
                self.assertEqual(a['observed_bp'],a['end']-a['start'])
                self.assertEqual(len(a['regions']),p['n_regions'])
                self.assertGreater(a['end'],a['start'])
                self.assertGreaterEqual(a['start'],last.get(a['chrom'],0));last[a['chrom']]=a['end']
                self.assertEqual({r['sample_id'] for r in a['regions']},set(p['primary_regions']))
                for r in a['regions']:
                    src=self.original_rows[r['source_row_index']]
                    self.assertEqual(r['sample_id'],sample_key(src['sample']))
                    self.assertEqual(a['chrom'],src['chr'])
                    self.assertGreaterEqual(a['start'],int(src['startpos'])-1)
                    self.assertLessEqual(a['end'],int(src['endpos']))
                    self.assertEqual((r['cn_major'],r['cn_minor'],r['cn_total']),(int(src['nMajor']),int(src['nMinor']),int(src['cnTotal'])))
                    self.assertEqual(r['source_startpos'],int(src['startpos']))
                    self.assertEqual(r['source_endpos'],int(src['endpos']))

    def test_05_arm_reference_uses_real_cytobands_and_excludes_centromeres(self):
        bands=defaultdict(list)
        with gzip.open(HERE/'raw/hg19_cytoBand.txt.gz','rt') as f:
            for line in f:
                chrom,start,end,band,stain=line.rstrip().split('\t')
                if stain!='acen':bands[(chrom[3:],band[0])].append((int(start),int(end)))
        arms=read(HERE/'hg19_arms.json')['arms'];self.assertEqual(len(arms),44)
        for a in arms:
            raw=bands[(a['chrom'],a['id'][-1])]
            self.assertEqual((a['start'],a['end']),(min(r[0] for r in raw),max(r[1] for r in raw)))

    def test_06_every_engine_input_has_exact_common_segmentation_and_preserved_uncapped_calls(self):
        self.assertEqual(len(self.jobs['jobs']),342*3)
        for job in self.jobs['jobs']:
            path=ROOT/job['input_path'];self.assertEqual(digest(path),job['sha256'])
            self.assertEqual(digest(ROOT/job['mapping_path']),job['mapping_sha256'])
            data=read(ROOT/job['canonical_path']);canonical={(a['chrom'],a['start'],a['end']):a for a in data['atoms']}
            mapping=read(ROOT/job['mapping_path'])['atoms']
            lookup={(a['pseudochrom'],a['start'],a['end']):a for a in mapping}
            by_sample=defaultdict(list)
            with path.open(newline='',encoding='utf-8') as f:
                for r in csv.DictReader(f,delimiter='\t'):
                    key=(r['chrom'],int(r['start']),int(r['end']));m=lookup[key]
                    self.assertRegex(r['chrom'],r'^chr\d+$')
                    self.assertGreater(int(r['chrom'][3:]),24)
                    self.assertEqual(m['observed_bp'],key[2]-key[1])
                    src=canonical[(m['chrom'],key[1],key[2])]
                    region=next(q for q in src['regions'] if q['sample_id']==r['sample_id'])
                    self.assertEqual((int(r['cn_a']),int(r['cn_b'])),(min(region['cn_major'],8),min(region['cn_minor'],8)))
                    by_sample[r['sample_id']].append(key)
            self.assertEqual(set(by_sample),set(job['primary_regions']))
            signatures=list(by_sample.values());self.assertTrue(all(x==signatures[0] for x in signatures))
            self.assertEqual(len(signatures[0]),job['n_segments'])

    def test_07_high_copy_mask_removes_whole_shared_interval_and_no_other_interval(self):
        for job in [j for j in self.jobs['jobs'] if j['variant']=='highcopy_mask']:
            atoms=read(ROOT/job['canonical_path'])['atoms']
            expected={(a['chrom'],a['start'],a['end']) for a in atoms if all(r['cn_major']<=8 and r['cn_minor']<=8 for r in a['regions'])}
            mapping=read(ROOT/job['mapping_path'])['atoms']
            self.assertEqual({(a['chrom'],a['start'],a['end']) for a in mapping},expected)
            self.assertEqual(job['caps'].get('regional_atoms_capped',0),0)

    def test_08_gap_blocks_do_not_bridge_gaps_over_fixed_threshold(self):
        for job in self.jobs['jobs']:
            data=read(ROOT/job['mapping_path']);atoms=data['atoms'];threshold=data['gap_threshold_bp']
            self.assertEqual(threshold,100000 if job['variant']=='gap100k' else 1000000)
            prior=None;seen={}
            for a in atoms:
                if a['pseudochrom'] in seen:self.assertEqual(seen[a['pseudochrom']],a['chrom'])
                seen[a['pseudochrom']]=a['chrom']
                if prior is not None:
                    must_split=a['chrom']!=prior['chrom'] or a['start']-prior['end']>threshold
                    self.assertEqual(a['pseudochrom']!=prior['pseudochrom'],must_split)
                prior=a

    def test_09_config_and_input_manifest_lock_integrity(self):
        freeze=ROOT/self.jobs['config_freeze_path']
        self.assertEqual(digest(freeze),self.jobs['config_freeze_sha256'])
        self.assertEqual(digest(OUT/'canonical_manifest.json'),self.jobs['canonical_manifest_sha256'])
        for job in self.jobs['jobs']:
            self.assertEqual(job['config_freeze_sha256'],self.jobs['config_freeze_sha256'])
            self.assertEqual(digest(ROOT/job['canonical_path']),job['canonical_sha256'])

    def test_10_versioned_aggregate_artifacts_have_no_patient_identifiers(self):
        for path in HERE.glob('*.json'):
            self.assertIsNone(re.search(r'CRUK\d{4}|TCGA-[A-Z0-9]{2}-[A-Z0-9]{4}',path.read_text(encoding='utf-8')),str(path))

if __name__=='__main__':unittest.main()
