"""Descriptive UCSC gap overlap; does not change the frozen continuity policy."""
import gzip
import json
from collections import Counter,defaultdict
from audit_quality import HERE,OUT,ROOT,read,digest

def main():
    reference=defaultdict(list)
    with gzip.open(HERE/'raw/hg19_gap.txt.gz','rt') as f:
        for line in f:
            fields=line.rstrip().split('\t')
            reference[fields[1][3:]].append((int(fields[2]),int(fields[3]),fields[7]))
    result={hist:Counter() for hist in ('luad','lusc')}
    for p in read(OUT/'canonical_manifest.json')['patients']:
        counts=result[p['histology']]
        for gap in read(ROOT/p['canonical_path'])['unmeasured_intervals']:
            start,end=gap['start'],gap['end'];width=end-start
            counts['unmeasured_atoms']+=1;counts['unmeasured_bp']+=width
            if width>1000000:counts['unmeasured_atoms_over_1Mb']+=1;counts['unmeasured_bp_over_1Mb']+=width
            overlap=0
            for a,b,kind in reference[gap['chrom']]:
                n=max(0,min(end,b)-max(start,a))
                overlap+=n;counts['assembly_gap_overlap_bp_'+kind]+=n
            counts['non_assembly_gap_unmeasured_bp']+=width-overlap
    payload=dict(status='descriptive_only_no_policy_change',ucsc_gap_sha256=digest(HERE/'raw/hg19_gap.txt.gz'),canonical_manifest_sha256=digest(OUT/'canonical_manifest.json'),aggregate={h:{k:v for k,v in n.items() if v} for h,n in result.items()},scope='Unknown intervals within observed chromosome envelopes; terminal unobserved bases are not included here and remain unknown in full-arm coverage.')
    (HERE/'assembly_gap_audit.json').write_text(json.dumps(payload,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(payload['aggregate']))

if __name__=='__main__':main()
