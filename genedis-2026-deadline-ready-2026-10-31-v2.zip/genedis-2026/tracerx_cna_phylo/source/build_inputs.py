"""Faithful genome-wide SCNA canonicalization, then frozen MEDICC2 inputs.

Canonical mode does not fit trees or select events. Engine exports require the
root-owned configuration freeze; no missing segment becomes a diploid call.
"""
from __future__ import annotations
import argparse
import csv
import gzip
import json
from collections import Counter, defaultdict
from pathlib import Path
from audit_quality import ROOT, HERE, OUT, digest, read, sample_key, source_scope, segment_rows

def dump(path, value):
    path.parent.mkdir(exist_ok=True, parents=True)
    path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')

def common_atoms(region_rows, samples):
    """Union breakpoints; retain only exact measured overlap of every region."""
    atoms=[]
    unknown=[]
    for chrom in map(str, range(1,23)):
        reg={s:sorted((r for r in region_rows[s] if r['chr']==chrom),key=lambda r:int(r['startpos'])) for s in samples}
        bounds=sorted({v for rr in reg.values() for r in rr for v in (int(r['startpos'])-1,int(r['endpos']))})
        pos={s:0 for s in samples}
        for start,end in zip(bounds,bounds[1:]):
            covering=[]
            for s in samples:
                rr=reg[s]
                while pos[s]<len(rr) and int(rr[pos[s]]['endpos'])<=start: pos[s]+=1
                i=pos[s]
                covering.append(rr[i] if i<len(rr) and int(rr[i]['startpos'])-1<=start and int(rr[i]['endpos'])>=end else None)
            if not all(covering):
                unknown.append({'chrom':chrom,'start':start,'end':end,'unmeasured_regions':[s for s,r in zip(samples,covering) if r is None]})
                continue
            values=[]
            for s,r in zip(samples,covering):
                a,b=int(r['nMajor']),int(r['nMinor'])
                if not (a>=b>=0 and a+b==int(r['cnTotal'])): raise ValueError('Invalid source integer calls')
                values.append(dict(sample_id=s,cn_major=a,cn_minor=b,cn_total=int(r['cnTotal']),source_row_index=int(r['source_row_index']),source_sample=r['sample'],source_startpos=int(r['startpos']),source_endpos=int(r['endpos']),n_het=int(r['n.het']),MSAI=None if not r['MSAI'] else r['MSAI']=='TRUE',samp_used_to_phase=r['samp_used_to_phase']))
            atoms.append(dict(chrom=chrom,start=start,end=end,observed_bp=end-start,regions=values))
    return atoms,unknown

def reference_arms():
    p=HERE/'raw/hg19_cytoBand.txt.gz'
    by_arm=defaultdict(list)
    with gzip.open(p,'rt') as f:
        for line in f:
            chrom,start,end,band,stain=line.rstrip('\n').split('\t')
            if chrom[3:] not in {str(i) for i in range(1,23)} or stain=='acen': continue
            by_arm[(chrom[3:],band[0])].append((int(start),int(end)))
    arms=[]
    for chrom in map(str,range(1,23)):
        for arm in ('p','q'):
            intervals=by_arm[(chrom,arm)]
            arms.append(dict(id=f'{chrom}{arm}',chrom=chrom,start=min(x[0] for x in intervals),end=max(x[1] for x in intervals),coordinate_convention='BED0_half_open',centromeric_acen_bands_excluded=True))
    assert len(arms)==44
    dump(HERE/'hg19_arms.json',dict(reference='UCSC hg19 cytoBand.txt.gz',sha256=digest(p),arms=arms))
    legacy_commit='ba84892f854031227aa60d674da07a75922b95f3'
    files=[]
    for name in ('hg19_cytoBand.txt.gz','hg19_gap.txt.gz'):
        path=HERE/'raw'/name
        remote='cytoBand.txt.gz' if 'cytoBand' in name else 'gap.txt.gz'
        files.append(dict(filename=name,url=f'https://hgdownload.soe.ucsc.edu/goldenPath/hg19/database/{remote}',bytes=path.stat().st_size,sha256=digest(path)))
    for path in sorted((HERE/'raw').glob('legacy_*.R')):
        files.append(dict(filename=path.name,url=f'https://api.bitbucket.org/2.0/repositories/schwarzlab/refphase-legacy/src/{legacy_commit}/{path.name[7:]}',bytes=path.stat().st_size,sha256=digest(path)))
    dump(HERE/'reference_manifest.json',dict(legacy_refphase_commit=legacy_commit,files=files,coordinate_evidence={'file':'legacy_minimum_consistent_segmentation_functions.R','input':'makeGRangesFromDataFrame starts.in.df.are.0based=FALSE','output':'GRanges start and end renamed directly to startpos/endpos','bed_conversion':'start=startpos-1;end=endpos'},phasing_evidence={'file':'legacy_final_output_segmentation_file_generation_functions_v3.R','lines':'225-235 and448-458','finding':'nAraw/nBraw are max/min sorted continuous estimates; nMajor/nMinor sorted source integers; distinct ph_int_cpnA/B hold phase and are absent from deposited SCNA table'}))
    return arms

def canonical():
    arms=reference_arms()
    by_region=defaultdict(list)
    for r in segment_rows('scna'): by_region[sample_key(r['sample'])].append(r)
    patients=[]
    aggs={h:Counter() for h in ('luad','lusc')}
    for p in source_scope():
        samples=p['primary_regions']
        atoms,unknown=common_atoms(by_region,samples)
        value=dict(schema_version='1.0',**p,copy_number_status='unphased_major_minor',coordinate_convention='BED0_half_open; original source 1-based closed coordinates retained per regional record',atoms=atoms,unmeasured_intervals=unknown,limitations=['Bulk regional copy-number profiles are mixtures, not purified tumour clones.','Major/minor source sorting discards consistent parental haplotype identity.','Unmeasured bases and missing regional segments are not diploid.'])
        path=OUT/f'canonical/{p["histology"]}/{p["patient_id"]}.json'
        dump(path,value)
        item={**p,'canonical_path':path.relative_to(ROOT).as_posix(),'sha256':digest(path),'n_regions':len(samples),'n_segments':len(atoms),'observed_bp':sum(a['observed_bp'] for a in atoms),'unmeasured_bp':sum(a['end']-a['start'] for a in unknown)}
        patients.append(item)
        agg=aggs[p['histology']]
        agg['patients']+=1;agg['regions']+=len(samples);agg['atoms']+=len(atoms);agg['observed_bp']+=item['observed_bp'];agg['unmeasured_bp']+=item['unmeasured_bp']
    dump(OUT/'canonical_manifest.json',dict(schema_version='1.0',patients=patients,reference_manifest_sha256=digest(HERE/'reference_manifest.json'),arms_sha256=digest(HERE/'hg19_arms.json'),source_scna_sha256=digest(ROOT/'tracerx_expanded/source/raw/20221109_TRACERx421_scna_table.fst'),scope_source_sha256={h:digest(ROOT/f'tracerx_routes/source/output/{"" if h=="luad" else "lusc/"}cohort_trees.json') for h in ('luad','lusc')}))
    dump(HERE/'canonical_audit.json',dict(status='source_canonicalization_only_no_fit',copy_number_status='unphased_major_minor',coordinate_convention='BED0_half_open',aggregate={k:dict(v) for k,v in aggs.items()},canonical_manifest_sha256=digest(OUT/'canonical_manifest.json'),reference_manifest_sha256=digest(HERE/'reference_manifest.json'),arms_sha256=digest(HERE/'hg19_arms.json')))
    print(json.dumps({k:dict(v) for k,v in aggs.items()}))

def variant_atoms(atoms, variant, gap_bp):
    """No call invented: compact only adjacency bookkeeping into numeric blocks."""
    selected=[]
    block_count=Counter()
    prior=None
    for atom in atoms:
        if variant=='highcopy_mask' and any(r['cn_major']>8 or r['cn_minor']>8 for r in atom['regions']): continue
        if prior is None or atom['chrom']!=prior['chrom'] or atom['start']-prior['end']>gap_bp:
            block_count[atom['chrom']]+=1
        block=block_count[atom['chrom']]
        # Official MEDICC2 parser collapses suffix labels, so use unique numbers.
        pseudo=f'chr{int(atom["chrom"])*10000+block}'
        selected.append(dict(atom,pseudochrom=pseudo,block=block))
        prior=atom
    return selected

def write_tsv(path,records):
    path.parent.mkdir(exist_ok=True,parents=True)
    with path.open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['sample_id','chrom','start','end','cn_a','cn_b'],delimiter='\t',lineterminator='\n')
        writer.writeheader();writer.writerows(records)

def engine_inputs(freeze_path):
    freeze_path=freeze_path.resolve()
    if not freeze_path.is_file(): raise ValueError('A root-owned config freeze is required')
    freeze=read(freeze_path)
    locks={'canonical_manifest_sha256':OUT/'canonical_manifest.json','reference_manifest_sha256':HERE/'reference_manifest.json','arms_sha256':HERE/'hg19_arms.json'}
    for key,path in locks.items():
        if digest(path)!=freeze[key]:raise ValueError('Frozen source lock changed: '+key)
    configurations={}
    for entry in freeze['configurations']:
        path=ROOT/entry['path']
        if digest(path)!=entry['sha256'] or path.stat().st_size!=entry['bytes']:raise ValueError('Frozen configuration changed')
        config=read(path);configurations[entry['cohort']]=config
        for key in ('canonical_manifest','reference_manifest','arms'):
            if digest(ROOT/config['source'][key+'_path'])!=config['source'][key+'_sha256']:raise ValueError('Config source lock changed: '+key)
        prior=config['source']['previous_source_manifest_path']
        if digest(ROOT/prior)!=config['source']['previous_source_manifest_sha256']:raise ValueError('Prior source manifest changed')
        quality=config['input_quality'];engine=config['engine']
        if (quality['primary_gap_threshold_bp'],quality['gap_sensitivity_threshold_bp'],quality['minimum_required_primary_regions'],quality['minimum_nondiploid_primary_regions'])!=(1000000,100000,2,2):raise ValueError('Unimplemented source quality policy')
        if engine['primary_per_allele_cap']!=8 or engine['maxcn']!=8 or engine['internal_evolutionary_phasing'] is not False:raise ValueError('Unimplemented engine input policy')
        variants={x['variant'] for x in config['sensitivities']}
        if variants!={'highcopy_mask','gap100k','total_cn_topology'}:raise ValueError('Unimplemented variants')
        if digest(ROOT/config['cohort']['frozen_source_path'])!=config['cohort']['frozen_source_sha256']:raise ValueError('Frozen cohort changed')
    if set(configurations)!={'luad','lusc'}:raise ValueError('Both separate histology configurations required')
    # Root froze these exact explicit settings, checked above before any export.
    expected={'primary':1000000,'gap100k':100000,'highcopy_mask':1000000}
    manifest=read(OUT/'canonical_manifest.json')
    jobs=[];aggregate={h:Counter() for h in ('luad','lusc')}
    for p in manifest['patients']:
        path=ROOT/p['canonical_path']
        if digest(path)!=p['sha256']: raise ValueError('Canonical bytes changed')
        value=read(path)
        for variant,gap in expected.items():
            selected=variant_atoms(value['atoms'],variant,gap)
            rows=[];caps=Counter();non_diploid=set()
            for atom in selected:
                for r in atom['regions']:
                    a,b=r['cn_major'],r['cn_minor']
                    if a>8 or b>8: caps['regional_atoms_capped']+=1;caps['regional_bp_capped']+=atom['observed_bp']
                    a,b=min(a,8),min(b,8)
                    if (a,b)!=(1,1): non_diploid.add(r['sample_id'])
                    rows.append(dict(sample_id=r['sample_id'],chrom=atom['pseudochrom'],start=atom['start'],end=atom['end'],cn_a=a,cn_b=b))
            path=OUT/f'inputs/{p["histology"]}/{p["patient_id"]}/{variant}.tsv'
            write_tsv(path,rows)
            map_path=path.with_suffix('.mapping.json')
            mapping=[{k:a[k] for k in ('chrom','pseudochrom','block','start','end','observed_bp')} for a in selected]
            dump(map_path,dict(atoms=mapping,gap_threshold_bp=gap,omitted_gaps_are_adjacent_within_block=True,unknown_bases_imputed=False))
            item={k:p[k] for k in ('histology','patient_id','tumour_id','role','primary_regions','n_regions')}
            item.update(variant=variant,input_path=path.relative_to(ROOT).as_posix(),n_segments=len(selected),n_blocks=len({a['pseudochrom'] for a in selected}),sha256=digest(path),mapping_path=map_path.relative_to(ROOT).as_posix(),mapping_sha256=digest(map_path),canonical_path=p['canonical_path'],canonical_sha256=p['sha256'],normal_name='diploid',source_status='ready' if len(non_diploid)>=2 and selected else 'not_run_less_than_two_nondiploid_regions',n_nondiploid_regions=len(non_diploid),caps=dict(caps),input_call_status='unphased_major_minor_with_explicit_per_allele_cap8',config_freeze_sha256=digest(freeze_path))
            jobs.append(item)
            aggregate[p['histology']][f'{variant}_patients']+=1
            aggregate[p['histology']][f'{variant}_segments']+=len(selected)
            aggregate[p['histology']][f'{variant}_regional_atoms_capped']+=caps['regional_atoms_capped']
    dump(OUT/'input_manifest.json',dict(schema_version='1.0',config_freeze_path=freeze_path.relative_to(ROOT).as_posix(),config_freeze_sha256=digest(freeze_path),canonical_manifest_sha256=digest(OUT/'canonical_manifest.json'),jobs=jobs))
    dump(HERE/'input_audit.json',dict(status='frozen_engine_inputs_no_fit',aggregate={h:dict(v) for h,v in aggregate.items()},input_manifest_sha256=digest(OUT/'input_manifest.json'),config_freeze_sha256=digest(freeze_path)))
    print(json.dumps({h:dict(v) for h,v in aggregate.items()}))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=('canonical','engine'));parser.add_argument('--freeze',type=Path)
    args=parser.parse_args()
    if args.mode=='canonical':canonical()
    else:engine_inputs(args.freeze or ROOT/'tracerx_cna_phylo/config_freeze_2026-10-18.json')
