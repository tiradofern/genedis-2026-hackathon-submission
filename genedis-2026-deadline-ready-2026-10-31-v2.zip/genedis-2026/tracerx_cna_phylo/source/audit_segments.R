# Audit and faithful translation only. No CNA model or inferred chronology.
args <- commandArgs(trailingOnly=TRUE)
root <- normalizePath(args[[1]],winslash="/",mustWork=TRUE)
setwd(root)
.libPaths(c("tracerx_routes/source/.rlibrary","population_routes/inference/.rlibrary",.libPaths()))
reader <- jsonlite::read_json("tracerx_routes/source/source_manifest.json",simplifyVector=FALSE)$reader
for(package in reader$packages) stopifnot(as.character(utils::packageVersion(package$name))==package$version)
out <- "tracerx_cna_phylo/source/output"
dir.create(out,recursive=TRUE,showWarnings=FALSE)
source_paths <- c(luad="tracerx_routes/source/output/cohort_trees.json",lusc="tracerx_routes/source/output/lusc/cohort_trees.json")
scope <- list()
for(hist in names(source_paths)) {
  src <- jsonlite::read_json(source_paths[[hist]],simplifyVector=FALSE)
  context <- jsonlite::read_json(paste0("tracerx_expanded/source/output/",hist,"/cna_context.json"),simplifyVector=FALSE)
  roles <- setNames(vapply(context$patients,function(p) p$role,character(1)),vapply(context$patients,function(p) p$patient_id,character(1)))
  for(p in src$patients) scope[[length(scope)+1]] <- data.frame(histology=hist,patient_id=p$patient_id,tumour_id=p$tumour_id,role=roles[[p$patient_id]])
}
scope <- do.call(rbind,scope)
write.table(scope,file.path(out,"frozen_scope.tsv"),sep="\t",quote=FALSE,row.names=FALSE,na="")
paths <- c(scna="tracerx_expanded/source/raw/20221109_TRACERx421_scna_table.fst",sequenza="tracerx_expanded/source/raw/20221108_sequenza_seg_df_cruk.fst")
audit <- list()
for(name in names(paths)) {
  manifest <- jsonlite::read_json("tracerx_expanded/source/source_manifest.json",simplifyVector=FALSE)
  entry <- Filter(function(e) e$filename==basename(paths[[name]]),manifest$files)[[1]]
  stopifnot(unname(tools::md5sum(paths[[name]]))==entry$md5,file.info(paths[[name]])$size==entry$bytes)
  x <- fst::read_fst(paths[[name]])
  x$source_row_index <- seq_len(nrow(x))
  key <- if("patient_id" %in% names(x)) "patient_id" else "cruk_id"
  all_rows <- nrow(x)
  x <- x[x[[key]] %in% scope$patient_id,,drop=FALSE]
  write.table(x,file.path(out,paste0(name,"_frozen_full.tsv")),sep="\t",quote=FALSE,row.names=FALSE,na="")
  valid <- function(z) is.finite(z) & z>=0 & z==floor(z)
  s <- list(all_source_rows=all_rows,frozen_patient_rows=nrow(x),samples=length(unique(x$sample)),tumours=length(unique(x$tumour_id)),chromosomes=sort(unique(as.character(x$chr))),columns=names(x),start_range=range(x$startpos),end_range=range(x$endpos),negative_or_invalid_coordinates=sum(!valid(x$startpos)|!valid(x$endpos)|x$endpos<x$startpos))
  for(v in c("cnTotal","nMajor","nMinor","nAraw","nBraw")) s[[v]] <- list(missing=sum(is.na(x[[v]])),negative=sum(x[[v]]<0,na.rm=TRUE),noninteger=sum(x[[v]]!=floor(x[[v]]),na.rm=TRUE),min=min(x[[v]],na.rm=TRUE),max=max(x[[v]],na.rm=TRUE),above8=sum(x[[v]]>8,na.rm=TRUE))
  s$major_minor_sum_mismatch <- sum(x$nMajor+x$nMinor!=x$cnTotal,na.rm=TRUE)
  s$major_below_minor <- sum(x$nMajor<x$nMinor,na.rm=TRUE)
  s$raw_a_below_b <- sum(x$nAraw<x$nBraw,na.rm=TRUE)
  if("MSAI" %in% names(x)) {
    s$MSAI <- as.list(table(x$MSAI,useNA="always"))
    s$phasing_reference_missing <- sum(is.na(x$samp_used_to_phase)|x$samp_used_to_phase=="")
    s$raw_negative_even_where_integer_valid <- sum((x$nAraw<0|x$nBraw<0)&valid(x$nMajor)&valid(x$nMinor),na.rm=TRUE)
  }
  audit[[name]] <- s
}
jsonlite::write_json(audit,file.path(out,"schema_quality_audit.json"),auto_unbox=TRUE,pretty=TRUE,na="null")
cat("Full-source frozen scope translations and aggregate schema quality audit complete.\n")
