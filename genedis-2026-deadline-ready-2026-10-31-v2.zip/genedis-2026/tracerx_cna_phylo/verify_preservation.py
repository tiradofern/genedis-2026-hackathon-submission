"""Verify prior TRACERx artifacts without changing any preserved evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RECORD = Path(__file__).with_name("prior_preservation_2026-10-18.json")


def verify():
    original = json.loads(RECORD.read_text(encoding="utf-8"))
    failures = []
    for item in original["files"]:
        path = ROOT / item["path"]
        if not path.is_file():
            failures.append(item["path"] + ": absent")
        elif (path.stat().st_size != item["bytes"] or
              hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]):
            failures.append(item["path"] + ": changed")
    native_root = ROOT / "nextstrain/datasets"
    native = sorted(native_root.glob("tracerx_*.json"))
    aggregate = hashlib.sha256(b"".join(
        path.name.encode() + b"\0" + hashlib.sha256(path.read_bytes()).digest()
        for path in native)).hexdigest()
    if len(native) != original["native_dataset_count"]:
        failures.append("prior native dataset count differs")
    if aggregate != original["native_aggregate_sha256"]:
        failures.append("prior native dataset aggregate differs")
    if failures:
        raise ValueError("Preservation verification failed: " + "; ".join(failures))
    result = {
        "verified_utc": datetime.now(timezone.utc).isoformat(),
        "preserved_file_count": len(original["files"]),
        "native_dataset_count": len(native),
        "native_aggregate_sha256": aggregate,
        "all_unchanged": True,
    }
    original["verified_after"] = result
    RECORD.write_text(json.dumps(original, indent=2) + "\n", encoding="utf-8", newline="\n")
    return result


if __name__ == "__main__":
    print(json.dumps(verify(), indent=2))
