"""Loopback-only, fail-closed companion for conditional CNA patient trees."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import sys
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from native_trees import VARIANTS, export_record, validate_record


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def within(root, path):
    resolved = (root / path).resolve()
    if not resolved.is_relative_to((root / "tracerx_cna_phylo").resolve()):
        raise ValueError("Artifact escaped the new CNA analysis")
    return resolved


def load_context(root, cohort):
    if cohort not in {"luad", "lusc"}:
        raise ValueError("Choose LUAD or LUSC separately")
    freeze_path = root / "tracerx_cna_phylo/config_freeze_2026-10-18.json"
    freeze = read(freeze_path)
    config_item = next(row for row in freeze["configurations"] if row["cohort"] == cohort)
    if digest(root / config_item["path"]) != config_item["sha256"]:
        raise ValueError("Frozen configuration bytes changed")
    config = read(root / config_item["path"])
    canonical_path = root / config["source"]["canonical_manifest_path"]
    if digest(canonical_path) != config["source"]["canonical_manifest_sha256"]:
        raise ValueError("Frozen cohort identities changed")
    inputs_path = root / "tracerx_cna_phylo/source/output/input_manifest.json"
    inputs = read(inputs_path)
    audit_path = root / "tracerx_cna_phylo/source/input_audit.json"
    if audit_path.is_file() and digest(inputs_path) != read(audit_path)["input_manifest_sha256"]:
        raise ValueError("Prepared input manifest bytes changed")
    if inputs["config_freeze_sha256"] != digest(freeze_path):
        raise ValueError("Prepared inputs refer to another configuration freeze")
    patients = [p for p in read(canonical_path)["patients"] if p["histology"].lower() == cohort]
    if len(patients) != config["cohort"]["patients"] or {role: sum(p["role"] == role for p in patients) for role in ("training", "evaluation")} != {
            "training": config["cohort"]["training"], "evaluation": config["cohort"]["evaluation"]}:
        raise ValueError("Patient/role denominators changed")
    return {"config": config, "config_sha256": config_item["sha256"],
            "freeze_sha256": digest(freeze_path), "patients": patients,
            "inputs": {(p["patient_id"], p["variant"]): p for p in inputs["jobs"] if p["histology"] == cohort}}


def record_path(root, cohort, patient, variant):
    return root / "tracerx_cna_phylo/methods/output" / cohort / patient / (variant + ".json")


def patient_payload(root, cohort, patient_id, variant, context):
    identities = {row["patient_id"]: row for row in context["patients"]}
    if patient_id not in identities or variant not in VARIANTS:
        raise ValueError("Choose a frozen patient and prespecified reconstruction")
    identity = identities[patient_id]
    source_variant = "primary" if variant == "total_cn_topology" else variant
    prepared = context["inputs"].get((patient_id, source_variant))
    if prepared is None:
        raise ValueError("No frozen prepared input for this patient variant")
    common = {"patient": identity, "variant": variant, "prepared": prepared,
              "config_sha256": context["config_sha256"], "native_url": None}
    path = record_path(root, cohort, patient_id, variant)
    if not path.is_file():
        return {**common, "status": "not_run", "reason": "No converted genuine engine result is available. Refresh after reconstruction completes."}
    value = read(path)
    if (value["patient_id"], value["histology"].lower(), value["role"], value["variant"]) != (
            patient_id, cohort, identity["role"], variant):
        raise ValueError("Converted output identity differs from frozen source")
    if value["input_sha256"] != prepared["sha256"]:
        raise ValueError("Converted output refers to another input")
    if value["status"] != "success":
        return {**common, "status": value["status"], "reason": value.get("failure_reason", "Engine result unavailable"),
                "record_sha256": digest(path), "record": value}
    validate_record(value, identity)
    for name, artifact in value["source_artifacts"].items():
        source = within(root, artifact)
        expected = value["fingerprints"].get(name + "_sha256")
        if not expected or digest(source) != expected:
            raise ValueError(f"Genuine {name} artifact bytes changed")
    mapping = read(within(root, value["source_artifacts"]["mapping"]))
    common["measured_bp"] = sum(atom["observed_bp"] for atom in mapping["atoms"])
    exported = export_record(path, root=root, identity=identity)
    return {**common, "status": "success", "record": value, "record_sha256": digest(path),
            "native_url": exported["url"], "native_audit": exported["audit"]}


def load_routes(root, cohort, context):
    folder = root / "tracerx_cna_phylo/routes/output" / cohort
    summary_path = folder / "summary.json"
    if not summary_path.is_file():
        return {"status": "not_run", "reason": "Across-patient screens are unavailable until genuine reconstructions have been converted."}
    summary = read(summary_path)
    if summary["histology"].lower() != cohort or summary["patients"] != len(context["patients"]):
        raise ValueError("Route result cohort differs from frozen patient set")
    if summary["config_sha256"] != context["config_sha256"] or summary["config_freeze_sha256"] != context["freeze_sha256"]:
        raise ValueError("Route screen refers to another configuration")
    if summary["cohort"] != {role: sum(p["role"] == role for p in context["patients"]) for role in ("training", "evaluation")}:
        raise ValueError("Route role denominator changed")
    for pair in summary["pairs"]:
        if set(pair["events"]) - set(summary["eligible_events"]):
            raise ValueError("Pair contains an ineligible event")
        for role in ("training", "evaluation"):
            evidence = pair[role]
            categories = evidence["categories"]
            if sum(categories.values()) != summary["cohort"][role] or evidence["patients"] != summary["cohort"][role]:
                raise ValueError("Route categories do not partition the frozen patient denominator")
            if evidence["forward"] != categories.get("a_ancestor_b", 0) or evidence["reverse"] != categories.get("b_ancestor_a", 0):
                raise ValueError("Strict order counts differ from categories")
    return {"status": summary["status"], "summary": summary, "sha256": digest(summary_path)}


def make_handler(root=ROOT):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urlparse(self.path)
            query = parse_qs(parsed.query)
            path = parsed.path
            try:
                content_type = "application/json; charset=utf-8"
                if path in {"/", "/index.html", "/app.js", "/styles.css", "/source-styles.css"}:
                    source = root / "tracerx_routes/visualization/styles.css" if path == "/source-styles.css" else HERE / ("index.html" if path == "/" else path[1:])
                    data = source.read_bytes()
                    content_type = "text/javascript; charset=utf-8" if path.endswith(".js") else "text/css; charset=utf-8" if path.endswith(".css") else "text/html; charset=utf-8"
                else:
                    cohort = query.get("cohort", ["luad"])[0]
                    context = load_context(root, cohort)
                    if path == "/cohort.json":
                        patients = []
                        for identity in context["patients"]:
                            primary = record_path(root, cohort, identity["patient_id"], "primary")
                            status = read(primary).get("status", "invalid") if primary.is_file() else "not_run"
                            patients.append({**identity, "primary_status": status})
                        payload = {"histology": cohort, "patients": patients, "cohort": context["config"]["cohort"],
                                   "config_sha256": context["config_sha256"], "freeze_sha256": context["freeze_sha256"],
                                   "statuses": dict(Counter(p["primary_status"] for p in patients)),
                                   "routes": load_routes(root, cohort, context)}
                    elif path in {"/patient.json", "/source-record.json", "/artifact"}:
                        patient = query.get("patient", [None])[0]
                        variant = query.get("variant", ["primary"])[0]
                        payload = patient_payload(root, cohort, patient, variant, context)
                        if path == "/source-record.json":
                            if "record" not in payload:
                                raise ValueError("No engine record exists to download")
                            data = record_path(root, cohort, patient, variant).read_bytes()
                        elif path == "/artifact":
                            name = query.get("name", [None])[0]
                            if payload["status"] != "success" or name not in payload["record"]["source_artifacts"]:
                                raise ValueError("Choose an available validated model artifact")
                            source = within(root, payload["record"]["source_artifacts"][name])
                            data = source.read_bytes()
                            content_type = "application/octet-stream"
                    elif path == "/pair.json":
                        routes = load_routes(root, cohort, context)
                        if "summary" not in routes:
                            raise ValueError("No across-patient screen is available")
                        summary = routes["summary"]
                        key = query.get("key", [None])[0]
                        if key not in {pair["key"] for pair in summary["pairs"]}:
                            raise ValueError("Choose an eligible tested event pair")
                        index = read(root / "tracerx_cna_phylo/routes/output" / cohort / "patient_pair_evidence.json")
                        selected = next(p for p in summary["pairs"] if p["key"] == key)
                        item = next(p for p in index["pairs"] if p["events"] == selected["events"])
                        source = within(root, item["path"])
                        if digest(source) != item["sha256"]:
                            raise ValueError("Patient-pair evidence fingerprint changed")
                        payload = read(source)
                        ids = {p["patient_id"]: p["role"] for p in context["patients"]}
                        if payload["histology"] != cohort or payload["events"] != selected["events"] or len(payload["patients"]) != len(ids) or {
                            p["patient_id"]: p["role"] for p in payload["patients"]} != ids:
                            raise ValueError("Patient-pair traces omit, repeat or mix frozen patients")
                        payload["sha256"] = item["sha256"]
                    else:
                        self.send_error(404)
                        return
                    if path not in {"/source-record.json", "/artifact"}:
                        data = json.dumps(payload, allow_nan=False).encode("utf-8")
            except (OSError, ValueError, KeyError, TypeError, StopIteration) as error:
                self.send_error(503, f"Validated CNA evidence unavailable: {error}")
                return
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self'; script-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
            if path in {"/source-record.json", "/artifact"}:
                self.send_header("Content-Disposition", "attachment")
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, *_):
            pass
    return Handler


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=4004)
    args = parser.parse_args()
    service = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler())
    print(f"CNA region-tree evidence: http://127.0.0.1:{args.port}/", flush=True)
    service.serve_forever()
