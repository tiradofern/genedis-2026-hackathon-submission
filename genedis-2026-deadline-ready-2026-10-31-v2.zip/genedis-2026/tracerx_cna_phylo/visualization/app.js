"use strict";
const $ = id => document.getElementById(id);
const esc = value => String(value ?? "Unknown").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const labels = {a_ancestor_b:"A ancestral to B",b_ancestor_a:"B ancestral to A",same_branch_unordered:"Same branch · unordered",incomparable_branches:"Incomparable branches",repeated_event:"Repeated event",state_reversion:"State reversion",placement_unknown:"Placement unknown",zero_length_separation:"Zero-length separation",assay_or_state_unknown:"Assay or state unknown",not_co_carrier:"Not co-carriers",reconstruction_unavailable:"Reconstruction unavailable",sensitivity_unavailable:"Sensitivity unavailable",sensitivity_disagreement:"Sensitivity disagreement",chromosome_resampling_unresolved:"Chromosome resampling unresolved"};
const categories = Object.keys(labels).filter(k => !k.startsWith("sensitivity_") && k !== "chromosome_resampling_unresolved");
const state = {cohort:"luad",patient:null,variant:"primary",cohortData:null,patientData:null,pair:null,traces:[],page:0,request:0,patientRequest:0,pairRequest:0};
const title = value => labels[value] || value;
const fmt = n => Number.isFinite(n) ? n.toLocaleString(undefined,{maximumFractionDigits:4}) : "Unavailable";
const pct = n => Number.isFinite(n) ? `${(100*n).toFixed(1)}%` : "Unavailable";
const query = extra => new URLSearchParams({cohort:state.cohort,...extra}).toString();
function error(message) { $("error").textContent=message; $("error").hidden=false; }
async function get(path) { const response=await fetch(path,{cache:"no-store"}); if(!response.ok) throw new Error(`Evidence unavailable (${response.status}). Source or model checks failed; refresh after the run or inspect the local service log.`); return response.json(); }
function updateUrl() { history.replaceState(null,"",`/?${query({patient:state.patient || "",variant:state.variant})}`); }
function clearPatient() {$("patient-content").hidden=true;$("native-link").removeAttribute("href");state.patientData=null;}
async function loadCohort() {
  const request=++state.request; ++state.patientRequest; ++state.pairRequest;
  $("error").hidden=true; $("refresh").disabled=true; $("patient-select").disabled=true;
  clearPatient(); $("route-content").hidden=true; $("readiness").textContent="Loading frozen cohort and genuine result statuses…"; $("patient-status").textContent="Loading patient evidence…"; $("route-status").textContent="Loading screen status…";
  try {
    const data=await get(`/cohort.json?${query({})}`); if(request!==state.request)return; state.cohortData=data;
    document.querySelector('a[href^="http://127.0.0.1:4003/"]').href=`http://127.0.0.1:4003/?cohort=${state.cohort}&analysis=expanded`;
    const completed=data.statuses.success || 0; const totalRegions=data.patients.reduce((sum,p)=>sum+p.n_regions,0);
    $("readiness").textContent=`${data.histology.toUpperCase()}: ${data.patients.length} independent patients · ${data.cohort.training} training / ${data.cohort.evaluation} reused evaluation · ${totalRegions} frozen primary regions. ${completed}/${data.patients.length} primary reconstructions reported successful. Other statuses: ${Object.entries(data.statuses).filter(([s])=>s!=="success").map(([s,n])=>`${s}: ${n}`).join("; ") || "none"}. Success is computational completion, not biological validation.`;
    if(!data.patients.some(p=>p.patient_id===state.patient))state.patient=(data.patients.find(p=>p.primary_status==="success") || data.patients[0]).patient_id;
    $("patient-select").innerHTML=data.patients.map(p=>`<option value="${esc(p.patient_id)}">${esc(p.patient_id)} · ${p.role} · ${p.n_regions} regions · ${esc(p.primary_status)}</option>`).join("");
    $("patient-select").value=state.patient;$("patient-select").disabled=false;
    $("fingerprint").textContent=`${data.histology.toUpperCase()} frozen config SHA256 ${data.config_sha256}`;
    renderRoutes(data.routes);updateUrl();await loadPatient();
  } catch(e) {if(request===state.request)error(e.message);} finally {if(request===state.request)$("refresh").disabled=false;}
}
async function loadPatient() {
  const request=++state.patientRequest;clearPatient();$("patient-status").textContent="Validating genuine input and output fingerprints…";updateUrl();
  try {
    const data=await get(`/patient.json?${query({patient:state.patient,variant:state.variant})}`);if(request!==state.patientRequest)return;
    state.patientData=data;const p=data.patient;
    $("patient-status").textContent=`${p.patient_id} · ${p.role} · ${p.n_regions} required primary regions · ${state.variant} · ${data.status}${data.reason?": "+data.reason:""}`;
    if(data.status!=="success")return;
    const record=data.record;$("patient-content").hidden=false;
    if(!$("native-axis-note")){
      const note=document.createElement("p");note.id="native-axis-note";note.className="method-note";
      note.textContent="Auspice labels this axis “Mutations”; here it represents minimum CNA model events.";
      $("native-link").insertAdjacentElement("afterend",note);
    }
    $("patient-meta").innerHTML=`<span><strong>${esc(p.n_regions)}</strong> regional tips + artificial diploid anchor</span><span><strong>${esc(data.prepared.n_segments)}</strong> shared measured segments</span><span><strong>${esc(data.prepared.n_blocks)}</strong> continuity blocks</span><span><strong>${fmt(data.measured_bp/1e9)} Gb</strong> measured bases in this variant</span>`;
    $("native-link").href=data.native_url;$("record-download").href=`/source-record.json?${query({patient:state.patient,variant:state.variant})}`;
    const flags=Object.values(record.history_audit.branches).filter(b=>!b.valid).length;
    $("history-note").textContent=`${record.history_audit.all_valid?"Every reconstructed branch passed the compatible-history check.":`${flags} branches have history-validation flags; WGD chronology remains unresolved.`} This shows a conditional minimum solution. It does not establish actual tumor history or a clone tree. ${data.prepared.caps.regional_atoms_capped || 0} regional input atoms were capped in this input; source major/minor orientation is phase-unresolved.`;
    renderTree(record);renderPlacements(record);
    $("artifacts").textContent="Open this disclosure to inspect exact source/output fingerprints.";
    if($("artifact-details").open)renderArtifacts();
  } catch(e) {if(request===state.patientRequest){$("patient-status").textContent="Validated patient evidence unavailable.";error(e.message);}}
}
function branchEvents(record,node,key) {return Object.entries(record.events).filter(([,p])=>p[key].includes(node)).map(([event])=>event);}
function inspectNode(node) {
  const r=state.patientData.record; const kind=node===r.normal_name?"Artificial diploid anchor":r.regions.includes(node)?"Sampled bulk primary region":"Model-inferred ancestor";
  const audit=r.history_audit.branches[node];
  $("node-detail").innerHTML=`<strong>${esc(node)} · ${kind}</strong><p>Parent: ${esc(r.parent[node] || "Model root")}. Incoming minimum-event distance: ${fmt(r.lengths[node] || 0)}. Acquired states: ${esc(branchEvents(r,node,"acquisition_branches").join(", ") || "None inferred")}. Reversions: ${esc(branchEvents(r,node,"reversion_branches").join(", ") || "None inferred")}.</p><p>History check: ${audit?(audit.valid?"passed":esc(audit.flags.join("; "))):"root has no incoming branch"}. All changes on this branch remain unordered.</p>`;
}
function renderTree(r) {
  const child={};Object.keys(r.parent).forEach(n=>child[n]=[]);Object.entries(r.parent).forEach(([n,p])=>{if(p!==null)child[p].push(n);});Object.values(child).forEach(a=>a.sort());
  const x={},y={},order=[];let row=0;
  function position(n,d) {x[n]=d;order.push(n);if(child[n].length){child[n].forEach(c=>position(c,d+r.lengths[c]));y[n]=child[n].reduce((s,c)=>s+y[c],0)/child[n].length;}else y[n]=55+(row++)*46;}
  position(r.root,0);const max=Math.max(...Object.values(x),1), width=1100,height=row*46+92; const px=n=>55+x[n]/max*620;
  let svg=`<title>Conditional CNA region reconstruction for ${esc(r.patient_id)}</title><desc>One separate patient tree; horizontal distance is cumulative minimum CNA model events.</desc>`;
  order.forEach(n=>{if(child[n].length){const ys=child[n].map(c=>y[c]);svg+=`<path class="patient-tree-edge" d="M${px(n)},${Math.min(...ys)}V${Math.max(...ys)}"/>`;}child[n].forEach(c=>svg+=`<path class="patient-tree-edge" d="M${px(n)},${y[c]}H${px(c)}"/>`);});
  order.forEach(n=>{const kind=n===r.normal_name?"patient-tree-normal":r.regions.includes(n)?"patient-tree-region":"";svg+=`<g class="patient-tree-target" data-node="${esc(n)}" tabindex="0" role="button" aria-label="Inspect ${esc(n)}"><circle class="patient-tree-node ${kind}" cx="${px(n)}" cy="${y[n]}" r="4.5"/><text class="patient-tree-label" x="${px(n)+9}" y="${y[n]-8}">${esc(n)}</text></g>`;});
  const axis=height-36;svg+=`<path class="patient-tree-edge" d="M55,${axis}H675"/><text class="patient-tree-axis" x="55" y="${axis+17}">0</text><text class="patient-tree-axis" x="675" y="${axis+17}" text-anchor="end">${fmt(max)} minimum CNA model events</text>`;
  $("patient-tree").setAttribute("viewBox",`0 0 ${width} ${height}`);$("patient-tree").innerHTML=svg;
  $("branches").innerHTML=order.map(n=>`<tr><td><button class="text-button" data-node="${esc(n)}">${esc(n)}</button></td><td>${esc(r.parent[n] || "Model root")}</td><td>${fmt(r.lengths[n] || 0)}</td><td>${esc(branchEvents(r,n,"acquisition_branches").join("; ") || "None inferred")}</td><td>${esc([...branchEvents(r,n,"reversion_branches"),...(r.history_audit.branches[n]?.flags || [])].join("; ") || "None")}</td></tr>`).join("");inspectNode(r.root);
}
function renderPlacements(r) {
  $("placements").innerHTML=Object.entries(r.events).map(([event,p])=>{const coverage=Object.entries(r.arm_states[event] || {}).map(([node,v])=>`${node}: ${v.state===null?"unknown":v.state?"LOH":"non-LOH"}, coverage ${pct(v.coverage)}, LOH bounds ${pct(v.loh_fraction_lower)}–${pct(v.loh_fraction_upper)}`).join("; ");return `<tr><td>${esc(event)}</td><td>${p.carrier===null?"Unknown":p.carrier?"Yes":"Known negative"}</td><td>${esc(p.acquisition_branches.join("; ") || "None unique")}</td><td>${esc(p.flags.join("; ") || "None under this model")}</td><td class="event-coverage">${esc(coverage || "WGD uses actual model x2 event rows; arm coverage does not define WGD.")}</td></tr>`;}).join("");
}
function renderArtifacts() {
  const data=state.patientData;if(data?.status!=="success")return;const r=data.record;
  $("artifacts").innerHTML=`<p class="method-note">Exact converted-record SHA256 <code>${esc(data.record_sha256)}</code></p><div class="table-scroll"><table><thead><tr><th scope="col">Artifact</th><th scope="col">Local artifact path</th><th scope="col">SHA256</th></tr></thead><tbody>${Object.entries(r.source_artifacts).map(([name,path])=>`<tr><td><a href="/artifact?${query({patient:state.patient,variant:state.variant,name})}">${esc(name)}</a></td><td><code>${esc(path)}</code></td><td><code>${esc(r.fingerprints[name+"_sha256"])}</code></td></tr>`).join("")}</tbody></table></div>`;
}
function renderRoutes(routes) {
  state.traces=[];state.pair=null;
  if(!routes.summary){$("route-status").textContent=routes.reason;return;}
  const r=routes.summary;state.routes=r;
  $("route-content").hidden=false;
  const pendingStatuses=new Set(["planned","not_run","running"]);
  const mainPending=Object.values(r.reconstruction_statuses || {}).some(counts=>Object.keys(counts).some(s=>pendingStatuses.has(s)));
  const uncertaintyPending=Object.keys(r.chromosome_bootstrap_statuses || {}).some(s=>pendingStatuses.has(s));
  const mainPresent=r.all_primary_sensitivity_records_present && !mainPending;
  const mainFailed=Object.values(r.reconstruction_statuses || {}).some(counts=>Object.keys(counts).some(s=>s!=="success" && !pendingStatuses.has(s)));
  const screenStatus=!mainPresent?"Partial reconstruction screen":uncertaintyPending?`${mainFailed?"Main reconstruction attempts complete":"Main reconstructions complete"}; chromosome uncertainty pending`:r.status.replaceAll("_"," ");
  $("route-status").textContent=`${screenStatus} · ${r.eligible_events.length}/45 states pass the training-only gate · ${r.pair_count} tested cross-chromosome/WGD pairs · ${r.direction_count} directions · ${r.directions_BH_below_0_05} directions with training BH q < 0.05. ${mainPresent?"All primary/sensitivity result records are present; failures remain explicit.":"The main reconstruction run is incomplete; pending or unavailable fits remain explicit."} Chromosome resamples: ${Object.entries(r.chromosome_bootstrap_statuses || {}).map(([s,n])=>`${s}: ${n}`).join("; ") || "unavailable"}.`;
  $("gates").innerHTML=r.event_catalogue.map(e=>{const g=r.event_gate[e];return `<tr><td>${esc(e)}</td><td>${g.training_carriers} / ${g.training_patients}</td><td>${g.training_known_noncarriers} / ${g.training_patients}</td><td>${g.training_unknown} / ${g.training_patients}</td><td>${g.eligible?"Yes":"No"}</td></tr>`;}).join("");
  $("pair-select").innerHTML=r.pairs.map(p=>`<option value="${esc(p.key)}">${esc(p.events.join(" / "))} · ${p.training.resolved} training strict orders</option>`).join("");$("pair-select").disabled=!r.pairs.length;
  if(r.pairs.length){state.pair=r.pairs[0];renderPair();}else{$("pair-summary").textContent="No event pair meets the frozen gate.";$("categories").innerHTML="";$("qualified").innerHTML="";$("pair-test").textContent="No tested route is available; no fallback pair or threshold relaxation is applied.";renderTraces();}
}
function renderPair() {
  const p=state.pair;$("pair-summary").innerHTML=`<span>A: <strong>${esc(p.events[0])}</strong> · B: <strong>${esc(p.events[1])}</strong></span><span>Strict training <strong>${p.training.resolved}/${p.training.known_co_carriers}</strong> known co-carriers (${pct(p.training.strict_fraction_of_known_co_carriers)})</span><span>Strict evaluation <strong>${p.evaluation.resolved}/${p.evaluation.known_co_carriers}</strong> (${pct(p.evaluation.strict_fraction_of_known_co_carriers)})</span>`;
  $("categories").innerHTML=categories.map(c=>`<tr><td>${title(c)}</td>${["training","evaluation"].map(role=>`<td>${p[role].categories[c] || 0} / ${p[role].patients}</td>`).join("")}</tr>`).join("");
  const qs=new Set([...Object.keys(p.sensitivity_qualified.training.categories),...Object.keys(p.sensitivity_qualified.evaluation.categories),"a_ancestor_b","b_ancestor_a"]);
  $("qualified").innerHTML=[...qs].sort().map(c=>`<tr><td>${esc(title(c))}</td>${["training","evaluation"].map(role=>`<td>${p.sensitivity_qualified[role].categories[c] || 0} / ${p.sensitivity_qualified[role].patients}</td>`).join("")}</tr>`).join("");
  $("pair-test").textContent=`Training A→B: p=${fmt(p.training.forward_p)}, BH q=${fmt(p.training.forward_BH_q)}; B→A: p=${fmt(p.training.reverse_p)}, BH q=${fmt(p.training.reverse_BH_q)}. Tests use only strict directional observations. Patient bootstrap sign frequencies: A→B ${pct(p.patient_bootstrap.forward_sign_frequency)}, B→A ${pct(p.patient_bootstrap.reverse_sign_frequency)} (${p.patient_bootstrap.planned} planned; ties ${p.patient_bootstrap.ties}). These frequencies are not truth probabilities.`;
  loadPairTraces();
}
async function loadPairTraces() {
  const request=++state.pairRequest;state.traces=[];state.page=0;$("trace-count").textContent="Loading this pair's hash-verified patient traces…";$("traces").innerHTML="";
  try {const data=await get(`/pair.json?${query({key:state.pair.key})}`);if(request!==state.pairRequest)return;state.traces=data.patients;$("trace-category").innerHTML='<option value="all">All categories</option>'+categories.map(c=>`<option value="${c}">${title(c)}</option>`).join("");renderTraces();}catch(e){if(request===state.pairRequest)error(e.message);}
}
function renderTraces() {
  const all=state.traces.filter(p=>($("trace-role").value==="all" || p.role===$("trace-role").value)&&($("trace-category").value==="all" || p.primary_category===$("trace-category").value));
  const pages=Math.max(1,Math.ceil(all.length/25));state.page=Math.min(state.page,pages-1);const visible=all.slice(state.page*25,(state.page+1)*25);
  $("trace-count").textContent=`${all.length} patients match display filters; ${visible.length} shown. Aggregate tables retain every frozen patient and do not change with these filters.`;
  $("traces").innerHTML=visible.map(p=>`<tr><td><button class="text-button" data-patient="${esc(p.patient_id)}">${esc(p.patient_id)}</button></td><td>${esc(p.role)}</td><td>${esc(title(p.primary_category))}</td><td>${esc(title(p.sensitivity_qualified_category))}</td><td><details><summary>Inspect variants / resamples</summary><pre>${esc(JSON.stringify({variants:p.variants,planned:p.planned_chromosome_replicates,categories:p.bootstrap_categories,same_strict_direction:p.same_strict_direction},null,2))}</pre></details></td></tr>`).join("");
  $("trace-page").textContent=`Page ${state.page+1} of ${pages}`;$("trace-prev").disabled=state.page===0;$("trace-next").disabled=state.page>=pages-1;
}
$("cohort-select").addEventListener("change",()=>{state.cohort=$("cohort-select").value;state.patient=null;loadCohort();});
$("patient-select").addEventListener("change",()=>{state.patient=$("patient-select").value;loadPatient();});
$("variant-select").addEventListener("change",()=>{state.variant=$("variant-select").value;loadPatient();});
$("refresh").addEventListener("click",loadCohort);
$("artifact-details").addEventListener("toggle",()=>{if($("artifact-details").open)renderArtifacts();});
$("pair-select").addEventListener("change",()=>{state.pair=state.routes.pairs.find(p=>p.key===$("pair-select").value);renderPair();});
for(const id of ["trace-role","trace-category"])$(id).addEventListener("change",()=>{state.page=0;renderTraces();});
$("trace-prev").addEventListener("click",()=>{state.page--;renderTraces();});$("trace-next").addEventListener("click",()=>{state.page++;renderTraces();});
document.addEventListener("click",event=>{const n=event.target.closest("[data-node]");if(n)inspectNode(n.dataset.node);const p=event.target.closest("[data-patient]");if(p){state.patient=p.dataset.patient;state.variant="primary";$("patient-select").value=state.patient;$("variant-select").value=state.variant;loadPatient();$("patient-section").scrollIntoView();}});
$("patient-tree").addEventListener("keydown",event=>{const n=event.target.closest("[data-node]");if(n&&["Enter"," "].includes(event.key)){event.preventDefault();inspectNode(n.dataset.node);}});
const initial=new URLSearchParams(location.search);if(["luad","lusc"].includes(initial.get("cohort")))state.cohort=initial.get("cohort");state.patient=initial.get("patient");if([...$("variant-select").options].some(o=>o.value===initial.get("variant")))state.variant=initial.get("variant");$("cohort-select").value=state.cohort;$("variant-select").value=state.variant;loadCohort();
