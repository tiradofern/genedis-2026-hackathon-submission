"""Fictional boundary fixtures and actual hash-bound official output checks."""
from __future__ import annotations

import copy
import hashlib
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import sys
import tempfile
from threading import Thread
import unittest
from urllib.error import HTTPError
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "nextstrain/tests"))
sys.path.insert(0, str(Path(__file__).parent))
from schema_validation import official_validator
from native_trees import VARIANTS, convert, export_record, native_route, validate_fidelity, validate_record
from server import load_context, load_routes, make_handler, patient_payload


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fictional_record():
    return {"patient_id": "FICTIONAL", "histology": "luad", "role": "training", "variant": "primary", "status": "success",
        "root": "root", "normal_name": "diploid", "regions": ["region-A", "region-B"],
        "parent": {"root": None, "diploid": "root", "ancestor": "root", "region-A": "ancestor", "region-B": "ancestor"},
        "lengths": {"root": 0, "diploid": 0, "ancestor": 4, "region-A": 0, "region-B": 3},
        "input_sha256": "a"*64, "fingerprints": {"input_sha256": "a"*64},
        "source_artifacts": {}, "arm_states": {},
        "events": {"LOH:1p": {"carrier": True, "acquisition_branches": ["ancestor"], "reversion_branches": [], "flags": [], "unique_branch": "ancestor"},
            "WGD": {"carrier": None, "reported_model_carrier": True, "acquisition_branches": ["region-B"], "reversion_branches": [], "flags": ["unvalidated_wgd_event_history"], "unique_branch": None}},
        "history_audit": {"all_valid": False, "branches": {"region-B": {"valid": False,"flags": ["primitive_event_count_differs_from_MED_length"]}}}}


def prepare_pending(root):
    canonical_path=root / "tracerx_cna_phylo/source/output/canonical_manifest.json"
    identity={"patient_id":"FICTIONAL", "histology":"luad", "role":"training", "n_regions":2,
              "primary_regions":["region-A","region-B"],"observed_bp":100,"unmeasured_bp":20}
    canonical_hash=write(canonical_path,{"patients":[identity]})
    config_path=root / "configs/fictional.json"
    config={"source":{"canonical_manifest_path":str(canonical_path.relative_to(root)),"canonical_manifest_sha256":canonical_hash},
            "cohort":{"patients":1,"training":1,"evaluation":0}}
    config_hash=write(config_path,config)
    freeze_hash=write(root / "tracerx_cna_phylo/config_freeze_2026-10-18.json",
                     {"configurations":[{"cohort":"luad","path":str(config_path.relative_to(root)),"sha256":config_hash}]})
    write(root / "tracerx_cna_phylo/source/output/input_manifest.json",{"config_freeze_sha256":freeze_hash,
          "jobs":[{"histology":"luad","patient_id":"FICTIONAL","variant":"primary","sha256":"a"*64}]})
    return identity


class ViewTests(unittest.TestCase):
    def test_exact_topology_zero_lengths_and_schema(self):
        value=fictional_record()
        dataset=convert(value,"b"*64)
        self.assertEqual(validate_fidelity(value,dataset)["nodes"],5)
        self.assertEqual(list(official_validator().iter_errors(dataset)),[])
        self.assertIn("not authors-verified",dataset["meta"]["description"])

    def test_flagged_wgd_remains_unknown_with_exact_trace(self):
        value=fictional_record(); dataset=convert(value,"b"*64)
        exact=dataset["meta"]["extensions"]["cna_phylo_model"]["exact_record"]
        self.assertIsNone(exact["events"]["WGD"]["carrier"])
        branch=dataset["tree"]["children"][0]["children"][1]
        self.assertIn("placement flags",branch["branch_attrs"]["labels"]["CNA"])
        self.assertEqual(branch["node_attrs"]["history_validation"]["value"],"Flagged")

    def test_projection_loss_or_length_change_fails(self):
        value=fictional_record();dataset=convert(value,"b"*64)
        dataset["tree"]["children"][0]["node_attrs"]["div"]+=1
        with self.assertRaisesRegex(ValueError,"distance"):
            validate_fidelity(value,dataset)
        dataset=convert(value,"b"*64);dataset["tree"]["children"].pop()
        with self.assertRaisesRegex(ValueError,"topology"):
            validate_fidelity(value,dataset)

    def test_foreign_patient_region_or_unsuccessful_record_fails(self):
        value=fictional_record();identity={"patient_id":"FICTIONAL","histology":"lusc","role":"training","primary_regions":value["regions"]}
        with self.assertRaisesRegex(ValueError,"another patient"):
            validate_record(value,identity)
        value["regions"].append("invented-region")
        with self.assertRaisesRegex(ValueError,"regional tips"):
            validate_record(value)
        value=fictional_record();value["status"]="timed_out"
        with self.assertRaisesRegex(ValueError,"successful"):
            convert(value,"b"*64)

    def test_native_routes_separate_patient_and_variants(self):
        a=fictional_record();b=copy.deepcopy(a);b["variant"]="gap100k"
        self.assertNotEqual(native_route(a),native_route(b))
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);path=root / "tracerx_cna_phylo/methods/output/fixture.json";write(path,a)
            exported=export_record(path,root=root)
            self.assertEqual(exported["path"].name,"cnaphylo_luad_FICTIONAL.json")
            self.assertFalse(exported["path"].name.startswith("tracerx_"))

    def test_pending_and_missing_screen_never_create_fallback_tree(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);prepare_pending(root);context=load_context(root,"luad")
            result=patient_payload(root,"luad","FICTIONAL","primary",context)
            self.assertEqual(result["status"],"not_run");self.assertIsNone(result["native_url"])
            self.assertEqual(load_routes(root,"luad",context)["status"],"not_run")
            self.assertFalse((root / "nextstrain/datasets").exists())

    def test_local_http_rejects_foreign_identity_and_config_drift(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);prepare_pending(root)
            service=ThreadingHTTPServer(("127.0.0.1",0),make_handler(root));thread=Thread(target=service.serve_forever,daemon=True);thread.start()
            base=f"http://127.0.0.1:{service.server_port}"
            try:
                with urlopen(base+"/cohort.json?cohort=luad") as response:
                    self.assertEqual(json.load(response)["statuses"],{"not_run":1})
                with self.assertRaises(HTTPError) as caught:
                    urlopen(base+"/patient.json?cohort=luad&patient=foreign&variant=primary")
                self.assertEqual(caught.exception.code,503)
                (root / "configs/fictional.json").write_text("{}")
                with self.assertRaises(HTTPError):urlopen(base+"/cohort.json?cohort=luad")
            finally:service.shutdown();service.server_close();thread.join()

    def test_route_partition_and_hash_bound_pair_trace(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);prepare_pending(root);context=load_context(root,"luad")
            folder=root / "tracerx_cna_phylo/routes/output/luad"
            events=["LOH:1p","LOH:2p"]; pair_key="|".join(events)
            trace={"histology":"luad","events":events,"patients":[{"patient_id":"FICTIONAL","role":"training","primary_category":"same_branch_unordered"}]}
            trace_path=folder / "pairs/fictional-index-key.json";trace_hash=write(trace_path,trace)
            write(folder / "patient_pair_evidence.json",{"pairs":[{"key":"hash-index-key","events":events,"path":str(trace_path.relative_to(root)),"sha256":trace_hash}]})
            training={"patients":1,"categories":{"same_branch_unordered":1},"forward":0,"reverse":0}
            evaluation={"patients":0,"categories":{},"forward":0,"reverse":0}
            summary={"histology":"luad","patients":1,"status":"partial_reconstruction_screen","cohort":{"training":1,"evaluation":0},
                "config_sha256":context["config_sha256"],"config_freeze_sha256":context["freeze_sha256"],
                "eligible_events":events,"pairs":[{"key":pair_key,"events":events,"training":training,"evaluation":evaluation}]}
            write(folder / "summary.json",summary)
            service=ThreadingHTTPServer(("127.0.0.1",0),make_handler(root));thread=Thread(target=service.serve_forever,daemon=True);thread.start()
            try:
                from urllib.parse import urlencode
                endpoint=f"http://127.0.0.1:{service.server_port}/pair.json?"+urlencode({"cohort":"luad","key":pair_key})
                with urlopen(endpoint) as response:self.assertEqual(json.load(response)["events"],events)
                write(trace_path,{**trace,"events":["LOH:3p","LOH:4p"]})
                with self.assertRaises(HTTPError):urlopen(endpoint)
                summary["pairs"][0]["training"]["categories"]["same_branch_unordered"]=2
                write(folder / "summary.json",summary)
                with self.assertRaisesRegex(ValueError,"partition"):
                    load_routes(root,"luad",context)
            finally:service.shutdown();service.server_close();thread.join()

    def test_actual_successful_records_official_schema_and_fidelity(self):
        paths=[]
        for cohort in ("luad","lusc"):
            folder=ROOT / "tracerx_cna_phylo/methods/output" / cohort
            for variant in VARIANTS:
                paths += [p for p in folder.glob("*/"+variant+".json") if json.loads(p.read_bytes()).get("status")=="success"]
        if not paths:self.skipTest("No genuine converted patient result available yet")
        validator=official_validator()
        for path in paths:
            value=json.loads(path.read_bytes());dataset=convert(value,hashlib.sha256(path.read_bytes()).hexdigest())
            self.assertEqual(list(validator.iter_errors(dataset)),[])
            validate_fidelity(value,dataset)
        print(f"Official schema and exact native topology/length fidelity: {len(paths)} genuine main-variant projections")

    def test_actual_separate_population_screens_and_selected_traces(self):
        available=[cohort for cohort in ("luad","lusc") if (ROOT / f"tracerx_cna_phylo/routes/output/{cohort}/summary.json").is_file()]
        if not available:self.skipTest("No genuine population screen is available yet")
        service=ThreadingHTTPServer(("127.0.0.1",0),make_handler(ROOT));thread=Thread(target=service.serve_forever,daemon=True);thread.start()
        try:
            from urllib.parse import urlencode
            for cohort in available:
                context=load_context(ROOT,cohort);result=load_routes(ROOT,cohort,context)
                summary=result["summary"]
                self.assertEqual(summary["patients"],len(context["patients"]))
                self.assertEqual(summary["direction_count"],2*len(summary["pairs"]))
                for pair in summary["pairs"][::max(1,len(summary["pairs"])-1)]:
                    endpoint=f"http://127.0.0.1:{service.server_port}/pair.json?"+urlencode({"cohort":cohort,"key":pair["key"]})
                    with urlopen(endpoint) as response:trace=json.load(response)
                    self.assertEqual(trace["events"],pair["events"])
                    for role in ("training","evaluation"):
                        observed=__import__("collections").Counter(p["primary_category"] for p in trace["patients"] if p["role"]==role)
                        self.assertEqual(dict(observed),pair[role]["categories"])
                    self.assertEqual(len(trace["patients"]),summary["patients"])
        finally:service.shutdown();service.server_close();thread.join()


if __name__=="__main__":unittest.main()
