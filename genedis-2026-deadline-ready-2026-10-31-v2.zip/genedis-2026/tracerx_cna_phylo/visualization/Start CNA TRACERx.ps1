param(
    [string]$Python = 'C:\Users\tirad\CODEX HOME\Active Projects\A18- GeNeDis 2026\.venv\Scripts\python.exe',
    [int]$Port = 4004
)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$serverPath = Join-Path $PSScriptRoot 'server.py'
$outputRoot = Join-Path $PSScriptRoot 'output'
New-Item -ItemType Directory -Path $outputRoot -Force | Out-Null
$listener = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($listener) {
    $owner = Get-CimInstance Win32_Process -Filter "ProcessId=$($listener[0].OwningProcess)"
    if ($owner.CommandLine -notlike "*$serverPath*") {
        throw "Port $Port belongs to another process; it was preserved. Choose another port explicitly."
    }
    Write-Output "Existing CNA companion: http://127.0.0.1:$Port/ (PID $($owner.ProcessId))"
    exit 0
}
$worker = Start-Process -FilePath $Python -ArgumentList @('-u', ('"' + $serverPath + '"'), '--port', $Port) -WorkingDirectory $projectRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $outputRoot 'stdout.log') -RedirectStandardError (Join-Path $outputRoot 'stderr.log')
@{pid=$worker.Id; port=$Port; host='127.0.0.1'; server=$serverPath; started_utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $outputRoot 'server.json') -Encoding utf8
Write-Output "CNA companion: http://127.0.0.1:$Port/ (PID $($worker.Id))"
