"""Loss-audited projections of genuine conditional MEDICC2 region trees.

No inference occurs here. Patient trees remain separate native Auspice datasets.
Generated patient identifiers, model outputs and native files stay ignored.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tracerx_cna_phylo.methods.contracts import validate_tree

VARIANTS = ("primary", "highcopy_mask", "gap100k", "total_cn_topology")


def slug(value):
    result = re.sub(r"[^A-Za-z0-9-]+", "-", value).strip("-")
    if not result:
        raise ValueError("Empty patient route")
    return result


def validate_record(value, identity=None):
    if value.get("status") != "success":
        raise ValueError("No successful genuine reconstruction is available")
    if value.get("histology", "").lower() not in {"luad", "lusc"} or value.get("variant") not in VARIANTS:
        raise ValueError("Unsupported histology or sensitivity record")
    if identity and any(str(value[name]).lower() != str(identity[name]).lower()
                        for name in ("patient_id", "histology", "role")):
        raise ValueError("Reconstruction belongs to another patient, role or histology")
    root = validate_tree(value["parent"], value["lengths"])
    if value["root"] != root:
        raise ValueError("Root annotation differs from model topology")
    internal = set(value["parent"].values()) - {None}
    leaves = set(value["parent"]) - internal
    if leaves != set(value["regions"]) | {value["normal_name"]}:
        raise ValueError("Exact regional tips and artificial diploid anchor must be preserved")
    if identity and set(value["regions"]) != set(identity["primary_regions"]):
        raise ValueError("Reconstruction omits or invents a frozen primary region")
    if len(value["regions"]) != len(set(value["regions"])) or len(value["regions"]) < 2:
        raise ValueError("Invalid regional reconstruction")
    nodes = set(value["parent"])
    for event in value["events"].values():
        if set(event["acquisition_branches"]) - nodes or set(event["reversion_branches"]) - nodes:
            raise ValueError("An event points outside the model tree")
        if event.get("unique_branch") and event["unique_branch"] not in event["acquisition_branches"]:
            raise ValueError("Unique event branch differs from acquisition trace")
    if not value.get("fingerprints", {}).get("input_sha256") == value.get("input_sha256"):
        raise ValueError("Input fingerprint is not bound to the reconstruction")
    return root


def native_route(value):
    tail = "" if value["variant"] == "primary" else "/" + slug(value["variant"])
    return f"http://127.0.0.1:4000/cnaphylo/{value['histology'].lower()}/{slug(value['patient_id'])}{tail}"


def convert(value, source_sha256):
    root = validate_record(value)
    children, acquired, reverted = defaultdict(list), defaultdict(list), defaultdict(list)
    for child, ancestor in value["parent"].items():
        if ancestor is not None:
            children[ancestor].append(child)
    for event, placement in value["events"].items():
        label = event + (" [placement flags]" if placement["flags"] else "")
        for branch in placement["acquisition_branches"]:
            acquired[branch].append(label)
        for branch in placement["reversion_branches"]:
            reverted[branch].append(event)

    def node(name, distance):
        kind = ("Artificial diploid anchor" if name == value["normal_name"] else
                "Sampled bulk primary region" if name in value["regions"] else "Model-inferred ancestor")
        branch = value["history_audit"].get("branches", {}).get(name, {})
        result = {"name": name, "node_attrs": {
            "div": distance, "node_kind": {"value": kind},
            "model_branch_length": {"value": value["lengths"].get(name, 0)},
            "acquired_states": {"value": "; ".join(sorted(acquired[name])) or "None inferred"},
            "reverted_states": {"value": "; ".join(sorted(reverted[name])) or "None inferred"},
            "history_flags": {"value": "; ".join(branch.get("flags", [])) or "None"},
            "history_validation": {"value": "Passed" if branch.get("valid", True) else "Flagged"}}}
        labels = []
        if acquired[name]:
            labels.append("Acquire " + ", ".join(sorted(acquired[name])))
        if reverted[name]:
            labels.append("Revert " + ", ".join(sorted(reverted[name])))
        if labels:
            result["branch_attrs"] = {"labels": {"CNA": "; ".join(labels)}}
        if children[name]:
            result["children"] = [node(child, distance + value["lengths"][child])
                                  for child in sorted(children[name])]
        return result

    dataset = {"version": "v2", "meta": {
        "title": f"TRACERx {value['histology'].upper()} {value['patient_id']} — minimum CNA-event distance · {value['variant']}",
        "updated": "2026-10-19", "panels": ["tree"],
        "description": (
            "**New model-derived CNA-only reconstruction.** Tips are sampled bulk primary regions plus an artificial diploid anchor. "
            "Internal nodes and arm-LOH/WGD placements are conditional MEDICC2 outputs, not authors-verified mutation clusters or a joint SNV/CNA clone tree. "
            "Auspice labels the horizontal axis 'Mutations'; here it represents minimum CNA model events, not SNV counts or elapsed time. Major/minor orientation is phase-unresolved; allele cap 8 and short-gap continuity are explicit assumptions. "
            "Multiple states on one branch are unordered. One deterministic minimum history is shown; tied alternatives are not exhaustively enumerated. "
            "A flagged event history cannot establish WGD order. Patients never share an invented root. "
            f"[Inspect patient evidence](http://127.0.0.1:4004/?cohort={value['histology'].lower()}&patient={value['patient_id']}&variant={value['variant']})."),
        "display_defaults": {"distance_measure": "div", "color_by": "node_kind", "branch_label": "CNA"},
        "colorings": [{"key": "node_kind", "title": "Model node type", "type": "categorical",
            "scale": [["Sampled bulk primary region", "#16656c"], ["Model-inferred ancestor", "#637783"],
                      ["Artificial diploid anchor", "#855a22"]]}],
        "extensions": {"cna_phylo_model": {"source_record_sha256": source_sha256,
            "branch_length_units": "Minimum CNA model events", "within_branch_order": "Unresolved",
            "joint_SNV_CNA_clone_tree": False, "exact_record": value}}}, "tree": node(root, 0)}
    validate_fidelity(value, dataset)
    return dataset


def validate_fidelity(value, dataset):
    found, expected_distance = {}, {}
    def walk(node, parent):
        name = node["name"]
        if name in found:
            raise ValueError("Duplicate projected model node")
        found[name] = parent
        expected_distance[name] = 0 if parent is None else expected_distance[parent] + value["lengths"][name]
        if node["node_attrs"]["div"] != expected_distance[name]:
            raise ValueError("Projected distance differs from genuine model lengths")
        for child in node.get("children", []):
            walk(child, name)
    walk(dataset["tree"], None)
    if found != value["parent"]:
        raise ValueError("Projected topology differs from genuine model tree")
    exact = dataset["meta"]["extensions"]["cna_phylo_model"]["exact_record"]
    if exact != value:
        raise ValueError("Native metadata lost event/history evidence")
    return {"nodes": len(found), "regions": len(value["regions"]), "events": len(value["events"]),
            "topology_and_lengths_preserved": True, "exact_model_record_preserved": True}


def export_record(path, *, root=ROOT, identity=None):
    raw = Path(path).read_bytes()
    value = json.loads(raw)
    validate_record(value, identity)
    fingerprint = hashlib.sha256(raw).hexdigest()
    dataset = convert(value, fingerprint)
    suffix = "" if value["variant"] == "primary" else "_" + slug(value["variant"])
    destination = root / f"nextstrain/datasets/cnaphylo_{value['histology'].lower()}_{slug(value['patient_id'])}{suffix}.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(dataset, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8", newline="\n")
    return {"url": native_route(value), "path": destination, "record_sha256": fingerprint,
            "audit": validate_fidelity(value, dataset)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--converted", type=Path, default=ROOT / "tracerx_cna_phylo/methods/output")
    args = parser.parse_args()
    result = {"exported": 0, "unavailable": 0, "histology": {}}
    for cohort in ("luad", "lusc"):
        count = 0
        paths = (folder / (variant + ".json")
                 for folder in sorted((args.converted / cohort).glob("*")) if folder.is_dir()
                 for variant in VARIANTS)
        for path in paths:
            if not path.is_file():
                continue
            value = json.loads(path.read_bytes())
            if value.get("status") == "success":
                export_record(path)
                result["exported"] += 1
                count += 1
            else:
                result["unavailable"] += 1
        result["histology"][cohort] = count
    print(json.dumps(result, indent=2))
