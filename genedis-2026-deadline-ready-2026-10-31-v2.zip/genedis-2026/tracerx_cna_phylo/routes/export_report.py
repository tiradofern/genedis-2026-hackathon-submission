"""Export a bounded, patient-free audit of every tested pair and fixed gate.

The detailed per-patient evidence stays in ignored local output files. This
export keeps every tested pair, including unfavorable evaluation observations,
without publishing sample identifiers or source regional profiles.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
from statistics import median


ROOT = Path(__file__).resolve().parents[2]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def export():
    report = {
        "schema_version": "0.1",
        "interpretation": "Exploratory model-conditional CNA orders; no validated common route",
        "pair_rows_reuse_patients": True,
        "evaluation_is_external_validation": False,
        "bootstrap_support_is_a_truth_probability": False,
        "patient_identifiers_and_regional_profiles_included": False,
        "configuration_freeze_sha256": digest(ROOT / "tracerx_cna_phylo/config_freeze_2026-10-18.json"),
        "cohorts": {},
    }
    for cohort in ("luad", "lusc"):
        path = ROOT / "tracerx_cna_phylo/routes/output" / cohort / "summary.json"
        source = json.loads(path.read_text(encoding="utf-8"))
        if source["histology"] != cohort or source["config_freeze_sha256"] != report["configuration_freeze_sha256"]:
            raise ValueError("Aggregate summary differs from its histology or effective freeze")
        for implementation, expected in source["screen_implementation_sha256"].items():
            if digest(ROOT / implementation) != expected:
                raise ValueError("Screen implementation changed since this aggregate was computed")
        entry = {key: source[key] for key in (
            "status", "cohort", "patients", "event_catalogue", "event_gate",
            "eligible_events", "pair_count", "direction_count", "directions_BH_below_0_05",
            "reconstruction_statuses", "all_primary_sensitivity_records_present",
            "primary_attempts_finished", "chromosome_uncertainty_complete",
            "patient_bootstrap_seed", "patient_bootstrap_seed_source",
            "chromosome_bootstrap_planned_per_patient", "chromosome_bootstrap_statuses",
            "config_sha256", "config_freeze_sha256", "canonical_manifest_sha256",
            "engine_jobs_sha256", "screen_implementation_sha256",
        )}
        entry["local_complete_summary_sha256"] = digest(path)
        resolved = [pair["training"]["resolved"] for pair in source["pairs"]]
        cocarriers = [pair["training"]["known_co_carriers"] for pair in source["pairs"]]
        entry["training_pair_information"] = {
            "purpose": "Descriptive sparsity audit only; no change to gates or tested family",
            "median_known_co_carriers_per_pair": median(cocarriers),
            "median_resolved_orders_per_pair": median(resolved),
            "pairs_without_any_resolved_order": sum(n == 0 for n in resolved),
            "pairs_with_fewer_than_five_resolved_orders": sum(n < 5 for n in resolved),
            "pairs_with_at_least_ten_resolved_orders": sum(n >= 10 for n in resolved),
            "resolved_order_count_distribution": dict(sorted(Counter(resolved).items())),
            "minimum_unadjusted_directional_p": min(
                pair["training"][key] for pair in source["pairs"] for key in ("forward_p", "reverse_p")),
            "minimum_directional_BH_q": min(
                pair["training"][key] for pair in source["pairs"] for key in ("forward_BH_q", "reverse_BH_q")),
        }
        entry["role_totals"] = {}
        for role in ("training", "evaluation"):
            primary, qualified = Counter(), Counter()
            known = strict = 0
            for pair in source["pairs"]:
                primary.update(pair[role]["categories"])
                qualified.update(pair["sensitivity_qualified"][role]["categories"])
                known += pair[role]["known_co_carriers"]
                strict += pair[role]["resolved"]
                assert sum(pair[role]["categories"].values()) == source["cohort"][role]
                assert sum(pair["sensitivity_qualified"][role]["categories"].values()) == source["cohort"][role]
            entry["role_totals"][role] = {
                "patients": source["cohort"][role],
                "patient_pair_observations": sum(primary.values()),
                "primary_categories": dict(sorted(primary.items())),
                "known_co_carriers": known,
                "primary_strict_order": strict,
                "primary_strict_fraction_of_known_co_carriers": strict / known if known else None,
                "sensitivity_qualified_categories": dict(sorted(qualified.items())),
            }
        # Every tested pair is retained in a compact row. The columns make the
        # meaning explicit without repeating field names thousands of times.
        entry["pair_columns"] = [
            "event_a", "event_b", "training_forward", "training_reverse",
            "training_forward_p", "training_reverse_p", "training_forward_BH_q", "training_reverse_BH_q",
            "evaluation_forward", "evaluation_reverse", "qualified_training_forward", "qualified_training_reverse",
            "qualified_evaluation_forward", "qualified_evaluation_reverse",
            "patient_bootstrap_positive", "patient_bootstrap_negative", "patient_bootstrap_ties",
        ]
        entry["pair_rows"] = []
        for pair in source["pairs"]:
            t, e, q, b = (pair[name] for name in ("training", "evaluation", "sensitivity_qualified", "patient_bootstrap"))
            entry["pair_rows"].append([
                *pair["events"], t["forward"], t["reverse"], t["forward_p"], t["reverse_p"],
                t["forward_BH_q"], t["reverse_BH_q"], e["forward"], e["reverse"],
                q["training"]["forward"], q["training"]["reverse"],
                q["evaluation"]["forward"], q["evaluation"]["reverse"],
                b["forward_minus_reverse_positive"], b["negative"], b["ties"],
            ])
        assert len(entry["pair_rows"]) == entry["pair_count"]
        report["cohorts"][cohort] = entry
    payload = json.dumps(report, indent=2, allow_nan=False) + "\n"
    if re.search(r"CRUK\d{4}|TCGA-[A-Z0-9]{2}-[A-Z0-9]{4}|sk-proj-", payload):
        raise ValueError("Patient identifier or secret-shaped content in aggregate export")
    target = Path(__file__).with_name("aggregate_report.json")
    target.write_text(payload, encoding="utf-8", newline="\n")
    return {"path": target.relative_to(ROOT).as_posix(), "sha256": digest(target), "bytes": target.stat().st_size}


if __name__ == "__main__":
    print(json.dumps(export(), indent=2))
