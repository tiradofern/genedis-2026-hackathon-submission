"""Run the frozen separate-histology CNA route screens after reconstruction."""
from __future__ import annotations

import argparse
from collections import Counter
from pathlib import Path
import hashlib
import json
import sys

from .screen import ROOT, VARIANTS, screen, sha

NONTERMINAL = {"planned", "running", "pending", "not_run"}

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n",
                    encoding="utf-8", newline="\n")


def run(jobs_path, converted_root, allow_pending=False):
    implementation = {path.relative_to(ROOT).as_posix(): sha(path) for path in (
        Path(__file__), Path(__file__).with_name("screen.py"),
        ROOT / "tracerx_cna_phylo/methods/contracts.py")}
    freeze_path = ROOT / "tracerx_cna_phylo/config_freeze_2026-10-18.json"
    freeze = read(freeze_path)
    configs = {}
    for item in freeze["configurations"]:
        if sha(ROOT / item["path"]) != item["sha256"]:
            raise ValueError("The pre-analysis configuration changed")
        configs[item["cohort"]] = read(ROOT / item["path"])
    source_path = ROOT / configs["luad"]["source"]["canonical_manifest_path"]
    if sha(source_path) != freeze["canonical_manifest_sha256"]:
        raise ValueError("Frozen patient/input identities changed")
    arms_path = ROOT / configs["luad"]["source"]["arms_path"]
    if sha(arms_path) != freeze["arms_sha256"]:
        raise ValueError("Event reference coordinates changed")
    events = ["LOH:" + arm["id"] for arm in read(arms_path)["arms"]] + ["WGD"]
    patients = read(source_path)["patients"]
    identities = {p["patient_id"]: p for p in patients}
    source_inputs_path = ROOT / "tracerx_cna_phylo/source/output/input_manifest.json"
    source_inputs = read(source_inputs_path)
    source_audit = read(ROOT / "tracerx_cna_phylo/source/input_audit.json")
    if sha(source_inputs_path) != source_audit["input_manifest_sha256"]:
        raise ValueError("Engine input manifest differs from independently verified source audit")
    if (source_inputs["config_freeze_sha256"] != sha(freeze_path) or
            source_inputs["canonical_manifest_sha256"] != sha(source_path)):
        raise ValueError("Source engine inputs are not bound to the effective freeze")
    locked_inputs = {(j["patient_id"], j["variant"]): j for j in source_inputs["jobs"]}
    if len(locked_inputs) != len(source_inputs["jobs"]):
        raise ValueError("Duplicate source input job")
    job_document = read(jobs_path)
    jobs = job_document["jobs"] if isinstance(job_document, dict) else job_document
    records, bootstraps, seen, pending = {}, {}, set(), []
    for job in jobs:
        variant, pid = job["variant"], job["patient_id"]
        if variant not in VARIANTS and not (variant.startswith("bootstrap_") and
                                           variant.removeprefix("bootstrap_").isdigit()):
            continue  # resampled topology fits are not full-input event records
        key = (pid, variant)
        if key in seen or pid not in identities:
            raise ValueError("Repeated reconstruction or foreign patient")
        seen.add(key)
        original = identities[pid]
        if job["role"] != original["role"] or job["histology"].lower() != original["histology"].lower():
            raise ValueError("Patient role or histology drift")
        path = converted_root / original["histology"].lower() / pid / (variant + ".json")
        if not path.is_file():
            pending.append(key)
            continue
        value = read(path)
        if value["patient_id"] != pid or value["variant"] != variant:
            raise ValueError("Converted file identity differs from engine job")
        if value["role"] != original["role"] or value["histology"].lower() != original["histology"].lower():
            raise ValueError("Converted patient role or histology changed, including bootstrap records")
        if value["status"] != job["status"]:
            raise ValueError("Converted status differs from engine job")
        # Total-CN and resampled-topology records are full primary-input allelic
        # refits. The intermediate diagnostic/topology inputs cannot stand in
        # for these full-input ancestral-state records.
        source_variant = variant if variant in {"primary", "highcopy_mask", "gap100k"} else "primary"
        locked = locked_inputs[(pid, source_variant)]
        if job["input_sha256"] != locked["sha256"]:
            raise ValueError("Patient input differs from frozen source-derived variant")
        if (Path(job["mapping_path"]).resolve() != (ROOT / locked["mapping_path"]).resolve() or
                sha(job["mapping_path"]) != locked["mapping_sha256"]):
            raise ValueError("Genomic atom mapping differs from frozen source-derived variant")
        if value["input_sha256"] != job["input_sha256"] or sha(job["input_path"]) != job["input_sha256"]:
            raise ValueError("Reconstruction input bytes changed")
        if value["status"] == "success":
            if value["fingerprints"]["mapping_sha256"] != locked["mapping_sha256"]:
                raise ValueError("Converted evidence mapped to different genomic atoms")
            for name, artifact in job["paths"].items():
                if value["fingerprints"].get(name + "_sha256") != sha(artifact):
                    raise ValueError("Official output differs from converted evidence")
        # Keep complete source traces on disk. Pair counts need only these
        # already-verified fields, rather than >1GB of repeated arm bounds.
        value = {name: value[name] for name in (
            "patient_id", "role", "histology", "status", "variant", "events", "parent", "lengths")
                 if name in value}
        if value["status"] == "success":
            value["events"] = {event: {key: placement[key] for key in ("carrier", "unique_branch", "flags")}
                               for event, placement in value["events"].items()}
        value["histology"] = value["histology"].lower()
        if variant in VARIANTS:
            records[key] = value
        else:
            index = int(variant.removeprefix("bootstrap_"))
            if not 0 <= index < 20:
                raise ValueError("Bootstrap replicate outside frozen planned range")
            bootstraps.setdefault(pid, {})[index] = value
    absent = [(pid, variant) for pid in identities for variant in VARIANTS
              if (pid, variant) not in records]
    incomplete = [(pid, variant) for (pid, variant), value in records.items()
                  if value["status"] in NONTERMINAL]
    if (absent or incomplete) and not allow_pending:
        raise ValueError(f"{len(absent)} absent and {len(incomplete)} pending primary/sensitivity records; "
                         "convert explicit failure records as well as successes")
    reports = {}
    for cohort, config in configs.items():
        cohort_patients = [p for p in patients if p["histology"].lower() == cohort]
        cohort_ids = {p["patient_id"] for p in cohort_patients}
        cohort_records = {key: value for key, value in records.items() if key[0] in cohort_ids}
        result, evidence = screen(cohort_patients, cohort_records, bootstraps, events, config)
        cohort_incomplete = any(pid in cohort_ids for pid, _ in absent + incomplete)
        bootstrap_status = Counter(bootstraps.get(pid, {}).get(index, {}).get("status", "not_run")
                                   for pid in cohort_ids for index in range(20))
        bootstrap_complete = not (set(bootstrap_status) & NONTERMINAL)
        status = ("partial_reconstruction_screen" if cohort_incomplete else
                  "partial_uncertainty_screen" if not bootstrap_complete else "completed_reconstruction_screen")
        result.update({"status": status,
                       "config_sha256": sha(ROOT / next(a["path"] for a in freeze["configurations"] if a["cohort"] == cohort)),
                       "config_freeze_sha256": sha(freeze_path),
                       "canonical_manifest_sha256": sha(source_path),
                       "engine_jobs_sha256": sha(jobs_path),
                       "screen_implementation_sha256": implementation,
                       "all_primary_sensitivity_records_present": not cohort_incomplete,
                       "primary_attempts_finished": all(
                           cohort_records.get((pid, "primary"), {}).get("status", "not_run") not in NONTERMINAL
                           for pid in cohort_ids),
                       "chromosome_uncertainty_complete": bootstrap_complete,
                       "patient_bootstrap_seed": config["robustness"]["bootstrap_seed"],
                       "patient_bootstrap_seed_source": "robustness.bootstrap_seed",
                       "chromosome_bootstrap_planned_per_patient": 20,
                       "chromosome_bootstrap_statuses": dict(sorted(bootstrap_status.items()))})
        output = ROOT / "tracerx_cna_phylo/routes/output" / cohort
        index = []
        for pair in evidence:
            key = hashlib.sha256("|".join(pair["events"]).encode()).hexdigest()[:20]
            path = output / "pairs" / (key + ".json")
            write(path, {"histology": cohort, **pair})
            index.append({"key": key, "events": pair["events"],
                          "path": path.relative_to(ROOT).as_posix(),
                          "sha256": sha(path), "patients": len(pair["patients"])})
        result["patient_evidence_index"] = index
        write(output / "summary.json", result)
        write(output / "patient_pair_evidence.json", {"histology": cohort, "pairs": index,
              "patient_details_are_per_pair_on_demand": True})
        reports[cohort] = {k: result[k] for k in ("patients", "eligible_events", "pair_count",
                            "direction_count", "directions_BH_below_0_05", "reconstruction_statuses")}
    return reports


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jobs", required=True, type=Path)
    parser.add_argument("--converted", default=ROOT / "tracerx_cna_phylo/methods/output", type=Path)
    parser.add_argument("--allow-pending", action="store_true")
    args = parser.parse_args()
    print(json.dumps(run(args.jobs, args.converted, args.allow_pending), indent=2))


if __name__ == "__main__":
    main()
