"""Across-patient screens of explicit, conditional CNA-tree event placements.

Reconstruction is performed by MEDICC2 elsewhere. This module never infers a
tree, moves an event, or changes a patient's frozen role to improve a result.
"""
from __future__ import annotations

from collections import Counter
from itertools import combinations
from pathlib import Path
import hashlib
import json
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tracerx_cna_phylo/methods"))
from contracts import bh_adjust, consensus_category, pair_category, pair_counts

VARIANTS = ("primary", "highcopy_mask", "gap100k", "total_cn_topology")
ORDERED = {"a_ancestor_b", "b_ancestor_a"}
_HASH_CACHE = {}


def sha(path):
    p = Path(path)
    stat = p.stat()
    key = (str(p.resolve()), stat.st_size, stat.st_mtime_ns)
    if key not in _HASH_CACHE:
        _HASH_CACHE[key] = hashlib.sha256(p.read_bytes()).hexdigest()
    return _HASH_CACHE[key]


def different_chromosomes(a, b):
    if "WGD" in (a, b):
        return True
    return a.split(":", 1)[1][:-1] != b.split(":", 1)[1][:-1]


def complete(record):
    return record is not None and record.get("status") == "success"


def category(record, a, b):
    if not complete(record):
        return "reconstruction_unavailable"
    if a not in record["events"] or b not in record["events"]:
        raise ValueError("A complete record must retain the entire fixed event catalogue")
    return pair_category(record["events"][a], record["events"][b],
                         record["parent"], record["lengths"])


def carrier(record, event):
    return record["events"][event]["carrier"] if complete(record) else None


def gate_events(patients, records, events, minimum_carriers=10, minimum_noncarriers=10):
    """Evaluation names and values do not participate in this function's gate."""
    training = [p for p in patients if p["role"] == "training"]
    result = {}
    for event in events:
        counts = Counter(carrier(records.get((p["patient_id"], "primary")), event)
                         for p in training)
        result[event] = {"training_carriers": counts[True],
                         "training_known_noncarriers": counts[False],
                         "training_unknown": counts[None],
                         "training_patients": len(training),
                         "eligible": counts[True] >= minimum_carriers and
                                     counts[False] >= minimum_noncarriers}
    return result


def qualified_category(patient_id, records, bootstraps, a, b, planned=20, minimum=16):
    values = [category(records.get((patient_id, variant)), a, b) for variant in VARIANTS]
    first = values[0]
    if not all(complete(records.get((patient_id, v))) for v in VARIANTS):
        return "sensitivity_unavailable", {"variants": dict(zip(VARIANTS, values))}
    agreed = consensus_category(values)
    detail = {"variants": dict(zip(VARIANTS, values))}
    if agreed not in ORDERED:
        return agreed, detail
    repetitions = bootstraps.get(patient_id, {})
    if any(type(index) is not int or not 0 <= index < planned for index in repetitions):
        raise ValueError("Unexpected or duplicate bootstrap replicate index")
    counts = Counter(category(repetitions.get(index), a, b) for index in range(planned))
    detail.update(planned_chromosome_replicates=planned,
                  bootstrap_categories=dict(sorted(counts.items())),
                  same_strict_direction=counts[agreed])
    if counts[agreed] < minimum:
        return "chromosome_resampling_unresolved", detail
    return agreed, detail


def summarize(values):
    result = pair_counts(values)
    unknown = {"assay_or_state_unknown", "reconstruction_unavailable"}
    result["known_co_carriers"] = sum(n for key, n in result["categories"].items()
                                      if key not in unknown | {"not_co_carrier"})
    result["strict_fraction_of_known_co_carriers"] = (
        result["resolved"] / result["known_co_carriers"]
        if result["known_co_carriers"] else None)
    return result


def screen(patients, records, bootstraps, events, config):
    ids = [p["patient_id"] for p in patients]
    if len(ids) != len(set(ids)):
        raise ValueError("Patients, not sampled regions, must be independent rows")
    if {p["role"] for p in patients} - {"training", "evaluation"}:
        raise ValueError("Unknown frozen patient role")
    for (patient_id, variant), record in records.items():
        if patient_id not in set(ids) or variant not in VARIANTS:
            raise ValueError("Foreign patient or variant in reconstruction records")
        original = next(p for p in patients if p["patient_id"] == patient_id)
        if record.get("role") != original["role"] or record.get("histology") != original["histology"]:
            raise ValueError("Frozen role or histology changed")
    gates = gate_events(patients, records, events,
                        config["frequency_gate"]["minimum_training_carriers"],
                        config["frequency_gate"]["minimum_training_known_noncarriers"])
    eligible = [e for e in events if gates[e]["eligible"]]
    training = [p for p in patients if p["role"] == "training"]
    # The specific patient-bootstrap setting is distinct from engine/draw seeds.
    rng = np.random.default_rng(config["robustness"]["bootstrap_seed"])
    nr = config["robustness"]["patient_bootstrap_replicates"]
    if nr != config["assessment"]["patient_bootstrap_replicates"]:
        raise ValueError("Conflicting frozen patient-bootstrap replicate counts")
    weights = rng.multinomial(len(training), np.full(len(training), 1 / len(training)), size=nr)
    pairs, pvalues = [], {}
    patient_evidence = []
    for a, b in combinations(eligible, 2):
        if not different_chromosomes(a, b):
            continue
        by_role = {role: [] for role in ("training", "evaluation")}
        qualified = {role: [] for role in by_role}
        qualified_detail = []
        for p in patients:
            pid, role = p["patient_id"], p["role"]
            value = category(records.get((pid, "primary")), a, b)
            robust, detail = qualified_category(pid, records, bootstraps, a, b)
            by_role[role].append(value)
            qualified[role].append(robust)
            qualified_detail.append({"patient_id": pid, "role": role,
                                     "primary_category": value,
                                     "sensitivity_qualified_category": robust, **detail})
        train, evaluation = summarize(by_role["training"]), summarize(by_role["evaluation"])
        key = a + "|" + b
        pvalues[key + "|forward"] = train["forward_p"]
        pvalues[key + "|reverse"] = train["reverse_p"]
        votes = np.array([1 if v == "a_ancestor_b" else -1 if v == "b_ancestor_a" else 0
                          for v in by_role["training"]], dtype=np.int16)
        boot_sign = weights @ votes
        pairs.append({"events": [a, b], "key": key, "training": train,
                      "evaluation": evaluation,
                      "sensitivity_qualified": {
                          role: {"patients": len(qualified[role]),
                                 "categories": dict(sorted(Counter(qualified[role]).items())),
                                 "forward": qualified[role].count("a_ancestor_b"),
                                 "reverse": qualified[role].count("b_ancestor_a")}
                          for role in qualified},
                      "patient_bootstrap": {"planned": nr,
                          "forward_minus_reverse_positive": int(np.sum(boot_sign > 0)),
                          "negative": int(np.sum(boot_sign < 0)),
                          "ties": int(np.sum(boot_sign == 0)),
                          "forward_sign_frequency": float(np.mean(boot_sign > 0)),
                          "reverse_sign_frequency": float(np.mean(boot_sign < 0))}})
        patient_evidence.append({"events": [a, b], "patients": qualified_detail})
    adjusted = bh_adjust(pvalues)
    for pair in pairs:
        pair["training"]["forward_BH_q"] = adjusted[pair["key"] + "|forward"]
        pair["training"]["reverse_BH_q"] = adjusted[pair["key"] + "|reverse"]
    statuses = {variant: dict(sorted(Counter(
        records.get((pid, variant), {}).get("status", "not_run") for pid in ids).items()))
        for variant in VARIANTS}
    summary = {"schema_version": "0.1", "histology": config["histology"],
               "claim_status": "Exploratory model-conditional CNA orders; no joint SNV/CNA clone tree or validated route",
               "cohort": {role: sum(p["role"] == role for p in patients)
                          for role in ("training", "evaluation")},
               "patients": len(patients), "event_catalogue": events,
               "event_gate": gates, "eligible_events": eligible,
               "pair_count": len(pairs), "direction_count": len(pvalues),
               "directions_BH_below_0_05": sum(q < 0.05 for q in adjusted.values()),
               "reconstruction_statuses": statuses, "pairs": pairs,
               "sensitivities_are_not_additional_independent_patients": True,
               "same_chromosome_arm_pairs_tested": False,
               "bootstrap_probabilities_are_truth_probabilities": False,
               "evaluation_is_external_validation": False}
    return summary, patient_evidence
