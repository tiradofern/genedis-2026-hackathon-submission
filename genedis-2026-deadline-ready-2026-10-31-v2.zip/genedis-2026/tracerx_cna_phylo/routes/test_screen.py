import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location("screen", Path(__file__).with_name("screen.py"))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def rec(role="training", reverse=False):
    parent = {"normal": None, "early": "normal", "late": "early", "region": "late"}
    def e(branch):
        return {"carrier": True, "unique_branch": branch, "flags": [],
                "acquisition_branches": [branch], "reversion_branches": []}
    return {"status": "success", "role": role, "histology": "luad", "parent": parent,
            "lengths": {"normal": 0, "early": 1, "late": 2, "region": 1},
            "events": {"LOH:1p": e("late" if reverse else "early"),
                       "LOH:2q": e("early" if reverse else "late")}}


class PopulationContracts(unittest.TestCase):
    def test_evaluation_cannot_change_training_gate(self):
        patients = [{"patient_id": "train", "role": "training"},
                    {"patient_id": "eval", "role": "evaluation"}]
        records = {("train", "primary"): rec(), ("eval", "primary"): rec("evaluation")}
        a = m.gate_events(patients, records, ["LOH:1p"], 1, 0)
        records[("eval", "primary")]["events"]["LOH:1p"]["carrier"] = False
        self.assertEqual(a, m.gate_events(patients, records, ["LOH:1p"], 1, 0))

    def test_failed_resampling_is_in_planned_denominator(self):
        records = {("case", v): rec() for v in m.VARIANTS}
        repetitions = {"case": {i: rec() for i in range(15)}}
        value, detail = m.qualified_category("case", records, repetitions, "LOH:1p", "LOH:2q")
        self.assertEqual(value, "chromosome_resampling_unresolved")
        self.assertEqual(detail["bootstrap_categories"]["reconstruction_unavailable"], 5)
        repetitions["case"][15] = rec()
        self.assertEqual(m.qualified_category("case", records, repetitions,
                                             "LOH:1p", "LOH:2q")[0], "a_ancestor_b")

    def test_sensitivity_disagreement_or_missingness_never_passes(self):
        records = {("case", v): rec() for v in m.VARIANTS}
        records[("case", "gap100k")] = rec(reverse=True)
        self.assertEqual(m.qualified_category("case", records, {}, "LOH:1p", "LOH:2q")[0],
                         "sensitivity_disagreement")
        records.pop(("case", "highcopy_mask"))
        self.assertEqual(m.qualified_category("case", records, {}, "LOH:1p", "LOH:2q")[0],
                         "sensitivity_unavailable")

    def test_broad_same_chromosome_aliases_are_not_primary_pairs(self):
        self.assertFalse(m.different_chromosomes("LOH:1p", "LOH:1q"))
        self.assertTrue(m.different_chromosomes("LOH:1p", "LOH:11p"))
        self.assertTrue(m.different_chromosomes("LOH:1p", "WGD"))

    def test_planted_patient_orders_and_evaluation_reversal_remain_visible(self):
        patients, records = [], {}
        for i in range(22):
            pid = "fictional_train_" + str(i)
            patients.append({"patient_id": pid, "role": "training", "histology": "luad"})
            value = rec()
            if i >= 12:
                for event in value["events"].values():
                    event["carrier"] = False
            records[(pid, "primary")] = value
        for i in range(2):
            pid = "fictional_eval_" + str(i)
            patients.append({"patient_id": pid, "role": "evaluation", "histology": "luad"})
            records[(pid, "primary")] = rec("evaluation", reverse=True)
        config = {"histology": "luad", "random_seed": 20261018,
                  "robustness": {"bootstrap_seed": 20261018, "patient_bootstrap_replicates": 1000},
                  "frequency_gate": {"minimum_training_carriers": 10,
                                     "minimum_training_known_noncarriers": 10},
                  "assessment": {"patient_bootstrap_replicates": 1000}}
        result, trace = m.screen(patients, records, {}, ["LOH:1p", "LOH:2q"], config)
        pair = result["pairs"][0]
        self.assertEqual(pair["training"]["forward"], 12)
        self.assertEqual(pair["training"]["categories"]["not_co_carrier"], 10)
        self.assertEqual(pair["evaluation"]["reverse"], 2)
        self.assertAlmostEqual(pair["training"]["forward_BH_q"], 2 / 2 ** 12)
        self.assertEqual(result["direction_count"], 2)
        self.assertEqual(len(trace[0]["patients"]), 24)
        self.assertEqual(pair["sensitivity_qualified"]["training"]["forward"], 0)
        self.assertEqual(pair["sensitivity_qualified"]["training"]["categories"],
                         {"sensitivity_unavailable": 22})

    def test_patient_bootstrap_uses_its_specific_frozen_seed(self):
        patients = [{"patient_id": f"fictional_{i}", "role": "training", "histology": "lusc"}
                    for i in range(9)]
        records = {(p["patient_id"], "primary"): rec(reverse=i >= 4)
                   for i, p in enumerate(patients)}
        for record in records.values():
            record["histology"] = "lusc"
        config = {"histology": "lusc", "random_seed": 1,
                  "robustness": {"bootstrap_seed": 123, "patient_bootstrap_replicates": 1000},
                  "frequency_gate": {"minimum_training_carriers": 1,
                                     "minimum_training_known_noncarriers": 0},
                  "assessment": {"patient_bootstrap_replicates": 1000}}
        a, _ = m.screen(patients, records, {}, ["LOH:1p", "LOH:2q"], config)
        config["random_seed"] = 999
        b, _ = m.screen(patients, records, {}, ["LOH:1p", "LOH:2q"], config)
        self.assertEqual(a["pairs"][0]["patient_bootstrap"], b["pairs"][0]["patient_bootstrap"])


if __name__ == "__main__":
    unittest.main()
