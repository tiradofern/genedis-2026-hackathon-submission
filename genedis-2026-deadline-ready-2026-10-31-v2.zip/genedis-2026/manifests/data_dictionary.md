# Data dictionary

All original source columns are preserved in sample TSVs; added columns are clearly distinguished below. Missing metadata are `NR`; they are never replaced with a negative label.

| Field/table | Definition / provenance |
|---|---|
| accession | GEO study identifier; source grouping, not patient identity |
| gsm | Deposited GEO sample accession; must join by exact identifier |
| sample_id / Sample | Original library label from GSE207422 workbook; exact matrix-column key |
| patient_id / Patient | Published deidentified within-study patient code. GSE248249 code is parsed from explicit sample title. Codes are never linked across independent studies |
| assay | bulk_RNAseq or scRNAseq; not a molecular-genomic modality |
| biological_state | pretreatment; posttreatment_resection; acquired_resistance. For GSE248249 post-treatment, AR is supported by its design and original clinical definition |
| response_group | GSE207422 source MPR, MPR (pCR), and pCR mapped to MPR; NMPR and NE retained. Original Pathologic Response preserved alongside it |
| Resource | Original sampling description. Pre_biopsy and Pre-treatment biopsy normalize to pretreatment |
| Residual Tumor | Original viable tumor fraction, 0–1 where numeric; NE remains unknown. Outcome is assessed at surgery even when RNA sample is baseline |
| Pathology | Source wording: Adeno, Squamous, NSCLC, Carcinosarcomatoid. No automatic reclassification |
| PD1 Antibody, Chemotherapy | Source strings retained verbatim, including spelling variants; review before pooling regimens |
| RECIST | Original CR/PR/SD/NE values. Do not substitute this for pathologic response |
| gender, tumor site, tumor type, timepoint, sample type | Source GSE248249 characteristics. Timepoint verified against title; histologic subtype is NR |
| confirmed_batch | NR in GSE248249. Not supplied in retrieved GEO characteristics |
| technical_file_group | Preparation-number token in CEL filename, 0024850 or 0029842; unconfirmed technical proxy. A/B plate suffix not equated with separate biological batch |
| GSE248249_pairs.tsv | One row per complete patient pair; pre/post GSM keys and source sites; same-site and same-file-group flags are descriptive audit quantities |
| same_anatomic_site | Exact equality of published tumor-site strings; does not prove the same lesion |
| egfr mutation status | GSE156054 source E19Del or L858R/T790M model annotation; not an inferred newly acquired mechanism |
| tki response / treatment | Source Sensitive/Resistant and Nontreated/Gefitinib selected/Osimertinib selected |
| independent_profiles_per_model_state | One deposited RNA profile for each model/state, not the count of all wet-lab assays in its article |
| published_patient_code | Shared Dis_NN title stem in GSE126043 and GSE126044; comparison is within the same study |
| GSE126045_patient_matches.tsv | RNA and methylation GSM crosswalk with exact shared codes, concordant source response labels, and RNA preservation. Matrix/specimen-level audit remains pending |
| patient response (Cho cohort) | Published responder: PR or SD >6 months; non-responder: PD or SD ≤6 months. Not equivalent to acquired resistance or MPR |
| matrix_integrity.tsv | Source matrix dimensions, duplicate feature IDs, missing/invalid numeric values, sample metadata match, source byte hash, and conversion count |
| thousands_separator_cells | GSE156054 values with valid comma thousands grouping converted only for integrity checks; original matrix retained unchanged |
| file_inventory.tsv | Local source bytes, SHA-256, source URL, and complete-file versus decompressed-prefix representation |

Expression units: GSE207422 bulk log2(TPM+1); GSE156054 TPM despite filename; GSE248249 deposited SST-RMA log-scale array intensity. Raw library sizes and feature counts from sequencing cannot be reconstructed from these processed values. Genomic coordinates in GPL23126 use the deposited Affymetrix na36 GRCh38 annotation, dated June 2016; full mapping not yet audited. GSE126044 processing lists GRCh37.p13/release19, requiring explicit identifier/build harmonization for integration.
