# Recovered NSCLC explorer — October 31, 2026

The existing explorer was rebuilt additively from source commit
`a4edb2ba85daef38f38b4d9a3c4cbaa1516df0b9`. Historical source manifests,
preparation code, model code, configurations and reports were preserved.
This directory records computational recovery, not new resistance findings.

## Verified results

All **47 frozen public processed input files**, totaling **647,110,442 bytes**,
were reacquired and matched their historical SHA256 and byte count. This
includes the historical GDC slide-metadata snapshot; no slide image or raw
sequence was downloaded. See `source_recovery_2026-10-31.json`.

| Cohort | Independent primary tumors | Training / evaluation | Provisional RNA programs |
|---|---:|---:|---:|
| LUAD | 507 | 354 / 153 | 14 |
| LUSC | 481 | 336 / 145 | 11 |

Two fresh builds in separate output directories have the same scientific
contents after excluding only `bootstrap.created_utc`. Every saved matrix array
is exactly equal between these runs. Eight of the nine prepared artifact files
are byte-identical; the bootstrap differs because it records a new timestamp.
All available historical cohort/program summary metrics agree within the fixed
numerical tolerance (`atol=1e-10`, `rtol=1e-8`). The full original bootstrap was
not available, so **exact historical gene-membership identity is not established**.
See `core_recovery_2026-10-31.json` and the supplemental final verification.

`program_definitions_2026-10-31.tsv` contains all **1,904 gene-loading rows**
across the 25 newly recovered programs, with source Entrez identifiers, source
symbols and full-precision PC1 loadings. It contains no patient identifiers.
The prepared artifacts retain the frozen training transforms and score scales.

All 28 existing core Python tests, five frontend tests, JavaScript syntax and
Python compilation checks passed. The existing real-data browser smoke checks
also passed at 1440×1000 and 390×844, with zero page errors. They exercise both
cohorts, RNA/CNA/reported-variant filters, source links, descriptive group
comparisons, selection, export/restore and mobile overflow. See
`checks_2026-10-31.json` and `logs/`; local screenshots and the browser result are
under ignored `work/qa/`.

## Interpretation boundaries

All 25 outputs remain **provisional RNA co-expression programs**. Training
coordination passed, but module resampling, holdout preservation,
purity/composition sensitivity, external replication and biological evidence
tier assignment have not been performed. These TCGA cohorts are cross-sectional
primary tumors, not verified pretreatment/acquired-resistance pairs. This
recovery establishes neither pan-cancer convergence nor resistance specificity,
causality, ancestry or therapeutic utility. Reported MAF absence does not prove
wild type. RNA/CNA/mutation linkage is at the TCGA sample key, not established
identity of aliquot or histology section. LUAD and LUSC remain separate.

The current fingerprint is
`593d3d11c9b25af65ccea9eea39ed46fb454ea106d302655b343033600afb61a`.
The historical fingerprint differs because the two tracked sample/slide TSV
manifests used CRLF in the original Windows working copy and use LF here.
Their historical hashes match exactly after CRLF conversion; the other four
recipe files already match exactly. No manifest was rewritten to force a match.
Historical prepared-file hashes also differ for several files; original bytes
were unavailable for a semantic comparison. Same-environment rerun equivalence
does not establish cross-platform equivalence.

## Run the recovered application

From the repository root, with Python 3.11+ and network access:

```bash
python -m venv .venv
.venv/bin/python -m pip install -r requirements-app.txt
.venv/bin/python release_recovery/retrieve_core_sources.py \
  --report release_recovery/source_recovery_local.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python scripts/prepare_explorer.py \
  --destination data/processed/explorer_local
.venv/bin/python scripts/run_explorer.py \
  --data data/processed/explorer_local --port 8766
```

Use a new destination for every preparation; the unchanged original producer
does not itself prevent overwriting its output directory. The recovery utilities
refuse to replace an existing report or gene-definition export. The retrieval
utility verifies existing cached sources and does not change the historical
audit outputs. Do **not** rerun `audit_public_tcga.py` in this release checkout
to retrieve inputs: that older producer writes the dated manifests/reports.

Open `http://127.0.0.1:8766`. The verified local build is presently at
`data/processed/explorer_release_2026-10-31`; pass that path with `--data` in this
workspace. The second build is at
`data/processed/explorer_release_rerun_2026-10-31`. Raw inputs, prepared matrices,
SQLite and local environments remain ignored by Git.

On Windows use `.venv\Scripts\python.exe`, omit the two BLAS environment
assignments if needed, and retain the same explicit `--data` and
`--destination` choices. This October 31 rerun used Linux/Python **3.12.14**,
NumPy **2.3.3** and SciPy **1.16.2**; it did not rerun the old Windows environment.

## Reproduce the computational comparison

Prepare a second new directory with the same command, then run:

```bash
.venv/bin/python release_recovery/verify_core_recovery.py \
  --first data/processed/explorer_local \
  --second data/processed/explorer_local_rerun \
  --report release_recovery/core_recovery_local.json \
  --definitions release_recovery/program_definitions_local.tsv
.venv/bin/python release_recovery/run_core_checks.py \
  --report release_recovery/checks_local.json \
  --log-directory release_recovery/logs_local
```

For browser verification, keep the app on port 8766 and add `--browser` to
`run_core_checks.py`. This requires Playwright discoverable by Node and an
installed Chromium. `EXPLORER_BROWSER_EXECUTABLE` can select its path; the
default is `/usr/bin/chromium`. The adapter only supplies that executable to
the unchanged historical smoke tests; it does not install a browser. Browser
checks write fresh local output to `work/qa/`, so preserve previous screenshots
before another browser run.

The application requires only the pinned NumPy/SciPy packages for preparation
and serving; frontend logic uses built-in browser functionality. Node is needed
for frontend verification, and Playwright/Chromium only for optional browser
verification. No R, Docker, phylogeny engine, GTEx or HLCA data are required for
this bounded explorer build. Preparation currently occupies about 117 MiB per
run in addition to approximately 618 MiB of source payloads.

## Source terms and release dependencies

The source inventory pins cBioPortal DataHub commit
`7a4b4ec142f76ac04db22834232b23142d25bd2a` and records durable URLs, sizes and
SHA256s. Large processed profiles are resolved through Git LFS; the retrieval
uses the source-declared DataHub endpoint when GitHub's LFS mirror lacks an
object. Temporary signed object URLs are not stored in the recovery report.
GDC supplies the purity publication file and slide metadata; no controlled data
were accessed.

The exact DataHub `LICENSE` and `README.md` files for both cohorts were included
in the verified retrieval. Their license notice points to the **Broad Institute
GDAC TCGA Analysis Pipeline License** and warns that source data require
validation. TCGA/GDC, cBioPortal/DataHub, publication and contributor terms remain
separate from this project's code license. The repository `LICENSE` still says
**release license pending investigator selection**. This recovery does not grant
a public redistribution license or resolve that pending decision. The release
owner must choose the project license and confirm the intended source/derived
data distribution terms before public publication. A source-only package can
retain these retrieval recipes and manifests without bundling the 647 MB input
payload or patient-level prepared artifacts.

NumPy and SciPy are pinned external dependencies, not vendored into this source
recovery. Their distribution licenses and bundled numerical-library notices
remain with their installers. The optional browser test dependencies are also
external; no browser, package cache or local environment should be added to Git
or a source-only archive.
