"""Run and retain the bounded explorer checks; requires prepared local data."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import platform
import subprocess
import sys

import numpy as np
import scipy

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", action="store_true", help="Requires the explorer at 127.0.0.1:8766, Playwright and local Chromium")
    parser.add_argument("--report", type=Path, default=ROOT / "release_recovery/checks_2026-10-31.json")
    parser.add_argument("--log-directory", type=Path, default=ROOT / "release_recovery/logs")
    args = parser.parse_args()
    if args.report.exists() or any(args.log_directory.glob("*_2026-10-31.log")):
        parser.error("Preserve existing verification outputs; choose new --report and --log-directory paths")
    checks = [("python_core", [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"]),
              ("frontend", ["node", "--test", "tests/frontend.test.mjs"]),
              ("javascript_syntax", ["node", "--check", "web/app.js"]),
              ("python_compile", [sys.executable, "-m", "compileall", "-q", "scripts", "src", "tests", "release_recovery"])]
    if args.browser:
        checks.append(("browser", ["node", "release_recovery/browser_smoke.cjs"]))
    log_directory = args.log_directory
    log_directory.mkdir(parents=True, exist_ok=True)
    results = []
    for name, command in checks:
        started = datetime.now(timezone.utc)
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        path = log_directory / f"{name}_2026-10-31.log"
        path.write_text(result.stdout + result.stderr, encoding="utf-8")
        record = dict(name=name, command=command, returncode=result.returncode,
                      started_utc=started.isoformat(), elapsed_seconds=(datetime.now(timezone.utc) - started).total_seconds(),
                      log=str(path))
        results.append(record)
        print(json.dumps(record), flush=True)
    report = dict(created_utc=datetime.now(timezone.utc).isoformat(),
                  status="passed" if all(r["returncode"] == 0 for r in results) else "failed",
                  runtime=dict(python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__),
                  checks=results,
                  interpretation="Software and local user-interface verification only; no biological validation")
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    raise SystemExit(report["status"] != "passed")


if __name__ == "__main__":
    main()
