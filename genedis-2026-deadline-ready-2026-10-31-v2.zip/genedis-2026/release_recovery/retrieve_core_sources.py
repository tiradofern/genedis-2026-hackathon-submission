"""Recover the frozen explorer inputs without rerunning or changing its audit.

Each file must match the historical size and SHA256. This is processed public
data, not raw sequence. The original source inventory is never rewritten.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import csv
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("frozen_public_audit", ROOT / "scripts/audit_public_tcga.py")
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


def recover(record, destination):
    study, resource = record["study"], record["resource"]
    target = destination / resource if study in {"DATAHUB", "GDC_PANCAN", "GDC_TCGA_LUNG_SLIDES"} else destination / study / resource
    expected_size, expected_hash = int(record["bytes"]), record["sha256"]
    for attempt in range(1, 4):
        try:
            if target.exists():
                result = audit.retrieve(record["url"], target, expected_size, False, expected_hash, expected_size)
            elif study in {"DATAHUB", "GDC_PANCAN", "GDC_TCGA_LUNG_SLIDES"}:
                result = audit.retrieve(record["url"], target, expected_size, True, expected_hash, expected_size)
            else:
                result = audit.acquire(study, resource, destination, True)
            actual_size, actual_hash = target.stat().st_size, audit.sha256(target)
            if actual_size != expected_size or actual_hash != expected_hash:
                raise ValueError("Frozen source identity does not match; original inventory was preserved")
            return dict(study=study, resource=resource, bytes=actual_size, sha256=actual_hash,
                        status=result["status"], attempts=attempt, historical_identity_match=True,
                        retrieval_route=result.get("retrieval_route", "historical URL"))
        except Exception as exc:
            if attempt == 3:
                return dict(study=study, resource=resource, status="failed", attempts=attempt,
                            error=f"{type(exc).__name__}: {exc}")
            time.sleep(attempt)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", type=Path, default=ROOT / "data/external/public_tcga_2026-10-17")
    parser.add_argument("--report", type=Path, default=ROOT / "release_recovery/source_recovery_2026-10-31.json")
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    if args.report.exists():
        parser.error(f"Preserve existing report; choose a new --report path: {args.report}")
    with (ROOT / "manifests/public_tcga_files_2026-10-17.tsv").open(newline="", encoding="utf-8") as stream:
        inventory = list(csv.DictReader(stream, delimiter="\t"))
    args.destination.mkdir(parents=True, exist_ok=True)
    results = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(recover, record, args.destination) for record in inventory]
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            print(json.dumps(result), flush=True)
    results.sort(key=lambda x: (x["study"], x["resource"]))
    failures = [r for r in results if r["status"] == "failed"]
    report = dict(created_utc=datetime.now(timezone.utc).isoformat(), source_inventory="manifests/public_tcga_files_2026-10-17.tsv",
                  expected_files=len(inventory), expected_bytes=sum(int(r["bytes"]) for r in inventory),
                  verified_files=len(results) - len(failures), failed_files=len(failures), files=results,
                  original_inventory_modified=False)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    raise SystemExit(bool(failures))


if __name__ == "__main__":
    main()
