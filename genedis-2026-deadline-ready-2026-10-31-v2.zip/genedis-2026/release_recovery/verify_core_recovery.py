"""Compare two fresh explorer builds and the available historical summary.

This checks computational reproducibility only. It does not establish module
stability, biological preservation, treatment resistance or clinical utility.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sqlite3
import sys

import numpy as np
import scipy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from survival_islands.explorer_server import ExplorerStore

ATOL, RTOL = 1e-10, 1e-8


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def compare(left, right, path="", differences=None):
    """Exact nonnumeric structure, toleranced floating point values."""
    if differences is None:
        differences = []
    if isinstance(left, dict) and isinstance(right, dict):
        if left.keys() != right.keys():
            differences.append(path + ": object keys differ")
        for key in left.keys() & right.keys():
            compare(left[key], right[key], f"{path}/{key}", differences)
    elif isinstance(left, list) and isinstance(right, list):
        if len(left) != len(right):
            differences.append(path + ": list length differs")
        for index, (a, b) in enumerate(zip(left, right)):
            compare(a, b, f"{path}/{index}", differences)
    elif isinstance(left, float) or isinstance(right, float):
        if left is None or right is None or not np.isclose(left, right, rtol=RTOL, atol=ATOL, equal_nan=True):
            differences.append(path + ": floating value differs")
    elif left != right:
        differences.append(path + ": value differs")
    return differences


def semantic_bootstrap(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    data.pop("created_utc", None)
    return data


def sqlite_identity(path):
    digest, count = hashlib.sha256(), 0
    with sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True) as database:
        for row in database.execute("SELECT * FROM variants ORDER BY study,sample,gene,symbol,classification,protein,chromosome,position,reference,alternate"):
            digest.update((json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n").encode())
            count += 1
    return dict(variant_rows=count, sorted_rows_sha256=digest.hexdigest())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--first", type=Path, required=True)
    parser.add_argument("--second", type=Path, required=True)
    parser.add_argument("--report", type=Path, default=ROOT / "release_recovery/core_recovery_2026-10-31.json")
    parser.add_argument("--definitions", type=Path, default=ROOT / "release_recovery/program_definitions_2026-10-31.tsv")
    args = parser.parse_args()
    if args.report.exists() or args.definitions.exists():
        parser.error("Preserve existing recovery outputs; choose new --report and --definitions paths")
    for folder in (args.first, args.second):
        ExplorerStore(folder, root=ROOT, verify=True)
    first, second = semantic_bootstrap(args.first / "bootstrap.json"), semantic_bootstrap(args.second / "bootstrap.json")
    bootstrap_differences = compare(first, second)
    historical = json.loads((ROOT / "results/reports/explorer_preparation_2026-10-17.json").read_text())
    historical_comparisons, array_comparisons, cohorts = {}, {}, {}
    for code, cohort in first["cohorts"].items():
        old = historical["cohorts"][code]
        current = {key: cohort[key] for key in old if key not in {"tumor_count", "programs"}}
        current["tumor_count"] = len(cohort["samples"])
        current["programs"] = [{key: program[key] for key in old["programs"][i]} for i, program in enumerate(cohort["programs"])]
        differences = compare(old, current)
        historical_comparisons[code] = dict(summary_matches_within_tolerance=not differences, differences=differences,
            old_full_program_membership_available=False,
            exact_historical_membership_identity_established=False)
        arrays = {}
        with np.load(args.first / f"{code}_matrices.npz", allow_pickle=False) as a, np.load(args.second / f"{code}_matrices.npz", allow_pickle=False) as b:
            for key in a.files:
                left, right = a[key], b[key]
                exact = bool(np.array_equal(left, right, equal_nan=True))
                close = left.shape == right.shape and bool(np.allclose(left, right, rtol=RTOL, atol=ATOL, equal_nan=True))
                arrays[key] = dict(shape=list(left.shape), dtype=str(left.dtype), exactly_equal=exact, equal_within_tolerance=close)
        array_comparisons[code] = arrays
        patients = [sample["patient_id"] for sample in cohort["samples"]]
        roles = {role: sum(s["role"] == role for s in cohort["samples"]) for role in ("training", "evaluation")}
        cohorts[code] = dict(tumors=len(patients), unique_patients=len(set(patients)), roles=roles,
            discovery_features=cohort["discovery_features"], eligible_training_features=cohort["eligible_training_features"],
            programs=len(cohort["programs"]), gene_counts=[p["gene_count"] for p in cohort["programs"]],
            all_training_coordination_pass=all(p["coordination_pass"] for p in cohort["programs"]),
            all_provisional=all(p["computational_status"] == "provisional_module" for p in cohort["programs"]),
            all_evidence_tiers_null=all(p["evidence_tier"] is None for p in cohort["programs"]),
            all_stability_and_preservation_not_run=all(p["resampling_status"] == p["preservation_status"] == "not_run" for p in cohort["programs"]),
            excluded_feature_rows=cohort["excluded_feature_rows"],
            longitudinal_resistance=cohort["available"]["longitudinal_resistance"])
    file_comparisons = {}
    for path in sorted(args.first.iterdir()):
        if path.name == "prepared_manifest.json":
            continue
        other = args.second / path.name
        item = dict(first_sha256=sha256(path), second_sha256=sha256(other), byte_identical=sha256(path) == sha256(other))
        if path.suffix == ".json":
            a, b = json.loads(path.read_text()), json.loads(other.read_text())
            if path.name == "bootstrap.json":
                a.pop("created_utc", None); b.pop("created_utc", None)
            item["semantic_differences"] = compare(a, b)
        elif path.suffix == ".sqlite":
            item["first_content"] = sqlite_identity(path)
            item["second_content"] = sqlite_identity(other)
            item["semantic_equal"] = item["first_content"] == item["second_content"]
        file_comparisons[path.name] = item
    recipes = {}
    for name, historical_hash in historical["recipe_files"].items():
        raw = (ROOT / name).read_bytes()
        crlf = raw.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
        recipes[name] = dict(historical_sha256=historical_hash, checkout_sha256=hashlib.sha256(raw).hexdigest(),
            exact_match=hashlib.sha256(raw).hexdigest() == historical_hash,
            crlf_equivalent_match=hashlib.sha256(crlf).hexdigest() == historical_hash)
    definitions = args.definitions
    definitions.parent.mkdir(parents=True, exist_ok=True)
    with definitions.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, delimiter="\t", lineterminator="\n")
        writer.writerow(("cohort", "program_id", "entrez_id", "source_symbol", "pc1_loading", "computational_status", "biological_tier"))
        for code, cohort in first["cohorts"].items():
            for program in cohort["programs"]:
                for gene in program["genes"]:
                    writer.writerow((code, program["id"], gene["id"], gene["symbol"], repr(gene["weight"]), "provisional_module", "unassigned"))
    semantic_payload = json.dumps(first, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    passed = (not bootstrap_differences and all(not r["differences"] for r in historical_comparisons.values())
              and all(r["equal_within_tolerance"] for group in array_comparisons.values() for r in group.values())
              and all(not r.get("semantic_differences", []) and r.get("semantic_equal", True) for r in file_comparisons.values()))
    historical_bytes = {name: dict(historical_sha256=historical["prepared_files_sha256"][name],
                        recovered_sha256=item["first_sha256"],
                        byte_identical=item["first_sha256"] == historical["prepared_files_sha256"][name])
                        for name, item in file_comparisons.items()}
    report = dict(created_utc=datetime.now(timezone.utc).isoformat(), status="passed" if passed else "review_required",
        scope="Computational recovery and same-environment rerun; no biological validation",
        runtime=dict(python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__, platform=platform.platform()),
        numerical_tolerance=dict(atol=ATOL, rtol=RTOL), first_run=str(args.first), second_run=str(args.second),
        first_fingerprint=first["fingerprint"], second_fingerprint=second["fingerprint"],
        historical_fingerprint=historical["fingerprint"],
        first_semantic_bootstrap_sha256=hashlib.sha256(semantic_payload).hexdigest(),
        semantic_ignored_fields=["bootstrap.created_utc"], bootstrap_differences=bootstrap_differences,
        cohorts=cohorts, historical_summary_comparison=historical_comparisons,
        recipe_byte_comparison=recipes, file_comparisons=file_comparisons, matrix_array_comparisons=array_comparisons,
        historical_prepared_byte_comparison=historical_bytes,
        program_definitions=dict(path=str(definitions), sha256=sha256(definitions)),
        limitations=["The original full bootstrap and matrix bytes were not available; historical comparisons use the tracked summary and hashes.",
                     "Matching historical aggregate metrics does not establish exact historical gene-membership identity.",
                     "Two fresh builds use the same recovered sources, code and environment; this is not independent cohort validation.",
                     "Module resampling, holdout preservation, composition adjustment and resistance associations remain untested."])
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(status=report["status"], cohorts=cohorts, report=str(args.report)), indent=2))
    raise SystemExit(not passed)


if __name__ == "__main__":
    main()
