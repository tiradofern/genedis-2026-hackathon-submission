// Run the unchanged historical checks with a locally installed Chromium.
// No browser is downloaded and no application behavior is changed.
const fs = require('node:fs');
const {chromium} = require('playwright');
const executablePath = process.env.EXPLORER_BROWSER_EXECUTABLE || '/usr/bin/chromium';
if (!fs.existsSync(executablePath)) throw new Error(`Chromium not found: ${executablePath}`);
const originalLaunch = chromium.launch.bind(chromium);
chromium.launch = options => originalLaunch({...options, executablePath});
require('../tests/browser_smoke.cjs');
