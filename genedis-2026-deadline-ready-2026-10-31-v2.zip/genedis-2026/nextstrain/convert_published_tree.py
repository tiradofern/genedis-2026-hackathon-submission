"""Translate an already published *single-tumour* reconstruction to Auspice v2.

This is a format adapter, not a phylogeny inference method. The source extractor
records source node IDs and parent IDs; this adapter preserves every node/edge.
Run ``python nextstrain/convert_published_tree.py --help`` for local usage.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from collections import Counter
from pathlib import Path
from urllib.parse import quote


class SourceError(ValueError):
    """The input is not one unambiguous, auditable rooted published tree."""


def _id(value: object) -> str:
    if isinstance(value, bool) or not isinstance(value, (str, int)) or str(value) == "":
        raise SourceError(f"Invalid source node ID: {value!r}")
    return str(value)


def _number(value: object, context: str) -> float | int:
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        raise SourceError(f"{context} must be a number, not {value!r}")
    if not math.isfinite(value) or value < 0:
        raise SourceError(f"{context} must be finite and nonnegative")
    return value


def validate_source(source: dict) -> tuple[dict[str, dict], dict[str, list[str]], str]:
    """Check IDs, a single root, connectivity, edge lengths, and provenance.

    In particular this rejects a forest, so independent patients cannot be joined
    through a fabricated common ancestor by this adapter.
    """
    if not isinstance(source, dict):
        raise SourceError("Source must be one JSON object")
    rows = source.get("nodes")
    if not isinstance(rows, list) or len(rows) < 3:
        raise SourceError("A published tree must contain at least three nodes")
    mode = source.get("branch_length", {}).get("mode")
    if mode not in {"published", "topology"}:
        raise SourceError("branch_length.mode must be 'published' or 'topology'")
    for key in ("units", "description", "source_evidence"):
        if not source.get("branch_length", {}).get(key):
            raise SourceError(f"Missing branch_length.{key}")
    provenance = source.get("source", {})
    for key in ("publication_title", "publication_url", "data_url", "license", "license_url", "source_file", "sha256"):
        if not provenance.get(key):
            raise SourceError(f"Missing source.{key}")
    if not re.fullmatch(r"[0-9a-f]{64}", provenance["sha256"]):
        raise SourceError("source.sha256 must contain the raw source file SHA256")
    for key in ("publication_url", "data_url", "license_url"):
        if not re.match(r"^https?://", provenance[key]):
            raise SourceError(f"source.{key} must be an HTTP(S) URL")
    if not source.get("patient_id") or not source.get("tumor_id"):
        raise SourceError("One explicit patient_id and tumor_id are required")
    nodes: dict[str, dict] = {}
    for row in rows:
        node_id = _id(row.get("id"))
        if node_id in nodes:
            raise SourceError(f"Duplicate source node ID: {node_id}")
        if not row.get("source_node_type"):
            raise SourceError(f"Source node type is required for {node_id}")
        if not isinstance(row.get("label"), (str, int)):
            raise SourceError(f"Source label is required for {node_id}")
        # Per-node patient/tumour values, when present, must agree with the tree.
        for key in ("patient_id", "tumor_id"):
            if key in row and row[key] != source[key]:
                raise SourceError(f"Mixed {key} at {node_id}: refuse to combine tumours")
        attrs = row.get("attributes", {})
        if not isinstance(attrs, dict):
            raise SourceError(f"Node attributes must be an object: {node_id}")
        for key, value in attrs.items():
            if not re.fullmatch(r"[a-z][a-z0-9_]*", key):
                raise SourceError(f"Unsupported attribute key {key!r}")
            if key in {"div", "num_date", "vaccine", "hidden", "url", "author", "accession", "node_role", "source_node_id", "source_label", "source_node_type", "source_branch_length", "patient_id", "tumor_id", "histology", "display_origin", "sequence_level_calls"}:
                raise SourceError(f"Reserved attribute {key!r}; supply only documented source traits")
            if value is not None and not isinstance(value, (str, int, float, bool)):
                raise SourceError(f"Attribute {key} must be scalar or null")
            if isinstance(value, float) and not math.isfinite(value):
                raise SourceError(f"Nonfinite attribute {key}")
        nodes[node_id] = row
    children: dict[str, list[str]] = {node_id: [] for node_id in nodes}
    roots = []
    for node_id, row in nodes.items():
        parent_id = row.get("parent_id")
        if parent_id is None:
            roots.append(node_id)
            if row.get("branch_length") is not None:
                _number(row["branch_length"], f"Root branch length at {node_id}")
            if row.get("branch_length") not in (None, 0):
                stem = source.get("root_stem", {})
                if mode != "published" or not stem.get("description") or stem.get("length") != row.get("branch_length"):
                    raise SourceError("Nonzero root stem requires matching, documented root_stem")
                _number(stem["length"], "Root stem")
        else:
            parent_id = _id(parent_id)
            if parent_id not in nodes:
                raise SourceError(f"Unknown parent {parent_id} for {node_id}")
            if node_id == parent_id:
                raise SourceError(f"Self-parent at {node_id}")
            children[parent_id].append(node_id)
            length = row.get("branch_length")
            if mode == "published":
                _number(length, f"Branch length at {node_id}")
            elif length is not None:
                raise SourceError("Topology mode cannot silently replace provided branch lengths")
    if len(roots) != 1:
        raise SourceError(f"Exactly one source root is required; found {len(roots)}")
    if source.get("root_id") is not None and _id(source["root_id"]) != roots[0]:
        raise SourceError("Declared source root_id differs from directed source graph")
    if "root_stem" in source:
        stem = source["root_stem"]
        if mode != "published" or not isinstance(stem, dict) or not stem.get("description"):
            raise SourceError("root_stem requires published mode and a source description")
        _number(stem.get("length"), "Root stem")
        if stem["length"] != nodes[roots[0]].get("branch_length"):
            raise SourceError("root_stem length differs from the source root branch length")
    visited = set()
    pending = [roots[0]]
    while pending:
        node_id = pending.pop()
        if node_id in visited:
            raise SourceError("Cycle or repeated traversal in source")
        visited.add(node_id)
        pending.extend(children[node_id])
    if visited != set(nodes):
        raise SourceError("Disconnected nodes or cycle outside source root")
    if sum(not values for values in children.values()) < 2:
        raise SourceError("Select a reconstruction with at least two terminal nodes")
    return nodes, children, roots[0]


def walk_tree(tree: dict):
    yield tree
    for child in tree.get("children", []):
        yield from walk_tree(child)


def _title(key: str) -> str:
    return key.replace("_", " ").capitalize()


def convert(source: dict, *, updated: str = "2026-10-18", input_sha256: str | None = None) -> dict:
    """Return an Auspice v2 dataset; never fit, prune, reroot, or join trees."""
    nodes, children, root_id = validate_source(source)
    spec = source["branch_length"]
    provenance = source["source"]
    published = spec["mode"] == "published"
    lengths = "Published branch lengths" if published else "Topology only (one display unit per edge)"
    patient = str(source["patient_id"])
    tumor = str(source["tumor_id"])
    histology = source.get("histology")
    regions = {str(row["region_id"]).lower(): row for row in source.get("regions", [])}
    stem_length = source.get("root_stem", {}).get("length", 0)
    has_display_origin = stem_length > 0
    description = (
        f"## Published lung-cancer reconstruction: {tumor}\n\n"
        f"This is a **format-integration demonstration** of one published tumour tree in the genuine "
        f"Nextstrain Auspice application. It is not a new evolutionary inference or a population-level progression model. "
        f"Separate patients are never connected.\n\n"
        f"**Source:** [{provenance['publication_title']}]({provenance['publication_url']}). "
        f"[Published data]({provenance['data_url']}); [source terms: {provenance['license']}]({provenance['license_url']}).\n\n"
        f"**Displayed horizontal distance:** {spec['description']} Units: **{spec['units']}**. "
        f"Auspice's built-in distance control/axis may call this 'Divergence'; the units are those stated here. "
        f"{spec['source_evidence']}\n\n"
        f"**Nodes:** source node IDs, labels, directed edges and multifurcations are retained. "
        f"Terminal nodes are terminal nodes of the published reconstruction; a terminal clone is not automatically "
        f"a sampled tissue region. Source node types are shown explicitly. Internal nodes are part of the authors' "
        f"inferred reconstruction, not directly observed ancestral tumours.\n\n"
        f"**Not supplied:** calibrated evolutionary dates, geography, sequence reconstruction, new mutation assignments, "
        f"or branch support. No map, clock, mutation/entropy panel or date slider is requested. "
        f"Uncertainty in the original reconstruction is not resolved by displaying it. "
        f"Auspice may show **'No sequence changes observed'** in its standard sequence popup when no "
        f"sequence-level mutation strings were supplied. Here that phrase means **sequence-level calls not supplied**, "
        f"not zero somatic mutations; use the published cluster SNV counts. The per-node sequence-call status "
        f"is an adapter evidence-status note, not a measured source trait.\n\n"
        f"**Provenance:** `{provenance['source_file']}`; raw SHA256 `{provenance['sha256']}`. "
        f"Input extract SHA256 `{input_sha256 or 'not recorded for in-memory conversion'}`. "
        f"Integration build date {updated}; this is not a patient sampling date."
    )
    if not published:
        description += "\n\n**Topology-only caution:** Edge depth is a display convention, not mutation burden, elapsed time, fitness, or evidence strength."
    if regions:
        description += "\n\n## Source regional specimens\n\nRegional colourings report the source cancer-cell-fraction (CCF) estimates for each inferred cluster. Each sampled region may contain several clones. Regional morphology describes the specimen; it is not a clone-level phenotype.\n\n"
        description += "| Region | Published specimen label | Source histology | Regional growth pattern |\n|---|---|---|---|\n"
        for region in regions.values():
            description += f"| {region['region_id']} | {region['published_specimen_label']} | {region.get('histology', 'Not supplied')} | {region.get('regional_growth_pattern', 'Not supplied')} |\n"
        if source.get("ccf_units"):
            description += f"\n**CCF units:** {source['ccf_units']}\n"
    if has_display_origin:
        description += (
            f"\n\n**Display origin:** An explicitly marked, display-only anchor at zero retains the source "
            f"root cluster's incoming truncal stem of **{stem_length} {spec['units']}**. "
            f"{source['root_stem']['description']} The anchor is not a published clone, a sampled normal, "
            f"or an inferred biological ancestor. Removing this display anchor gives exactly the published "
            f"source graph. Auspice may call terminal clones 'genomes' in its standard interface; this wording "
            f"does not establish sequenced clones or independently sampled regions."
        )

    def make_node(node_id: str, cumulative: int | float) -> dict:
        row = nodes[node_id]
        has_children = bool(children[node_id])
        attrs = {
            "div": cumulative,
            "source_node_id": {"value": node_id},
            "source_label": {"value": str(row["label"])},
            "source_node_type": {"value": str(row["source_node_type"])},
            "node_role": {"value": "Internal node in published tree" if has_children else "Terminal node in published tree"},
            "patient_id": {"value": patient},
            "tumor_id": {"value": tumor},
            "display_origin": {"value": False},
            "sequence_level_calls": {"value": "Not supplied; use published SNV counts"},
        }
        if histology:
            attrs["histology"] = {"value": str(histology)}
        if published and (node_id != root_id or has_display_origin):
            attrs["source_branch_length"] = {"value": row["branch_length"]}
        for key, value in row.get("attributes", {}).items():
            if value is not None and value != "":
                attrs[key] = {"value": value}
        node = {
            "name": f"node_{quote(node_id, safe='-_.~')}",
            "node_attrs": attrs,
            "branch_attrs": {"labels": {"source": str(row["label"])}}
        }
        if has_children:
            node["children"] = [make_node(child_id, cumulative + (nodes[child_id]["branch_length"] if published else 1)) for child_id in children[node_id]]
        return node

    tree = make_node(root_id, stem_length)
    if has_display_origin:
        tree = {
            "name": "DISPLAY_ORIGIN_NOT_A_BIOLOGICAL_CLONE",
            "node_attrs": {
                "div": 0,
                "node_role": {"value": "Display origin (not a biological clone)"},
                "display_origin": {"value": True},
            },
            "branch_attrs": {"labels": {"source": "Display origin (not a clone)"}},
            "children": [tree],
        }
    colorings = [
        {"key": "node_role", "title": "Position in published tree", "type": "categorical", "scale": [["Internal node in published tree", "#785EF0"], ["Terminal node in published tree", "#009E73"], ["Display origin (not a biological clone)", "#888888"]]},
        {"key": "display_origin", "title": "Display-only origin anchor", "type": "boolean"},
        {"key": "source_node_type", "title": "Source node type", "type": "categorical"},
        {"key": "sequence_level_calls", "title": "Sequence-level calls (integration status)", "type": "categorical"},
        {"key": "source_label", "title": "Source node label", "type": "categorical"},
        {"key": "source_node_id", "title": "Source node ID", "type": "categorical"},
        {"key": "patient_id", "title": "Published patient ID", "type": "categorical"},
        {"key": "tumor_id", "title": "Published tumour ID", "type": "categorical"},
    ]
    if histology:
        colorings.append({"key": "histology", "title": "Source histology", "type": "categorical"})
    if published:
        colorings.append({"key": "source_branch_length", "title": f"Incoming edge: {spec['units']}", "type": "continuous"})
    extra_keys = sorted({key for row in nodes.values() for key, value in row.get("attributes", {}).items() if value is not None and value != ""})
    for key in extra_keys:
        values = [row.get("attributes", {}).get(key) for row in nodes.values()]
        present = [value for value in values if value is not None and value != ""]
        kind = "continuous" if all(isinstance(value, (float, int)) and not isinstance(value, bool) for value in present) else "categorical"
        coloring = {"key": key, "title": _title(key), "type": kind}
        ccf_match = re.fullmatch(r"region_(r[0-9]+)_ccf_percent", key)
        clonality_match = re.fullmatch(r"region_(r[0-9]+)_clonality", key)
        if ccf_match:
            region_id = ccf_match[1]
            growth_pattern = regions.get(region_id, {}).get("regional_growth_pattern")
            coloring["title"] = f"{region_id.upper()} CCF (%)" + (f" · {growth_pattern} region" if growth_pattern else "")
            # Explicit source-value domain; estimates >100 remain >100, never clamped.
            highest = max(100, max(present))
            coloring["scale"] = [[0, "#DDE6EE"], [highest / 2, "#00A5B5"], [highest, "#6B3DA7"]]
        elif clonality_match:
            coloring["title"] = f"{clonality_match[1].upper()} source clonality"
            coloring["scale"] = [["absent", "#B5BEC7"], ["subclonal", "#FFB000"], ["clonal", "#DC267F"]]
        elif key == "snv_count":
            coloring["title"] = "Published cluster SNV count"
        elif key == "cluster_id":
            coloring["title"] = "Published mutation cluster ID"
        colorings.append(coloring)
    default_color = "region_r3_ccf_percent" if "region_r3_ccf_percent" in extra_keys else "node_role"
    result = {
        "version": "v2",
        "meta": {
            "title": f"TRACERx {histology + ' ' if histology else ''}published tumour {tumor} — {lengths}",
            "updated": updated,
            "description": description,
            "warning": f"Published single-tumour reconstruction · {lengths} · {spec['units']}. Integration proof; no across-patient ancestry inferred.",
            "maintainers": [{"name": "GeNeDis research integration demonstration"}],
            "data_provenance": [{"name": provenance["publication_title"], "url": provenance["publication_url"]}, {"name": "Published tree data", "url": provenance["data_url"]}],
            "colorings": colorings,
            "filters": ["source_node_type", "node_role"],
            "panels": ["tree"],
            "stream_labels": [],
            "display_defaults": {"distance_measure": "div", "layout": "rect", "color_by": default_color, "branch_label": "none", "tip_label": "source_label", "sidebar": "open"},
            "sharing": {"dataset_json": True, "metadata_tsv": True, "authors": False, "trees": True, "entropy": False, "screenshot": True},
        },
        "tree": tree,
    }
    validate_fidelity(source, result)
    return result


def validate_fidelity(source: dict, dataset: dict) -> dict:
    """Compare source and result independently, including every edge and length."""
    nodes, children, root_id = validate_source(source)
    rendered_nodes = list(walk_tree(dataset["tree"]))
    output_nodes = [node for node in rendered_nodes if not node["node_attrs"].get("display_origin", {}).get("value", False)]
    anchors = [node for node in rendered_nodes if node["node_attrs"].get("display_origin", {}).get("value", False)]
    stem_length = source.get("root_stem", {}).get("length", 0)
    if stem_length > 0:
        if len(anchors) != 1 or anchors[0] is not dataset["tree"]:
            raise SourceError("Source stem requires exactly one explicit display origin at the root")
        anchor = anchors[0]
        if anchor["node_attrs"]["div"] != 0 or "source_node_id" in anchor["node_attrs"] or len(anchor.get("children", [])) != 1:
            raise SourceError("Display origin must be zero, unassigned to a source ID, and have one child")
        source_root = anchor["children"][0]
    else:
        if anchors:
            raise SourceError("Unexpected display origin without source stem")
        source_root = dataset["tree"]
    ids = [node["node_attrs"]["source_node_id"]["value"] for node in output_nodes]
    if Counter(ids) != Counter(nodes.keys()):
        raise SourceError("Converted node set differs from source")
    if len({node["name"] for node in output_nodes}) != len(output_nodes):
        raise SourceError("Auspice names are not unique")
    expected_edges = {(parent, child) for parent, child_ids in children.items() for child in child_ids}
    actual_edges = set()
    for node in output_nodes:
        node_id = node["node_attrs"]["source_node_id"]["value"]
        if node["node_attrs"]["source_label"]["value"] != str(nodes[node_id]["label"]):
            raise SourceError(f"Source label changed at {node_id}")
        if node["node_attrs"]["source_node_type"]["value"] != nodes[node_id]["source_node_type"]:
            raise SourceError(f"Source node type changed at {node_id}")
        if source["branch_length"]["mode"] == "published" and (node_id != root_id or stem_length > 0):
            if node["node_attrs"].get("source_branch_length", {}).get("value") != nodes[node_id]["branch_length"]:
                raise SourceError(f"Source branch-length trait changed at {node_id}")
        for key, value in nodes[node_id].get("attributes", {}).items():
            if value is not None and value != "" and node["node_attrs"].get(key, {}).get("value") != value:
                raise SourceError(f"Source trait {key} changed at {node_id}")
        for child in node.get("children", []):
            child_id = child["node_attrs"]["source_node_id"]["value"]
            actual_edges.add((node_id, child_id))
            length = child["node_attrs"]["div"] - node["node_attrs"]["div"]
            expected_length = nodes[child_id]["branch_length"] if source["branch_length"]["mode"] == "published" else 1
            if not math.isclose(length, expected_length, rel_tol=1e-12, abs_tol=1e-12):
                raise SourceError(f"Displayed edge length changed at {child_id}")
    if expected_edges != actual_edges:
        raise SourceError("Converted directed edge set differs from source")
    actual_root = source_root["node_attrs"]["source_node_id"]["value"]
    if actual_root != root_id or source_root["node_attrs"]["div"] != stem_length:
        raise SourceError("Root changed")
    if dataset["meta"]["panels"] != ["tree"]:
        raise SourceError("Unexpected non-tree panel")
    for node in output_nodes:
        if "num_date" in node["node_attrs"] or "mutations" in node.get("branch_attrs", {}):
            raise SourceError("Unexpected invented dates or mutation assignments")
    return {"source_nodes": len(nodes), "output_source_nodes": len(output_nodes), "display_origin_nodes": len(anchors), "rendered_nodes": len(rendered_nodes), "source_directed_edges": len(expected_edges), "rendered_edges": len(rendered_nodes) - 1, "terminal_nodes": sum(not row for row in children.values()), "root_id": root_id, "root_stem_length": stem_length, "branch_length_mode": source["branch_length"]["mode"], "branch_length_units": source["branch_length"]["units"], "node_set_preserved": True, "directed_edges_preserved": True, "source_labels_preserved": True, "branch_lengths_preserved": True}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path(__file__).parent / "source" / "selected_published_tree.json")
    parser.add_argument("--output", type=Path, default=Path(__file__).parent / "datasets" / "lungcancer_tracerx_published.json")
    parser.add_argument("--report", type=Path, default=Path(__file__).parent / "validation_report.json")
    parser.add_argument("--updated", default="2026-10-18", help="Build date, never a patient/sample date")
    args = parser.parse_args()
    raw = args.source.read_bytes()
    source = json.loads(raw)
    dataset = convert(source, updated=args.updated, input_sha256=hashlib.sha256(raw).hexdigest())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(dataset, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    report = validate_fidelity(source, dataset)
    report.update({"source_extract_sha256": hashlib.sha256(raw).hexdigest(), "dataset_sha256": hashlib.sha256(args.output.read_bytes()).hexdigest(), "dataset_file": args.output.name, "source_file": source["source"]["source_file"], "source_file_sha256": source["source"]["sha256"], "scientific_inference_performed": False})
    args.report.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
