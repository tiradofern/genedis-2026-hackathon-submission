"""Fetch the unmodified official Augur schemas at one pinned Git commit."""
import hashlib
import json
from pathlib import Path
import urllib.request

COMMIT = "5b6ddcb26d5aaf1dc9c8991758f404c24e7b0d69"
FILES = ["schema-export-v2.json", "schema-auspice-config-v2.json", "schema-annotations.json", "schema-export-root-sequence.json"]


def main():
    output = Path(__file__).parent / "schemas"
    output.mkdir(parents=True, exist_ok=True)
    manifest = {"repository": "https://github.com/nextstrain/augur", "commit": COMMIT, "files": []}
    for name in FILES:
        url = f"https://raw.githubusercontent.com/nextstrain/augur/{COMMIT}/augur/data/{name}"
        data = urllib.request.urlopen(url).read()
        schema = json.loads(data)
        (output / name).write_bytes(data)
        manifest["files"].append({"file": name, "url": url, "id": schema["$id"], "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
    license_url = f"https://raw.githubusercontent.com/nextstrain/augur/{COMMIT}/LICENSE.txt"
    license_data = urllib.request.urlopen(license_url).read()
    (output / "UPSTREAM_LICENSE.txt").write_bytes(license_data)
    manifest["license"] = {"file": "UPSTREAM_LICENSE.txt", "url": license_url, "sha256": hashlib.sha256(license_data).hexdigest()}
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
