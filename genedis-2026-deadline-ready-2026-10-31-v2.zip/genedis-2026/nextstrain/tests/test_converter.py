"""Fidelity/invalid-source checks; fixtures are explicitly fictional and not app data."""
from pathlib import Path
import copy
import importlib.util
import json
import math
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).parent))
from schema_validation import validate_dataset

spec = importlib.util.spec_from_file_location("tree_converter", ROOT / "convert_published_tree.py")
adapter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(adapter)


def fictional_tree():
    """A polytomy, zero-length edge, nonuniform distances and an explicit root stem."""
    return {
        "patient_id": "FICTIONAL_TEST_PATIENT", "tumor_id": "FICTIONAL_TEST_TUMOR", "histology": "Fictional test histology",
        "source": {"publication_title": "Fictional test fixture, never displayed in the application", "publication_url": "https://example.org/fixture", "data_url": "https://example.org/data", "license": "Fictional", "license_url": "https://example.org/terms", "source_file": "fictional.rds", "sha256": "a" * 64},
        "branch_length": {"mode": "published", "units": "test SNVs", "description": "Fictional exact counts for parser testing", "source_evidence": "Fictional fixture only"},
        "root_stem": {"length": 259, "description": "Fictional truncal test stem, no normal observation"},
        "nodes": [
            {"id": "2", "label": "2", "parent_id": None, "branch_length": 259, "source_node_type": "Inferred mutation cluster", "attributes": {"test_count": 259}},
            {"id": "5", "label": "5", "parent_id": "2", "branch_length": 11, "source_node_type": "Inferred mutation cluster", "attributes": {}},
            {"id": "1", "label": "1", "parent_id": "5", "branch_length": 0, "source_node_type": "Inferred mutation cluster", "attributes": {}},
            {"id": "7", "label": "7", "parent_id": "5", "branch_length": 1.25, "source_node_type": "Inferred mutation cluster", "attributes": {}},
            {"id": "9", "label": "9", "parent_id": "5", "branch_length": 17.5, "source_node_type": "Inferred mutation cluster", "attributes": {}},
            {"id": "4", "label": "4", "parent_id": "2", "branch_length": 3, "source_node_type": "Inferred mutation cluster", "attributes": {}},
        ],
    }


def index(tree):
    return {node["node_attrs"]["source_node_id"]["value"]: node for node in adapter.walk_tree(tree) if "source_node_id" in node["node_attrs"]}


class ConversionTests(unittest.TestCase):
    def test_source_polytomy_nonuniform_edge_lengths_and_root_stem(self):
        source = fictional_tree()
        dataset = adapter.convert(source)
        got = index(dataset["tree"])
        self.assertEqual(set(got), {"1", "2", "4", "5", "7", "9"})
        # Independent hard-coded expected root-to-cluster cumulative distances.
        self.assertEqual({key: node["node_attrs"]["div"] for key, node in got.items()}, {"2": 259, "5": 270, "1": 270, "7": 271.25, "9": 287.5, "4": 262})
        self.assertEqual({node["node_attrs"]["source_node_id"]["value"] for node in got["5"]["children"]}, {"1", "7", "9"})
        self.assertEqual(dataset["tree"]["node_attrs"]["div"], 0)
        self.assertTrue(dataset["tree"]["node_attrs"]["display_origin"]["value"])
        self.assertNotIn("source_node_id", dataset["tree"]["node_attrs"])
        self.assertIn("not a biological clone", dataset["tree"]["node_attrs"]["node_role"]["value"])
        self.assertEqual(got["2"]["node_attrs"]["source_branch_length"]["value"], 259)
        report = adapter.validate_fidelity(source, dataset)
        self.assertEqual((report["source_nodes"], report["source_directed_edges"], report["rendered_nodes"], report["rendered_edges"], report["root_stem_length"]), (6, 5, 7, 6, 259))

    def test_official_schema_on_meaningful_fixture_and_does_reject_errors(self):
        dataset = adapter.convert(fictional_tree())
        validate_dataset(dataset)
        invalid = copy.deepcopy(dataset)
        invalid["meta"]["panels"] = ["invented_panel"]
        with self.assertRaises(ValueError):
            validate_dataset(invalid)
        invalid = copy.deepcopy(dataset)
        invalid["tree"]["node_attrs"]["div"] = "wrong_type"
        with self.assertRaises(ValueError):
            validate_dataset(invalid)

    def test_rejects_silently_discarded_or_mismatched_root_stem(self):
        for mutate in (lambda s: s.pop("root_stem"), lambda s: s["root_stem"].update(length=258)):
            source = fictional_tree()
            mutate(source)
            with self.assertRaises(adapter.SourceError):
                adapter.convert(source)

    def test_rejects_forests_cycles_duplicate_ids_and_unknown_parents(self):
        changes = [
            lambda s: s["nodes"][1].update(parent_id=None, branch_length=0),
            lambda s: s["nodes"][1].update(parent_id="1"),
            lambda s: s["nodes"][1].update(id="2"),
            lambda s: s["nodes"][1].update(parent_id="missing"),
        ]
        for mutate in changes:
            with self.subTest(mutation=mutate):
                source = fictional_tree()
                mutate(source)
                with self.assertRaises(adapter.SourceError):
                    adapter.convert(source)

    def test_rejects_mixed_patients_or_tumors(self):
        for key in ("patient_id", "tumor_id"):
            source = fictional_tree()
            source["nodes"][2][key] = "DIFFERENT_FICTIONAL_PATIENT"
            with self.assertRaises(adapter.SourceError):
                adapter.convert(source)

    def test_rejects_missing_negative_or_nonfinite_lengths(self):
        for value in (None, -1, math.nan, math.inf, "11", True):
            with self.subTest(length=value):
                source = fictional_tree()
                source["nodes"][1]["branch_length"] = value
                with self.assertRaises(adapter.SourceError):
                    adapter.convert(source)

    def test_fidelity_detects_rerooting_rewiring_id_length_or_trait_changes(self):
        source = fictional_tree()
        mutations = [
            lambda d, n: n["7"]["node_attrs"].update(div=999),
            lambda d, n: n["2"]["node_attrs"].update(div=0),
            lambda d, n: n["5"]["node_attrs"]["source_node_id"].update(value="changed"),
            lambda d, n: n["2"]["node_attrs"]["test_count"].update(value=1),
            lambda d, n: n["2"]["node_attrs"]["source_branch_length"].update(value=0),
            lambda d, n: n["5"].update(children=n["5"]["children"][:-1]),
            lambda d, n: n["4"].update(children=[n["7"]]),
        ]
        for mutate in mutations:
            with self.subTest(mutation=mutate):
                dataset = adapter.convert(source)
                mutate(dataset, index(dataset["tree"]))
                with self.assertRaises((adapter.SourceError, KeyError)):
                    adapter.validate_fidelity(source, dataset)

    def test_topology_only_explicit_units_and_no_silent_length_replacement(self):
        source = fictional_tree()
        source.pop("root_stem")
        source["branch_length"] = {"mode": "topology", "units": "display edges", "description": "One layout unit per source edge", "source_evidence": "Source lengths unavailable in fictional fixture"}
        for row in source["nodes"]:
            row["branch_length"] = None
        dataset = adapter.convert(source)
        self.assertIn("Topology only", dataset["meta"]["title"])
        self.assertIn("not mutation burden", dataset["meta"]["description"])
        self.assertEqual(index(dataset["tree"])["7"]["node_attrs"]["div"], 2)
        validate_dataset(dataset)
        source["nodes"][1]["branch_length"] = 11
        with self.assertRaises(adapter.SourceError):
            adapter.convert(source)

    def test_no_dates_geography_mutations_sequences_or_unsupported_panels(self):
        dataset = adapter.convert(fictional_tree())
        self.assertEqual(dataset["meta"]["panels"], ["tree"])
        for key in ("genome_annotations", "geo_resolutions"):
            self.assertNotIn(key, dataset["meta"])
        self.assertNotIn("root_sequence", dataset)
        for node in adapter.walk_tree(dataset["tree"]):
            self.assertNotIn("num_date", node["node_attrs"])
            self.assertNotIn("mutations", node.get("branch_attrs", {}))


class PublishedSourceIntegrationTests(unittest.TestCase):
    def test_local_published_extract_has_exact_nodes_edges_lengths_and_valid_schema(self):
        source_path = ROOT / "source" / "selected_published_tree.json"
        if not source_path.exists():
            self.skipTest("Run the published-source retrieval/extraction first; fixture tests are not a published-data test")
        source = json.loads(source_path.read_text(encoding="utf-8"))
        dataset = adapter.convert(source)
        validate_dataset(dataset)
        # An independent source-driven ancestor walk checks every cumulative length.
        source_nodes = {str(node["id"]): node for node in source["nodes"]}
        got = index(dataset["tree"])
        self.assertEqual(set(source_nodes), set(got))
        for key, row in source_nodes.items():
            total = 0
            current = row
            while True:
                total += current["branch_length"] or 0
                if current["parent_id"] is None:
                    break
                current = source_nodes[str(current["parent_id"])]
            self.assertAlmostEqual(got[key]["node_attrs"]["div"], total, places=10)
        expected_edges = {(str(row["parent_id"]), str(row["id"])) for row in source["nodes"] if row["parent_id"] is not None}
        got_edges = {(parent, child["node_attrs"]["source_node_id"]["value"]) for parent, node in got.items() for child in node.get("children", [])}
        self.assertEqual(expected_edges, got_edges)


if __name__ == "__main__":
    unittest.main()
