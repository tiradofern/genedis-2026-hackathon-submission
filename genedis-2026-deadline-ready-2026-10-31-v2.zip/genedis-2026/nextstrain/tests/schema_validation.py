"""Validate offline against complete, unmodified, hash-pinned upstream schemas."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".validation-deps"))


def official_validator():
    try:
        from jsonschema import Draft6Validator
        from referencing import Registry, Resource
    except ImportError as error:
        raise RuntimeError("Install the isolated validator: python -m pip install --target nextstrain/.validation-deps -r nextstrain/tests/requirements-validation.txt") from error
    folder = Path(__file__).parent / "schemas"
    manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    resources = []
    schemas = {}
    for item in manifest["files"]:
        raw = (folder / item["file"]).read_bytes()
        if hashlib.sha256(raw).hexdigest() != item["sha256"]:
            raise ValueError(f"Pinned official schema hash mismatch: {item['file']}")
        schema = json.loads(raw)
        if schema["$id"] != item["id"]:
            raise ValueError(f"Pinned official schema identity mismatch: {item['file']}")
        schemas[item["file"]] = schema
        resources.append((item["id"], Resource.from_contents(schema)))
    registry = Registry().with_resources(resources)
    validator = Draft6Validator(schemas["schema-export-v2.json"], registry=registry)
    return validator


def validate_dataset(dataset):
    errors = sorted(official_validator().iter_errors(dataset), key=lambda e: str(list(e.absolute_path)))
    if errors:
        raise ValueError("\n".join(f"{list(error.absolute_path)}: {error.message}" for error in errors))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python nextstrain/tests/schema_validation.py DATASET.json")
    validate_dataset(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8")))
    print("PASS: official Augur v2 schema and all pinned schema-file hashes")
