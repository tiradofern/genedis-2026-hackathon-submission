These four JSON schemas are unmodified copies from the official Nextstrain Augur
repository, commit `5b6ddcb26d5aaf1dc9c8991758f404c24e7b0d69`.

`manifest.json` records each pinned source URL, schema ID, byte count and SHA256.
The validator checks these hashes and resolves references locally, so validating a
dataset requires no network requests. `UPSTREAM_LICENSE.txt` retains the source
repository's license. This license is separate from the published tumour data
terms recorded in the source extract and project guide.

Reacquire the same files with `python nextstrain/tests/download_schemas.py`.
Install the isolated validation dependencies using the pinned requirements in
`nextstrain/tests/requirements-validation.txt`, then run
`python -m unittest discover -s nextstrain/tests -v`.
