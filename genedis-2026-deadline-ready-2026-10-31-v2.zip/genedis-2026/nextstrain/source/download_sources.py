"""Download pinned public processed TRACERx source files and verify integrity.

The depositor restricts these data to academic non-commercial use. Read
docs/NEXTSTRAIN_SOURCE.md and the linked Zenodo record before reuse.
This does not retrieve controlled-access WES/RNA-seq or change the source manifest.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import urllib.request

HERE = Path(__file__).resolve().parent


def verify(path: Path, entry: dict) -> None:
    contents = path.read_bytes()
    for name, actual in (("bytes", len(contents)),
                         ("sha256", hashlib.sha256(contents).hexdigest()),
                         ("md5", hashlib.md5(contents).hexdigest())):
        if actual != entry[name]:
            raise ValueError(f"{entry['filename']}: pinned {name} mismatch; refusing source")


def download(raw_dir: Path, offline: bool = False) -> None:
    manifest = json.loads((HERE / "source_manifest.json").read_text(encoding="utf-8-sig"))
    raw_dir.mkdir(parents=True, exist_ok=True)
    for entry in manifest:
        target = raw_dir / entry["filename"]
        if target.is_file():
            verify(target, entry)
            print(f"Verified {target.name}: {entry['bytes']} bytes", flush=True)
            continue
        if offline:
            raise FileNotFoundError(f"Missing pinned source in offline verification: {target.name}")
        # Keep unverified payloads separate. Failed transfers never become source files.
        temporary = target.with_name(target.name + ".partial")
        request = urllib.request.Request(entry["url"], headers={"User-Agent": "GeNeDis-TRACERx-local-proof/1.0"})
        print(f"Downloading {target.name}", flush=True)
        with urllib.request.urlopen(request, timeout=120) as response, temporary.open("wb") as output:
            while chunk := response.read(1024 * 1024):
                output.write(chunk)
        verify(temporary, entry)
        temporary.replace(target)
        print(f"Verified {target.name}: {entry['bytes']} bytes", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, default=HERE / "raw")
    parser.add_argument("--verify-only", action="store_true", help="Check all pinned files without network access")
    args = parser.parse_args()
    download(args.raw_dir, offline=args.verify_only)


if __name__ == "__main__":
    main()
