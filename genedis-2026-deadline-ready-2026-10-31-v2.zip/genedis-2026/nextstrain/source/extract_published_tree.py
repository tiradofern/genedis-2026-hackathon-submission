"""Extract, rather than re-infer, one published TRACERx clonal reconstruction.

Run from any directory. Download the checked inputs first with download_sources.py.
The full RDS parsing step can take several minutes. No clinical model is fitted.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
import warnings

HERE = Path(__file__).resolve().parent
if (HERE / "_deps").is_dir():
    sys.path.insert(0, str(HERE / "_deps"))

TREE_FILE = "20221109_TRACERx421_phylogenetic_trees.rds"
TUMOUR_FILE = "20221109_TRACERx421_all_tumour_df.rds"
REGION_FILE = "20221109_LUAD_input_plot_df_all_LUAD_region_df_full.RDS"
SCRIPT_FILE = "Fig.3bd.S4abcdefgh.R"


def checked_manifest(raw_dir: Path) -> list[dict]:
    manifest = json.loads((HERE / "source_manifest.json").read_text(encoding="utf-8-sig"))
    for entry in manifest:
        payload = (raw_dir / entry["filename"]).read_bytes()
        if len(payload) != entry["bytes"]:
            raise ValueError(f"Source size changed: {entry['filename']}")
        if hashlib.sha256(payload).hexdigest() != entry["sha256"]:
            raise ValueError(f"Source SHA256 mismatch: {entry['filename']}")
        if hashlib.md5(payload).hexdigest() != entry["md5"]:
            raise ValueError(f"Source Zenodo MD5 mismatch: {entry['filename']}")
    return manifest


def edge_pairs(value) -> list[tuple[str, str]]:
    """The deposited Corrected_tree is an R column-major edge vector.

    Verify interpretation against independently supplied consensus_branches below.
    Do not infer parent/child direction from CCF, cluster number, or branch length.
    """
    if getattr(value, "ndim", 0) == 2:
        if value.shape[1] != 2:
            raise ValueError("Unexpected source edge matrix")
        return [(str(a), str(b)) for a, b in value]
    if len(value) % 2:
        raise ValueError("Odd source edge-vector size")
    half = len(value) // 2
    return [(str(a), str(b)) for a, b in zip(value[:half], value[half:])]


def assemble(trees, tumour_df, region_df, tumour_id: str, manifest: list[dict]) -> dict:
    import numpy as np
    import pandas as pd

    source_tree = trees[tumour_id]
    graph = source_tree["graph_pyclone"]
    edges = edge_pairs(graph["Corrected_tree"])
    source_ids = sorted({i for edge in edges for i in edge}, key=int)
    parent = {child: ancestor for ancestor, child in edges}
    if len(parent) != len(edges):
        raise ValueError("Source topology is not a single-parent tree")
    roots = set(source_ids) - set(parent)
    if len(roots) != 1:
        raise ValueError("Expected exactly one published root")
    root = roots.pop()
    for node_id in source_ids:
        cursor, visited = node_id, set()
        while cursor in parent:
            if cursor in visited:
                raise ValueError("Cycle in deposited source topology")
            visited.add(cursor)
            cursor = parent[cursor]
        if cursor != root:
            raise ValueError("Disconnected deposited source topology")
    if [str(i) for i in graph["trunk"]] != [root]:
        raise ValueError("Source trunk does not match root")

    consensus = {tuple(str(i).split(":")) for i in graph["consensus_branches"]}
    if set(edges) != consensus:
        raise ValueError("Selected example must have every source edge in consensus_branches")
    alternatives = [set(edge_pairs(tree)) for tree in graph["alt_trees"]]
    if not alternatives or any(tree != set(edges) for tree in alternatives):
        raise ValueError("Selected example must have no alternative source topology")

    counts = graph["edgelength"]
    count_labels = counts.coords[counts.dims[0]].values
    count_map = {str(k): int(v) for k, v in zip(count_labels, counts.values)}
    if not set(source_ids) <= set(count_map) or any(count_map[i] < 0 for i in source_ids):
        raise ValueError("Missing or negative source SNV count")
    ccf = source_tree["nested_pyclone"]["ccf_cluster_table"]
    ccf_ids = [str(i) for i in ccf.coords[ccf.dims[0]].values]
    ccf_regions = [str(i) for i in ccf.coords[ccf.dims[1]].values]
    ccf_map = dict(zip(ccf_ids, ccf.values))
    clonality = source_tree["clonality_out"]["clonality_table_corrected"]
    tumour_rows = tumour_df.loc[tumour_df["tumour_id_muttable_cruk"] == tumour_id]
    if len(tumour_rows) != 1 or tumour_rows.iloc[0]["histology_3"] != "LUAD":
        raise ValueError("Selected tumour must be independently source-verified LUAD")
    specimen = tumour_rows.iloc[0]
    patient_id = str(specimen["cruk_id"])

    region_rows = region_df.loc[region_df["tumour_id_muttable_cruk"] == tumour_id]
    regions = []
    for label in ccf_regions:
        short = label.rsplit(".", 1)[-1]
        matching = region_rows.loc[region_rows["region"] == short]
        if len(matching) != 1:
            raise ValueError(f"Missing or duplicate source specimen annotation: {label}")
        row = matching.iloc[0]
        sample_name = str(row["sample_name_cruk"])
        # The matrix uses '.' before R1; the regional metadata uses '-'.
        if label.replace(".", "-") != sample_name:
            raise ValueError(f"Unverified matrix-to-specimen label mapping: {label}")
        pattern = row["regional_pattern.new"]
        regions.append({
            "region_id": short,
            "ccf_matrix_label": label,
            "published_specimen_label": sample_name,
            "histology": None if pd.isna(row["Histology_per_tumour_id_muttable"]) else str(row["Histology_per_tumour_id_muttable"]),
            "regional_growth_pattern": None if pd.isna(pattern) else str(pattern),
        })

    parents = {a for a, _ in edges}
    nodes = []
    for node_id in source_ids:
        node_type = "inferred_truncal_cluster" if node_id == root else (
            "inferred_ancestral_subclone" if node_id in parents else "inferred_terminal_subclone"
        )
        values = ccf_map[node_id]
        if not np.isfinite(values).all():
            raise ValueError("Non-finite source CCF")
        attributes = {"cluster_id": node_id, "snv_count": count_map[node_id]}
        for label, value in zip(ccf_regions, values):
            short = label.rsplit(".", 1)[-1].lower()
            attributes[f"region_{short}_ccf_percent"] = float(value)
            attributes[f"region_{short}_clonality"] = str(clonality.loc[node_id, label])
        nodes.append({"id": node_id, "label": f"Cluster {node_id}",
                      "parent_id": parent.get(node_id), "branch_length": count_map[node_id],
                      "source_node_type": node_type, "attributes": attributes})

    stem_evidence = f"graph_pyclone.trunk identifies cluster {root}; graph_pyclone.edgelength assigns it {count_map[root]}; no normal-origin node is present in Corrected_tree."
    output = {
        "schema_version": "1.0",
        "source": {
            "publication_title": "Evolutionary characterization of lung adenocarcinoma morphology in TRACERx",
            "authors": "Karasaki T, Moore DA, Veeriah S, et al.; TRACERx Consortium",
            "journal": "Nature Medicine 29, 833-845 (2023)",
            "doi": "10.1038/s41591-023-02230-w", "pmid": "37045996", "pmcid": "PMC7614478",
            "publication_url": "https://doi.org/10.1038/s41591-023-02230-w",
            "data_url": "https://zenodo.org/records/7683605", "data_doi": "10.5281/zenodo.7683605",
            "license": "Academic non-commercial use only; commercial users must request access as directed by the depositor.",
            "license_url": "https://zenodo.org/records/7683605",
            "source_file": TREE_FILE,
            "sha256": next(x["sha256"] for x in manifest if x["filename"] == TREE_FILE),
            "source_object_path": f"[{tumour_id!r}]['graph_pyclone']['Corrected_tree']",
        },
        "patient_id": patient_id, "tumor_id": tumour_id, "histology": "LUAD",
        "histology_source_value": str(specimen["Histology_per_tumour_id_muttable"]),
        "tumor_predominant_growth_pattern": str(specimen["LUAD_pred_subtype_with.IMA_per_tumour"]),
        "branch_length": {
            "mode": "published", "units": "SNVs per mutation cluster",
            "description": "Each branch contains the published count of SNVs assigned to that inferred mutation cluster; cumulative root-to-node distance is an SNV count, not time or mutations per genome site.",
            "source_evidence": f"{SCRIPT_FILE}:531-535 extracts Corrected_tree clusters and labels graph_pyclone.edgelength values as numSNVs.",
        },
        "root_stem": {"length": count_map[root], "description": "Published truncal SNV burden; the source graph has no sampled normal-origin node.", "source_evidence": stem_evidence},
        "root_id": root, "nodes": nodes, "regions": regions,
        "ccf_units": "Percent as deposited in nested_pyclone.ccf_cluster_table; some estimates exceed 100. Values are not clamped or imputed.",
        "selection_reason": (
            "First tumour in the deposited tree list, independently confirmed LUAD, with four regional specimens, informative branching, and one deposited topology. Selected for an interface proof, not a biological comparison."
            if tumour_id == str(next(iter(trees))) else
            "User-specified tumour, independently confirmed LUAD, with the exact regional specimen count recorded in verification and one deposited topology. Selected for an interface proof, not a biological comparison."
        ),
        "verification": {"source_nodes": len(nodes), "source_edges": len(edges), "source_terminal_clusters": sum(i not in parents for i in source_ids),
                         "source_alternative_topologies": len(alternatives), "all_edges_equal_consensus_branches": True,
                         "all_branch_counts_equal_deposited_edgelength": True, "source_truncal_snv_count": count_map[root],
                         "root_plus_retained_branch_snv_count": sum(count_map[i] for i in source_ids), "source_ccf_regions": len(regions)},
        "source_files": manifest,
        "limitations": [
            "This is an authors' within-patient inferred clonal tree; it does not reconstruct common evolutionary routes across patients.",
            "Terminal nodes are inferred mutation clusters, not sampled specimens; each region contains a mixture of clones.",
            "Regional morphology is specimen metadata and is not assigned to individual clones.",
            "Source graph corrections and exclusions are preserved; removed clusters are not reattached.",
            "No uncertainty values are invented; consensus-branch identity is not a calibrated probability of ancestry.",
            "No raw sequence analysis, new inference, calendar-time dating, survival test, or population-level route analysis was performed.",
            "A display-only origin anchor may be added by the viewer adapter to expose the published truncal stem; it is not a published observed clone.",
            "Underlying WES/RNA-seq remain controlled-access EGA data; only public processed source data were retrieved.",
        ],
    }
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, default=HERE / "raw")
    parser.add_argument("--tumor-id", default="CRUK0005")
    parser.add_argument("--output", type=Path, default=HERE / "selected_published_tree.json")
    args = parser.parse_args()
    manifest = checked_manifest(args.raw_dir)
    import rdata
    print(f"Parsing {TREE_FILE}; this may take several minutes.", flush=True)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message='Missing constructor for R class "data.table"')
        warnings.filterwarnings("ignore", message='Missing constructor for R class "table"')
        trees = rdata.read_rds(args.raw_dir / TREE_FILE)
        tumour_df = rdata.read_rds(args.raw_dir / TUMOUR_FILE)
        region_df = rdata.read_rds(args.raw_dir / REGION_FILE)
    output = assemble(trees, tumour_df, region_df, args.tumor_id, manifest)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(output["verification"], indent=2), flush=True)
    print(f"Wrote {args.output}", flush=True)


if __name__ == "__main__":
    main()
