// A small launcher for the unmodified, official Auspice application.
// Always bind to IPv4 loopback; this prototype is not a public deployment.
import { fileURLToPath } from "node:url";

const port = process.env.PORT || "4000";
if (!/^\d+$/.test(port) || Number(port) < 1024 || Number(port) > 65535) {
  throw new Error("PORT must be an integer from 1024 through 65535.");
}
process.env.HOST = "127.0.0.1";
process.env.PORT = port;
process.argv = [
  process.execPath,
  fileURLToPath(new URL("./node_modules/auspice/auspice.js", import.meta.url)),
  "view",
  fileURLToPath(new URL("./datasets", import.meta.url)),
  fileURLToPath(new URL("./narratives", import.meta.url))
];
await import("./node_modules/auspice/auspice.js");
